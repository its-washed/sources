// Chunk 14 - 50 functions

// ============================================================
// Function: FUN_180024200
// Address: 0x180024200
// Size: 1755 bytes
// ============================================================
undefined8 fcn.180024200(int64_t arg1)
{
    code *pcVar1;
    bool bVar2;
    undefined8 *puVar3;
    char cVar4;
    undefined2 uVar5;
    int64_t iVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    undefined (*pauVar12) [16];
    int64_t iVar13;
    int64_t iVar14;
    undefined *puVar15;
    undefined *puVar16;
    undefined8 *unaff_RSI;
    undefined8 *puVar17;
    uint64_t uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_200;
    undefined auStack_1f8 [8];
    undefined auStack_1f0 [24];
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    uint32_t var_f8h;
    int64_t var_f4h;
    undefined4 var_ech;
    uint8_t var_e8h;
    int64_t var_e0h;
    int64_t var_cch;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar14 = *(int64_t *)0x180781f30;
    puVar16 = auStack_1f8;
    puVar15 = auStack_1f8;
    puVar17 = (undefined8 *)0x0;
    var_a8h = 0;
    var_a0h._0_1_ = 0;
    _var_98h = ZEXT816(0);
    _var_88h = ZEXT816(0);
    var_78h = 0;
    var_70h._0_1_ = 0;
    _var_68h = ZEXT816(0);
    var_58h._0_1_ = 0;
    var_50h = 0;
    var_48h = 0;
    var_40h._0_1_ = 0;
    var_10h = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        var_10h = *(int64_t *)arg1;
    }
    iVar10 = var_10h;
    iVar13 = *(int64_t *)(arg1 + 0x10) + var_10h;
    if (*(int64_t *)0x180781f30 != 0) {
        var_f8h = *(uint32_t *)(*(int64_t *)0x180781f30 + 0x20);
        var_ech = *(undefined4 *)(*(int64_t *)0x180781f30 + 0x28);
        _var_1c8h = ZEXT816(0);
        _var_1b8h = ZEXT816(0);
        var_1a8h = 0;
        var_1a0h = 0;
        _var_198h = ZEXT816(0);
        _var_188h = ZEXT816(0);
        _var_178h = ZEXT816(0);
        var_168h = 0;
        var_160h = 0;
        _var_158h = ZEXT816(0);
        _var_148h = ZEXT816(0);
        var_138h = 0;
        var_130h = 0;
        _var_128h = ZEXT816(0);
        var_100h = *(int64_t *)0x180781f30;
        var_f4h._0_4_ = 0;
        var_f4h._4_1_ = 0;
        var_e8h = *(uint8_t *)(*(int64_t *)0x180781f30 + 0xc) >> 3 & 1;
        var_e0h = 0x180781f38;
        var_cch._0_4_ = 0;
        var_cch._4_2_ = 0;
        uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)0x180781f30 + 0x24);
        puVar16 = auStack_1f8;
        var_110h = var_10h;
        var_108h = iVar13;
        if (uVar11 != 0) {
            if (0xfffffffffffffff < uVar11) {
                func_0x000180010010();
                pcVar1 = (code *)swi(3);
                uVar8 = (*pcVar1)();
                return uVar8;
            }
            uVar18 = uVar11 * 0x10;
            uVar9 = uVar11;
            puVar3 = puVar17;
            if (uVar11 == 0) {
code_r0x0001800243a0:
                do {
                    unaff_RSI = puVar3;
                    *puVar17 = 0;
                    puVar17[1] = 0;
                    puVar17 = puVar17 + 2;
                    uVar9 = uVar9 - 1;
                    puVar3 = unaff_RSI;
                } while (uVar9 != 0);
                func_0x000180498030(unaff_RSI, var_148h, var_140h - var_148h);
                if (var_148h != 0) {
                    iVar6 = var_148h;
                    puVar15 = auStack_1f8;
                    if ((0xfff < (var_138h - var_148h & 0xfffffffffffffff0U)) &&
                       (iVar6 = *(int64_t *)(var_148h + -8), puVar15 = auStack_1f8, 0x1f < (var_148h - iVar6) - 8U))
                    goto code_r0x0001800243fc;
                    goto code_r0x000180024406;
                }
            } else {
                if (uVar18 < 0x1000) {
                    puVar17 = (undefined8 *)func_0x000180459890(uVar18);
                    puVar3 = puVar17;
                    goto code_r0x0001800243a0;
                }
                if (uVar18 + 0x27 <= uVar18) {
                    func_0x000180004720();
                    pcVar1 = (code *)swi(3);
                    uVar8 = (*pcVar1)();
                    return uVar8;
                }
                iVar6 = func_0x000180459890();
                if (iVar6 != 0) {
                    puVar17 = (undefined8 *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                    puVar17[-1] = iVar6;
                    puVar3 = puVar17;
                    goto code_r0x0001800243a0;
                }
code_r0x0001800243fc:
                pcVar1 = (code *)swi(0x29);
                iVar6 = (*pcVar1)(5);
                puVar15 = auStack_1f0;
code_r0x000180024406:
                *(undefined8 *)(puVar15 + -8) = 0x18002440b;
                func_0x000180459c3c(iVar6);
            }
            var_140h = (int64_t)(unaff_RSI + uVar11 * 2);
            var_148h = (int64_t)unaff_RSI;
            var_138h = (int64_t)(unaff_RSI + uVar11 * 2);
            puVar16 = puVar15;
        }
        if ((*(uint32_t *)(iVar14 + 0xc) & 0x100) != 0) {
            var_8h._0_1_ = 0x57;
            *(undefined8 *)(puVar16 + -8) = 0x18002445a;
            uVar5 = func_0x00018002c7f0(var_e0h, &var_8h, (int64_t)&var_8h + 1, (uint8_t)(var_f8h >> 8) & 1);
            var_cch._0_4_ = CONCAT22(var_cch._2_2_, uVar5);
        }
        if ((*(uint32_t *)(iVar14 + 0xc) & 0x200) != 0) {
            var_8h._0_1_ = 0x53;
            *(undefined8 *)(puVar16 + -8) = 0x180024496;
            uVar5 = func_0x00018002c7f0(var_e0h, &var_8h, (int64_t)&var_8h + 1, (uint8_t)(var_f8h >> 8) & 1);
            var_cch._0_4_ = CONCAT22(uVar5, (undefined2)var_cch);
        }
        if ((*(uint32_t *)(iVar14 + 0xc) & 0x400) != 0) {
            var_8h._0_1_ = 0x44;
            *(undefined8 *)(puVar16 + -8) = 0x1800244d2;
            var_cch._4_2_ = func_0x00018002c7f0(var_e0h, &var_8h, (int64_t)&var_8h + 1, (uint8_t)(var_f8h >> 8) & 1);
        }
        if ((var_f8h & 0x3e) != 0) {
            var_f8h = var_f8h & 0xffffefff;
        }
        *(undefined8 *)(puVar16 + -8) = 0x1800244f3;
        cVar4 = func_0x0001800299f0(puVar16 + 0x30, &var_a8h);
        if (cVar4 == '\0') {
            bVar2 = false;
            if (iVar10 != iVar13) {
                var_f4h._0_4_ = (uint32_t)var_f4h & 0xffffdfff | 0x100;
                *(undefined4 *)(puVar16 + 0x28) = 0;
                *(undefined8 *)(puVar16 + 0x20) = 0;
                *(undefined8 *)(puVar16 + -8) = 0x18002453b;
                piVar7 = (int64_t *)func_0x000180029db0(puVar16 + 0x30, &var_8h, iVar10 + 1, iVar13);
                iVar14 = *piVar7;
                while (iVar14 != iVar13) {
                    *(undefined8 *)(puVar16 + -8) = 0x180024555;
                    var_110h = iVar14;
                    cVar4 = func_0x0001800299f0(puVar16 + 0x30, &var_a8h);
                    if (cVar4 != '\0') goto code_r0x000180024599;
                    *(undefined4 *)(puVar16 + 0x28) = 0;
                    *(undefined8 *)(puVar16 + 0x20) = 0;
                    *(undefined8 *)(puVar16 + -8) = 0x18002457b;
                    piVar7 = (int64_t *)func_0x000180029db0(puVar16 + 0x30, &var_8h, iVar14 + 1, iVar13);
                    iVar14 = *piVar7;
                }
                *(undefined8 *)(puVar16 + -8) = 0x180024595;
                var_110h = iVar13;
                cVar4 = func_0x0001800299f0(puVar16 + 0x30, &var_a8h);
                if (cVar4 != '\0') goto code_r0x000180024599;
            }
        } else {
code_r0x000180024599:
            bVar2 = true;
            var_a8h = var_10h;
            var_80h = iVar10;
            var_70h._0_1_ = iVar10 != var_78h;
        }
        if (var_130h == 0) {
code_r0x000180024675:
            if (var_148h != 0) {
                uVar11 = var_138h - var_148h & 0xfffffffffffffff0;
                iVar14 = var_148h;
                if (0xfff < uVar11) {
                    if (0x1f < (var_148h - *(int64_t *)(var_148h + -8)) - 8U) goto code_r0x0001800247f0;
                    uVar11 = uVar11 + 0x27;
                    iVar14 = *(int64_t *)(var_148h + -8);
                }
                *(undefined8 *)(puVar16 + -8) = 0x1800246b5;
                func_0x000180459c3c(iVar14, uVar11);
                _var_148h = ZEXT816(0);
                var_138h = 0;
            }
            if (var_160h != 0) {
                uVar11 = var_150h - var_160h & 0xfffffffffffffff0;
                iVar14 = var_160h;
                if (0xfff < uVar11) {
                    if (0x1f < (var_160h - *(int64_t *)(var_160h + -8)) - 8U) goto code_r0x0001800247f0;
                    uVar11 = uVar11 + 0x27;
                    iVar14 = *(int64_t *)(var_160h + -8);
                }
                *(undefined8 *)(puVar16 + -8) = 0x180024701;
                func_0x000180459c3c(iVar14, uVar11);
                var_160h = 0;
                _var_158h = ZEXT816(0);
            }
            iVar14 = *(int64_t *)(puVar16 + 0x78);
            if (iVar14 != 0) {
                uVar11 = (var_170h - iVar14 >> 2) * 4;
                if (0xfff < uVar11) {
                    if (0x1f < (iVar14 - *(int64_t *)(iVar14 + -8)) - 8U) goto code_r0x0001800247f0;
                    uVar11 = uVar11 + 0x27;
                    iVar14 = *(int64_t *)(iVar14 + -8);
                }
                *(undefined8 *)(puVar16 + -8) = 0x180024759;
                func_0x000180459c3c(iVar14, uVar11);
                *(undefined8 *)(puVar16 + 0x78) = 0;
                _var_178h = ZEXT816(0);
            }
            iVar14 = *(int64_t *)(puVar16 + 0x58);
            if (iVar14 != 0) {
                uVar11 = *(int64_t *)(puVar16 + 0x68) - iVar14 & 0xfffffffffffffff0;
                if (0xfff < uVar11) {
                    if (0x1f < (iVar14 - *(int64_t *)(iVar14 + -8)) - 8U) goto code_r0x0001800247f0;
                    uVar11 = uVar11 + 0x27;
                    iVar14 = *(int64_t *)(iVar14 + -8);
                }
                *(undefined8 *)(puVar16 + -8) = 0x1800247a4;
                func_0x000180459c3c(iVar14, uVar11);
                *(undefined8 *)(puVar16 + 0x58) = 0;
                *(undefined (*) [16])(puVar16 + 0x60) = ZEXT816(0);
            }
            iVar14 = *(int64_t *)(puVar16 + 0x38);
            if (iVar14 != 0) {
                if ((0xfff < (uint64_t)((*(int64_t *)(puVar16 + 0x48) - iVar14 >> 2) * 4)) &&
                   (iVar10 = iVar14 - *(int64_t *)(iVar14 + -8), iVar14 = *(int64_t *)(iVar14 + -8), 0x1f < iVar10 - 8U)
                   ) goto code_r0x0001800247f0;
                goto code_r0x0001800247fa;
            }
        } else {
            iVar10 = var_128h;
            for (iVar14 = var_130h; iVar14 != iVar10; iVar14 = iVar14 + 0x40) {
                iVar13 = *(int64_t *)(iVar14 + 0x28);
                if (iVar13 != 0) {
                    uVar11 = *(int64_t *)(iVar14 + 0x38) - iVar13 & 0xfffffffffffffff0;
                    if (0xfff < uVar11) {
                        if (0x1f < (iVar13 - *(int64_t *)(iVar13 + -8)) - 8U) goto code_r0x0001800247f0;
                        uVar11 = uVar11 + 0x27;
                        iVar13 = *(int64_t *)(iVar13 + -8);
                    }
                    *(undefined8 *)(puVar16 + -8) = 0x180024610;
                    func_0x000180459c3c(iVar13, uVar11);
                    *(undefined8 *)(iVar14 + 0x28) = 0;
                    *(undefined8 *)(iVar14 + 0x30) = 0;
                    *(undefined8 *)(iVar14 + 0x38) = 0;
                }
                *(undefined8 *)(puVar16 + -8) = 0x180024625;
                func_0x00018002ee50(iVar14 + 8);
            }
            uVar11 = var_120h - var_130h & 0xffffffffffffffc0;
            iVar14 = var_130h;
            if (uVar11 < 0x1000) {
code_r0x000180024664:
                *(undefined8 *)(puVar16 + -8) = 0x180024669;
                func_0x000180459c3c(iVar14, uVar11);
                var_130h = 0;
                _var_128h = ZEXT816(0);
                goto code_r0x000180024675;
            }
            if ((var_130h - *(int64_t *)(var_130h + -8)) - 8U < 0x20) {
                uVar11 = uVar11 + 0x27;
                iVar14 = *(int64_t *)(var_130h + -8);
                goto code_r0x000180024664;
            }
code_r0x0001800247f0:
            iVar14 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar16 = puVar16 + 8;
code_r0x0001800247fa:
            *(undefined8 *)(puVar16 + -8) = 0x180024802;
            func_0x000180459c3c(iVar14);
        }
        if (bVar2) {
            pauVar12 = (undefined (*) [16])&var_50h;
            if (var_90h != var_98h) {
                pauVar12 = (undefined (*) [16])var_98h;
            }
            if (pauVar12[1][0] == '\0') {
                _var_b8h = ZEXT816(0);
            } else {
                _var_b8h = *pauVar12;
            }
            *(undefined8 *)(puVar16 + -8) = 0x180024848;
            func_0x00018000dcf0(arg1, 0, var_b0h - var_b8h);
            uVar8 = 1;
            goto code_r0x00018002484a;
        }
    }
    uVar8 = 0;
code_r0x00018002484a:
    if (var_98h != 0) {
        iVar14 = var_98h;
        if ((0xfff < (uint64_t)((var_88h - var_98h >> 3) * 8)) &&
           (iVar14 = *(int64_t *)(var_98h + -8), 0x1f < (var_98h - iVar14) - 8U)) {
            iVar14 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar16 = puVar16 + 8;
        }
        *(undefined8 *)(puVar16 + -8) = 0x1800248aa;
        func_0x000180459c3c(iVar14);
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1800248f0
// Address: 0x1800248f0
// Size: 168 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cah

void fcn.1800248f0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    if ((int32_t)arg2 == 0) {
        fcn.180459870(var_18h ^ (uint64_t)auStack_58);
        return;
    }
    iVar2 = fcn.180085cd0(arg1, 0xffffffff);
    if (iVar2 == 6) {
        uVar3 = fcn.1800860c0(arg1, 0xffffffff, 0);
        fcn.1800047e0(&var_38h, uVar3);
        fcn.180024200((int64_t)&var_38h);
        fcn.1800858c0(arg1, 0xfffffffe);
        uVar3 = fcn.18000b450(&var_38h);
        fcn.1800868c0(arg1, uVar3);
        fcn.180004dd0(&var_38h);
    }
    fcn.180087960(arg1);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800249a0
// Address: 0x1800249a0
// Size: 652 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cah

void fcn.1800249a0(int64_t arg1)
{
    uint32_t *puVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    bool bVar10;
    int32_t iVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    undefined4 *puVar14;
    uint64_t uVar15;
    int64_t iVar16;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar3 = *(int64_t *)(arg1 + 0x40);
    iVar4 = *(int64_t *)(arg1 + 0x28);
    iVar5 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
    func_0x000180086ba0(arg1, iVar5, 0);
    uVar15 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    func_0x000180023f30(arg1, 0x180782490, 0);
    func_0x000180085bf0(arg1, uVar15 & 0xffffffff);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar16 = *(int64_t *)(arg1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar16 + -0x20), (undefined4 *)(iVar16 + -0x10));
    uVar7 = puVar12[1];
    uVar8 = puVar12[2];
    uVar9 = puVar12[3];
    *(undefined4 *)(iVar16 + -0x10) = *puVar12;
    *(undefined4 *)(iVar16 + -0xc) = uVar7;
    *(undefined4 *)(iVar16 + -8) = uVar8;
    *(undefined4 *)(iVar16 + -4) = uVar9;
    iVar16 = *(int64_t *)(arg1 + 0x40);
    if (((((undefined4 *)(iVar16 + -0x10) == *(undefined4 **)0x180782430) || (*(int32_t *)(iVar16 + -4) == 0)) ||
        ((undefined4 *)(iVar16 + -0x10) == *(undefined4 **)0x180782430)) || (*(int32_t *)(iVar16 + -4) == -1)) {
        *(int64_t *)(arg1 + 0x40) = iVar16 + -0x30;
        func_0x000180088560(arg1, 0x180621a98);
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    func_0x000180085a50(arg1, uVar15 & 0xffffffff);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar12 = *(undefined4 **)(arg1 + 0x40);
    puVar14 = *(undefined4 **)(arg1 + 0x28);
    if (puVar12 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar14 = *(undefined4 **)0x180782430;
    }
    while (puVar14 < puVar12) {
        *puVar12 = puVar12[-4];
        puVar12[1] = puVar12[-3];
        puVar12[2] = puVar12[-2];
        puVar12[3] = puVar12[-1];
        puVar12 = puVar12 + -4;
    }
    puVar12 = *(undefined4 **)(arg1 + 0x40);
    uVar7 = puVar12[1];
    uVar8 = puVar12[2];
    uVar9 = puVar12[3];
    *puVar14 = *puVar12;
    puVar14[1] = uVar7;
    puVar14[2] = uVar8;
    puVar14[3] = uVar9;
    uVar15 = *(uint64_t *)(arg1 + 0x18);
    do {
        if (uVar15 <= *(uint64_t *)(arg1 + 0x78)) {
            puVar1 = (uint32_t *)(*(uint64_t *)(arg1 + 0x18) + 0x24);
            *puVar1 = *puVar1 | 2;
            bVar10 = false;
            iVar16 = 0;
code_r0x000180024b0c:
            *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
            iVar11 = func_0x0001800878a0(arg1, iVar3 - iVar4 >> 4 & 0xffffffff, 0xffffffff);
            *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1;
            if (bVar10) {
                *(int64_t *)(iVar5 + 0x28) = iVar16 - (int64_t)(int64_t *)(iVar5 + 0x28);
            }
            if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
                **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
            }
            if (iVar11 != 0) {
                iVar11 = fcn.180085cd0(arg1, 0xffffffff);
                if (iVar11 == 6) {
                    uVar13 = fcn.1800860c0(arg1, 0xffffffff, 0);
                    fcn.1800047e0(&var_68h, uVar13);
                    fcn.180024200((int64_t)&var_68h);
                    fcn.1800858c0(arg1, 0xfffffffe);
                    uVar13 = fcn.18000b450(&var_68h);
                    fcn.1800868c0(arg1, uVar13);
                    fcn.180004dd0(&var_68h);
                }
                fcn.180087960(arg1);
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            fcn.180459870(var_48h ^ (uint64_t)auStack_88);
            return;
        }
        if ((*(uint8_t *)(uVar15 + 0x24) & 2) != 0) {
            piVar2 = (int64_t *)(iVar5 + 0x28);
            iVar16 = *piVar2 + (int64_t)piVar2;
            *piVar2 = -(int64_t)piVar2;
            bVar10 = true;
            goto code_r0x000180024b0c;
        }
        uVar15 = uVar15 - 0x28;
    } while( true );
}

// ============================================================
// Function: FUN_180024c30
// Address: 0x180024c30
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

void fcn.180024c30(int64_t arg1)
{
    uint64_t uVar1;
    int64_t var_8h;
    
    uVar1 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, 0x180782490, 0);
    fcn.180085bf0(arg1, uVar1 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar1 + -1);
    fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    return;
}

// ============================================================
// Function: FUN_180024c90
// Address: 0x180024c90
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined fcn.180024c90(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    char cVar1;
    uint64_t uVar2;
    int64_t var_8h;
    
    cVar1 = fcn.180024130(arg1, 0x180782490, 0);
    if (cVar1 == '\0') {
        return 0;
    }
    fcn.180086ba0(arg1, arg2, 0);
    uVar2 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, 0x180782490, 0);
    fcn.180085bf0(arg1, uVar2 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar2 + -1);
    fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    return 1;
}

// ============================================================
// Function: FUN_180024d20
// Address: 0x180024d20
// Size: 1395 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

void fcn.180024d20(int64_t arg1)
{
    uint64_t uVar1;
    uint32_t uVar2;
    int64_t *piVar3;
    code *pcVar4;
    bool bVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t **ppiVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    undefined auStack_1a8 [32];
    int64_t var_188h;
    int64_t **var_180h;
    int64_t var_178h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1a8;
    ppiVar12 = *(int64_t ***)(arg1 + 0x28);
    if (*(int64_t ***)(arg1 + 0x40) <= *(int64_t ***)(arg1 + 0x28)) {
        ppiVar12 = *(int64_t ***)0x180782430;
    }
    bVar5 = true;
    if (((ppiVar12 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar12 + 0xc) != 8)) &&
       (iVar8 = func_0x000180085d50(arg1, 1), iVar8 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x180621af0);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    iVar8 = func_0x000180085d50(arg1, 1);
    if (iVar8 == 0) {
        ppiVar12 = *(int64_t ***)(arg1 + 0x40);
        ppiVar10 = *(int64_t ***)(arg1 + 0x28);
        if (ppiVar12 <= *(int64_t ***)(arg1 + 0x28)) {
            ppiVar10 = *(int64_t ***)0x180782430;
        }
        if (ppiVar10 == *(int64_t ***)0x180782430) {
            ppiVar10 = (int64_t **)0x0;
        }
        piVar15 = *ppiVar10;
        ppiVar10 = *(int64_t ***)0x180782430;
    } else {
        iVar8 = func_0x000180085f50(arg1, 1, 0);
        if (iVar8 < 0) {
            func_0x000180088380(arg1, 1, 0x180621ad8);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar8 = func_0x000180092a10(arg1, iVar8, 0x180621b1c);
        ppiVar10 = *(int64_t ***)0x180782430;
        if (iVar8 == 0) {
            func_0x000180088380(arg1, 1, 0x180621b08);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        ppiVar12 = (int64_t **)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if ((ppiVar12 == *(int64_t ***)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
            fcn.1800858c0(arg1, 0xfffffffe);
            func_0x000180088380(arg1, 1, 0x180621b08);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        ppiVar9 = ppiVar12;
        if (ppiVar12 == *(int64_t ***)0x180782430) {
            ppiVar9 = (int64_t **)0x0;
        }
        piVar15 = *ppiVar9;
        *(int64_t ***)(arg1 + 0x40) = ppiVar12;
    }
    ppiVar9 = (int64_t **)0x0;
    var_188h = (int64_t)piVar15;
    if (piVar15 == (int64_t *)0x0) {
        func_0x000180088560(arg1, 0x180621b30);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    ppiVar11 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
    ppiVar16 = ppiVar11;
    if (ppiVar12 <= ppiVar11) {
        ppiVar16 = ppiVar10;
    }
    if ((ppiVar16 != ppiVar10) && (0 < *(int32_t *)((int64_t)ppiVar16 + 0xc))) {
        ppiVar16 = ppiVar11;
        if (ppiVar12 <= ppiVar11) {
            ppiVar16 = ppiVar10;
        }
        if ((ppiVar16 == ppiVar10) || (*(int32_t *)((int64_t)ppiVar16 + 0xc) != 1)) {
            func_0x000180088470(arg1, 2, 1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if (ppiVar12 <= ppiVar11) {
            ppiVar11 = ppiVar10;
        }
        uVar2 = *(uint32_t *)((int64_t)ppiVar11 + 0xc);
        ppiVar12 = (int64_t **)(uint64_t)uVar2;
        if ((uVar2 == 0) || ((uVar2 == 1 && (*(int32_t *)ppiVar11 == 0)))) {
            bVar5 = false;
        }
        if (!bVar5) {
            cVar7 = func_0x000180028f00(ppiVar12, &var_188h);
            iVar6 = *(int64_t *)0x18077af98;
            ppiVar12 = *(int64_t ***)0x18077af88;
            if (cVar7 != '\0') {
                uVar14 = (((((((((uint64_t)piVar15 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)var_188h >> 8 & 0xff) * 0x100000001b3 ^ (uint64_t)var_188h >> 0x10 & 0xff) *
                              0x100000001b3 ^ (uint64_t)var_188h >> 0x18 & 0xff) * 0x100000001b3 ^
                            (uint64_t)var_188h >> 0x20 & 0xff) * 0x100000001b3 ^ (uint64_t)var_188h >> 0x28 & 0xff) *
                           0x100000001b3 ^ (uint64_t)var_188h >> 0x30 & 0xff) * 0x100000001b3 ^
                         (uint64_t)var_188h >> 0x38) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
                ppiVar10 = *(int64_t ***)(*(int64_t *)0x18077af98 + 8 + uVar14 * 0x10);
                ppiVar11 = ppiVar9;
                if (ppiVar10 != *(int64_t ***)0x18077af88) {
                    piVar3 = ppiVar10[2];
                    ppiVar16 = ppiVar10;
                    while ((ppiVar11 = ppiVar16, piVar15 != piVar3 &&
                           (ppiVar11 = ppiVar9, ppiVar16 != *(int64_t ***)(*(int64_t *)0x18077af98 + uVar14 * 0x10)))) {
                        ppiVar16 = (int64_t **)ppiVar16[1];
                        piVar3 = ppiVar16[2];
                    }
                }
                if (ppiVar11 != (int64_t **)0x0) {
                    iVar13 = uVar14 * 0x10;
                    if (ppiVar10 == ppiVar11) {
                        if (*(int64_t ***)(iVar13 + *(int64_t *)0x18077af98) == ppiVar11) {
                            *(int64_t ***)(iVar13 + *(int64_t *)0x18077af98) = *(int64_t ***)0x18077af88;
                            *(int64_t ***)(iVar6 + 8 + uVar14 * 0x10) = ppiVar12;
                        } else {
                            *(int64_t **)(*(int64_t *)0x18077af98 + 8 + uVar14 * 0x10) = ppiVar11[1];
                        }
                    } else if (*(int64_t ***)(iVar13 + *(int64_t *)0x18077af98) == ppiVar11) {
                        *(int64_t **)(iVar13 + *(int64_t *)0x18077af98) = *ppiVar11;
                    }
                    piVar15 = *ppiVar11;
                    *(int64_t *)0x18077af90 = *(int64_t *)0x18077af90 + -1;
                    *ppiVar11[1] = (int64_t)piVar15;
                    piVar15[1] = (int64_t)ppiVar11[1];
                    func_0x000180459c3c(ppiVar11, 0x18);
                }
            }
            goto code_r0x0001800251f5;
        }
    }
    cVar7 = func_0x000180028f00(ppiVar12, &var_188h);
    if (cVar7 == '\0') {
        uVar14 = (((((((((uint64_t)piVar15 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)var_188h >> 8 & 0xff
                       ) * 0x100000001b3 ^ (uint64_t)var_188h >> 0x10 & 0xff) * 0x100000001b3 ^
                     (uint64_t)var_188h >> 0x18 & 0xff) * 0x100000001b3 ^ (uint64_t)var_188h >> 0x20 & 0xff) *
                    0x100000001b3 ^ (uint64_t)var_188h >> 0x28 & 0xff) * 0x100000001b3 ^
                  (uint64_t)var_188h >> 0x30 & 0xff) * 0x100000001b3 ^ (uint64_t)var_188h >> 0x38) * 0x100000001b3;
        ppiVar12 = *(int64_t ***)(*(int64_t *)0x18077af98 + 8 + (uVar14 & *(uint64_t *)0x18077afb0) * 0x10);
        ppiVar10 = *(int64_t ***)0x18077af88;
        if (ppiVar12 == *(int64_t ***)0x18077af88) {
code_r0x000180025097:
            if (*(int64_t *)0x18077af90 == 0xaaaaaaaaaaaaaaa) {
                fcn.1804546d4(0x180620428);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            var_188h = 0x18077af88;
            var_180h = ppiVar9;
            ppiVar12 = (int64_t **)fcn.180459890(0x18);
            ppiVar12[2] = piVar15;
            uVar1 = *(int64_t *)0x18077af90 + 1;
            if ((int64_t)uVar1 < 0) {
                fVar17 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
                fVar17 = fVar17 + fVar17;
            } else {
                fVar17 = (float)uVar1;
            }
            if ((int64_t)*(uint64_t *)0x18077afb8 < 0) {
                fVar18 = (float)(*(uint64_t *)0x18077afb8 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x18077afb8 & 1));
                fVar18 = fVar18 + fVar18;
            } else {
                fVar18 = (float)*(uint64_t *)0x18077afb8;
            }
            var_180h = ppiVar12;
            if (*(float *)0x18077af80 < fVar17 / fVar18) {
                func_0x0001800296c0();
                ppiVar9 = *(int64_t ***)(*(int64_t *)0x18077af98 + 8 + (uVar14 & *(uint64_t *)0x18077afb0) * 0x10);
                ppiVar10 = *(int64_t ***)0x18077af88;
                if (ppiVar9 != *(int64_t ***)0x18077af88) {
                    piVar15 = ppiVar9[2];
                    ppiVar10 = ppiVar9;
                    while (ppiVar12[2] != piVar15) {
                        if (ppiVar10 ==
                            *(int64_t ***)(*(int64_t *)0x18077af98 + (uVar14 & *(uint64_t *)0x18077afb0) * 0x10))
                        goto code_r0x000180025199;
                        ppiVar10 = (int64_t **)ppiVar10[1];
                        piVar15 = ppiVar10[2];
                    }
                    ppiVar10 = (int64_t **)*ppiVar10;
                }
            }
code_r0x000180025199:
            piVar15 = ppiVar10[1];
            *(int64_t *)0x18077af90 = *(int64_t *)0x18077af90 + 1;
            *ppiVar12 = (int64_t *)ppiVar10;
            ppiVar12[1] = piVar15;
            *piVar15 = (int64_t)ppiVar12;
            ppiVar10[1] = (int64_t *)ppiVar12;
            iVar6 = *(int64_t *)0x18077af98;
            uVar14 = uVar14 & *(uint64_t *)0x18077afb0;
            ppiVar9 = *(int64_t ***)(*(int64_t *)0x18077af98 + uVar14 * 0x10);
            if (ppiVar9 == *(int64_t ***)0x18077af88) {
                *(int64_t ***)(*(int64_t *)0x18077af98 + uVar14 * 0x10) = ppiVar12;
            } else {
                if (ppiVar9 == ppiVar10) {
                    *(int64_t ***)(*(int64_t *)0x18077af98 + uVar14 * 0x10) = ppiVar12;
                    goto code_r0x0001800251f5;
                }
                if (*(int64_t **)(*(int64_t *)0x18077af98 + 8 + uVar14 * 0x10) != piVar15) goto code_r0x0001800251f5;
            }
            *(int64_t ***)(iVar6 + 8 + uVar14 * 0x10) = ppiVar12;
        } else {
            piVar3 = ppiVar12[2];
            ppiVar10 = ppiVar12;
            while (piVar15 != piVar3) {
                if (ppiVar10 == *(int64_t ***)(*(int64_t *)0x18077af98 + (uVar14 & *(uint64_t *)0x18077afb0) * 0x10))
                goto code_r0x000180025097;
                ppiVar10 = (int64_t **)ppiVar10[1];
                piVar3 = ppiVar10[2];
            }
        }
    }
code_r0x0001800251f5:
    fcn.180459870(var_38h ^ (uint64_t)auStack_1a8);
    return;
}

// ============================================================
// Function: FUN_1800252a0
// Address: 0x1800252a0
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800252a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (piVar5 == *(int64_t **)0x180782430) {
        piVar5 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar5 + 3) != '\0') {
        fcn.180085bf0(arg1, 1);
        return 1;
    }
    piVar7 = piVar7 + 2;
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar5 + 0xc) == 6)) {
        if (piVar1 <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = fcn.1800a8360(arg1);
            if ((iVar4 != 0) &&
               (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))) {
                (**(code **)0x180782658)(arg1, 1);
            }
        }
    }
    fcn.1800869f0(0x1800248f0);
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar2 = *piVar7;
    fcn.180085bf0(arg1, 1);
    fcn.180086ba0(arg1, iVar2, 0);
    fcn.180024c30(arg1);
    return 1;
}

// ============================================================
// Function: FUN_18002530d
// Address: 0x18002530d
// Size: 242 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800252a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (piVar5 == *(int64_t **)0x180782430) {
        piVar5 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar5 + 3) != '\0') {
        fcn.180085bf0(arg1, 1);
        return 1;
    }
    piVar7 = piVar7 + 2;
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar5 + 0xc) == 6)) {
        if (piVar1 <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = fcn.1800a8360(arg1);
            if ((iVar4 != 0) &&
               (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))) {
                (**(code **)0x180782658)(arg1, 1);
            }
        }
    }
    fcn.1800869f0(0x1800248f0);
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar2 = *piVar7;
    fcn.180085bf0(arg1, 1);
    fcn.180086ba0(arg1, iVar2, 0);
    fcn.180024c30(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800253ff
// Address: 0x1800253ff
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800252a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (piVar5 == *(int64_t **)0x180782430) {
        piVar5 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar5 + 3) != '\0') {
        fcn.180085bf0(arg1, 1);
        return 1;
    }
    piVar7 = piVar7 + 2;
    piVar5 = piVar7;
    if (piVar1 <= piVar7) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar5 + 0xc) == 6)) {
        if (piVar1 <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = fcn.1800a8360(arg1);
            if ((iVar4 != 0) &&
               (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))) {
                (**(code **)0x180782658)(arg1, 1);
            }
        }
    }
    fcn.1800869f0(0x1800248f0);
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = (int64_t *)0x0;
    }
    iVar2 = *piVar7;
    fcn.180085bf0(arg1, 1);
    fcn.180086ba0(arg1, iVar2, 0);
    fcn.180024c30(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180025410
// Address: 0x180025410
// Size: 1117 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

void fcn.180025410(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    undefined *puVar11;
    uint64_t uVar12;
    int64_t iVar13;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar11 = auStack_98;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 == *(undefined4 **)0x180782430) || (puVar8[3] != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    func_0x000180086fd0(arg1, 0, 0);
    func_0x000180086fd0(arg1, 0, 0);
    func_0x000180087250(arg1, 1);
    func_0x000180087370(arg1, 0xfffffffe, 0x1805aae90);
    *(undefined *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 4) = 1;
    func_0x000180087650(arg1, 0xfffffffe);
    fcn.180085bf0(arg1, 1);
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(char *)(*(int64_t *)(iVar10 + -0x20) + 4) != '\0') {
        func_0x000180092f10(arg1);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar7 = fcn.18009a8e0(arg1, 0x180621b20, 0xb);
    puVar8 = (undefined4 *)func_0x0001800a10a0(arg1, *(undefined8 *)(iVar10 + -0x20), uVar7);
    uVar2 = *(undefined4 *)(iVar10 + -0xc);
    uVar3 = *(undefined4 *)(iVar10 + -8);
    uVar4 = *(undefined4 *)(iVar10 + -4);
    *puVar8 = *(undefined4 *)(iVar10 + -0x10);
    puVar8[1] = uVar2;
    puVar8[2] = uVar3;
    puVar8[3] = uVar4;
    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
        iVar10 = *(int64_t *)(iVar10 + -0x20);
        if (((*(uint8_t *)(iVar10 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar13 = *(int64_t *)(arg1 + 0x20);
            if (*(char *)(iVar13 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xfb;
                *(undefined8 *)(iVar10 + 0x18) = *(undefined8 *)(iVar13 + 0x18);
                *(int64_t *)(iVar13 + 0x18) = iVar10;
            }
        }
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180012f50();
    _var_68h = ZEXT816(0);
    var_58h = 0;
    var_50h = 0;
    puVar8 = (undefined4 *)fcn.180459890(0x20);
    var_68h = (int64_t)puVar8;
    var_58h = 0x17;
    var_50h = 0x1f;
    *puVar8 = 0x75746572;
    puVar8[1] = 0x5f206e72;
    puVar8[2] = 0x4152575f;
    puVar8[3] = 0x44455050;
    *(undefined8 *)((int64_t)puVar8 + 0xf) = 0x292e2e2e285f5f44;
    *(undefined *)((int64_t)puVar8 + 0x17) = 0;
    var_78h._0_4_ = 0xffffffff;
    cVar5 = func_0x0001800131b0(0x75746572, arg1, &var_68h, 0x1805aae98);
    if (0xf < (uint64_t)var_50h) {
        puVar11 = auStack_98;
        iVar10 = var_68h;
        if ((0xfff < var_50h + 1U) &&
           (iVar10 = *(int64_t *)(var_68h + -8), puVar11 = auStack_98, 0x1f < (var_68h - iVar10) - 8U)) {
            iVar10 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar11 = auStack_90;
        }
        *(undefined8 *)(puVar11 + -8) = 0x1800255f6;
        func_0x000180459c3c(iVar10);
    }
    if (cVar5 == '\0') {
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar8 = *(undefined4 **)(arg1 + 0x40);
        puVar9 = puVar8;
        while (puVar8 + -8 < puVar9) {
            *puVar9 = puVar9[-4];
            puVar9[1] = puVar9[-3];
            puVar9[2] = puVar9[-2];
            puVar9[3] = puVar9[-1];
            puVar9 = puVar9 + -4;
        }
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        puVar8[-8] = *puVar9;
        puVar8[-7] = uVar2;
        puVar8[-6] = uVar3;
        puVar8[-5] = uVar4;
        *(undefined8 *)(puVar11 + -8) = 0x180025684;
        func_0x000180087760(arg1);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            *(undefined8 *)(puVar11 + -8) = 0x1800256ce;
            iVar6 = fcn.180085510(*(int64_t *)(puVar11 + 0x38));
            if (iVar6 == 0) goto code_r0x000180025841;
        }
        puVar8 = *(undefined4 **)(arg1 + 0x40);
        *puVar8 = puVar8[-4];
        puVar8[1] = puVar8[-3];
        puVar8[2] = puVar8[-2];
        puVar8[3] = puVar8[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined8 *)(puVar11 + -8) = 0x1800256fb;
        fcn.180085bf0(arg1, 1);
        uVar12 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        *(undefined8 *)(puVar11 + -8) = 0x180025719;
        fcn.180023f30(arg1, 0x180782460, 0);
        *(undefined8 *)(puVar11 + -8) = 0x180025723;
        fcn.180085bf0(arg1, uVar12 & 0xffffffff);
        *(undefined8 *)(puVar11 + -8) = 0x18002572e;
        fcn.180085bf0(arg1, (int32_t)uVar12 + -1);
        *(undefined8 *)(puVar11 + -8) = 0x18002573b;
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
        *(undefined8 *)(puVar11 + 0x20) = 0;
        *(undefined8 *)(puVar11 + -8) = 0x18002575a;
        fcn.1800869f0(*(int64_t *)(puVar11 + 0x20));
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            *(undefined8 *)(puVar11 + -8) = 0x18002579c;
            iVar6 = fcn.180085510(*(int64_t *)(puVar11 + 0x38));
            if (iVar6 == 0) goto code_r0x000180025841;
        }
        puVar8 = *(undefined4 **)(arg1 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (puVar8 <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            *(undefined8 *)(puVar11 + -8) = 0x1800257e9;
            iVar6 = fcn.180085510(*(int64_t *)(puVar11 + 0x38));
            if (iVar6 == 0) {
code_r0x000180025841:
                *(undefined8 *)(puVar11 + -8) = 0x180025850;
                fcn.180099450(arg1, 0x18063d8d0);
                *(undefined8 *)(puVar11 + -8) = 0x180025858;
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
        }
        puVar8 = *(undefined4 **)(arg1 + 0x40);
        *puVar8 = 1;
        puVar8[3] = 1;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar13 = *(int64_t *)(arg1 + 0x40) + -0x30;
        *(int64_t *)(puVar11 + 0x30) = iVar13;
        *(undefined4 *)(puVar11 + 0x38) = 0;
        iVar10 = *(int64_t *)(arg1 + 0x38);
        *(undefined8 *)(puVar11 + 0x20) = 0;
        *(undefined8 *)(puVar11 + -8) = 0x180025831;
        func_0x000180094080(arg1, 0x180087890, puVar11 + 0x30, iVar13 - iVar10);
    }
    *(undefined8 *)(puVar11 + -8) = 0x18002560f;
    fcn.180459870(*(uint64_t *)(puVar11 + 0x50) ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_180025870
// Address: 0x180025870
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.180025870(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int32_t iVar19;
    unkbyte7 Var20;
    uint64_t uVar21;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_33h;
    
    piVar18 = *(int64_t **)(arg1 + 0x28);
    piVar3 = *(int64_t **)(arg1 + 0x40);
    piVar13 = piVar18;
    if (piVar3 <= piVar18) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar13 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar7 = (code *)swi(3);
        uVar15 = (*pcVar7)();
        return uVar15;
    }
    if (piVar3 <= piVar18) {
        piVar18 = *(int64_t **)0x180782430;
    }
    if (piVar18 == *(int64_t **)0x180782430) {
        piVar18 = (int64_t *)0x0;
    }
    iVar4 = *piVar18;
    iVar8 = (int32_t)arg1;
    if (*(char *)(iVar4 + 3) == '\0') {
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)piVar3 >> 8), 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x000180094210(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10), 
                                     *(undefined8 *)(iVar4 + 0x20));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x28 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x28 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
code_r0x000180025e33:
        piVar18 = *(int64_t **)(arg1 + 0x40);
        *piVar18 = iVar14;
        *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar19 * 2;
            if (iVar19 < 1) {
                iVar8 = iVar19 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    if (*(code **)(iVar4 + 0x20) == fcn.1800249a0) {
        fcn.1800869f0(0x1800248f0);
        piVar18 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if (piVar18 == *(int64_t **)0x180782430) {
            piVar18 = (int64_t *)0x0;
        }
        iVar14 = *piVar18;
        fcn.180086ba0(arg1, iVar4, 0);
        fcn.180024c90(arg1, iVar14, unaff_R14);
        return 1;
    }
    uVar21 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30);
    uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28);
    Var20 = (unkbyte7)(uVar21 >> 8);
    if (*(code **)(iVar4 + 0x20) != (code *)0x1800517c0) {
        if (uVar5 <= uVar21) {
            (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
        *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
        *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
        *(undefined8 *)(iVar14 + 0x20) = *(undefined8 *)(iVar4 + 0x20);
        *(int64_t *)(iVar14 + 0x28) =
             ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
        piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
        if ((int64_t *)(iVar4 + 0x30) != piVar18) {
            *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
        }
        goto code_r0x000180025e33;
    }
    if (uVar5 <= uVar21) {
        (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
    iVar19 = 0;
    if (*(char *)(iVar4 + 4) != '\0') {
        do {
            iVar17 = (int64_t)iVar19;
            iVar19 = iVar19 + 1;
            puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
            uVar9 = puVar1[1];
            uVar10 = puVar1[2];
            uVar11 = puVar1[3];
            puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar9;
            puVar2[2] = uVar10;
            puVar2[3] = uVar11;
        } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
    }
    *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
    *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
    *(undefined8 *)(iVar14 + 0x20) = 0x1800517c0;
    *(int64_t *)(iVar14 + 0x28) = ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
    piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
    if ((int64_t *)(iVar4 + 0x30) != piVar18) {
        *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
    }
    piVar18 = *(int64_t **)(arg1 + 0x40);
    *piVar18 = iVar14;
    *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar16 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
        iVar19 = iVar16 * 2;
        if (iVar16 < 1) {
            iVar19 = iVar16 + 1;
        }
        func_0x000180093240(arg1, iVar19, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782470, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782470, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    fcn.180085610(arg1, 3);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 == '\0') goto code_r0x000180025cf2;
    iVar17 = *(int64_t *)(arg1 + 0x40);
    iVar19 = *(int32_t *)(iVar17 + -4);
    if (iVar19 == 6) {
        iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 0x14);
code_r0x000180025bcb:
        if (0 < iVar19) {
            func_0x000180086ed0(arg1, 0xffffffff, iVar19);
            iVar17 = *(int64_t *)(arg1 + 0x40);
            piVar18 = (int64_t *)(iVar17 - 0x10);
            if ((piVar18 == *(int64_t **)0x180782430) || (*(int32_t *)(iVar17 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
            } else {
                if (piVar18 == *(int64_t **)0x180782430) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar6 = *piVar18;
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
                fcn.180085610(arg1, 2);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar18 = *(int64_t **)(arg1 + 0x40);
                *piVar18 = iVar6;
                *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
                    iVar8 = iVar19 * 2;
                    if (iVar19 < 1) {
                        iVar8 = iVar19 + 1;
                    }
                    func_0x000180093240(arg1, iVar8, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                fcn.180086ba0(arg1, iVar14, 0);
                uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
                fcn.180023f30(arg1, 0x180782470, 2);
                fcn.180085bf0(arg1, uVar21 & 0xffffffff);
                fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
                fcn.180087440(arg1, 0xfffffffd);
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            }
            goto code_r0x000180025cf2;
        }
    } else {
        if (iVar19 == 7) {
            iVar19 = func_0x0001800a1110(*(undefined8 *)(iVar17 + -0x10));
            goto code_r0x000180025bcb;
        }
        if ((iVar19 == 9) || (iVar19 == 0xb)) {
            iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 4);
            goto code_r0x000180025bcb;
        }
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
code_r0x000180025cf2:
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782488, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    return 1;
}

// ============================================================
// Function: FUN_1800258b2
// Address: 0x1800258b2
// Size: 285 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.180025870(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int32_t iVar19;
    unkbyte7 Var20;
    uint64_t uVar21;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_33h;
    
    piVar18 = *(int64_t **)(arg1 + 0x28);
    piVar3 = *(int64_t **)(arg1 + 0x40);
    piVar13 = piVar18;
    if (piVar3 <= piVar18) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar13 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar7 = (code *)swi(3);
        uVar15 = (*pcVar7)();
        return uVar15;
    }
    if (piVar3 <= piVar18) {
        piVar18 = *(int64_t **)0x180782430;
    }
    if (piVar18 == *(int64_t **)0x180782430) {
        piVar18 = (int64_t *)0x0;
    }
    iVar4 = *piVar18;
    iVar8 = (int32_t)arg1;
    if (*(char *)(iVar4 + 3) == '\0') {
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)piVar3 >> 8), 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x000180094210(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10), 
                                     *(undefined8 *)(iVar4 + 0x20));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x28 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x28 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
code_r0x000180025e33:
        piVar18 = *(int64_t **)(arg1 + 0x40);
        *piVar18 = iVar14;
        *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar19 * 2;
            if (iVar19 < 1) {
                iVar8 = iVar19 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    if (*(code **)(iVar4 + 0x20) == fcn.1800249a0) {
        fcn.1800869f0(0x1800248f0);
        piVar18 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if (piVar18 == *(int64_t **)0x180782430) {
            piVar18 = (int64_t *)0x0;
        }
        iVar14 = *piVar18;
        fcn.180086ba0(arg1, iVar4, 0);
        fcn.180024c90(arg1, iVar14, unaff_R14);
        return 1;
    }
    uVar21 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30);
    uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28);
    Var20 = (unkbyte7)(uVar21 >> 8);
    if (*(code **)(iVar4 + 0x20) != (code *)0x1800517c0) {
        if (uVar5 <= uVar21) {
            (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
        *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
        *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
        *(undefined8 *)(iVar14 + 0x20) = *(undefined8 *)(iVar4 + 0x20);
        *(int64_t *)(iVar14 + 0x28) =
             ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
        piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
        if ((int64_t *)(iVar4 + 0x30) != piVar18) {
            *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
        }
        goto code_r0x000180025e33;
    }
    if (uVar5 <= uVar21) {
        (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
    iVar19 = 0;
    if (*(char *)(iVar4 + 4) != '\0') {
        do {
            iVar17 = (int64_t)iVar19;
            iVar19 = iVar19 + 1;
            puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
            uVar9 = puVar1[1];
            uVar10 = puVar1[2];
            uVar11 = puVar1[3];
            puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar9;
            puVar2[2] = uVar10;
            puVar2[3] = uVar11;
        } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
    }
    *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
    *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
    *(undefined8 *)(iVar14 + 0x20) = 0x1800517c0;
    *(int64_t *)(iVar14 + 0x28) = ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
    piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
    if ((int64_t *)(iVar4 + 0x30) != piVar18) {
        *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
    }
    piVar18 = *(int64_t **)(arg1 + 0x40);
    *piVar18 = iVar14;
    *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar16 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
        iVar19 = iVar16 * 2;
        if (iVar16 < 1) {
            iVar19 = iVar16 + 1;
        }
        func_0x000180093240(arg1, iVar19, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782470, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782470, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    fcn.180085610(arg1, 3);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 == '\0') goto code_r0x000180025cf2;
    iVar17 = *(int64_t *)(arg1 + 0x40);
    iVar19 = *(int32_t *)(iVar17 + -4);
    if (iVar19 == 6) {
        iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 0x14);
code_r0x000180025bcb:
        if (0 < iVar19) {
            func_0x000180086ed0(arg1, 0xffffffff, iVar19);
            iVar17 = *(int64_t *)(arg1 + 0x40);
            piVar18 = (int64_t *)(iVar17 - 0x10);
            if ((piVar18 == *(int64_t **)0x180782430) || (*(int32_t *)(iVar17 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
            } else {
                if (piVar18 == *(int64_t **)0x180782430) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar6 = *piVar18;
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
                fcn.180085610(arg1, 2);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar18 = *(int64_t **)(arg1 + 0x40);
                *piVar18 = iVar6;
                *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
                    iVar8 = iVar19 * 2;
                    if (iVar19 < 1) {
                        iVar8 = iVar19 + 1;
                    }
                    func_0x000180093240(arg1, iVar8, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                fcn.180086ba0(arg1, iVar14, 0);
                uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
                fcn.180023f30(arg1, 0x180782470, 2);
                fcn.180085bf0(arg1, uVar21 & 0xffffffff);
                fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
                fcn.180087440(arg1, 0xfffffffd);
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            }
            goto code_r0x000180025cf2;
        }
    } else {
        if (iVar19 == 7) {
            iVar19 = func_0x0001800a1110(*(undefined8 *)(iVar17 + -0x10));
            goto code_r0x000180025bcb;
        }
        if ((iVar19 == 9) || (iVar19 == 0xb)) {
            iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 4);
            goto code_r0x000180025bcb;
        }
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
code_r0x000180025cf2:
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782488, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    return 1;
}

// ============================================================
// Function: FUN_1800259cf
// Address: 0x1800259cf
// Size: 1194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.180025870(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int32_t iVar19;
    unkbyte7 Var20;
    uint64_t uVar21;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_33h;
    
    piVar18 = *(int64_t **)(arg1 + 0x28);
    piVar3 = *(int64_t **)(arg1 + 0x40);
    piVar13 = piVar18;
    if (piVar3 <= piVar18) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar13 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar7 = (code *)swi(3);
        uVar15 = (*pcVar7)();
        return uVar15;
    }
    if (piVar3 <= piVar18) {
        piVar18 = *(int64_t **)0x180782430;
    }
    if (piVar18 == *(int64_t **)0x180782430) {
        piVar18 = (int64_t *)0x0;
    }
    iVar4 = *piVar18;
    iVar8 = (int32_t)arg1;
    if (*(char *)(iVar4 + 3) == '\0') {
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)piVar3 >> 8), 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x000180094210(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10), 
                                     *(undefined8 *)(iVar4 + 0x20));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x28 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x28 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
code_r0x000180025e33:
        piVar18 = *(int64_t **)(arg1 + 0x40);
        *piVar18 = iVar14;
        *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar19 * 2;
            if (iVar19 < 1) {
                iVar8 = iVar19 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    if (*(code **)(iVar4 + 0x20) == fcn.1800249a0) {
        fcn.1800869f0(0x1800248f0);
        piVar18 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if (piVar18 == *(int64_t **)0x180782430) {
            piVar18 = (int64_t *)0x0;
        }
        iVar14 = *piVar18;
        fcn.180086ba0(arg1, iVar4, 0);
        fcn.180024c90(arg1, iVar14, unaff_R14);
        return 1;
    }
    uVar21 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30);
    uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28);
    Var20 = (unkbyte7)(uVar21 >> 8);
    if (*(code **)(iVar4 + 0x20) != (code *)0x1800517c0) {
        if (uVar5 <= uVar21) {
            (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
        *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
        *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
        *(undefined8 *)(iVar14 + 0x20) = *(undefined8 *)(iVar4 + 0x20);
        *(int64_t *)(iVar14 + 0x28) =
             ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
        piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
        if ((int64_t *)(iVar4 + 0x30) != piVar18) {
            *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
        }
        goto code_r0x000180025e33;
    }
    if (uVar5 <= uVar21) {
        (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
    iVar19 = 0;
    if (*(char *)(iVar4 + 4) != '\0') {
        do {
            iVar17 = (int64_t)iVar19;
            iVar19 = iVar19 + 1;
            puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
            uVar9 = puVar1[1];
            uVar10 = puVar1[2];
            uVar11 = puVar1[3];
            puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar9;
            puVar2[2] = uVar10;
            puVar2[3] = uVar11;
        } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
    }
    *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
    *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
    *(undefined8 *)(iVar14 + 0x20) = 0x1800517c0;
    *(int64_t *)(iVar14 + 0x28) = ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
    piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
    if ((int64_t *)(iVar4 + 0x30) != piVar18) {
        *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
    }
    piVar18 = *(int64_t **)(arg1 + 0x40);
    *piVar18 = iVar14;
    *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar16 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
        iVar19 = iVar16 * 2;
        if (iVar16 < 1) {
            iVar19 = iVar16 + 1;
        }
        func_0x000180093240(arg1, iVar19, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782470, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782470, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    fcn.180085610(arg1, 3);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 == '\0') goto code_r0x000180025cf2;
    iVar17 = *(int64_t *)(arg1 + 0x40);
    iVar19 = *(int32_t *)(iVar17 + -4);
    if (iVar19 == 6) {
        iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 0x14);
code_r0x000180025bcb:
        if (0 < iVar19) {
            func_0x000180086ed0(arg1, 0xffffffff, iVar19);
            iVar17 = *(int64_t *)(arg1 + 0x40);
            piVar18 = (int64_t *)(iVar17 - 0x10);
            if ((piVar18 == *(int64_t **)0x180782430) || (*(int32_t *)(iVar17 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
            } else {
                if (piVar18 == *(int64_t **)0x180782430) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar6 = *piVar18;
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
                fcn.180085610(arg1, 2);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar18 = *(int64_t **)(arg1 + 0x40);
                *piVar18 = iVar6;
                *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
                    iVar8 = iVar19 * 2;
                    if (iVar19 < 1) {
                        iVar8 = iVar19 + 1;
                    }
                    func_0x000180093240(arg1, iVar8, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                fcn.180086ba0(arg1, iVar14, 0);
                uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
                fcn.180023f30(arg1, 0x180782470, 2);
                fcn.180085bf0(arg1, uVar21 & 0xffffffff);
                fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
                fcn.180087440(arg1, 0xfffffffd);
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            }
            goto code_r0x000180025cf2;
        }
    } else {
        if (iVar19 == 7) {
            iVar19 = func_0x0001800a1110(*(undefined8 *)(iVar17 + -0x10));
            goto code_r0x000180025bcb;
        }
        if ((iVar19 == 9) || (iVar19 == 0xb)) {
            iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 4);
            goto code_r0x000180025bcb;
        }
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
code_r0x000180025cf2:
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782488, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    return 1;
}

// ============================================================
// Function: FUN_180025e79
// Address: 0x180025e79
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.180025870(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int32_t iVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int32_t iVar19;
    unkbyte7 Var20;
    uint64_t uVar21;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_33h;
    
    piVar18 = *(int64_t **)(arg1 + 0x28);
    piVar3 = *(int64_t **)(arg1 + 0x40);
    piVar13 = piVar18;
    if (piVar3 <= piVar18) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar13 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar7 = (code *)swi(3);
        uVar15 = (*pcVar7)();
        return uVar15;
    }
    if (piVar3 <= piVar18) {
        piVar18 = *(int64_t **)0x180782430;
    }
    if (piVar18 == *(int64_t **)0x180782430) {
        piVar18 = (int64_t *)0x0;
    }
    iVar4 = *piVar18;
    iVar8 = (int32_t)arg1;
    if (*(char *)(iVar4 + 3) == '\0') {
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)piVar3 >> 8), 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x000180094210(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10), 
                                     *(undefined8 *)(iVar4 + 0x20));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x28 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x28 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
code_r0x000180025e33:
        piVar18 = *(int64_t **)(arg1 + 0x40);
        *piVar18 = iVar14;
        *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar19 * 2;
            if (iVar19 < 1) {
                iVar8 = iVar19 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    if (*(code **)(iVar4 + 0x20) == fcn.1800249a0) {
        fcn.1800869f0(0x1800248f0);
        piVar18 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if (piVar18 == *(int64_t **)0x180782430) {
            piVar18 = (int64_t *)0x0;
        }
        iVar14 = *piVar18;
        fcn.180086ba0(arg1, iVar4, 0);
        fcn.180024c90(arg1, iVar14, unaff_R14);
        return 1;
    }
    uVar21 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30);
    uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28);
    Var20 = (unkbyte7)(uVar21 >> 8);
    if (*(code **)(iVar4 + 0x20) != (code *)0x1800517c0) {
        if (uVar5 <= uVar21) {
            (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
        iVar19 = 0;
        if (*(char *)(iVar4 + 4) != '\0') {
            do {
                iVar17 = (int64_t)iVar19;
                iVar19 = iVar19 + 1;
                puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
        }
        *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
        *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
        *(undefined8 *)(iVar14 + 0x20) = *(undefined8 *)(iVar4 + 0x20);
        *(int64_t *)(iVar14 + 0x28) =
             ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
        piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
        if ((int64_t *)(iVar4 + 0x30) != piVar18) {
            *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
        }
        goto code_r0x000180025e33;
    }
    if (uVar5 <= uVar21) {
        (**(code **)0x180782658)(arg1, CONCAT71(Var20, 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar14 = func_0x0001800942b0(arg1, *(undefined *)(iVar4 + 4), *(undefined8 *)(iVar4 + 0x10));
    iVar19 = 0;
    if (*(char *)(iVar4 + 4) != '\0') {
        do {
            iVar17 = (int64_t)iVar19;
            iVar19 = iVar19 + 1;
            puVar1 = (undefined4 *)(iVar4 + 0x38 + iVar17 * 0x10);
            uVar9 = puVar1[1];
            uVar10 = puVar1[2];
            uVar11 = puVar1[3];
            puVar2 = (undefined4 *)(iVar14 + 0x38 + iVar17 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar9;
            puVar2[2] = uVar10;
            puVar2[3] = uVar11;
        } while (iVar19 < (int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4));
    }
    *(undefined *)(iVar14 + 5) = *(undefined *)(iVar4 + 5);
    *(undefined *)(iVar14 + 6) = *(undefined *)(iVar4 + 6);
    *(undefined8 *)(iVar14 + 0x20) = 0x1800517c0;
    *(int64_t *)(iVar14 + 0x28) = ((iVar4 + 0x28) - (int64_t)(int64_t *)(iVar14 + 0x28)) + *(int64_t *)(iVar4 + 0x28);
    piVar18 = *(int64_t **)(int64_t *)(iVar4 + 0x30);
    if ((int64_t *)(iVar4 + 0x30) != piVar18) {
        *(int64_t *)(iVar14 + 0x30) = (iVar14 - iVar4) + (int64_t)piVar18;
    }
    piVar18 = *(int64_t **)(arg1 + 0x40);
    *piVar18 = iVar14;
    *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar16 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
        iVar19 = iVar16 * 2;
        if (iVar16 < 1) {
            iVar19 = iVar16 + 1;
        }
        func_0x000180093240(arg1, iVar19, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782470, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782470, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    fcn.180085610(arg1, 3);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 == '\0') goto code_r0x000180025cf2;
    iVar17 = *(int64_t *)(arg1 + 0x40);
    iVar19 = *(int32_t *)(iVar17 + -4);
    if (iVar19 == 6) {
        iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 0x14);
code_r0x000180025bcb:
        if (0 < iVar19) {
            func_0x000180086ed0(arg1, 0xffffffff, iVar19);
            iVar17 = *(int64_t *)(arg1 + 0x40);
            piVar18 = (int64_t *)(iVar17 - 0x10);
            if ((piVar18 == *(int64_t **)0x180782430) || (*(int32_t *)(iVar17 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
            } else {
                if (piVar18 == *(int64_t **)0x180782430) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar6 = *piVar18;
                *(int64_t *)(arg1 + 0x40) = iVar17 + -0x20;
                fcn.180085610(arg1, 2);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar18 = *(int64_t **)(arg1 + 0x40);
                *piVar18 = iVar6;
                *(undefined4 *)((int64_t)piVar18 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar19 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
                    iVar8 = iVar19 * 2;
                    if (iVar19 < 1) {
                        iVar8 = iVar19 + 1;
                    }
                    func_0x000180093240(arg1, iVar8, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                fcn.180086ba0(arg1, iVar14, 0);
                uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
                fcn.180023f30(arg1, 0x180782470, 2);
                fcn.180085bf0(arg1, uVar21 & 0xffffffff);
                fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
                fcn.180087440(arg1, 0xfffffffd);
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            }
            goto code_r0x000180025cf2;
        }
    } else {
        if (iVar19 == 7) {
            iVar19 = func_0x0001800a1110(*(undefined8 *)(iVar17 + -0x10));
            goto code_r0x000180025bcb;
        }
        if ((iVar19 == 9) || (iVar19 == 0xb)) {
            iVar19 = *(int32_t *)(*(int64_t *)(iVar17 + -0x10) + 4);
            goto code_r0x000180025bcb;
        }
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
code_r0x000180025cf2:
    fcn.180085610(arg1, 2);
    fcn.180086ba0(arg1, iVar4, 0);
    cVar12 = fcn.180024130(arg1, 0x180782488, 2);
    if (cVar12 != '\0') {
        fcn.180086ba0(arg1, iVar14, 0);
        uVar21 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        fcn.180023f30(arg1, 0x180782488, 2);
        fcn.180085bf0(arg1, uVar21 & 0xffffffff);
        fcn.180085bf0(arg1, (int32_t)uVar21 + -1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    }
    return 1;
}

// ============================================================
// Function: FUN_180025e90
// Address: 0x180025e90
// Size: 116 bytes
// ============================================================
undefined8 fcn.180025e90(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar2 + 0xc) == 8) && (*(char *)(*piVar2 + 3) == '\0')) {
        fcn.180086b20(arg1, 1);
        return 1;
    }
    fcn.180086b20(arg1, 0);
    return 1;
}

// ============================================================
// Function: FUN_180025f10
// Address: 0x180025f10
// Size: 116 bytes
// ============================================================
undefined8 fcn.180025f10(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar2 + 0xc) == 8) && (*(char *)(*piVar2 + 3) != '\0')) {
        fcn.180086b20(arg1, 1);
        return 1;
    }
    fcn.180086b20(arg1, 0);
    return 1;
}

// ============================================================
// Function: FUN_180025f90
// Address: 0x180025f90
// Size: 142 bytes
// ============================================================
undefined8 fcn.180025f90(int64_t arg1)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    bool bVar5;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 8)) {
        func_0x000180013530();
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (piVar4 == *(int64_t **)0x180782430) {
            piVar4 = (int64_t *)0x0;
        }
        cVar1 = *(char *)(*piVar4 + 3);
        if (cVar1 == '\0') {
            bVar5 = *(int64_t *)(*(int64_t *)(*piVar4 + 0x20) + 0x78) == 1;
        } else {
            bVar5 = cVar1 == '\x02';
        }
        fcn.180086b20(arg1, bVar5);
        return 1;
    }
    fcn.180088470(arg1, 1, 8);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180026020
// Address: 0x180026020
// Size: 118 bytes
// ============================================================
undefined8 fcn.180026020(int64_t arg1)
{
    code *pcVar1;
    undefined uVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t var_8h;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar5 + 0xc) == 8)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
            piVar3 = *(int64_t **)0x180782430;
        }
        if (piVar3 == *(int64_t **)0x180782430) {
            piVar3 = (int64_t *)0x0;
        }
        var_8h = *piVar3;
        uVar2 = fcn.1800289c0(*(int64_t **)0x180782430, &var_8h);
        fcn.180086b20(arg1, uVar2);
        return 1;
    }
    fcn.180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800260a0
// Address: 0x1800260a0
// Size: 940 bytes
// ============================================================
void fcn.1800260a0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    undefined4 uVar15;
    int64_t var_1h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar12 = auStack_98;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar11 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) != 6)) {
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar4 + 0xc) == 6) {
code_r0x00018002615b:
        uVar13 = (uint64_t)*(uint32_t *)(*piVar4 + 0x14);
        iVar9 = *piVar4 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = fcn.1800a8360(arg1);
        if (iVar3 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar4 = *(int64_t **)(arg1 + 0x28);
            if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
                piVar4 = *(int64_t **)0x180782430;
            }
            goto code_r0x00018002615b;
        }
        uVar13 = 0;
        iVar9 = 0;
    }
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar4 = piVar11;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) < 1)) {
        iVar14 = 0x1805aae98;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar3 = fcn.1800a8360(arg1);
            if (iVar3 == 0) goto code_r0x00018002641e;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        iVar14 = *piVar11 + 0x18;
        if (iVar14 == 0) {
code_r0x00018002641e:
            fcn.180088470(arg1, 2, 6);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    func_0x000180012f50();
    _var_68h = ZEXT816(0);
    var_58h = 0;
    var_50h = 0;
    if (uVar13 < 0x10) {
        var_50h = 0xf;
        var_58h = uVar13;
        uVar15 = fcn.180498030(&var_68h, iVar9, uVar13);
        *(undefined *)((int64_t)&var_68h + uVar13) = 0;
code_r0x0001800262e3:
        var_78h._0_4_ = 0;
        uVar2 = func_0x0001800131b0(uVar15, arg1, &var_68h, iVar14);
        uVar13 = (uint64_t)uVar2;
        if ((uint64_t)var_50h < 0x10) goto code_r0x000180026343;
        puVar12 = auStack_98;
        iVar9 = var_68h;
        if ((0xfff < var_50h + 1U) &&
           (iVar9 = *(int64_t *)(var_68h + -8), puVar12 = auStack_98, 0x1f < (var_68h - iVar9) - 8U))
        goto code_r0x000180026331;
    } else {
        uVar5 = uVar13 | 0xf;
        if (uVar5 < 0x8000000000000000) {
            if (uVar5 < 0x16) {
                uVar5 = 0x16;
            }
            if (0xfff < uVar5 + 1) {
                uVar6 = uVar5 + 0x28;
                if (uVar6 <= uVar5 + 1) {
                    fcn.180004720();
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                goto code_r0x000180026270;
            }
            uVar6 = fcn.180459890();
code_r0x0001800262c2:
            var_68h = uVar6;
            var_58h = uVar13;
            var_50h = uVar5;
            uVar15 = fcn.180498030(uVar6, iVar9, uVar13);
            *(undefined *)(uVar6 + uVar13) = 0;
            goto code_r0x0001800262e3;
        }
        uVar6 = 0x8000000000000027;
        uVar5 = 0x7fffffffffffffff;
code_r0x000180026270:
        iVar7 = fcn.180459890(uVar6);
        if (iVar7 != 0) {
            uVar6 = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar6 - 8) = iVar7;
            goto code_r0x0001800262c2;
        }
code_r0x000180026331:
        uVar2 = (uint8_t)uVar13;
        iVar9 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar12 = auStack_90;
    }
    *(undefined8 *)(puVar12 + -8) = 0x180026343;
    func_0x000180459c3c(iVar9);
code_r0x000180026343:
    if (uVar2 == 0) {
        *(undefined8 *)(puVar12 + -8) = 0x18002636f;
        func_0x000180086510(arg1);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            *(undefined8 *)(puVar12 + -8) = 0x1800263b3;
            iVar3 = fcn.180085510(*(int64_t *)(puVar12 + 0x38));
            if (iVar3 == 0) {
                *(undefined8 *)(puVar12 + -8) = 0x180026415;
                fcn.180099450(arg1, 0x18063d8d0);
                *(undefined8 *)(puVar12 + -8) = 0x18002641d;
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
        }
        puVar8 = *(undefined4 **)(arg1 + 0x40);
        *puVar8 = puVar8[-8];
        puVar8[1] = puVar8[-7];
        puVar8[2] = puVar8[-6];
        puVar8[3] = puVar8[-5];
        iVar9 = *(int64_t *)(arg1 + 0x40);
        puVar10 = (undefined4 *)(iVar9 + 0x10);
        *(undefined4 **)(arg1 + 0x40) = puVar10;
        puVar8 = (undefined4 *)(iVar9 - 0x10);
        if (puVar8 < puVar10) {
            do {
                puVar8[-4] = *puVar8;
                puVar8[-3] = puVar8[1];
                puVar8[-2] = puVar8[2];
                puVar8[-1] = puVar8[3];
                puVar8 = puVar8 + 4;
                puVar10 = *(undefined4 **)(arg1 + 0x40);
            } while (puVar8 < puVar10);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar10 + -4;
    }
    *(undefined8 *)(puVar12 + -8) = 0x18002635a;
    fcn.180459870(*(uint64_t *)(puVar12 + 0x50) ^ (uint64_t)puVar12);
    return;
}

// ============================================================
// Function: FUN_180026450
// Address: 0x180026450
// Size: 121 bytes
// ============================================================
undefined8 fcn.180026450(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar3 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 8)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        cVar2 = '\0';
        if (piVar5 == *(int64_t **)0x180782430) {
            piVar5 = (int64_t *)0x0;
        }
        if (*(char *)(*piVar5 + 3) != '\0') {
            cVar2 = (*(code **)(*piVar5 + 0x20) == fcn.1800249a0) + '\x01';
        }
        fcn.180086b20(arg1, cVar2 == '\x02');
        return 1;
    }
    fcn.180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800264d0
// Address: 0x1800264d0
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800264d0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar2 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((piVar2 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar2 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (piVar5 == *(int64_t **)0x180782430) {
        piVar5 = (int64_t *)0x0;
    }
    iVar4 = *piVar5;
    if (*(char *)(iVar4 + 3) == '\0') {
        uVar3 = fcn.18009a8e0(arg1, 0x180621b48, 0x12);
        iVar4 = fcn.1800a0e30(*(undefined8 *)(iVar4 + 0x10), uVar3);
        if (iVar4 != 0) {
            uVar3 = 1;
            goto code_r0x000180026549;
        }
    }
    uVar3 = 0;
code_r0x000180026549:
    fcn.180086b20(arg1, uVar3);
    return 1;
}

// ============================================================
// Function: FUN_180026500
// Address: 0x180026500
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800264d0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar2 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((piVar2 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar2 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (piVar5 == *(int64_t **)0x180782430) {
        piVar5 = (int64_t *)0x0;
    }
    iVar4 = *piVar5;
    if (*(char *)(iVar4 + 3) == '\0') {
        uVar3 = fcn.18009a8e0(arg1, 0x180621b48, 0x12);
        iVar4 = fcn.1800a0e30(*(undefined8 *)(iVar4 + 0x10), uVar3);
        if (iVar4 != 0) {
            uVar3 = 1;
            goto code_r0x000180026549;
        }
    }
    uVar3 = 0;
code_r0x000180026549:
    fcn.180086b20(arg1, uVar3);
    return 1;
}

// ============================================================
// Function: FUN_180026561
// Address: 0x180026561
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800264d0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar2 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((piVar2 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar2 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (piVar5 == *(int64_t **)0x180782430) {
        piVar5 = (int64_t *)0x0;
    }
    iVar4 = *piVar5;
    if (*(char *)(iVar4 + 3) == '\0') {
        uVar3 = fcn.18009a8e0(arg1, 0x180621b48, 0x12);
        iVar4 = fcn.1800a0e30(*(undefined8 *)(iVar4 + 0x10), uVar3);
        if (iVar4 != 0) {
            uVar3 = 1;
            goto code_r0x000180026549;
        }
    }
    uVar3 = 0;
code_r0x000180026549:
    fcn.180086b20(arg1, uVar3);
    return 1;
}

// ============================================================
// Function: FUN_180026580
// Address: 0x180026580
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180026580(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    *(int64_t *)(arg2 + 0x20) = arg2 + 0x20;
    iVar1 = fcn.18009a8e0(arg1, 0x1805aadb1, 0);
    *(undefined4 *)(arg2 + 0x8c) = 0xffffffff;
    *(int64_t *)(arg2 + 0x10) = iVar1 + (int64_t)(int64_t *)(arg2 + 0x10);
    iVar2 = 0;
    if (0 < *(int32_t *)(arg2 + 0xa0)) {
        do {
            fcn.180026580(arg1, *(int64_t *)(*(int64_t *)(arg2 + 0x58) + (int64_t)iVar2 * 8));
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg2 + 0xa0));
    }
    return;
}

// ============================================================
// Function: FUN_180026600
// Address: 0x180026600
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180026600(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar4 = 0;
    *(int64_t *)(arg2 + 0x20) = ((arg2 + 0x20) - (int64_t)(int64_t *)(arg3 + 0x20)) + *(int64_t *)(arg3 + 0x20);
    *(int64_t *)(arg2 + 0x10) =
         (*(int64_t *)(arg3 + 0x10) - (int64_t)(int64_t *)(arg3 + 0x10)) + (int64_t)(int64_t *)(arg2 + 0x10);
    *(undefined4 *)(arg2 + 0x8c) = *(undefined4 *)(arg3 + 0x8c);
    if (0 < *(int32_t *)(arg2 + 0xa0)) {
        do {
            iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x58) + (int64_t)iVar4 * 8);
            *(int64_t *)(iVar1 + 0x20) = iVar1 + 0x20;
            iVar2 = fcn.18009a8e0(arg1, 0x1805aadb1, 0);
            iVar3 = 0;
            *(undefined4 *)(iVar1 + 0x8c) = 0xffffffff;
            *(int64_t *)(iVar1 + 0x10) = iVar2 + 0x10 + iVar1;
            if (0 < *(int32_t *)(iVar1 + 0xa0)) {
                do {
                    fcn.180026580(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + (int64_t)iVar3 * 8));
                    iVar3 = iVar3 + 1;
                } while (iVar3 < *(int32_t *)(iVar1 + 0xa0));
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < *(int32_t *)(arg2 + 0xa0));
    }
    return;
}

// ============================================================
// Function: FUN_180026657
// Address: 0x180026657
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180026600(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar4 = 0;
    *(int64_t *)(arg2 + 0x20) = ((arg2 + 0x20) - (int64_t)(int64_t *)(arg3 + 0x20)) + *(int64_t *)(arg3 + 0x20);
    *(int64_t *)(arg2 + 0x10) =
         (*(int64_t *)(arg3 + 0x10) - (int64_t)(int64_t *)(arg3 + 0x10)) + (int64_t)(int64_t *)(arg2 + 0x10);
    *(undefined4 *)(arg2 + 0x8c) = *(undefined4 *)(arg3 + 0x8c);
    if (0 < *(int32_t *)(arg2 + 0xa0)) {
        do {
            iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x58) + (int64_t)iVar4 * 8);
            *(int64_t *)(iVar1 + 0x20) = iVar1 + 0x20;
            iVar2 = fcn.18009a8e0(arg1, 0x1805aadb1, 0);
            iVar3 = 0;
            *(undefined4 *)(iVar1 + 0x8c) = 0xffffffff;
            *(int64_t *)(iVar1 + 0x10) = iVar2 + 0x10 + iVar1;
            if (0 < *(int32_t *)(iVar1 + 0xa0)) {
                do {
                    fcn.180026580(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + (int64_t)iVar3 * 8));
                    iVar3 = iVar3 + 1;
                } while (iVar3 < *(int32_t *)(iVar1 + 0xa0));
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < *(int32_t *)(arg2 + 0xa0));
    }
    return;
}

// ============================================================
// Function: FUN_1800266e2
// Address: 0x1800266e2
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180026600(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar4 = 0;
    *(int64_t *)(arg2 + 0x20) = ((arg2 + 0x20) - (int64_t)(int64_t *)(arg3 + 0x20)) + *(int64_t *)(arg3 + 0x20);
    *(int64_t *)(arg2 + 0x10) =
         (*(int64_t *)(arg3 + 0x10) - (int64_t)(int64_t *)(arg3 + 0x10)) + (int64_t)(int64_t *)(arg2 + 0x10);
    *(undefined4 *)(arg2 + 0x8c) = *(undefined4 *)(arg3 + 0x8c);
    if (0 < *(int32_t *)(arg2 + 0xa0)) {
        do {
            iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x58) + (int64_t)iVar4 * 8);
            *(int64_t *)(iVar1 + 0x20) = iVar1 + 0x20;
            iVar2 = fcn.18009a8e0(arg1, 0x1805aadb1, 0);
            iVar3 = 0;
            *(undefined4 *)(iVar1 + 0x8c) = 0xffffffff;
            *(int64_t *)(iVar1 + 0x10) = iVar2 + 0x10 + iVar1;
            if (0 < *(int32_t *)(iVar1 + 0xa0)) {
                do {
                    fcn.180026580(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + (int64_t)iVar3 * 8));
                    iVar3 = iVar3 + 1;
                } while (iVar3 < *(int32_t *)(iVar1 + 0xa0));
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < *(int32_t *)(arg2 + 0xa0));
    }
    return;
}

// ============================================================
// Function: FUN_180026700
// Address: 0x180026700
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180026700(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar13;
    if (piVar11 <= piVar13) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    piVar7 = piVar13 + 2;
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    if (piVar11 <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar13 == *(int64_t **)0x180782430) {
        piVar13 = piVar8;
    }
    if (piVar11 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar13;
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    iVar12 = *piVar7;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar15 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        iVar10 = var_8h;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        uVar15 = 0x180782468;
        *piVar13 = iVar10;
        *(undefined4 *)(piVar13 + 1) = 0;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar15, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da, &var_8h);
            *puVar9 = 1;
            iVar10 = var_8h;
        }
        if (*(char *)(iVar12 + 3) == '\0') {
            if (*(uint8_t *)(iVar10 + 4) < *(uint8_t *)(iVar12 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
            }
        } else {
            if (*(code **)(iVar12 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar13 = *(int64_t **)(arg1 + 0x40);
                piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar13 <= piVar11) {
                    piVar11 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar11 + 4);
                uVar3 = *(undefined4 *)(piVar11 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar11 + 0xc);
                *(undefined4 *)piVar13 = *(undefined4 *)piVar11;
                *(undefined4 *)((int64_t)piVar13 + 4) = uVar19;
                *(undefined4 *)(piVar13 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar12, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            if ((*(char *)(*piVar13 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar13 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar14 = *(undefined4 **)(arg1 + 0x40);
                puVar9 = puVar14 + -8;
                if (puVar9 < puVar14) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar14 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar14);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar14 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar10 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 3;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 2;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar15 = (*pcVar2)();
                    return uVar15;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar15 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar15 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar12 = func_0x0001800942b0(arg1, 0, uVar15);
        *(code **)(iVar12 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar12 + 0x28) = -(iVar12 + 0x28);
        *(int64_t *)(iVar12 + 0x30) = iVar12 + 0x30;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13;
        *piVar13 = iVar12;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
                puVar9 = *(undefined4 **)(arg1 + 0x40);
                var_20h._0_4_ = 0;
                *puVar9 = 1;
                puVar9[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                var_28h = *(int64_t *)(arg1 + 0x40) + -0x30;
                func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar15 = (*pcVar2)();
    return uVar15;
}

// ============================================================
// Function: FUN_180026739
// Address: 0x180026739
// Size: 2276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180026700(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar13;
    if (piVar11 <= piVar13) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    piVar7 = piVar13 + 2;
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    if (piVar11 <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar13 == *(int64_t **)0x180782430) {
        piVar13 = piVar8;
    }
    if (piVar11 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar13;
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    iVar12 = *piVar7;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar15 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        iVar10 = var_8h;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        uVar15 = 0x180782468;
        *piVar13 = iVar10;
        *(undefined4 *)(piVar13 + 1) = 0;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar15, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da, &var_8h);
            *puVar9 = 1;
            iVar10 = var_8h;
        }
        if (*(char *)(iVar12 + 3) == '\0') {
            if (*(uint8_t *)(iVar10 + 4) < *(uint8_t *)(iVar12 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
            }
        } else {
            if (*(code **)(iVar12 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar13 = *(int64_t **)(arg1 + 0x40);
                piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar13 <= piVar11) {
                    piVar11 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar11 + 4);
                uVar3 = *(undefined4 *)(piVar11 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar11 + 0xc);
                *(undefined4 *)piVar13 = *(undefined4 *)piVar11;
                *(undefined4 *)((int64_t)piVar13 + 4) = uVar19;
                *(undefined4 *)(piVar13 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar12, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            if ((*(char *)(*piVar13 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar13 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar14 = *(undefined4 **)(arg1 + 0x40);
                puVar9 = puVar14 + -8;
                if (puVar9 < puVar14) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar14 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar14);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar14 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar10 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 3;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 2;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar15 = (*pcVar2)();
                    return uVar15;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar15 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar15 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar12 = func_0x0001800942b0(arg1, 0, uVar15);
        *(code **)(iVar12 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar12 + 0x28) = -(iVar12 + 0x28);
        *(int64_t *)(iVar12 + 0x30) = iVar12 + 0x30;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13;
        *piVar13 = iVar12;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
                puVar9 = *(undefined4 **)(arg1 + 0x40);
                var_20h._0_4_ = 0;
                *puVar9 = 1;
                puVar9[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                var_28h = *(int64_t *)(arg1 + 0x40) + -0x30;
                func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar15 = (*pcVar2)();
    return uVar15;
}

// ============================================================
// Function: FUN_18002701d
// Address: 0x18002701d
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180026700(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar13;
    if (piVar11 <= piVar13) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    piVar7 = piVar13 + 2;
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    if (piVar11 <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar13 == *(int64_t **)0x180782430) {
        piVar13 = piVar8;
    }
    if (piVar11 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar13;
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    iVar12 = *piVar7;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar15 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        iVar10 = var_8h;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        uVar15 = 0x180782468;
        *piVar13 = iVar10;
        *(undefined4 *)(piVar13 + 1) = 0;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar15, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da, &var_8h);
            *puVar9 = 1;
            iVar10 = var_8h;
        }
        if (*(char *)(iVar12 + 3) == '\0') {
            if (*(uint8_t *)(iVar10 + 4) < *(uint8_t *)(iVar12 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
            }
        } else {
            if (*(code **)(iVar12 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar13 = *(int64_t **)(arg1 + 0x40);
                piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar13 <= piVar11) {
                    piVar11 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar11 + 4);
                uVar3 = *(undefined4 *)(piVar11 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar11 + 0xc);
                *(undefined4 *)piVar13 = *(undefined4 *)piVar11;
                *(undefined4 *)((int64_t)piVar13 + 4) = uVar19;
                *(undefined4 *)(piVar13 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar12, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            if ((*(char *)(*piVar13 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar13 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar14 = *(undefined4 **)(arg1 + 0x40);
                puVar9 = puVar14 + -8;
                if (puVar9 < puVar14) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar14 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar14);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar14 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar10 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 3;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 2;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar15 = (*pcVar2)();
                    return uVar15;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar15 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar15 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar12 = func_0x0001800942b0(arg1, 0, uVar15);
        *(code **)(iVar12 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar12 + 0x28) = -(iVar12 + 0x28);
        *(int64_t *)(iVar12 + 0x30) = iVar12 + 0x30;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13;
        *piVar13 = iVar12;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
                puVar9 = *(undefined4 **)(arg1 + 0x40);
                var_20h._0_4_ = 0;
                *puVar9 = 1;
                puVar9[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                var_28h = *(int64_t *)(arg1 + 0x40) + -0x30;
                func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar15 = (*pcVar2)();
    return uVar15;
}

// ============================================================
// Function: FUN_180027031
// Address: 0x180027031
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180026700(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar13;
    if (piVar11 <= piVar13) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    piVar7 = piVar13 + 2;
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    if (piVar11 <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar13 == *(int64_t **)0x180782430) {
        piVar13 = piVar8;
    }
    if (piVar11 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar13;
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    iVar12 = *piVar7;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar15 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        iVar10 = var_8h;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        uVar15 = 0x180782468;
        *piVar13 = iVar10;
        *(undefined4 *)(piVar13 + 1) = 0;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar15, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da, &var_8h);
            *puVar9 = 1;
            iVar10 = var_8h;
        }
        if (*(char *)(iVar12 + 3) == '\0') {
            if (*(uint8_t *)(iVar10 + 4) < *(uint8_t *)(iVar12 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
            }
        } else {
            if (*(code **)(iVar12 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar13 = *(int64_t **)(arg1 + 0x40);
                piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar13 <= piVar11) {
                    piVar11 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar11 + 4);
                uVar3 = *(undefined4 *)(piVar11 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar11 + 0xc);
                *(undefined4 *)piVar13 = *(undefined4 *)piVar11;
                *(undefined4 *)((int64_t)piVar13 + 4) = uVar19;
                *(undefined4 *)(piVar13 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar12, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            if ((*(char *)(*piVar13 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar13 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar14 = *(undefined4 **)(arg1 + 0x40);
                puVar9 = puVar14 + -8;
                if (puVar9 < puVar14) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar14 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar14);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar14 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar10 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 3;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 2;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar15 = (*pcVar2)();
                    return uVar15;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar15 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar15 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar12 = func_0x0001800942b0(arg1, 0, uVar15);
        *(code **)(iVar12 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar12 + 0x28) = -(iVar12 + 0x28);
        *(int64_t *)(iVar12 + 0x30) = iVar12 + 0x30;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13;
        *piVar13 = iVar12;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
                puVar9 = *(undefined4 **)(arg1 + 0x40);
                var_20h._0_4_ = 0;
                *puVar9 = 1;
                puVar9[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                var_28h = *(int64_t *)(arg1 + 0x40) + -0x30;
                func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar15 = (*pcVar2)();
    return uVar15;
}

// ============================================================
// Function: FUN_180027090
// Address: 0x180027090
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180026700(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar13;
    if (piVar11 <= piVar13) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    piVar7 = piVar13 + 2;
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar15 = (*pcVar2)();
        return uVar15;
    }
    if (piVar11 <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar13 == *(int64_t **)0x180782430) {
        piVar13 = piVar8;
    }
    if (piVar11 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar13;
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    iVar12 = *piVar7;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar15 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        iVar10 = var_8h;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0)) goto code_r0x000180027078;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        uVar15 = 0x180782468;
        *piVar13 = iVar10;
        *(undefined4 *)(piVar13 + 1) = 0;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar15, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da, &var_8h);
            *puVar9 = 1;
            iVar10 = var_8h;
        }
        if (*(char *)(iVar12 + 3) == '\0') {
            if (*(uint8_t *)(iVar10 + 4) < *(uint8_t *)(iVar12 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
            }
        } else {
            if (*(code **)(iVar12 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar13 = *(int64_t **)(arg1 + 0x40);
                piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar13 <= piVar11) {
                    piVar11 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar11 + 4);
                uVar3 = *(undefined4 *)(piVar11 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar11 + 0xc);
                *(undefined4 *)piVar13 = *(undefined4 *)piVar11;
                *(undefined4 *)((int64_t)piVar13 + 4) = uVar19;
                *(undefined4 *)(piVar13 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar12, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar15 = (*pcVar2)();
                return uVar15;
            }
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            if ((*(char *)(*piVar13 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar13 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar14 = *(undefined4 **)(arg1 + 0x40);
                puVar9 = puVar14 + -8;
                if (puVar9 < puVar14) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar14 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar14);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar14 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar13 == *(int64_t **)0x180782430) {
                piVar13 = piVar8;
            }
            iVar12 = *piVar13;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar12 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar12 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar12 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar12 + 0x20), *(int64_t *)(var_8h + 0x20), var_28h);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar12 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar12 + 4);
            if (*(char *)(iVar12 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar8;
                    iVar10 = (int64_t)iVar6;
                    puVar9 = (undefined4 *)(iVar12 + 0x28 + iVar10 * 0x10);
                    uVar19 = puVar9[1];
                    uVar3 = puVar9[2];
                    uVar4 = puVar9[3];
                    puVar14 = (undefined4 *)(var_8h + 0x28 + iVar10 * 0x10);
                    *puVar14 = *puVar9;
                    puVar14[1] = uVar19;
                    puVar14[2] = uVar3;
                    puVar14[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar10 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar10 = *(int64_t *)(var_8h + 0x28 + iVar10 * 0x10), (*(uint8_t *)(iVar10 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar1, iVar10);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar8 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar12 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar10 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar10 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 3;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar9 = (undefined4 *)func_0x000180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar9 = 2;
            }
            if ((*(char *)(iVar12 + 3) == '\0') || (*(code **)(iVar12 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar12, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, var_28h);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar15 = (*pcVar2)();
                    return uVar15;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar15 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar15 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar12 = func_0x0001800942b0(arg1, 0, uVar15);
        *(code **)(iVar12 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar12 + 0x28) = -(iVar12 + 0x28);
        *(int64_t *)(iVar12 + 0x30) = iVar12 + 0x30;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13;
        *piVar13 = iVar12;
        *(undefined4 *)((int64_t)piVar13 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
            puVar9 = *(undefined4 **)(arg1 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(var_20h._4_4_, (undefined4)var_20h)), iVar6 != 0)) {
                puVar9 = *(undefined4 **)(arg1 + 0x40);
                var_20h._0_4_ = 0;
                *puVar9 = 1;
                puVar9[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                var_28h = *(int64_t *)(arg1 + 0x40) + -0x30;
                func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar15 = (*pcVar2)();
    return uVar15;
}

// ============================================================
// Function: FUN_1800270b0
// Address: 0x1800270b0
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.1800270b0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int32_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t unaff_RDI;
    int64_t iVar17;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar15;
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar13 = (*pcVar4)();
        return uVar13;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar15 = *(int64_t **)0x180782430;
    }
    piVar10 = (int64_t *)0x0;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    var_8h = *piVar15;
    fcn.180086ba0(arg1, var_8h, 0);
    cVar8 = fcn.180024130(arg1, 0x180782478, 0);
    if (cVar8 == '\0') {
        return 0;
    }
    var_10h = unaff_RDI;
    piVar11 = (int32_t *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    iVar9 = *piVar11;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    iVar17 = *piVar15;
    if (iVar9 == 1) {
        *(undefined *)(var_8h + 5) = *(undefined *)(iVar17 + 5);
        *(undefined *)(var_8h + 6) = *(undefined *)(iVar17 + 6);
        *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar17 + 0x10);
        iVar12 = *(int64_t *)(var_8h + 0x10);
        if (((iVar12 != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) && ((*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                fcn.180094420(iVar3, iVar12);
            } else {
                *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
            }
        }
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        piVar15 = piVar10;
        if (*(char *)(var_8h + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar15;
                uVar14 = iVar9 + 1;
                piVar15 = (int64_t *)(uint64_t)uVar14;
                *(undefined4 *)(var_8h + 0x34 + (int64_t)iVar9 * 0x10) = 0;
            } while ((int32_t)uVar14 < (int32_t)(uint32_t)*(uint8_t *)(var_8h + 4));
        }
        *(undefined *)(var_8h + 4) = *(undefined *)(iVar17 + 4);
        if (*(char *)(iVar17 + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar10;
                iVar12 = (int64_t)iVar9;
                puVar1 = (undefined4 *)(iVar17 + 0x28 + iVar12 * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                puVar2 = (undefined4 *)(var_8h + 0x28 + iVar12 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar5;
                puVar2[2] = uVar6;
                puVar2[3] = uVar7;
                if (((5 < *(int32_t *)(var_8h + 0x34 + iVar12 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                   (iVar12 = *(int64_t *)(var_8h + 0x28 + iVar12 * 0x10), (*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
                    iVar3 = *(int64_t *)(arg1 + 0x20);
                    if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                        fcn.180094420(iVar3, iVar12);
                    } else {
                        *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                    }
                }
                piVar10 = (int64_t *)(uint64_t)(iVar9 + 1U);
            } while ((int32_t)(iVar9 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar17 + 4));
        }
    } else if (iVar9 == 2) {
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        *(int64_t *)(var_8h + 0x28) =
             (*(int64_t *)(iVar17 + 0x28) - (int64_t)(int64_t *)(var_8h + 0x28)) + (int64_t)(int64_t *)(iVar17 + 0x28);
        fcn.180086ba0(arg1, var_8h, 0);
        iVar17 = *(int64_t *)(arg1 + 0x40);
        iVar12 = *(int64_t *)(arg1 + 0x28);
        fcn.180023f30(arg1, 0x180782490, 0);
        fcn.180085bf0(arg1, iVar17 - iVar12 >> 4 & 0xffffffff);
        fcn.180086510(arg1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    } else if (iVar9 == 3) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = fcn.180085510(var_10h), iVar9 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar13 = (*pcVar4)();
            return uVar13;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        fcn.180024c30(arg1);
    }
    iVar17 = *(int64_t *)0x1807820d8;
    piVar10 = *(int64_t **)0x1807820c8;
    uVar16 = ((((((((var_8h & 0xffU ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)var_8h >> 8 & 0xff) *
                   0x100000001b3 ^ (uint64_t)var_8h >> 0x10 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x18 & 0xff) *
                 0x100000001b3 ^ (uint64_t)var_8h >> 0x20 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x28 & 0xff) *
               0x100000001b3 ^ (uint64_t)var_8h >> 0x30 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x38) *
             0x100000001b3 & *(uint64_t *)0x1807820f0;
    piVar15 = *(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10);
    if (piVar15 == *(int64_t **)0x1807820c8) {
code_r0x000180027441:
        piVar15 = (int64_t *)0x0;
    } else {
        iVar12 = piVar15[2];
        while (var_8h != iVar12) {
            if (piVar15 == *(int64_t **)(*(int64_t *)0x1807820d8 + uVar16 * 0x10)) goto code_r0x000180027441;
            piVar15 = (int64_t *)piVar15[1];
            iVar12 = piVar15[2];
        }
    }
    if (piVar15 != (int64_t *)0x0) {
        iVar12 = uVar16 * 0x10;
        if (*(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) == piVar15) {
            if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
                *(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) = *(int64_t **)0x1807820c8;
                *(int64_t **)(iVar17 + 8 + uVar16 * 0x10) = piVar10;
            } else {
                *(int64_t *)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) = piVar15[1];
            }
        } else if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
            *(int64_t *)(iVar12 + *(int64_t *)0x1807820d8) = *piVar15;
        }
        iVar17 = *piVar15;
        *(int64_t *)0x1807820d0 = *(int64_t *)0x1807820d0 + -1;
        *(int64_t *)piVar15[1] = iVar17;
        *(int64_t *)(iVar17 + 8) = piVar15[1];
        fcn.180459c3c(piVar15, 0x20);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return 0;
}

// ============================================================
// Function: FUN_1800270ef
// Address: 0x1800270ef
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.1800270b0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int32_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t unaff_RDI;
    int64_t iVar17;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar15;
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar13 = (*pcVar4)();
        return uVar13;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar15 = *(int64_t **)0x180782430;
    }
    piVar10 = (int64_t *)0x0;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    var_8h = *piVar15;
    fcn.180086ba0(arg1, var_8h, 0);
    cVar8 = fcn.180024130(arg1, 0x180782478, 0);
    if (cVar8 == '\0') {
        return 0;
    }
    var_10h = unaff_RDI;
    piVar11 = (int32_t *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    iVar9 = *piVar11;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    iVar17 = *piVar15;
    if (iVar9 == 1) {
        *(undefined *)(var_8h + 5) = *(undefined *)(iVar17 + 5);
        *(undefined *)(var_8h + 6) = *(undefined *)(iVar17 + 6);
        *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar17 + 0x10);
        iVar12 = *(int64_t *)(var_8h + 0x10);
        if (((iVar12 != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) && ((*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                fcn.180094420(iVar3, iVar12);
            } else {
                *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
            }
        }
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        piVar15 = piVar10;
        if (*(char *)(var_8h + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar15;
                uVar14 = iVar9 + 1;
                piVar15 = (int64_t *)(uint64_t)uVar14;
                *(undefined4 *)(var_8h + 0x34 + (int64_t)iVar9 * 0x10) = 0;
            } while ((int32_t)uVar14 < (int32_t)(uint32_t)*(uint8_t *)(var_8h + 4));
        }
        *(undefined *)(var_8h + 4) = *(undefined *)(iVar17 + 4);
        if (*(char *)(iVar17 + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar10;
                iVar12 = (int64_t)iVar9;
                puVar1 = (undefined4 *)(iVar17 + 0x28 + iVar12 * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                puVar2 = (undefined4 *)(var_8h + 0x28 + iVar12 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar5;
                puVar2[2] = uVar6;
                puVar2[3] = uVar7;
                if (((5 < *(int32_t *)(var_8h + 0x34 + iVar12 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                   (iVar12 = *(int64_t *)(var_8h + 0x28 + iVar12 * 0x10), (*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
                    iVar3 = *(int64_t *)(arg1 + 0x20);
                    if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                        fcn.180094420(iVar3, iVar12);
                    } else {
                        *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                    }
                }
                piVar10 = (int64_t *)(uint64_t)(iVar9 + 1U);
            } while ((int32_t)(iVar9 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar17 + 4));
        }
    } else if (iVar9 == 2) {
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        *(int64_t *)(var_8h + 0x28) =
             (*(int64_t *)(iVar17 + 0x28) - (int64_t)(int64_t *)(var_8h + 0x28)) + (int64_t)(int64_t *)(iVar17 + 0x28);
        fcn.180086ba0(arg1, var_8h, 0);
        iVar17 = *(int64_t *)(arg1 + 0x40);
        iVar12 = *(int64_t *)(arg1 + 0x28);
        fcn.180023f30(arg1, 0x180782490, 0);
        fcn.180085bf0(arg1, iVar17 - iVar12 >> 4 & 0xffffffff);
        fcn.180086510(arg1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    } else if (iVar9 == 3) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = fcn.180085510(var_10h), iVar9 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar13 = (*pcVar4)();
            return uVar13;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        fcn.180024c30(arg1);
    }
    iVar17 = *(int64_t *)0x1807820d8;
    piVar10 = *(int64_t **)0x1807820c8;
    uVar16 = ((((((((var_8h & 0xffU ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)var_8h >> 8 & 0xff) *
                   0x100000001b3 ^ (uint64_t)var_8h >> 0x10 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x18 & 0xff) *
                 0x100000001b3 ^ (uint64_t)var_8h >> 0x20 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x28 & 0xff) *
               0x100000001b3 ^ (uint64_t)var_8h >> 0x30 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x38) *
             0x100000001b3 & *(uint64_t *)0x1807820f0;
    piVar15 = *(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10);
    if (piVar15 == *(int64_t **)0x1807820c8) {
code_r0x000180027441:
        piVar15 = (int64_t *)0x0;
    } else {
        iVar12 = piVar15[2];
        while (var_8h != iVar12) {
            if (piVar15 == *(int64_t **)(*(int64_t *)0x1807820d8 + uVar16 * 0x10)) goto code_r0x000180027441;
            piVar15 = (int64_t *)piVar15[1];
            iVar12 = piVar15[2];
        }
    }
    if (piVar15 != (int64_t *)0x0) {
        iVar12 = uVar16 * 0x10;
        if (*(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) == piVar15) {
            if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
                *(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) = *(int64_t **)0x1807820c8;
                *(int64_t **)(iVar17 + 8 + uVar16 * 0x10) = piVar10;
            } else {
                *(int64_t *)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) = piVar15[1];
            }
        } else if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
            *(int64_t *)(iVar12 + *(int64_t *)0x1807820d8) = *piVar15;
        }
        iVar17 = *piVar15;
        *(int64_t *)0x1807820d0 = *(int64_t *)0x1807820d0 + -1;
        *(int64_t *)piVar15[1] = iVar17;
        *(int64_t *)(iVar17 + 8) = piVar15[1];
        fcn.180459c3c(piVar15, 0x20);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return 0;
}

// ============================================================
// Function: FUN_18002713c
// Address: 0x18002713c
// Size: 906 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.1800270b0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int32_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t unaff_RDI;
    int64_t iVar17;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar15;
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar13 = (*pcVar4)();
        return uVar13;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar15 = *(int64_t **)0x180782430;
    }
    piVar10 = (int64_t *)0x0;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    var_8h = *piVar15;
    fcn.180086ba0(arg1, var_8h, 0);
    cVar8 = fcn.180024130(arg1, 0x180782478, 0);
    if (cVar8 == '\0') {
        return 0;
    }
    var_10h = unaff_RDI;
    piVar11 = (int32_t *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    iVar9 = *piVar11;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    iVar17 = *piVar15;
    if (iVar9 == 1) {
        *(undefined *)(var_8h + 5) = *(undefined *)(iVar17 + 5);
        *(undefined *)(var_8h + 6) = *(undefined *)(iVar17 + 6);
        *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar17 + 0x10);
        iVar12 = *(int64_t *)(var_8h + 0x10);
        if (((iVar12 != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) && ((*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                fcn.180094420(iVar3, iVar12);
            } else {
                *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
            }
        }
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        piVar15 = piVar10;
        if (*(char *)(var_8h + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar15;
                uVar14 = iVar9 + 1;
                piVar15 = (int64_t *)(uint64_t)uVar14;
                *(undefined4 *)(var_8h + 0x34 + (int64_t)iVar9 * 0x10) = 0;
            } while ((int32_t)uVar14 < (int32_t)(uint32_t)*(uint8_t *)(var_8h + 4));
        }
        *(undefined *)(var_8h + 4) = *(undefined *)(iVar17 + 4);
        if (*(char *)(iVar17 + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar10;
                iVar12 = (int64_t)iVar9;
                puVar1 = (undefined4 *)(iVar17 + 0x28 + iVar12 * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                puVar2 = (undefined4 *)(var_8h + 0x28 + iVar12 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar5;
                puVar2[2] = uVar6;
                puVar2[3] = uVar7;
                if (((5 < *(int32_t *)(var_8h + 0x34 + iVar12 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                   (iVar12 = *(int64_t *)(var_8h + 0x28 + iVar12 * 0x10), (*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
                    iVar3 = *(int64_t *)(arg1 + 0x20);
                    if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                        fcn.180094420(iVar3, iVar12);
                    } else {
                        *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                    }
                }
                piVar10 = (int64_t *)(uint64_t)(iVar9 + 1U);
            } while ((int32_t)(iVar9 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar17 + 4));
        }
    } else if (iVar9 == 2) {
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        *(int64_t *)(var_8h + 0x28) =
             (*(int64_t *)(iVar17 + 0x28) - (int64_t)(int64_t *)(var_8h + 0x28)) + (int64_t)(int64_t *)(iVar17 + 0x28);
        fcn.180086ba0(arg1, var_8h, 0);
        iVar17 = *(int64_t *)(arg1 + 0x40);
        iVar12 = *(int64_t *)(arg1 + 0x28);
        fcn.180023f30(arg1, 0x180782490, 0);
        fcn.180085bf0(arg1, iVar17 - iVar12 >> 4 & 0xffffffff);
        fcn.180086510(arg1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    } else if (iVar9 == 3) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = fcn.180085510(var_10h), iVar9 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar13 = (*pcVar4)();
            return uVar13;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        fcn.180024c30(arg1);
    }
    iVar17 = *(int64_t *)0x1807820d8;
    piVar10 = *(int64_t **)0x1807820c8;
    uVar16 = ((((((((var_8h & 0xffU ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)var_8h >> 8 & 0xff) *
                   0x100000001b3 ^ (uint64_t)var_8h >> 0x10 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x18 & 0xff) *
                 0x100000001b3 ^ (uint64_t)var_8h >> 0x20 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x28 & 0xff) *
               0x100000001b3 ^ (uint64_t)var_8h >> 0x30 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x38) *
             0x100000001b3 & *(uint64_t *)0x1807820f0;
    piVar15 = *(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10);
    if (piVar15 == *(int64_t **)0x1807820c8) {
code_r0x000180027441:
        piVar15 = (int64_t *)0x0;
    } else {
        iVar12 = piVar15[2];
        while (var_8h != iVar12) {
            if (piVar15 == *(int64_t **)(*(int64_t *)0x1807820d8 + uVar16 * 0x10)) goto code_r0x000180027441;
            piVar15 = (int64_t *)piVar15[1];
            iVar12 = piVar15[2];
        }
    }
    if (piVar15 != (int64_t *)0x0) {
        iVar12 = uVar16 * 0x10;
        if (*(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) == piVar15) {
            if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
                *(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) = *(int64_t **)0x1807820c8;
                *(int64_t **)(iVar17 + 8 + uVar16 * 0x10) = piVar10;
            } else {
                *(int64_t *)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) = piVar15[1];
            }
        } else if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
            *(int64_t *)(iVar12 + *(int64_t *)0x1807820d8) = *piVar15;
        }
        iVar17 = *piVar15;
        *(int64_t *)0x1807820d0 = *(int64_t *)0x1807820d0 + -1;
        *(int64_t *)piVar15[1] = iVar17;
        *(int64_t *)(iVar17 + 8) = piVar15[1];
        fcn.180459c3c(piVar15, 0x20);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return 0;
}

// ============================================================
// Function: FUN_1800274c6
// Address: 0x1800274c6
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.1800270b0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int32_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t unaff_RDI;
    int64_t iVar17;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar15;
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar13 = (*pcVar4)();
        return uVar13;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar15 = *(int64_t **)0x180782430;
    }
    piVar10 = (int64_t *)0x0;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    var_8h = *piVar15;
    fcn.180086ba0(arg1, var_8h, 0);
    cVar8 = fcn.180024130(arg1, 0x180782478, 0);
    if (cVar8 == '\0') {
        return 0;
    }
    var_10h = unaff_RDI;
    piVar11 = (int32_t *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    iVar9 = *piVar11;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    iVar17 = *piVar15;
    if (iVar9 == 1) {
        *(undefined *)(var_8h + 5) = *(undefined *)(iVar17 + 5);
        *(undefined *)(var_8h + 6) = *(undefined *)(iVar17 + 6);
        *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar17 + 0x10);
        iVar12 = *(int64_t *)(var_8h + 0x10);
        if (((iVar12 != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) && ((*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                fcn.180094420(iVar3, iVar12);
            } else {
                *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
            }
        }
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        piVar15 = piVar10;
        if (*(char *)(var_8h + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar15;
                uVar14 = iVar9 + 1;
                piVar15 = (int64_t *)(uint64_t)uVar14;
                *(undefined4 *)(var_8h + 0x34 + (int64_t)iVar9 * 0x10) = 0;
            } while ((int32_t)uVar14 < (int32_t)(uint32_t)*(uint8_t *)(var_8h + 4));
        }
        *(undefined *)(var_8h + 4) = *(undefined *)(iVar17 + 4);
        if (*(char *)(iVar17 + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar10;
                iVar12 = (int64_t)iVar9;
                puVar1 = (undefined4 *)(iVar17 + 0x28 + iVar12 * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                puVar2 = (undefined4 *)(var_8h + 0x28 + iVar12 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar5;
                puVar2[2] = uVar6;
                puVar2[3] = uVar7;
                if (((5 < *(int32_t *)(var_8h + 0x34 + iVar12 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                   (iVar12 = *(int64_t *)(var_8h + 0x28 + iVar12 * 0x10), (*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
                    iVar3 = *(int64_t *)(arg1 + 0x20);
                    if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                        fcn.180094420(iVar3, iVar12);
                    } else {
                        *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                    }
                }
                piVar10 = (int64_t *)(uint64_t)(iVar9 + 1U);
            } while ((int32_t)(iVar9 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar17 + 4));
        }
    } else if (iVar9 == 2) {
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        *(int64_t *)(var_8h + 0x28) =
             (*(int64_t *)(iVar17 + 0x28) - (int64_t)(int64_t *)(var_8h + 0x28)) + (int64_t)(int64_t *)(iVar17 + 0x28);
        fcn.180086ba0(arg1, var_8h, 0);
        iVar17 = *(int64_t *)(arg1 + 0x40);
        iVar12 = *(int64_t *)(arg1 + 0x28);
        fcn.180023f30(arg1, 0x180782490, 0);
        fcn.180085bf0(arg1, iVar17 - iVar12 >> 4 & 0xffffffff);
        fcn.180086510(arg1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    } else if (iVar9 == 3) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = fcn.180085510(var_10h), iVar9 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar13 = (*pcVar4)();
            return uVar13;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        fcn.180024c30(arg1);
    }
    iVar17 = *(int64_t *)0x1807820d8;
    piVar10 = *(int64_t **)0x1807820c8;
    uVar16 = ((((((((var_8h & 0xffU ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)var_8h >> 8 & 0xff) *
                   0x100000001b3 ^ (uint64_t)var_8h >> 0x10 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x18 & 0xff) *
                 0x100000001b3 ^ (uint64_t)var_8h >> 0x20 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x28 & 0xff) *
               0x100000001b3 ^ (uint64_t)var_8h >> 0x30 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x38) *
             0x100000001b3 & *(uint64_t *)0x1807820f0;
    piVar15 = *(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10);
    if (piVar15 == *(int64_t **)0x1807820c8) {
code_r0x000180027441:
        piVar15 = (int64_t *)0x0;
    } else {
        iVar12 = piVar15[2];
        while (var_8h != iVar12) {
            if (piVar15 == *(int64_t **)(*(int64_t *)0x1807820d8 + uVar16 * 0x10)) goto code_r0x000180027441;
            piVar15 = (int64_t *)piVar15[1];
            iVar12 = piVar15[2];
        }
    }
    if (piVar15 != (int64_t *)0x0) {
        iVar12 = uVar16 * 0x10;
        if (*(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) == piVar15) {
            if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
                *(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) = *(int64_t **)0x1807820c8;
                *(int64_t **)(iVar17 + 8 + uVar16 * 0x10) = piVar10;
            } else {
                *(int64_t *)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) = piVar15[1];
            }
        } else if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
            *(int64_t *)(iVar12 + *(int64_t *)0x1807820d8) = *piVar15;
        }
        iVar17 = *piVar15;
        *(int64_t *)0x1807820d0 = *(int64_t *)0x1807820d0 + -1;
        *(int64_t *)piVar15[1] = iVar17;
        *(int64_t *)(iVar17 + 8) = piVar15[1];
        fcn.180459c3c(piVar15, 0x20);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return 0;
}

// ============================================================
// Function: FUN_1800274de
// Address: 0x1800274de
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

undefined8 fcn.1800270b0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int32_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    int64_t unaff_RDI;
    int64_t iVar17;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar15;
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar13 = (*pcVar4)();
        return uVar13;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar15) {
        piVar15 = *(int64_t **)0x180782430;
    }
    piVar10 = (int64_t *)0x0;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    var_8h = *piVar15;
    fcn.180086ba0(arg1, var_8h, 0);
    cVar8 = fcn.180024130(arg1, 0x180782478, 0);
    if (cVar8 == '\0') {
        return 0;
    }
    var_10h = unaff_RDI;
    piVar11 = (int32_t *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    iVar9 = *piVar11;
    if (piVar15 == *(int64_t **)0x180782430) {
        piVar15 = piVar10;
    }
    iVar17 = *piVar15;
    if (iVar9 == 1) {
        *(undefined *)(var_8h + 5) = *(undefined *)(iVar17 + 5);
        *(undefined *)(var_8h + 6) = *(undefined *)(iVar17 + 6);
        *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar17 + 0x10);
        iVar12 = *(int64_t *)(var_8h + 0x10);
        if (((iVar12 != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) && ((*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                fcn.180094420(iVar3, iVar12);
            } else {
                *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
            }
        }
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        piVar15 = piVar10;
        if (*(char *)(var_8h + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar15;
                uVar14 = iVar9 + 1;
                piVar15 = (int64_t *)(uint64_t)uVar14;
                *(undefined4 *)(var_8h + 0x34 + (int64_t)iVar9 * 0x10) = 0;
            } while ((int32_t)uVar14 < (int32_t)(uint32_t)*(uint8_t *)(var_8h + 4));
        }
        *(undefined *)(var_8h + 4) = *(undefined *)(iVar17 + 4);
        if (*(char *)(iVar17 + 4) != '\0') {
            do {
                iVar9 = (int32_t)piVar10;
                iVar12 = (int64_t)iVar9;
                puVar1 = (undefined4 *)(iVar17 + 0x28 + iVar12 * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                puVar2 = (undefined4 *)(var_8h + 0x28 + iVar12 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar5;
                puVar2[2] = uVar6;
                puVar2[3] = uVar7;
                if (((5 < *(int32_t *)(var_8h + 0x34 + iVar12 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                   (iVar12 = *(int64_t *)(var_8h + 0x28 + iVar12 * 0x10), (*(uint8_t *)(iVar12 + 1) & 3) != 0)) {
                    iVar3 = *(int64_t *)(arg1 + 0x20);
                    if ((uint8_t)(*(char *)(iVar3 + 0x59) - 1U) < 3) {
                        fcn.180094420(iVar3, iVar12);
                    } else {
                        *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar3 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                    }
                }
                piVar10 = (int64_t *)(uint64_t)(iVar9 + 1U);
            } while ((int32_t)(iVar9 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar17 + 4));
        }
    } else if (iVar9 == 2) {
        *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar17 + 0x20);
        *(int64_t *)(var_8h + 0x28) =
             (*(int64_t *)(iVar17 + 0x28) - (int64_t)(int64_t *)(var_8h + 0x28)) + (int64_t)(int64_t *)(iVar17 + 0x28);
        fcn.180086ba0(arg1, var_8h, 0);
        iVar17 = *(int64_t *)(arg1 + 0x40);
        iVar12 = *(int64_t *)(arg1 + 0x28);
        fcn.180023f30(arg1, 0x180782490, 0);
        fcn.180085bf0(arg1, iVar17 - iVar12 >> 4 & 0xffffffff);
        fcn.180086510(arg1);
        fcn.180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    } else if (iVar9 == 3) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = fcn.180085510(var_10h), iVar9 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar13 = (*pcVar4)();
            return uVar13;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        fcn.180024c30(arg1);
    }
    iVar17 = *(int64_t *)0x1807820d8;
    piVar10 = *(int64_t **)0x1807820c8;
    uVar16 = ((((((((var_8h & 0xffU ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)var_8h >> 8 & 0xff) *
                   0x100000001b3 ^ (uint64_t)var_8h >> 0x10 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x18 & 0xff) *
                 0x100000001b3 ^ (uint64_t)var_8h >> 0x20 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x28 & 0xff) *
               0x100000001b3 ^ (uint64_t)var_8h >> 0x30 & 0xff) * 0x100000001b3 ^ (uint64_t)var_8h >> 0x38) *
             0x100000001b3 & *(uint64_t *)0x1807820f0;
    piVar15 = *(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10);
    if (piVar15 == *(int64_t **)0x1807820c8) {
code_r0x000180027441:
        piVar15 = (int64_t *)0x0;
    } else {
        iVar12 = piVar15[2];
        while (var_8h != iVar12) {
            if (piVar15 == *(int64_t **)(*(int64_t *)0x1807820d8 + uVar16 * 0x10)) goto code_r0x000180027441;
            piVar15 = (int64_t *)piVar15[1];
            iVar12 = piVar15[2];
        }
    }
    if (piVar15 != (int64_t *)0x0) {
        iVar12 = uVar16 * 0x10;
        if (*(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) == piVar15) {
            if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
                *(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) = *(int64_t **)0x1807820c8;
                *(int64_t **)(iVar17 + 8 + uVar16 * 0x10) = piVar10;
            } else {
                *(int64_t *)(*(int64_t *)0x1807820d8 + 8 + uVar16 * 0x10) = piVar15[1];
            }
        } else if (*(int64_t **)(iVar12 + *(int64_t *)0x1807820d8) == piVar15) {
            *(int64_t *)(iVar12 + *(int64_t *)0x1807820d8) = *piVar15;
        }
        iVar17 = *piVar15;
        *(int64_t *)0x1807820d0 = *(int64_t *)0x1807820d0 + -1;
        *(int64_t *)piVar15[1] = iVar17;
        *(int64_t *)(iVar17 + 8) = piVar15[1];
        fcn.180459c3c(piVar15, 0x20);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return 0;
}

// ============================================================
// Function: FUN_180027500
// Address: 0x180027500
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180027500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    undefined4 in_stack_ffffffffffffffe0;
    undefined4 in_stack_ffffffffffffffe4;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 6)) {
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar7 = piVar11 + 4;
    if (piVar15 <= piVar11 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 3, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar14 + 0xc) == 6) {
code_r0x0001800275e0:
        iVar9 = *piVar14 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = fcn.1800a8360(arg1);
        if (iVar6 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            goto code_r0x0001800275e0;
        }
        iVar9 = 0;
    }
    iVar6 = func_0x000180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180088560(arg1, 0x180621b78);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (iVar9 == 0) {
        fcn.180086510(arg1);
    } else {
        uVar13 = fcn.180498cd0(iVar9);
        func_0x0001800867f0(arg1, iVar9, uVar13);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar9 = *(int64_t *)(arg1 + 0x40);
    puVar10 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar9 + -0x20), (undefined4 *)(iVar9 + -0x10));
    piVar14 = *(int64_t **)0x180782430;
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)(iVar9 + -0x10) = *puVar10;
    *(undefined4 *)(iVar9 + -0xc) = uVar19;
    *(undefined4 *)(iVar9 + -8) = uVar3;
    *(undefined4 *)(iVar9 + -4) = uVar4;
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar15 + -2;
    if ((piVar11 == piVar14) || (*(int32_t *)((int64_t)piVar15 + -4) != 8)) {
        fcn.1800858c0(arg1, 0xfffffffd);
        fcn.180088560(arg1, 0x180621bc8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar11 < piVar15) {
        do {
            uVar19 = *(undefined4 *)(piVar11 + 1);
            uVar3 = *(undefined4 *)((int64_t)piVar11 + 0xc);
            *(undefined4 *)(piVar11 + -2) = *(undefined4 *)piVar11;
            *(undefined4 *)((int64_t)piVar11 - 0xc) = *(undefined4 *)((int64_t)piVar11 + 4);
            *(undefined4 *)(piVar11 + -1) = uVar19;
            *(undefined4 *)((int64_t)piVar11 - 4) = uVar3;
            piVar15 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar11 + 2;
        } while (piVar11 < piVar15);
    }
    *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    uVar19 = *(undefined4 *)((int64_t)piVar11 + -0xc);
    uVar3 = *(undefined4 *)(piVar11 + -1);
    uVar4 = *(undefined4 *)((int64_t)piVar11 + -4);
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = piVar14;
    }
    *(undefined4 *)piVar15 = *(undefined4 *)(piVar11 + -2);
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (piVar11 <= piVar15) {
        piVar15 = piVar14;
    }
    for (; piVar15 < piVar11; piVar11 = piVar11 + -2) {
        *(undefined4 *)piVar11 = *(undefined4 *)(piVar11 + -2);
        *(undefined4 *)((int64_t)piVar11 + 4) = *(undefined4 *)((int64_t)piVar11 + -0xc);
        *(undefined4 *)(piVar11 + 1) = *(undefined4 *)(piVar11 + -1);
        *(undefined4 *)((int64_t)piVar11 + 0xc) = *(undefined4 *)((int64_t)piVar11 + -4);
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)piVar15 = *puVar10;
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    piVar7 = (int64_t *)0x0;
    if (piVar11 == *(int64_t **)0x180782430) {
        piVar11 = piVar7;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar11;
    if (piVar14 == *(int64_t **)0x180782430) {
        piVar14 = piVar7;
    }
    iVar9 = *piVar14;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar13 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        iVar8 = var_8h;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        uVar13 = 0x180782468;
        *piVar11 = iVar8;
        *(undefined4 *)(piVar11 + 1) = 0;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar13, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
            *puVar10 = 1;
            iVar8 = var_8h;
        }
        if (*(char *)(iVar9 + 3) == '\0') {
            if (*(uint8_t *)(iVar8 + 4) < *(uint8_t *)(iVar9 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
            }
        } else {
            if (*(code **)(iVar9 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar11 = *(int64_t **)(arg1 + 0x40);
                piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar11 <= piVar15) {
                    piVar15 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar15 + 4);
                uVar3 = *(undefined4 *)(piVar15 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar15 + 0xc);
                *(undefined4 *)piVar11 = *(undefined4 *)piVar15;
                *(undefined4 *)((int64_t)piVar11 + 4) = uVar19;
                *(undefined4 *)(piVar11 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar9, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            if ((*(char *)(*piVar11 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar11 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar12 = *(undefined4 **)(arg1 + 0x40);
                puVar10 = puVar12 + -8;
                if (puVar10 < puVar12) {
                    do {
                        puVar10[-4] = *puVar10;
                        puVar10[-3] = puVar10[1];
                        puVar10[-2] = puVar10[2];
                        puVar10[-1] = puVar10[3];
                        puVar12 = *(undefined4 **)(arg1 + 0x40);
                        puVar10 = puVar10 + 4;
                    } while (puVar10 < puVar12);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar12 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar8 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 3;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 2;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar13 = (*pcVar2)();
                    return uVar13;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar13 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar13 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar9 = func_0x0001800942b0(arg1, 0, uVar13);
        *(code **)(iVar9 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar9 + 0x28) = -(iVar9 + 0x28);
        *(int64_t *)(iVar9 + 0x30) = iVar9 + 0x30;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar11;
        *piVar11 = iVar9;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
            puVar10 = *(undefined4 **)(arg1 + 0x40);
            *puVar10 = puVar10[-8];
            puVar10[1] = puVar10[-7];
            puVar10[2] = puVar10[-6];
            puVar10[3] = puVar10[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
                puVar10 = *(undefined4 **)(arg1 + 0x40);
                *puVar10 = 1;
                puVar10[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180094080(arg1, 0x180087890, &stack0xffffffffffffffd8, 
                                    (*(int64_t *)(arg1 + 0x40) + -0x30) - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar13 = (*pcVar2)();
    return uVar13;
}

// ============================================================
// Function: FUN_180027577
// Address: 0x180027577
// Size: 461 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180027500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    undefined4 in_stack_ffffffffffffffe0;
    undefined4 in_stack_ffffffffffffffe4;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 6)) {
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar7 = piVar11 + 4;
    if (piVar15 <= piVar11 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 3, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar14 + 0xc) == 6) {
code_r0x0001800275e0:
        iVar9 = *piVar14 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = fcn.1800a8360(arg1);
        if (iVar6 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            goto code_r0x0001800275e0;
        }
        iVar9 = 0;
    }
    iVar6 = func_0x000180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180088560(arg1, 0x180621b78);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (iVar9 == 0) {
        fcn.180086510(arg1);
    } else {
        uVar13 = fcn.180498cd0(iVar9);
        func_0x0001800867f0(arg1, iVar9, uVar13);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar9 = *(int64_t *)(arg1 + 0x40);
    puVar10 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar9 + -0x20), (undefined4 *)(iVar9 + -0x10));
    piVar14 = *(int64_t **)0x180782430;
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)(iVar9 + -0x10) = *puVar10;
    *(undefined4 *)(iVar9 + -0xc) = uVar19;
    *(undefined4 *)(iVar9 + -8) = uVar3;
    *(undefined4 *)(iVar9 + -4) = uVar4;
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar15 + -2;
    if ((piVar11 == piVar14) || (*(int32_t *)((int64_t)piVar15 + -4) != 8)) {
        fcn.1800858c0(arg1, 0xfffffffd);
        fcn.180088560(arg1, 0x180621bc8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar11 < piVar15) {
        do {
            uVar19 = *(undefined4 *)(piVar11 + 1);
            uVar3 = *(undefined4 *)((int64_t)piVar11 + 0xc);
            *(undefined4 *)(piVar11 + -2) = *(undefined4 *)piVar11;
            *(undefined4 *)((int64_t)piVar11 - 0xc) = *(undefined4 *)((int64_t)piVar11 + 4);
            *(undefined4 *)(piVar11 + -1) = uVar19;
            *(undefined4 *)((int64_t)piVar11 - 4) = uVar3;
            piVar15 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar11 + 2;
        } while (piVar11 < piVar15);
    }
    *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    uVar19 = *(undefined4 *)((int64_t)piVar11 + -0xc);
    uVar3 = *(undefined4 *)(piVar11 + -1);
    uVar4 = *(undefined4 *)((int64_t)piVar11 + -4);
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = piVar14;
    }
    *(undefined4 *)piVar15 = *(undefined4 *)(piVar11 + -2);
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (piVar11 <= piVar15) {
        piVar15 = piVar14;
    }
    for (; piVar15 < piVar11; piVar11 = piVar11 + -2) {
        *(undefined4 *)piVar11 = *(undefined4 *)(piVar11 + -2);
        *(undefined4 *)((int64_t)piVar11 + 4) = *(undefined4 *)((int64_t)piVar11 + -0xc);
        *(undefined4 *)(piVar11 + 1) = *(undefined4 *)(piVar11 + -1);
        *(undefined4 *)((int64_t)piVar11 + 0xc) = *(undefined4 *)((int64_t)piVar11 + -4);
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)piVar15 = *puVar10;
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    piVar7 = (int64_t *)0x0;
    if (piVar11 == *(int64_t **)0x180782430) {
        piVar11 = piVar7;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar11;
    if (piVar14 == *(int64_t **)0x180782430) {
        piVar14 = piVar7;
    }
    iVar9 = *piVar14;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar13 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        iVar8 = var_8h;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        uVar13 = 0x180782468;
        *piVar11 = iVar8;
        *(undefined4 *)(piVar11 + 1) = 0;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar13, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
            *puVar10 = 1;
            iVar8 = var_8h;
        }
        if (*(char *)(iVar9 + 3) == '\0') {
            if (*(uint8_t *)(iVar8 + 4) < *(uint8_t *)(iVar9 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
            }
        } else {
            if (*(code **)(iVar9 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar11 = *(int64_t **)(arg1 + 0x40);
                piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar11 <= piVar15) {
                    piVar15 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar15 + 4);
                uVar3 = *(undefined4 *)(piVar15 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar15 + 0xc);
                *(undefined4 *)piVar11 = *(undefined4 *)piVar15;
                *(undefined4 *)((int64_t)piVar11 + 4) = uVar19;
                *(undefined4 *)(piVar11 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar9, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            if ((*(char *)(*piVar11 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar11 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar12 = *(undefined4 **)(arg1 + 0x40);
                puVar10 = puVar12 + -8;
                if (puVar10 < puVar12) {
                    do {
                        puVar10[-4] = *puVar10;
                        puVar10[-3] = puVar10[1];
                        puVar10[-2] = puVar10[2];
                        puVar10[-1] = puVar10[3];
                        puVar12 = *(undefined4 **)(arg1 + 0x40);
                        puVar10 = puVar10 + 4;
                    } while (puVar10 < puVar12);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar12 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar8 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 3;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 2;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar13 = (*pcVar2)();
                    return uVar13;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar13 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar13 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar9 = func_0x0001800942b0(arg1, 0, uVar13);
        *(code **)(iVar9 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar9 + 0x28) = -(iVar9 + 0x28);
        *(int64_t *)(iVar9 + 0x30) = iVar9 + 0x30;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar11;
        *piVar11 = iVar9;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
            puVar10 = *(undefined4 **)(arg1 + 0x40);
            *puVar10 = puVar10[-8];
            puVar10[1] = puVar10[-7];
            puVar10[2] = puVar10[-6];
            puVar10[3] = puVar10[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
                puVar10 = *(undefined4 **)(arg1 + 0x40);
                *puVar10 = 1;
                puVar10[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180094080(arg1, 0x180087890, &stack0xffffffffffffffd8, 
                                    (*(int64_t *)(arg1 + 0x40) + -0x30) - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar13 = (*pcVar2)();
    return uVar13;
}

// ============================================================
// Function: FUN_180027744
// Address: 0x180027744
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180027500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    undefined4 in_stack_ffffffffffffffe0;
    undefined4 in_stack_ffffffffffffffe4;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 6)) {
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar7 = piVar11 + 4;
    if (piVar15 <= piVar11 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 3, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar14 + 0xc) == 6) {
code_r0x0001800275e0:
        iVar9 = *piVar14 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = fcn.1800a8360(arg1);
        if (iVar6 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            goto code_r0x0001800275e0;
        }
        iVar9 = 0;
    }
    iVar6 = func_0x000180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180088560(arg1, 0x180621b78);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (iVar9 == 0) {
        fcn.180086510(arg1);
    } else {
        uVar13 = fcn.180498cd0(iVar9);
        func_0x0001800867f0(arg1, iVar9, uVar13);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar9 = *(int64_t *)(arg1 + 0x40);
    puVar10 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar9 + -0x20), (undefined4 *)(iVar9 + -0x10));
    piVar14 = *(int64_t **)0x180782430;
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)(iVar9 + -0x10) = *puVar10;
    *(undefined4 *)(iVar9 + -0xc) = uVar19;
    *(undefined4 *)(iVar9 + -8) = uVar3;
    *(undefined4 *)(iVar9 + -4) = uVar4;
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar15 + -2;
    if ((piVar11 == piVar14) || (*(int32_t *)((int64_t)piVar15 + -4) != 8)) {
        fcn.1800858c0(arg1, 0xfffffffd);
        fcn.180088560(arg1, 0x180621bc8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar11 < piVar15) {
        do {
            uVar19 = *(undefined4 *)(piVar11 + 1);
            uVar3 = *(undefined4 *)((int64_t)piVar11 + 0xc);
            *(undefined4 *)(piVar11 + -2) = *(undefined4 *)piVar11;
            *(undefined4 *)((int64_t)piVar11 - 0xc) = *(undefined4 *)((int64_t)piVar11 + 4);
            *(undefined4 *)(piVar11 + -1) = uVar19;
            *(undefined4 *)((int64_t)piVar11 - 4) = uVar3;
            piVar15 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar11 + 2;
        } while (piVar11 < piVar15);
    }
    *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    uVar19 = *(undefined4 *)((int64_t)piVar11 + -0xc);
    uVar3 = *(undefined4 *)(piVar11 + -1);
    uVar4 = *(undefined4 *)((int64_t)piVar11 + -4);
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = piVar14;
    }
    *(undefined4 *)piVar15 = *(undefined4 *)(piVar11 + -2);
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (piVar11 <= piVar15) {
        piVar15 = piVar14;
    }
    for (; piVar15 < piVar11; piVar11 = piVar11 + -2) {
        *(undefined4 *)piVar11 = *(undefined4 *)(piVar11 + -2);
        *(undefined4 *)((int64_t)piVar11 + 4) = *(undefined4 *)((int64_t)piVar11 + -0xc);
        *(undefined4 *)(piVar11 + 1) = *(undefined4 *)(piVar11 + -1);
        *(undefined4 *)((int64_t)piVar11 + 0xc) = *(undefined4 *)((int64_t)piVar11 + -4);
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)piVar15 = *puVar10;
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    piVar7 = (int64_t *)0x0;
    if (piVar11 == *(int64_t **)0x180782430) {
        piVar11 = piVar7;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar11;
    if (piVar14 == *(int64_t **)0x180782430) {
        piVar14 = piVar7;
    }
    iVar9 = *piVar14;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar13 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        iVar8 = var_8h;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        uVar13 = 0x180782468;
        *piVar11 = iVar8;
        *(undefined4 *)(piVar11 + 1) = 0;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar13, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
            *puVar10 = 1;
            iVar8 = var_8h;
        }
        if (*(char *)(iVar9 + 3) == '\0') {
            if (*(uint8_t *)(iVar8 + 4) < *(uint8_t *)(iVar9 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
            }
        } else {
            if (*(code **)(iVar9 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar11 = *(int64_t **)(arg1 + 0x40);
                piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar11 <= piVar15) {
                    piVar15 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar15 + 4);
                uVar3 = *(undefined4 *)(piVar15 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar15 + 0xc);
                *(undefined4 *)piVar11 = *(undefined4 *)piVar15;
                *(undefined4 *)((int64_t)piVar11 + 4) = uVar19;
                *(undefined4 *)(piVar11 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar9, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            if ((*(char *)(*piVar11 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar11 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar12 = *(undefined4 **)(arg1 + 0x40);
                puVar10 = puVar12 + -8;
                if (puVar10 < puVar12) {
                    do {
                        puVar10[-4] = *puVar10;
                        puVar10[-3] = puVar10[1];
                        puVar10[-2] = puVar10[2];
                        puVar10[-1] = puVar10[3];
                        puVar12 = *(undefined4 **)(arg1 + 0x40);
                        puVar10 = puVar10 + 4;
                    } while (puVar10 < puVar12);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar12 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar8 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 3;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 2;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar13 = (*pcVar2)();
                    return uVar13;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar13 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar13 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar9 = func_0x0001800942b0(arg1, 0, uVar13);
        *(code **)(iVar9 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar9 + 0x28) = -(iVar9 + 0x28);
        *(int64_t *)(iVar9 + 0x30) = iVar9 + 0x30;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar11;
        *piVar11 = iVar9;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
            puVar10 = *(undefined4 **)(arg1 + 0x40);
            *puVar10 = puVar10[-8];
            puVar10[1] = puVar10[-7];
            puVar10[2] = puVar10[-6];
            puVar10[3] = puVar10[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
                puVar10 = *(undefined4 **)(arg1 + 0x40);
                *puVar10 = 1;
                puVar10[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180094080(arg1, 0x180087890, &stack0xffffffffffffffd8, 
                                    (*(int64_t *)(arg1 + 0x40) + -0x30) - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar13 = (*pcVar2)();
    return uVar13;
}

// ============================================================
// Function: FUN_18002775a
// Address: 0x18002775a
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180027500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    undefined4 in_stack_ffffffffffffffe0;
    undefined4 in_stack_ffffffffffffffe4;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 6)) {
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar7 = piVar11 + 4;
    if (piVar15 <= piVar11 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 3, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar14 + 0xc) == 6) {
code_r0x0001800275e0:
        iVar9 = *piVar14 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = fcn.1800a8360(arg1);
        if (iVar6 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            goto code_r0x0001800275e0;
        }
        iVar9 = 0;
    }
    iVar6 = func_0x000180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180088560(arg1, 0x180621b78);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (iVar9 == 0) {
        fcn.180086510(arg1);
    } else {
        uVar13 = fcn.180498cd0(iVar9);
        func_0x0001800867f0(arg1, iVar9, uVar13);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar9 = *(int64_t *)(arg1 + 0x40);
    puVar10 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar9 + -0x20), (undefined4 *)(iVar9 + -0x10));
    piVar14 = *(int64_t **)0x180782430;
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)(iVar9 + -0x10) = *puVar10;
    *(undefined4 *)(iVar9 + -0xc) = uVar19;
    *(undefined4 *)(iVar9 + -8) = uVar3;
    *(undefined4 *)(iVar9 + -4) = uVar4;
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar15 + -2;
    if ((piVar11 == piVar14) || (*(int32_t *)((int64_t)piVar15 + -4) != 8)) {
        fcn.1800858c0(arg1, 0xfffffffd);
        fcn.180088560(arg1, 0x180621bc8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar11 < piVar15) {
        do {
            uVar19 = *(undefined4 *)(piVar11 + 1);
            uVar3 = *(undefined4 *)((int64_t)piVar11 + 0xc);
            *(undefined4 *)(piVar11 + -2) = *(undefined4 *)piVar11;
            *(undefined4 *)((int64_t)piVar11 - 0xc) = *(undefined4 *)((int64_t)piVar11 + 4);
            *(undefined4 *)(piVar11 + -1) = uVar19;
            *(undefined4 *)((int64_t)piVar11 - 4) = uVar3;
            piVar15 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar11 + 2;
        } while (piVar11 < piVar15);
    }
    *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    uVar19 = *(undefined4 *)((int64_t)piVar11 + -0xc);
    uVar3 = *(undefined4 *)(piVar11 + -1);
    uVar4 = *(undefined4 *)((int64_t)piVar11 + -4);
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = piVar14;
    }
    *(undefined4 *)piVar15 = *(undefined4 *)(piVar11 + -2);
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (piVar11 <= piVar15) {
        piVar15 = piVar14;
    }
    for (; piVar15 < piVar11; piVar11 = piVar11 + -2) {
        *(undefined4 *)piVar11 = *(undefined4 *)(piVar11 + -2);
        *(undefined4 *)((int64_t)piVar11 + 4) = *(undefined4 *)((int64_t)piVar11 + -0xc);
        *(undefined4 *)(piVar11 + 1) = *(undefined4 *)(piVar11 + -1);
        *(undefined4 *)((int64_t)piVar11 + 0xc) = *(undefined4 *)((int64_t)piVar11 + -4);
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)piVar15 = *puVar10;
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    piVar7 = (int64_t *)0x0;
    if (piVar11 == *(int64_t **)0x180782430) {
        piVar11 = piVar7;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar11;
    if (piVar14 == *(int64_t **)0x180782430) {
        piVar14 = piVar7;
    }
    iVar9 = *piVar14;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar13 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        iVar8 = var_8h;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        uVar13 = 0x180782468;
        *piVar11 = iVar8;
        *(undefined4 *)(piVar11 + 1) = 0;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar13, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
            *puVar10 = 1;
            iVar8 = var_8h;
        }
        if (*(char *)(iVar9 + 3) == '\0') {
            if (*(uint8_t *)(iVar8 + 4) < *(uint8_t *)(iVar9 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
            }
        } else {
            if (*(code **)(iVar9 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar11 = *(int64_t **)(arg1 + 0x40);
                piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar11 <= piVar15) {
                    piVar15 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar15 + 4);
                uVar3 = *(undefined4 *)(piVar15 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar15 + 0xc);
                *(undefined4 *)piVar11 = *(undefined4 *)piVar15;
                *(undefined4 *)((int64_t)piVar11 + 4) = uVar19;
                *(undefined4 *)(piVar11 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar9, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            if ((*(char *)(*piVar11 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar11 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar12 = *(undefined4 **)(arg1 + 0x40);
                puVar10 = puVar12 + -8;
                if (puVar10 < puVar12) {
                    do {
                        puVar10[-4] = *puVar10;
                        puVar10[-3] = puVar10[1];
                        puVar10[-2] = puVar10[2];
                        puVar10[-1] = puVar10[3];
                        puVar12 = *(undefined4 **)(arg1 + 0x40);
                        puVar10 = puVar10 + 4;
                    } while (puVar10 < puVar12);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar12 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar8 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 3;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 2;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar13 = (*pcVar2)();
                    return uVar13;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar13 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar13 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar9 = func_0x0001800942b0(arg1, 0, uVar13);
        *(code **)(iVar9 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar9 + 0x28) = -(iVar9 + 0x28);
        *(int64_t *)(iVar9 + 0x30) = iVar9 + 0x30;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar11;
        *piVar11 = iVar9;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
            puVar10 = *(undefined4 **)(arg1 + 0x40);
            *puVar10 = puVar10[-8];
            puVar10[1] = puVar10[-7];
            puVar10[2] = puVar10[-6];
            puVar10[3] = puVar10[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
                puVar10 = *(undefined4 **)(arg1 + 0x40);
                *puVar10 = 1;
                puVar10[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180094080(arg1, 0x180087890, &stack0xffffffffffffffd8, 
                                    (*(int64_t *)(arg1 + 0x40) + -0x30) - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar13 = (*pcVar2)();
    return uVar13;
}

// ============================================================
// Function: FUN_180027787
// Address: 0x180027787
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable var_187h
// WARNING: [rz-ghidra] Detected overlap for variable var_186h
// WARNING: [rz-ghidra] Detected overlap for variable var_185h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h
// WARNING: [rz-ghidra] Detected overlap for variable var_181h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

undefined8 fcn.180027500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    undefined4 uVar19;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    undefined4 in_stack_ffffffffffffffe0;
    undefined4 in_stack_ffffffffffffffe4;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 6)) {
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar7 = piVar11 + 4;
    if (piVar15 <= piVar11 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 3, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar14 + 0xc) == 6) {
code_r0x0001800275e0:
        iVar9 = *piVar14 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = fcn.1800a8360(arg1);
        if (iVar6 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            goto code_r0x0001800275e0;
        }
        iVar9 = 0;
    }
    iVar6 = func_0x000180087120(arg1, 1);
    if (iVar6 == 0) {
        fcn.180088560(arg1, 0x180621b78);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (iVar9 == 0) {
        fcn.180086510(arg1);
    } else {
        uVar13 = fcn.180498cd0(iVar9);
        func_0x0001800867f0(arg1, iVar9, uVar13);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar9 = *(int64_t *)(arg1 + 0x40);
    puVar10 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar9 + -0x20), (undefined4 *)(iVar9 + -0x10));
    piVar14 = *(int64_t **)0x180782430;
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)(iVar9 + -0x10) = *puVar10;
    *(undefined4 *)(iVar9 + -0xc) = uVar19;
    *(undefined4 *)(iVar9 + -8) = uVar3;
    *(undefined4 *)(iVar9 + -4) = uVar4;
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar15 + -2;
    if ((piVar11 == piVar14) || (*(int32_t *)((int64_t)piVar15 + -4) != 8)) {
        fcn.1800858c0(arg1, 0xfffffffd);
        fcn.180088560(arg1, 0x180621bc8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar11 < piVar15) {
        do {
            uVar19 = *(undefined4 *)(piVar11 + 1);
            uVar3 = *(undefined4 *)((int64_t)piVar11 + 0xc);
            *(undefined4 *)(piVar11 + -2) = *(undefined4 *)piVar11;
            *(undefined4 *)((int64_t)piVar11 - 0xc) = *(undefined4 *)((int64_t)piVar11 + 4);
            *(undefined4 *)(piVar11 + -1) = uVar19;
            *(undefined4 *)((int64_t)piVar11 - 4) = uVar3;
            piVar15 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar11 + 2;
        } while (piVar11 < piVar15);
    }
    *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    uVar19 = *(undefined4 *)((int64_t)piVar11 + -0xc);
    uVar3 = *(undefined4 *)(piVar11 + -1);
    uVar4 = *(undefined4 *)((int64_t)piVar11 + -4);
    piVar15 = *(int64_t **)(arg1 + 0x28);
    if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
        piVar15 = piVar14;
    }
    *(undefined4 *)piVar15 = *(undefined4 *)(piVar11 + -2);
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (piVar11 <= piVar15) {
        piVar15 = piVar14;
    }
    for (; piVar15 < piVar11; piVar11 = piVar11 + -2) {
        *(undefined4 *)piVar11 = *(undefined4 *)(piVar11 + -2);
        *(undefined4 *)((int64_t)piVar11 + 4) = *(undefined4 *)((int64_t)piVar11 + -0xc);
        *(undefined4 *)(piVar11 + 1) = *(undefined4 *)(piVar11 + -1);
        *(undefined4 *)((int64_t)piVar11 + 0xc) = *(undefined4 *)((int64_t)piVar11 + -4);
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    uVar19 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *(undefined4 *)piVar15 = *puVar10;
    *(undefined4 *)((int64_t)piVar15 + 4) = uVar19;
    *(undefined4 *)(piVar15 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar11;
    if (piVar15 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    piVar14 = piVar11 + 2;
    piVar7 = piVar14;
    if (piVar15 <= piVar14) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar13 = (*pcVar2)();
        return uVar13;
    }
    if (piVar15 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    piVar7 = (int64_t *)0x0;
    if (piVar11 == *(int64_t **)0x180782430) {
        piVar11 = piVar7;
    }
    if (piVar15 <= piVar14) {
        piVar14 = *(int64_t **)0x180782430;
    }
    var_8h = *piVar11;
    if (piVar14 == *(int64_t **)0x180782430) {
        piVar14 = piVar7;
    }
    iVar9 = *piVar14;
    fcn.1800869f0(0);
    fcn.180085bf0(arg1, 1);
    uVar19 = func_0x000180087810(arg1, 1);
    uVar17 = *(uint8_t *)(arg1 + 1);
    uVar18 = uVar17 & 4;
    cVar5 = fcn.1800289c0(uVar19, &var_8h);
    if (cVar5 == '\0') {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        fcn.180086ba0(arg1, var_8h, 0);
        uVar13 = 0x180782478;
    } else {
        if (uVar18 != 0) {
            *(uint8_t *)(arg1 + 1) = uVar17 & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        iVar8 = var_8h;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
        goto code_r0x000180027078;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        uVar13 = 0x180782468;
        *piVar11 = iVar8;
        *(undefined4 *)(piVar11 + 1) = 0;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    uVar16 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, uVar13, 0);
    fcn.180085bf0(arg1, uVar16 & 0xffffffff);
    fcn.180085bf0(arg1, (int32_t)uVar16 + -1);
    uVar19 = fcn.180087440(arg1, 0xfffffffd);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
    if (*(char *)(var_8h + 3) == '\0') {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (cVar5 == '\0') {
            puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da, &var_8h);
            *puVar10 = 1;
            iVar8 = var_8h;
        }
        if (*(char *)(iVar9 + 3) == '\0') {
            if (*(uint8_t *)(iVar8 + 4) < *(uint8_t *)(iVar9 + 4)) goto code_r0x000180026b9f;
            fcn.180085bf0(arg1, 2);
code_r0x000180026c43:
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
            }
        } else {
            if (*(code **)(iVar9 + 0x20) != fcn.1800249a0) {
code_r0x000180026b9f:
                fcn.1800869f0(0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 == 0))
                goto code_r0x000180027078;
                piVar11 = *(int64_t **)(arg1 + 0x40);
                piVar15 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (piVar11 <= piVar15) {
                    piVar15 = *(int64_t **)0x180782430;
                }
                uVar19 = *(undefined4 *)((int64_t)piVar15 + 4);
                uVar3 = *(undefined4 *)(piVar15 + 1);
                uVar4 = *(undefined4 *)((int64_t)piVar15 + 0xc);
                *(undefined4 *)piVar11 = *(undefined4 *)piVar15;
                *(undefined4 *)((int64_t)piVar11 + 4) = uVar19;
                *(undefined4 *)(piVar11 + 1) = uVar3;
                *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar4;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180087810(arg1, 1);
                goto code_r0x000180026c43;
            }
            fcn.180086ba0(arg1, iVar9, 0);
            cVar5 = fcn.180024130(arg1, 0x180782490, 0);
            if (cVar5 == '\0') {
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                fcn.1800858c0(arg1, 0xfffffffe);
                func_0x000180088380(arg1, 2, 0x180621b90);
                pcVar2 = (code *)swi(3);
                uVar13 = (*pcVar2)();
                return uVar13;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            if ((*(char *)(*piVar11 + 3) != '\0') || (*(uint8_t *)(var_8h + 4) < *(uint8_t *)(*piVar11 + 4))) {
                fcn.1800869f0(0);
                fcn.180085bf0(arg1, 0xfffffffe);
                puVar12 = *(undefined4 **)(arg1 + 0x40);
                puVar10 = puVar12 + -8;
                if (puVar10 < puVar12) {
                    do {
                        puVar10[-4] = *puVar10;
                        puVar10[-3] = puVar10[1];
                        puVar10[-2] = puVar10[2];
                        puVar10[-1] = puVar10[3];
                        puVar12 = *(undefined4 **)(arg1 + 0x40);
                        puVar10 = puVar10 + 4;
                    } while (puVar10 < puVar12);
                }
                *(undefined4 **)(arg1 + 0x40) = puVar12 + -4;
                func_0x000180087810(arg1, 1);
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar7;
            }
            iVar9 = *piVar11;
            *(undefined *)(var_8h + 5) = *(undefined *)(iVar9 + 5);
            *(undefined *)(var_8h + 6) = *(undefined *)(iVar9 + 6);
            *(undefined8 *)(var_8h + 0x10) = *(undefined8 *)(iVar9 + 0x10);
            if (((*(int64_t *)(var_8h + 0x10) != 0) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)(var_8h + 0x10) + 1) & 3) != 0)) {
                if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                    fcn.180094420();
                } else {
                    *(uint8_t *)(var_8h + 1) =
                         *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                }
            }
            fcn.180026600(arg1, *(int64_t *)(iVar9 + 0x20), *(int64_t *)(var_8h + 0x20), in_stack_ffffffffffffffd8);
            *(undefined8 *)(var_8h + 0x20) = *(undefined8 *)(iVar9 + 0x20);
            *(undefined *)(var_8h + 4) = *(undefined *)(iVar9 + 4);
            if (*(char *)(iVar9 + 4) != '\0') {
                do {
                    iVar6 = (int32_t)piVar7;
                    iVar8 = (int64_t)iVar6;
                    puVar10 = (undefined4 *)(iVar9 + 0x28 + iVar8 * 0x10);
                    uVar19 = puVar10[1];
                    uVar3 = puVar10[2];
                    uVar4 = puVar10[3];
                    puVar12 = (undefined4 *)(var_8h + 0x28 + iVar8 * 0x10);
                    *puVar12 = *puVar10;
                    puVar12[1] = uVar19;
                    puVar12[2] = uVar3;
                    puVar12[3] = uVar4;
                    if (((5 < *(int32_t *)(var_8h + 0x34 + iVar8 * 0x10)) && ((*(uint8_t *)(var_8h + 1) & 4) != 0)) &&
                       (iVar8 = *(int64_t *)(var_8h + 0x28 + iVar8 * 0x10), (*(uint8_t *)(iVar8 + 1) & 3) != 0)) {
                        iVar1 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                            fcn.180094420(iVar1, iVar8);
                        } else {
                            *(uint8_t *)(var_8h + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(var_8h + 1) & 0xf8;
                        }
                    }
                    piVar7 = (int64_t *)(uint64_t)(iVar6 + 1U);
                } while ((int32_t)(iVar6 + 1U) < (int32_t)(uint32_t)*(uint8_t *)(iVar9 + 4));
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                goto code_r0x000180026e74;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    } else {
        iVar8 = var_8h;
        cVar5 = fcn.1800289c0(uVar19, &var_8h);
        if (*(code **)(iVar8 + 0x20) == fcn.1800249a0) {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 3;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') goto code_r0x000180027068;
            }
        } else {
            if (cVar5 == '\0') {
                puVar10 = (undefined4 *)fcn.180028a80(extraout_XMM0_Da_00, &var_8h);
                *puVar10 = 2;
            }
            if ((*(char *)(iVar9 + 3) == '\0') || (*(code **)(iVar9 + 0x20) != fcn.1800249a0)) {
                fcn.180085bf0(arg1, 2);
                fcn.180086ba0(arg1, var_8h, 0);
                fcn.180024c30(arg1);
            } else {
                fcn.180086ba0(arg1, iVar9, 0);
                cVar5 = fcn.180024c90(arg1, var_8h, in_stack_ffffffffffffffd8);
                if (cVar5 == '\0') {
code_r0x000180027068:
                    fcn.180088560(arg1, 0x180621b90);
                    pcVar2 = (code *)swi(3);
                    uVar13 = (*pcVar2)();
                    return uVar13;
                }
            }
            *(code **)(var_8h + 0x20) = fcn.1800249a0;
            *(int64_t *)(var_8h + 0x28) = (int64_t)fcn.1800248f0 - (int64_t)(int64_t *)(var_8h + 0x28);
        }
    }
code_r0x000180026e74:
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
        if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
            uVar13 = *(undefined8 *)(arg1 + 0x58);
        } else {
            uVar13 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
        }
        iVar9 = func_0x0001800942b0(arg1, 0, uVar13);
        *(code **)(iVar9 + 0x20) = fcn.180024d20;
        *(int64_t *)(iVar9 + 0x28) = -(iVar9 + 0x28);
        *(int64_t *)(iVar9 + 0x30) = iVar9 + 0x30;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar11;
        *piVar11 = iVar9;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = 8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
            puVar10 = *(undefined4 **)(arg1 + 0x40);
            *puVar10 = puVar10[-8];
            puVar10[1] = puVar10[-7];
            puVar10[2] = puVar10[-6];
            puVar10[3] = puVar10[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0)), iVar6 != 0)) {
                puVar10 = *(undefined4 **)(arg1 + 0x40);
                *puVar10 = 1;
                puVar10[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180094080(arg1, 0x180087890, &stack0xffffffffffffffd8, 
                                    (*(int64_t *)(arg1 + 0x40) + -0x30) - *(int64_t *)(arg1 + 0x38), 0);
                return 1;
            }
        }
    }
code_r0x000180027078:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar13 = (*pcVar2)();
    return uVar13;
}

// ============================================================
// Function: FUN_1800277b0
// Address: 0x1800277b0
// Size: 43 bytes
// ============================================================
undefined8 fcn.1800277b0(int64_t arg1)
{
    fcn.180013530();
    fcn.180086b20(arg1, *(uint8_t *)(arg1 + 1) >> 6 & 1);
    return 1;
}

// ============================================================
// Function: FUN_1800277e0
// Address: 0x1800277e0
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_27910h because it doesn't fit into ProtoModel

int64_t fcn.1800277e0(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar5 = *(int32_t *)(arg1 + 0xa8);
    iVar3 = 2;
    if (0 < iVar5) {
        iVar4 = 0;
        do {
            piVar7 = (int64_t *)((int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x38));
    // switch table (9 cases) at 0x180027938
            switch(*(undefined4 *)((int64_t)piVar7 + 0xc)) {
            case 0:
                iVar3 = iVar3 + 1;
                break;
            case 1:
            case 4:
                iVar3 = iVar3 + 4;
                break;
            case 3:
                iVar3 = iVar3 + 8;
                break;
            case 5:
                iVar3 = iVar3 + 0xc;
                break;
            case 6:
                iVar3 = iVar3 + (uint64_t)*(uint32_t *)(*piVar7 + 0x14);
                break;
            case 7:
                iVar2 = *(int64_t *)(*piVar7 + 0x28);
                if ((iVar2 != 0x180782410) && (iVar6 = 1 << (*(uint8_t *)(*piVar7 + 7) & 0x1f), 0 < iVar6)) {
                    uVar1 = 0;
                    do {
                        if (((uint8_t)*(undefined4 *)((uint64_t)uVar1 * 0x20 + 0x1c + iVar2) & 0xf) == 6) {
                            iVar3 = iVar3 + (uint64_t)
                                            *(uint32_t *)(*(int64_t *)((uint64_t)uVar1 * 0x20 + 0x10 + iVar2) + 0x14);
                        }
                        uVar1 = uVar1 + 1;
                    } while ((int32_t)uVar1 < iVar6);
                    iVar5 = *(int32_t *)(arg1 + 0xa8);
                }
                break;
            case 8:
                if (*(char *)(*piVar7 + 3) == '\0') {
                    iVar2 = fcn.1800277e0(*(int64_t *)(*piVar7 + 0x20));
                    iVar5 = *(int32_t *)(arg1 + 0xa8);
                } else {
                    iVar2 = 1;
                }
                iVar3 = iVar3 + iVar2;
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < iVar5);
    }
    iVar5 = 0;
    if (0 < *(int32_t *)(arg1 + 0xa0)) {
        do {
            iVar2 = fcn.1800277e0(*(int64_t *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar5 * 8));
            iVar3 = iVar3 + iVar2;
            iVar5 = iVar5 + 1;
        } while (iVar5 < *(int32_t *)(arg1 + 0xa0));
    }
    return iVar3 + (int64_t)*(int32_t *)(arg1 + 0x9c) * 4;
}

// ============================================================
// Function: FUN_180027805
// Address: 0x180027805
// Size: 238 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_27910h because it doesn't fit into ProtoModel

int64_t fcn.1800277e0(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar5 = *(int32_t *)(arg1 + 0xa8);
    iVar3 = 2;
    if (0 < iVar5) {
        iVar4 = 0;
        do {
            piVar7 = (int64_t *)((int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x38));
    // switch table (9 cases) at 0x180027938
            switch(*(undefined4 *)((int64_t)piVar7 + 0xc)) {
            case 0:
                iVar3 = iVar3 + 1;
                break;
            case 1:
            case 4:
                iVar3 = iVar3 + 4;
                break;
            case 3:
                iVar3 = iVar3 + 8;
                break;
            case 5:
                iVar3 = iVar3 + 0xc;
                break;
            case 6:
                iVar3 = iVar3 + (uint64_t)*(uint32_t *)(*piVar7 + 0x14);
                break;
            case 7:
                iVar2 = *(int64_t *)(*piVar7 + 0x28);
                if ((iVar2 != 0x180782410) && (iVar6 = 1 << (*(uint8_t *)(*piVar7 + 7) & 0x1f), 0 < iVar6)) {
                    uVar1 = 0;
                    do {
                        if (((uint8_t)*(undefined4 *)((uint64_t)uVar1 * 0x20 + 0x1c + iVar2) & 0xf) == 6) {
                            iVar3 = iVar3 + (uint64_t)
                                            *(uint32_t *)(*(int64_t *)((uint64_t)uVar1 * 0x20 + 0x10 + iVar2) + 0x14);
                        }
                        uVar1 = uVar1 + 1;
                    } while ((int32_t)uVar1 < iVar6);
                    iVar5 = *(int32_t *)(arg1 + 0xa8);
                }
                break;
            case 8:
                if (*(char *)(*piVar7 + 3) == '\0') {
                    iVar2 = fcn.1800277e0(*(int64_t *)(*piVar7 + 0x20));
                    iVar5 = *(int32_t *)(arg1 + 0xa8);
                } else {
                    iVar2 = 1;
                }
                iVar3 = iVar3 + iVar2;
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < iVar5);
    }
    iVar5 = 0;
    if (0 < *(int32_t *)(arg1 + 0xa0)) {
        do {
            iVar2 = fcn.1800277e0(*(int64_t *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar5 * 8));
            iVar3 = iVar3 + iVar2;
            iVar5 = iVar5 + 1;
        } while (iVar5 < *(int32_t *)(arg1 + 0xa0));
    }
    return iVar3 + (int64_t)*(int32_t *)(arg1 + 0x9c) * 4;
}

// ============================================================
// Function: FUN_1800278f3
// Address: 0x1800278f3
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_27910h because it doesn't fit into ProtoModel

int64_t fcn.1800277e0(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar5 = *(int32_t *)(arg1 + 0xa8);
    iVar3 = 2;
    if (0 < iVar5) {
        iVar4 = 0;
        do {
            piVar7 = (int64_t *)((int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x38));
    // switch table (9 cases) at 0x180027938
            switch(*(undefined4 *)((int64_t)piVar7 + 0xc)) {
            case 0:
                iVar3 = iVar3 + 1;
                break;
            case 1:
            case 4:
                iVar3 = iVar3 + 4;
                break;
            case 3:
                iVar3 = iVar3 + 8;
                break;
            case 5:
                iVar3 = iVar3 + 0xc;
                break;
            case 6:
                iVar3 = iVar3 + (uint64_t)*(uint32_t *)(*piVar7 + 0x14);
                break;
            case 7:
                iVar2 = *(int64_t *)(*piVar7 + 0x28);
                if ((iVar2 != 0x180782410) && (iVar6 = 1 << (*(uint8_t *)(*piVar7 + 7) & 0x1f), 0 < iVar6)) {
                    uVar1 = 0;
                    do {
                        if (((uint8_t)*(undefined4 *)((uint64_t)uVar1 * 0x20 + 0x1c + iVar2) & 0xf) == 6) {
                            iVar3 = iVar3 + (uint64_t)
                                            *(uint32_t *)(*(int64_t *)((uint64_t)uVar1 * 0x20 + 0x10 + iVar2) + 0x14);
                        }
                        uVar1 = uVar1 + 1;
                    } while ((int32_t)uVar1 < iVar6);
                    iVar5 = *(int32_t *)(arg1 + 0xa8);
                }
                break;
            case 8:
                if (*(char *)(*piVar7 + 3) == '\0') {
                    iVar2 = fcn.1800277e0(*(int64_t *)(*piVar7 + 0x20));
                    iVar5 = *(int32_t *)(arg1 + 0xa8);
                } else {
                    iVar2 = 1;
                }
                iVar3 = iVar3 + iVar2;
            }
            iVar4 = iVar4 + 1;
        } while (iVar4 < iVar5);
    }
    iVar5 = 0;
    if (0 < *(int32_t *)(arg1 + 0xa0)) {
        do {
            iVar2 = fcn.1800277e0(*(int64_t *)(*(int64_t *)(arg1 + 0x58) + (int64_t)iVar5 * 8));
            iVar3 = iVar3 + iVar2;
            iVar5 = iVar5 + 1;
        } while (iVar5 < *(int32_t *)(arg1 + 0xa0));
    }
    return iVar3 + (int64_t)*(int32_t *)(arg1 + 0x9c) * 4;
}

// ============================================================
// Function: FUN_180027960
// Address: 0x180027960
// Size: 1740 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_93h
// WARNING: [rz-ghidra] Removing arg arg_27910h because it doesn't fit into ProtoModel

int64_t fcn.180027960(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_a0h,
                     int64_t arg_a8h)
{
    undefined *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    undefined *puVar7;
    uint64_t uVar8;
    undefined *puVar9;
    int32_t iVar10;
    uint64_t uVar11;
    undefined uVar12;
    undefined *puVar13;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_98 [4];
    int64_t var_94h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t in_stack_ffffffffffffffb8;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    var_78h._0_4_ = 1;
    uVar3 = fcn.1800277e0(arg2);
    if (uVar3 == 0) goto code_r0x000180027a65;
    puVar13 = auStack_98;
    if (0x7fffffffffffffff < uVar3) goto code_r0x000180027ffa;
    if (0xfff < uVar3) {
        if (uVar3 + 0x27 <= uVar3) {
code_r0x000180028000:
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            iVar4 = (*pcVar2)();
            return iVar4;
        }
        iVar4 = fcn.180459890();
        if (iVar4 != 0) {
            uVar11 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar11 - 8) = iVar4;
            goto code_r0x0001800279fc;
        }
code_r0x000180027ff3:
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar13 = (undefined *)((int64_t)&var_94h + 4);
code_r0x000180027ffa:
        *(undefined8 *)(puVar13 + -8) = 0x180027fff;
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        iVar4 = (*pcVar2)();
        return iVar4;
    }
    uVar11 = fcn.180459890(uVar3);
code_r0x0001800279fc:
    fcn.180498030(uVar11, *(int64_t *)arg1, *(int64_t *)(arg1 + 8) - *(int64_t *)arg1);
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        uVar8 = *(int64_t *)(arg1 + 0x10) - iVar4;
        if (0xfff < uVar8) {
            if (0x1f < (iVar4 - *(int64_t *)(iVar4 + -8)) - 8U) goto code_r0x000180027ff3;
            uVar8 = uVar8 + 0x27;
            iVar4 = *(int64_t *)(iVar4 + -8);
        }
        fcn.180459c3c(iVar4, uVar8);
    }
    *(uint64_t *)arg1 = uVar11;
    *(uint64_t *)(arg1 + 8) = uVar11;
    *(uint64_t *)(arg1 + 0x10) = uVar11 + uVar3;
code_r0x000180027a65:
    func_0x000180029270(arg1, arg2 + 4);
    func_0x000180029270(arg1, arg2 + 5);
    var_20h._0_4_ = 0;
    if (0 < *(int32_t *)(arg2 + 0xa8)) {
        do {
            var_70h = (int64_t)(int32_t)var_20h * 0x10 + *(int64_t *)(arg2 + 0x38);
    // switch table (9 cases) at 0x180028008
            switch(*(undefined4 *)(var_70h + 0xc)) {
            case 0:
                var_18h._0_4_ = (uint32_t)var_18h & 0xffffff00;
                func_0x000180029270(arg1, &var_18h);
                break;
            case 1:
                var_18h._0_4_ = CONCAT31(var_18h._1_3_, *(undefined *)var_70h);
                func_0x000180029270(arg1, &var_18h);
                break;
            case 3:
                func_0x000180029450(arg1, *(undefined8 *)(arg1 + 8), var_70h, 8);
                break;
            case 4:
                func_0x000180029450(arg1, *(undefined8 *)(arg1 + 8), var_70h, 4);
                break;
            case 5:
                uVar3 = 0;
                var_18h._0_4_ = 0;
                do {
                    iVar10 = 0x18;
                    piVar5 = (int32_t *)(var_70h + uVar3 * 4);
                    var_68h = (int64_t)piVar5;
                    do {
                        uVar3 = 0x7fffffffffffffff;
                        puVar9 = *(undefined **)(arg1 + 8);
                        uVar12 = (undefined)(*piVar5 >> ((uint8_t)iVar10 & 0x1f));
                        if (puVar9 == *(undefined **)(arg1 + 0x10)) {
                            iVar4 = *(int64_t *)arg1;
                            puVar13 = auStack_98;
                            if ((int64_t)puVar9 - iVar4 == 0x7fffffffffffffff) goto code_r0x000180027ffa;
                            uVar11 = ((int64_t)puVar9 - iVar4) + 1;
                            uVar8 = (int64_t)*(undefined **)(arg1 + 0x10) - iVar4;
                            if (0x7fffffffffffffff - (uVar8 >> 1) < uVar8) {
                                uVar8 = 0x8000000000000026;
code_r0x000180027bec:
                                iVar6 = fcn.180459890(uVar8);
                                if (iVar6 == 0) goto code_r0x000180027ff3;
                                puVar13 = (undefined *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                                *(int64_t *)(puVar13 + -8) = iVar6;
                            } else {
                                uVar8 = (uVar8 >> 1) + uVar8;
                                uVar3 = uVar11;
                                if (uVar11 <= uVar8) {
                                    uVar3 = uVar8;
                                }
                                if (uVar3 == 0) {
                                    puVar13 = (undefined *)0x0;
                                } else {
                                    if (0xfff < uVar3) {
                                        uVar8 = uVar3 + 0x27;
                                        if (uVar3 < uVar8) goto code_r0x000180027bec;
                                        goto code_r0x000180028000;
                                    }
                                    puVar13 = (undefined *)fcn.180459890(uVar3);
                                }
                            }
                            puVar13[(int64_t)puVar9 - iVar4] = uVar12;
                            puVar1 = *(undefined **)arg1;
                            if (puVar9 == *(undefined **)(arg1 + 8)) {
                                iVar6 = (int64_t)*(undefined **)(arg1 + 8) - (int64_t)puVar1;
                                puVar7 = puVar13;
                                puVar9 = puVar1;
                            } else {
                                fcn.180498030(puVar13, puVar1, (int64_t)puVar9 - (int64_t)puVar1);
                                iVar6 = *(int64_t *)(arg1 + 8) - (int64_t)puVar9;
                                puVar7 = puVar13 + ((int64_t)puVar9 - iVar4) + 1;
                            }
                            fcn.180498030(puVar7, puVar9, iVar6);
                            func_0x00018002a1f0(arg1, puVar13, uVar11, uVar3);
                            piVar5 = (int32_t *)var_68h;
                        } else {
                            *puVar9 = uVar12;
                            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 1;
                        }
                        iVar10 = iVar10 + -8;
                    } while (-1 < iVar10);
                    var_18h._0_4_ = (uint32_t)var_18h + 1;
                    uVar3 = (uint64_t)(uint32_t)var_18h;
                } while ((int32_t)(uint32_t)var_18h < 2);
                iVar10 = 0x18;
                iVar4 = var_70h;
                do {
                    puVar9 = *(undefined **)(arg1 + 8);
                    uVar12 = (undefined)(*(int32_t *)(iVar4 + 8) >> ((uint8_t)iVar10 & 0x1f));
                    if (puVar9 == *(undefined **)(arg1 + 0x10)) {
                        iVar4 = *(int64_t *)arg1;
                        puVar13 = auStack_98;
                        if ((int64_t)puVar9 - iVar4 == 0x7fffffffffffffff) goto code_r0x000180027ffa;
                        uVar3 = ((int64_t)puVar9 - iVar4) + 1;
                        uVar11 = (int64_t)*(undefined **)(arg1 + 0x10) - iVar4;
                        if (0x7fffffffffffffff - (uVar11 >> 1) < uVar11) {
                            uVar8 = 0x7fffffffffffffff;
                            uVar11 = 0x8000000000000026;
code_r0x000180027d3a:
                            iVar6 = fcn.180459890(uVar11);
                            if (iVar6 == 0) goto code_r0x000180027ff3;
                            puVar13 = (undefined *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                            *(int64_t *)(puVar13 + -8) = iVar6;
                        } else {
                            uVar11 = (uVar11 >> 1) + uVar11;
                            uVar8 = uVar3;
                            if (uVar3 <= uVar11) {
                                uVar8 = uVar11;
                            }
                            if (uVar8 == 0) {
                                puVar13 = (undefined *)0x0;
                            } else {
                                if (0xfff < uVar8) {
                                    uVar11 = uVar8 + 0x27;
                                    if (uVar8 < uVar11) goto code_r0x000180027d3a;
                                    goto code_r0x000180028000;
                                }
                                puVar13 = (undefined *)fcn.180459890(uVar8);
                            }
                        }
                        puVar13[(int64_t)puVar9 - iVar4] = uVar12;
                        puVar1 = *(undefined **)arg1;
                        if (puVar9 == *(undefined **)(arg1 + 8)) {
                            iVar6 = (int64_t)*(undefined **)(arg1 + 8) - (int64_t)puVar1;
                            puVar7 = puVar13;
                            puVar9 = puVar1;
                        } else {
                            fcn.180498030(puVar13, puVar1, (int64_t)puVar9 - (int64_t)puVar1);
                            iVar6 = *(int64_t *)(arg1 + 8) - (int64_t)puVar9;
                            puVar7 = puVar13 + ((int64_t)puVar9 - iVar4) + 1;
                        }
                        fcn.180498030(puVar7, puVar9, iVar6);
                        func_0x00018002a1f0(arg1, puVar13, uVar3, uVar8);
                        iVar4 = var_70h;
                    } else {
                        *puVar9 = uVar12;
                        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 1;
                    }
                    iVar10 = iVar10 + -8;
                } while (-1 < iVar10);
                break;
            case 6:
                iVar4 = *(int64_t *)var_70h;
                func_0x000180029450(arg1, *(undefined8 *)(arg1 + 8), iVar4 + 0x18, 
                                    iVar4 + 0x18 + ((uint64_t)*(uint32_t *)(iVar4 + 0x14) - (iVar4 + 0x18)));
                break;
            case 7:
                iVar4 = *(int64_t *)var_70h;
                if ((*(int64_t *)(iVar4 + 0x28) != 0x180782410) &&
                   (iVar10 = 0, 0 < 1 << (*(uint8_t *)(iVar4 + 7) & 0x1f))) {
                    do {
                        if (((uint8_t)*(undefined4 *)((int64_t)iVar10 * 0x20 + 0x1c + *(int64_t *)(iVar4 + 0x28)) & 0xf)
                            == 6) {
                            iVar6 = *(int64_t *)((int64_t)iVar10 * 0x20 + 0x10 + *(int64_t *)(iVar4 + 0x28));
                            func_0x000180029450(arg1, *(undefined8 *)(arg1 + 8), iVar6 + 0x18, 
                                                iVar6 + 0x18 + ((uint64_t)*(uint32_t *)(iVar6 + 0x14) - (iVar6 + 0x18)))
                            ;
                        }
                        iVar10 = iVar10 + 1;
                    } while (iVar10 < 1 << (*(uint8_t *)(iVar4 + 7) & 0x1f));
                }
                break;
            case 8:
                if (*(char *)(*(int64_t *)var_70h + 3) == '\0') {
                    fcn.180027960((int64_t)&var_60h, *(int64_t *)(*(int64_t *)var_70h + 0x20), var_68h, var_60h, 
                                  in_stack_ffffffffffffffb8, unaff_retaddr, arg1);
                    func_0x000180029450(arg1, *(undefined8 *)(arg1 + 8), var_60h, var_58h - var_60h);
                    if (var_60h != 0) {
                        uVar3 = var_50h - var_60h;
                        iVar4 = var_60h;
                        if (0xfff < uVar3) {
                            if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180027ff3;
                            uVar3 = uVar3 + 0x27;
                            iVar4 = *(int64_t *)(var_60h + -8);
                        }
                        fcn.180459c3c(iVar4, uVar3);
                    }
                } else {
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, 0x43);
                    func_0x000180029270(arg1, &var_18h);
                }
            }
            var_20h._0_4_ = (int32_t)var_20h + 1;
        } while ((int32_t)var_20h < *(int32_t *)(arg2 + 0xa8));
    }
    iVar10 = 0;
    if (0 < *(int32_t *)(arg2 + 0xa0)) {
        do {
            fcn.180027960((int64_t)&var_60h, *(int64_t *)(*(int64_t *)(arg2 + 0x58) + (int64_t)iVar10 * 8), var_68h, 
                          var_60h, in_stack_ffffffffffffffb8, unaff_retaddr, arg1);
            func_0x000180029450(arg1, *(undefined8 *)(arg1 + 8), var_60h, var_58h - var_60h);
            if (var_60h != 0) {
                uVar3 = var_50h - var_60h;
                iVar4 = var_60h;
                if (0xfff < uVar3) {
                    if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180027ff3;
                    uVar3 = uVar3 + 0x27;
                    iVar4 = *(int64_t *)(var_60h + -8);
                }
                fcn.180459c3c(iVar4, uVar3);
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg2 + 0xa0));
    }
    func_0x000180029450(arg1, *(undefined8 *)(arg1 + 8), *(undefined8 *)(arg2 + 0x40), 
                        (int64_t)*(int32_t *)(arg2 + 0x9c) << 2);
    return arg1;
}

// ============================================================
// Function: FUN_180028030
// Address: 0x180028030
// Size: 532 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h
// WARNING: [rz-ghidra] Detected overlap for variable arg_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_93h

void fcn.180028030(int64_t arg1)
{
    code *pcVar1;
    undefined auVar2 [16];
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined *puVar7;
    int64_t unaff_RBP;
    int64_t var_10h;
    undefined8 uStackY_b0;
    undefined auStackY_a8 [8];
    undefined auStackY_a0 [24];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t in_stack_ffffffffffffff90;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    puVar7 = auStackY_a8;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_a8;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar3 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 8)) {
        fcn.180088470(arg1, 1, 8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar6 + 3) == '\0') {
        fcn.180027960((int64_t)&var_88h, *(int64_t *)(*piVar6 + 0x20), var_78h, in_stack_ffffffffffffff90, var_58h, 
                      in_stack_fffffffffffffff0, unaff_RBP);
        _var_58h = ZEXT816(0);
        var_48h = 0;
        var_40h = 0;
        fcn.180004830(&var_58h, var_88h, var_80h - var_88h);
        func_0x00018007ff90();
        uVar4 = func_0x00018020e890();
        var_68h = (int64_t)&var_58h;
        if (0xf < (uint64_t)var_40h) {
            var_68h = var_58h;
        }
        var_60h = var_48h;
        func_0x000180081030(var_48h, &var_38h, &var_68h, uVar4);
        piVar6 = &var_38h;
        if (0xf < (uint64_t)var_20h) {
            piVar6 = (int64_t *)var_38h;
        }
        func_0x0001800867f0(arg1, piVar6, var_28h);
        if (0xf < (uint64_t)var_20h) {
            iVar5 = var_38h;
            puVar7 = auStackY_a8;
            if ((0xfff < var_20h + 1U) &&
               (iVar5 = *(int64_t *)(var_38h + -8), puVar7 = auStackY_a8, 0x1f < (var_38h - iVar5) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar5 = (*pcVar1)(5);
                puVar7 = auStackY_a0;
            }
            *(undefined8 *)(puVar7 + -8) = 0x180028165;
            fcn.180459c3c(iVar5);
        }
        if (0xf < (uint64_t)var_40h) {
            iVar5 = var_58h;
            if ((0xfff < var_40h + 1U) && (iVar5 = *(int64_t *)(var_58h + -8), 0x1f < (var_58h - iVar5) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar5 = (*pcVar1)(5);
                puVar7 = puVar7 + 8;
            }
            *(undefined8 *)(puVar7 + -8) = 0x1800281a6;
            fcn.180459c3c(iVar5);
        }
        var_48h = 0;
        var_40h = 0xf;
        auVar2[15] = 0;
        auVar2._0_15_ = stack0xffffffffffffffa9;
        _var_58h = auVar2 << 8;
        if (var_88h != 0) {
            iVar5 = var_88h;
            if ((0xfff < (uint64_t)(var_78h - var_88h)) &&
               (iVar5 = *(int64_t *)(var_88h + -8), 0x1f < (var_88h - iVar5) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar5 = (*pcVar1)(5);
                puVar7 = puVar7 + 8;
            }
            *(undefined8 *)(puVar7 + -8) = 0x1800281f9;
            fcn.180459c3c(iVar5);
        }
        *(undefined8 *)(puVar7 + -8) = 0x18002820a;
        fcn.180459870(var_18h ^ (uint64_t)puVar7);
        return;
    }
    func_0x000180088380(arg1, 1, 0x180621bb0);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180028250
// Address: 0x180028250
// Size: 1737 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h

void fcn.180028250(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    func_0x000180018f70();
    fcn.180023f30(arg2, 0x180782490, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    fcn.180023f30(arg2, 0x180782460, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    fcn.180023f30(arg2, 0x180782478, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    fcn.180023f30(arg2, 0x180782468, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621c10);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621c00);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621c30);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621c20);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621c50);
    var_58h = 0x180621c40;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_50h = 0x180621c78;
    fcn.1800869f0(0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621c60);
    piVar4 = &var_58h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621c60);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_48h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_78h = 0x180621ca0;
    fcn.1800869f0(0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621c88);
    piVar4 = &var_78h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621c88);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_70h);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621cc8);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_70h = 0x180621cb0;
    fcn.1800869f0(0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621cf0);
    piVar4 = &var_70h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621cf0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_68h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_68h = 0x180621cd8;
    fcn.1800869f0(0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621d10);
    piVar4 = &var_68h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621d10);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_60h);
    var_48h = 0x180621d00;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_40h = 0x180621d30;
    fcn.1800869f0(0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621d20);
    piVar4 = &var_48h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621d20);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_38h);
    var_38h = 0x180621d50;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_30h = 0x180621d40;
    fcn.1800869f0(0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621d70);
    piVar4 = &var_38h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621d70);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != (int64_t *)&stack0xffffffffffffffd8);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621d60);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621d90);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621d80);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_60h = 0x180621db0;
    fcn.1800869f0(0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621da0);
    piVar4 = &var_60h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621da0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_58h);
    return;
}

// ============================================================
// Function: FUN_180028920
// Address: 0x180028920
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028920(void)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    fcn.18001c190(0x1807820c0);
    ppiVar4 = *(int64_t ***)0x18077af88;
    if (*(uint64_t *)0x18077af90 != 0) {
        if (*(uint64_t *)0x18077af90 < *(uint64_t *)0x18077afb8 >> 3) {
            ppiVar2 = (int64_t **)**(int64_t ***)0x18077af88;
            if (ppiVar2 != *(int64_t ***)0x18077af88) {
                ppiVar3 = (int64_t **)ppiVar2[1];
                iStackX_18 = *(int64_t *)0x18077af98;
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar2 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar2 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar2 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar2 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar2 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar2 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar2 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar2 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x18077afb0) *
                        0x10;
                var_8h = *(int64_t *)(iVar6 + *(int64_t *)0x18077af98);
                ppiVar1 = (int64_t **)(iVar6 + *(int64_t *)0x18077af98);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + *(int64_t *)0x18077af98);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(uint64_t *)0x18077af90 = *(uint64_t *)0x18077af90 - 1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar3;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *ppiVar1 = (int64_t *)ppiVar4;
                            ppiVar5 = ppiVar4;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar4) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)0x18077afb0;
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar2 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(uint64_t *)0x18077af90 = *(uint64_t *)0x18077af90 - 1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar4) {
                                    *ppiVar2 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar4;
                            *(int64_t ***)(iVar6 + 8) = ppiVar4;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar4);
                if ((int64_t **)var_8h == ppiVar2) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar3 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar3;
                return;
            }
        } else {
            *(*(int64_t ***)0x18077af88)[1] = 0;
            ppiVar4 = (int64_t **)*ppiVar4;
            while (ppiVar4 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar4;
                fcn.180459c3c(ppiVar4, 0x18);
                ppiVar4 = ppiVar2;
            }
            **(int64_t ***)0x18077af88 = (int64_t *)*(int64_t ***)0x18077af88;
            (*(int64_t ***)0x18077af88)[1] = (int64_t *)*(int64_t ***)0x18077af88;
            *(uint64_t *)0x18077af90 = 0;
            var_8h = (int64_t)*(int64_t ***)0x18077af88;
            fcn.18000d540(*(int64_t *)0x18077af98, *(undefined8 *)0x18077afa0, &var_8h);
        }
    }
    return;
}

