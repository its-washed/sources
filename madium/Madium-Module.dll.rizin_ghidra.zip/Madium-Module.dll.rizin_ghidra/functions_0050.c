// Chunk 50 - 50 functions

// ============================================================
// Function: FUN_18009f929
// Address: 0x18009f929
// Size: 984 bytes
// ============================================================
void fcn.18009f929(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_a0h, int64_t arg_a8h,
                  int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h)
{
    char cVar1;
    undefined uVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t in_RAX;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    char *unaff_RBX;
    int64_t unaff_RBP;
    int32_t iVar11;
    uint32_t uVar12;
    int64_t unaff_RDI;
    undefined *puVar13;
    undefined *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined4 in_XMM0_Da;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    undefined4 extraout_XMM0_Da_03;
    undefined4 extraout_XMM0_Da_04;
    undefined4 extraout_XMM0_Da_05;
    undefined4 uVar17;
    double dVar18;
    int64_t var_27h;
    int64_t var_39h;
    int64_t var_31h;
    int64_t var_29h;
    int64_t var_21h;
    int64_t var_11h;
    int64_t var_9h;
    
    uVar3 = *(uint32_t *)(in_RAX + 0x14);
    if ((uint64_t)arg4 <= (uint64_t)arg1) {
        arg1 = arg3;
    }
    *(uint64_t *)(unaff_RBP + -9) = (uint64_t)uVar3;
    if ((arg1 == arg3) || (*(int32_t *)(arg1 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = func_0x000180088860(in_XMM0_Da, 3);
        if (iVar5 < 0) {
            iVar5 = iVar5 + 1 + uVar3;
        }
    }
    iVar6 = 0;
    if (-1 < iVar5) {
        iVar6 = iVar5;
    }
    uVar12 = 0;
    if (-1 < (int32_t)(iVar6 - 1U)) {
        uVar12 = iVar6 - 1U;
    }
    if ((uint64_t)uVar3 < (uint64_t)(int64_t)(int32_t)uVar12) {
        func_0x000180088380();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    *(int64_t *)(unaff_RBP + -0x29) = unaff_RDI;
    *(undefined4 *)(unaff_RBP + -0x21) = 1;
    *(undefined4 *)(unaff_RBP + -0x1d) = 1;
    cVar1 = *unaff_RBX;
    iVar5 = 0;
    while( true ) {
        if (cVar1 == '\0') {
            func_0x0001800865e0();
            func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x27) ^ (uint64_t)&stack0x00000000);
            return;
        }
        iVar6 = func_0x00018009e550(unaff_RBP + -0x29, unaff_RBP + -0x19, unaff_RBP + -0x11);
        uVar3 = *(uint32_t *)(unaff_RBP + -0x11);
        iVar15 = (int64_t)(int32_t)uVar3;
        *(uint32_t *)(unaff_RBP + -0x39) = uVar3;
        uVar17 = extraout_XMM0_Da;
        uVar10 = uVar3;
        if ((iVar6 == 7) &&
           (((**(char **)(unaff_RBP + -0x19) == '\0' ||
             (iVar7 = func_0x00018009e550(unaff_RBP + -0x29, unaff_RBP + -0x19, unaff_RBP + -0x39), iVar7 == 3)) ||
            (uVar10 = *(uint32_t *)(unaff_RBP + -0x39), uVar17 = extraout_XMM0_Da_00, uVar10 == 0)))) {
            func_0x000180088380(*(undefined8 *)(unaff_RBP + -0x29), 1, 0x18063e8f8);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if (((int32_t)uVar10 < 2) || (iVar6 == 3)) {
            uVar9 = 0;
        } else {
            if (*(int32_t *)(unaff_RBP + -0x1d) < (int32_t)uVar10) {
                uVar10 = *(uint32_t *)(unaff_RBP + -0x1d);
            }
            uVar9 = uVar10 - 1;
            if ((uVar10 & uVar9) != 0) {
                func_0x000180088380(*(undefined8 *)(unaff_RBP + -0x29), 1, 0x18063e8c8);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar9 = uVar10 - (uVar9 & uVar12) & uVar9;
        }
        if ((uint64_t)(*(int64_t *)(unaff_RBP + -9) - (int64_t)(int32_t)uVar12) < (uint64_t)((int32_t)uVar9 + iVar15))
        break;
        if (8000 < (*(int64_t *)(unaff_RDI + 0x40) - *(int64_t *)(unaff_RDI + 0x28) >> 4) + 2) {
code_r0x00018009fd7c:
            func_0x000180088560(uVar17, 0x18063da38, 0x18063e998);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if (*(int64_t *)(unaff_RDI + 0x30) - *(int64_t *)(unaff_RDI + 0x40) < 0x21) {
            *(undefined4 *)(unaff_RBP + -0x39) = 2;
            iVar7 = func_0x000180093190(uVar17, 0x1800855e0, unaff_RBP + -0x39);
            uVar17 = extraout_XMM0_Da_01;
            if (iVar7 != 0) goto code_r0x00018009fd7c;
        }
        uVar8 = *(int64_t *)(unaff_RDI + 0x40) + 0x20;
        if (**(uint64_t **)(unaff_RDI + 0x18) < uVar8) {
            **(uint64_t **)(unaff_RDI + 0x18) = uVar8;
        }
        iVar11 = uVar12 + uVar9;
        iVar7 = iVar5 + 1;
    // switch table (9 cases) at 0x18009fda8
        switch(iVar6) {
        case 0:
            iVar15 = func_0x00018009f6d0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), 
                                         *(undefined4 *)(unaff_RBP + -0x21), uVar3, 1);
            func_0x000180086570(extraout_XMM0_Da_02, (double)iVar15);
            break;
        case 1:
            uVar8 = func_0x00018009f6d0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), 
                                        *(undefined4 *)(unaff_RBP + -0x21), uVar3, 0);
            if ((int64_t)uVar8 < 0) {
                dVar18 = (double)(uVar8 >> 1 | (uint64_t)((uint32_t)uVar8 & 1));
                func_0x000180086570(extraout_XMM0_Da_03, dVar18 + dVar18);
            } else {
                func_0x000180086570(extraout_XMM0_Da_03, (double)uVar8);
            }
            break;
        case 2:
            puVar13 = (undefined *)((int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31));
            if (*(int32_t *)(unaff_RBP + -0x21) == 1) {
                puVar14 = (undefined *)(unaff_RBP + -1);
                for (uVar12 = uVar3; uVar12 != 0; uVar12 = uVar12 - 1) {
                    uVar2 = *puVar13;
                    puVar13 = puVar13 + 1;
                    *puVar14 = uVar2;
                    puVar14 = puVar14 + 1;
                }
            } else {
                puVar14 = (undefined *)(unaff_RBP + -1 + (int64_t)(int32_t)(uVar3 - 1));
                for (uVar12 = uVar3; uVar12 != 0; uVar12 = uVar12 - 1) {
                    uVar2 = *puVar13;
                    puVar13 = puVar13 + 1;
                    *puVar14 = uVar2;
                    puVar14 = puVar14 + -1;
                }
            }
            if (uVar3 == 4) {
                func_0x000180086570(*(float *)(unaff_RBP + -1), (double)*(float *)(unaff_RBP + -1));
            } else {
                func_0x000180086570(uVar17, *(undefined8 *)(unaff_RBP + -1));
            }
            break;
        case 3:
            func_0x0001800867f0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), iVar15);
            break;
        case 4:
            iVar16 = (int64_t)iVar11;
            uVar8 = func_0x00018009f6d0(uVar17, *(int64_t *)(unaff_RBP + -0x31) + iVar16, 
                                        *(undefined4 *)(unaff_RBP + -0x21), uVar3, 0);
            uVar17 = extraout_XMM0_Da_04;
            if ((uint64_t)((*(int64_t *)(unaff_RBP + -9) - iVar16) - iVar15) < uVar8) goto code_r0x00018009fd93;
            func_0x0001800867f0(extraout_XMM0_Da_04, *(int64_t *)(unaff_RBP + -0x31) + iVar16 + iVar15, uVar8);
            iVar11 = iVar11 + (int32_t)uVar8;
            break;
        case 5:
            iVar16 = *(int64_t *)(unaff_RBP + -0x31) + (int64_t)iVar11;
            iVar15 = func_0x000180498cd0(iVar16, iVar5);
            if (*(uint64_t *)(unaff_RBP + -9) <= (uint64_t)(iVar11 + iVar15)) {
                func_0x000180088380(extraout_XMM0_Da_05, 2, 0x18063ea28);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            func_0x0001800867f0(extraout_XMM0_Da_05, iVar16, iVar15);
            iVar11 = iVar11 + 1 + (int32_t)iVar15;
            break;
        case 6:
        case 7:
        case 8:
            iVar7 = iVar5;
        }
        uVar12 = iVar11 + uVar3;
        cVar1 = **(char **)(unaff_RBP + -0x19);
        iVar5 = iVar7;
    }
code_r0x00018009fd93:
    func_0x000180088380(uVar17, 2, 0x18063e9b0);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18009fd01
// Address: 0x18009fd01
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_d8h
// WARNING: Variable defined which should be unmapped: arg_e0h
// WARNING: Variable defined which should be unmapped: arg_e8h
// WARNING: Variable defined which should be unmapped: arg_a8h
// WARNING: Variable defined which should be unmapped: arg_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.18009f929(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_a0h, int64_t arg_a8h,
                  int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h)
{
    char cVar1;
    undefined uVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t in_RAX;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    char *unaff_RBX;
    int64_t unaff_RBP;
    int32_t iVar11;
    uint32_t uVar12;
    int64_t unaff_RDI;
    undefined *puVar13;
    undefined *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined4 in_XMM0_Da;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    undefined4 extraout_XMM0_Da_03;
    undefined4 extraout_XMM0_Da_04;
    undefined4 extraout_XMM0_Da_05;
    undefined4 uVar17;
    double dVar18;
    int64_t var_27h;
    int64_t var_39h;
    int64_t var_31h;
    int64_t var_29h;
    int64_t var_21h;
    int64_t var_11h;
    int64_t var_9h;
    
    uVar3 = *(uint32_t *)(in_RAX + 0x14);
    if ((uint64_t)arg4 <= (uint64_t)arg1) {
        arg1 = arg3;
    }
    *(uint64_t *)(unaff_RBP + -9) = (uint64_t)uVar3;
    if ((arg1 == arg3) || (*(int32_t *)(arg1 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = func_0x000180088860(in_XMM0_Da, 3);
        if (iVar5 < 0) {
            iVar5 = iVar5 + 1 + uVar3;
        }
    }
    iVar6 = 0;
    if (-1 < iVar5) {
        iVar6 = iVar5;
    }
    uVar12 = 0;
    if (-1 < (int32_t)(iVar6 - 1U)) {
        uVar12 = iVar6 - 1U;
    }
    if ((uint64_t)uVar3 < (uint64_t)(int64_t)(int32_t)uVar12) {
        func_0x000180088380();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    *(int64_t *)(unaff_RBP + -0x29) = unaff_RDI;
    *(undefined4 *)(unaff_RBP + -0x21) = 1;
    *(undefined4 *)(unaff_RBP + -0x1d) = 1;
    cVar1 = *unaff_RBX;
    iVar5 = 0;
    while( true ) {
        if (cVar1 == '\0') {
            func_0x0001800865e0();
            func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x27) ^ (uint64_t)&stack0x00000000);
            return;
        }
        iVar6 = func_0x00018009e550(unaff_RBP + -0x29, unaff_RBP + -0x19, unaff_RBP + -0x11);
        uVar3 = *(uint32_t *)(unaff_RBP + -0x11);
        iVar15 = (int64_t)(int32_t)uVar3;
        *(uint32_t *)(unaff_RBP + -0x39) = uVar3;
        uVar17 = extraout_XMM0_Da;
        uVar10 = uVar3;
        if ((iVar6 == 7) &&
           (((**(char **)(unaff_RBP + -0x19) == '\0' ||
             (iVar7 = func_0x00018009e550(unaff_RBP + -0x29, unaff_RBP + -0x19, unaff_RBP + -0x39), iVar7 == 3)) ||
            (uVar10 = *(uint32_t *)(unaff_RBP + -0x39), uVar17 = extraout_XMM0_Da_00, uVar10 == 0)))) {
            func_0x000180088380(*(undefined8 *)(unaff_RBP + -0x29), 1, 0x18063e8f8);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if (((int32_t)uVar10 < 2) || (iVar6 == 3)) {
            uVar9 = 0;
        } else {
            if (*(int32_t *)(unaff_RBP + -0x1d) < (int32_t)uVar10) {
                uVar10 = *(uint32_t *)(unaff_RBP + -0x1d);
            }
            uVar9 = uVar10 - 1;
            if ((uVar10 & uVar9) != 0) {
                func_0x000180088380(*(undefined8 *)(unaff_RBP + -0x29), 1, 0x18063e8c8);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar9 = uVar10 - (uVar9 & uVar12) & uVar9;
        }
        if ((uint64_t)(*(int64_t *)(unaff_RBP + -9) - (int64_t)(int32_t)uVar12) < (uint64_t)((int32_t)uVar9 + iVar15))
        break;
        if (8000 < (*(int64_t *)(unaff_RDI + 0x40) - *(int64_t *)(unaff_RDI + 0x28) >> 4) + 2) {
code_r0x00018009fd7c:
            func_0x000180088560(uVar17, 0x18063da38, 0x18063e998);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if (*(int64_t *)(unaff_RDI + 0x30) - *(int64_t *)(unaff_RDI + 0x40) < 0x21) {
            *(undefined4 *)(unaff_RBP + -0x39) = 2;
            iVar7 = func_0x000180093190(uVar17, 0x1800855e0, unaff_RBP + -0x39);
            uVar17 = extraout_XMM0_Da_01;
            if (iVar7 != 0) goto code_r0x00018009fd7c;
        }
        uVar8 = *(int64_t *)(unaff_RDI + 0x40) + 0x20;
        if (**(uint64_t **)(unaff_RDI + 0x18) < uVar8) {
            **(uint64_t **)(unaff_RDI + 0x18) = uVar8;
        }
        iVar11 = uVar12 + uVar9;
        iVar7 = iVar5 + 1;
    // switch table (9 cases) at 0x18009fda8
        switch(iVar6) {
        case 0:
            iVar15 = func_0x00018009f6d0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), 
                                         *(undefined4 *)(unaff_RBP + -0x21), uVar3, 1);
            func_0x000180086570(extraout_XMM0_Da_02, (double)iVar15);
            break;
        case 1:
            uVar8 = func_0x00018009f6d0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), 
                                        *(undefined4 *)(unaff_RBP + -0x21), uVar3, 0);
            if ((int64_t)uVar8 < 0) {
                dVar18 = (double)(uVar8 >> 1 | (uint64_t)((uint32_t)uVar8 & 1));
                func_0x000180086570(extraout_XMM0_Da_03, dVar18 + dVar18);
            } else {
                func_0x000180086570(extraout_XMM0_Da_03, (double)uVar8);
            }
            break;
        case 2:
            puVar13 = (undefined *)((int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31));
            if (*(int32_t *)(unaff_RBP + -0x21) == 1) {
                puVar14 = (undefined *)(unaff_RBP + -1);
                for (uVar12 = uVar3; uVar12 != 0; uVar12 = uVar12 - 1) {
                    uVar2 = *puVar13;
                    puVar13 = puVar13 + 1;
                    *puVar14 = uVar2;
                    puVar14 = puVar14 + 1;
                }
            } else {
                puVar14 = (undefined *)(unaff_RBP + -1 + (int64_t)(int32_t)(uVar3 - 1));
                for (uVar12 = uVar3; uVar12 != 0; uVar12 = uVar12 - 1) {
                    uVar2 = *puVar13;
                    puVar13 = puVar13 + 1;
                    *puVar14 = uVar2;
                    puVar14 = puVar14 + -1;
                }
            }
            if (uVar3 == 4) {
                func_0x000180086570(*(float *)(unaff_RBP + -1), (double)*(float *)(unaff_RBP + -1));
            } else {
                func_0x000180086570(uVar17, *(undefined8 *)(unaff_RBP + -1));
            }
            break;
        case 3:
            func_0x0001800867f0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), iVar15);
            break;
        case 4:
            iVar16 = (int64_t)iVar11;
            uVar8 = func_0x00018009f6d0(uVar17, *(int64_t *)(unaff_RBP + -0x31) + iVar16, 
                                        *(undefined4 *)(unaff_RBP + -0x21), uVar3, 0);
            uVar17 = extraout_XMM0_Da_04;
            if ((uint64_t)((*(int64_t *)(unaff_RBP + -9) - iVar16) - iVar15) < uVar8) goto code_r0x00018009fd93;
            func_0x0001800867f0(extraout_XMM0_Da_04, *(int64_t *)(unaff_RBP + -0x31) + iVar16 + iVar15, uVar8);
            iVar11 = iVar11 + (int32_t)uVar8;
            break;
        case 5:
            iVar16 = *(int64_t *)(unaff_RBP + -0x31) + (int64_t)iVar11;
            iVar15 = func_0x000180498cd0(iVar16, iVar5);
            if (*(uint64_t *)(unaff_RBP + -9) <= (uint64_t)(iVar11 + iVar15)) {
                func_0x000180088380(extraout_XMM0_Da_05, 2, 0x18063ea28);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            func_0x0001800867f0(extraout_XMM0_Da_05, iVar16, iVar15);
            iVar11 = iVar11 + 1 + (int32_t)iVar15;
            break;
        case 6:
        case 7:
        case 8:
            iVar7 = iVar5;
        }
        uVar12 = iVar11 + uVar3;
        cVar1 = **(char **)(unaff_RBP + -0x19);
        iVar5 = iVar7;
    }
code_r0x00018009fd93:
    func_0x000180088380(uVar17, 2, 0x18063e9b0);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18009fd16
// Address: 0x18009fd16
// Size: 40 bytes
// ============================================================
void fcn.18009fd16(void)
{
    code *pcVar1;
    
    fcn.180088470();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18009fd3e
// Address: 0x18009fd3e
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_d8h
// WARNING: Variable defined which should be unmapped: arg_e0h
// WARNING: Variable defined which should be unmapped: arg_e8h
// WARNING: Variable defined which should be unmapped: arg_a8h
// WARNING: Variable defined which should be unmapped: arg_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.18009f929(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_a0h, int64_t arg_a8h,
                  int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h)
{
    char cVar1;
    undefined uVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t in_RAX;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    char *unaff_RBX;
    int64_t unaff_RBP;
    int32_t iVar11;
    uint32_t uVar12;
    int64_t unaff_RDI;
    undefined *puVar13;
    undefined *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined4 in_XMM0_Da;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    undefined4 extraout_XMM0_Da_03;
    undefined4 extraout_XMM0_Da_04;
    undefined4 extraout_XMM0_Da_05;
    undefined4 uVar17;
    double dVar18;
    int64_t var_27h;
    int64_t var_39h;
    int64_t var_31h;
    int64_t var_29h;
    int64_t var_21h;
    int64_t var_11h;
    int64_t var_9h;
    
    uVar3 = *(uint32_t *)(in_RAX + 0x14);
    if ((uint64_t)arg4 <= (uint64_t)arg1) {
        arg1 = arg3;
    }
    *(uint64_t *)(unaff_RBP + -9) = (uint64_t)uVar3;
    if ((arg1 == arg3) || (*(int32_t *)(arg1 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = func_0x000180088860(in_XMM0_Da, 3);
        if (iVar5 < 0) {
            iVar5 = iVar5 + 1 + uVar3;
        }
    }
    iVar6 = 0;
    if (-1 < iVar5) {
        iVar6 = iVar5;
    }
    uVar12 = 0;
    if (-1 < (int32_t)(iVar6 - 1U)) {
        uVar12 = iVar6 - 1U;
    }
    if ((uint64_t)uVar3 < (uint64_t)(int64_t)(int32_t)uVar12) {
        func_0x000180088380();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    *(int64_t *)(unaff_RBP + -0x29) = unaff_RDI;
    *(undefined4 *)(unaff_RBP + -0x21) = 1;
    *(undefined4 *)(unaff_RBP + -0x1d) = 1;
    cVar1 = *unaff_RBX;
    iVar5 = 0;
    while( true ) {
        if (cVar1 == '\0') {
            func_0x0001800865e0();
            func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x27) ^ (uint64_t)&stack0x00000000);
            return;
        }
        iVar6 = func_0x00018009e550(unaff_RBP + -0x29, unaff_RBP + -0x19, unaff_RBP + -0x11);
        uVar3 = *(uint32_t *)(unaff_RBP + -0x11);
        iVar15 = (int64_t)(int32_t)uVar3;
        *(uint32_t *)(unaff_RBP + -0x39) = uVar3;
        uVar17 = extraout_XMM0_Da;
        uVar10 = uVar3;
        if ((iVar6 == 7) &&
           (((**(char **)(unaff_RBP + -0x19) == '\0' ||
             (iVar7 = func_0x00018009e550(unaff_RBP + -0x29, unaff_RBP + -0x19, unaff_RBP + -0x39), iVar7 == 3)) ||
            (uVar10 = *(uint32_t *)(unaff_RBP + -0x39), uVar17 = extraout_XMM0_Da_00, uVar10 == 0)))) {
            func_0x000180088380(*(undefined8 *)(unaff_RBP + -0x29), 1, 0x18063e8f8);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if (((int32_t)uVar10 < 2) || (iVar6 == 3)) {
            uVar9 = 0;
        } else {
            if (*(int32_t *)(unaff_RBP + -0x1d) < (int32_t)uVar10) {
                uVar10 = *(uint32_t *)(unaff_RBP + -0x1d);
            }
            uVar9 = uVar10 - 1;
            if ((uVar10 & uVar9) != 0) {
                func_0x000180088380(*(undefined8 *)(unaff_RBP + -0x29), 1, 0x18063e8c8);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar9 = uVar10 - (uVar9 & uVar12) & uVar9;
        }
        if ((uint64_t)(*(int64_t *)(unaff_RBP + -9) - (int64_t)(int32_t)uVar12) < (uint64_t)((int32_t)uVar9 + iVar15))
        break;
        if (8000 < (*(int64_t *)(unaff_RDI + 0x40) - *(int64_t *)(unaff_RDI + 0x28) >> 4) + 2) {
code_r0x00018009fd7c:
            fcn.180088560(uVar17, 0x18063da38, 0x18063e998);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if (*(int64_t *)(unaff_RDI + 0x30) - *(int64_t *)(unaff_RDI + 0x40) < 0x21) {
            *(undefined4 *)(unaff_RBP + -0x39) = 2;
            iVar7 = func_0x000180093190(uVar17, 0x1800855e0, unaff_RBP + -0x39);
            uVar17 = extraout_XMM0_Da_01;
            if (iVar7 != 0) goto code_r0x00018009fd7c;
        }
        uVar8 = *(int64_t *)(unaff_RDI + 0x40) + 0x20;
        if (**(uint64_t **)(unaff_RDI + 0x18) < uVar8) {
            **(uint64_t **)(unaff_RDI + 0x18) = uVar8;
        }
        iVar11 = uVar12 + uVar9;
        iVar7 = iVar5 + 1;
    // switch table (9 cases) at 0x18009fda8
        switch(iVar6) {
        case 0:
            iVar15 = func_0x00018009f6d0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), 
                                         *(undefined4 *)(unaff_RBP + -0x21), uVar3, 1);
            func_0x000180086570(extraout_XMM0_Da_02, (double)iVar15);
            break;
        case 1:
            uVar8 = func_0x00018009f6d0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), 
                                        *(undefined4 *)(unaff_RBP + -0x21), uVar3, 0);
            if ((int64_t)uVar8 < 0) {
                dVar18 = (double)(uVar8 >> 1 | (uint64_t)((uint32_t)uVar8 & 1));
                func_0x000180086570(extraout_XMM0_Da_03, dVar18 + dVar18);
            } else {
                func_0x000180086570(extraout_XMM0_Da_03, (double)uVar8);
            }
            break;
        case 2:
            puVar13 = (undefined *)((int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31));
            if (*(int32_t *)(unaff_RBP + -0x21) == 1) {
                puVar14 = (undefined *)(unaff_RBP + -1);
                for (uVar12 = uVar3; uVar12 != 0; uVar12 = uVar12 - 1) {
                    uVar2 = *puVar13;
                    puVar13 = puVar13 + 1;
                    *puVar14 = uVar2;
                    puVar14 = puVar14 + 1;
                }
            } else {
                puVar14 = (undefined *)(unaff_RBP + -1 + (int64_t)(int32_t)(uVar3 - 1));
                for (uVar12 = uVar3; uVar12 != 0; uVar12 = uVar12 - 1) {
                    uVar2 = *puVar13;
                    puVar13 = puVar13 + 1;
                    *puVar14 = uVar2;
                    puVar14 = puVar14 + -1;
                }
            }
            if (uVar3 == 4) {
                func_0x000180086570(*(float *)(unaff_RBP + -1), (double)*(float *)(unaff_RBP + -1));
            } else {
                func_0x000180086570(uVar17, *(undefined8 *)(unaff_RBP + -1));
            }
            break;
        case 3:
            func_0x0001800867f0(uVar17, (int64_t)iVar11 + *(int64_t *)(unaff_RBP + -0x31), iVar15);
            break;
        case 4:
            iVar16 = (int64_t)iVar11;
            uVar8 = func_0x00018009f6d0(uVar17, *(int64_t *)(unaff_RBP + -0x31) + iVar16, 
                                        *(undefined4 *)(unaff_RBP + -0x21), uVar3, 0);
            uVar17 = extraout_XMM0_Da_04;
            if ((uint64_t)((*(int64_t *)(unaff_RBP + -9) - iVar16) - iVar15) < uVar8) goto code_r0x00018009fd93;
            func_0x0001800867f0(extraout_XMM0_Da_04, *(int64_t *)(unaff_RBP + -0x31) + iVar16 + iVar15, uVar8);
            iVar11 = iVar11 + (int32_t)uVar8;
            break;
        case 5:
            iVar16 = *(int64_t *)(unaff_RBP + -0x31) + (int64_t)iVar11;
            iVar15 = func_0x000180498cd0(iVar16, iVar5);
            if (*(uint64_t *)(unaff_RBP + -9) <= (uint64_t)(iVar11 + iVar15)) {
                func_0x000180088380(extraout_XMM0_Da_05, 2, 0x18063ea28);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            func_0x0001800867f0(extraout_XMM0_Da_05, iVar16, iVar15);
            iVar11 = iVar11 + 1 + (int32_t)iVar15;
            break;
        case 6:
        case 7:
        case 8:
            iVar7 = iVar5;
        }
        uVar12 = iVar11 + uVar3;
        cVar1 = **(char **)(unaff_RBP + -0x19);
        iVar5 = iVar7;
    }
code_r0x00018009fd93:
    func_0x000180088380(uVar17, 2, 0x18063e9b0);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18009fdd0
// Address: 0x18009fdd0
// Size: 715 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.18009fdd0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 *puVar7;
    int32_t iVar8;
    int64_t var_38h;
    
    puVar7 = (undefined8 *)0x180612a60;
    iVar8 = 0;
    piVar2 = (int64_t *)0x180612a60;
    do {
        iVar8 = iVar8 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x180625fe4);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x180625fe4, iVar8);
        if (iVar3 != 0) {
            fcn.180088560(arg1, 0x18063da68, 0x180625fe4);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), iVar8 == 0)) goto code_r0x0001800a0083;
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x180625fe4);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c28c;
    do {
        func_0x0001800869f0(arg1, puVar7[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar7);
        iVar3 = puVar7[2];
        puVar7 = puVar7 + 2;
    } while (iVar3 != 0);
    func_0x000180086fd0(arg1, 0, 1);
    func_0x0001800867f0(arg1, 0x1805aadb1, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar8 = func_0x000180085510(arg1, 1), iVar8 != 0)) {
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-8];
        puVar4[1] = puVar4[-7];
        puVar4[2] = puVar4[-6];
        puVar4[3] = puVar4[-5];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087650(arg1, 0xfffffffe);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar8 = func_0x000180085510(arg1, 1), iVar8 != 0)) {
            puVar4 = *(undefined4 **)(arg1 + 0x40);
            *puVar4 = puVar4[-8];
            puVar4[1] = puVar4[-7];
            puVar4[2] = puVar4[-6];
            puVar4[3] = puVar4[-5];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087370(arg1, 0xfffffffe, 0x1805aae90);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return 1;
        }
    }
code_r0x0001800a0083:
    func_0x000180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar1 = (code *)swi(3);
    uVar5 = (*pcVar1)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800a0280
// Address: 0x1800a0280
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800a0280(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar4 = (int32_t)arg3;
    if (0x4000000 < iVar4) {
        func_0x000180093000(placeholder_0, 0x18063ea68);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)(int64_t)iVar4 < 0x1000000000000000) {
        iVar2 = func_0x0001800988a0(placeholder_0, *(undefined8 *)(arg2 + 0x20), (int64_t)*(int32_t *)(arg2 + 8) << 4, 
                                    (int64_t)iVar4 << 4, *(undefined *)arg2);
        iVar3 = *(int32_t *)(arg2 + 8);
        *(int64_t *)(arg2 + 0x20) = iVar2;
        for (; iVar3 < iVar4; iVar3 = iVar3 + 1) {
            *(undefined4 *)(iVar2 + 0xc + (int64_t)iVar3 * 0x10) = 0;
        }
        *(int32_t *)(arg2 + 8) = iVar4;
        return;
    }
    func_0x000180098420();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800a0320
// Address: 0x1800a0320
// Size: 237 bytes
// ============================================================
void fcn.1800a0320(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t iVar7;
    
    if ((int32_t)arg3 == 0) {
        *(undefined8 *)(arg2 + 0x28) = *(undefined8 *)0x1807823c8;
        iVar5 = 0;
        iVar7 = 0;
    } else {
        iVar5 = -1;
        for (uVar3 = (int32_t)arg3 - 1; 0xff < uVar3; uVar3 = uVar3 >> 8) {
            iVar5 = iVar5 + 8;
        }
        iVar5 = iVar5 + 1 + (uint32_t)*(uint8_t *)((uint64_t)uVar3 + 0x18063e3c0);
        if (0x1a < iVar5) {
            func_0x000180093000(arg1, 0x18063ea68);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar7 = 1 << ((uint8_t)iVar5 & 0x1f);
        if (0x7ffffffffffffff < (uint64_t)(int64_t)iVar7) {
            func_0x000180098420();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar4 = func_0x000180098670(arg1, (int64_t)iVar7 << 5, *(undefined *)arg2);
        *(undefined8 *)(arg2 + 0x28) = uVar4;
        uVar3 = 0;
        if (0 < iVar7) {
            do {
                iVar1 = *(int64_t *)(arg2 + 0x28);
                uVar6 = (uint64_t)uVar3;
                uVar3 = uVar3 + 1;
                *(undefined4 *)(uVar6 * 0x20 + 0x1c + iVar1) = 0;
                *(undefined4 *)(uVar6 * 0x20 + 0xc + iVar1) = 0;
            } while ((int32_t)uVar3 < iVar7);
        }
    }
    *(uint8_t *)(arg2 + 7) = (uint8_t)iVar5;
    *(int32_t *)(arg2 + 0xc) = iVar7;
    *(char *)(arg2 + 3) = ('\x01' << ((uint8_t)iVar5 & 0x1f)) + -1;
    return;
}

// ============================================================
// Function: FUN_1800a0410
// Address: 0x1800a0410
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800a0410(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    uint8_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    int64_t iVar18;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    iVar16 = (int32_t)arg3;
    if ((0x4000000 < iVar16) || (0x4000000 < (int32_t)arg4)) {
        func_0x000180093000(arg1, 0x18063ea68);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_68h._0_1_ = *(uint8_t *)(arg2 + 7);
    iVar3 = *(int64_t *)(arg2 + 0x28);
    iVar17 = *(int32_t *)(arg2 + 8);
    if (iVar17 < iVar16) {
        fcn.1800a0280(arg1, arg2, arg3 & 0xffffffff);
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
    } else {
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
        if (iVar16 < iVar17) {
            *(int32_t *)(arg2 + 8) = iVar16;
            uVar14 = arg3 & 0xffffffff;
            do {
                iVar18 = *(int64_t *)(arg2 + 0x20);
                iVar12 = (int32_t)uVar14;
                uVar8 = iVar12 + 1;
                uVar14 = (uint64_t)uVar8;
                if (*(int32_t *)(iVar18 + 0xc + (int64_t)iVar12 * 0x10) != 0) {
                    var_60h = (int64_t)(double)uVar8;
                    var_58h._4_4_ = 3;
                    puVar10 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                    puVar9 = (undefined4 *)(iVar18 + (int64_t)iVar12 * 0x10);
                    uVar5 = puVar9[1];
                    uVar6 = puVar9[2];
                    uVar7 = puVar9[3];
                    *puVar10 = *puVar9;
                    puVar10[1] = uVar5;
                    puVar10[2] = uVar6;
                    puVar10[3] = uVar7;
                }
            } while ((int32_t)uVar8 < iVar17);
            if (0xfffffffffffffff < (uint64_t)(int64_t)iVar16) {
                func_0x000180098420(arg1);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            var_78h._0_1_ = *(undefined *)arg2;
            uVar11 = func_0x0001800988a0(arg1, *(undefined8 *)(arg2 + 0x20), (int64_t)iVar17 << 4, (int64_t)iVar16 << 4)
            ;
            *(undefined8 *)(arg2 + 0x20) = uVar11;
        }
    }
    iVar17 = 1 << ((uint8_t)var_68h & 0x1f);
    iVar16 = iVar17 + -1;
    if (-1 < iVar16) {
        iVar18 = (int64_t)iVar16;
        do {
            iVar13 = iVar18 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar3) != 0) {
                var_58h._0_4_ = *(undefined4 *)(iVar13 + 0x18 + iVar3);
                var_60h = *(int64_t *)(iVar13 + 0x10 + iVar3);
                var_58h._4_4_ = *(uint32_t *)(iVar13 + 0x1c + iVar3) & 0xf;
                if (((var_58h._4_4_ == 3) && ((double)(int32_t)(double)var_60h == (double)var_60h)) &&
                   (uVar8 = (int32_t)(double)var_60h - 1, uVar8 < *(uint32_t *)(arg2 + 8))) {
                    puVar9 = (undefined4 *)((int64_t)(int32_t)uVar8 * 0x10 + *(int64_t *)(arg2 + 0x20));
                } else {
                    puVar9 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                }
                puVar10 = (undefined4 *)(iVar13 + iVar3);
                uVar5 = puVar10[1];
                uVar6 = puVar10[2];
                uVar7 = puVar10[3];
                *puVar9 = *puVar10;
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
            }
            iVar18 = iVar18 + -1;
            iVar16 = iVar16 + -1;
        } while (-1 < iVar16);
    }
    if (iVar3 != *(int64_t *)0x1807823c8) {
        uVar2 = *(uint8_t *)arg2;
        iVar18 = *(int64_t *)(arg1 + 0x20);
        iVar13 = (int64_t)iVar17;
        iVar15 = iVar13 * 0x20;
        if ((iVar15 - 1U < 0x400) && (-1 < *(char *)(iVar15 + 0x180777990))) {
            func_0x0001800985c0(arg1, (int32_t)*(char *)(iVar15 + 0x180777990), iVar3);
        } else {
            (**(code **)(iVar18 + 0x48))(*(undefined8 *)(iVar18 + 0x50), iVar3, iVar15, 0);
        }
        *(int64_t *)(iVar18 + 0x30) = *(int64_t *)(iVar18 + 0x30) + iVar13 * -0x20;
        piVar1 = (int64_t *)(iVar18 + 0x2c30 + (uint64_t)uVar2 * 8);
        *piVar1 = *piVar1 + iVar13 * -0x20;
    }
    func_0x000180459870(var_50h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_1800a0453
// Address: 0x1800a0453
// Size: 539 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800a0410(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    uint8_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    int64_t iVar18;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    iVar16 = (int32_t)arg3;
    if ((0x4000000 < iVar16) || (0x4000000 < (int32_t)arg4)) {
        func_0x000180093000(arg1, 0x18063ea68);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_68h._0_1_ = *(uint8_t *)(arg2 + 7);
    iVar3 = *(int64_t *)(arg2 + 0x28);
    iVar17 = *(int32_t *)(arg2 + 8);
    if (iVar17 < iVar16) {
        fcn.1800a0280(arg1, arg2, arg3 & 0xffffffff);
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
    } else {
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
        if (iVar16 < iVar17) {
            *(int32_t *)(arg2 + 8) = iVar16;
            uVar14 = arg3 & 0xffffffff;
            do {
                iVar18 = *(int64_t *)(arg2 + 0x20);
                iVar12 = (int32_t)uVar14;
                uVar8 = iVar12 + 1;
                uVar14 = (uint64_t)uVar8;
                if (*(int32_t *)(iVar18 + 0xc + (int64_t)iVar12 * 0x10) != 0) {
                    var_60h = (int64_t)(double)uVar8;
                    var_58h._4_4_ = 3;
                    puVar10 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                    puVar9 = (undefined4 *)(iVar18 + (int64_t)iVar12 * 0x10);
                    uVar5 = puVar9[1];
                    uVar6 = puVar9[2];
                    uVar7 = puVar9[3];
                    *puVar10 = *puVar9;
                    puVar10[1] = uVar5;
                    puVar10[2] = uVar6;
                    puVar10[3] = uVar7;
                }
            } while ((int32_t)uVar8 < iVar17);
            if (0xfffffffffffffff < (uint64_t)(int64_t)iVar16) {
                func_0x000180098420(arg1);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            var_78h._0_1_ = *(undefined *)arg2;
            uVar11 = func_0x0001800988a0(arg1, *(undefined8 *)(arg2 + 0x20), (int64_t)iVar17 << 4, (int64_t)iVar16 << 4)
            ;
            *(undefined8 *)(arg2 + 0x20) = uVar11;
        }
    }
    iVar17 = 1 << ((uint8_t)var_68h & 0x1f);
    iVar16 = iVar17 + -1;
    if (-1 < iVar16) {
        iVar18 = (int64_t)iVar16;
        do {
            iVar13 = iVar18 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar3) != 0) {
                var_58h._0_4_ = *(undefined4 *)(iVar13 + 0x18 + iVar3);
                var_60h = *(int64_t *)(iVar13 + 0x10 + iVar3);
                var_58h._4_4_ = *(uint32_t *)(iVar13 + 0x1c + iVar3) & 0xf;
                if (((var_58h._4_4_ == 3) && ((double)(int32_t)(double)var_60h == (double)var_60h)) &&
                   (uVar8 = (int32_t)(double)var_60h - 1, uVar8 < *(uint32_t *)(arg2 + 8))) {
                    puVar9 = (undefined4 *)((int64_t)(int32_t)uVar8 * 0x10 + *(int64_t *)(arg2 + 0x20));
                } else {
                    puVar9 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                }
                puVar10 = (undefined4 *)(iVar13 + iVar3);
                uVar5 = puVar10[1];
                uVar6 = puVar10[2];
                uVar7 = puVar10[3];
                *puVar9 = *puVar10;
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
            }
            iVar18 = iVar18 + -1;
            iVar16 = iVar16 + -1;
        } while (-1 < iVar16);
    }
    if (iVar3 != *(int64_t *)0x1807823c8) {
        uVar2 = *(uint8_t *)arg2;
        iVar18 = *(int64_t *)(arg1 + 0x20);
        iVar13 = (int64_t)iVar17;
        iVar15 = iVar13 * 0x20;
        if ((iVar15 - 1U < 0x400) && (-1 < *(char *)(iVar15 + 0x180777990))) {
            func_0x0001800985c0(arg1, (int32_t)*(char *)(iVar15 + 0x180777990), iVar3);
        } else {
            (**(code **)(iVar18 + 0x48))(*(undefined8 *)(iVar18 + 0x50), iVar3, iVar15, 0);
        }
        *(int64_t *)(iVar18 + 0x30) = *(int64_t *)(iVar18 + 0x30) + iVar13 * -0x20;
        piVar1 = (int64_t *)(iVar18 + 0x2c30 + (uint64_t)uVar2 * 8);
        *piVar1 = *piVar1 + iVar13 * -0x20;
    }
    func_0x000180459870(var_50h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_1800a066e
// Address: 0x1800a066e
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800a0410(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    uint8_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    int64_t iVar18;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    iVar16 = (int32_t)arg3;
    if ((0x4000000 < iVar16) || (0x4000000 < (int32_t)arg4)) {
        func_0x000180093000(arg1, 0x18063ea68);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_68h._0_1_ = *(uint8_t *)(arg2 + 7);
    iVar3 = *(int64_t *)(arg2 + 0x28);
    iVar17 = *(int32_t *)(arg2 + 8);
    if (iVar17 < iVar16) {
        fcn.1800a0280(arg1, arg2, arg3 & 0xffffffff);
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
    } else {
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
        if (iVar16 < iVar17) {
            *(int32_t *)(arg2 + 8) = iVar16;
            uVar14 = arg3 & 0xffffffff;
            do {
                iVar18 = *(int64_t *)(arg2 + 0x20);
                iVar12 = (int32_t)uVar14;
                uVar8 = iVar12 + 1;
                uVar14 = (uint64_t)uVar8;
                if (*(int32_t *)(iVar18 + 0xc + (int64_t)iVar12 * 0x10) != 0) {
                    var_60h = (int64_t)(double)uVar8;
                    var_58h._4_4_ = 3;
                    puVar10 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                    puVar9 = (undefined4 *)(iVar18 + (int64_t)iVar12 * 0x10);
                    uVar5 = puVar9[1];
                    uVar6 = puVar9[2];
                    uVar7 = puVar9[3];
                    *puVar10 = *puVar9;
                    puVar10[1] = uVar5;
                    puVar10[2] = uVar6;
                    puVar10[3] = uVar7;
                }
            } while ((int32_t)uVar8 < iVar17);
            if (0xfffffffffffffff < (uint64_t)(int64_t)iVar16) {
                func_0x000180098420(arg1);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            var_78h._0_1_ = *(undefined *)arg2;
            uVar11 = func_0x0001800988a0(arg1, *(undefined8 *)(arg2 + 0x20), (int64_t)iVar17 << 4, (int64_t)iVar16 << 4)
            ;
            *(undefined8 *)(arg2 + 0x20) = uVar11;
        }
    }
    iVar17 = 1 << ((uint8_t)var_68h & 0x1f);
    iVar16 = iVar17 + -1;
    if (-1 < iVar16) {
        iVar18 = (int64_t)iVar16;
        do {
            iVar13 = iVar18 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar3) != 0) {
                var_58h._0_4_ = *(undefined4 *)(iVar13 + 0x18 + iVar3);
                var_60h = *(int64_t *)(iVar13 + 0x10 + iVar3);
                var_58h._4_4_ = *(uint32_t *)(iVar13 + 0x1c + iVar3) & 0xf;
                if (((var_58h._4_4_ == 3) && ((double)(int32_t)(double)var_60h == (double)var_60h)) &&
                   (uVar8 = (int32_t)(double)var_60h - 1, uVar8 < *(uint32_t *)(arg2 + 8))) {
                    puVar9 = (undefined4 *)((int64_t)(int32_t)uVar8 * 0x10 + *(int64_t *)(arg2 + 0x20));
                } else {
                    puVar9 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                }
                puVar10 = (undefined4 *)(iVar13 + iVar3);
                uVar5 = puVar10[1];
                uVar6 = puVar10[2];
                uVar7 = puVar10[3];
                *puVar9 = *puVar10;
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
            }
            iVar18 = iVar18 + -1;
            iVar16 = iVar16 + -1;
        } while (-1 < iVar16);
    }
    if (iVar3 != *(int64_t *)0x1807823c8) {
        uVar2 = *(uint8_t *)arg2;
        iVar18 = *(int64_t *)(arg1 + 0x20);
        iVar13 = (int64_t)iVar17;
        iVar15 = iVar13 * 0x20;
        if ((iVar15 - 1U < 0x400) && (-1 < *(char *)(iVar15 + 0x180777990))) {
            func_0x0001800985c0(arg1, (int32_t)*(char *)(iVar15 + 0x180777990), iVar3);
        } else {
            (**(code **)(iVar18 + 0x48))(*(undefined8 *)(iVar18 + 0x50), iVar3, iVar15, 0);
        }
        *(int64_t *)(iVar18 + 0x30) = *(int64_t *)(iVar18 + 0x30) + iVar13 * -0x20;
        piVar1 = (int64_t *)(iVar18 + 0x2c30 + (uint64_t)uVar2 * 8);
        *piVar1 = *piVar1 + iVar13 * -0x20;
    }
    func_0x000180459870(var_50h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_1800a067b
// Address: 0x1800a067b
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800a0410(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    uint8_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    int64_t iVar18;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    iVar16 = (int32_t)arg3;
    if ((0x4000000 < iVar16) || (0x4000000 < (int32_t)arg4)) {
        func_0x000180093000(arg1, 0x18063ea68);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_68h._0_1_ = *(uint8_t *)(arg2 + 7);
    iVar3 = *(int64_t *)(arg2 + 0x28);
    iVar17 = *(int32_t *)(arg2 + 8);
    if (iVar17 < iVar16) {
        fcn.1800a0280(arg1, arg2, arg3 & 0xffffffff);
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
    } else {
        fcn.1800a0320(arg1, arg2, arg4 & 0xffffffff);
        if (iVar16 < iVar17) {
            *(int32_t *)(arg2 + 8) = iVar16;
            uVar14 = arg3 & 0xffffffff;
            do {
                iVar18 = *(int64_t *)(arg2 + 0x20);
                iVar12 = (int32_t)uVar14;
                uVar8 = iVar12 + 1;
                uVar14 = (uint64_t)uVar8;
                if (*(int32_t *)(iVar18 + 0xc + (int64_t)iVar12 * 0x10) != 0) {
                    var_60h = (int64_t)(double)uVar8;
                    var_58h._4_4_ = 3;
                    puVar10 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                    puVar9 = (undefined4 *)(iVar18 + (int64_t)iVar12 * 0x10);
                    uVar5 = puVar9[1];
                    uVar6 = puVar9[2];
                    uVar7 = puVar9[3];
                    *puVar10 = *puVar9;
                    puVar10[1] = uVar5;
                    puVar10[2] = uVar6;
                    puVar10[3] = uVar7;
                }
            } while ((int32_t)uVar8 < iVar17);
            if (0xfffffffffffffff < (uint64_t)(int64_t)iVar16) {
                func_0x000180098420(arg1);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            var_78h._0_1_ = *(undefined *)arg2;
            uVar11 = func_0x0001800988a0(arg1, *(undefined8 *)(arg2 + 0x20), (int64_t)iVar17 << 4, (int64_t)iVar16 << 4)
            ;
            *(undefined8 *)(arg2 + 0x20) = uVar11;
        }
    }
    iVar17 = 1 << ((uint8_t)var_68h & 0x1f);
    iVar16 = iVar17 + -1;
    if (-1 < iVar16) {
        iVar18 = (int64_t)iVar16;
        do {
            iVar13 = iVar18 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar3) != 0) {
                var_58h._0_4_ = *(undefined4 *)(iVar13 + 0x18 + iVar3);
                var_60h = *(int64_t *)(iVar13 + 0x10 + iVar3);
                var_58h._4_4_ = *(uint32_t *)(iVar13 + 0x1c + iVar3) & 0xf;
                if (((var_58h._4_4_ == 3) && ((double)(int32_t)(double)var_60h == (double)var_60h)) &&
                   (uVar8 = (int32_t)(double)var_60h - 1, uVar8 < *(uint32_t *)(arg2 + 8))) {
                    puVar9 = (undefined4 *)((int64_t)(int32_t)uVar8 * 0x10 + *(int64_t *)(arg2 + 0x20));
                } else {
                    puVar9 = (undefined4 *)func_0x0001800a0a80(arg1, arg2, &var_60h);
                }
                puVar10 = (undefined4 *)(iVar13 + iVar3);
                uVar5 = puVar10[1];
                uVar6 = puVar10[2];
                uVar7 = puVar10[3];
                *puVar9 = *puVar10;
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
            }
            iVar18 = iVar18 + -1;
            iVar16 = iVar16 + -1;
        } while (-1 < iVar16);
    }
    if (iVar3 != *(int64_t *)0x1807823c8) {
        uVar2 = *(uint8_t *)arg2;
        iVar18 = *(int64_t *)(arg1 + 0x20);
        iVar13 = (int64_t)iVar17;
        iVar15 = iVar13 * 0x20;
        if ((iVar15 - 1U < 0x400) && (-1 < *(char *)(iVar15 + 0x180777990))) {
            func_0x0001800985c0(arg1, (int32_t)*(char *)(iVar15 + 0x180777990), iVar3);
        } else {
            (**(code **)(iVar18 + 0x48))(*(undefined8 *)(iVar18 + 0x50), iVar3, iVar15, 0);
        }
        *(int64_t *)(iVar18 + 0x30) = *(int64_t *)(iVar18 + 0x30) + iVar13 * -0x20;
        piVar1 = (int64_t *)(iVar18 + 0x2c30 + (uint64_t)uVar2 * 8);
        *piVar1 = *piVar1 + iVar13 * -0x20;
    }
    func_0x000180459870(var_50h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_1800a0690
// Address: 0x1800a0690
// Size: 836 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800a0690(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    double dVar2;
    int32_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    int32_t iVar16;
    uint32_t uVar17;
    int32_t iVar18;
    int64_t var_7h;
    int64_t var_20h;
    undefined auStack_f8 [8];
    int64_t var_f0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    undefined auStack_78 [16];
    undefined auStack_68 [12];
    undefined4 uStack_5c;
    undefined auStack_58 [12];
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar16 = *(int32_t *)(arg2 + 8);
    _var_b8h = ZEXT816(0);
    uVar8 = 1;
    iVar18 = 0;
    _var_a8h = _var_b8h;
    _var_98h = _var_b8h;
    _var_88h = _var_b8h;
    iVar12 = 1;
    auStack_68 = SUB1612(_var_b8h, 0);
    uVar9 = 0;
    uStack_5c = SUB164(_var_b8h, 0);
    uStack_5c = 0;
    auStack_58 = SUB1612(_var_b8h, 4);
    auStack_78 = _var_b8h;
    iVar15 = iVar12;
    do {
        if (iVar16 < iVar15) {
            iVar14 = iVar16;
            if (iVar16 < iVar12) break;
code_r0x0001800a072b:
            iVar13 = 0;
            do {
                iVar6 = iVar13 + 1;
                if (*(int32_t *)(*(int64_t *)(arg2 + 0x20) + -4 + (int64_t)iVar12 * 0x10) == 0) {
                    iVar6 = iVar13;
                }
                iVar12 = iVar12 + 1;
                iVar13 = iVar6;
            } while (iVar12 <= iVar14);
        } else {
            iVar6 = 0;
            iVar14 = iVar15;
            if (iVar12 <= iVar15) goto code_r0x0001800a072b;
        }
        piVar1 = (int32_t *)((int64_t)&var_b8h + uVar9 * 4);
        *piVar1 = *piVar1 + iVar6;
        iVar18 = iVar18 + iVar6;
        uVar11 = (int32_t)uVar9 + 1;
        uVar9 = (uint64_t)uVar11;
        iVar15 = iVar15 * 2;
    } while ((int32_t)uVar11 < 0x1b);
    iVar15 = 1;
    iVar14 = 0;
    iVar12 = 1 << (*(uint8_t *)(arg2 + 7) & 0x1f);
    iVar16 = 0;
    if (iVar12 != 0) {
        iVar5 = *(int64_t *)(arg2 + 0x28);
        do {
            iVar12 = iVar12 + -1;
            iVar7 = (int64_t)iVar12 * 0x20;
            if (*(int32_t *)(iVar7 + 0xc + iVar5) != 0) {
                if (((uint8_t)*(undefined4 *)(iVar7 + 0x1c + iVar5) & 0xf) == 3) {
                    dVar2 = *(double *)(iVar7 + 0x10 + iVar5);
                    iVar6 = (int32_t)dVar2;
                    if (((double)iVar6 == dVar2) && (iVar6 - 1U < 0x4000000)) {
                        uVar11 = iVar6 - 1;
                        iVar6 = -1;
                        uVar9 = (uint64_t)uVar11;
                        while (0xff < uVar11) {
                            iVar6 = iVar6 + 8;
                            uVar11 = (uint32_t)(uVar9 >> 8);
                            uVar9 = uVar9 >> 8;
                        }
                        piVar1 = (int32_t *)
                                 ((int64_t)&var_b8h +
                                 (int64_t)(int32_t)((uint32_t)*(uint8_t *)(uVar9 + 0x18063e3c0) + iVar6) * 4 + 4);
                        *piVar1 = *piVar1 + 1;
                        iVar6 = 1;
                    } else {
                        iVar6 = 0;
                    }
                    iVar16 = iVar16 + iVar6;
                }
                iVar14 = iVar14 + 1;
            }
        } while (iVar12 != 0);
    }
    iVar12 = *(int32_t *)(arg3 + 0xc);
    iVar16 = iVar16 + iVar18;
    if (iVar12 == 3) {
        iVar6 = (int32_t)*(double *)arg3;
        if (((double)iVar6 == *(double *)arg3) && (iVar6 - 1U < 0x4000000)) {
            uVar11 = iVar6 - 1;
            iVar6 = -1;
            uVar9 = (uint64_t)uVar11;
            while (0xff < uVar11) {
                iVar6 = iVar6 + 8;
                uVar11 = (uint32_t)(uVar9 >> 8);
                uVar9 = uVar9 >> 8;
            }
            piVar1 = (int32_t *)
                     ((int64_t)&var_b8h +
                     (int64_t)(int32_t)((uint32_t)*(uint8_t *)(uVar9 + 0x18063e3c0) + iVar6) * 4 + 4);
            *piVar1 = *piVar1 + 1;
        } else {
            iVar15 = 0;
        }
        iVar16 = iVar16 + iVar15;
    }
    iVar6 = 0;
    iVar15 = 0;
    uVar9 = 0;
    iVar13 = 0;
    if (0 < iVar16) {
        do {
            iVar3 = *(int32_t *)((int64_t)&var_b8h + (int64_t)iVar13 * 4);
            if ((0 < iVar3) && (iVar6 = iVar6 + iVar3, (int32_t)uVar8 / 2 < iVar6)) {
                uVar9 = (uint64_t)uVar8;
                iVar15 = iVar6;
            }
            if (iVar6 == iVar16) break;
            uVar8 = uVar8 * 2;
            iVar13 = iVar13 + 1;
        } while ((int32_t)uVar8 / 2 < iVar16);
    }
    iVar5 = *(int64_t *)(arg2 + 0x28);
    uVar11 = (iVar18 + 1 + iVar14) - iVar15;
    uVar8 = (uint32_t)uVar9;
    if ((iVar5 == *(int64_t *)0x1807823c8) && (*(int32_t *)(arg2 + 8) <= (int32_t)uVar8)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    var_d8h = arg2;
    var_d0h = arg3;
    var_c8h = arg1;
    if ((iVar12 != 3) || (uVar10 = (uint32_t)*(double *)arg3, (double)uVar10 != *(double *)arg3)) {
        uVar10 = 0xffffffff;
    }
    while( true ) {
        iVar16 = (int32_t)uVar9;
        uVar17 = iVar16 + 1;
        uVar9 = (uint64_t)uVar17;
        if ((uVar17 != uVar10) &&
           ((!bVar4 || (iVar7 = func_0x0001800a0d50(arg2, uVar17), *(int32_t *)(iVar7 + 0xc) == 0)))) break;
        uVar9 = uVar9 & 0xffffffff;
    }
    iVar7 = var_d8h;
    iVar15 = iVar16 - uVar8;
    if (iVar15 != 0) {
        uVar11 = uVar11 - iVar15;
        uVar9 = (uint64_t)(uint32_t)(iVar16 + iVar15);
        if ((iVar5 == *(int64_t *)0x1807823c8) && (*(int32_t *)(var_d8h + 8) <= iVar16 + iVar15)) {
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        if ((iVar12 != 3) || (uVar10 = (uint32_t)*(double *)var_d0h, (double)uVar10 != *(double *)var_d0h)) {
            uVar10 = 0xffffffff;
        }
        while( true ) {
            uVar8 = (uint32_t)uVar9;
            uVar17 = uVar8 + 1;
            uVar9 = (uint64_t)uVar17;
            if ((uVar17 != uVar10) &&
               ((!bVar4 || (iVar5 = func_0x0001800a0d50(iVar7, uVar17), *(int32_t *)(iVar5 + 0xc) == 0)))) break;
            uVar9 = uVar9 & 0xffffffff;
        }
    }
    fcn.1800a0410(var_c8h, iVar7, (uint64_t)uVar8, (uint64_t)uVar11);
    func_0x000180459870(var_48h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1800a09e0
// Address: 0x1800a09e0
// Size: 147 bytes
// ============================================================
undefined * fcn.1800a09e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    undefined *arg2_00;
    
    arg2_00 = (undefined *)func_0x000180098710(arg1, 0x30, *(undefined *)(arg1 + 4));
    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
    arg2_00[2] = 7;
    arg2_00[1] = uVar1 & 3;
    *arg2_00 = *(undefined *)(arg1 + 4);
    *(undefined8 *)(arg2_00 + 0x10) = 0;
    *(undefined8 *)(arg2_00 + 0x20) = 0;
    *(undefined8 *)(arg2_00 + 8) = 0;
    arg2_00[3] = 0;
    *(undefined8 *)(arg2_00 + 0x28) = *(undefined8 *)0x1807823c8;
    *(undefined4 *)(arg2_00 + 4) = 0xff00;
    if (0 < (int32_t)arg2) {
        fcn.1800a0280(arg1, (int64_t)arg2_00, arg2 & 0xffffffff);
    }
    if (0 < (int32_t)arg3) {
        fcn.1800a0320(arg1, (int64_t)arg2_00, arg3 & 0xffffffff);
    }
    return arg2_00;
}

// ============================================================
// Function: FUN_1800a0a80
// Address: 0x1800a0a80
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a0a80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 in_R9;
    undefined4 *puVar10;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    if ((*(int32_t *)(arg3 + 0xc) == 3) && (*(double *)arg3 == (double)(*(int32_t *)(arg2 + 8) + 1))) {
        fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
        if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
           (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
            fcn.1800a0a80(arg1, arg2, arg3);
        }
    } else {
        puVar4 = (undefined4 *)func_0x0001800a00a0(arg2, arg3);
        if ((puVar4[3] == 0) && (puVar10 = puVar4, puVar4 != *(undefined4 **)0x1807823c8)) {
code_r0x0001800a0cba:
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)arg3;
            puVar10[6] = *(undefined4 *)(arg3 + 8);
            puVar10[7] = puVar10[7] ^ (puVar10[7] ^ *(uint32_t *)(arg3 + 0xc)) & 0xf;
            if (((5 < *(int32_t *)(arg3 + 0xc)) && ((*(uint8_t *)(arg2 + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)arg3 + 1) & 3) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar8 + 0x59) == '\x02') {
                    func_0x000180094420(iVar8);
                } else {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x18) = *(undefined8 *)(iVar8 + 0x18);
                    *(int64_t *)(iVar8 + 0x18) = arg2;
                }
            }
        } else {
            uVar7 = *(uint32_t *)(arg2 + 0xc);
            if (0 < (int32_t)uVar7) {
                iVar8 = *(int64_t *)(arg2 + 0x28) + -0x20;
                do {
                    uVar5 = (uint64_t)uVar7;
                    uVar7 = uVar7 - 1;
                    *(uint32_t *)(arg2 + 0xc) = uVar7;
                    puVar10 = (undefined4 *)(uVar5 * 0x20 + iVar8);
                    if ((*(uint8_t *)(uVar5 * 0x20 + 0x1c + iVar8) & 0xf) == 0) {
                        var_48h = *(int64_t *)(puVar4 + 4);
                        var_40h._0_4_ = puVar4[6];
                        uVar7 = puVar4[7];
                        var_40h._4_4_ = uVar7 & 0xf;
                        puVar6 = (undefined4 *)func_0x0001800a00a0(arg2, &var_48h);
                        if (puVar6 == puVar4) {
                            if ((uVar7 & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] & 0xf;
                                puVar10[7] = puVar10[7] |
                                             (int32_t)((((int64_t)(int32_t)uVar7 >> 4) * 0x20 - (int64_t)puVar10) +
                                                       (int64_t)puVar4 >> 5) << 4;
                            }
                            puVar4[7] = puVar4[7] & 0xf;
                            puVar4[7] = puVar4[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar4 >> 5) << 4;
                        } else {
                            puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            while (puVar9 != puVar4) {
                                puVar6 = puVar6 + ((int64_t)(int32_t)puVar6[7] >> 4) * 8;
                                puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            }
                            puVar6[7] = puVar6[7] & 0xf;
                            puVar6[7] = puVar6[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar6 >> 5) << 4;
                            uVar1 = puVar4[1];
                            uVar2 = puVar4[2];
                            uVar3 = puVar4[3];
                            *puVar10 = *puVar4;
                            puVar10[1] = uVar1;
                            puVar10[2] = uVar2;
                            puVar10[3] = uVar3;
                            uVar1 = puVar4[5];
                            uVar2 = puVar4[6];
                            uVar3 = puVar4[7];
                            puVar10[4] = puVar4[4];
                            puVar10[5] = uVar1;
                            puVar10[6] = uVar2;
                            puVar10[7] = uVar3;
                            if ((puVar4[7] & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] + (int32_t)((int64_t)puVar4 - (int64_t)puVar10 >> 5) * 0x10;
                                puVar4[7] = puVar4[7] & 0xf;
                            }
                            puVar4[3] = 0;
                            puVar10 = puVar4;
                        }
                        goto code_r0x0001800a0cba;
                    }
                } while (0 < (int32_t)uVar7);
            }
            fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
            if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
               (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
                fcn.1800a0a80(arg1, arg2, arg3);
            }
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStackY_68);
    return;
}

// ============================================================
// Function: FUN_1800a0b0c
// Address: 0x1800a0b0c
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a0a80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 in_R9;
    undefined4 *puVar10;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    if ((*(int32_t *)(arg3 + 0xc) == 3) && (*(double *)arg3 == (double)(*(int32_t *)(arg2 + 8) + 1))) {
        fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
        if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
           (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
            fcn.1800a0a80(arg1, arg2, arg3);
        }
    } else {
        puVar4 = (undefined4 *)func_0x0001800a00a0(arg2, arg3);
        if ((puVar4[3] == 0) && (puVar10 = puVar4, puVar4 != *(undefined4 **)0x1807823c8)) {
code_r0x0001800a0cba:
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)arg3;
            puVar10[6] = *(undefined4 *)(arg3 + 8);
            puVar10[7] = puVar10[7] ^ (puVar10[7] ^ *(uint32_t *)(arg3 + 0xc)) & 0xf;
            if (((5 < *(int32_t *)(arg3 + 0xc)) && ((*(uint8_t *)(arg2 + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)arg3 + 1) & 3) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar8 + 0x59) == '\x02') {
                    func_0x000180094420(iVar8);
                } else {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x18) = *(undefined8 *)(iVar8 + 0x18);
                    *(int64_t *)(iVar8 + 0x18) = arg2;
                }
            }
        } else {
            uVar7 = *(uint32_t *)(arg2 + 0xc);
            if (0 < (int32_t)uVar7) {
                iVar8 = *(int64_t *)(arg2 + 0x28) + -0x20;
                do {
                    uVar5 = (uint64_t)uVar7;
                    uVar7 = uVar7 - 1;
                    *(uint32_t *)(arg2 + 0xc) = uVar7;
                    puVar10 = (undefined4 *)(uVar5 * 0x20 + iVar8);
                    if ((*(uint8_t *)(uVar5 * 0x20 + 0x1c + iVar8) & 0xf) == 0) {
                        var_48h = *(int64_t *)(puVar4 + 4);
                        var_40h._0_4_ = puVar4[6];
                        uVar7 = puVar4[7];
                        var_40h._4_4_ = uVar7 & 0xf;
                        puVar6 = (undefined4 *)func_0x0001800a00a0(arg2, &var_48h);
                        if (puVar6 == puVar4) {
                            if ((uVar7 & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] & 0xf;
                                puVar10[7] = puVar10[7] |
                                             (int32_t)((((int64_t)(int32_t)uVar7 >> 4) * 0x20 - (int64_t)puVar10) +
                                                       (int64_t)puVar4 >> 5) << 4;
                            }
                            puVar4[7] = puVar4[7] & 0xf;
                            puVar4[7] = puVar4[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar4 >> 5) << 4;
                        } else {
                            puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            while (puVar9 != puVar4) {
                                puVar6 = puVar6 + ((int64_t)(int32_t)puVar6[7] >> 4) * 8;
                                puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            }
                            puVar6[7] = puVar6[7] & 0xf;
                            puVar6[7] = puVar6[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar6 >> 5) << 4;
                            uVar1 = puVar4[1];
                            uVar2 = puVar4[2];
                            uVar3 = puVar4[3];
                            *puVar10 = *puVar4;
                            puVar10[1] = uVar1;
                            puVar10[2] = uVar2;
                            puVar10[3] = uVar3;
                            uVar1 = puVar4[5];
                            uVar2 = puVar4[6];
                            uVar3 = puVar4[7];
                            puVar10[4] = puVar4[4];
                            puVar10[5] = uVar1;
                            puVar10[6] = uVar2;
                            puVar10[7] = uVar3;
                            if ((puVar4[7] & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] + (int32_t)((int64_t)puVar4 - (int64_t)puVar10 >> 5) * 0x10;
                                puVar4[7] = puVar4[7] & 0xf;
                            }
                            puVar4[3] = 0;
                            puVar10 = puVar4;
                        }
                        goto code_r0x0001800a0cba;
                    }
                } while (0 < (int32_t)uVar7);
            }
            fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
            if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
               (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
                fcn.1800a0a80(arg1, arg2, arg3);
            }
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStackY_68);
    return;
}

// ============================================================
// Function: FUN_1800a0bc2
// Address: 0x1800a0bc2
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a0a80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 in_R9;
    undefined4 *puVar10;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    if ((*(int32_t *)(arg3 + 0xc) == 3) && (*(double *)arg3 == (double)(*(int32_t *)(arg2 + 8) + 1))) {
        fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
        if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
           (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
            fcn.1800a0a80(arg1, arg2, arg3);
        }
    } else {
        puVar4 = (undefined4 *)func_0x0001800a00a0(arg2, arg3);
        if ((puVar4[3] == 0) && (puVar10 = puVar4, puVar4 != *(undefined4 **)0x1807823c8)) {
code_r0x0001800a0cba:
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)arg3;
            puVar10[6] = *(undefined4 *)(arg3 + 8);
            puVar10[7] = puVar10[7] ^ (puVar10[7] ^ *(uint32_t *)(arg3 + 0xc)) & 0xf;
            if (((5 < *(int32_t *)(arg3 + 0xc)) && ((*(uint8_t *)(arg2 + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)arg3 + 1) & 3) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar8 + 0x59) == '\x02') {
                    func_0x000180094420(iVar8);
                } else {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x18) = *(undefined8 *)(iVar8 + 0x18);
                    *(int64_t *)(iVar8 + 0x18) = arg2;
                }
            }
        } else {
            uVar7 = *(uint32_t *)(arg2 + 0xc);
            if (0 < (int32_t)uVar7) {
                iVar8 = *(int64_t *)(arg2 + 0x28) + -0x20;
                do {
                    uVar5 = (uint64_t)uVar7;
                    uVar7 = uVar7 - 1;
                    *(uint32_t *)(arg2 + 0xc) = uVar7;
                    puVar10 = (undefined4 *)(uVar5 * 0x20 + iVar8);
                    if ((*(uint8_t *)(uVar5 * 0x20 + 0x1c + iVar8) & 0xf) == 0) {
                        var_48h = *(int64_t *)(puVar4 + 4);
                        var_40h._0_4_ = puVar4[6];
                        uVar7 = puVar4[7];
                        var_40h._4_4_ = uVar7 & 0xf;
                        puVar6 = (undefined4 *)func_0x0001800a00a0(arg2, &var_48h);
                        if (puVar6 == puVar4) {
                            if ((uVar7 & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] & 0xf;
                                puVar10[7] = puVar10[7] |
                                             (int32_t)((((int64_t)(int32_t)uVar7 >> 4) * 0x20 - (int64_t)puVar10) +
                                                       (int64_t)puVar4 >> 5) << 4;
                            }
                            puVar4[7] = puVar4[7] & 0xf;
                            puVar4[7] = puVar4[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar4 >> 5) << 4;
                        } else {
                            puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            while (puVar9 != puVar4) {
                                puVar6 = puVar6 + ((int64_t)(int32_t)puVar6[7] >> 4) * 8;
                                puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            }
                            puVar6[7] = puVar6[7] & 0xf;
                            puVar6[7] = puVar6[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar6 >> 5) << 4;
                            uVar1 = puVar4[1];
                            uVar2 = puVar4[2];
                            uVar3 = puVar4[3];
                            *puVar10 = *puVar4;
                            puVar10[1] = uVar1;
                            puVar10[2] = uVar2;
                            puVar10[3] = uVar3;
                            uVar1 = puVar4[5];
                            uVar2 = puVar4[6];
                            uVar3 = puVar4[7];
                            puVar10[4] = puVar4[4];
                            puVar10[5] = uVar1;
                            puVar10[6] = uVar2;
                            puVar10[7] = uVar3;
                            if ((puVar4[7] & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] + (int32_t)((int64_t)puVar4 - (int64_t)puVar10 >> 5) * 0x10;
                                puVar4[7] = puVar4[7] & 0xf;
                            }
                            puVar4[3] = 0;
                            puVar10 = puVar4;
                        }
                        goto code_r0x0001800a0cba;
                    }
                } while (0 < (int32_t)uVar7);
            }
            fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
            if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
               (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
                fcn.1800a0a80(arg1, arg2, arg3);
            }
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStackY_68);
    return;
}

// ============================================================
// Function: FUN_1800a0cba
// Address: 0x1800a0cba
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a0a80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 in_R9;
    undefined4 *puVar10;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    if ((*(int32_t *)(arg3 + 0xc) == 3) && (*(double *)arg3 == (double)(*(int32_t *)(arg2 + 8) + 1))) {
        fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
        if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
           (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
            fcn.1800a0a80(arg1, arg2, arg3);
        }
    } else {
        puVar4 = (undefined4 *)func_0x0001800a00a0(arg2, arg3);
        if ((puVar4[3] == 0) && (puVar10 = puVar4, puVar4 != *(undefined4 **)0x1807823c8)) {
code_r0x0001800a0cba:
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)arg3;
            puVar10[6] = *(undefined4 *)(arg3 + 8);
            puVar10[7] = puVar10[7] ^ (puVar10[7] ^ *(uint32_t *)(arg3 + 0xc)) & 0xf;
            if (((5 < *(int32_t *)(arg3 + 0xc)) && ((*(uint8_t *)(arg2 + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)arg3 + 1) & 3) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar8 + 0x59) == '\x02') {
                    func_0x000180094420(iVar8);
                } else {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x18) = *(undefined8 *)(iVar8 + 0x18);
                    *(int64_t *)(iVar8 + 0x18) = arg2;
                }
            }
        } else {
            uVar7 = *(uint32_t *)(arg2 + 0xc);
            if (0 < (int32_t)uVar7) {
                iVar8 = *(int64_t *)(arg2 + 0x28) + -0x20;
                do {
                    uVar5 = (uint64_t)uVar7;
                    uVar7 = uVar7 - 1;
                    *(uint32_t *)(arg2 + 0xc) = uVar7;
                    puVar10 = (undefined4 *)(uVar5 * 0x20 + iVar8);
                    if ((*(uint8_t *)(uVar5 * 0x20 + 0x1c + iVar8) & 0xf) == 0) {
                        var_48h = *(int64_t *)(puVar4 + 4);
                        var_40h._0_4_ = puVar4[6];
                        uVar7 = puVar4[7];
                        var_40h._4_4_ = uVar7 & 0xf;
                        puVar6 = (undefined4 *)func_0x0001800a00a0(arg2, &var_48h);
                        if (puVar6 == puVar4) {
                            if ((uVar7 & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] & 0xf;
                                puVar10[7] = puVar10[7] |
                                             (int32_t)((((int64_t)(int32_t)uVar7 >> 4) * 0x20 - (int64_t)puVar10) +
                                                       (int64_t)puVar4 >> 5) << 4;
                            }
                            puVar4[7] = puVar4[7] & 0xf;
                            puVar4[7] = puVar4[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar4 >> 5) << 4;
                        } else {
                            puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            while (puVar9 != puVar4) {
                                puVar6 = puVar6 + ((int64_t)(int32_t)puVar6[7] >> 4) * 8;
                                puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            }
                            puVar6[7] = puVar6[7] & 0xf;
                            puVar6[7] = puVar6[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar6 >> 5) << 4;
                            uVar1 = puVar4[1];
                            uVar2 = puVar4[2];
                            uVar3 = puVar4[3];
                            *puVar10 = *puVar4;
                            puVar10[1] = uVar1;
                            puVar10[2] = uVar2;
                            puVar10[3] = uVar3;
                            uVar1 = puVar4[5];
                            uVar2 = puVar4[6];
                            uVar3 = puVar4[7];
                            puVar10[4] = puVar4[4];
                            puVar10[5] = uVar1;
                            puVar10[6] = uVar2;
                            puVar10[7] = uVar3;
                            if ((puVar4[7] & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] + (int32_t)((int64_t)puVar4 - (int64_t)puVar10 >> 5) * 0x10;
                                puVar4[7] = puVar4[7] & 0xf;
                            }
                            puVar4[3] = 0;
                            puVar10 = puVar4;
                        }
                        goto code_r0x0001800a0cba;
                    }
                } while (0 < (int32_t)uVar7);
            }
            fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
            if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
               (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
                fcn.1800a0a80(arg1, arg2, arg3);
            }
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStackY_68);
    return;
}

// ============================================================
// Function: FUN_1800a0d2f
// Address: 0x1800a0d2f
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a0a80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 in_R9;
    undefined4 *puVar10;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    if ((*(int32_t *)(arg3 + 0xc) == 3) && (*(double *)arg3 == (double)(*(int32_t *)(arg2 + 8) + 1))) {
        fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
        if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
           (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
            fcn.1800a0a80(arg1, arg2, arg3);
        }
    } else {
        puVar4 = (undefined4 *)func_0x0001800a00a0(arg2, arg3);
        if ((puVar4[3] == 0) && (puVar10 = puVar4, puVar4 != *(undefined4 **)0x1807823c8)) {
code_r0x0001800a0cba:
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)arg3;
            puVar10[6] = *(undefined4 *)(arg3 + 8);
            puVar10[7] = puVar10[7] ^ (puVar10[7] ^ *(uint32_t *)(arg3 + 0xc)) & 0xf;
            if (((5 < *(int32_t *)(arg3 + 0xc)) && ((*(uint8_t *)(arg2 + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)arg3 + 1) & 3) != 0)) {
                iVar8 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar8 + 0x59) == '\x02') {
                    func_0x000180094420(iVar8);
                } else {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x18) = *(undefined8 *)(iVar8 + 0x18);
                    *(int64_t *)(iVar8 + 0x18) = arg2;
                }
            }
        } else {
            uVar7 = *(uint32_t *)(arg2 + 0xc);
            if (0 < (int32_t)uVar7) {
                iVar8 = *(int64_t *)(arg2 + 0x28) + -0x20;
                do {
                    uVar5 = (uint64_t)uVar7;
                    uVar7 = uVar7 - 1;
                    *(uint32_t *)(arg2 + 0xc) = uVar7;
                    puVar10 = (undefined4 *)(uVar5 * 0x20 + iVar8);
                    if ((*(uint8_t *)(uVar5 * 0x20 + 0x1c + iVar8) & 0xf) == 0) {
                        var_48h = *(int64_t *)(puVar4 + 4);
                        var_40h._0_4_ = puVar4[6];
                        uVar7 = puVar4[7];
                        var_40h._4_4_ = uVar7 & 0xf;
                        puVar6 = (undefined4 *)func_0x0001800a00a0(arg2, &var_48h);
                        if (puVar6 == puVar4) {
                            if ((uVar7 & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] & 0xf;
                                puVar10[7] = puVar10[7] |
                                             (int32_t)((((int64_t)(int32_t)uVar7 >> 4) * 0x20 - (int64_t)puVar10) +
                                                       (int64_t)puVar4 >> 5) << 4;
                            }
                            puVar4[7] = puVar4[7] & 0xf;
                            puVar4[7] = puVar4[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar4 >> 5) << 4;
                        } else {
                            puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            while (puVar9 != puVar4) {
                                puVar6 = puVar6 + ((int64_t)(int32_t)puVar6[7] >> 4) * 8;
                                puVar9 = puVar6 + (int64_t)((int32_t)puVar6[7] >> 4) * 8;
                            }
                            puVar6[7] = puVar6[7] & 0xf;
                            puVar6[7] = puVar6[7] | (int32_t)((int64_t)puVar10 - (int64_t)puVar6 >> 5) << 4;
                            uVar1 = puVar4[1];
                            uVar2 = puVar4[2];
                            uVar3 = puVar4[3];
                            *puVar10 = *puVar4;
                            puVar10[1] = uVar1;
                            puVar10[2] = uVar2;
                            puVar10[3] = uVar3;
                            uVar1 = puVar4[5];
                            uVar2 = puVar4[6];
                            uVar3 = puVar4[7];
                            puVar10[4] = puVar4[4];
                            puVar10[5] = uVar1;
                            puVar10[6] = uVar2;
                            puVar10[7] = uVar3;
                            if ((puVar4[7] & 0xfffffff0) != 0) {
                                puVar10[7] = puVar10[7] + (int32_t)((int64_t)puVar4 - (int64_t)puVar10 >> 5) * 0x10;
                                puVar4[7] = puVar4[7] & 0xf;
                            }
                            puVar4[3] = 0;
                            puVar10 = puVar4;
                        }
                        goto code_r0x0001800a0cba;
                    }
                } while (0 < (int32_t)uVar7);
            }
            fcn.1800a0690(arg1, arg2, arg3, in_R9, var_48h);
            if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
               (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
                fcn.1800a0a80(arg1, arg2, arg3);
            }
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStackY_68);
    return;
}

// ============================================================
// Function: FUN_1800a0ea0
// Address: 0x1800a0ea0
// Size: 156 bytes
// ============================================================
int64_t fcn.1800a0ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    double dVar6;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    if (iVar1 != 0) {
        if (iVar1 == 3) {
            iVar1 = (int32_t)*(double *)arg2;
            if ((double)iVar1 == *(double *)arg2) {
                if (iVar1 - 1U < *(uint32_t *)(arg1 + 8)) {
                    return (int64_t)(int32_t)(iVar1 - 1U) * 0x10 + *(int64_t *)(arg1 + 0x20);
                }
                if (*(int64_t *)(arg1 + 0x28) != *(int64_t *)0x1807823c8) {
                    dVar6 = (double)iVar1;
                    uVar4 = (uint32_t)((uint64_t)dVar6 >> 0x20) & 0x7fffffff;
                    uVar5 = (uVar4 >> 0x12 ^ SUB84(dVar6, 0)) * 0x5bd1e995;
                    uVar4 = (uVar5 >> 0x16 ^ uVar4) * 0x5bd1e995;
                    iVar2 = (int64_t)(int32_t)((1 << (*(uint8_t *)(arg1 + 7) & 0x1f)) - 1U &
                                              ((uVar4 >> 0x11 ^ uVar5) * 0x5bd1e995 >> 0x13 ^ uVar4) * 0x5bd1e995) *
                            0x20 + *(int64_t *)(arg1 + 0x28);
                    while( true ) {
                        uVar4 = *(uint32_t *)(iVar2 + 0x1c);
                        if ((((uint8_t)uVar4 & 0xf) == 3) && (*(double *)(iVar2 + 0x10) == dVar6)) {
                            return iVar2;
                        }
                        if ((uVar4 & 0xfffffff0) == 0) break;
                        iVar2 = iVar2 + ((int64_t)(int32_t)uVar4 >> 4) * 0x20;
                    }
                }
                return *(int64_t *)0x180782430;
            }
        } else if (iVar1 == 6) {
            arg2 = *(int64_t *)arg2;
            iVar2 = (int64_t)(int32_t)((1 << (*(uint8_t *)(arg1 + 7) & 0x1f)) - 1U &
                                      *(int32_t *)(arg2 + 0x10) + 0x10 + (int32_t)arg2) * 0x20 +
                    *(int64_t *)(arg1 + 0x28);
            while( true ) {
                uVar4 = *(uint32_t *)(iVar2 + 0x1c);
                if (((((uint8_t)uVar4 & 0xf) == 6) && (iVar3 = iVar2, *(int64_t *)(iVar2 + 0x10) == arg2)) ||
                   (iVar3 = *(int64_t *)0x180782430, (uVar4 & 0xfffffff0) == 0)) break;
                iVar2 = iVar2 + ((int64_t)(int32_t)uVar4 >> 4) * 0x20;
            }
            return iVar3;
        }
        iVar2 = func_0x0001800a00a0(arg1, arg2);
        iVar1 = func_0x000180099200(iVar2 + 0x10, arg2);
        while( true ) {
            if (iVar1 != 0) {
                return iVar2;
            }
            if (((int64_t)*(int32_t *)(iVar2 + 0x1c) & 0xfffffff0U) == 0) break;
            iVar2 = iVar2 + ((int64_t)*(int32_t *)(iVar2 + 0x1c) >> 4) * 0x20;
            iVar1 = func_0x000180099200(iVar2 + 0x10, arg2);
        }
    }
    return *(int64_t *)0x180782430;
}

// ============================================================
// Function: FUN_1800a0f40
// Address: 0x1800a0f40
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800a0f40(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    bool bVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = fcn.1800a0ea0(arg2, arg3, arg3);
    bVar2 = iVar1 == *(int64_t *)0x180782430;
    *(undefined *)(arg2 + 5) = 0;
    if (bVar2) {
        fcn.1800a0f90(arg1, arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800a0f90
// Address: 0x1800a0f90
// Size: 115 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a0f90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    uint32_t uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    undefined8 in_R9;
    undefined4 *puVar13;
    undefined auStackY_68 [32];
    int64_t in_stack_ffffffffffffffb8;
    
    iVar1 = *(int32_t *)(arg3 + 0xc);
    if (iVar1 == 0) {
        func_0x000180093000(arg1, 0x18063ea50);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    if (iVar1 == 3) {
        if (NAN(*(double *)arg3)) {
            func_0x000180093000(*(double *)arg3, 0x18063eab0);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    } else if ((iVar1 == 5) && (((NAN(*(float *)arg3) || (NAN(*(float *)(arg3 + 4)))) || (NAN(*(float *)(arg3 + 8))))))
    {
        func_0x000180093000(arg1, 0x18063ea90);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar6 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    if ((*(int32_t *)(arg3 + 0xc) == 3) && (*(double *)arg3 == (double)(*(int32_t *)(arg2 + 8) + 1))) {
        fcn.1800a0690(arg1, arg2, arg3, in_R9, in_stack_ffffffffffffffb8);
        if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
           (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
            fcn.1800a0a80(arg1, arg2, arg3);
        }
    } else {
        puVar7 = (undefined4 *)func_0x0001800a00a0(arg2, arg3);
        if ((puVar7[3] == 0) && (puVar13 = puVar7, puVar7 != *(undefined4 **)0x1807823c8)) {
code_r0x0001800a0cba:
            *(undefined8 *)(puVar13 + 4) = *(undefined8 *)arg3;
            puVar13[6] = *(undefined4 *)(arg3 + 8);
            puVar13[7] = puVar13[7] ^ (puVar13[7] ^ *(uint32_t *)(arg3 + 0xc)) & 0xf;
            if (((5 < *(int32_t *)(arg3 + 0xc)) && ((*(uint8_t *)(arg2 + 1) & 4) != 0)) &&
               ((*(uint8_t *)(*(int64_t *)arg3 + 1) & 3) != 0)) {
                iVar11 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar11 + 0x59) == '\x02') {
                    func_0x000180094420(iVar11);
                } else {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x18) = *(undefined8 *)(iVar11 + 0x18);
                    *(int64_t *)(iVar11 + 0x18) = arg2;
                }
            }
        } else {
            uVar10 = *(uint32_t *)(arg2 + 0xc);
            if (0 < (int32_t)uVar10) {
                iVar11 = *(int64_t *)(arg2 + 0x28) + -0x20;
                do {
                    uVar8 = (uint64_t)uVar10;
                    uVar10 = uVar10 - 1;
                    *(uint32_t *)(arg2 + 0xc) = uVar10;
                    puVar13 = (undefined4 *)(uVar8 * 0x20 + iVar11);
                    if ((*(uint8_t *)(uVar8 * 0x20 + 0x1c + iVar11) & 0xf) == 0) {
                        uVar10 = puVar7[7];
                        puVar9 = (undefined4 *)func_0x0001800a00a0(arg2, &stack0xffffffffffffffb8);
                        if (puVar9 == puVar7) {
                            if ((uVar10 & 0xfffffff0) != 0) {
                                puVar13[7] = puVar13[7] & 0xf;
                                puVar13[7] = puVar13[7] |
                                             (int32_t)((((int64_t)(int32_t)uVar10 >> 4) * 0x20 - (int64_t)puVar13) +
                                                       (int64_t)puVar7 >> 5) << 4;
                            }
                            puVar7[7] = puVar7[7] & 0xf;
                            puVar7[7] = puVar7[7] | (int32_t)((int64_t)puVar13 - (int64_t)puVar7 >> 5) << 4;
                        } else {
                            puVar12 = puVar9 + (int64_t)((int32_t)puVar9[7] >> 4) * 8;
                            while (puVar12 != puVar7) {
                                puVar9 = puVar9 + ((int64_t)(int32_t)puVar9[7] >> 4) * 8;
                                puVar12 = puVar9 + (int64_t)((int32_t)puVar9[7] >> 4) * 8;
                            }
                            puVar9[7] = puVar9[7] & 0xf;
                            puVar9[7] = puVar9[7] | (int32_t)((int64_t)puVar13 - (int64_t)puVar9 >> 5) << 4;
                            uVar3 = puVar7[1];
                            uVar4 = puVar7[2];
                            uVar5 = puVar7[3];
                            *puVar13 = *puVar7;
                            puVar13[1] = uVar3;
                            puVar13[2] = uVar4;
                            puVar13[3] = uVar5;
                            uVar3 = puVar7[5];
                            uVar4 = puVar7[6];
                            uVar5 = puVar7[7];
                            puVar13[4] = puVar7[4];
                            puVar13[5] = uVar3;
                            puVar13[6] = uVar4;
                            puVar13[7] = uVar5;
                            if ((puVar7[7] & 0xfffffff0) != 0) {
                                puVar13[7] = puVar13[7] + (int32_t)((int64_t)puVar7 - (int64_t)puVar13 >> 5) * 0x10;
                                puVar7[7] = puVar7[7] & 0xf;
                            }
                            puVar7[3] = 0;
                            puVar13 = puVar7;
                        }
                        goto code_r0x0001800a0cba;
                    }
                } while (0 < (int32_t)uVar10);
            }
            fcn.1800a0690(arg1, arg2, arg3, in_R9, in_stack_ffffffffffffffb8);
            if (((*(int32_t *)(arg3 + 0xc) != 3) || ((double)(int32_t)*(double *)arg3 != *(double *)arg3)) ||
               (*(uint32_t *)(arg2 + 8) <= (int32_t)*(double *)arg3 - 1U)) {
                fcn.1800a0a80(arg1, arg2, arg3);
            }
        }
    }
    func_0x000180459870(uVar6 ^ (uint64_t)auStackY_68);
    return;
}

// ============================================================
// Function: FUN_1800a1010
// Address: 0x1800a1010
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a1010(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined auStack_48 [32];
    int64_t var_28h;
    undefined4 var_1ch;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if ((*(uint32_t *)(arg2 + 8) <= (int32_t)arg3 - 1U) &&
       (iVar1 = func_0x0001800a0d50(arg2, arg3 & 0xffffffff), iVar1 == *(int64_t *)0x180782430)) {
        var_28h = (int64_t)(double)(int32_t)arg3;
        var_1ch = 3;
        fcn.1800a0a80(arg1, arg2, (int64_t)&var_28h);
    }
    func_0x000180459870(var_18h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_1800a10a0
// Address: 0x1800a10a0
// Size: 106 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a10a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int64_t iVar1;
    bool bVar2;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    iVar1 = fcn.1800a0e30(arg2, arg3);
    bVar2 = iVar1 == *(int64_t *)0x180782430;
    *(undefined *)(arg2 + 5) = 0;
    if (bVar2) {
        var_2ch = 6;
        var_38h = arg3;
        fcn.1800a0a80(arg1, arg2, (int64_t)&var_38h);
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_1800a1110
// Address: 0x1800a1110
// Size: 331 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800a1110(int64_t arg1)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(arg1 + 0xc);
    if (iVar1 < 0) {
        uVar6 = -iVar1;
    } else {
        uVar6 = *(uint32_t *)(arg1 + 8);
    }
    uVar7 = (uint64_t)uVar6;
    if (0 < (int32_t)uVar6) {
        uVar2 = *(uint32_t *)(arg1 + 8);
        iVar3 = *(int64_t *)(arg1 + 0x20);
        if ((*(int32_t *)(iVar3 + -4 + (int64_t)(int32_t)uVar2 * 0x10) != 0) &&
           (*(int64_t *)(arg1 + 0x28) == *(int64_t *)0x1807823c8)) {
            return (uint64_t)uVar2;
        }
        if ((int32_t)uVar6 < (int32_t)uVar2) {
            iVar8 = (int64_t)(int32_t)uVar6;
            if (*(int32_t *)(iVar3 + -4 + iVar8 * 0x10) != 0) {
                if (*(int32_t *)(iVar3 + 0xc + iVar8 * 0x10) == 0) goto code_r0x0001800a117d;
                goto code_r0x0001800a11a9;
            }
            uVar4 = uVar6 - 1;
            if (((int32_t)uVar6 < 2) || (*(int32_t *)(iVar3 + -0x14 + iVar8 * 0x10) == 0)) goto code_r0x0001800a11e3;
            if (iVar1 < 1) {
                *(uint32_t *)(arg1 + 0xc) = 1 - uVar6;
            }
        } else {
code_r0x0001800a11a9:
            uVar4 = uVar6 + 1;
            if ((((int32_t)uVar2 <= (int32_t)uVar4) || (*(int32_t *)(iVar3 + 0xc + (int64_t)(int32_t)uVar6 * 0x10) == 0)
                ) || (*(int32_t *)(iVar3 + 0x1c + (int64_t)(int32_t)uVar6 * 0x10) != 0)) goto code_r0x0001800a11e3;
            if (iVar1 < 1) {
                *(uint32_t *)(arg1 + 0xc) = ~uVar6;
            }
        }
        if (0 < (int32_t)uVar4) {
            return (uint64_t)uVar4;
        }
    }
code_r0x0001800a11e3:
    uVar6 = *(uint32_t *)(arg1 + 8);
    uVar7 = (uint64_t)(int32_t)uVar6;
    if ((0 < (int32_t)uVar6) &&
       (iVar3 = *(int64_t *)(arg1 + 0x20), iVar8 = iVar3, *(int32_t *)(iVar3 + -4 + uVar7 * 0x10) == 0)) {
        while (iVar1 = (int32_t)uVar6 >> 1, iVar1 != 0) {
            iVar5 = (int64_t)iVar1 * 0x10 + iVar8;
            if (*(int32_t *)(iVar5 + 0xc) != 0) {
                iVar8 = iVar5;
            }
            uVar6 = (int32_t)uVar7 - iVar1;
            uVar7 = (uint64_t)uVar6;
        }
        uVar6 = (uint32_t)(*(int32_t *)(iVar8 + 0xc) != 0) + (int32_t)(iVar8 - iVar3 >> 4);
        if (0 < *(int32_t *)(arg1 + 0xc)) {
            return (uint64_t)uVar6;
        }
        *(uint32_t *)(arg1 + 0xc) = -uVar6;
        return (uint64_t)uVar6;
    }
code_r0x0001800a117d:
    return uVar7 & 0xffffffff;
}

// ============================================================
// Function: FUN_1800a1260
// Address: 0x1800a1260
// Size: 329 bytes
// ============================================================
undefined * fcn.1800a1260(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    code *pcVar2;
    undefined *puVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t var_4h;
    int64_t var_20h;
    
    puVar3 = (undefined *)func_0x000180098710(arg1, 0x30, *(undefined *)(arg1 + 4));
    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
    puVar3[2] = 7;
    puVar3[1] = uVar1 & 3;
    *puVar3 = *(undefined *)(arg1 + 4);
    *(undefined8 *)(puVar3 + 0x10) = *(undefined8 *)(arg2 + 0x10);
    puVar3[5] = *(undefined *)(arg2 + 5);
    *(undefined8 *)(puVar3 + 0x20) = 0;
    *(undefined4 *)(puVar3 + 8) = 0;
    *(undefined2 *)(puVar3 + 6) = 0;
    *(undefined2 *)(puVar3 + 3) = 0;
    iVar7 = *(int64_t *)0x1807823c8;
    *(int64_t *)(puVar3 + 0x28) = *(int64_t *)0x1807823c8;
    *(undefined4 *)(puVar3 + 0xc) = 0;
    iVar5 = *(int32_t *)(arg2 + 8);
    if (iVar5 != 0) {
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar5) goto code_r0x0001800a13a0;
        uVar4 = func_0x000180098670(arg1, (int64_t)iVar5 << 4);
        *(undefined8 *)(puVar3 + 0x20) = uVar4;
        if (*(int32_t *)(puVar3 + 0xc) < 1) {
            if (*(int32_t *)(arg2 + 0xc) < 0) {
                iVar5 = -*(int32_t *)(arg2 + 0xc);
            } else {
                iVar5 = *(int32_t *)(arg2 + 8);
            }
            *(int32_t *)(puVar3 + 0xc) = -iVar5;
        }
        iVar5 = *(int32_t *)(arg2 + 8);
        *(int32_t *)(puVar3 + 8) = iVar5;
        func_0x000180498030(uVar4, *(undefined8 *)(arg2 + 0x20), (int64_t)iVar5 << 4);
        iVar7 = *(int64_t *)0x1807823c8;
    }
    if (*(int64_t *)(arg2 + 0x28) != iVar7) {
        uVar6 = (uint64_t)(1 << (*(uint8_t *)(arg2 + 7) & 0x1f));
        if (0x7ffffffffffffff < uVar6) {
code_r0x0001800a13a0:
            func_0x000180098420(arg1);
            pcVar2 = (code *)swi(3);
            puVar3 = (undefined *)(*pcVar2)();
            return puVar3;
        }
        iVar7 = uVar6 << 5;
        uVar4 = func_0x000180098670(arg1, iVar7, *puVar3);
        *(undefined8 *)(puVar3 + 0x28) = uVar4;
        puVar3[7] = *(undefined *)(arg2 + 7);
        puVar3[3] = *(undefined *)(arg2 + 3);
        func_0x000180498030(uVar4, *(undefined8 *)(arg2 + 0x28), iVar7);
        *(undefined4 *)(puVar3 + 0xc) = *(undefined4 *)(arg2 + 0xc);
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1800a1440
// Address: 0x1800a1440
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a1440(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar14 = *(int64_t **)0x180782430;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar9 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    piVar8 = piVar11 + 2;
    if (piVar9 <= piVar11 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    if (piVar9 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
    if (iVar6 == 6) {
        iVar6 = *(int32_t *)(*piVar11 + 0x14);
    } else if (iVar6 == 7) {
        iVar6 = fcn.1800a1110(*piVar11);
    } else {
        if ((iVar6 != 9) && (iVar6 != 0xb)) {
            return 0;
        }
        iVar6 = *(int32_t *)(*piVar11 + 4);
    }
    iVar13 = 1;
    if (0 < iVar6) {
        do {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0)) {
code_r0x0001800a169e:
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar12 = (*pcVar2)();
                return uVar12;
            }
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar11 <= piVar9) {
                piVar9 = piVar14;
            }
            uVar3 = *(undefined4 *)((int64_t)piVar9 + 4);
            uVar4 = *(undefined4 *)(piVar9 + 1);
            uVar5 = *(undefined4 *)((int64_t)piVar9 + 0xc);
            *(undefined4 *)piVar11 = *(undefined4 *)piVar9;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            pdVar1 = *(double **)(arg1 + 0x40);
            *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
            *pdVar1 = (double)iVar13;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = *(int64_t **)(arg1 + 0x28);
            if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
                piVar9 = piVar14;
            }
            puVar10 = (undefined4 *)func_0x0001800a0d50(*piVar9, iVar13);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)piVar11 = *puVar10;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800935b0(arg1, *(int64_t *)(arg1 + 0x40) + -0x30, 1, 0);
            piVar14 = *(int64_t **)0x180782430;
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0)) {
                return 1;
            }
            iVar13 = iVar13 + 1;
            *(int64_t **)(arg1 + 0x40) = piVar11;
        } while (iVar13 <= iVar6);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a149a
// Address: 0x1800a149a
// Size: 489 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a1440(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar14 = *(int64_t **)0x180782430;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar9 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    piVar8 = piVar11 + 2;
    if (piVar9 <= piVar11 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    if (piVar9 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
    if (iVar6 == 6) {
        iVar6 = *(int32_t *)(*piVar11 + 0x14);
    } else if (iVar6 == 7) {
        iVar6 = fcn.1800a1110(*piVar11);
    } else {
        if ((iVar6 != 9) && (iVar6 != 0xb)) {
            return 0;
        }
        iVar6 = *(int32_t *)(*piVar11 + 4);
    }
    iVar13 = 1;
    if (0 < iVar6) {
        do {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0)) {
code_r0x0001800a169e:
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar12 = (*pcVar2)();
                return uVar12;
            }
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar11 <= piVar9) {
                piVar9 = piVar14;
            }
            uVar3 = *(undefined4 *)((int64_t)piVar9 + 4);
            uVar4 = *(undefined4 *)(piVar9 + 1);
            uVar5 = *(undefined4 *)((int64_t)piVar9 + 0xc);
            *(undefined4 *)piVar11 = *(undefined4 *)piVar9;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            pdVar1 = *(double **)(arg1 + 0x40);
            *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
            *pdVar1 = (double)iVar13;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = *(int64_t **)(arg1 + 0x28);
            if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
                piVar9 = piVar14;
            }
            puVar10 = (undefined4 *)func_0x0001800a0d50(*piVar9, iVar13);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)piVar11 = *puVar10;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800935b0(arg1, *(int64_t *)(arg1 + 0x40) + -0x30, 1, 0);
            piVar14 = *(int64_t **)0x180782430;
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0)) {
                return 1;
            }
            iVar13 = iVar13 + 1;
            *(int64_t **)(arg1 + 0x40) = piVar11;
        } while (iVar13 <= iVar6);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a1683
// Address: 0x1800a1683
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a1440(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar14 = *(int64_t **)0x180782430;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar9 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    piVar8 = piVar11 + 2;
    if (piVar9 <= piVar11 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    if (piVar9 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
    if (iVar6 == 6) {
        iVar6 = *(int32_t *)(*piVar11 + 0x14);
    } else if (iVar6 == 7) {
        iVar6 = fcn.1800a1110(*piVar11);
    } else {
        if ((iVar6 != 9) && (iVar6 != 0xb)) {
            return 0;
        }
        iVar6 = *(int32_t *)(*piVar11 + 4);
    }
    iVar13 = 1;
    if (0 < iVar6) {
        do {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0)) {
code_r0x0001800a169e:
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar12 = (*pcVar2)();
                return uVar12;
            }
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar11 <= piVar9) {
                piVar9 = piVar14;
            }
            uVar3 = *(undefined4 *)((int64_t)piVar9 + 4);
            uVar4 = *(undefined4 *)(piVar9 + 1);
            uVar5 = *(undefined4 *)((int64_t)piVar9 + 0xc);
            *(undefined4 *)piVar11 = *(undefined4 *)piVar9;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            pdVar1 = *(double **)(arg1 + 0x40);
            *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
            *pdVar1 = (double)iVar13;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = *(int64_t **)(arg1 + 0x28);
            if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
                piVar9 = piVar14;
            }
            puVar10 = (undefined4 *)func_0x0001800a0d50(*piVar9, iVar13);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)piVar11 = *puVar10;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800935b0(arg1, *(int64_t *)(arg1 + 0x40) + -0x30, 1, 0);
            piVar14 = *(int64_t **)0x180782430;
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0)) {
                return 1;
            }
            iVar13 = iVar13 + 1;
            *(int64_t **)(arg1 + 0x40) = piVar11;
        } while (iVar13 <= iVar6);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a168a
// Address: 0x1800a168a
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a1440(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar14 = *(int64_t **)0x180782430;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar9 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    piVar8 = piVar11 + 2;
    if (piVar9 <= piVar11 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    if (piVar9 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
    if (iVar6 == 6) {
        iVar6 = *(int32_t *)(*piVar11 + 0x14);
    } else if (iVar6 == 7) {
        iVar6 = fcn.1800a1110(*piVar11);
    } else {
        if ((iVar6 != 9) && (iVar6 != 0xb)) {
            return 0;
        }
        iVar6 = *(int32_t *)(*piVar11 + 4);
    }
    iVar13 = 1;
    if (0 < iVar6) {
        do {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0)) {
code_r0x0001800a169e:
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar12 = (*pcVar2)();
                return uVar12;
            }
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar11 <= piVar9) {
                piVar9 = piVar14;
            }
            uVar3 = *(undefined4 *)((int64_t)piVar9 + 4);
            uVar4 = *(undefined4 *)(piVar9 + 1);
            uVar5 = *(undefined4 *)((int64_t)piVar9 + 0xc);
            *(undefined4 *)piVar11 = *(undefined4 *)piVar9;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            pdVar1 = *(double **)(arg1 + 0x40);
            *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
            *pdVar1 = (double)iVar13;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = *(int64_t **)(arg1 + 0x28);
            if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
                piVar9 = piVar14;
            }
            puVar10 = (undefined4 *)func_0x0001800a0d50(*piVar9, iVar13);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)piVar11 = *puVar10;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800935b0(arg1, *(int64_t *)(arg1 + 0x40) + -0x30, 1, 0);
            piVar14 = *(int64_t **)0x180782430;
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0)) {
                return 1;
            }
            iVar13 = iVar13 + 1;
            *(int64_t **)(arg1 + 0x40) = piVar11;
        } while (iVar13 <= iVar6);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a169e
// Address: 0x1800a169e
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a1440(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar14 = *(int64_t **)0x180782430;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar9 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    piVar8 = piVar11 + 2;
    if (piVar9 <= piVar11 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    if (piVar9 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
    if (iVar6 == 6) {
        iVar6 = *(int32_t *)(*piVar11 + 0x14);
    } else if (iVar6 == 7) {
        iVar6 = fcn.1800a1110(*piVar11);
    } else {
        if ((iVar6 != 9) && (iVar6 != 0xb)) {
            return 0;
        }
        iVar6 = *(int32_t *)(*piVar11 + 4);
    }
    iVar13 = 1;
    if (0 < iVar6) {
        do {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0)) {
code_r0x0001800a169e:
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar12 = (*pcVar2)();
                return uVar12;
            }
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar11 <= piVar9) {
                piVar9 = piVar14;
            }
            uVar3 = *(undefined4 *)((int64_t)piVar9 + 4);
            uVar4 = *(undefined4 *)(piVar9 + 1);
            uVar5 = *(undefined4 *)((int64_t)piVar9 + 0xc);
            *(undefined4 *)piVar11 = *(undefined4 *)piVar9;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            pdVar1 = *(double **)(arg1 + 0x40);
            *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
            *pdVar1 = (double)iVar13;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = *(int64_t **)(arg1 + 0x28);
            if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
                piVar9 = piVar14;
            }
            puVar10 = (undefined4 *)func_0x0001800a0d50(*piVar9, iVar13);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)piVar11 = *puVar10;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800935b0(arg1, *(int64_t *)(arg1 + 0x40) + -0x30, 1, 0);
            piVar14 = *(int64_t **)0x180782430;
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0)) {
                return 1;
            }
            iVar13 = iVar13 + 1;
            *(int64_t **)(arg1 + 0x40) = piVar11;
        } while (iVar13 <= iVar6);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a16b6
// Address: 0x1800a16b6
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a1440(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar14 = *(int64_t **)0x180782430;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar9 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    piVar8 = piVar11 + 2;
    if (piVar9 <= piVar11 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar12 = (*pcVar2)();
        return uVar12;
    }
    if (piVar9 <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
    if (iVar6 == 6) {
        iVar6 = *(int32_t *)(*piVar11 + 0x14);
    } else if (iVar6 == 7) {
        iVar6 = fcn.1800a1110(*piVar11);
    } else {
        if ((iVar6 != 9) && (iVar6 != 0xb)) {
            return 0;
        }
        iVar6 = *(int32_t *)(*piVar11 + 4);
    }
    iVar13 = 1;
    if (0 < iVar6) {
        do {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0)) {
code_r0x0001800a169e:
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar12 = (*pcVar2)();
                return uVar12;
            }
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar11 <= piVar9) {
                piVar9 = piVar14;
            }
            uVar3 = *(undefined4 *)((int64_t)piVar9 + 4);
            uVar4 = *(undefined4 *)(piVar9 + 1);
            uVar5 = *(undefined4 *)((int64_t)piVar9 + 0xc);
            *(undefined4 *)piVar11 = *(undefined4 *)piVar9;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            pdVar1 = *(double **)(arg1 + 0x40);
            *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
            *pdVar1 = (double)iVar13;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = func_0x000180085510(arg1, 1), piVar14 = *(int64_t **)0x180782430, iVar7 == 0))
            goto code_r0x0001800a169e;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = *(int64_t **)(arg1 + 0x28);
            if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
                piVar9 = piVar14;
            }
            puVar10 = (undefined4 *)func_0x0001800a0d50(*piVar9, iVar13);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)piVar11 = *puVar10;
            *(undefined4 *)((int64_t)piVar11 + 4) = uVar3;
            *(undefined4 *)(piVar11 + 1) = uVar4;
            *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800935b0(arg1, *(int64_t *)(arg1 + 0x40) + -0x30, 1, 0);
            piVar14 = *(int64_t **)0x180782430;
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0)) {
                return 1;
            }
            iVar13 = iVar13 + 1;
            *(int64_t **)(arg1 + 0x40) = piVar11;
        } while (iVar13 <= iVar6);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a16d0
// Address: 0x1800a16d0
// Size: 566 bytes
// ============================================================
undefined8 fcn.1800a16d0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    
    puVar1 = *(undefined4 **)(arg1 + 0x28);
    puVar8 = puVar1;
    if (*(undefined4 **)(arg1 + 0x40) <= puVar1) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 == *(undefined4 **)0x180782430) || (puVar8[3] != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    puVar8 = puVar1 + 4;
    if (*(undefined4 **)(arg1 + 0x40) <= puVar1 + 4) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 == *(undefined4 **)0x180782430) || (puVar8[3] != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    func_0x000180086510(arg1);
    iVar7 = func_0x000180087970(arg1, 1);
    while( true ) {
        if (iVar7 == 0) {
            return 0;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) break;
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        puVar8 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (puVar1 <= puVar8) {
            puVar8 = *(undefined4 **)0x180782430;
        }
        uVar4 = puVar8[1];
        uVar5 = puVar8[2];
        uVar6 = puVar8[3];
        *puVar1 = *puVar8;
        puVar1[1] = uVar4;
        puVar1[2] = uVar5;
        puVar1[3] = uVar6;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) break;
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-0xc];
        puVar1[1] = puVar1[-0xb];
        puVar1[2] = puVar1[-10];
        puVar1[3] = puVar1[-9];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) break;
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = puVar1[-0xc];
        puVar1[1] = puVar1[-0xb];
        puVar1[2] = puVar1[-10];
        puVar1[3] = puVar1[-9];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x0001800935b0(arg1, *(int64_t *)(arg1 + 0x40) + -0x30, 1, 0);
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (((undefined4 *)(iVar2 - 0x10U) == *(undefined4 **)0x180782430) || (*(int32_t *)(iVar2 + -4) != 0)) {
            return 1;
        }
        *(int64_t *)(arg1 + 0x40) = iVar2 + -0x20;
        iVar7 = func_0x000180087970(arg1, 1);
    }
    func_0x000180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_1800a1910
// Address: 0x1800a1910
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a1910(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    double dVar11;
    undefined auVar12 [16];
    int64_t var_8h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar7 = piVar1;
    if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    iVar6 = *piVar1;
    iVar5 = 0;
    auVar12 = ZEXT816(0);
    iVar10 = *(int32_t *)(iVar6 + 8);
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar9 = *(int64_t *)(iVar6 + 0x20);
            goto code_r0x0001800a19f0;
        }
    } else {
        iVar9 = *(int64_t *)(iVar6 + 0x20);
        do {
            iVar8 = (int64_t)iVar5;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 1);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x1c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 2);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x2c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 3);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x3c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 4);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        while (iVar5 < iVar10) {
code_r0x0001800a19f0:
            iVar8 = (int64_t)iVar5;
            iVar5 = iVar5 + 1;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)iVar5;
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
        }
    }
    uVar4 = auVar12._0_8_;
    iVar10 = 1 << (*(uint8_t *)(iVar6 + 7) & 0x1f);
    iVar5 = 0;
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar6 = *(int64_t *)(iVar6 + 0x28);
            goto code_r0x0001800a1b01;
        }
    } else {
        iVar6 = *(int64_t *)(iVar6 + 0x28);
        do {
            iVar8 = (int64_t)iVar5;
            iVar9 = iVar8 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 1) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 2) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 3) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        for (; uVar4 = auVar12._0_8_, iVar5 < iVar10; iVar5 = iVar5 + 1) {
code_r0x0001800a1b01:
            iVar9 = (int64_t)iVar5 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
        }
    }
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < *(int64_t **)(arg1 + 0x40) + 2)) &&
       (iVar5 = func_0x000180085510(arg1, 1), iVar5 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar4;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a194f
// Address: 0x1800a194f
// Size: 562 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a1910(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    double dVar11;
    undefined auVar12 [16];
    int64_t var_8h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar7 = piVar1;
    if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    iVar6 = *piVar1;
    iVar5 = 0;
    auVar12 = ZEXT816(0);
    iVar10 = *(int32_t *)(iVar6 + 8);
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar9 = *(int64_t *)(iVar6 + 0x20);
            goto code_r0x0001800a19f0;
        }
    } else {
        iVar9 = *(int64_t *)(iVar6 + 0x20);
        do {
            iVar8 = (int64_t)iVar5;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 1);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x1c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 2);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x2c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 3);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x3c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 4);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        while (iVar5 < iVar10) {
code_r0x0001800a19f0:
            iVar8 = (int64_t)iVar5;
            iVar5 = iVar5 + 1;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)iVar5;
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
        }
    }
    uVar4 = auVar12._0_8_;
    iVar10 = 1 << (*(uint8_t *)(iVar6 + 7) & 0x1f);
    iVar5 = 0;
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar6 = *(int64_t *)(iVar6 + 0x28);
            goto code_r0x0001800a1b01;
        }
    } else {
        iVar6 = *(int64_t *)(iVar6 + 0x28);
        do {
            iVar8 = (int64_t)iVar5;
            iVar9 = iVar8 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 1) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 2) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 3) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        for (; uVar4 = auVar12._0_8_, iVar5 < iVar10; iVar5 = iVar5 + 1) {
code_r0x0001800a1b01:
            iVar9 = (int64_t)iVar5 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
        }
    }
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < *(int64_t **)(arg1 + 0x40) + 2)) &&
       (iVar5 = func_0x000180085510(arg1, 1), iVar5 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar4;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a1b81
// Address: 0x1800a1b81
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a1910(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    double dVar11;
    undefined auVar12 [16];
    int64_t var_8h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar7 = piVar1;
    if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    iVar6 = *piVar1;
    iVar5 = 0;
    auVar12 = ZEXT816(0);
    iVar10 = *(int32_t *)(iVar6 + 8);
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar9 = *(int64_t *)(iVar6 + 0x20);
            goto code_r0x0001800a19f0;
        }
    } else {
        iVar9 = *(int64_t *)(iVar6 + 0x20);
        do {
            iVar8 = (int64_t)iVar5;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 1);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x1c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 2);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x2c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 3);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x3c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 4);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        while (iVar5 < iVar10) {
code_r0x0001800a19f0:
            iVar8 = (int64_t)iVar5;
            iVar5 = iVar5 + 1;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)iVar5;
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
        }
    }
    uVar4 = auVar12._0_8_;
    iVar10 = 1 << (*(uint8_t *)(iVar6 + 7) & 0x1f);
    iVar5 = 0;
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar6 = *(int64_t *)(iVar6 + 0x28);
            goto code_r0x0001800a1b01;
        }
    } else {
        iVar6 = *(int64_t *)(iVar6 + 0x28);
        do {
            iVar8 = (int64_t)iVar5;
            iVar9 = iVar8 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 1) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 2) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 3) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        for (; uVar4 = auVar12._0_8_, iVar5 < iVar10; iVar5 = iVar5 + 1) {
code_r0x0001800a1b01:
            iVar9 = (int64_t)iVar5 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
        }
    }
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < *(int64_t **)(arg1 + 0x40) + 2)) &&
       (iVar5 = func_0x000180085510(arg1, 1), iVar5 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar4;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a1b92
// Address: 0x1800a1b92
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a1910(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    double dVar11;
    undefined auVar12 [16];
    int64_t var_8h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar7 = piVar1;
    if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    iVar6 = *piVar1;
    iVar5 = 0;
    auVar12 = ZEXT816(0);
    iVar10 = *(int32_t *)(iVar6 + 8);
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar9 = *(int64_t *)(iVar6 + 0x20);
            goto code_r0x0001800a19f0;
        }
    } else {
        iVar9 = *(int64_t *)(iVar6 + 0x20);
        do {
            iVar8 = (int64_t)iVar5;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 1);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x1c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 2);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x2c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 3);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            if (*(int32_t *)(iVar9 + 0x3c + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)(iVar5 + 4);
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        while (iVar5 < iVar10) {
code_r0x0001800a19f0:
            iVar8 = (int64_t)iVar5;
            iVar5 = iVar5 + 1;
            if (*(int32_t *)(iVar9 + 0xc + iVar8 * 0x10) != 0) {
                auVar12._0_8_ = (double)iVar5;
                auVar12._8_8_ = (double)(int32_t)((uint64_t)auVar12._0_8_ >> 0x20);
            }
        }
    }
    uVar4 = auVar12._0_8_;
    iVar10 = 1 << (*(uint8_t *)(iVar6 + 7) & 0x1f);
    iVar5 = 0;
    if (iVar10 < 4) {
        if (0 < iVar10) {
            iVar6 = *(int64_t *)(iVar6 + 0x28);
            goto code_r0x0001800a1b01;
        }
    } else {
        iVar6 = *(int64_t *)(iVar6 + 0x28);
        do {
            iVar8 = (int64_t)iVar5;
            iVar9 = iVar8 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 1) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 2) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar9 = (iVar8 + 3) * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
            iVar5 = iVar5 + 4;
        } while (iVar5 < iVar10 + -3);
        for (; uVar4 = auVar12._0_8_, iVar5 < iVar10; iVar5 = iVar5 + 1) {
code_r0x0001800a1b01:
            iVar9 = (int64_t)iVar5 * 0x20;
            if ((*(int32_t *)(iVar9 + 0xc + iVar6) != 0) &&
               (((uint8_t)*(undefined4 *)(iVar9 + 0x1c + iVar6) & 0xf) == 3)) {
                dVar11 = *(double *)(iVar9 + 0x10 + iVar6);
                if (dVar11 <= auVar12._0_8_) {
                    dVar11 = auVar12._0_8_;
                }
                auVar12._8_8_ = 0.0;
                auVar12._0_8_ = dVar11;
            }
        }
    }
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < *(int64_t **)(arg1 + 0x40) + 2)) &&
       (iVar5 = func_0x000180085510(arg1, 1), iVar5 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar4;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a1bb0
// Address: 0x1800a1bb0
// Size: 144 bytes
// ============================================================
undefined8 fcn.1800a1bb0(int64_t arg1)
{
    int32_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        iVar1 = *(int32_t *)((int64_t)piVar6 + 0xc);
        if (iVar1 == 6) {
            uVar3 = *(undefined4 *)(*piVar6 + 0x14);
        } else if (iVar1 == 7) {
            uVar3 = fcn.1800a1110(*piVar6);
        } else if ((iVar1 == 9) || (iVar1 == 0xb)) {
            uVar3 = *(undefined4 *)(*piVar6 + 4);
        } else {
            uVar3 = 0;
        }
        func_0x0001800865e0(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800a1c40
// Address: 0x1800a1c40
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1800a1c40(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar3 = (*(int64_t **)(arg1 + 0x28))[(int64_t)(int32_t)arg3 * 2 + -2];
    if (*(char *)(iVar3 + 4) != '\0') {
        func_0x000180092f10();
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    iVar8 = (int32_t)arg4;
    iVar4 = **(int64_t **)(arg1 + 0x28);
    iVar14 = (uint32_t)arg_28h - iVar8;
    iVar15 = iVar14 + 1;
    if ((((iVar8 - 1U < *(uint32_t *)(iVar4 + 8)) && ((int32_t)arg_30h - 1U < *(uint32_t *)(iVar3 + 8))) &&
        ((uint32_t)arg_28h <= *(uint32_t *)(iVar4 + 8))) &&
       ((uint32_t)((int32_t)arg_30h + -1 + iVar15) <= *(uint32_t *)(iVar3 + 8))) {
        iVar5 = *(int64_t *)(iVar4 + 0x20);
        iVar6 = *(int64_t *)(iVar3 + 0x20);
        if ((((int32_t)(uint32_t)arg_28h < (int32_t)arg_30h) || ((int32_t)arg_30h <= iVar8)) ||
           (((int32_t)arg3 != 1 && (iVar3 != iVar4)))) {
            iVar14 = 0;
            if (0 < iVar15) {
                do {
                    iVar12 = iVar14 + iVar8;
                    iVar13 = iVar14 + (int32_t)arg_30h;
                    iVar14 = iVar14 + 1;
                    puVar1 = (undefined4 *)(iVar5 + -0x10 + (int64_t)iVar12 * 0x10);
                    uVar9 = puVar1[1];
                    uVar10 = puVar1[2];
                    uVar11 = puVar1[3];
                    puVar2 = (undefined4 *)(iVar6 + -0x10 + (int64_t)iVar13 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar9;
                    puVar2[2] = uVar10;
                    puVar2[3] = uVar11;
                } while (iVar14 < iVar15);
            }
        } else {
            for (; -1 < iVar14; iVar14 = iVar14 + -1) {
                puVar1 = (undefined4 *)(iVar5 + -0x10 + (int64_t)(iVar14 + iVar8) * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar6 + -0x10 + (int64_t)(iVar14 + (int32_t)arg_30h) * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            }
        }
        if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
            *(int64_t *)(iVar4 + 0x18) = iVar3;
        }
    } else if ((((int32_t)(uint32_t)arg_28h < (int32_t)arg_30h) || ((int32_t)arg_30h <= iVar8)) || (iVar3 != iVar4)) {
        iVar14 = 0;
        if (0 < iVar15) {
            do {
                func_0x000180086ed0(arg1, 1, iVar14 + iVar8);
                func_0x000180087560(arg1, arg3 & 0xffffffff, iVar14 + (int32_t)arg_30h);
                iVar14 = iVar14 + 1;
            } while (iVar14 < iVar15);
        }
    } else {
        for (; -1 < iVar14; iVar14 = iVar14 + -1) {
            func_0x000180086ed0(arg1, 1, iVar14 + iVar8);
            func_0x000180087560(arg1, arg3 & 0xffffffff, iVar14 + (int32_t)arg_30h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800a1c76
// Address: 0x1800a1c76
// Size: 377 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1800a1c40(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar3 = (*(int64_t **)(arg1 + 0x28))[(int64_t)(int32_t)arg3 * 2 + -2];
    if (*(char *)(iVar3 + 4) != '\0') {
        func_0x000180092f10();
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    iVar8 = (int32_t)arg4;
    iVar4 = **(int64_t **)(arg1 + 0x28);
    iVar14 = (uint32_t)arg_28h - iVar8;
    iVar15 = iVar14 + 1;
    if ((((iVar8 - 1U < *(uint32_t *)(iVar4 + 8)) && ((int32_t)arg_30h - 1U < *(uint32_t *)(iVar3 + 8))) &&
        ((uint32_t)arg_28h <= *(uint32_t *)(iVar4 + 8))) &&
       ((uint32_t)((int32_t)arg_30h + -1 + iVar15) <= *(uint32_t *)(iVar3 + 8))) {
        iVar5 = *(int64_t *)(iVar4 + 0x20);
        iVar6 = *(int64_t *)(iVar3 + 0x20);
        if ((((int32_t)(uint32_t)arg_28h < (int32_t)arg_30h) || ((int32_t)arg_30h <= iVar8)) ||
           (((int32_t)arg3 != 1 && (iVar3 != iVar4)))) {
            iVar14 = 0;
            if (0 < iVar15) {
                do {
                    iVar12 = iVar14 + iVar8;
                    iVar13 = iVar14 + (int32_t)arg_30h;
                    iVar14 = iVar14 + 1;
                    puVar1 = (undefined4 *)(iVar5 + -0x10 + (int64_t)iVar12 * 0x10);
                    uVar9 = puVar1[1];
                    uVar10 = puVar1[2];
                    uVar11 = puVar1[3];
                    puVar2 = (undefined4 *)(iVar6 + -0x10 + (int64_t)iVar13 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar9;
                    puVar2[2] = uVar10;
                    puVar2[3] = uVar11;
                } while (iVar14 < iVar15);
            }
        } else {
            for (; -1 < iVar14; iVar14 = iVar14 + -1) {
                puVar1 = (undefined4 *)(iVar5 + -0x10 + (int64_t)(iVar14 + iVar8) * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar6 + -0x10 + (int64_t)(iVar14 + (int32_t)arg_30h) * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            }
        }
        if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
            *(int64_t *)(iVar4 + 0x18) = iVar3;
        }
    } else if ((((int32_t)(uint32_t)arg_28h < (int32_t)arg_30h) || ((int32_t)arg_30h <= iVar8)) || (iVar3 != iVar4)) {
        iVar14 = 0;
        if (0 < iVar15) {
            do {
                func_0x000180086ed0(arg1, 1, iVar14 + iVar8);
                func_0x000180087560(arg1, arg3 & 0xffffffff, iVar14 + (int32_t)arg_30h);
                iVar14 = iVar14 + 1;
            } while (iVar14 < iVar15);
        }
    } else {
        for (; -1 < iVar14; iVar14 = iVar14 + -1) {
            func_0x000180086ed0(arg1, 1, iVar14 + iVar8);
            func_0x000180087560(arg1, arg3 & 0xffffffff, iVar14 + (int32_t)arg_30h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800a1def
// Address: 0x1800a1def
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1800a1c40(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar3 = (*(int64_t **)(arg1 + 0x28))[(int64_t)(int32_t)arg3 * 2 + -2];
    if (*(char *)(iVar3 + 4) != '\0') {
        func_0x000180092f10();
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    iVar8 = (int32_t)arg4;
    iVar4 = **(int64_t **)(arg1 + 0x28);
    iVar14 = (uint32_t)arg_28h - iVar8;
    iVar15 = iVar14 + 1;
    if ((((iVar8 - 1U < *(uint32_t *)(iVar4 + 8)) && ((int32_t)arg_30h - 1U < *(uint32_t *)(iVar3 + 8))) &&
        ((uint32_t)arg_28h <= *(uint32_t *)(iVar4 + 8))) &&
       ((uint32_t)((int32_t)arg_30h + -1 + iVar15) <= *(uint32_t *)(iVar3 + 8))) {
        iVar5 = *(int64_t *)(iVar4 + 0x20);
        iVar6 = *(int64_t *)(iVar3 + 0x20);
        if ((((int32_t)(uint32_t)arg_28h < (int32_t)arg_30h) || ((int32_t)arg_30h <= iVar8)) ||
           (((int32_t)arg3 != 1 && (iVar3 != iVar4)))) {
            iVar14 = 0;
            if (0 < iVar15) {
                do {
                    iVar12 = iVar14 + iVar8;
                    iVar13 = iVar14 + (int32_t)arg_30h;
                    iVar14 = iVar14 + 1;
                    puVar1 = (undefined4 *)(iVar5 + -0x10 + (int64_t)iVar12 * 0x10);
                    uVar9 = puVar1[1];
                    uVar10 = puVar1[2];
                    uVar11 = puVar1[3];
                    puVar2 = (undefined4 *)(iVar6 + -0x10 + (int64_t)iVar13 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar9;
                    puVar2[2] = uVar10;
                    puVar2[3] = uVar11;
                } while (iVar14 < iVar15);
            }
        } else {
            for (; -1 < iVar14; iVar14 = iVar14 + -1) {
                puVar1 = (undefined4 *)(iVar5 + -0x10 + (int64_t)(iVar14 + iVar8) * 0x10);
                uVar9 = puVar1[1];
                uVar10 = puVar1[2];
                uVar11 = puVar1[3];
                puVar2 = (undefined4 *)(iVar6 + -0x10 + (int64_t)(iVar14 + (int32_t)arg_30h) * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar9;
                puVar2[2] = uVar10;
                puVar2[3] = uVar11;
            }
        }
        if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
            *(int64_t *)(iVar4 + 0x18) = iVar3;
        }
    } else if ((((int32_t)(uint32_t)arg_28h < (int32_t)arg_30h) || ((int32_t)arg_30h <= iVar8)) || (iVar3 != iVar4)) {
        iVar14 = 0;
        if (0 < iVar15) {
            do {
                func_0x000180086ed0(arg1, 1, iVar14 + iVar8);
                func_0x000180087560(arg1, arg3 & 0xffffffff, iVar14 + (int32_t)arg_30h);
                iVar14 = iVar14 + 1;
            } while (iVar14 < iVar15);
        }
    } else {
        for (; -1 < iVar14; iVar14 = iVar14 + -1) {
            func_0x000180086ed0(arg1, 1, iVar14 + iVar8);
            func_0x000180087560(arg1, arg3 & 0xffffffff, iVar14 + (int32_t)arg_30h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800a1e00
// Address: 0x1800a1e00
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1e00(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        iVar2 = *(int32_t *)((int64_t)piVar6 + 0xc);
        if (iVar2 == 6) {
            iVar2 = *(int32_t *)(*piVar6 + 0x14);
        } else if (iVar2 == 7) {
            iVar2 = fcn.1800a1110(*piVar6);
        } else if ((iVar2 == 9) || (iVar2 == 0xb)) {
            iVar2 = *(int32_t *)(*piVar6 + 4);
        } else {
            iVar2 = 0;
        }
        iVar5 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
        if (iVar5 == 2) {
            uVar3 = iVar2 + 1;
        } else {
            if (iVar5 != 3) {
                fcn.180088560(arg1, 0x18063eac8);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
            uVar7 = 2;
            uVar3 = func_0x000180088860();
            if ((0 < (int32_t)uVar3) && ((int32_t)uVar3 <= iVar2)) {
                fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)uVar3, CONCAT44(var_18h._4_4_, iVar2), 
                              CONCAT44(in_stack_fffffffffffffff4, uVar3 + 1));
            }
        }
        func_0x000180087560(arg1, 1, uVar3);
        return 0;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a1e38
// Address: 0x1800a1e38
// Size: 180 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1e00(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        iVar2 = *(int32_t *)((int64_t)piVar6 + 0xc);
        if (iVar2 == 6) {
            iVar2 = *(int32_t *)(*piVar6 + 0x14);
        } else if (iVar2 == 7) {
            iVar2 = fcn.1800a1110(*piVar6);
        } else if ((iVar2 == 9) || (iVar2 == 0xb)) {
            iVar2 = *(int32_t *)(*piVar6 + 4);
        } else {
            iVar2 = 0;
        }
        iVar5 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
        if (iVar5 == 2) {
            uVar3 = iVar2 + 1;
        } else {
            if (iVar5 != 3) {
                fcn.180088560(arg1, 0x18063eac8);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
            uVar7 = 2;
            uVar3 = func_0x000180088860();
            if ((0 < (int32_t)uVar3) && ((int32_t)uVar3 <= iVar2)) {
                fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)uVar3, CONCAT44(var_18h._4_4_, iVar2), 
                              CONCAT44(in_stack_fffffffffffffff4, uVar3 + 1));
            }
        }
        func_0x000180087560(arg1, 1, uVar3);
        return 0;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a1eec
// Address: 0x1800a1eec
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1e00(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        iVar2 = *(int32_t *)((int64_t)piVar6 + 0xc);
        if (iVar2 == 6) {
            iVar2 = *(int32_t *)(*piVar6 + 0x14);
        } else if (iVar2 == 7) {
            iVar2 = fcn.1800a1110(*piVar6);
        } else if ((iVar2 == 9) || (iVar2 == 0xb)) {
            iVar2 = *(int32_t *)(*piVar6 + 4);
        } else {
            iVar2 = 0;
        }
        iVar5 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
        if (iVar5 == 2) {
            uVar3 = iVar2 + 1;
        } else {
            if (iVar5 != 3) {
                fcn.180088560(arg1, 0x18063eac8);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
            uVar7 = 2;
            uVar3 = func_0x000180088860();
            if ((0 < (int32_t)uVar3) && ((int32_t)uVar3 <= iVar2)) {
                fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)uVar3, CONCAT44(var_18h._4_4_, iVar2), 
                              CONCAT44(in_stack_fffffffffffffff4, uVar3 + 1));
            }
        }
        func_0x000180087560(arg1, 1, uVar3);
        return 0;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a1f00
// Address: 0x1800a1f00
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1e00(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        iVar2 = *(int32_t *)((int64_t)piVar6 + 0xc);
        if (iVar2 == 6) {
            iVar2 = *(int32_t *)(*piVar6 + 0x14);
        } else if (iVar2 == 7) {
            iVar2 = fcn.1800a1110(*piVar6);
        } else if ((iVar2 == 9) || (iVar2 == 0xb)) {
            iVar2 = *(int32_t *)(*piVar6 + 4);
        } else {
            iVar2 = 0;
        }
        iVar5 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
        if (iVar5 == 2) {
            uVar3 = iVar2 + 1;
        } else {
            if (iVar5 != 3) {
                fcn.180088560(arg1, 0x18063eac8);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
            uVar7 = 2;
            uVar3 = func_0x000180088860();
            if ((0 < (int32_t)uVar3) && ((int32_t)uVar3 <= iVar2)) {
                fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)uVar3, CONCAT44(var_18h._4_4_, iVar2), 
                              CONCAT44(in_stack_fffffffffffffff4, uVar3 + 1));
            }
        }
        func_0x000180087560(arg1, 1, uVar3);
        return 0;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a1f10
// Address: 0x1800a1f10
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1f10(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar2 = *(int64_t **)0x180782430;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xc);
    if (iVar3 == 6) {
        iVar3 = *(int32_t *)(*piVar6 + 0x14);
    } else if (iVar3 == 7) {
        iVar3 = fcn.1800a1110(*piVar6);
    } else if ((iVar3 == 9) || (iVar3 == 0xb)) {
        iVar3 = *(int32_t *)(*piVar6 + 4);
    } else {
        iVar3 = 0;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = piVar2;
    }
    iVar4 = iVar3;
    if ((piVar6 != piVar2) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar4 = func_0x000180088860(arg1, 2);
    }
    if ((0 < iVar4) && (iVar4 <= iVar3)) {
        uVar7 = 1;
        func_0x000180086ed0(arg1, 1, iVar4);
        fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)(iVar4 + 1), CONCAT44(var_18h._4_4_, iVar3), 
                      CONCAT44(in_stack_fffffffffffffff4, iVar4));
        func_0x000180086510(arg1);
        func_0x000180087560(arg1, 1, iVar3);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a1f4c
// Address: 0x1800a1f4c
// Size: 204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1f10(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar2 = *(int64_t **)0x180782430;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xc);
    if (iVar3 == 6) {
        iVar3 = *(int32_t *)(*piVar6 + 0x14);
    } else if (iVar3 == 7) {
        iVar3 = fcn.1800a1110(*piVar6);
    } else if ((iVar3 == 9) || (iVar3 == 0xb)) {
        iVar3 = *(int32_t *)(*piVar6 + 4);
    } else {
        iVar3 = 0;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = piVar2;
    }
    iVar4 = iVar3;
    if ((piVar6 != piVar2) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar4 = func_0x000180088860(arg1, 2);
    }
    if ((0 < iVar4) && (iVar4 <= iVar3)) {
        uVar7 = 1;
        func_0x000180086ed0(arg1, 1, iVar4);
        fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)(iVar4 + 1), CONCAT44(var_18h._4_4_, iVar3), 
                      CONCAT44(in_stack_fffffffffffffff4, iVar4));
        func_0x000180086510(arg1);
        func_0x000180087560(arg1, 1, iVar3);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a2018
// Address: 0x1800a2018
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1f10(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar2 = *(int64_t **)0x180782430;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xc);
    if (iVar3 == 6) {
        iVar3 = *(int32_t *)(*piVar6 + 0x14);
    } else if (iVar3 == 7) {
        iVar3 = fcn.1800a1110(*piVar6);
    } else if ((iVar3 == 9) || (iVar3 == 0xb)) {
        iVar3 = *(int32_t *)(*piVar6 + 4);
    } else {
        iVar3 = 0;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = piVar2;
    }
    iVar4 = iVar3;
    if ((piVar6 != piVar2) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar4 = func_0x000180088860(arg1, 2);
    }
    if ((0 < iVar4) && (iVar4 <= iVar3)) {
        uVar7 = 1;
        func_0x000180086ed0(arg1, 1, iVar4);
        fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)(iVar4 + 1), CONCAT44(var_18h._4_4_, iVar3), 
                      CONCAT44(in_stack_fffffffffffffff4, iVar4));
        func_0x000180086510(arg1);
        func_0x000180087560(arg1, 1, iVar3);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a202a
// Address: 0x1800a202a
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a1f10(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff4;
    
    piVar2 = *(int64_t **)0x180782430;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xc);
    if (iVar3 == 6) {
        iVar3 = *(int32_t *)(*piVar6 + 0x14);
    } else if (iVar3 == 7) {
        iVar3 = fcn.1800a1110(*piVar6);
    } else if ((iVar3 == 9) || (iVar3 == 0xb)) {
        iVar3 = *(int32_t *)(*piVar6 + 4);
    } else {
        iVar3 = 0;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = piVar2;
    }
    iVar4 = iVar3;
    if ((piVar6 != piVar2) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar4 = func_0x000180088860(arg1, 2);
    }
    if ((0 < iVar4) && (iVar4 <= iVar3)) {
        uVar7 = 1;
        func_0x000180086ed0(arg1, 1, iVar4);
        fcn.1800a1c40(arg1, uVar7, 1, (uint64_t)(iVar4 + 1), CONCAT44(var_18h._4_4_, iVar3), 
                      CONCAT44(in_stack_fffffffffffffff4, iVar4));
        func_0x000180086510(arg1);
        func_0x000180087560(arg1, 1, iVar3);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a2040
// Address: 0x1800a2040
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a2040(int64_t arg1)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    uint64_t arg2;
    uint32_t uVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    uVar10 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    uVar2 = func_0x000180088860(arg1, 2);
    iVar3 = func_0x000180088860(arg1, 3);
    iVar4 = func_0x000180088860(arg1, 4);
    uVar10 = *(int64_t *)(arg1 + 0x28) + 0x40;
    iVar8 = -1;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if (uVar10 != *(uint64_t *)0x180782430) {
        iVar8 = *(int32_t *)(uVar10 + 0xc);
    }
    uVar5 = 1;
    if (0 < iVar8) {
        uVar5 = 5;
    }
    func_0x0001800886a0(arg1, uVar5, 7);
    if ((int32_t)uVar2 <= iVar3) {
        if (((int32_t)uVar2 < 1) && ((int32_t)(uVar2 + 0x7fffffff) <= iVar3)) {
            func_0x000180088380(arg1, 3, 0x18063eb48);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
        uVar9 = (iVar3 - uVar2) + 1;
        uVar10 = (uint64_t)uVar9;
        if ((int32_t)(-0x80000000 - uVar9) < iVar4) {
            func_0x000180088380(arg1, 4, 0x18063eb30);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
        arg2 = *(uint64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (uint64_t)uVar5 * 0x10);
        if (*(char *)(arg2 + 4) != '\0') {
            func_0x000180092f10(arg1);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
        if (((0 < iVar4) && (iVar4 + -1 <= *(int32_t *)(arg2 + 8))) &&
           (uVar9 = iVar4 + -1 + uVar9, *(int32_t *)(arg2 + 8) < (int32_t)uVar9)) {
            if (*(int64_t *)(arg2 + 0x28) == *(int64_t *)0x1807823c8) {
                uVar11 = 0;
            } else {
                uVar11 = 1 << (*(uint8_t *)(arg2 + 7) & 0x1f);
            }
            bVar12 = *(int64_t *)(arg2 + 0x28) != *(int64_t *)0x1807823c8;
            while ((uVar10 = (uint64_t)uVar9, uVar9 == 0xfffffffe ||
                   ((bVar12 && (iVar6 = func_0x0001800a0d50(arg2, uVar9 + 1), *(int32_t *)(iVar6 + 0xc) != 0))))) {
                uVar9 = uVar9 + 1;
            }
            fcn.1800a0410(arg1, arg2, uVar10 & 0xffffffff, (uint64_t)uVar11);
            uVar10 = arg2;
        }
        fcn.1800a1c40(arg1, uVar10, (uint64_t)uVar5, (uint64_t)uVar2, CONCAT44(var_38h._4_4_, iVar3), 
                      CONCAT44(var_30h._4_4_, iVar4));
    }
    func_0x000180085bf0(arg1, uVar5);
    return 1;
}

// ============================================================
// Function: FUN_1800a2070
// Address: 0x1800a2070
// Size: 267 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800a2040(int64_t arg1)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    uint64_t arg2;
    uint32_t uVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    uVar10 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    uVar2 = func_0x000180088860(arg1, 2);
    iVar3 = func_0x000180088860(arg1, 3);
    iVar4 = func_0x000180088860(arg1, 4);
    uVar10 = *(int64_t *)(arg1 + 0x28) + 0x40;
    iVar8 = -1;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if (uVar10 != *(uint64_t *)0x180782430) {
        iVar8 = *(int32_t *)(uVar10 + 0xc);
    }
    uVar5 = 1;
    if (0 < iVar8) {
        uVar5 = 5;
    }
    func_0x0001800886a0(arg1, uVar5, 7);
    if ((int32_t)uVar2 <= iVar3) {
        if (((int32_t)uVar2 < 1) && ((int32_t)(uVar2 + 0x7fffffff) <= iVar3)) {
            func_0x000180088380(arg1, 3, 0x18063eb48);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
        uVar9 = (iVar3 - uVar2) + 1;
        uVar10 = (uint64_t)uVar9;
        if ((int32_t)(-0x80000000 - uVar9) < iVar4) {
            func_0x000180088380(arg1, 4, 0x18063eb30);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
        arg2 = *(uint64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (uint64_t)uVar5 * 0x10);
        if (*(char *)(arg2 + 4) != '\0') {
            func_0x000180092f10(arg1);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
        if (((0 < iVar4) && (iVar4 + -1 <= *(int32_t *)(arg2 + 8))) &&
           (uVar9 = iVar4 + -1 + uVar9, *(int32_t *)(arg2 + 8) < (int32_t)uVar9)) {
            if (*(int64_t *)(arg2 + 0x28) == *(int64_t *)0x1807823c8) {
                uVar11 = 0;
            } else {
                uVar11 = 1 << (*(uint8_t *)(arg2 + 7) & 0x1f);
            }
            bVar12 = *(int64_t *)(arg2 + 0x28) != *(int64_t *)0x1807823c8;
            while ((uVar10 = (uint64_t)uVar9, uVar9 == 0xfffffffe ||
                   ((bVar12 && (iVar6 = func_0x0001800a0d50(arg2, uVar9 + 1), *(int32_t *)(iVar6 + 0xc) != 0))))) {
                uVar9 = uVar9 + 1;
            }
            fcn.1800a0410(arg1, arg2, uVar10 & 0xffffffff, (uint64_t)uVar11);
            uVar10 = arg2;
        }
        fcn.1800a1c40(arg1, uVar10, (uint64_t)uVar5, (uint64_t)uVar2, CONCAT44(var_38h._4_4_, iVar3), 
                      CONCAT44(var_30h._4_4_, iVar4));
    }
    func_0x000180085bf0(arg1, uVar5);
    return 1;
}

