// Chunk 100 - 50 functions

// ============================================================
// Function: FUN_18015c410
// Address: 0x18015c410
// Size: 87 bytes
// ============================================================
void fcn.18015c410(int64_t arg1, int64_t arg_58h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    undefined8 *puVar14;
    uint64_t uVar15;
    int32_t iVar16;
    int32_t iVar17;
    undefined8 uVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    for (uVar9 = *(uint64_t *)arg1; uVar9 < *(uint64_t *)(arg1 + 8); uVar9 = uVar9 + 0x14) {
        *(undefined *)(uVar9 + 0x12) = 0;
    }
    if (1 < (uint64_t)(((int64_t)(*(uint64_t *)(arg1 + 8) - *(int64_t *)arg1) >> 2) * -0x3333333333333333)) {
        func_0x000180163fc0();
        puVar1 = *(undefined8 **)(arg1 + 8);
code_r0x00018015c480:
        puVar14 = puVar1;
        iVar6 = *(int64_t *)arg1;
        if ((puVar14 != (undefined8 *)(iVar6 + 0x14U)) && ((undefined8 *)(iVar6 + 0x14U) <= puVar14)) {
            iVar2 = *(int32_t *)(puVar14 + -4);
            iVar3 = *(int32_t *)(puVar14 + -5);
            bVar20 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            bVar19 = iVar3 == iVar2;
            if (bVar19) {
                iVar4 = *(int32_t *)((int64_t)puVar14 + -0x1c);
                iVar5 = *(int32_t *)((int64_t)puVar14 + -0x24);
                bVar20 = SBORROW4(iVar5, iVar4);
                iVar8 = iVar5 - iVar4;
                bVar19 = iVar5 == iVar4;
            }
            iVar4 = *(int32_t *)((int64_t)puVar14 + -0x14);
            puVar1 = (undefined8 *)((int64_t)puVar14 + -0x14);
            iVar5 = *(int32_t *)((int64_t)puVar14 + -0xc);
            uVar18 = *(undefined8 *)((int64_t)puVar14 - ((uint64_t)(!bVar19 && bVar20 == iVar8 < 0) * 8 + 0x20));
            puVar13 = (undefined8 *)((int64_t)puVar14 + -0xc);
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar8 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar7 = *(int32_t *)(puVar14 + -1);
                iVar16 = *(int32_t *)(puVar14 + -2);
                bVar20 = SBORROW4(iVar16, iVar7);
                iVar8 = iVar16 - iVar7;
                bVar19 = iVar16 == iVar7;
            }
            puVar10 = puVar13;
            if (!bVar19 && bVar20 == iVar8 < 0) {
                puVar10 = puVar1;
            }
            iVar8 = (int32_t)*puVar10;
            iVar7 = (int32_t)uVar18;
            if (iVar7 == iVar8) {
                bVar19 = (int32_t)((uint64_t)*puVar10 >> 0x20) <= (int32_t)((uint64_t)uVar18 >> 0x20);
            } else {
                bVar19 = iVar7 != iVar8 && iVar8 <= iVar7;
            }
            if (!bVar19) goto code_r0x00018015c521;
            if (*(char *)((int64_t)puVar14 + -4) != '\0') {
                *(undefined *)(puVar14 + -3) = 1;
            }
            if (*(char *)((int64_t)puVar14 + -3) != '\0') {
                *(undefined *)((int64_t)puVar14 + -0x17) = 1;
            }
            goto code_r0x00018015c616;
        }
        uVar9 = 0;
        uVar15 = (*(int64_t *)(arg1 + 8) - iVar6 >> 2) * -0x3333333333333333;
        if (uVar15 != 0) {
            do {
                if (*(char *)(iVar6 + 0x10 + uVar9 * 0x14) != '\0') {
                    *(uint64_t *)(arg1 + 0x18) = uVar9;
                }
                if (*(char *)(iVar6 + 0x11 + uVar9 * 0x14) != '\0') {
                    *(uint64_t *)(arg1 + 0x20) = uVar9;
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < uVar15);
        }
    }
    return;
code_r0x00018015c521:
    puVar10 = puVar14 + -5;
    bVar20 = SBORROW4(iVar3, iVar2);
    iVar8 = iVar3 - iVar2;
    bVar19 = iVar3 == iVar2;
    if (bVar19) {
        iVar7 = *(int32_t *)((int64_t)puVar14 + -0x1c);
        iVar16 = *(int32_t *)((int64_t)puVar14 + -0x24);
        bVar20 = SBORROW4(iVar16, iVar7);
        iVar8 = iVar16 - iVar7;
        bVar19 = iVar16 == iVar7;
    }
    puVar12 = puVar14 + -4;
    if (!bVar19 && bVar20 == iVar8 < 0) {
        puVar12 = puVar10;
    }
    bVar19 = SBORROW4(iVar4, iVar5);
    iVar8 = iVar4 - iVar5;
    if (iVar4 == iVar5) {
        bVar19 = SBORROW4(*(int32_t *)(puVar14 + -2), *(int32_t *)(puVar14 + -1));
        iVar8 = *(int32_t *)(puVar14 + -2) - *(int32_t *)(puVar14 + -1);
    }
    puVar11 = puVar13;
    if (bVar19 != iVar8 < 0) {
        puVar11 = puVar1;
    }
    iVar7 = (int32_t)*puVar11;
    iVar16 = (int32_t)*puVar12;
    bVar20 = SBORROW4(iVar16, iVar7);
    iVar8 = iVar16 - iVar7;
    bVar19 = iVar16 == iVar7;
    if (bVar19) {
        iVar7 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        iVar16 = (int32_t)((uint64_t)*puVar12 >> 0x20);
        bVar20 = SBORROW4(iVar16, iVar7);
        iVar8 = iVar16 - iVar7;
        bVar19 = iVar16 == iVar7;
    }
    if (!bVar19 && bVar20 == iVar8 < 0) {
        uVar18 = *puVar1;
        iVar17 = (int32_t)uVar18;
        iVar7 = (int32_t)*(undefined8 *)((int64_t)puVar14 + -0xc);
        bVar19 = SBORROW4(iVar7, iVar17);
        iVar8 = iVar7 - iVar17;
        iVar16 = (int32_t)((uint64_t)uVar18 >> 0x20);
        if (iVar7 == iVar17) {
            iVar8 = (int32_t)((uint64_t)*(undefined8 *)((int64_t)puVar14 + -0xc) >> 0x20);
            bVar19 = SBORROW4(iVar8, iVar16);
            iVar8 = iVar8 - iVar16;
        }
        if (bVar19 == iVar8 < 0) {
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar8 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar4 = *(int32_t *)(puVar14 + -1);
                bVar20 = SBORROW4(iVar16, iVar4);
                iVar8 = iVar16 - iVar4;
                bVar19 = iVar16 == iVar4;
            }
            if (bVar19 || bVar20 != iVar8 < 0) {
                uVar18 = *puVar13;
            }
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            if (iVar3 == iVar2) {
                bVar19 = SBORROW4(*(int32_t *)((int64_t)puVar14 + -0x24), *(int32_t *)((int64_t)puVar14 + -0x1c));
                iVar8 = *(int32_t *)((int64_t)puVar14 + -0x24) - *(int32_t *)((int64_t)puVar14 + -0x1c);
            }
            puVar13 = puVar14 + -4;
            if (bVar19 != iVar8 < 0) {
                puVar13 = puVar10;
            }
        } else {
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            if (iVar3 == iVar2) {
                bVar19 = SBORROW4(*(int32_t *)((int64_t)puVar14 + -0x24), *(int32_t *)((int64_t)puVar14 + -0x1c));
                iVar8 = *(int32_t *)((int64_t)puVar14 + -0x24) - *(int32_t *)((int64_t)puVar14 + -0x1c);
            }
            puVar12 = puVar14 + -4;
            if (bVar19 != iVar8 < 0) {
                puVar12 = puVar10;
            }
            uVar18 = *puVar12;
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar2 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar3 = *(int32_t *)(puVar14 + -1);
                bVar20 = SBORROW4(iVar16, iVar3);
                iVar2 = iVar16 - iVar3;
                bVar19 = iVar16 == iVar3;
            }
            if (!bVar19 && bVar20 == iVar2 < 0) {
                puVar13 = puVar1;
            }
        }
        puVar14[-5] = *puVar13;
        puVar14[-4] = uVar18;
        *(undefined *)((int64_t)puVar14 + -0x16) = 1;
        if (*(char *)((int64_t)puVar14 + -4) != '\0') {
            *(undefined *)(puVar14 + -3) = 1;
        }
        if (*(char *)((int64_t)puVar14 + -3) != '\0') {
            *(undefined *)((int64_t)puVar14 + -0x17) = 1;
        }
code_r0x00018015c616:
        func_0x000180498030(puVar1, puVar14, *(int64_t *)(arg1 + 8) - (int64_t)puVar14);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
    }
    goto code_r0x00018015c480;
}

// ============================================================
// Function: FUN_18015c467
// Address: 0x18015c467
// Size: 506 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18015c410(int64_t arg1, int64_t arg_58h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    undefined8 *puVar14;
    uint64_t uVar15;
    int32_t iVar16;
    int32_t iVar17;
    undefined8 uVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    for (uVar9 = *(uint64_t *)arg1; uVar9 < *(uint64_t *)(arg1 + 8); uVar9 = uVar9 + 0x14) {
        *(undefined *)(uVar9 + 0x12) = 0;
    }
    if (1 < (uint64_t)(((int64_t)(*(uint64_t *)(arg1 + 8) - *(int64_t *)arg1) >> 2) * -0x3333333333333333)) {
        func_0x000180163fc0();
        puVar1 = *(undefined8 **)(arg1 + 8);
code_r0x00018015c480:
        puVar14 = puVar1;
        iVar6 = *(int64_t *)arg1;
        if ((puVar14 != (undefined8 *)(iVar6 + 0x14U)) && ((undefined8 *)(iVar6 + 0x14U) <= puVar14)) {
            iVar2 = *(int32_t *)(puVar14 + -4);
            iVar3 = *(int32_t *)(puVar14 + -5);
            bVar20 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            bVar19 = iVar3 == iVar2;
            if (bVar19) {
                iVar4 = *(int32_t *)((int64_t)puVar14 + -0x1c);
                iVar5 = *(int32_t *)((int64_t)puVar14 + -0x24);
                bVar20 = SBORROW4(iVar5, iVar4);
                iVar8 = iVar5 - iVar4;
                bVar19 = iVar5 == iVar4;
            }
            iVar4 = *(int32_t *)((int64_t)puVar14 + -0x14);
            puVar1 = (undefined8 *)((int64_t)puVar14 + -0x14);
            iVar5 = *(int32_t *)((int64_t)puVar14 + -0xc);
            uVar18 = *(undefined8 *)((int64_t)puVar14 - ((uint64_t)(!bVar19 && bVar20 == iVar8 < 0) * 8 + 0x20));
            puVar13 = (undefined8 *)((int64_t)puVar14 + -0xc);
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar8 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar7 = *(int32_t *)(puVar14 + -1);
                iVar16 = *(int32_t *)(puVar14 + -2);
                bVar20 = SBORROW4(iVar16, iVar7);
                iVar8 = iVar16 - iVar7;
                bVar19 = iVar16 == iVar7;
            }
            puVar10 = puVar13;
            if (!bVar19 && bVar20 == iVar8 < 0) {
                puVar10 = puVar1;
            }
            iVar8 = (int32_t)*puVar10;
            iVar7 = (int32_t)uVar18;
            if (iVar7 == iVar8) {
                bVar19 = (int32_t)((uint64_t)*puVar10 >> 0x20) <= (int32_t)((uint64_t)uVar18 >> 0x20);
            } else {
                bVar19 = iVar7 != iVar8 && iVar8 <= iVar7;
            }
            if (!bVar19) goto code_r0x00018015c521;
            if (*(char *)((int64_t)puVar14 + -4) != '\0') {
                *(undefined *)(puVar14 + -3) = 1;
            }
            if (*(char *)((int64_t)puVar14 + -3) != '\0') {
                *(undefined *)((int64_t)puVar14 + -0x17) = 1;
            }
            goto code_r0x00018015c616;
        }
        uVar9 = 0;
        uVar15 = (*(int64_t *)(arg1 + 8) - iVar6 >> 2) * -0x3333333333333333;
        if (uVar15 != 0) {
            do {
                if (*(char *)(iVar6 + 0x10 + uVar9 * 0x14) != '\0') {
                    *(uint64_t *)(arg1 + 0x18) = uVar9;
                }
                if (*(char *)(iVar6 + 0x11 + uVar9 * 0x14) != '\0') {
                    *(uint64_t *)(arg1 + 0x20) = uVar9;
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < uVar15);
        }
    }
    return;
code_r0x00018015c521:
    puVar10 = puVar14 + -5;
    bVar20 = SBORROW4(iVar3, iVar2);
    iVar8 = iVar3 - iVar2;
    bVar19 = iVar3 == iVar2;
    if (bVar19) {
        iVar7 = *(int32_t *)((int64_t)puVar14 + -0x1c);
        iVar16 = *(int32_t *)((int64_t)puVar14 + -0x24);
        bVar20 = SBORROW4(iVar16, iVar7);
        iVar8 = iVar16 - iVar7;
        bVar19 = iVar16 == iVar7;
    }
    puVar12 = puVar14 + -4;
    if (!bVar19 && bVar20 == iVar8 < 0) {
        puVar12 = puVar10;
    }
    bVar19 = SBORROW4(iVar4, iVar5);
    iVar8 = iVar4 - iVar5;
    if (iVar4 == iVar5) {
        bVar19 = SBORROW4(*(int32_t *)(puVar14 + -2), *(int32_t *)(puVar14 + -1));
        iVar8 = *(int32_t *)(puVar14 + -2) - *(int32_t *)(puVar14 + -1);
    }
    puVar11 = puVar13;
    if (bVar19 != iVar8 < 0) {
        puVar11 = puVar1;
    }
    iVar7 = (int32_t)*puVar11;
    iVar16 = (int32_t)*puVar12;
    bVar20 = SBORROW4(iVar16, iVar7);
    iVar8 = iVar16 - iVar7;
    bVar19 = iVar16 == iVar7;
    if (bVar19) {
        iVar7 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        iVar16 = (int32_t)((uint64_t)*puVar12 >> 0x20);
        bVar20 = SBORROW4(iVar16, iVar7);
        iVar8 = iVar16 - iVar7;
        bVar19 = iVar16 == iVar7;
    }
    if (!bVar19 && bVar20 == iVar8 < 0) {
        uVar18 = *puVar1;
        iVar17 = (int32_t)uVar18;
        iVar7 = (int32_t)*(undefined8 *)((int64_t)puVar14 + -0xc);
        bVar19 = SBORROW4(iVar7, iVar17);
        iVar8 = iVar7 - iVar17;
        iVar16 = (int32_t)((uint64_t)uVar18 >> 0x20);
        if (iVar7 == iVar17) {
            iVar8 = (int32_t)((uint64_t)*(undefined8 *)((int64_t)puVar14 + -0xc) >> 0x20);
            bVar19 = SBORROW4(iVar8, iVar16);
            iVar8 = iVar8 - iVar16;
        }
        if (bVar19 == iVar8 < 0) {
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar8 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar4 = *(int32_t *)(puVar14 + -1);
                bVar20 = SBORROW4(iVar16, iVar4);
                iVar8 = iVar16 - iVar4;
                bVar19 = iVar16 == iVar4;
            }
            if (bVar19 || bVar20 != iVar8 < 0) {
                uVar18 = *puVar13;
            }
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            if (iVar3 == iVar2) {
                bVar19 = SBORROW4(*(int32_t *)((int64_t)puVar14 + -0x24), *(int32_t *)((int64_t)puVar14 + -0x1c));
                iVar8 = *(int32_t *)((int64_t)puVar14 + -0x24) - *(int32_t *)((int64_t)puVar14 + -0x1c);
            }
            puVar13 = puVar14 + -4;
            if (bVar19 != iVar8 < 0) {
                puVar13 = puVar10;
            }
        } else {
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            if (iVar3 == iVar2) {
                bVar19 = SBORROW4(*(int32_t *)((int64_t)puVar14 + -0x24), *(int32_t *)((int64_t)puVar14 + -0x1c));
                iVar8 = *(int32_t *)((int64_t)puVar14 + -0x24) - *(int32_t *)((int64_t)puVar14 + -0x1c);
            }
            puVar12 = puVar14 + -4;
            if (bVar19 != iVar8 < 0) {
                puVar12 = puVar10;
            }
            uVar18 = *puVar12;
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar2 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar3 = *(int32_t *)(puVar14 + -1);
                bVar20 = SBORROW4(iVar16, iVar3);
                iVar2 = iVar16 - iVar3;
                bVar19 = iVar16 == iVar3;
            }
            if (!bVar19 && bVar20 == iVar2 < 0) {
                puVar13 = puVar1;
            }
        }
        puVar14[-5] = *puVar13;
        puVar14[-4] = uVar18;
        *(undefined *)((int64_t)puVar14 + -0x16) = 1;
        if (*(char *)((int64_t)puVar14 + -4) != '\0') {
            *(undefined *)(puVar14 + -3) = 1;
        }
        if (*(char *)((int64_t)puVar14 + -3) != '\0') {
            *(undefined *)((int64_t)puVar14 + -0x17) = 1;
        }
code_r0x00018015c616:
        func_0x000180498030(puVar1, puVar14, *(int64_t *)(arg1 + 8) - (int64_t)puVar14);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
    }
    goto code_r0x00018015c480;
}

// ============================================================
// Function: FUN_18015c661
// Address: 0x18015c661
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18015c410(int64_t arg1, int64_t arg_58h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    undefined8 *puVar14;
    uint64_t uVar15;
    int32_t iVar16;
    int32_t iVar17;
    undefined8 uVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    for (uVar9 = *(uint64_t *)arg1; uVar9 < *(uint64_t *)(arg1 + 8); uVar9 = uVar9 + 0x14) {
        *(undefined *)(uVar9 + 0x12) = 0;
    }
    if (1 < (uint64_t)(((int64_t)(*(uint64_t *)(arg1 + 8) - *(int64_t *)arg1) >> 2) * -0x3333333333333333)) {
        func_0x000180163fc0();
        puVar1 = *(undefined8 **)(arg1 + 8);
code_r0x00018015c480:
        puVar14 = puVar1;
        iVar6 = *(int64_t *)arg1;
        if ((puVar14 != (undefined8 *)(iVar6 + 0x14U)) && ((undefined8 *)(iVar6 + 0x14U) <= puVar14)) {
            iVar2 = *(int32_t *)(puVar14 + -4);
            iVar3 = *(int32_t *)(puVar14 + -5);
            bVar20 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            bVar19 = iVar3 == iVar2;
            if (bVar19) {
                iVar4 = *(int32_t *)((int64_t)puVar14 + -0x1c);
                iVar5 = *(int32_t *)((int64_t)puVar14 + -0x24);
                bVar20 = SBORROW4(iVar5, iVar4);
                iVar8 = iVar5 - iVar4;
                bVar19 = iVar5 == iVar4;
            }
            iVar4 = *(int32_t *)((int64_t)puVar14 + -0x14);
            puVar1 = (undefined8 *)((int64_t)puVar14 + -0x14);
            iVar5 = *(int32_t *)((int64_t)puVar14 + -0xc);
            uVar18 = *(undefined8 *)((int64_t)puVar14 - ((uint64_t)(!bVar19 && bVar20 == iVar8 < 0) * 8 + 0x20));
            puVar13 = (undefined8 *)((int64_t)puVar14 + -0xc);
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar8 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar7 = *(int32_t *)(puVar14 + -1);
                iVar16 = *(int32_t *)(puVar14 + -2);
                bVar20 = SBORROW4(iVar16, iVar7);
                iVar8 = iVar16 - iVar7;
                bVar19 = iVar16 == iVar7;
            }
            puVar10 = puVar13;
            if (!bVar19 && bVar20 == iVar8 < 0) {
                puVar10 = puVar1;
            }
            iVar8 = (int32_t)*puVar10;
            iVar7 = (int32_t)uVar18;
            if (iVar7 == iVar8) {
                bVar19 = (int32_t)((uint64_t)*puVar10 >> 0x20) <= (int32_t)((uint64_t)uVar18 >> 0x20);
            } else {
                bVar19 = iVar7 != iVar8 && iVar8 <= iVar7;
            }
            if (!bVar19) goto code_r0x00018015c521;
            if (*(char *)((int64_t)puVar14 + -4) != '\0') {
                *(undefined *)(puVar14 + -3) = 1;
            }
            if (*(char *)((int64_t)puVar14 + -3) != '\0') {
                *(undefined *)((int64_t)puVar14 + -0x17) = 1;
            }
            goto code_r0x00018015c616;
        }
        uVar9 = 0;
        uVar15 = (*(int64_t *)(arg1 + 8) - iVar6 >> 2) * -0x3333333333333333;
        if (uVar15 != 0) {
            do {
                if (*(char *)(iVar6 + 0x10 + uVar9 * 0x14) != '\0') {
                    *(uint64_t *)(arg1 + 0x18) = uVar9;
                }
                if (*(char *)(iVar6 + 0x11 + uVar9 * 0x14) != '\0') {
                    *(uint64_t *)(arg1 + 0x20) = uVar9;
                }
                uVar9 = uVar9 + 1;
            } while (uVar9 < uVar15);
        }
    }
    return;
code_r0x00018015c521:
    puVar10 = puVar14 + -5;
    bVar20 = SBORROW4(iVar3, iVar2);
    iVar8 = iVar3 - iVar2;
    bVar19 = iVar3 == iVar2;
    if (bVar19) {
        iVar7 = *(int32_t *)((int64_t)puVar14 + -0x1c);
        iVar16 = *(int32_t *)((int64_t)puVar14 + -0x24);
        bVar20 = SBORROW4(iVar16, iVar7);
        iVar8 = iVar16 - iVar7;
        bVar19 = iVar16 == iVar7;
    }
    puVar12 = puVar14 + -4;
    if (!bVar19 && bVar20 == iVar8 < 0) {
        puVar12 = puVar10;
    }
    bVar19 = SBORROW4(iVar4, iVar5);
    iVar8 = iVar4 - iVar5;
    if (iVar4 == iVar5) {
        bVar19 = SBORROW4(*(int32_t *)(puVar14 + -2), *(int32_t *)(puVar14 + -1));
        iVar8 = *(int32_t *)(puVar14 + -2) - *(int32_t *)(puVar14 + -1);
    }
    puVar11 = puVar13;
    if (bVar19 != iVar8 < 0) {
        puVar11 = puVar1;
    }
    iVar7 = (int32_t)*puVar11;
    iVar16 = (int32_t)*puVar12;
    bVar20 = SBORROW4(iVar16, iVar7);
    iVar8 = iVar16 - iVar7;
    bVar19 = iVar16 == iVar7;
    if (bVar19) {
        iVar7 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        iVar16 = (int32_t)((uint64_t)*puVar12 >> 0x20);
        bVar20 = SBORROW4(iVar16, iVar7);
        iVar8 = iVar16 - iVar7;
        bVar19 = iVar16 == iVar7;
    }
    if (!bVar19 && bVar20 == iVar8 < 0) {
        uVar18 = *puVar1;
        iVar17 = (int32_t)uVar18;
        iVar7 = (int32_t)*(undefined8 *)((int64_t)puVar14 + -0xc);
        bVar19 = SBORROW4(iVar7, iVar17);
        iVar8 = iVar7 - iVar17;
        iVar16 = (int32_t)((uint64_t)uVar18 >> 0x20);
        if (iVar7 == iVar17) {
            iVar8 = (int32_t)((uint64_t)*(undefined8 *)((int64_t)puVar14 + -0xc) >> 0x20);
            bVar19 = SBORROW4(iVar8, iVar16);
            iVar8 = iVar8 - iVar16;
        }
        if (bVar19 == iVar8 < 0) {
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar8 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar4 = *(int32_t *)(puVar14 + -1);
                bVar20 = SBORROW4(iVar16, iVar4);
                iVar8 = iVar16 - iVar4;
                bVar19 = iVar16 == iVar4;
            }
            if (bVar19 || bVar20 != iVar8 < 0) {
                uVar18 = *puVar13;
            }
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            if (iVar3 == iVar2) {
                bVar19 = SBORROW4(*(int32_t *)((int64_t)puVar14 + -0x24), *(int32_t *)((int64_t)puVar14 + -0x1c));
                iVar8 = *(int32_t *)((int64_t)puVar14 + -0x24) - *(int32_t *)((int64_t)puVar14 + -0x1c);
            }
            puVar13 = puVar14 + -4;
            if (bVar19 != iVar8 < 0) {
                puVar13 = puVar10;
            }
        } else {
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar8 = iVar3 - iVar2;
            if (iVar3 == iVar2) {
                bVar19 = SBORROW4(*(int32_t *)((int64_t)puVar14 + -0x24), *(int32_t *)((int64_t)puVar14 + -0x1c));
                iVar8 = *(int32_t *)((int64_t)puVar14 + -0x24) - *(int32_t *)((int64_t)puVar14 + -0x1c);
            }
            puVar12 = puVar14 + -4;
            if (bVar19 != iVar8 < 0) {
                puVar12 = puVar10;
            }
            uVar18 = *puVar12;
            bVar20 = SBORROW4(iVar4, iVar5);
            iVar2 = iVar4 - iVar5;
            bVar19 = iVar4 == iVar5;
            if (bVar19) {
                iVar3 = *(int32_t *)(puVar14 + -1);
                bVar20 = SBORROW4(iVar16, iVar3);
                iVar2 = iVar16 - iVar3;
                bVar19 = iVar16 == iVar3;
            }
            if (!bVar19 && bVar20 == iVar2 < 0) {
                puVar13 = puVar1;
            }
        }
        puVar14[-5] = *puVar13;
        puVar14[-4] = uVar18;
        *(undefined *)((int64_t)puVar14 + -0x16) = 1;
        if (*(char *)((int64_t)puVar14 + -4) != '\0') {
            *(undefined *)(puVar14 + -3) = 1;
        }
        if (*(char *)((int64_t)puVar14 + -3) != '\0') {
            *(undefined *)((int64_t)puVar14 + -0x17) = 1;
        }
code_r0x00018015c616:
        func_0x000180498030(puVar1, puVar14, *(int64_t *)(arg1 + 8) - (int64_t)puVar14);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
    }
    goto code_r0x00018015c480;
}

// ============================================================
// Function: FUN_18015c690
// Address: 0x18015c690
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18015c690(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar3 = (int32_t)arg3;
    var_20h._4_4_ = (int32_t)((uint64_t)arg4 >> 0x20);
    var_18h._4_4_ = (int32_t)((uint64_t)arg3 >> 0x20);
    while (puVar2 = (undefined8 *)(arg2 + 0x14), puVar2 < *(undefined8 **)(arg1 + 8)) {
        iVar1 = (int32_t)((uint64_t)*puVar2 >> 0x20);
        iVar4 = (int32_t)*puVar2;
        if (iVar4 == iVar3) {
            iVar1 = (iVar1 - var_18h._4_4_) + var_20h._4_4_;
        }
        *(int32_t *)(arg2 + 0x18) = iVar1;
        *(int32_t *)puVar2 = ((int32_t)arg4 - iVar3) + iVar4;
        iVar1 = (int32_t)((uint64_t)*(undefined8 *)(arg2 + 0x1c) >> 0x20);
        iVar4 = (int32_t)*(undefined8 *)(arg2 + 0x1c);
        if (iVar4 == iVar3) {
            iVar1 = (iVar1 - var_18h._4_4_) + var_20h._4_4_;
        }
        *(int32_t *)(arg2 + 0x20) = iVar1;
        *(int32_t *)(arg2 + 0x1c) = (iVar4 - iVar3) + (int32_t)arg4;
        arg2 = (int64_t)puVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18015c720
// Address: 0x18015c720
// Size: 193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18015c720(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint64_t *puVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar5 = (uint32_t)arg4;
    uVar4 = (uint32_t)arg3;
    var_20h._4_4_ = (int32_t)((uint64_t)arg4 >> 0x20);
    var_18h._4_4_ = (int32_t)((uint64_t)arg3 >> 0x20);
code_r0x00018015c740:
    do {
        puVar3 = (uint64_t *)(arg2 + 0x14);
        if (*(uint64_t **)(arg1 + 8) <= puVar3) {
            return;
        }
        uVar1 = *puVar3;
        iVar6 = (int32_t)(uVar1 >> 0x20);
        if (uVar4 == uVar5) {
            if ((uint32_t)uVar1 == uVar5) {
                iVar6 = (iVar6 - var_20h._4_4_) + var_18h._4_4_;
            }
        } else {
            uVar2 = ((uint32_t)uVar1 - uVar5) + uVar4;
            uVar1 = (uint64_t)uVar2;
            if (uVar2 == uVar5) {
                iVar6 = iVar6 - var_20h._4_4_;
            }
        }
        uVar7 = *(uint64_t *)(arg2 + 0x1c);
        *(int32_t *)(arg2 + 0x18) = iVar6;
        iVar6 = (int32_t)(uVar7 >> 0x20);
        *(int32_t *)puVar3 = (int32_t)uVar1;
        uVar2 = (uint32_t)uVar7;
        if (uVar4 == uVar5) {
            if (uVar2 == uVar5) {
                *(uint32_t *)(arg2 + 0x1c) = uVar2;
                *(int32_t *)(arg2 + 0x20) = (iVar6 - var_20h._4_4_) + var_18h._4_4_;
                arg2 = (int64_t)puVar3;
                goto code_r0x00018015c740;
            }
        } else {
            uVar2 = (uVar4 - uVar5) + uVar2;
            uVar7 = (uint64_t)uVar2;
            if (uVar2 == uVar5) {
                iVar6 = iVar6 - var_20h._4_4_;
            }
        }
        *(int32_t *)(arg2 + 0x1c) = (int32_t)uVar7;
        *(int32_t *)(arg2 + 0x20) = iVar6;
        arg2 = (int64_t)puVar3;
    } while( true );
}

// ============================================================
// Function: FUN_18015c7f0
// Address: 0x18015c7f0
// Size: 2322 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b6h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

int64_t fcn.18015c7f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    code *pcVar5;
    uint32_t uVar6;
    char cVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    int64_t **ppiVar13;
    uint16_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t **ppiVar17;
    int64_t **ppiVar18;
    undefined *puVar19;
    undefined *puVar20;
    uint8_t *puVar21;
    uint8_t *puVar22;
    int64_t iVar23;
    int64_t **ppiVar24;
    undefined4 *puVar25;
    int64_t **ppiVar26;
    int64_t iVar27;
    uint64_t uVar28;
    int32_t iVar29;
    int64_t **ppiVar30;
    uint8_t *puVar31;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_f0;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 var_b8h;
    int64_t var_b4h;
    undefined4 uStack_ac;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    undefined8 var_68h;
    undefined8 var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar19 = auStack_e8;
    uVar12 = (uint32_t)arg3;
    uVar28 = (uint64_t)(int32_t)uVar12;
    ppiVar17 = (int64_t **)(uVar28 * 0x38 + *(int64_t *)arg1);
    uVar9 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    puVar20 = auStack_e8;
    if (uVar28 <= uVar9 && uVar9 - uVar28 != 0) {
        var_18h._4_4_ = (undefined4)((uint64_t)arg3 >> 0x20);
        var_c0h = func_0x00018015d7b0(arg1, ppiVar17, var_18h._4_4_);
        uVar28 = arg3 & 0xffffffff;
        puVar31 = *(uint8_t **)arg4 + *(int64_t *)(arg4 + 8);
        puVar21 = *(uint8_t **)arg4;
        uVar9 = var_c0h;
        var_c8h._0_4_ = uVar12;
code_r0x00018015c884:
        do {
            ppiVar24 = (int64_t **)0x0;
            iVar29 = (int32_t)uVar28;
            puVar20 = auStack_e8;
            piVar11 = (int64_t *)arg1;
            if (puVar21 == puVar31) goto code_r0x00018015d04c;
            cVar7 = -1;
            if (puVar31 <= puVar21) {
                cVar7 = '\x01';
            }
            puVar20 = auStack_e8;
            if (-1 < cVar7) goto code_r0x00018015d04c;
            cVar7 = -1;
            if (puVar31 <= puVar21) {
                cVar7 = '\x01';
            }
            if ((-1 < cVar7) || (uVar14 = (uint16_t)(char)*puVar21, (char)*puVar21 < '\0')) {
                puVar22 = puVar21 + 1;
                if (puVar22 != puVar31) {
                    cVar7 = -1;
                    if (puVar31 <= puVar22) {
                        cVar7 = '\x01';
                    }
                    if ((cVar7 < '\0') && ((*puVar21 & 0xe0) == 0xc0)) {
                        uVar14 = (uint16_t)(*puVar21 & 0x1f) << 6 | (uint16_t)(*puVar22 & 0x3f);
                        puVar22 = puVar21 + 2;
                        goto code_r0x00018015c95b;
                    }
                }
                puVar1 = puVar21 + 2;
                if (puVar1 != puVar31) {
                    cVar7 = -1;
                    if (puVar31 <= puVar1) {
                        cVar7 = '\x01';
                    }
                    if ((cVar7 < '\0') && ((*puVar21 & 0xf0) == 0xe0)) {
                        uVar14 = ((uint16_t)(*puVar21 & 0xf) << 6 | (uint16_t)(*puVar22 & 0x3f)) << 6 |
                                 (uint16_t)(*puVar1 & 0x3f);
                        puVar22 = puVar21 + 3;
                        goto code_r0x00018015c95b;
                    }
                }
                if (puVar21 + 3 != puVar31) {
                    cVar7 = -1;
                    if (puVar31 <= puVar21 + 3) {
                        cVar7 = '\x01';
                    }
                    if ((cVar7 < '\0') && ((*puVar21 & 0xf8) == 0xf0)) {
                        puVar22 = puVar21 + 4;
                    }
                }
                uVar14 = 0xfffd;
code_r0x00018015cec7:
                puVar21 = puVar22;
                if ((*(char *)(arg1 + 0x1c) == '\0') || (uVar14 != 9)) {
                    if (uVar14 == 0xd) goto code_r0x00018015c884;
                    uVar8 = (undefined4)var_b4h;
                    var_c0h = uVar9 + 1;
                    piVar11 = (int64_t *)((int64_t)*ppiVar17 + uVar9 * 4);
                    piVar10 = ppiVar17[1];
                    if (piVar10 == ppiVar17[2]) {
                        func_0x000180164e00(ppiVar17, piVar11, &var_b4h);
                    } else {
                        if (piVar11 == piVar10) {
                            *(undefined4 *)piVar10 = (undefined4)var_b4h;
                            ppiVar17[1] = (int64_t *)((int64_t)ppiVar17[1] + 4);
                            uVar28 = (uint64_t)(uint32_t)var_c8h;
                            uVar9 = var_c0h;
                            goto code_r0x00018015c884;
                        }
                        *(undefined4 *)piVar10 = *(undefined4 *)((int64_t)piVar10 - 4U);
                        ppiVar17[1] = (int64_t *)((int64_t)ppiVar17[1] + 4);
                        func_0x000180498030((int64_t)piVar10 -
                                            ((int64_t)(undefined4 *)((int64_t)piVar10 - 4U) - (int64_t)piVar11), piVar11
                                           );
                        *(undefined4 *)piVar11 = uVar8;
                    }
                } else {
                    uVar16 = (uint64_t)*(int32_t *)(arg1 + 0x18);
                    uVar15 = uVar9 % uVar16;
                    if (uVar16 == uVar15) goto code_r0x00018015c884;
                    do {
                        var_b8h = CONCAT13(var_b8h._3_1_, 0x20);
                        uVar8 = var_b8h;
                        var_c0h = uVar9 + 1;
                        piVar11 = (int64_t *)((int64_t)*ppiVar17 + uVar9 * 4);
                        piVar10 = ppiVar17[1];
                        if (piVar10 == ppiVar17[2]) {
                            func_0x000180164e00(ppiVar17, piVar11, &var_b8h);
                        } else if (piVar11 == piVar10) {
                            *(undefined4 *)piVar10 = var_b8h;
                            ppiVar17[1] = (int64_t *)((int64_t)ppiVar17[1] + 4);
                        } else {
                            *(undefined4 *)piVar10 = *(undefined4 *)((int64_t)piVar10 - 4U);
                            ppiVar17[1] = (int64_t *)((int64_t)ppiVar17[1] + 4);
                            func_0x000180498030((int64_t)piVar10 -
                                                ((int64_t)(undefined4 *)((int64_t)piVar10 - 4U) - (int64_t)piVar11), 
                                                piVar11);
                            *(undefined4 *)piVar11 = uVar8;
                        }
                        ppiVar24 = (int64_t **)((int64_t)ppiVar24 + 1);
                        uVar9 = var_c0h;
                    } while (ppiVar24 < (int64_t **)(uVar16 - uVar15));
                }
                uVar28 = (uint64_t)(uint32_t)var_c8h;
                uVar9 = var_c0h;
                goto code_r0x00018015c884;
            }
            puVar22 = puVar21 + 1;
code_r0x00018015c95b:
            if (uVar14 != 10) goto code_r0x00018015cec7;
            _var_98h = ZEXT816(0);
            _var_88h = (unkuint9)0;
            var_80h._1_7_ = 0;
            _var_78h = ZEXT812(0);
            var_70h._4_1_ = 1;
            var_70h._5_3_ = 0;
            var_68h = 0;
            iVar27 = *(int64_t *)arg1;
            ppiVar30 = (int64_t **)(((int64_t)iVar29 + 1) * 0x38);
            ppiVar17 = (int64_t **)((int64_t)ppiVar30 + iVar27);
            ppiVar26 = *(int64_t ***)(arg1 + 8);
            if (ppiVar26 == *(int64_t ***)(arg1 + 0x10)) {
                iVar23 = ((int64_t)ppiVar26 - iVar27 >> 3) * 0x6db6db6db6db6db7;
                if (iVar23 == 0x492492492492492) {
                    func_0x000180010010();
                    puVar20 = auStack_e8;
                    break;
                }
                uVar16 = ((int64_t)*(int64_t ***)(arg1 + 0x10) - iVar27 >> 3) * 0x6db6db6db6db6db7;
                uVar28 = 0x492492492492492 - (uVar16 >> 1);
                if (uVar28 <= uVar16 && uVar16 - uVar28 != 0) {
code_r0x00018015d0fc:
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    iVar27 = (*pcVar5)();
                    return iVar27;
                }
                unique0x00003100 = (int64_t *)(iVar23 + 1);
                piVar10 = (int64_t *)(uVar16 + (uVar16 >> 1));
                piVar11 = unique0x00003100;
                if (unique0x00003100 <= piVar10) {
                    piVar11 = piVar10;
                }
                if ((int64_t *)0x492492492492492 < piVar11) goto code_r0x00018015d0fc;
                uVar28 = (int64_t)piVar11 * 0x38;
                if (uVar28 != 0) {
                    if (uVar28 < 0x1000) {
                        ppiVar24 = (int64_t **)func_0x000180459890();
                    } else {
                        if (uVar28 + 0x27 <= uVar28) goto code_r0x00018015d0fc;
                        piVar10 = (int64_t *)func_0x000180459890(uVar28 + 0x27);
                        if (piVar10 == (int64_t *)0x0) {
code_r0x00018015d03e:
                            iVar29 = (int32_t)ppiVar30;
                            pcVar5 = (code *)swi(0x29);
                            (*pcVar5)(5);
                            puVar19 = auStack_e0;
code_r0x00018015d045:
                            pcVar5 = (code *)swi(0x29);
                            (*pcVar5)(5);
                            puVar20 = puVar19 + 8;
                            goto code_r0x00018015d04c;
                        }
                        ppiVar24 = (int64_t **)((int64_t)piVar10 + 0x27U & 0xffffffffffffffe0);
                        ppiVar24[-1] = piVar10;
                    }
                }
                ppiVar18 = ppiVar24 + ((int64_t)ppiVar30 / 0x38) * 7;
                *ppiVar18 = (int64_t *)0x0;
                ppiVar18[1] = (int64_t *)0x0;
                ppiVar18[2] = (int64_t *)0x0;
                *(undefined *)(ppiVar18 + 3) = 0;
                ppiVar18[4] = (int64_t *)0x0;
                *(undefined4 *)(ppiVar18 + 5) = 0;
                *(undefined *)((int64_t)ppiVar18 + 0x2c) = 1;
                ppiVar18[6] = (int64_t *)0x0;
                ppiVar30 = *(int64_t ***)(arg1 + 8);
                ppiVar13 = *(int64_t ***)arg1;
                ppiVar26 = ppiVar24;
                if (ppiVar17 != ppiVar30) {
                    func_0x00018014fd20(*(int64_t ***)arg1, ppiVar17, ppiVar24);
                    ppiVar26 = ppiVar18 + 7;
                    ppiVar30 = *(int64_t ***)(arg1 + 8);
                    ppiVar13 = ppiVar17;
                }
                func_0x00018014fd20(ppiVar13, ppiVar30, ppiVar26);
                func_0x00018014fd90(arg1, ppiVar24, stack0xffffffffffffff50, piVar11);
            } else {
                ppiVar18 = ppiVar17;
                if (ppiVar17 == ppiVar26) {
                    *ppiVar26 = (int64_t *)0x0;
                    ppiVar26[1] = (int64_t *)0x0;
                    ppiVar26[2] = (int64_t *)0x0;
                    *(undefined *)(ppiVar26 + 3) = 0;
                    ppiVar26[4] = (int64_t *)0x0;
                    *(undefined4 *)(ppiVar26 + 5) = 0;
                    *(undefined *)((int64_t)ppiVar26 + 0x2c) = 1;
                    ppiVar26[6] = (int64_t *)0x0;
                    *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x38;
                } else {
                    var_90h = 0;
                    var_98h = arg1;
                    _var_88h = ZEXT816(0);
                    _var_78h = ZEXT816(0);
                    var_68h = 0x100000000;
                    var_60h = 0;
                    ppiVar24 = ppiVar26 + -7;
                    piVar10 = ppiVar26[-5];
                    ppiVar26[-5] = (int64_t *)0x0;
                    piVar2 = ppiVar26[-6];
                    ppiVar26[-6] = (int64_t *)0x0;
                    piVar3 = *ppiVar24;
                    *ppiVar24 = (int64_t *)0x0;
                    *ppiVar26 = piVar3;
                    ppiVar26[1] = piVar2;
                    ppiVar26[2] = piVar10;
                    *(undefined *)(ppiVar26 + 3) = *(undefined *)(ppiVar26 + -4);
                    ppiVar26[4] = ppiVar26[-3];
                    *(undefined4 *)(ppiVar26 + 5) = *(undefined4 *)(ppiVar26 + -2);
                    *(undefined *)((int64_t)ppiVar26 + 0x2c) = *(undefined *)((int64_t)ppiVar26 + -0xc);
                    ppiVar26[6] = ppiVar26[-1];
                    *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x38;
                    while (ppiVar17 != ppiVar24) {
                        ppiVar30 = ppiVar24 + -7;
                        ppiVar13 = ppiVar26 + -7;
                        if (ppiVar13 != ppiVar30) {
                            piVar10 = *ppiVar13;
                            if (piVar10 != (int64_t *)0x0) {
                                uVar28 = ((int64_t)ppiVar26[-5] - (int64_t)piVar10 >> 2) * 4;
                                if (0xfff < uVar28) {
                                    if (0x1f < (uint64_t)((int64_t)piVar10 + (-8 - (int64_t)(int64_t *)piVar10[-1])))
                                    goto code_r0x00018015d03e;
                                    uVar28 = uVar28 + 0x27;
                                    piVar10 = (int64_t *)piVar10[-1];
                                }
                                func_0x000180459c3c(piVar10, uVar28);
                                *ppiVar13 = (int64_t *)0x0;
                                ppiVar26[-6] = (int64_t *)0x0;
                                ppiVar26[-5] = (int64_t *)0x0;
                            }
                            *ppiVar13 = *ppiVar30;
                            ppiVar26[-6] = ppiVar24[-6];
                            ppiVar26[-5] = ppiVar24[-5];
                            *ppiVar30 = (int64_t *)0x0;
                            ppiVar24[-6] = (int64_t *)0x0;
                            ppiVar24[-5] = (int64_t *)0x0;
                        }
                        *(undefined *)(ppiVar26 + -4) = *(undefined *)(ppiVar24 + -4);
                        ppiVar26[-3] = ppiVar24[-3];
                        *(undefined4 *)(ppiVar26 + -2) = *(undefined4 *)(ppiVar24 + -2);
                        *(undefined *)((int64_t)ppiVar26 + -0xc) = *(undefined *)((int64_t)ppiVar24 + -0xc);
                        ppiVar26[-1] = ppiVar24[-1];
                        ppiVar26 = ppiVar13;
                        ppiVar24 = ppiVar30;
                    }
                    func_0x000180164cd0(ppiVar17, &var_90h);
                    func_0x00018002ee50(&var_90h);
                }
            }
            uVar6 = (uint32_t)var_c8h;
            uVar9 = (uint64_t)(uint32_t)var_c8h;
            if (*(int64_t *)(arg1 + 0x60) != 0) {
                stack0xffffffffffffff50 = (int64_t *)CONCAT44(uStack_ac, (uint32_t)var_c8h + 1);
                piVar11 = *(int64_t **)(arg1 + 0x60);
                if (piVar11 == (int64_t *)0x0) {
                    func_0x000180454690();
                    pcVar5 = (code *)swi(3);
                    iVar27 = (*pcVar5)();
                    return iVar27;
                }
                piVar11 = (int64_t *)(**(code **)(*piVar11 + 0x10))(piVar11, (int64_t)&var_b4h + 4);
                ppiVar18[6] = piVar11;
            }
            var_48h = (int64_t)(int32_t)uVar6 * 0x38 + *(int64_t *)arg1;
            ppiVar17 = (int64_t **)(((int64_t)(int32_t)uVar6 + 1) * 0x38 + *(int64_t *)arg1);
            var_a8h = var_c0h * 4;
            puVar25 = (undefined4 *)(*(int64_t *)var_48h + var_a8h);
            piVar11 = (int64_t *)var_48h;
            while( true ) {
                iVar29 = (int32_t)uVar9;
                puVar4 = (undefined4 *)piVar11[1];
                if (puVar25 == puVar4) break;
                cVar7 = -1;
                if (puVar4 <= puVar25) {
                    cVar7 = '\x01';
                }
                if (-1 < cVar7) break;
                unique0x0000c280 = ppiVar17[1];
                if (unique0x0000c280 == ppiVar17[2]) {
                    piVar11 = (int64_t *)((int64_t)unique0x0000c280 - (int64_t)*ppiVar17 >> 2);
                    uVar9 = 0x3fffffffffffffff;
                    if (piVar11 == (int64_t *)0x3fffffffffffffff) {
                        func_0x000180010010();
                        goto code_r0x00018015d0fc;
                    }
                    uVar28 = (int64_t)ppiVar17[2] - (int64_t)*ppiVar17 >> 2;
                    if (0x3fffffffffffffff - (uVar28 >> 1) < uVar28) {
code_r0x00018015d0f0:
                        func_0x000180004720();
                        pcVar5 = (code *)swi(3);
                        iVar27 = (*pcVar5)();
                        return iVar27;
                    }
                    var_50h = (int64_t)piVar11 + 1;
                    uVar28 = uVar28 + (uVar28 >> 1);
                    var_c0h = var_50h;
                    if ((uint64_t)var_50h <= uVar28) {
                        var_c0h = uVar28;
                    }
                    if (0x3fffffffffffffff < (uint64_t)var_c0h) goto code_r0x00018015d0f0;
                    uVar28 = var_c0h * 4;
                    if (uVar28 == 0) {
                        uVar9 = 0;
                    } else if (uVar28 < 0x1000) {
                        uVar9 = func_0x000180459890();
                    } else {
                        if (uVar28 + 0x27 <= uVar28) goto code_r0x00018015d0f0;
                        iVar27 = func_0x000180459890(uVar28 + 0x27);
                        if (iVar27 == 0) goto code_r0x00018015d045;
                        uVar9 = iVar27 + 0x27U & 0xffffffffffffffe0;
                        *(int64_t *)(uVar9 - 8) = iVar27;
                    }
                    piVar10 = stack0xffffffffffffff50;
                    var_58h = uVar9 + (int64_t)piVar11 * 4;
                    *(undefined4 *)var_58h = *puVar25;
                    piVar11 = *ppiVar17;
                    if (stack0xffffffffffffff50 == ppiVar17[1]) {
                        iVar27 = (int64_t)ppiVar17[1] - (int64_t)piVar11;
                        uVar28 = uVar9;
                        piVar10 = piVar11;
                    } else {
                        func_0x000180498030(uVar9, piVar11, (int64_t)stack0xffffffffffffff50 - (int64_t)piVar11);
                        iVar27 = (int64_t)ppiVar17[1] - (int64_t)piVar10;
                        uVar28 = var_58h + 4;
                    }
                    func_0x000180498030(uVar28, piVar10, iVar27);
                    func_0x000180030d40(ppiVar17, uVar9, var_50h, var_c0h);
                    puVar25 = puVar25 + 1;
                    piVar11 = (int64_t *)var_48h;
                } else {
                    *(undefined4 *)unique0x0000c280 = *puVar25;
                    ppiVar17[1] = (int64_t *)((int64_t)ppiVar17[1] + 4);
                    puVar25 = puVar25 + 1;
                }
            }
            uVar28 = (uint64_t)((uint32_t)var_c8h + 1);
            if ((undefined4 *)(var_a8h + *piVar11) != puVar4) {
                piVar11[1] = (int64_t)(undefined4 *)(var_a8h + *piVar11);
            }
            var_c0h = 0;
            puVar21 = puVar22;
            uVar9 = 0;
            var_c8h._0_4_ = (uint32_t)var_c8h + 1;
        } while( true );
    }
code_r0x00018015d0e4:
    *(undefined8 *)(puVar20 + -8) = 0x18015d0e9;
    func_0x000180060370();
    pcVar5 = (code *)swi(3);
    iVar27 = (*pcVar5)();
    return iVar27;
code_r0x00018015d04c:
    iVar27 = *piVar11;
    *(undefined8 *)(puVar20 + -8) = 0x18015d06f;
    uVar8 = func_0x000180150020(piVar11, ((int64_t)ppiVar17 - iVar27 >> 3) * 0x6db6db6db6db6db7 & 0xffffffff, uVar9);
    *(int32_t *)arg2 = iVar29;
    *(undefined4 *)(arg2 + 4) = uVar8;
    uVar9 = arg3 & 0xffffffff;
    while( true ) {
        if (iVar29 < (int32_t)uVar12) {
            *(undefined8 *)(puVar20 + -8) = 0x18015d0bb;
            func_0x00018015d710(piVar11, arg3 & 0xffffffff, iVar29);
            *(undefined *)((int64_t)piVar11 + 0x24) = 1;
            return arg2;
        }
        uVar16 = (uint64_t)(int32_t)uVar9;
        uVar28 = (piVar11[1] - *piVar11 >> 3) * 0x6db6db6db6db6db7;
        if (uVar28 < uVar16 || uVar28 - uVar16 == 0) break;
        *(undefined *)(uVar16 * 0x38 + 0x2c + *piVar11) = 1;
        uVar12 = (int32_t)uVar9 + 1;
        uVar9 = (uint64_t)uVar12;
    }
    goto code_r0x00018015d0e4;
}

// ============================================================
// Function: FUN_18015d110
// Address: 0x18015d110
// Size: 830 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18015d110(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint64_t uVar12;
    undefined *puVar13;
    undefined *puVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    int32_t iVar17;
    int64_t *piVar18;
    int64_t *piVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar13 = auStack_58;
    iVar11 = (int32_t)arg2;
    uVar4 = (uint64_t)iVar11;
    iVar10 = *(int64_t *)arg1;
    uVar9 = (*(int64_t *)(arg1 + 8) - iVar10 >> 3) * 0x6db6db6db6db6db7;
    puVar14 = auStack_58;
    var_10h = arg2;
    var_18h = arg3;
    if (uVar9 < uVar4 || uVar9 - uVar4 == 0) {
code_r0x00018015d448:
        *(undefined8 *)(puVar14 + -8) = 0x18015d44d;
        func_0x000180060370();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar17 = (int32_t)arg3;
    uVar5 = (uint64_t)iVar17;
    piVar18 = (int64_t *)(uVar4 * 0x38 + iVar10);
    puVar14 = auStack_58;
    if (uVar9 < uVar5 || uVar9 - uVar5 == 0) goto code_r0x00018015d448;
    var_10h._4_4_ = (undefined4)((uint64_t)arg2 >> 0x20);
    uVar3 = var_10h._4_4_;
    piVar16 = (int64_t *)(iVar10 + uVar5 * 0x38);
    iVar6 = func_0x00018015d7b0(arg1, piVar18, uVar3);
    iVar7 = func_0x00018015d7b0(arg1, piVar16, var_18h._4_4_);
    iVar10 = *piVar18;
    if (iVar11 == iVar17) {
        iVar7 = iVar10 + iVar7 * 4;
        iVar10 = iVar10 + iVar6 * 4;
        if (iVar10 != iVar7) {
            iVar6 = piVar18[1];
            func_0x000180498030(iVar10, iVar7, iVar6 - iVar7);
            piVar18[1] = (iVar6 - iVar7) + iVar10;
        }
    } else {
        iVar10 = iVar10 + iVar6 * 4;
        if (iVar10 != piVar18[1]) {
            piVar18[1] = iVar10;
        }
        iVar6 = *piVar16;
        iVar10 = iVar6 + iVar7 * 4;
        if (iVar6 != iVar10) {
            iVar7 = piVar16[1];
            func_0x000180498030(iVar6, iVar10, iVar7 - iVar10);
            piVar16[1] = (iVar7 - iVar10) + iVar6;
        }
        func_0x0001801649f0(piVar18, piVar18[1], *piVar16, piVar16[1] - *piVar16 >> 2);
        iVar2 = iVar11 + 1;
        if (*(int64_t *)(arg1 + 0xa0) != 0) {
            for (; iVar2 <= iVar17; iVar2 = iVar2 + 1) {
                uVar9 = (uint64_t)iVar2;
                uVar4 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
                puVar14 = auStack_58;
                if (uVar4 < uVar9 || uVar4 - uVar9 == 0) goto code_r0x00018015d448;
                var_10h._4_4_ = (undefined4)((uint64_t)var_10h >> 0x20);
                var_10h = CONCAT44(var_10h._4_4_, iVar2);
                var_8h = *(int64_t *)(uVar9 * 0x38 + 0x30 + *(int64_t *)arg1);
                piVar16 = *(int64_t **)(arg1 + 0xa0);
                if (piVar16 == (int64_t *)0x0) {
                    func_0x000180454690();
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                (**(code **)(*piVar16 + 0x10))(piVar16, &var_10h, &var_8h);
            }
        }
        piVar16 = (int64_t *)((int64_t)(iVar11 + 1) * 0x38 + *(int64_t *)arg1);
        piVar19 = (int64_t *)(*(int64_t *)arg1 + 0x38 + uVar5 * 0x38);
        if (piVar16 != piVar19) {
            piVar15 = *(int64_t **)(arg1 + 8);
            for (; piVar19 != piVar15; piVar19 = piVar19 + 7) {
                if (piVar16 != piVar19) {
                    iVar10 = *piVar16;
                    if (iVar10 != 0) {
                        uVar4 = (piVar16[2] - iVar10 >> 2) * 4;
                        if (0xfff < uVar4) {
                            if (0x1f < (iVar10 - *(int64_t *)(iVar10 + -8)) - 8U) {
                                uVar4 = 5;
                                pcVar1 = (code *)swi(0x29);
                                (*pcVar1)();
                                puVar13 = auStack_50;
                                goto code_r0x00018015d3dc;
                            }
                            uVar4 = uVar4 + 0x27;
                            iVar10 = *(int64_t *)(iVar10 + -8);
                        }
                        func_0x000180459c3c(iVar10, uVar4);
                        iVar10 = 0;
                        *piVar16 = 0;
                        piVar16[1] = 0;
                        piVar16[2] = 0;
                    }
                    *piVar16 = *piVar19;
                    piVar16[1] = piVar19[1];
                    piVar16[2] = piVar19[2];
                    *piVar19 = iVar10;
                    piVar19[1] = iVar10;
                    piVar19[2] = iVar10;
                }
                *(undefined *)(piVar16 + 3) = *(undefined *)(piVar19 + 3);
                piVar16[4] = piVar19[4];
                *(undefined4 *)(piVar16 + 5) = *(undefined4 *)(piVar19 + 5);
                *(undefined *)((int64_t)piVar16 + 0x2c) = *(undefined *)((int64_t)piVar19 + 0x2c);
                piVar16[6] = piVar19[6];
                piVar16 = piVar16 + 7;
            }
            piVar19 = *(int64_t **)(arg1 + 8);
            for (piVar15 = piVar16; piVar15 != piVar19; piVar15 = piVar15 + 7) {
                func_0x00018002ee50(piVar15);
            }
            *(int64_t **)(arg1 + 8) = piVar16;
        }
    }
    piVar19 = (int64_t *)0x6db6db6db6db6db7;
    piVar18[4] = 0;
    uVar4 = arg2 & 0xffffffff;
    if (iVar11 == (int32_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * -0x49249249 + -1) {
        uVar9 = arg2 & 0xffffffff;
        puVar13 = auStack_58;
    } else {
code_r0x00018015d3dc:
        uVar9 = (uint64_t)(iVar11 + 1U);
        if ((int32_t)(iVar11 + 1U) < iVar11) goto code_r0x00018015d41b;
    }
    do {
        uVar12 = (uint64_t)(int32_t)uVar4;
        uVar5 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * (int64_t)piVar19;
        puVar14 = puVar13;
        if (uVar5 < uVar12 || uVar5 - uVar12 == 0) goto code_r0x00018015d448;
        uVar8 = (int32_t)uVar4 + 1;
        uVar4 = (uint64_t)uVar8;
        *(undefined *)(uVar12 * 0x38 + 0x2c + *(int64_t *)arg1) = 1;
    } while ((int32_t)uVar8 <= (int32_t)uVar9);
code_r0x00018015d41b:
    *(undefined8 *)(puVar13 + -8) = 0x18015d428;
    func_0x00018015d710(arg1, arg2 & 0xffffffff, arg3 & 0xffffffff);
    *(undefined *)(arg1 + 0x24) = 1;
    return;
}

// ============================================================
// Function: FUN_18015d450
// Address: 0x18015d450
// Size: 570 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

int64_t fcn.18015d450(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint16_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t unaff_RDI;
    int64_t var_18h;
    int64_t var_24h;
    int64_t var_48h;
    
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    uVar4 = (uint64_t)(int32_t)arg3;
    iVar7 = *(int64_t *)arg1;
    uVar10 = (*(int64_t *)(arg1 + 8) - iVar7 >> 3) * 0x6db6db6db6db6db7;
    if (uVar4 <= uVar10 && uVar10 - uVar4 != 0) {
        var_18h._4_4_ = (undefined4)((uint64_t)arg3 >> 0x20);
        uVar4 = fcn.18015d7b0(arg1, uVar4 * 0x38 + iVar7, var_18h._4_4_, arg4, 1);
        uVar5 = (uint64_t)(int32_t)arg4;
        if (uVar5 <= uVar10 && uVar10 - uVar5 != 0) {
            var_24h._0_4_ = (undefined4)((uint64_t)arg4 >> 0x20);
            uVar5 = fcn.18015d7b0(arg1, uVar5 * 0x38 + iVar7, (undefined4)var_24h);
            uVar10 = arg3;
            while( true ) {
                iVar9 = (int32_t)uVar10;
                if (((int32_t)arg4 <= iVar9) && (uVar5 <= uVar4)) {
                    return arg2;
                }
                iVar7 = *(int64_t *)arg1;
                uVar8 = (uint64_t)iVar9;
                uVar6 = (*(int64_t *)(arg1 + 8) - iVar7 >> 3) * 0x6db6db6db6db6db7;
                if (uVar6 < uVar8 || uVar6 - uVar8 == 0) break;
                iVar2 = *(int64_t *)(uVar8 * 0x38 + iVar7);
                if (uVar4 < (uint64_t)(*(int64_t *)(uVar8 * 0x38 + 8 + iVar7) - iVar2 >> 2)) {
                    uVar1 = *(uint16_t *)(iVar2 + uVar4 * 4);
                    if ((uVar1 < 0x80) || (0x7ff < uVar1)) {
                        fcn.18000d970(unaff_RDI);
                        uVar4 = uVar4 + 1;
                    } else {
                        fcn.18000d970(unaff_RDI);
                        uVar4 = uVar4 + 1;
                    }
                } else {
                    uVar4 = *(uint64_t *)(arg2 + 0x10);
                    if (uVar4 < *(uint64_t *)(arg2 + 0x18)) {
                        *(uint64_t *)(arg2 + 0x10) = uVar4 + 1;
                        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                            *(undefined2 *)(uVar4 + arg2) = 10;
                            uVar4 = 0;
                            uVar10 = (uint64_t)(iVar9 + 1);
                        } else {
                            *(undefined2 *)(uVar4 + *(int64_t *)arg2) = 10;
                            uVar4 = 0;
                            uVar10 = (uint64_t)(iVar9 + 1);
                        }
                    } else {
                        fcn.18000f010(arg2, 1, arg3 & 0xff, 0x6db6db6db6db6d0a);
                        uVar4 = 0;
                        uVar10 = (uint64_t)(iVar9 + 1);
                    }
                }
            }
        }
    }
    fcn.180060370();
    pcVar3 = (code *)swi(3);
    iVar7 = (*pcVar3)();
    return iVar7;
}

// ============================================================
// Function: FUN_18015d690
// Address: 0x18015d690
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

uint64_t fcn.18015d690(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar4 = (uint64_t)(int32_t)arg2;
    uVar2 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar2 < uVar4 || uVar2 - uVar4 == 0) {
        fcn.180060370();
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    var_10h._4_4_ = (undefined4)((uint64_t)arg2 >> 0x20);
    piVar3 = (int64_t *)(uVar4 * 0x38 + *(int64_t *)arg1);
    uVar2 = fcn.18015d7b0(arg1, piVar3, var_10h._4_4_);
    if (uVar2 < (uint64_t)(piVar3[1] - *piVar3 >> 2)) {
        return (uint64_t)*(uint16_t *)(*piVar3 + uVar2 * 4);
    }
    return 0xfffd;
}

// ============================================================
// Function: FUN_18015d6bd
// Address: 0x18015d6bd
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

uint64_t fcn.18015d690(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar4 = (uint64_t)(int32_t)arg2;
    uVar2 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar2 < uVar4 || uVar2 - uVar4 == 0) {
        fcn.180060370();
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    var_10h._4_4_ = (undefined4)((uint64_t)arg2 >> 0x20);
    piVar3 = (int64_t *)(uVar4 * 0x38 + *(int64_t *)arg1);
    uVar2 = fcn.18015d7b0(arg1, piVar3, var_10h._4_4_);
    if (uVar2 < (uint64_t)(piVar3[1] - *piVar3 >> 2)) {
        return (uint64_t)*(uint16_t *)(*piVar3 + uVar2 * 4);
    }
    return 0xfffd;
}

// ============================================================
// Function: FUN_18015d6ee
// Address: 0x18015d6ee
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

uint64_t fcn.18015d690(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar4 = (uint64_t)(int32_t)arg2;
    uVar2 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar2 < uVar4 || uVar2 - uVar4 == 0) {
        fcn.180060370();
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    var_10h._4_4_ = (undefined4)((uint64_t)arg2 >> 0x20);
    piVar3 = (int64_t *)(uVar4 * 0x38 + *(int64_t *)arg1);
    uVar2 = fcn.18015d7b0(arg1, piVar3, var_10h._4_4_);
    if (uVar2 < (uint64_t)(piVar3[1] - *piVar3 >> 2)) {
        return (uint64_t)*(uint16_t *)(*piVar3 + uVar2 * 4);
    }
    return 0xfffd;
}

// ============================================================
// Function: FUN_18015d710
// Address: 0x18015d710
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18015d710(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int16_t **ppiVar1;
    uint64_t uVar2;
    int16_t *piVar3;
    int32_t iVar4;
    int16_t **ppiVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    ppiVar5 = (int16_t **)((int64_t)(int32_t)arg2 * 0x38 + *(int64_t *)arg1);
    while( true ) {
        uVar2 = *(uint64_t *)arg1;
        ppiVar1 = (int16_t **)(uVar2 + (int64_t)(int32_t)arg3 * 0x38);
        if ((ppiVar5 != ppiVar1) && (ppiVar1 <= ppiVar5)) break;
        piVar3 = *ppiVar5;
        iVar4 = 0;
        while (piVar3 < ppiVar5[1]) {
            if (*piVar3 == 9) {
                iVar4 = iVar4 + (*(int32_t *)(arg1 + 0x18) - iVar4 % *(int32_t *)(arg1 + 0x18));
                piVar3 = piVar3 + 2;
            } else {
                iVar4 = iVar4 + 1;
                piVar3 = piVar3 + 2;
            }
        }
        *(int32_t *)(ppiVar5 + 5) = iVar4;
        ppiVar5 = ppiVar5 + 7;
    }
    *(undefined4 *)(arg1 + 0x20) = 0;
    iVar4 = 0;
    for (; uVar2 < *(uint64_t *)(arg1 + 8); uVar2 = uVar2 + 0x38) {
        if (iVar4 < *(int32_t *)(uVar2 + 0x28)) {
            iVar4 = *(int32_t *)(uVar2 + 0x28);
        }
        *(int32_t *)(arg1 + 0x20) = iVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18015d7b0
// Address: 0x18015d7b0
// Size: 118 bytes
// ============================================================
int64_t fcn.18015d7b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int16_t *piVar5;
    int32_t iVar6;
    int32_t iVar7;
    
    iVar4 = (int32_t)arg3;
    iVar2 = 0;
    if (0 < iVar4) {
        piVar5 = *(int16_t **)arg2;
        iVar7 = 0;
        iVar3 = 0;
        do {
            iVar6 = iVar7;
            iVar7 = iVar6;
            if (*(int16_t **)(arg2 + 8) <= piVar5) break;
            if (*piVar5 == 9) {
                iVar7 = iVar6 + (*(int32_t *)(arg1 + 0x18) - iVar6 % *(int32_t *)(arg1 + 0x18));
            } else {
                iVar7 = iVar6 + 1;
            }
            iVar2 = iVar2 + 1;
            piVar5 = piVar5 + 2;
            iVar3 = iVar6;
        } while (iVar7 < iVar4);
        if (1 < iVar7 - iVar3) {
            iVar1 = iVar2 + -1;
            if (iVar7 - iVar4 < iVar4 - iVar3) {
                iVar1 = iVar2;
            }
            return iVar1;
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18015d830
// Address: 0x18015d830
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

int64_t fcn.18015d830(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    code *pcVar2;
    char cVar3;
    undefined4 uVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int16_t *piVar10;
    int16_t **arg2_00;
    int32_t iVar11;
    char in_R9B;
    uint64_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_28h;
    undefined auStack_20 [8];
    
    if (in_R9B == '\0') {
        iVar7 = *(int64_t *)arg1;
        iVar9 = (int32_t)arg3;
        uVar6 = (uint64_t)iVar9;
        uVar12 = (*(int64_t *)(arg1 + 8) - iVar7 >> 3) * 0x6db6db6db6db6db7;
        if (uVar12 < uVar6 || uVar12 - uVar6 == 0) goto code_r0x00018015d9b2;
        iVar8 = fcn.18015d7b0(arg1, uVar6 * 0x38 + iVar7, (uint64_t)arg3 >> 0x20);
        if (iVar8 == 0) {
            if (0 < iVar9) {
                uVar6 = (uint64_t)(iVar9 + -1);
                if (uVar12 < uVar6 || uVar12 - uVar6 == 0) goto code_r0x00018015d9b2;
                arg3 = CONCAT44(*(undefined4 *)(uVar6 * 0x38 + 0x28 + iVar7), iVar9 + -1);
            }
            *(int64_t *)arg2 = arg3;
        } else {
            uVar4 = func_0x000180150020(arg1, arg3 & 0xffffffff, iVar8 + -1);
            *(undefined4 *)(arg2 + 4) = uVar4;
            *(int32_t *)arg2 = iVar9;
        }
    } else {
        puVar5 = (uint64_t *)fcn.18015d830(arg1, (int64_t)auStack_20, arg3);
        iVar9 = (int32_t)*puVar5;
        uVar12 = (uint64_t)iVar9;
        uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar12 || uVar6 - uVar12 == 0) {
code_r0x00018015d9b2:
            fcn.180060370();
            pcVar2 = (code *)swi(3);
            iVar7 = (*pcVar2)();
            return iVar7;
        }
        arg2_00 = (int16_t **)(uVar12 * 0x38 + *(int64_t *)arg1);
        iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, *puVar5 >> 0x20);
        do {
            if (iVar7 == 0) {
                iVar11 = 0;
                goto code_r0x00018015d902;
            }
            piVar10 = *arg2_00;
            iVar7 = iVar7 + -1;
            piVar1 = piVar10 + iVar7 * 2;
            cVar3 = func_0x000180162130(piVar10[iVar7 * 2]);
        } while (cVar3 != '\0');
        iVar11 = 0;
        while (piVar10 < piVar1) {
            if (*piVar10 == 9) {
                iVar11 = iVar11 + (*(int32_t *)(arg1 + 0x18) - iVar11 % *(int32_t *)(arg1 + 0x18));
                piVar10 = piVar10 + 2;
            } else {
                iVar11 = iVar11 + 1;
                piVar10 = piVar10 + 2;
            }
        }
code_r0x00018015d902:
        var_28h = CONCAT44(iVar11, iVar9);
        func_0x00018015db90(arg1, arg2, var_28h, 0);
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015d89f
// Address: 0x18015d89f
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

int64_t fcn.18015d830(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    code *pcVar2;
    char cVar3;
    undefined4 uVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int16_t *piVar10;
    int16_t **arg2_00;
    int32_t iVar11;
    char in_R9B;
    uint64_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_28h;
    undefined auStack_20 [8];
    
    if (in_R9B == '\0') {
        iVar7 = *(int64_t *)arg1;
        iVar9 = (int32_t)arg3;
        uVar6 = (uint64_t)iVar9;
        uVar12 = (*(int64_t *)(arg1 + 8) - iVar7 >> 3) * 0x6db6db6db6db6db7;
        if (uVar12 < uVar6 || uVar12 - uVar6 == 0) goto code_r0x00018015d9b2;
        iVar8 = fcn.18015d7b0(arg1, uVar6 * 0x38 + iVar7, (uint64_t)arg3 >> 0x20);
        if (iVar8 == 0) {
            if (0 < iVar9) {
                uVar6 = (uint64_t)(iVar9 + -1);
                if (uVar12 < uVar6 || uVar12 - uVar6 == 0) goto code_r0x00018015d9b2;
                arg3 = CONCAT44(*(undefined4 *)(uVar6 * 0x38 + 0x28 + iVar7), iVar9 + -1);
            }
            *(int64_t *)arg2 = arg3;
        } else {
            uVar4 = func_0x000180150020(arg1, arg3 & 0xffffffff, iVar8 + -1);
            *(undefined4 *)(arg2 + 4) = uVar4;
            *(int32_t *)arg2 = iVar9;
        }
    } else {
        puVar5 = (uint64_t *)fcn.18015d830(arg1, (int64_t)auStack_20, arg3);
        iVar9 = (int32_t)*puVar5;
        uVar12 = (uint64_t)iVar9;
        uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar12 || uVar6 - uVar12 == 0) {
code_r0x00018015d9b2:
            fcn.180060370();
            pcVar2 = (code *)swi(3);
            iVar7 = (*pcVar2)();
            return iVar7;
        }
        arg2_00 = (int16_t **)(uVar12 * 0x38 + *(int64_t *)arg1);
        iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, *puVar5 >> 0x20);
        do {
            if (iVar7 == 0) {
                iVar11 = 0;
                goto code_r0x00018015d902;
            }
            piVar10 = *arg2_00;
            iVar7 = iVar7 + -1;
            piVar1 = piVar10 + iVar7 * 2;
            cVar3 = func_0x000180162130(piVar10[iVar7 * 2]);
        } while (cVar3 != '\0');
        iVar11 = 0;
        while (piVar10 < piVar1) {
            if (*piVar10 == 9) {
                iVar11 = iVar11 + (*(int32_t *)(arg1 + 0x18) - iVar11 % *(int32_t *)(arg1 + 0x18));
                piVar10 = piVar10 + 2;
            } else {
                iVar11 = iVar11 + 1;
                piVar10 = piVar10 + 2;
            }
        }
code_r0x00018015d902:
        var_28h = CONCAT44(iVar11, iVar9);
        func_0x00018015db90(arg1, arg2, var_28h, 0);
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015d91f
// Address: 0x18015d91f
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

int64_t fcn.18015d830(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    code *pcVar2;
    char cVar3;
    undefined4 uVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int16_t *piVar10;
    int16_t **arg2_00;
    int32_t iVar11;
    char in_R9B;
    uint64_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_28h;
    undefined auStack_20 [8];
    
    if (in_R9B == '\0') {
        iVar7 = *(int64_t *)arg1;
        iVar9 = (int32_t)arg3;
        uVar6 = (uint64_t)iVar9;
        uVar12 = (*(int64_t *)(arg1 + 8) - iVar7 >> 3) * 0x6db6db6db6db6db7;
        if (uVar12 < uVar6 || uVar12 - uVar6 == 0) goto code_r0x00018015d9b2;
        iVar8 = fcn.18015d7b0(arg1, uVar6 * 0x38 + iVar7, (uint64_t)arg3 >> 0x20);
        if (iVar8 == 0) {
            if (0 < iVar9) {
                uVar6 = (uint64_t)(iVar9 + -1);
                if (uVar12 < uVar6 || uVar12 - uVar6 == 0) goto code_r0x00018015d9b2;
                arg3 = CONCAT44(*(undefined4 *)(uVar6 * 0x38 + 0x28 + iVar7), iVar9 + -1);
            }
            *(int64_t *)arg2 = arg3;
        } else {
            uVar4 = func_0x000180150020(arg1, arg3 & 0xffffffff, iVar8 + -1);
            *(undefined4 *)(arg2 + 4) = uVar4;
            *(int32_t *)arg2 = iVar9;
        }
    } else {
        puVar5 = (uint64_t *)fcn.18015d830(arg1, (int64_t)auStack_20, arg3);
        iVar9 = (int32_t)*puVar5;
        uVar12 = (uint64_t)iVar9;
        uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar12 || uVar6 - uVar12 == 0) {
code_r0x00018015d9b2:
            fcn.180060370();
            pcVar2 = (code *)swi(3);
            iVar7 = (*pcVar2)();
            return iVar7;
        }
        arg2_00 = (int16_t **)(uVar12 * 0x38 + *(int64_t *)arg1);
        iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, *puVar5 >> 0x20);
        do {
            if (iVar7 == 0) {
                iVar11 = 0;
                goto code_r0x00018015d902;
            }
            piVar10 = *arg2_00;
            iVar7 = iVar7 + -1;
            piVar1 = piVar10 + iVar7 * 2;
            cVar3 = func_0x000180162130(piVar10[iVar7 * 2]);
        } while (cVar3 != '\0');
        iVar11 = 0;
        while (piVar10 < piVar1) {
            if (*piVar10 == 9) {
                iVar11 = iVar11 + (*(int32_t *)(arg1 + 0x18) - iVar11 % *(int32_t *)(arg1 + 0x18));
                piVar10 = piVar10 + 2;
            } else {
                iVar11 = iVar11 + 1;
                piVar10 = piVar10 + 2;
            }
        }
code_r0x00018015d902:
        var_28h = CONCAT44(iVar11, iVar9);
        func_0x00018015db90(arg1, arg2, var_28h, 0);
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015d9c0
// Address: 0x18015d9c0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

int64_t fcn.18015d9c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t *piVar2;
    code *pcVar3;
    char cVar4;
    undefined4 uVar5;
    uint64_t *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int16_t *piVar11;
    uint64_t uVar12;
    int64_t *arg2_00;
    int32_t iVar13;
    int32_t iVar14;
    char in_R9B;
    int16_t **arg2_01;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    if (in_R9B == '\0') {
        iVar13 = (int32_t)arg3;
        uVar10 = (uint64_t)iVar13;
        uVar9 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        if (uVar10 <= uVar9 && uVar9 - uVar10 != 0) {
            arg2_00 = (int64_t *)(uVar10 * 0x38 + *(int64_t *)arg1);
            iVar8 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
            if (iVar8 == arg2_00[1] - *arg2_00 >> 2) {
                if (iVar13 < (int32_t)uVar9 + -1) {
                    arg3 = (int64_t)(iVar13 + 1);
                }
                *(int64_t *)arg2 = arg3;
            } else {
                uVar5 = func_0x000180150020(arg1, arg3 & 0xffffffff, iVar8 + 1);
                *(undefined4 *)(arg2 + 4) = uVar5;
                *(int32_t *)arg2 = iVar13;
            }
            return arg2;
        }
    } else {
        puVar6 = (uint64_t *)fcn.18015d9c0(arg1, (int64_t)&var_30h, arg3);
        uVar10 = *puVar6;
        uVar15 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        iVar13 = (int32_t)uVar10;
        uVar9 = (uint64_t)iVar13;
        if (uVar9 <= uVar15 && uVar15 - uVar9 != 0) {
            arg2_01 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
            uVar9 = fcn.18015d7b0(arg1, (int64_t)arg2_01, uVar10 >> 0x20);
            piVar11 = *arg2_01;
            piVar2 = arg2_01[1];
code_r0x00018015da60:
            if (uVar9 < (uint64_t)((int64_t)piVar2 - (int64_t)piVar11 >> 2)) {
                piVar1 = piVar11 + uVar9 * 2;
                cVar4 = func_0x000180162130(piVar11[uVar9 * 2]);
                if (cVar4 != '\0') goto code_r0x00018015da76;
                uVar9 = 0;
                while (piVar11 < piVar1) {
                    iVar14 = (int32_t)uVar9;
                    if (*piVar11 == 9) {
                        uVar9 = (uint64_t)
                                (uint32_t)(iVar14 + (*(int32_t *)(arg1 + 0x18) - iVar14 % *(int32_t *)(arg1 + 0x18)));
                        piVar11 = piVar11 + 2;
                    } else {
                        uVar9 = (uint64_t)(iVar14 + 1);
                        piVar11 = piVar11 + 2;
                    }
                }
            } else {
                uVar9 = (uint64_t)*(uint32_t *)(arg2_01 + 5);
            }
            uVar12 = (uint64_t)iVar13;
            if (uVar12 <= uVar15 && uVar15 - uVar12 != 0) {
                uVar7 = fcn.18015d7b0(arg1, uVar12 * 0x38 + *(int64_t *)arg1, uVar9);
                uVar5 = func_0x000180150020(arg1, uVar10 & 0xffffffff, uVar7);
                var_38h = CONCAT44(uVar5, iVar13);
                func_0x00018015dd90(arg1, arg2, var_38h, 0);
                return arg2;
            }
        }
    }
    fcn.180060370();
    pcVar3 = (code *)swi(3);
    iVar8 = (*pcVar3)();
    return iVar8;
code_r0x00018015da76:
    uVar9 = uVar9 + 1;
    goto code_r0x00018015da60;
}

// ============================================================
// Function: FUN_18015da2a
// Address: 0x18015da2a
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

int64_t fcn.18015d9c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t *piVar2;
    code *pcVar3;
    char cVar4;
    undefined4 uVar5;
    uint64_t *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int16_t *piVar11;
    uint64_t uVar12;
    int64_t *arg2_00;
    int32_t iVar13;
    int32_t iVar14;
    char in_R9B;
    int16_t **arg2_01;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    if (in_R9B == '\0') {
        iVar13 = (int32_t)arg3;
        uVar10 = (uint64_t)iVar13;
        uVar9 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        if (uVar10 <= uVar9 && uVar9 - uVar10 != 0) {
            arg2_00 = (int64_t *)(uVar10 * 0x38 + *(int64_t *)arg1);
            iVar8 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
            if (iVar8 == arg2_00[1] - *arg2_00 >> 2) {
                if (iVar13 < (int32_t)uVar9 + -1) {
                    arg3 = (int64_t)(iVar13 + 1);
                }
                *(int64_t *)arg2 = arg3;
            } else {
                uVar5 = func_0x000180150020(arg1, arg3 & 0xffffffff, iVar8 + 1);
                *(undefined4 *)(arg2 + 4) = uVar5;
                *(int32_t *)arg2 = iVar13;
            }
            return arg2;
        }
    } else {
        puVar6 = (uint64_t *)fcn.18015d9c0(arg1, (int64_t)&var_30h, arg3);
        uVar10 = *puVar6;
        uVar15 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        iVar13 = (int32_t)uVar10;
        uVar9 = (uint64_t)iVar13;
        if (uVar9 <= uVar15 && uVar15 - uVar9 != 0) {
            arg2_01 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
            uVar9 = fcn.18015d7b0(arg1, (int64_t)arg2_01, uVar10 >> 0x20);
            piVar11 = *arg2_01;
            piVar2 = arg2_01[1];
code_r0x00018015da60:
            if (uVar9 < (uint64_t)((int64_t)piVar2 - (int64_t)piVar11 >> 2)) {
                piVar1 = piVar11 + uVar9 * 2;
                cVar4 = func_0x000180162130(piVar11[uVar9 * 2]);
                if (cVar4 != '\0') goto code_r0x00018015da76;
                uVar9 = 0;
                while (piVar11 < piVar1) {
                    iVar14 = (int32_t)uVar9;
                    if (*piVar11 == 9) {
                        uVar9 = (uint64_t)
                                (uint32_t)(iVar14 + (*(int32_t *)(arg1 + 0x18) - iVar14 % *(int32_t *)(arg1 + 0x18)));
                        piVar11 = piVar11 + 2;
                    } else {
                        uVar9 = (uint64_t)(iVar14 + 1);
                        piVar11 = piVar11 + 2;
                    }
                }
            } else {
                uVar9 = (uint64_t)*(uint32_t *)(arg2_01 + 5);
            }
            uVar12 = (uint64_t)iVar13;
            if (uVar12 <= uVar15 && uVar15 - uVar12 != 0) {
                uVar7 = fcn.18015d7b0(arg1, uVar12 * 0x38 + *(int64_t *)arg1, uVar9);
                uVar5 = func_0x000180150020(arg1, uVar10 & 0xffffffff, uVar7);
                var_38h = CONCAT44(uVar5, iVar13);
                func_0x00018015dd90(arg1, arg2, var_38h, 0);
                return arg2;
            }
        }
    }
    fcn.180060370();
    pcVar3 = (code *)swi(3);
    iVar8 = (*pcVar3)();
    return iVar8;
code_r0x00018015da76:
    uVar9 = uVar9 + 1;
    goto code_r0x00018015da60;
}

// ============================================================
// Function: FUN_18015dac9
// Address: 0x18015dac9
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

int64_t fcn.18015d9c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t *piVar2;
    code *pcVar3;
    char cVar4;
    undefined4 uVar5;
    uint64_t *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int16_t *piVar11;
    uint64_t uVar12;
    int64_t *arg2_00;
    int32_t iVar13;
    int32_t iVar14;
    char in_R9B;
    int16_t **arg2_01;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    if (in_R9B == '\0') {
        iVar13 = (int32_t)arg3;
        uVar10 = (uint64_t)iVar13;
        uVar9 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        if (uVar10 <= uVar9 && uVar9 - uVar10 != 0) {
            arg2_00 = (int64_t *)(uVar10 * 0x38 + *(int64_t *)arg1);
            iVar8 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
            if (iVar8 == arg2_00[1] - *arg2_00 >> 2) {
                if (iVar13 < (int32_t)uVar9 + -1) {
                    arg3 = (int64_t)(iVar13 + 1);
                }
                *(int64_t *)arg2 = arg3;
            } else {
                uVar5 = func_0x000180150020(arg1, arg3 & 0xffffffff, iVar8 + 1);
                *(undefined4 *)(arg2 + 4) = uVar5;
                *(int32_t *)arg2 = iVar13;
            }
            return arg2;
        }
    } else {
        puVar6 = (uint64_t *)fcn.18015d9c0(arg1, (int64_t)&var_30h, arg3);
        uVar10 = *puVar6;
        uVar15 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
        iVar13 = (int32_t)uVar10;
        uVar9 = (uint64_t)iVar13;
        if (uVar9 <= uVar15 && uVar15 - uVar9 != 0) {
            arg2_01 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
            uVar9 = fcn.18015d7b0(arg1, (int64_t)arg2_01, uVar10 >> 0x20);
            piVar11 = *arg2_01;
            piVar2 = arg2_01[1];
code_r0x00018015da60:
            if (uVar9 < (uint64_t)((int64_t)piVar2 - (int64_t)piVar11 >> 2)) {
                piVar1 = piVar11 + uVar9 * 2;
                cVar4 = func_0x000180162130(piVar11[uVar9 * 2]);
                if (cVar4 != '\0') goto code_r0x00018015da76;
                uVar9 = 0;
                while (piVar11 < piVar1) {
                    iVar14 = (int32_t)uVar9;
                    if (*piVar11 == 9) {
                        uVar9 = (uint64_t)
                                (uint32_t)(iVar14 + (*(int32_t *)(arg1 + 0x18) - iVar14 % *(int32_t *)(arg1 + 0x18)));
                        piVar11 = piVar11 + 2;
                    } else {
                        uVar9 = (uint64_t)(iVar14 + 1);
                        piVar11 = piVar11 + 2;
                    }
                }
            } else {
                uVar9 = (uint64_t)*(uint32_t *)(arg2_01 + 5);
            }
            uVar12 = (uint64_t)iVar13;
            if (uVar12 <= uVar15 && uVar15 - uVar12 != 0) {
                uVar7 = fcn.18015d7b0(arg1, uVar12 * 0x38 + *(int64_t *)arg1, uVar9);
                uVar5 = func_0x000180150020(arg1, uVar10 & 0xffffffff, uVar7);
                var_38h = CONCAT44(uVar5, iVar13);
                func_0x00018015dd90(arg1, arg2, var_38h, 0);
                return arg2;
            }
        }
    }
    fcn.180060370();
    pcVar3 = (code *)swi(3);
    iVar8 = (*pcVar3)();
    return iVar8;
code_r0x00018015da76:
    uVar9 = uVar9 + 1;
    goto code_r0x00018015da60;
}

// ============================================================
// Function: FUN_18015db90
// Address: 0x18015db90
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015db90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t **arg2_00;
    int16_t *piVar8;
    char in_R9B;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar10 = (uint64_t)(int32_t)arg3;
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar6 < uVar10 || uVar6 - uVar10 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    var_18h._4_4_ = (uint32_t)((uint64_t)arg3 >> 0x20);
    if (var_18h._4_4_ != 0) {
        arg2_00 = (int16_t **)(uVar10 * 0x38 + *(int64_t *)arg1);
        piVar8 = *arg2_00;
        if (arg2_00[1] != piVar8) {
            iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)var_18h._4_4_);
            iVar2 = piVar8[iVar7 * 2 + -2];
            if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
                while ((iVar7 != 0 && (cVar5 = func_0x000180162130(piVar8[iVar7 * 2 + -2]), cVar5 != '\0'))) {
                    iVar7 = iVar7 + -1;
                }
            } else {
                cVar5 = func_0x0001801621e0(iVar2);
                if (cVar5 == '\0') {
                    if (in_R9B == '\0') {
                        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                            uVar3 = piVar8[iVar7 * 2 + -2];
                            if (uVar3 < 0x7f) {
                                if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                            } else {
                                cVar5 = func_0x000180163840();
                                if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                            }
                            cVar5 = func_0x000180162130(uVar3);
                            if (cVar5 != '\0') break;
                        }
                    }
                } else {
                    for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                        uVar3 = piVar8[iVar7 * 2 + -2];
                        if (uVar3 < 0x7f) {
                            if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                        }
                    }
                }
            }
            piVar1 = piVar8 + iVar7 * 2;
            iVar9 = 0;
            while (piVar8 < piVar1) {
                if (*piVar8 == 9) {
                    iVar9 = iVar9 + (*(int32_t *)(arg1 + 0x18) - iVar9 % *(int32_t *)(arg1 + 0x18));
                    piVar8 = piVar8 + 2;
                } else {
                    iVar9 = iVar9 + 1;
                    piVar8 = piVar8 + 2;
                }
            }
            *(int32_t *)arg2 = (int32_t)arg3;
            *(int32_t *)(arg2 + 4) = iVar9;
            return arg2;
        }
    }
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18015dbda
// Address: 0x18015dbda
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015db90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t **arg2_00;
    int16_t *piVar8;
    char in_R9B;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar10 = (uint64_t)(int32_t)arg3;
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar6 < uVar10 || uVar6 - uVar10 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    var_18h._4_4_ = (uint32_t)((uint64_t)arg3 >> 0x20);
    if (var_18h._4_4_ != 0) {
        arg2_00 = (int16_t **)(uVar10 * 0x38 + *(int64_t *)arg1);
        piVar8 = *arg2_00;
        if (arg2_00[1] != piVar8) {
            iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)var_18h._4_4_);
            iVar2 = piVar8[iVar7 * 2 + -2];
            if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
                while ((iVar7 != 0 && (cVar5 = func_0x000180162130(piVar8[iVar7 * 2 + -2]), cVar5 != '\0'))) {
                    iVar7 = iVar7 + -1;
                }
            } else {
                cVar5 = func_0x0001801621e0(iVar2);
                if (cVar5 == '\0') {
                    if (in_R9B == '\0') {
                        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                            uVar3 = piVar8[iVar7 * 2 + -2];
                            if (uVar3 < 0x7f) {
                                if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                            } else {
                                cVar5 = func_0x000180163840();
                                if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                            }
                            cVar5 = func_0x000180162130(uVar3);
                            if (cVar5 != '\0') break;
                        }
                    }
                } else {
                    for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                        uVar3 = piVar8[iVar7 * 2 + -2];
                        if (uVar3 < 0x7f) {
                            if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                        }
                    }
                }
            }
            piVar1 = piVar8 + iVar7 * 2;
            iVar9 = 0;
            while (piVar8 < piVar1) {
                if (*piVar8 == 9) {
                    iVar9 = iVar9 + (*(int32_t *)(arg1 + 0x18) - iVar9 % *(int32_t *)(arg1 + 0x18));
                    piVar8 = piVar8 + 2;
                } else {
                    iVar9 = iVar9 + 1;
                    piVar8 = piVar8 + 2;
                }
            }
            *(int32_t *)arg2 = (int32_t)arg3;
            *(int32_t *)(arg2 + 4) = iVar9;
            return arg2;
        }
    }
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18015dbfc
// Address: 0x18015dbfc
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015db90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t **arg2_00;
    int16_t *piVar8;
    char in_R9B;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar10 = (uint64_t)(int32_t)arg3;
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar6 < uVar10 || uVar6 - uVar10 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    var_18h._4_4_ = (uint32_t)((uint64_t)arg3 >> 0x20);
    if (var_18h._4_4_ != 0) {
        arg2_00 = (int16_t **)(uVar10 * 0x38 + *(int64_t *)arg1);
        piVar8 = *arg2_00;
        if (arg2_00[1] != piVar8) {
            iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)var_18h._4_4_);
            iVar2 = piVar8[iVar7 * 2 + -2];
            if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
                while ((iVar7 != 0 && (cVar5 = func_0x000180162130(piVar8[iVar7 * 2 + -2]), cVar5 != '\0'))) {
                    iVar7 = iVar7 + -1;
                }
            } else {
                cVar5 = func_0x0001801621e0(iVar2);
                if (cVar5 == '\0') {
                    if (in_R9B == '\0') {
                        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                            uVar3 = piVar8[iVar7 * 2 + -2];
                            if (uVar3 < 0x7f) {
                                if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                            } else {
                                cVar5 = func_0x000180163840();
                                if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                            }
                            cVar5 = func_0x000180162130(uVar3);
                            if (cVar5 != '\0') break;
                        }
                    }
                } else {
                    for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                        uVar3 = piVar8[iVar7 * 2 + -2];
                        if (uVar3 < 0x7f) {
                            if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                        }
                    }
                }
            }
            piVar1 = piVar8 + iVar7 * 2;
            iVar9 = 0;
            while (piVar8 < piVar1) {
                if (*piVar8 == 9) {
                    iVar9 = iVar9 + (*(int32_t *)(arg1 + 0x18) - iVar9 % *(int32_t *)(arg1 + 0x18));
                    piVar8 = piVar8 + 2;
                } else {
                    iVar9 = iVar9 + 1;
                    piVar8 = piVar8 + 2;
                }
            }
            *(int32_t *)arg2 = (int32_t)arg3;
            *(int32_t *)(arg2 + 4) = iVar9;
            return arg2;
        }
    }
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18015dc55
// Address: 0x18015dc55
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015db90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t **arg2_00;
    int16_t *piVar8;
    char in_R9B;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar10 = (uint64_t)(int32_t)arg3;
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar6 < uVar10 || uVar6 - uVar10 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    var_18h._4_4_ = (uint32_t)((uint64_t)arg3 >> 0x20);
    if (var_18h._4_4_ != 0) {
        arg2_00 = (int16_t **)(uVar10 * 0x38 + *(int64_t *)arg1);
        piVar8 = *arg2_00;
        if (arg2_00[1] != piVar8) {
            iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)var_18h._4_4_);
            iVar2 = piVar8[iVar7 * 2 + -2];
            if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
                while ((iVar7 != 0 && (cVar5 = func_0x000180162130(piVar8[iVar7 * 2 + -2]), cVar5 != '\0'))) {
                    iVar7 = iVar7 + -1;
                }
            } else {
                cVar5 = func_0x0001801621e0(iVar2);
                if (cVar5 == '\0') {
                    if (in_R9B == '\0') {
                        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                            uVar3 = piVar8[iVar7 * 2 + -2];
                            if (uVar3 < 0x7f) {
                                if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                            } else {
                                cVar5 = func_0x000180163840();
                                if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                            }
                            cVar5 = func_0x000180162130(uVar3);
                            if (cVar5 != '\0') break;
                        }
                    }
                } else {
                    for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                        uVar3 = piVar8[iVar7 * 2 + -2];
                        if (uVar3 < 0x7f) {
                            if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                        }
                    }
                }
            }
            piVar1 = piVar8 + iVar7 * 2;
            iVar9 = 0;
            while (piVar8 < piVar1) {
                if (*piVar8 == 9) {
                    iVar9 = iVar9 + (*(int32_t *)(arg1 + 0x18) - iVar9 % *(int32_t *)(arg1 + 0x18));
                    piVar8 = piVar8 + 2;
                } else {
                    iVar9 = iVar9 + 1;
                    piVar8 = piVar8 + 2;
                }
            }
            *(int32_t *)arg2 = (int32_t)arg3;
            *(int32_t *)(arg2 + 4) = iVar9;
            return arg2;
        }
    }
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18015dc80
// Address: 0x18015dc80
// Size: 215 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015db90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t **arg2_00;
    int16_t *piVar8;
    char in_R9B;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar10 = (uint64_t)(int32_t)arg3;
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar6 < uVar10 || uVar6 - uVar10 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    var_18h._4_4_ = (uint32_t)((uint64_t)arg3 >> 0x20);
    if (var_18h._4_4_ != 0) {
        arg2_00 = (int16_t **)(uVar10 * 0x38 + *(int64_t *)arg1);
        piVar8 = *arg2_00;
        if (arg2_00[1] != piVar8) {
            iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)var_18h._4_4_);
            iVar2 = piVar8[iVar7 * 2 + -2];
            if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
                while ((iVar7 != 0 && (cVar5 = func_0x000180162130(piVar8[iVar7 * 2 + -2]), cVar5 != '\0'))) {
                    iVar7 = iVar7 + -1;
                }
            } else {
                cVar5 = func_0x0001801621e0(iVar2);
                if (cVar5 == '\0') {
                    if (in_R9B == '\0') {
                        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                            uVar3 = piVar8[iVar7 * 2 + -2];
                            if (uVar3 < 0x7f) {
                                if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                            } else {
                                cVar5 = func_0x000180163840();
                                if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                            }
                            cVar5 = func_0x000180162130(uVar3);
                            if (cVar5 != '\0') break;
                        }
                    }
                } else {
                    for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                        uVar3 = piVar8[iVar7 * 2 + -2];
                        if (uVar3 < 0x7f) {
                            if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                        }
                    }
                }
            }
            piVar1 = piVar8 + iVar7 * 2;
            iVar9 = 0;
            while (piVar8 < piVar1) {
                if (*piVar8 == 9) {
                    iVar9 = iVar9 + (*(int32_t *)(arg1 + 0x18) - iVar9 % *(int32_t *)(arg1 + 0x18));
                    piVar8 = piVar8 + 2;
                } else {
                    iVar9 = iVar9 + 1;
                    piVar8 = piVar8 + 2;
                }
            }
            *(int32_t *)arg2 = (int32_t)arg3;
            *(int32_t *)(arg2 + 4) = iVar9;
            return arg2;
        }
    }
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18015dd57
// Address: 0x18015dd57
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015db90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t **arg2_00;
    int16_t *piVar8;
    char in_R9B;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar10 = (uint64_t)(int32_t)arg3;
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar6 < uVar10 || uVar6 - uVar10 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    var_18h._4_4_ = (uint32_t)((uint64_t)arg3 >> 0x20);
    if (var_18h._4_4_ != 0) {
        arg2_00 = (int16_t **)(uVar10 * 0x38 + *(int64_t *)arg1);
        piVar8 = *arg2_00;
        if (arg2_00[1] != piVar8) {
            iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)var_18h._4_4_);
            iVar2 = piVar8[iVar7 * 2 + -2];
            if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
                while ((iVar7 != 0 && (cVar5 = func_0x000180162130(piVar8[iVar7 * 2 + -2]), cVar5 != '\0'))) {
                    iVar7 = iVar7 + -1;
                }
            } else {
                cVar5 = func_0x0001801621e0(iVar2);
                if (cVar5 == '\0') {
                    if (in_R9B == '\0') {
                        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                            uVar3 = piVar8[iVar7 * 2 + -2];
                            if (uVar3 < 0x7f) {
                                if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                            } else {
                                cVar5 = func_0x000180163840();
                                if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                            }
                            cVar5 = func_0x000180162130(uVar3);
                            if (cVar5 != '\0') break;
                        }
                    }
                } else {
                    for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                        uVar3 = piVar8[iVar7 * 2 + -2];
                        if (uVar3 < 0x7f) {
                            if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                        }
                    }
                }
            }
            piVar1 = piVar8 + iVar7 * 2;
            iVar9 = 0;
            while (piVar8 < piVar1) {
                if (*piVar8 == 9) {
                    iVar9 = iVar9 + (*(int32_t *)(arg1 + 0x18) - iVar9 % *(int32_t *)(arg1 + 0x18));
                    piVar8 = piVar8 + 2;
                } else {
                    iVar9 = iVar9 + 1;
                    piVar8 = piVar8 + 2;
                }
            }
            *(int32_t *)arg2 = (int32_t)arg3;
            *(int32_t *)(arg2 + 4) = iVar9;
            return arg2;
        }
    }
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18015dd83
// Address: 0x18015dd83
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015db90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t **arg2_00;
    int16_t *piVar8;
    char in_R9B;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar10 = (uint64_t)(int32_t)arg3;
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar6 < uVar10 || uVar6 - uVar10 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    var_18h._4_4_ = (uint32_t)((uint64_t)arg3 >> 0x20);
    if (var_18h._4_4_ != 0) {
        arg2_00 = (int16_t **)(uVar10 * 0x38 + *(int64_t *)arg1);
        piVar8 = *arg2_00;
        if (arg2_00[1] != piVar8) {
            iVar7 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)var_18h._4_4_);
            iVar2 = piVar8[iVar7 * 2 + -2];
            if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
                while ((iVar7 != 0 && (cVar5 = func_0x000180162130(piVar8[iVar7 * 2 + -2]), cVar5 != '\0'))) {
                    iVar7 = iVar7 + -1;
                }
            } else {
                cVar5 = func_0x0001801621e0(iVar2);
                if (cVar5 == '\0') {
                    if (in_R9B == '\0') {
                        for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                            uVar3 = piVar8[iVar7 * 2 + -2];
                            if (uVar3 < 0x7f) {
                                if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                            } else {
                                cVar5 = func_0x000180163840();
                                if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                            }
                            cVar5 = func_0x000180162130(uVar3);
                            if (cVar5 != '\0') break;
                        }
                    }
                } else {
                    for (; iVar7 != 0; iVar7 = iVar7 + -1) {
                        uVar3 = piVar8[iVar7 * 2 + -2];
                        if (uVar3 < 0x7f) {
                            if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                        }
                    }
                }
            }
            piVar1 = piVar8 + iVar7 * 2;
            iVar9 = 0;
            while (piVar8 < piVar1) {
                if (*piVar8 == 9) {
                    iVar9 = iVar9 + (*(int32_t *)(arg1 + 0x18) - iVar9 % *(int32_t *)(arg1 + 0x18));
                    piVar8 = piVar8 + 2;
                } else {
                    iVar9 = iVar9 + 1;
                    piVar8 = piVar8 + 2;
                }
            }
            *(int32_t *)arg2 = (int32_t)arg3;
            *(int32_t *)(arg2 + 4) = iVar9;
            return arg2;
        }
    }
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18015dd90
// Address: 0x18015dd90
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015dd90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t *piVar8;
    uint64_t uVar9;
    char in_R9B;
    int32_t iVar10;
    int16_t **arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar9 = (uint64_t)(int32_t)arg3;
    if (uVar6 < uVar9 || uVar6 - uVar9 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    arg2_00 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
    uVar6 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
    piVar8 = *arg2_00;
    uVar9 = (int64_t)arg2_00[1] - (int64_t)piVar8 >> 2;
    if (uVar6 < uVar9) {
        iVar2 = piVar8[uVar6 * 2];
        if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
            do {
                cVar5 = func_0x000180162130(piVar8[uVar6 * 2]);
                if (cVar5 == '\0') break;
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar9);
        } else {
            cVar5 = func_0x0001801621e0(iVar2);
            if (cVar5 == '\0') {
                if (in_R9B == '\0') {
                    for (; uVar6 < uVar9; uVar6 = uVar6 + 1) {
                        uVar3 = piVar8[uVar6 * 2];
                        if (uVar3 < 0x7f) {
                            if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                        }
                        cVar5 = func_0x000180162130(uVar3);
                        if (cVar5 != '\0') break;
                    }
                }
            } else {
                do {
                    uVar3 = piVar8[uVar6 * 2];
                    if (uVar3 < 0x7f) {
                        if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                    } else {
                        cVar5 = func_0x000180163840();
                        if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                    }
                    uVar6 = uVar6 + 1;
                } while (uVar6 < uVar9);
            }
        }
        piVar1 = piVar8 + uVar6 * 2;
        iVar10 = 0;
        while (piVar8 < piVar1) {
            if (*piVar8 == 9) {
                iVar10 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                piVar8 = piVar8 + 2;
            } else {
                iVar10 = iVar10 + 1;
                piVar8 = piVar8 + 2;
            }
        }
        *(int32_t *)arg2 = (int32_t)arg3;
        *(int32_t *)(arg2 + 4) = iVar10;
    } else {
        *(int64_t *)arg2 = arg3;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015ddd5
// Address: 0x18015ddd5
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015dd90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t *piVar8;
    uint64_t uVar9;
    char in_R9B;
    int32_t iVar10;
    int16_t **arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar9 = (uint64_t)(int32_t)arg3;
    if (uVar6 < uVar9 || uVar6 - uVar9 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    arg2_00 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
    uVar6 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
    piVar8 = *arg2_00;
    uVar9 = (int64_t)arg2_00[1] - (int64_t)piVar8 >> 2;
    if (uVar6 < uVar9) {
        iVar2 = piVar8[uVar6 * 2];
        if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
            do {
                cVar5 = func_0x000180162130(piVar8[uVar6 * 2]);
                if (cVar5 == '\0') break;
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar9);
        } else {
            cVar5 = func_0x0001801621e0(iVar2);
            if (cVar5 == '\0') {
                if (in_R9B == '\0') {
                    for (; uVar6 < uVar9; uVar6 = uVar6 + 1) {
                        uVar3 = piVar8[uVar6 * 2];
                        if (uVar3 < 0x7f) {
                            if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                        }
                        cVar5 = func_0x000180162130(uVar3);
                        if (cVar5 != '\0') break;
                    }
                }
            } else {
                do {
                    uVar3 = piVar8[uVar6 * 2];
                    if (uVar3 < 0x7f) {
                        if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                    } else {
                        cVar5 = func_0x000180163840();
                        if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                    }
                    uVar6 = uVar6 + 1;
                } while (uVar6 < uVar9);
            }
        }
        piVar1 = piVar8 + uVar6 * 2;
        iVar10 = 0;
        while (piVar8 < piVar1) {
            if (*piVar8 == 9) {
                iVar10 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                piVar8 = piVar8 + 2;
            } else {
                iVar10 = iVar10 + 1;
                piVar8 = piVar8 + 2;
            }
        }
        *(int32_t *)arg2 = (int32_t)arg3;
        *(int32_t *)(arg2 + 4) = iVar10;
    } else {
        *(int64_t *)arg2 = arg3;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015de1a
// Address: 0x18015de1a
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015dd90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t *piVar8;
    uint64_t uVar9;
    char in_R9B;
    int32_t iVar10;
    int16_t **arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar9 = (uint64_t)(int32_t)arg3;
    if (uVar6 < uVar9 || uVar6 - uVar9 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    arg2_00 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
    uVar6 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
    piVar8 = *arg2_00;
    uVar9 = (int64_t)arg2_00[1] - (int64_t)piVar8 >> 2;
    if (uVar6 < uVar9) {
        iVar2 = piVar8[uVar6 * 2];
        if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
            do {
                cVar5 = func_0x000180162130(piVar8[uVar6 * 2]);
                if (cVar5 == '\0') break;
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar9);
        } else {
            cVar5 = func_0x0001801621e0(iVar2);
            if (cVar5 == '\0') {
                if (in_R9B == '\0') {
                    for (; uVar6 < uVar9; uVar6 = uVar6 + 1) {
                        uVar3 = piVar8[uVar6 * 2];
                        if (uVar3 < 0x7f) {
                            if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                        }
                        cVar5 = func_0x000180162130(uVar3);
                        if (cVar5 != '\0') break;
                    }
                }
            } else {
                do {
                    uVar3 = piVar8[uVar6 * 2];
                    if (uVar3 < 0x7f) {
                        if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                    } else {
                        cVar5 = func_0x000180163840();
                        if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                    }
                    uVar6 = uVar6 + 1;
                } while (uVar6 < uVar9);
            }
        }
        piVar1 = piVar8 + uVar6 * 2;
        iVar10 = 0;
        while (piVar8 < piVar1) {
            if (*piVar8 == 9) {
                iVar10 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                piVar8 = piVar8 + 2;
            } else {
                iVar10 = iVar10 + 1;
                piVar8 = piVar8 + 2;
            }
        }
        *(int32_t *)arg2 = (int32_t)arg3;
        *(int32_t *)(arg2 + 4) = iVar10;
    } else {
        *(int64_t *)arg2 = arg3;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015de55
// Address: 0x18015de55
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015dd90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t *piVar8;
    uint64_t uVar9;
    char in_R9B;
    int32_t iVar10;
    int16_t **arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar9 = (uint64_t)(int32_t)arg3;
    if (uVar6 < uVar9 || uVar6 - uVar9 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    arg2_00 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
    uVar6 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
    piVar8 = *arg2_00;
    uVar9 = (int64_t)arg2_00[1] - (int64_t)piVar8 >> 2;
    if (uVar6 < uVar9) {
        iVar2 = piVar8[uVar6 * 2];
        if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
            do {
                cVar5 = func_0x000180162130(piVar8[uVar6 * 2]);
                if (cVar5 == '\0') break;
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar9);
        } else {
            cVar5 = func_0x0001801621e0(iVar2);
            if (cVar5 == '\0') {
                if (in_R9B == '\0') {
                    for (; uVar6 < uVar9; uVar6 = uVar6 + 1) {
                        uVar3 = piVar8[uVar6 * 2];
                        if (uVar3 < 0x7f) {
                            if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                        }
                        cVar5 = func_0x000180162130(uVar3);
                        if (cVar5 != '\0') break;
                    }
                }
            } else {
                do {
                    uVar3 = piVar8[uVar6 * 2];
                    if (uVar3 < 0x7f) {
                        if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                    } else {
                        cVar5 = func_0x000180163840();
                        if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                    }
                    uVar6 = uVar6 + 1;
                } while (uVar6 < uVar9);
            }
        }
        piVar1 = piVar8 + uVar6 * 2;
        iVar10 = 0;
        while (piVar8 < piVar1) {
            if (*piVar8 == 9) {
                iVar10 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                piVar8 = piVar8 + 2;
            } else {
                iVar10 = iVar10 + 1;
                piVar8 = piVar8 + 2;
            }
        }
        *(int32_t *)arg2 = (int32_t)arg3;
        *(int32_t *)(arg2 + 4) = iVar10;
    } else {
        *(int64_t *)arg2 = arg3;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015de7f
// Address: 0x18015de7f
// Size: 215 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015dd90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t *piVar8;
    uint64_t uVar9;
    char in_R9B;
    int32_t iVar10;
    int16_t **arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar9 = (uint64_t)(int32_t)arg3;
    if (uVar6 < uVar9 || uVar6 - uVar9 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    arg2_00 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
    uVar6 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
    piVar8 = *arg2_00;
    uVar9 = (int64_t)arg2_00[1] - (int64_t)piVar8 >> 2;
    if (uVar6 < uVar9) {
        iVar2 = piVar8[uVar6 * 2];
        if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
            do {
                cVar5 = func_0x000180162130(piVar8[uVar6 * 2]);
                if (cVar5 == '\0') break;
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar9);
        } else {
            cVar5 = func_0x0001801621e0(iVar2);
            if (cVar5 == '\0') {
                if (in_R9B == '\0') {
                    for (; uVar6 < uVar9; uVar6 = uVar6 + 1) {
                        uVar3 = piVar8[uVar6 * 2];
                        if (uVar3 < 0x7f) {
                            if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                        }
                        cVar5 = func_0x000180162130(uVar3);
                        if (cVar5 != '\0') break;
                    }
                }
            } else {
                do {
                    uVar3 = piVar8[uVar6 * 2];
                    if (uVar3 < 0x7f) {
                        if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                    } else {
                        cVar5 = func_0x000180163840();
                        if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                    }
                    uVar6 = uVar6 + 1;
                } while (uVar6 < uVar9);
            }
        }
        piVar1 = piVar8 + uVar6 * 2;
        iVar10 = 0;
        while (piVar8 < piVar1) {
            if (*piVar8 == 9) {
                iVar10 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                piVar8 = piVar8 + 2;
            } else {
                iVar10 = iVar10 + 1;
                piVar8 = piVar8 + 2;
            }
        }
        *(int32_t *)arg2 = (int32_t)arg3;
        *(int32_t *)(arg2 + 4) = iVar10;
    } else {
        *(int64_t *)arg2 = arg3;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015df56
// Address: 0x18015df56
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015dd90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t *piVar8;
    uint64_t uVar9;
    char in_R9B;
    int32_t iVar10;
    int16_t **arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar9 = (uint64_t)(int32_t)arg3;
    if (uVar6 < uVar9 || uVar6 - uVar9 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    arg2_00 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
    uVar6 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
    piVar8 = *arg2_00;
    uVar9 = (int64_t)arg2_00[1] - (int64_t)piVar8 >> 2;
    if (uVar6 < uVar9) {
        iVar2 = piVar8[uVar6 * 2];
        if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
            do {
                cVar5 = func_0x000180162130(piVar8[uVar6 * 2]);
                if (cVar5 == '\0') break;
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar9);
        } else {
            cVar5 = func_0x0001801621e0(iVar2);
            if (cVar5 == '\0') {
                if (in_R9B == '\0') {
                    for (; uVar6 < uVar9; uVar6 = uVar6 + 1) {
                        uVar3 = piVar8[uVar6 * 2];
                        if (uVar3 < 0x7f) {
                            if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                        }
                        cVar5 = func_0x000180162130(uVar3);
                        if (cVar5 != '\0') break;
                    }
                }
            } else {
                do {
                    uVar3 = piVar8[uVar6 * 2];
                    if (uVar3 < 0x7f) {
                        if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                    } else {
                        cVar5 = func_0x000180163840();
                        if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                    }
                    uVar6 = uVar6 + 1;
                } while (uVar6 < uVar9);
            }
        }
        piVar1 = piVar8 + uVar6 * 2;
        iVar10 = 0;
        while (piVar8 < piVar1) {
            if (*piVar8 == 9) {
                iVar10 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                piVar8 = piVar8 + 2;
            } else {
                iVar10 = iVar10 + 1;
                piVar8 = piVar8 + 2;
            }
        }
        *(int32_t *)arg2 = (int32_t)arg3;
        *(int32_t *)(arg2 + 4) = iVar10;
    } else {
        *(int64_t *)arg2 = arg3;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015df89
// Address: 0x18015df89
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015dd90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint16_t uVar3;
    code *pcVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int16_t *piVar8;
    uint64_t uVar9;
    char in_R9B;
    int32_t iVar10;
    int16_t **arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_28h;
    
    uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar9 = (uint64_t)(int32_t)arg3;
    if (uVar6 < uVar9 || uVar6 - uVar9 == 0) {
        fcn.180060370();
        pcVar4 = (code *)swi(3);
        iVar7 = (*pcVar4)();
        return iVar7;
    }
    arg2_00 = (int16_t **)(uVar9 * 0x38 + *(int64_t *)arg1);
    uVar6 = fcn.18015d7b0(arg1, (int64_t)arg2_00, (uint64_t)arg3 >> 0x20);
    piVar8 = *arg2_00;
    uVar9 = (int64_t)arg2_00[1] - (int64_t)piVar8 >> 2;
    if (uVar6 < uVar9) {
        iVar2 = piVar8[uVar6 * 2];
        if ((in_R9B == '\0') && (cVar5 = func_0x000180162130(iVar2), cVar5 != '\0')) {
            do {
                cVar5 = func_0x000180162130(piVar8[uVar6 * 2]);
                if (cVar5 == '\0') break;
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar9);
        } else {
            cVar5 = func_0x0001801621e0(iVar2);
            if (cVar5 == '\0') {
                if (in_R9B == '\0') {
                    for (; uVar6 < uVar9; uVar6 = uVar6 + 1) {
                        uVar3 = piVar8[uVar6 * 2];
                        if (uVar3 < 0x7f) {
                            if (((uVar3 | 0x20) - 0x61 < 0x1a) || ((uVar3 - 0x30 < 10 || (uVar3 == 0x5f)))) break;
                        } else {
                            cVar5 = func_0x000180163840();
                            if ((cVar5 != '\0') || (cVar5 = func_0x0001801638d0(), cVar5 != '\0')) break;
                        }
                        cVar5 = func_0x000180162130(uVar3);
                        if (cVar5 != '\0') break;
                    }
                }
            } else {
                do {
                    uVar3 = piVar8[uVar6 * 2];
                    if (uVar3 < 0x7f) {
                        if ((0x19 < (uVar3 | 0x20) - 0x61) && ((9 < uVar3 - 0x30 && (uVar3 != 0x5f)))) break;
                    } else {
                        cVar5 = func_0x000180163840();
                        if ((cVar5 == '\0') && (cVar5 = func_0x0001801638d0(), cVar5 == '\0')) break;
                    }
                    uVar6 = uVar6 + 1;
                } while (uVar6 < uVar9);
            }
        }
        piVar1 = piVar8 + uVar6 * 2;
        iVar10 = 0;
        while (piVar8 < piVar1) {
            if (*piVar8 == 9) {
                iVar10 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                piVar8 = piVar8 + 2;
            } else {
                iVar10 = iVar10 + 1;
                piVar8 = piVar8 + 2;
            }
        }
        *(int32_t *)arg2 = (int32_t)arg3;
        *(int32_t *)(arg2 + 4) = iVar10;
    } else {
        *(int64_t *)arg2 = arg3;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015df90
// Address: 0x18015df90
// Size: 1594 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8
fcn.18015df90(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
             int64_t arg_38h, undefined8 placeholder_7, int64_t arg_48h)
{
    uint8_t *puVar1;
    code *pcVar2;
    char cVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int16_t *piVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint8_t *puVar15;
    uint8_t *puVar16;
    int16_t *piVar17;
    undefined *puVar18;
    uint16_t uVar19;
    uint32_t uVar20;
    uint16_t uVar21;
    uint8_t *puVar22;
    int32_t iVar23;
    uint64_t uVar24;
    int64_t iVar25;
    int64_t iVar26;
    undefined4 uVar27;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 var_18h;
    int64_t var_20h;
    undefined auStack_d8 [8];
    undefined auStack_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int32_t var_78h;
    int32_t var_74h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    uVar27 = 0;
    _var_a8h = ZEXT816(0);
    var_98h = 0;
    puVar22 = *(uint8_t **)arg3 + *(int64_t *)(arg3 + 8);
    puVar15 = *(uint8_t **)arg3;
    var_20h._0_1_ = (char)placeholder_3;
    while (puVar15 != puVar22) {
        cVar3 = -1;
        if (puVar22 <= puVar15) {
            cVar3 = '\x01';
        }
        if (-1 < cVar3) break;
        cVar3 = -1;
        if (puVar22 <= puVar15) {
            cVar3 = '\x01';
        }
        if ((cVar3 < '\0') && (uVar19 = (uint16_t)(char)*puVar15, -1 < (char)*puVar15)) {
            puVar16 = puVar15 + 1;
        } else {
            puVar16 = puVar15 + 1;
            if (puVar16 != puVar22) {
                cVar3 = -1;
                if (puVar22 <= puVar16) {
                    cVar3 = '\x01';
                }
                if ((cVar3 < '\0') && ((*puVar15 & 0xe0) == 0xc0)) {
                    uVar19 = (uint16_t)(*puVar15 & 0x1f) << 6 | (uint16_t)(*puVar16 & 0x3f);
                    puVar16 = puVar15 + 2;
                    goto code_r0x00018015e0cb;
                }
            }
            puVar1 = puVar15 + 2;
            if (puVar1 != puVar22) {
                cVar3 = -1;
                if (puVar22 <= puVar1) {
                    cVar3 = '\x01';
                }
                if ((cVar3 < '\0') && ((*puVar15 & 0xf0) == 0xe0)) {
                    uVar19 = ((uint16_t)(*puVar16 & 0x3f) | (int16_t)(char)*puVar15 << 6) << 6 |
                             (uint16_t)(*puVar1 & 0x3f);
                    puVar16 = puVar15 + 3;
                    goto code_r0x00018015e0cb;
                }
            }
            if (puVar15 + 3 != puVar22) {
                cVar3 = -1;
                if (puVar22 <= puVar15 + 3) {
                    cVar3 = '\x01';
                }
                if ((cVar3 < '\0') && ((*puVar15 & 0xf8) == 0xf0)) {
                    uVar19 = 0xfffd;
                    puVar16 = puVar15 + 4;
                    goto code_r0x00018015e0cb;
                }
            }
            uVar19 = 0xfffd;
        }
code_r0x00018015e0cb:
        if ((char)placeholder_3 == '\0') {
            if (uVar19 < 0x7f) {
                if (uVar19 - 0x41 < 0x1a) {
                    uVar19 = uVar19 | 0x20;
                }
            } else {
                iVar5 = func_0x000180164c60(uVar27, uVar19);
                if ((iVar5 != 0) && (iVar14 = *(int32_t *)(iVar5 + 8), iVar14 != 0)) {
                    if (iVar14 == 0xffff) {
                        uVar19 = uVar19 | 1;
                    } else {
                        uVar19 = uVar19 + (int16_t)iVar14;
                    }
                }
            }
        }
        var_18h = CONCAT22(var_18h._2_2_, uVar19);
        uVar27 = func_0x0001800d4930(&var_a8h, &var_18h);
        puVar15 = puVar16;
    }
    uVar20 = (uint32_t)arg2;
    uVar11 = (uint64_t)(int32_t)uVar20;
    iVar5 = *(int64_t *)(arg1 + 8);
    iVar25 = *(int64_t *)arg1;
    uVar6 = (iVar5 - iVar25 >> 3) * 0x6db6db6db6db6db7;
    if (uVar11 <= uVar6 && uVar6 - uVar11 != 0) {
        var_88h = fcn.18015d7b0(arg1, uVar11 * 0x38 + iVar25, (uint64_t)arg2 >> 0x20);
        uVar6 = arg2 & 0xffffffff;
        iVar13 = var_a8h;
        var_18h = uVar20;
        var_58h = var_88h;
        while( true ) {
            var_b8h = (int64_t)(int32_t)(uint32_t)uVar6;
            uVar11 = (iVar5 - iVar25 >> 3) * 0x6db6db6db6db6db7;
            if (uVar11 < (uint64_t)var_b8h || uVar11 - var_b8h == 0) break;
            var_60h = var_b8h * 0x38;
            piVar17 = *(int16_t **)(iVar25 + var_60h);
            iVar26 = *(int64_t *)(iVar25 + 8 + var_60h) - (int64_t)piVar17 >> 2;
            uVar24 = 0;
            var_b0h._0_4_ = (uint32_t)uVar6;
            var_90h = var_88h;
            while( true ) {
                uVar8 = var_b8h;
                uVar7 = var_a0h - iVar13 >> 1;
                iVar14 = (int32_t)uVar6;
                if (uVar7 <= uVar24) break;
                uVar19 = *(uint16_t *)(iVar13 + uVar24 * 2);
                if (uVar19 == 10) {
                    if ((var_90h != iVar26) || (iVar14 == (int32_t)uVar11 + -1)) goto code_r0x00018015e4c7;
                    uVar8 = (int64_t)iVar14 + 1;
                    if (uVar11 < uVar8 || uVar11 - uVar8 == 0) goto code_r0x00018015e5c4;
                    iVar25 = *(int64_t *)arg1;
                    var_b0h._0_4_ = iVar14 + 1;
                    uVar6 = (uint64_t)(uint32_t)var_b0h;
                    iVar26 = *(int64_t *)(uVar8 * 0x38 + 8 + iVar25) - *(int64_t *)(uVar8 * 0x38 + iVar25) >> 2;
                    iVar5 = *(int64_t *)(arg1 + 8);
                    uVar24 = uVar24 + 1;
                    var_90h = 0;
                    iVar13 = var_a8h;
                } else {
                    if (var_90h == iVar26) goto code_r0x00018015e4c7;
                    uVar8 = (uint64_t)iVar14;
                    if (uVar11 < uVar8 || uVar11 - uVar8 == 0) goto code_r0x00018015e5c4;
                    iVar13 = *(int64_t *)(uVar8 * 0x38 + iVar25);
                    uVar21 = *(uint16_t *)(iVar13 + var_90h * 4);
                    if ((char)var_20h == '\0') {
                        if (uVar21 < 0x7f) {
                            if (uVar21 - 0x41 < 0x1a) {
                                uVar21 = uVar21 | 0x20;
                            }
                        } else {
                            iVar5 = func_0x000180164c60(iVar13, uVar21);
                            if ((iVar5 != 0) && (iVar14 = *(int32_t *)(iVar5 + 8), iVar14 != 0)) {
                                if (iVar14 == 0xffff) {
                                    uVar21 = uVar21 | 1;
                                } else {
                                    uVar21 = uVar21 + (int16_t)iVar14;
                                }
                            }
                            uVar6 = (uint64_t)(uint32_t)var_b0h;
                        }
                        iVar5 = *(int64_t *)(arg1 + 8);
                        iVar25 = *(int64_t *)arg1;
                    }
                    uVar8 = var_b8h;
                    if (uVar21 != uVar19) goto code_r0x00018015e4c7;
                    var_90h = var_90h + 1;
                    uVar24 = uVar24 + 1;
                    iVar13 = var_a8h;
                }
            }
            if (uVar24 == uVar7) {
                uVar6 = (iVar5 - iVar25 >> 3) * 0x6db6db6db6db6db7;
                if (uVar6 < (uint64_t)var_b8h || uVar6 - var_b8h == 0) break;
                piVar12 = piVar17 + var_88h * 2;
                iVar23 = 0;
                while (piVar17 != piVar12) {
                    cVar3 = -1;
                    if (piVar12 <= piVar17) {
                        cVar3 = '\x01';
                    }
                    if (-1 < cVar3) break;
                    if (*piVar17 == 9) {
                        iVar23 = iVar23 + (*(int32_t *)(arg1 + 0x18) - iVar23 % *(int32_t *)(arg1 + 0x18));
                        piVar17 = piVar17 + 2;
                    } else {
                        iVar23 = iVar23 + 1;
                        piVar17 = piVar17 + 2;
                    }
                }
                *(uint32_t *)arg_30h = var_18h;
                *(int32_t *)(arg_30h + 4) = iVar23;
                uVar11 = (uint64_t)iVar14;
                uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
                if (uVar6 < uVar11 || uVar6 - uVar11 == 0) break;
                piVar12 = *(int16_t **)(uVar11 * 0x38 + *(int64_t *)arg1);
                piVar17 = piVar12 + var_90h * 2;
                iVar23 = 0;
                while (piVar12 != piVar17) {
                    cVar3 = -1;
                    if (piVar17 <= piVar12) {
                        cVar3 = '\x01';
                    }
                    if (-1 < cVar3) break;
                    if (*piVar12 == 9) {
                        iVar23 = iVar23 + (*(int32_t *)(arg1 + 0x18) - iVar23 % *(int32_t *)(arg1 + 0x18));
                        piVar12 = piVar12 + 2;
                    } else {
                        iVar23 = iVar23 + 1;
                        piVar12 = piVar12 + 2;
                    }
                }
                *(int32_t *)arg_38h = iVar14;
                *(int32_t *)(arg_38h + 4) = iVar23;
                if ((char)arg_28h == '\0') {
code_r0x00018015e59a:
                    uVar9 = 1;
                    goto code_r0x00018015e561;
                }
                iVar23 = (int32_t)*(undefined8 *)arg_38h;
                iVar14 = (int32_t)*(undefined8 *)arg_30h;
                if (iVar14 == iVar23) {
                    iVar4 = (int32_t)((uint64_t)*(undefined8 *)arg_38h >> 0x20);
                    iVar10 = (int32_t)((uint64_t)*(undefined8 *)arg_30h >> 0x20);
                    if (0 < iVar4 - iVar10) {
                        var_80h._4_4_ = iVar10 + 1;
                        var_80h._0_4_ = iVar14;
                        fcn.18015db90(arg1, (int64_t)&var_70h, CONCAT44(var_80h._4_4_, iVar14));
                        var_74h = iVar4 + -1;
                        var_78h = iVar23;
                        fcn.18015dd90(arg1, (int64_t)&var_68h, CONCAT44(var_74h, iVar23));
                        if ((((iVar14 == (int32_t)var_70h) && (iVar10 == var_70h._4_4_)) && (iVar23 == (int32_t)var_68h)
                            ) && (iVar4 == var_68h._4_4_)) goto code_r0x00018015e59a;
                    }
                }
code_r0x00018015e4c7:
                iVar13 = var_a8h;
            }
            iVar5 = *(int64_t *)(arg1 + 8);
            iVar25 = *(int64_t *)arg1;
            uVar11 = (iVar5 - iVar25 >> 3) * 0x6db6db6db6db6db7;
            if (uVar11 < uVar8 || uVar11 - uVar8 == 0) break;
            uVar6 = (uint64_t)var_18h;
            if (var_88h == *(int64_t *)(var_60h + 8 + iVar25) - *(int64_t *)(var_60h + iVar25) >> 2) {
                if (var_18h == (int32_t)uVar11 - 1U) {
                    uVar6 = 0;
                    var_18h = 0;
                    var_88h = 0;
                } else {
                    var_18h = var_18h + 1;
                    uVar6 = (uint64_t)var_18h;
                    var_88h = 0;
                }
            } else {
                var_88h = var_88h + 1;
            }
            if (((uint32_t)uVar6 == uVar20) && (var_88h == var_58h)) {
                uVar9 = 0;
code_r0x00018015e561:
                if (var_a8h != 0) {
                    uVar6 = var_a8h;
                    puVar18 = auStack_d8;
                    if (0xfff < (uint64_t)((var_98h - var_a8h >> 1) * 2)) {
                        uVar6 = *(uint64_t *)(var_a8h + -8);
                        uVar11 = (var_a8h - uVar6) - 8;
                        puVar18 = auStack_d8;
                        if (0x1f < uVar11) {
                            pcVar2 = (code *)swi(0x29);
                            uVar6 = uVar11;
                            (*pcVar2)(5);
                            puVar18 = auStack_d0;
                        }
                    }
                    *(undefined8 *)(puVar18 + -8) = 0x18015e5ad;
                    func_0x000180459c3c(uVar6);
                }
                return uVar9;
            }
        }
    }
code_r0x00018015e5c4:
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    uVar9 = (*pcVar2)();
    return uVar9;
}

// ============================================================
// Function: FUN_18015e5d0
// Address: 0x18015e5d0
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015e5d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int16_t **ppiVar3;
    int64_t iVar4;
    int16_t *piVar5;
    uint64_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int32_t)arg3;
    if (iVar7 < 0) {
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    iVar4 = *(int64_t *)arg1;
    uVar2 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
    if (iVar7 < (int32_t)uVar2) {
        var_18h._4_4_ = (int32_t)((uint64_t)arg3 >> 0x20);
        if (arg3 < 0) {
            *(int32_t *)arg2 = iVar7;
            *(undefined4 *)(arg2 + 4) = 0;
        } else {
            uVar6 = (uint64_t)iVar7;
            if (uVar2 < uVar6 || uVar2 - uVar6 == 0) goto code_r0x00018015e703;
            if (*(int32_t *)(uVar6 * 0x38 + 0x28 + iVar4) < var_18h._4_4_) {
                iVar4 = fcn.180163b10(arg1);
                *(undefined4 *)(arg2 + 4) = *(undefined4 *)(iVar4 + 0x28);
            } else {
                ppiVar3 = (int16_t **)fcn.180163b10(arg1);
                iVar9 = 0;
                iVar10 = 0;
                if (0xffffffff < arg3) {
                    piVar5 = *ppiVar3;
                    do {
                        iVar8 = iVar9;
                        iVar9 = iVar8;
                        if (ppiVar3[1] <= piVar5) break;
                        if (*piVar5 == 9) {
                            iVar9 = iVar8 + (*(int32_t *)(arg1 + 0x18) - iVar8 % *(int32_t *)(arg1 + 0x18));
                        } else {
                            iVar9 = iVar8 + 1;
                        }
                        piVar5 = piVar5 + 2;
                        iVar10 = iVar8;
                    } while (iVar9 < var_18h._4_4_);
                }
                if (var_18h._4_4_ - iVar10 <= iVar9 - var_18h._4_4_) {
                    iVar9 = iVar10;
                }
                *(int32_t *)(arg2 + 4) = iVar9;
            }
            *(int32_t *)arg2 = iVar7;
        }
    } else {
        uVar6 = uVar2 - 1;
        if (uVar2 < uVar6 || uVar2 - uVar6 == 0) {
code_r0x00018015e703:
            fcn.180060370();
            pcVar1 = (code *)swi(3);
            iVar4 = (*pcVar1)();
            return iVar4;
        }
        *(int32_t *)arg2 = (int32_t)uVar2 + -1;
        *(undefined4 *)(arg2 + 4) = *(undefined4 *)(uVar6 * 0x38 + 0x28 + iVar4);
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015e621
// Address: 0x18015e621
// Size: 226 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015e5d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int16_t **ppiVar3;
    int64_t iVar4;
    int16_t *piVar5;
    uint64_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int32_t)arg3;
    if (iVar7 < 0) {
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    iVar4 = *(int64_t *)arg1;
    uVar2 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
    if (iVar7 < (int32_t)uVar2) {
        var_18h._4_4_ = (int32_t)((uint64_t)arg3 >> 0x20);
        if (arg3 < 0) {
            *(int32_t *)arg2 = iVar7;
            *(undefined4 *)(arg2 + 4) = 0;
        } else {
            uVar6 = (uint64_t)iVar7;
            if (uVar2 < uVar6 || uVar2 - uVar6 == 0) goto code_r0x00018015e703;
            if (*(int32_t *)(uVar6 * 0x38 + 0x28 + iVar4) < var_18h._4_4_) {
                iVar4 = fcn.180163b10(arg1);
                *(undefined4 *)(arg2 + 4) = *(undefined4 *)(iVar4 + 0x28);
            } else {
                ppiVar3 = (int16_t **)fcn.180163b10(arg1);
                iVar9 = 0;
                iVar10 = 0;
                if (0xffffffff < arg3) {
                    piVar5 = *ppiVar3;
                    do {
                        iVar8 = iVar9;
                        iVar9 = iVar8;
                        if (ppiVar3[1] <= piVar5) break;
                        if (*piVar5 == 9) {
                            iVar9 = iVar8 + (*(int32_t *)(arg1 + 0x18) - iVar8 % *(int32_t *)(arg1 + 0x18));
                        } else {
                            iVar9 = iVar8 + 1;
                        }
                        piVar5 = piVar5 + 2;
                        iVar10 = iVar8;
                    } while (iVar9 < var_18h._4_4_);
                }
                if (var_18h._4_4_ - iVar10 <= iVar9 - var_18h._4_4_) {
                    iVar9 = iVar10;
                }
                *(int32_t *)(arg2 + 4) = iVar9;
            }
            *(int32_t *)arg2 = iVar7;
        }
    } else {
        uVar6 = uVar2 - 1;
        if (uVar2 < uVar6 || uVar2 - uVar6 == 0) {
code_r0x00018015e703:
            fcn.180060370();
            pcVar1 = (code *)swi(3);
            iVar4 = (*pcVar1)();
            return iVar4;
        }
        *(int32_t *)arg2 = (int32_t)uVar2 + -1;
        *(undefined4 *)(arg2 + 4) = *(undefined4 *)(uVar6 * 0x38 + 0x28 + iVar4);
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015e703
// Address: 0x18015e703
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18015e5d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int16_t **ppiVar3;
    int64_t iVar4;
    int16_t *piVar5;
    uint64_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int32_t)arg3;
    if (iVar7 < 0) {
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    iVar4 = *(int64_t *)arg1;
    uVar2 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
    if (iVar7 < (int32_t)uVar2) {
        var_18h._4_4_ = (int32_t)((uint64_t)arg3 >> 0x20);
        if (arg3 < 0) {
            *(int32_t *)arg2 = iVar7;
            *(undefined4 *)(arg2 + 4) = 0;
        } else {
            uVar6 = (uint64_t)iVar7;
            if (uVar2 < uVar6 || uVar2 - uVar6 == 0) goto code_r0x00018015e703;
            if (*(int32_t *)(uVar6 * 0x38 + 0x28 + iVar4) < var_18h._4_4_) {
                iVar4 = fcn.180163b10(arg1);
                *(undefined4 *)(arg2 + 4) = *(undefined4 *)(iVar4 + 0x28);
            } else {
                ppiVar3 = (int16_t **)fcn.180163b10(arg1);
                iVar9 = 0;
                iVar10 = 0;
                if (0xffffffff < arg3) {
                    piVar5 = *ppiVar3;
                    do {
                        iVar8 = iVar9;
                        iVar9 = iVar8;
                        if (ppiVar3[1] <= piVar5) break;
                        if (*piVar5 == 9) {
                            iVar9 = iVar8 + (*(int32_t *)(arg1 + 0x18) - iVar8 % *(int32_t *)(arg1 + 0x18));
                        } else {
                            iVar9 = iVar8 + 1;
                        }
                        piVar5 = piVar5 + 2;
                        iVar10 = iVar8;
                    } while (iVar9 < var_18h._4_4_);
                }
                if (var_18h._4_4_ - iVar10 <= iVar9 - var_18h._4_4_) {
                    iVar9 = iVar10;
                }
                *(int32_t *)(arg2 + 4) = iVar9;
            }
            *(int32_t *)arg2 = iVar7;
        }
    } else {
        uVar6 = uVar2 - 1;
        if (uVar2 < uVar6 || uVar2 - uVar6 == 0) {
code_r0x00018015e703:
            fcn.180060370();
            pcVar1 = (code *)swi(3);
            iVar4 = (*pcVar1)();
            return iVar4;
        }
        *(int32_t *)arg2 = (int32_t)uVar2 + -1;
        *(undefined4 *)(arg2 + 4) = *(undefined4 *)(uVar6 * 0x38 + 0x28 + iVar4);
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015e710
// Address: 0x18015e710
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015e710(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int16_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int16_t **ppiVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int16_t *piVar8;
    undefined8 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.0 <= in_XMM1_Da) {
        iVar4 = *(int64_t *)arg1;
        uVar7 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
        iVar6 = (int32_t)uVar7;
        if (in_XMM1_Da < (float)iVar6) {
            uVar12 = (uint32_t)in_XMM1_Da;
            if (0.0 <= in_XMM2_Da) {
                uVar3 = (uint64_t)(int32_t)uVar12;
                if (uVar7 < uVar3 || uVar7 - uVar3 == 0) goto code_r0x00018015e8cf;
                if (in_XMM2_Da < (float)*(int32_t *)(uVar3 * 0x38 + 0x28 + iVar4)) {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    piVar1 = *(int16_t **)(iVar4 + 8);
                    ppiVar5 = (int16_t **)fcn.180163b10(arg1, uVar3);
                    iVar6 = 0;
                    iVar11 = 0;
                    if (0.0 < in_XMM2_Da) {
                        piVar8 = *ppiVar5;
                        iVar10 = 0;
                        do {
                            iVar11 = iVar10;
                            if (piVar1 <= piVar8) break;
                            if (*piVar8 == 9) {
                                iVar11 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                            } else {
                                iVar11 = iVar10 + 1;
                            }
                            piVar8 = piVar8 + 2;
                            iVar6 = iVar10;
                            iVar10 = iVar11;
                        } while ((float)iVar11 < in_XMM2_Da);
                    }
                    *(uint32_t *)arg4 = uVar12;
                    *(int32_t *)(arg4 + 4) = iVar6;
                    *(uint32_t *)arg_28h = uVar12;
                    if (in_XMM2_Da - (float)iVar6 <= (float)iVar11 - in_XMM2_Da) {
                        iVar11 = iVar6;
                    }
                    *(int32_t *)(arg_28h + 4) = iVar11;
                } else {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    uVar9 = CONCAT44(*(undefined4 *)(iVar4 + 0x28), uVar12);
                    *(undefined8 *)arg4 = uVar9;
                    *(undefined8 *)arg_28h = uVar9;
                }
            } else {
                *(uint64_t *)arg4 = (uint64_t)uVar12;
                *(uint64_t *)arg_28h = (uint64_t)uVar12;
            }
        } else {
            uVar3 = (int64_t)iVar6 - 1;
            if (uVar7 < uVar3 || uVar7 - uVar3 == 0) {
code_r0x00018015e8cf:
                fcn.180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            uVar9 = CONCAT44(*(undefined4 *)(uVar3 * 0x38 + 0x28 + iVar4), iVar6 + -1);
            *(undefined8 *)arg4 = uVar9;
            *(undefined8 *)arg_28h = uVar9;
        }
    } else {
        *(undefined8 *)arg4 = 0;
        *(undefined8 *)arg_28h = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18015e75e
// Address: 0x18015e75e
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015e710(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int16_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int16_t **ppiVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int16_t *piVar8;
    undefined8 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.0 <= in_XMM1_Da) {
        iVar4 = *(int64_t *)arg1;
        uVar7 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
        iVar6 = (int32_t)uVar7;
        if (in_XMM1_Da < (float)iVar6) {
            uVar12 = (uint32_t)in_XMM1_Da;
            if (0.0 <= in_XMM2_Da) {
                uVar3 = (uint64_t)(int32_t)uVar12;
                if (uVar7 < uVar3 || uVar7 - uVar3 == 0) goto code_r0x00018015e8cf;
                if (in_XMM2_Da < (float)*(int32_t *)(uVar3 * 0x38 + 0x28 + iVar4)) {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    piVar1 = *(int16_t **)(iVar4 + 8);
                    ppiVar5 = (int16_t **)fcn.180163b10(arg1, uVar3);
                    iVar6 = 0;
                    iVar11 = 0;
                    if (0.0 < in_XMM2_Da) {
                        piVar8 = *ppiVar5;
                        iVar10 = 0;
                        do {
                            iVar11 = iVar10;
                            if (piVar1 <= piVar8) break;
                            if (*piVar8 == 9) {
                                iVar11 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                            } else {
                                iVar11 = iVar10 + 1;
                            }
                            piVar8 = piVar8 + 2;
                            iVar6 = iVar10;
                            iVar10 = iVar11;
                        } while ((float)iVar11 < in_XMM2_Da);
                    }
                    *(uint32_t *)arg4 = uVar12;
                    *(int32_t *)(arg4 + 4) = iVar6;
                    *(uint32_t *)arg_28h = uVar12;
                    if (in_XMM2_Da - (float)iVar6 <= (float)iVar11 - in_XMM2_Da) {
                        iVar11 = iVar6;
                    }
                    *(int32_t *)(arg_28h + 4) = iVar11;
                } else {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    uVar9 = CONCAT44(*(undefined4 *)(iVar4 + 0x28), uVar12);
                    *(undefined8 *)arg4 = uVar9;
                    *(undefined8 *)arg_28h = uVar9;
                }
            } else {
                *(uint64_t *)arg4 = (uint64_t)uVar12;
                *(uint64_t *)arg_28h = (uint64_t)uVar12;
            }
        } else {
            uVar3 = (int64_t)iVar6 - 1;
            if (uVar7 < uVar3 || uVar7 - uVar3 == 0) {
code_r0x00018015e8cf:
                fcn.180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            uVar9 = CONCAT44(*(undefined4 *)(uVar3 * 0x38 + 0x28 + iVar4), iVar6 + -1);
            *(undefined8 *)arg4 = uVar9;
            *(undefined8 *)arg_28h = uVar9;
        }
    } else {
        *(undefined8 *)arg4 = 0;
        *(undefined8 *)arg_28h = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18015e818
// Address: 0x18015e818
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015e710(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int16_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int16_t **ppiVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int16_t *piVar8;
    undefined8 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.0 <= in_XMM1_Da) {
        iVar4 = *(int64_t *)arg1;
        uVar7 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
        iVar6 = (int32_t)uVar7;
        if (in_XMM1_Da < (float)iVar6) {
            uVar12 = (uint32_t)in_XMM1_Da;
            if (0.0 <= in_XMM2_Da) {
                uVar3 = (uint64_t)(int32_t)uVar12;
                if (uVar7 < uVar3 || uVar7 - uVar3 == 0) goto code_r0x00018015e8cf;
                if (in_XMM2_Da < (float)*(int32_t *)(uVar3 * 0x38 + 0x28 + iVar4)) {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    piVar1 = *(int16_t **)(iVar4 + 8);
                    ppiVar5 = (int16_t **)fcn.180163b10(arg1, uVar3);
                    iVar6 = 0;
                    iVar11 = 0;
                    if (0.0 < in_XMM2_Da) {
                        piVar8 = *ppiVar5;
                        iVar10 = 0;
                        do {
                            iVar11 = iVar10;
                            if (piVar1 <= piVar8) break;
                            if (*piVar8 == 9) {
                                iVar11 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                            } else {
                                iVar11 = iVar10 + 1;
                            }
                            piVar8 = piVar8 + 2;
                            iVar6 = iVar10;
                            iVar10 = iVar11;
                        } while ((float)iVar11 < in_XMM2_Da);
                    }
                    *(uint32_t *)arg4 = uVar12;
                    *(int32_t *)(arg4 + 4) = iVar6;
                    *(uint32_t *)arg_28h = uVar12;
                    if (in_XMM2_Da - (float)iVar6 <= (float)iVar11 - in_XMM2_Da) {
                        iVar11 = iVar6;
                    }
                    *(int32_t *)(arg_28h + 4) = iVar11;
                } else {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    uVar9 = CONCAT44(*(undefined4 *)(iVar4 + 0x28), uVar12);
                    *(undefined8 *)arg4 = uVar9;
                    *(undefined8 *)arg_28h = uVar9;
                }
            } else {
                *(uint64_t *)arg4 = (uint64_t)uVar12;
                *(uint64_t *)arg_28h = (uint64_t)uVar12;
            }
        } else {
            uVar3 = (int64_t)iVar6 - 1;
            if (uVar7 < uVar3 || uVar7 - uVar3 == 0) {
code_r0x00018015e8cf:
                fcn.180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            uVar9 = CONCAT44(*(undefined4 *)(uVar3 * 0x38 + 0x28 + iVar4), iVar6 + -1);
            *(undefined8 *)arg4 = uVar9;
            *(undefined8 *)arg_28h = uVar9;
        }
    } else {
        *(undefined8 *)arg4 = 0;
        *(undefined8 *)arg_28h = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18015e8b1
// Address: 0x18015e8b1
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015e710(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int16_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int16_t **ppiVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int16_t *piVar8;
    undefined8 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.0 <= in_XMM1_Da) {
        iVar4 = *(int64_t *)arg1;
        uVar7 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
        iVar6 = (int32_t)uVar7;
        if (in_XMM1_Da < (float)iVar6) {
            uVar12 = (uint32_t)in_XMM1_Da;
            if (0.0 <= in_XMM2_Da) {
                uVar3 = (uint64_t)(int32_t)uVar12;
                if (uVar7 < uVar3 || uVar7 - uVar3 == 0) goto code_r0x00018015e8cf;
                if (in_XMM2_Da < (float)*(int32_t *)(uVar3 * 0x38 + 0x28 + iVar4)) {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    piVar1 = *(int16_t **)(iVar4 + 8);
                    ppiVar5 = (int16_t **)fcn.180163b10(arg1, uVar3);
                    iVar6 = 0;
                    iVar11 = 0;
                    if (0.0 < in_XMM2_Da) {
                        piVar8 = *ppiVar5;
                        iVar10 = 0;
                        do {
                            iVar11 = iVar10;
                            if (piVar1 <= piVar8) break;
                            if (*piVar8 == 9) {
                                iVar11 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                            } else {
                                iVar11 = iVar10 + 1;
                            }
                            piVar8 = piVar8 + 2;
                            iVar6 = iVar10;
                            iVar10 = iVar11;
                        } while ((float)iVar11 < in_XMM2_Da);
                    }
                    *(uint32_t *)arg4 = uVar12;
                    *(int32_t *)(arg4 + 4) = iVar6;
                    *(uint32_t *)arg_28h = uVar12;
                    if (in_XMM2_Da - (float)iVar6 <= (float)iVar11 - in_XMM2_Da) {
                        iVar11 = iVar6;
                    }
                    *(int32_t *)(arg_28h + 4) = iVar11;
                } else {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    uVar9 = CONCAT44(*(undefined4 *)(iVar4 + 0x28), uVar12);
                    *(undefined8 *)arg4 = uVar9;
                    *(undefined8 *)arg_28h = uVar9;
                }
            } else {
                *(uint64_t *)arg4 = (uint64_t)uVar12;
                *(uint64_t *)arg_28h = (uint64_t)uVar12;
            }
        } else {
            uVar3 = (int64_t)iVar6 - 1;
            if (uVar7 < uVar3 || uVar7 - uVar3 == 0) {
code_r0x00018015e8cf:
                fcn.180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            uVar9 = CONCAT44(*(undefined4 *)(uVar3 * 0x38 + 0x28 + iVar4), iVar6 + -1);
            *(undefined8 *)arg4 = uVar9;
            *(undefined8 *)arg_28h = uVar9;
        }
    } else {
        *(undefined8 *)arg4 = 0;
        *(undefined8 *)arg_28h = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18015e8bb
// Address: 0x18015e8bb
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015e710(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int16_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int16_t **ppiVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int16_t *piVar8;
    undefined8 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.0 <= in_XMM1_Da) {
        iVar4 = *(int64_t *)arg1;
        uVar7 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
        iVar6 = (int32_t)uVar7;
        if (in_XMM1_Da < (float)iVar6) {
            uVar12 = (uint32_t)in_XMM1_Da;
            if (0.0 <= in_XMM2_Da) {
                uVar3 = (uint64_t)(int32_t)uVar12;
                if (uVar7 < uVar3 || uVar7 - uVar3 == 0) goto code_r0x00018015e8cf;
                if (in_XMM2_Da < (float)*(int32_t *)(uVar3 * 0x38 + 0x28 + iVar4)) {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    piVar1 = *(int16_t **)(iVar4 + 8);
                    ppiVar5 = (int16_t **)fcn.180163b10(arg1, uVar3);
                    iVar6 = 0;
                    iVar11 = 0;
                    if (0.0 < in_XMM2_Da) {
                        piVar8 = *ppiVar5;
                        iVar10 = 0;
                        do {
                            iVar11 = iVar10;
                            if (piVar1 <= piVar8) break;
                            if (*piVar8 == 9) {
                                iVar11 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                            } else {
                                iVar11 = iVar10 + 1;
                            }
                            piVar8 = piVar8 + 2;
                            iVar6 = iVar10;
                            iVar10 = iVar11;
                        } while ((float)iVar11 < in_XMM2_Da);
                    }
                    *(uint32_t *)arg4 = uVar12;
                    *(int32_t *)(arg4 + 4) = iVar6;
                    *(uint32_t *)arg_28h = uVar12;
                    if (in_XMM2_Da - (float)iVar6 <= (float)iVar11 - in_XMM2_Da) {
                        iVar11 = iVar6;
                    }
                    *(int32_t *)(arg_28h + 4) = iVar11;
                } else {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    uVar9 = CONCAT44(*(undefined4 *)(iVar4 + 0x28), uVar12);
                    *(undefined8 *)arg4 = uVar9;
                    *(undefined8 *)arg_28h = uVar9;
                }
            } else {
                *(uint64_t *)arg4 = (uint64_t)uVar12;
                *(uint64_t *)arg_28h = (uint64_t)uVar12;
            }
        } else {
            uVar3 = (int64_t)iVar6 - 1;
            if (uVar7 < uVar3 || uVar7 - uVar3 == 0) {
code_r0x00018015e8cf:
                fcn.180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            uVar9 = CONCAT44(*(undefined4 *)(uVar3 * 0x38 + 0x28 + iVar4), iVar6 + -1);
            *(undefined8 *)arg4 = uVar9;
            *(undefined8 *)arg_28h = uVar9;
        }
    } else {
        *(undefined8 *)arg4 = 0;
        *(undefined8 *)arg_28h = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18015e8cf
// Address: 0x18015e8cf
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015e710(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int16_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int16_t **ppiVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int16_t *piVar8;
    undefined8 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (0.0 <= in_XMM1_Da) {
        iVar4 = *(int64_t *)arg1;
        uVar7 = (*(int64_t *)(arg1 + 8) - iVar4 >> 3) * 0x6db6db6db6db6db7;
        iVar6 = (int32_t)uVar7;
        if (in_XMM1_Da < (float)iVar6) {
            uVar12 = (uint32_t)in_XMM1_Da;
            if (0.0 <= in_XMM2_Da) {
                uVar3 = (uint64_t)(int32_t)uVar12;
                if (uVar7 < uVar3 || uVar7 - uVar3 == 0) goto code_r0x00018015e8cf;
                if (in_XMM2_Da < (float)*(int32_t *)(uVar3 * 0x38 + 0x28 + iVar4)) {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    piVar1 = *(int16_t **)(iVar4 + 8);
                    ppiVar5 = (int16_t **)fcn.180163b10(arg1, uVar3);
                    iVar6 = 0;
                    iVar11 = 0;
                    if (0.0 < in_XMM2_Da) {
                        piVar8 = *ppiVar5;
                        iVar10 = 0;
                        do {
                            iVar11 = iVar10;
                            if (piVar1 <= piVar8) break;
                            if (*piVar8 == 9) {
                                iVar11 = iVar10 + (*(int32_t *)(arg1 + 0x18) - iVar10 % *(int32_t *)(arg1 + 0x18));
                            } else {
                                iVar11 = iVar10 + 1;
                            }
                            piVar8 = piVar8 + 2;
                            iVar6 = iVar10;
                            iVar10 = iVar11;
                        } while ((float)iVar11 < in_XMM2_Da);
                    }
                    *(uint32_t *)arg4 = uVar12;
                    *(int32_t *)(arg4 + 4) = iVar6;
                    *(uint32_t *)arg_28h = uVar12;
                    if (in_XMM2_Da - (float)iVar6 <= (float)iVar11 - in_XMM2_Da) {
                        iVar11 = iVar6;
                    }
                    *(int32_t *)(arg_28h + 4) = iVar11;
                } else {
                    iVar4 = fcn.180163b10(arg1, uVar3);
                    uVar9 = CONCAT44(*(undefined4 *)(iVar4 + 0x28), uVar12);
                    *(undefined8 *)arg4 = uVar9;
                    *(undefined8 *)arg_28h = uVar9;
                }
            } else {
                *(uint64_t *)arg4 = (uint64_t)uVar12;
                *(uint64_t *)arg_28h = (uint64_t)uVar12;
            }
        } else {
            uVar3 = (int64_t)iVar6 - 1;
            if (uVar7 < uVar3 || uVar7 - uVar3 == 0) {
code_r0x00018015e8cf:
                fcn.180060370();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            uVar9 = CONCAT44(*(undefined4 *)(uVar3 * 0x38 + 0x28 + iVar4), iVar6 + -1);
            *(undefined8 *)arg4 = uVar9;
            *(undefined8 *)arg_28h = uVar9;
        }
    } else {
        *(undefined8 *)arg4 = 0;
        *(undefined8 *)arg_28h = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18015e8e0
// Address: 0x18015e8e0
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015e8e0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int64_t *)(arg1 + 0xa0) != 0) {
        iVar4 = *(int64_t *)(arg1 + 8);
        iVar9 = *(int64_t *)arg1;
        if (-1 < (int32_t)(iVar4 - iVar9 >> 3) * -0x49249249) {
            iVar8 = 0;
            do {
                uVar7 = (uint64_t)iVar8;
                uVar5 = (iVar4 - iVar9 >> 3) * 0x6db6db6db6db6db7;
                if (uVar5 < uVar7 || uVar5 - uVar7 == 0) {
                    fcn.180060370();
                    pcVar2 = (code *)swi(3);
                    (*pcVar2)();
                    return;
                }
                var_10h = *(int64_t *)(uVar7 * 0x38 + 0x30 + iVar9);
                piVar1 = *(int64_t **)(arg1 + 0xa0);
                var_8h._0_4_ = iVar8;
                if (piVar1 == (int64_t *)0x0) {
                    func_0x000180454690();
                    pcVar2 = (code *)swi(3);
                    (*pcVar2)();
                    return;
                }
                (**(code **)(*piVar1 + 0x10))(piVar1, &var_8h, &var_10h);
                iVar4 = *(int64_t *)(arg1 + 8);
                iVar8 = iVar8 + 1;
                iVar9 = *(int64_t *)arg1;
                iVar3 = (int32_t)(iVar4 - iVar9 >> 3);
                iVar6 = iVar3 * -0x49249249;
            } while (iVar8 == iVar6 || SBORROW4(iVar8, iVar6) != iVar8 + iVar3 * 0x49249249 < 0);
        }
    }
    iVar4 = *(int64_t *)(arg1 + 8);
    iVar9 = *(int64_t *)arg1;
    if (iVar9 != iVar4) {
        do {
            func_0x00018002ee50(iVar9);
            iVar9 = iVar9 + 0x38;
        } while (iVar9 != iVar4);
        *(undefined8 *)(arg1 + 8) = *(undefined8 *)arg1;
    }
    return;
}

// ============================================================
// Function: FUN_18015e9e0
// Address: 0x18015e9e0
// Size: 3443 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_12fh
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h

void fcn.18015e9e0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined auVar4 [16];
    char cVar5;
    char cVar6;
    uint8_t uVar7;
    int32_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    uint16_t *puVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    uint16_t *puVar17;
    uint16_t *puVar18;
    undefined *puVar19;
    uint32_t unaff_EDI;
    uint32_t uVar20;
    int64_t *piVar21;
    uint64_t uVar22;
    char cVar23;
    undefined uVar24;
    uint16_t uVar25;
    bool bVar26;
    undefined4 uVar27;
    int64_t var_8h;
    undefined auStack_178 [8];
    undefined auStack_170 [24];
    int64_t var_158h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    uint8_t var_130h;
    uint8_t var_12fh;
    uint8_t var_12eh;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t iStack_78;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    cVar23 = *(char *)(arg2 + 0x18);
    var_138h._0_4_ = unaff_EDI & 0xffffff00;
    puVar12 = *(uint16_t **)arg2;
    var_148h._0_1_ = cVar23;
    var_140h = (int64_t)*(uint16_t **)arg2;
    var_110h = arg3;
    var_108h = arg2;
    cVar6 = cVar23;
    uVar20 = (uint32_t)var_138h;
code_r0x00018015ea48:
    do {
        puVar18 = puVar12;
        puVar12 = *(uint16_t **)(arg2 + 8);
        puVar19 = auStack_178;
        if (puVar18 == puVar12) {
code_r0x00018015f70c:
            *(undefined *)(arg2 + 0x2c) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x18015f720;
            func_0x000180459870(var_48h ^ (uint64_t)puVar19);
            return;
        }
        cVar5 = -1;
        if (puVar12 <= puVar18) {
            cVar5 = '\x01';
        }
        puVar19 = auStack_178;
        if (-1 < cVar5) goto code_r0x00018015f70c;
        if (cVar6 == '\0') {
            if ((((char)uVar20 == '\0') && (*(uint16_t *)(arg3 + 0x22) != 0)) &&
               (*puVar18 != *(uint16_t *)(arg3 + 0x22))) {
                cVar6 = func_0x000180162130();
                var_138h._0_4_ = uVar20 & 0xff;
                if (cVar6 == '\0') {
                    var_138h._0_4_ = 1;
                }
            }
            uVar25 = *puVar18;
            cVar6 = func_0x000180162130(uVar25);
            if (cVar6 == '\0') {
                if (*(int64_t *)(arg3 + 0x38) != 0) {
                    if (*(uint64_t *)(arg3 + 0x40) < 0x10) {
                        var_e8h = arg3 + 0x28;
                    } else {
                        var_e8h = *(int64_t *)(arg3 + 0x28);
                    }
                    var_e0h = *(int64_t *)(arg3 + 0x38);
                    puVar12 = *(uint16_t **)(arg2 + 8);
                    cVar6 = func_0x00018015f840(var_e8h, puVar18, puVar12, &var_e8h);
                    puVar17 = puVar18;
                    if (cVar6 == '\0') goto code_r0x00018015eb1f;
                    for (; puVar17 != puVar12; puVar17 = puVar17 + 2) {
                        cVar6 = -1;
                        if (puVar12 <= puVar17) {
                            cVar6 = '\x01';
                        }
                        if (-1 < cVar6) break;
                        *(undefined *)(puVar17 + 1) = 9;
                    }
code_r0x00018015eb16:
                    var_140h = *(int64_t *)(arg2 + 8);
                    goto code_r0x00018015ee44;
                }
code_r0x00018015eb1f:
                if (*(int64_t *)(arg3 + 0x58) != 0) {
                    if (*(uint64_t *)(arg3 + 0x60) < 0x10) {
                        var_d8h = arg3 + 0x48;
                    } else {
                        var_d8h = *(int64_t *)(arg3 + 0x48);
                    }
                    var_d0h = *(int64_t *)(arg3 + 0x58);
                    puVar12 = *(uint16_t **)(arg2 + 8);
                    cVar6 = func_0x00018015f840(var_d8h, puVar18, puVar12, &var_d8h);
                    puVar17 = puVar18;
                    if (cVar6 != '\0') {
                        for (; puVar17 != puVar12; puVar17 = puVar17 + 2) {
                            cVar6 = -1;
                            if (puVar12 <= puVar17) {
                                cVar6 = '\x01';
                            }
                            if (-1 < cVar6) break;
                            *(undefined *)(puVar17 + 1) = 9;
                        }
                        goto code_r0x00018015eb16;
                    }
                }
                if (*(int64_t *)(arg3 + 0x78) != 0) {
                    if (*(uint64_t *)(arg3 + 0x80) < 0x10) {
                        var_c8h = arg3 + 0x68;
                    } else {
                        var_c8h = *(int64_t *)(arg3 + 0x68);
                    }
                    var_c0h = *(int64_t *)(arg3 + 0x78);
                    cVar6 = func_0x00018015f840(var_c8h, puVar18, *(uint64_t *)(arg2 + 8), &var_c8h);
                    if (cVar6 != '\0') {
                        var_148h._0_1_ = '\x01';
                        var_140h = (int64_t)(puVar18 + *(int64_t *)(arg3 + 0x98) * 2);
                        for (puVar12 = puVar18; puVar12 != (uint16_t *)var_140h; puVar12 = puVar12 + 2) {
                            cVar6 = -1;
                            if ((uint64_t)var_140h <= puVar12) {
                                cVar6 = '\x01';
                            }
                            if (-1 < cVar6) break;
                            *(undefined *)(puVar12 + 1) = 9;
                        }
                        goto code_r0x00018015ee44;
                    }
                }
                iVar10 = *(int64_t *)(arg3 + 0xc0);
                if (iVar10 != 0) {
                    if (*(uint64_t *)(arg3 + 200) < 0x10) {
                        var_b8h = arg3 + 0xb0;
                    } else {
                        var_b8h = *(int64_t *)(arg3 + 0xb0);
                    }
                    var_b0h = *(int64_t *)(arg3 + 0xc0);
                    cVar6 = func_0x00018015f840(var_b8h, puVar18, *(uint64_t *)(arg2 + 8), &var_b8h);
                    if (cVar6 != '\0') {
                        var_148h._0_1_ = '\x04';
                        var_140h = (int64_t)(puVar18 + iVar10 * 2);
                        for (puVar12 = puVar18; puVar12 != (uint16_t *)var_140h; puVar12 = puVar12 + 2) {
                            cVar6 = -1;
                            if ((uint64_t)var_140h <= puVar12) {
                                cVar6 = '\x01';
                            }
                            if (-1 < cVar6) break;
                            *(undefined *)(puVar12 + 1) = 4;
                        }
                        goto code_r0x00018015ee44;
                    }
                }
                iVar10 = *(int64_t *)(arg3 + 0x100);
                if (iVar10 != 0) {
                    if (*(uint64_t *)(arg3 + 0x108) < 0x10) {
                        var_a8h = arg3 + 0xf0;
                    } else {
                        var_a8h = *(int64_t *)(arg3 + 0xf0);
                    }
                    var_a0h = *(int64_t *)(arg3 + 0x100);
                    cVar6 = func_0x00018015f840(var_a8h, puVar18, *(uint64_t *)(arg2 + 8), &var_a8h);
                    if (cVar6 != '\0') {
                        var_148h._0_1_ = '\x05';
                        var_140h = (int64_t)(puVar18 + iVar10 * 2);
                        for (puVar12 = puVar18; puVar12 != (uint16_t *)var_140h; puVar12 = puVar12 + 2) {
                            cVar6 = -1;
                            if ((uint64_t)var_140h <= puVar12) {
                                cVar6 = '\x01';
                            }
                            if (-1 < cVar6) break;
                            *(undefined *)(puVar12 + 1) = 4;
                        }
                        goto code_r0x00018015ee44;
                    }
                }
                if ((*(char *)(arg3 + 0xa8) != '\0') && (uVar25 == 0x27)) {
                    var_148h._0_1_ = '\x02';
code_r0x00018015ed1f:
                    var_140h = (int64_t)(puVar18 + 2);
                    *(undefined *)(puVar18 + 1) = 4;
                    goto code_r0x00018015ee44;
                }
                if ((*(char *)(arg3 + 0xa9) != '\0') && (uVar25 == 0x22)) {
                    var_148h._0_1_ = '\x03';
                    goto code_r0x00018015ed1f;
                }
                if (((*(uint16_t *)(arg3 + 0x22) != 0) && ((char)var_138h == '\0')) &&
                   (uVar25 == *(uint16_t *)(arg3 + 0x22))) {
                    uVar16 = *(uint64_t *)(arg2 + 8);
                    for (uVar9 = *(uint64_t *)arg2; uVar9 != uVar16; uVar9 = uVar9 + 4) {
                        cVar6 = -1;
                        if (uVar16 <= uVar9) {
                            cVar6 = '\x01';
                        }
                        if (-1 < cVar6) break;
                        *(undefined *)(uVar9 + 2) = 6;
                    }
                    goto code_r0x00018015eb16;
                }
                if (*(int64_t *)(arg3 + 0x2f0) != 0) {
                    var_118h = *(uint64_t *)arg2 + ((int64_t)(*(uint64_t *)(arg2 + 8) - *(uint64_t *)arg2) >> 2) * 4;
                    piVar21 = *(int64_t **)(arg3 + 0x2f0);
                    var_120h = (int64_t)puVar18;
                    if (piVar21 == (int64_t *)0x0) {
                        func_0x000180454690();
                        pcVar3 = (code *)swi(3);
                        (*pcVar3)();
                        return;
                    }
                    var_158h = (int64_t)&var_138h + 4;
                    (**(code **)(*piVar21 + 0x10))(piVar21, &var_100h, &var_120h, &var_118h);
                    if ((uint16_t *)var_100h != puVar18) {
                        iVar10 = var_100h - (int64_t)puVar18 >> 2;
                        for (puVar12 = puVar18; puVar12 != puVar18 + iVar10 * 2; puVar12 = puVar12 + 2) {
                            cVar6 = -1;
                            if (puVar18 + iVar10 * 2 <= puVar12) {
                                cVar6 = '\x01';
                            }
                            if (-1 < cVar6) break;
                            *(undefined *)(puVar12 + 1) = var_138h._4_1_;
                        }
                        var_140h = (int64_t)(puVar18 + iVar10 * 2);
                        goto code_r0x00018015ee44;
                    }
                }
            } else {
                var_140h = (int64_t)(puVar18 + 2);
                *(undefined *)(puVar18 + 1) = 0xd;
code_r0x00018015ee44:
                bVar26 = (uint16_t *)var_140h != puVar18;
                puVar12 = (uint16_t *)var_140h;
                puVar18 = (uint16_t *)var_140h;
                cVar6 = (char)var_148h;
                uVar20 = (uint32_t)var_138h;
                if (bVar26) goto code_r0x00018015ea48;
            }
            iVar10 = *(uint64_t *)arg2 + ((int64_t)(*(uint64_t *)(arg2 + 8) - *(uint64_t *)arg2) >> 2) * 4;
            if (*(int64_t *)(arg3 + 0x270) != 0) {
                piVar21 = *(int64_t **)(arg3 + 0x270);
                if (piVar21 == (int64_t *)0x0) {
                    var_120h = iVar10;
                    var_118h = (int64_t)puVar18;
                    func_0x000180454690();
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                var_120h = iVar10;
                var_118h = (int64_t)puVar18;
                (**(code **)(*piVar21 + 0x10))(piVar21, &var_f8h, &var_118h, &var_120h);
                iVar1 = var_f8h;
                if ((uint16_t *)var_f8h != puVar18) {
                    var_120h = var_f8h - (int64_t)puVar18 >> 2;
                    uVar27 = 0;
                    var_58h = 0;
                    var_50h = 0xf;
                    stack0xffffffffffffff99 = SUB1615(ZEXT816(0), 1);
                    auVar4[15] = 0;
                    auVar4._0_15_ = stack0xffffffffffffff99;
                    _var_68h = auVar4 << 8;
                    puVar17 = puVar18;
                    uVar16 = var_58h;
                    uVar9 = var_50h;
                    for (; var_58h = uVar16, var_50h = uVar9, puVar18 < (uint64_t)iVar1; puVar18 = puVar18 + 2) {
                        uVar25 = *puVar18;
                        uVar9 = (uint64_t)uVar25;
                        if (*(char *)(arg3 + 0x20) == '\0') {
                            if (uVar25 < 0x7f) {
                                if (uVar25 - 0x41 < 0x1a) {
                                    uVar9 = (uint64_t)(uVar25 | 0x20);
                                }
                            } else {
                                iVar10 = func_0x000180164c60(uVar27, uVar25);
                                if ((iVar10 != 0) && (iVar8 = *(int32_t *)(iVar10 + 8), iVar8 != 0)) {
                                    if (iVar8 == 0xffff) {
                                        uVar9 = (uint64_t)(uVar25 | 1);
                                    } else {
                                        uVar9 = (uint64_t)(uint16_t)(uVar25 + (int16_t)iVar8);
                                    }
                                }
                            }
                        }
                        uVar25 = (uint16_t)uVar9;
                        if (uVar25 < 0x80) {
                            uVar22 = 1;
code_r0x00018015ef98:
                            var_130h = (uint8_t)uVar9;
                        } else {
                            uVar11 = (uint8_t)uVar9 & 0x3f | 0x80;
                            uVar7 = (uint8_t)(uVar25 >> 6);
                            if (0x7ff < uVar25) {
                                uVar9 = (uint64_t)(uint8_t)((uint8_t)(uVar9 >> 8) >> 4 | 0xe0);
                                var_12fh = uVar7 & 0x3f | 0x80;
                                uVar22 = 3;
                                var_12eh = uVar11;
                                goto code_r0x00018015ef98;
                            }
                            var_130h = uVar7 & 0x1f | 0xc0;
                            uVar22 = 2;
                            var_12fh = uVar11;
                        }
                        if (var_50h - uVar16 < uVar22) {
                            var_158h = uVar22;
                            uVar27 = func_0x00018000ee80(&var_68h, uVar22, cVar23, &var_130h);
                        } else {
                            var_58h = uVar22 + uVar16;
                            piVar21 = &var_68h;
                            if (0xf < (uint64_t)var_50h) {
                                piVar21 = (int64_t *)var_68h;
                            }
                            uVar27 = func_0x000180498030((int64_t)piVar21 + uVar16, &var_130h, uVar22);
                            *(undefined *)((int64_t)piVar21 + uVar16 + uVar22) = 0;
                        }
                        puVar17 = (uint16_t *)var_140h;
                        arg3 = var_110h;
                        uVar16 = var_58h;
                        uVar9 = var_50h;
                    }
                    piVar21 = &var_68h;
                    if (0xf < uVar9) {
                        piVar21 = (int64_t *)var_68h;
                    }
                    uVar22 = 0xcbf29ce484222325;
                    uVar14 = 0;
                    if (uVar16 != 0) {
                        do {
                            uVar22 = (uVar22 ^ *(uint8_t *)((int64_t)piVar21 + uVar14)) * 0x100000001b3;
                            uVar14 = uVar14 + 1;
                            cVar23 = (char)var_148h;
                        } while (uVar14 < uVar16);
                    }
                    uVar22 = uVar22 & *(uint64_t *)(arg3 + 0x168);
                    iVar10 = *(int64_t *)(*(int64_t *)(arg3 + 0x150) + 8 + uVar22 * 0x10);
                    iVar1 = *(int64_t *)(arg3 + 0x140);
                    piVar21 = (int64_t *)var_68h;
                    if (iVar10 != iVar1) {
                        iVar2 = *(int64_t *)(*(int64_t *)(arg3 + 0x150) + uVar22 * 0x10);
                        while( true ) {
                            piVar15 = (int64_t *)(iVar10 + 0x10);
                            if (0xf < *(uint64_t *)(iVar10 + 0x28)) {
                                piVar15 = (int64_t *)*piVar15;
                            }
                            piVar13 = &var_68h;
                            if (0xf < uVar9) {
                                piVar13 = piVar21;
                            }
                            if (uVar16 == *(uint64_t *)(iVar10 + 0x20)) {
                                if (uVar16 == 0) goto code_r0x00018015f0ff;
                                iVar8 = func_0x000180497f30(piVar13, piVar15, uVar16);
                                piVar21 = (int64_t *)var_68h;
                                uVar9 = var_50h;
                                if (iVar8 == 0) goto code_r0x00018015f0ff;
                            }
                            if (iVar10 == iVar2) break;
                            iVar10 = *(int64_t *)(iVar10 + 8);
                        }
                    }
                    iVar10 = 0;
code_r0x00018015f0ff:
                    if ((iVar10 == 0) || (iVar10 == iVar1)) {
                        piVar15 = &var_68h;
                        if (0xf < uVar9) {
                            piVar15 = piVar21;
                        }
                        uVar22 = 0xcbf29ce484222325;
                        uVar14 = 0;
                        if (uVar16 != 0) {
                            do {
                                uVar22 = (uVar22 ^ *(uint8_t *)((int64_t)piVar15 + uVar14)) * 0x100000001b3;
                                uVar14 = uVar14 + 1;
                                cVar23 = (char)var_148h;
                            } while (uVar14 < uVar16);
                        }
                        uVar22 = uVar22 & *(uint64_t *)(arg3 + 0x1a8);
                        iVar10 = *(int64_t *)(*(int64_t *)(arg3 + 400) + 8 + uVar22 * 0x10);
                        iVar1 = *(int64_t *)(arg3 + 0x180);
                        if (iVar10 != iVar1) {
                            iVar2 = *(int64_t *)(*(int64_t *)(arg3 + 400) + uVar22 * 0x10);
                            while( true ) {
                                piVar15 = (int64_t *)(iVar10 + 0x10);
                                if (0xf < *(uint64_t *)(iVar10 + 0x28)) {
                                    piVar15 = (int64_t *)*piVar15;
                                }
                                piVar13 = &var_68h;
                                if (0xf < uVar9) {
                                    piVar13 = piVar21;
                                }
                                if (uVar16 == *(uint64_t *)(iVar10 + 0x20)) {
                                    if (uVar16 == 0) goto code_r0x00018015f1df;
                                    iVar8 = func_0x000180497f30(piVar13, piVar15, uVar16);
                                    piVar21 = (int64_t *)var_68h;
                                    uVar9 = var_50h;
                                    if (iVar8 == 0) goto code_r0x00018015f1df;
                                }
                                if (iVar10 == iVar2) break;
                                iVar10 = *(int64_t *)(iVar10 + 8);
                            }
                        }
                        iVar10 = 0;
code_r0x00018015f1df:
                        if ((iVar10 == 0) || (iVar10 == iVar1)) {
                            uVar24 = 7;
                            piVar15 = &var_68h;
                            if (0xf < uVar9) {
                                piVar15 = piVar21;
                            }
                            uVar22 = 0xcbf29ce484222325;
                            uVar14 = 0;
                            if (uVar16 != 0) {
                                do {
                                    uVar22 = (uVar22 ^ *(uint8_t *)((int64_t)piVar15 + uVar14)) * 0x100000001b3;
                                    uVar14 = uVar14 + 1;
                                    cVar23 = (char)var_148h;
                                } while (uVar14 < uVar16);
                            }
                            uVar22 = uVar22 & *(uint64_t *)(arg3 + 0x1e8);
                            iVar10 = *(int64_t *)(*(int64_t *)(arg3 + 0x1d0) + 8 + uVar22 * 0x10);
                            iVar1 = *(int64_t *)(arg3 + 0x1c0);
                            if (iVar10 != iVar1) {
                                iVar2 = *(int64_t *)(*(int64_t *)(arg3 + 0x1d0) + uVar22 * 0x10);
                                while( true ) {
                                    piVar15 = (int64_t *)(iVar10 + 0x10);
                                    if (0xf < *(uint64_t *)(iVar10 + 0x28)) {
                                        piVar15 = (int64_t *)*piVar15;
                                    }
                                    piVar13 = &var_68h;
                                    if (0xf < uVar9) {
                                        piVar13 = piVar21;
                                    }
                                    if (uVar16 == *(uint64_t *)(iVar10 + 0x20)) {
                                        if ((uVar16 == 0) ||
                                           (iVar8 = func_0x000180497f30(piVar13, piVar15, uVar16), iVar8 == 0))
                                        goto code_r0x00018015f2b9;
                                        piVar21 = (int64_t *)var_68h;
                                        uVar9 = var_50h;
                                    }
                                    if (iVar10 == iVar2) break;
                                    iVar10 = *(int64_t *)(iVar10 + 8);
                                }
                            }
                            iVar10 = 0;
code_r0x00018015f2b9:
                            arg3 = var_110h;
                            if ((iVar10 != 0) && (uVar24 = 7, iVar10 != iVar1)) {
                                uVar24 = 8;
                            }
                        } else {
                            uVar24 = 2;
                        }
                    } else {
                        uVar24 = 1;
                    }
                    arg2 = var_108h;
                    puVar12 = puVar17 + var_120h * 2;
                    for (; puVar17 != puVar12; puVar17 = puVar17 + 2) {
                        cVar6 = -1;
                        if (puVar12 <= puVar17) {
                            cVar6 = '\x01';
                        }
                        if (-1 < cVar6) break;
                        *(undefined *)(puVar17 + 1) = uVar24;
                    }
                    var_140h = (int64_t)puVar12;
                    cVar6 = (char)var_148h;
                    uVar20 = (uint32_t)var_138h;
                    if (0xf < (uint64_t)var_50h) {
                        uVar16 = var_50h + 1;
                        iVar10 = var_68h;
                        if (0xfff < uVar16) {
                            iVar10 = *(int64_t *)(var_68h + -8);
                            if (0x1f < (var_68h - iVar10) - 8U) {
                                pcVar3 = (code *)swi(0x29);
                                (*pcVar3)(5);
                                puVar19 = auStack_170;
                                goto code_r0x00018015f70c;
                            }
                            uVar16 = var_50h + 0x28;
                        }
                        func_0x000180459c3c(iVar10, uVar16);
                        cVar6 = (char)var_148h;
                        uVar20 = (uint32_t)var_138h;
                    }
                    goto code_r0x00018015ea48;
                }
            }
            if (*(int64_t *)(arg3 + 0x2b0) != 0) {
                piVar21 = *(int64_t **)(arg3 + 0x2b0);
                if (piVar21 == (int64_t *)0x0) {
                    var_120h = iVar10;
                    var_118h = (int64_t)puVar18;
                    func_0x000180454690();
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                var_120h = iVar10;
                var_118h = (int64_t)puVar18;
                (**(code **)(*piVar21 + 0x10))(piVar21, &var_f0h, &var_118h, &var_120h);
                if ((uint16_t *)var_f0h != puVar18) {
                    iVar10 = var_f0h - (int64_t)puVar18 >> 2;
                    for (puVar12 = puVar18; puVar12 != puVar18 + iVar10 * 2; puVar12 = puVar12 + 2) {
                        cVar6 = -1;
                        if (puVar18 + iVar10 * 2 <= puVar12) {
                            cVar6 = '\x01';
                        }
                        if (-1 < cVar6) break;
                        *(undefined *)(puVar12 + 1) = 3;
                    }
                    var_140h = (int64_t)(puVar18 + iVar10 * 2);
                    puVar12 = (uint16_t *)var_140h;
                    cVar6 = (char)var_148h;
                    uVar20 = (uint32_t)var_138h;
                    goto code_r0x00018015ea48;
                }
            }
            if (*(int64_t *)(arg3 + 0x230) != 0) {
                var_128h._0_2_ = *puVar18;
                piVar21 = *(int64_t **)(arg3 + 0x230);
                if (piVar21 == (int64_t *)0x0) {
                    func_0x000180454690();
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                cVar6 = (**(code **)(*piVar21 + 0x10))(piVar21, &var_128h);
                if (cVar6 != '\0') {
                    *(undefined *)(puVar18 + 1) = 5;
                    var_140h = (int64_t)(puVar18 + 2);
                    puVar12 = (uint16_t *)var_140h;
                    cVar6 = (char)var_148h;
                    uVar20 = (uint32_t)var_138h;
                    goto code_r0x00018015ea48;
                }
            }
            *(undefined *)(puVar18 + 1) = 0;
            var_140h = (int64_t)(puVar18 + 2);
            puVar12 = (uint16_t *)var_140h;
            cVar6 = (char)var_148h;
            uVar20 = (uint32_t)var_138h;
            goto code_r0x00018015ea48;
        }
        if (cVar6 == '\x01') {
            if (*(uint64_t *)(arg3 + 0xa0) < 0x10) {
                var_98h = arg3 + 0x88;
            } else {
                var_98h = *(int64_t *)(arg3 + 0x88);
            }
            var_90h = *(int64_t *)(arg3 + 0x98);
            cVar6 = func_0x00018015f840(var_98h, puVar18, puVar12, &var_98h);
            if (cVar6 == '\0') {
code_r0x00018015f626:
                var_140h = (int64_t)(puVar18 + 2);
                *(undefined *)(puVar18 + 1) = 9;
                puVar12 = (uint16_t *)var_140h;
                cVar6 = (char)var_148h;
            } else {
                puVar12 = puVar18 + *(int64_t *)(arg3 + 0x98) * 2;
                for (; puVar18 != puVar12; puVar18 = puVar18 + 2) {
                    cVar6 = -1;
                    if (puVar12 <= puVar18) {
                        cVar6 = '\x01';
                    }
                    if (-1 < cVar6) break;
                    *(undefined *)(puVar18 + 1) = 9;
                }
code_r0x00018015f4b3:
                var_148h._0_1_ = '\0';
                var_140h = (int64_t)puVar12;
                cVar6 = '\0';
            }
        } else if (cVar6 == '\x04') {
            if (*puVar18 != *(uint16_t *)(arg3 + 0x130)) {
                if (*(uint64_t *)(arg3 + 0xe8) < 0x10) {
                    var_88h = arg3 + 0xd0;
                } else {
                    var_88h = *(int64_t *)(arg3 + 0xd0);
                }
                var_80h = *(int64_t *)(arg3 + 0xe0);
                cVar6 = func_0x00018015f840(var_88h, puVar18, puVar12, &var_88h);
                if (cVar6 == '\0') goto code_r0x00018015f626;
                puVar12 = puVar18 + *(int64_t *)(arg3 + 0xe0) * 2;
                for (; puVar18 != puVar12; puVar18 = puVar18 + 2) {
                    cVar6 = -1;
                    if (puVar12 <= puVar18) {
                        cVar6 = '\x01';
                    }
                    if (-1 < cVar6) break;
                    *(undefined *)(puVar18 + 1) = 4;
                }
                goto code_r0x00018015f4b3;
            }
code_r0x00018015f4dd:
            puVar12 = puVar18 + 2;
            *(undefined *)(puVar18 + 1) = 4;
            var_140h = (int64_t)puVar12;
            if (puVar12 != *(uint16_t **)(arg2 + 8)) {
                cVar5 = -1;
                if (*(uint16_t **)(arg2 + 8) <= puVar12) {
                    cVar5 = '\x01';
                }
                if (cVar5 < '\0') {
                    *(undefined *)(puVar18 + 3) = 4;
                    puVar12 = puVar18 + 4;
                    var_140h = (int64_t)(puVar18 + 4);
                }
            }
        } else {
            if (cVar6 == '\x05') {
                if (*puVar18 != *(uint16_t *)(arg3 + 0x130)) {
                    if (*(uint64_t *)(arg3 + 0x128) < 0x10) {
                        iStack_78 = arg3 + 0x110;
                    } else {
                        iStack_78 = *(int64_t *)(arg3 + 0x110);
                    }
                    var_70h = *(int64_t *)(arg3 + 0x120);
                    cVar6 = func_0x00018015f840(iStack_78, puVar18, puVar12, &iStack_78);
                    if (cVar6 == '\0') goto code_r0x00018015f626;
                    puVar12 = puVar18 + *(int64_t *)(arg3 + 0x120) * 2;
                    for (; puVar18 != puVar12; puVar18 = puVar18 + 2) {
                        cVar6 = -1;
                        if (puVar12 <= puVar18) {
                            cVar6 = '\x01';
                        }
                        if (-1 < cVar6) break;
                        *(undefined *)(puVar18 + 1) = 4;
                    }
                    goto code_r0x00018015f4b3;
                }
                goto code_r0x00018015f4dd;
            }
            if (cVar6 != '\x02') break;
            if (*puVar18 == *(uint16_t *)(arg3 + 0x130)) goto code_r0x00018015f691;
            if (*puVar18 != 0x27) goto code_r0x00018015f6f1;
            *(undefined *)(puVar18 + 1) = 4;
            var_148h._0_1_ = '\0';
            puVar12 = puVar18 + 2;
            var_140h = (int64_t)(puVar18 + 2);
            cVar6 = (char)var_148h;
        }
    } while( true );
    puVar12 = puVar18;
    if (cVar6 == '\x03') {
        if (*puVar18 == *(uint16_t *)(arg3 + 0x130)) {
code_r0x00018015f691:
            var_140h = (int64_t)(puVar18 + 2);
            *(undefined *)(puVar18 + 1) = 4;
            puVar12 = (uint16_t *)var_140h;
            cVar6 = (char)var_148h;
            if ((uint16_t *)var_140h != *(uint16_t **)(arg2 + 8)) {
                cVar5 = -1;
                if (*(uint16_t **)(arg2 + 8) <= (uint64_t)var_140h) {
                    cVar5 = '\x01';
                }
                if (cVar5 < '\0') {
                    *(undefined *)(puVar18 + 3) = 4;
                    puVar12 = puVar18 + 4;
                    var_140h = (int64_t)(puVar18 + 4);
                }
            }
        } else if (*puVar18 == 0x22) {
            *(undefined *)(puVar18 + 1) = 4;
            var_148h._0_1_ = '\0';
            puVar12 = puVar18 + 2;
            var_140h = (int64_t)(puVar18 + 2);
            cVar6 = '\0';
        } else {
code_r0x00018015f6f1:
            *(undefined *)(puVar18 + 1) = 4;
            puVar12 = puVar18 + 2;
            var_140h = (int64_t)(puVar18 + 2);
        }
    }
    goto code_r0x00018015ea48;
}

// ============================================================
// Function: FUN_18015f760
// Address: 0x18015f760
// Size: 119 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_12fh
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h

void fcn.18015f760(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined uVar1;
    uint64_t uVar2;
    uint64_t *arg2_00;
    
    arg2_00 = *(uint64_t **)arg2;
    if (arg3 == 0) {
        for (; arg2_00 < *(uint64_t **)(arg2 + 8); arg2_00 = arg2_00 + 7) {
            for (uVar2 = *arg2_00; uVar2 < arg2_00[1]; uVar2 = uVar2 + 4) {
                *(undefined *)(uVar2 + 2) = 0;
            }
            *(undefined *)(arg2_00 + 3) = 0;
            *(undefined *)((int64_t)arg2_00 + 0x2c) = 0;
        }
    } else {
        while (arg2_00 < *(uint64_t **)(arg2 + 8)) {
            uVar1 = fcn.18015e9e0(arg1, (int64_t)arg2_00, arg3);
            if (*(uint64_t **)(arg2 + 8) <= arg2_00 + 7) {
                return;
            }
            *(undefined *)(arg2_00 + 10) = uVar1;
            arg2_00 = arg2_00 + 7;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18015f7e0
// Address: 0x18015f7e0
// Size: 84 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_12fh
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h

void fcn.18015f7e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    uint64_t arg2_00;
    
    for (arg2_00 = *(uint64_t *)arg2; arg2_00 < *(uint64_t *)(arg2 + 8); arg2_00 = arg2_00 + 0x38) {
        if (*(char *)(arg2_00 + 0x2c) != '\0') {
            cVar1 = fcn.18015e9e0(arg1, arg2_00, arg3);
            if ((arg2_00 + 0x38 < *(uint64_t *)(arg2 + 8)) && (*(char *)(arg2_00 + 0x50) != cVar1)) {
                *(char *)(arg2_00 + 0x50) = cVar1;
                *(undefined *)(arg2_00 + 100) = 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18015f840
// Address: 0x18015f840
// Size: 246 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18015f840(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    uint16_t uVar3;
    uint8_t *puVar4;
    int64_t var_8h;
    
    puVar4 = *(uint8_t **)arg4 + *(int64_t *)(arg4 + 8);
    puVar1 = *(uint8_t **)arg4;
    while( true ) {
        if (puVar4 <= puVar1) {
            return CONCAT71((unkint7)((uint64_t)puVar1 >> 8), 1);
        }
        puVar2 = puVar1;
        if (arg2 == arg3) break;
        uVar3 = (uint16_t)(char)*puVar1;
        if ((char)*puVar1 < '\0') {
            puVar2 = puVar1 + 1;
            if ((puVar2 < puVar4) && ((*puVar1 & 0xe0) == 0xc0)) {
                uVar3 = (uint16_t)(*puVar1 & 0x1f) << 6 | (uint16_t)(*puVar2 & 0x3f);
                puVar2 = puVar1 + 2;
            } else if ((puVar1 + 2 < puVar4) && ((*puVar1 & 0xf0) == 0xe0)) {
                uVar3 = ((uint16_t)(*puVar2 & 0x3f) | (int16_t)(char)*puVar1 << 6) << 6 | (uint16_t)(puVar1[2] & 0x3f);
                puVar2 = puVar1 + 3;
            } else if ((puVar1 + 3 < puVar4) && ((*puVar1 & 0xf8) == 0xf0)) {
                uVar3 = 0xfffd;
                puVar2 = puVar1 + 4;
            } else {
                uVar3 = 0xfffd;
            }
        } else {
            puVar2 = puVar1 + 1;
        }
        if (*(uint16_t *)arg2 != uVar3) break;
        arg2 = arg2 + 4;
        puVar1 = puVar2;
    }
    return (uint64_t)puVar2 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18015f950
// Address: 0x18015f950
// Size: 1938 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18015f950(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    int16_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined *puVar4;
    char cVar5;
    int16_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t *puVar9;
    int16_t *piVar10;
    int16_t *piVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t *puVar14;
    undefined *puVar15;
    uint32_t uVar16;
    uint64_t unaff_RBP;
    int16_t *unaff_RSI;
    int16_t *piVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int32_t iVar21;
    uint64_t unaff_R12;
    uint64_t unaff_R15;
    int64_t unaff_GS_OFFSET;
    undefined4 uVar22;
    undefined4 extraout_XMM0_Da;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_c0;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar15 = auStack_b8;
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    uVar22 = 0;
    _var_80h = ZEXT816(0);
    var_70h = 0;
    piVar17 = *(int16_t **)arg2;
    puVar4 = auStack_b8;
    if ((int32_t)(*(int64_t *)(arg2 + 8) - (int64_t)piVar17 >> 3) * -0x49249249 < 1) goto code_r0x00018015ff63;
    unaff_RBP = 0;
    iVar21 = 0;
    piVar18 = (int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8);
    var_88h = (int64_t)piVar18;
code_r0x00018015f9f0:
    unaff_R12 = 0;
    *(undefined8 *)(puVar15 + 0x58) = 0;
    puVar14 = (uint64_t *)(int64_t)iVar21;
    *(uint64_t **)(puVar15 + 0x60) = puVar14;
    unaff_R15 = (int64_t)puVar14 * 0x38;
    *(uint64_t *)(puVar15 + 0x68) = unaff_R15;
    if (*(int64_t *)(piVar17 + (int64_t)puVar14 * 0x1c + 4) - *(int64_t *)(piVar17 + (int64_t)puVar14 * 0x1c) >> 2 == 0)
    goto code_r0x00018015ff40;
code_r0x00018015fa20:
    uVar16 = (uint32_t)unaff_RBP;
    unaff_RSI = (int16_t *)(*(int64_t *)((int64_t)piVar17 + unaff_R15) + unaff_R12 * 4);
    *(int16_t **)(puVar15 + 0x50) = unaff_RSI;
    cVar5 = *(char *)(unaff_RSI + 1);
    if ((cVar5 != '\x05') && (3 < (uint8_t)(cVar5 - 0x10U))) goto code_r0x00018015ff1f;
    iVar1 = *unaff_RSI;
    if ((iVar1 == 0x7b) || ((iVar1 == 0x5b || (iVar1 == 0x28)))) {
        *(int64_t *)(puVar15 + 0x28) = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * 0x6db6db6db6db6db7;
        *(undefined8 *)(puVar15 + -8) = 0x18015fc3b;
        uVar22 = func_0x0001800c1140(puVar15 + 0x38, puVar15 + 0x28);
        if (*(int32_t *)(*piVar18 + 8) < *(int32_t *)0x180782b3c) goto code_r0x00018016009b;
        goto code_r0x00018015fc52;
    }
    if ((cVar5 != '\x05') && (3 < (uint8_t)(cVar5 - 0x10U))) goto code_r0x00018015ff1f;
    if ((iVar1 != 0x7d) && ((iVar1 != 0x5d && (iVar1 != 0x29)))) goto code_r0x00018015ff1f;
    if (*(int64_t *)(puVar15 + 0x40) == *(int64_t *)(puVar15 + 0x38)) {
        *(undefined *)(unaff_RSI + 1) = 0x13;
        goto code_r0x00018015ff1f;
    }
    puVar9 = (uint64_t *)(*(int64_t *)(puVar15 + 0x40) + -8);
    uVar19 = *puVar9;
    uVar7 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * 0x6db6db6db6db6db7;
    if (uVar7 < uVar19 || uVar7 - uVar19 == 0) goto code_r0x000180160095;
    piVar17 = (int16_t *)(uVar19 * 0x1c + *(int64_t *)arg1);
    *(uint64_t **)(puVar15 + 0x40) = puVar9;
    uVar16 = uVar16 - 1;
    unaff_RBP = (uint64_t)uVar16;
    *(uint32_t *)(puVar15 + 0xd8) = uVar16;
    iVar1 = *unaff_RSI;
    if (iVar1 == 0x7d) {
        iVar6 = 0x7b;
    } else if (iVar1 == 0x5d) {
        iVar6 = 0x5b;
    } else {
        iVar6 = iVar1;
        if (iVar1 == 0x29) {
            iVar6 = 0x28;
        }
    }
    if (*piVar17 == iVar6) {
        *(undefined *)(unaff_RSI + 1) =
             puVar15[(int64_t)(int32_t)(uVar16 + ((int32_t)uVar16 / 3 + ((int32_t)uVar16 >> 0x1f) +
                                                 (int32_t)(((int64_t)(int32_t)uVar16 / 3 +
                                                            ((int64_t)(int32_t)uVar16 >> 0x3f) & 0xffffffffU) >> 0x1f))
                                                 * -3) + 0xc0];
        piVar17[6] = iVar1;
        puVar9 = (uint64_t *)(((int64_t)*(int16_t **)(arg2 + 8) - (int64_t)*(int16_t **)arg2 >> 3) * 0x6db6db6db6db6db7)
        ;
        if (puVar14 <= puVar9 && (int64_t)puVar9 - (int64_t)puVar14 != 0) {
            piVar10 = *(int16_t **)(unaff_R15 + (int64_t)*(int16_t **)arg2);
            piVar11 = piVar10 + unaff_R12 * 2;
            iVar20 = 0;
            while (piVar10 != piVar11) {
                cVar5 = -1;
                if (piVar11 <= piVar10) {
                    cVar5 = '\x01';
                }
                if (-1 < cVar5) break;
                if (*piVar10 == 9) {
                    iVar20 = iVar20 + (*(int32_t *)(arg2 + 0x18) - iVar20 % *(int32_t *)(arg2 + 0x18));
                    piVar10 = piVar10 + 2;
                } else {
                    iVar20 = iVar20 + 1;
                    piVar10 = piVar10 + 2;
                }
            }
            iVar21 = *(int32_t *)(puVar15 + 0xd0);
            *(int32_t *)(piVar17 + 8) = iVar21;
            *(int32_t *)(piVar17 + 10) = iVar20;
code_r0x00018015ff10:
            piVar18 = *(int64_t **)(puVar15 + 0x30);
code_r0x00018015ff1f:
            unaff_R12 = unaff_R12 + 1;
            *(uint64_t *)(puVar15 + 0x58) = unaff_R12;
            piVar17 = *(int16_t **)arg2;
            if ((uint64_t)
                (*(int64_t *)((int64_t)piVar17 + unaff_R15 + 8) - *(int64_t *)((int64_t)piVar17 + unaff_R15) >> 2) <=
                unaff_R12) {
code_r0x00018015ff40:
                iVar21 = iVar21 + 1;
                *(int32_t *)(puVar15 + 0xd0) = iVar21;
                iVar20 = (int32_t)((int64_t)*(int16_t **)(arg2 + 8) - (int64_t)piVar17 >> 3);
                puVar4 = puVar15;
                if (SBORROW4(iVar21, iVar20 * -0x49249249) == iVar21 + iVar20 * 0x49249249 < 0) {
code_r0x00018015ff63:
                    puVar15 = puVar4;
                    puVar14 = *(uint64_t **)(puVar15 + 0x40);
                    puVar9 = *(uint64_t **)(puVar15 + 0x38);
                    if (puVar14 == puVar9) goto code_r0x00018016003e;
                    while( true ) {
                        if (puVar14 == puVar9) goto code_r0x00018016003e;
                        cVar5 = -1;
                        if (puVar9 <= puVar14) {
                            cVar5 = '\x01';
                        }
                        if (cVar5 < '\x01') goto code_r0x00018016003e;
                        puVar14 = puVar14 + -1;
                        uVar19 = *puVar14;
                        uVar7 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * 0x6db6db6db6db6db7;
                        if (uVar7 < uVar19 || uVar7 - uVar19 == 0) break;
                        uVar19 = *(uint64_t *)(uVar19 * 0x1c + 4 + *(int64_t *)arg1);
                        iVar21 = (int32_t)uVar19;
                        uVar12 = (uint64_t)iVar21;
                        unaff_RSI = *(int16_t **)arg2;
                        uVar7 = ((int64_t)*(int16_t **)(arg2 + 8) - (int64_t)unaff_RSI >> 3) * 0x6db6db6db6db6db7;
                        if (uVar7 < uVar12 || uVar7 - uVar12 == 0) goto code_r0x0001801600dc;
                        *(undefined8 *)(puVar15 + -8) = 0x18015fff0;
                        iVar8 = fcn.18015d7b0(arg2, (int64_t)(unaff_RSI + uVar12 * 0x1c), uVar19 >> 0x20);
                        *(undefined *)(*(int64_t *)(unaff_RSI + (int64_t)iVar21 * 0x1c) + 2 + iVar8 * 4) = 0x13;
                        iVar13 = *puVar14 * 0x1c + *(int64_t *)arg1;
                        iVar8 = iVar13 + 0x1c;
                        iVar2 = *(int64_t *)(arg1 + 8);
                        *(undefined8 *)(puVar15 + -8) = 0x180160018;
                        uVar22 = func_0x000180498030(iVar13, iVar8, iVar2 - iVar8);
                        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x1c;
                        puVar9 = *(uint64_t **)(puVar15 + 0x38);
                    }
code_r0x000180160095:
                    do {
                        uVar16 = (uint32_t)unaff_RBP;
                        *(undefined8 *)(puVar15 + -8) = 0x18016009a;
                        fcn.180060370();
code_r0x00018016009b:
                        *(undefined8 *)(puVar15 + -8) = 0x1801600a7;
                        uVar22 = func_0x000180459d18(0x180782b3c);
                        if (*(int32_t *)0x180782b3c == -1) {
                            *(undefined8 *)0x180782b30 = 0xffffffffffffffff;
                            *(undefined8 *)(puVar15 + -8) = 0x1801600cb;
                            uVar22 = func_0x000180459cac(0x180782b3c);
                        }
code_r0x00018015fc52:
                        piVar17 = *(int16_t **)arg2;
                        puVar9 = (uint64_t *)
                                 (((int64_t)*(int16_t **)(arg2 + 8) - (int64_t)piVar17 >> 3) * 0x6db6db6db6db6db7);
                        if (puVar9 < puVar14 || (int64_t)puVar9 - (int64_t)puVar14 == 0) goto code_r0x0001801600dc;
                        *(undefined4 *)(puVar15 + 0x20) = *(undefined4 *)0x180782b30;
                        *(undefined4 *)(puVar15 + 0x28) = *(undefined4 *)0x180782b34;
                        piVar11 = *(int16_t **)(unaff_R15 + (int64_t)piVar17);
                        piVar17 = piVar11 + unaff_R12 * 2;
                        puVar14 = (uint64_t *)0x0;
                        while( true ) {
                            iVar20 = (int32_t)puVar14;
                            if (piVar11 == piVar17) break;
                            cVar5 = -1;
                            if (piVar17 <= piVar11) {
                                cVar5 = '\x01';
                            }
                            if (-1 < cVar5) break;
                            if (*piVar11 == 9) {
                                puVar14 = (uint64_t *)
                                          (uint64_t)
                                          (uint32_t)
                                          (iVar20 + (*(int32_t *)(arg2 + 0x18) - iVar20 % *(int32_t *)(arg2 + 0x18)));
                                piVar11 = piVar11 + 2;
                            } else {
                                puVar14 = (uint64_t *)(uint64_t)(iVar20 + 1);
                                piVar11 = piVar11 + 2;
                            }
                        }
                        piVar17 = *(int16_t **)(arg1 + 8);
                        if (piVar17 != *(int16_t **)(arg1 + 0x10)) {
                            *piVar17 = *unaff_RSI;
                            iVar21 = *(int32_t *)(puVar15 + 0xd0);
                            *(int32_t *)(piVar17 + 2) = iVar21;
                            *(int32_t *)(piVar17 + 4) = iVar20;
                            piVar17[6] = 0;
                            *(undefined4 *)(piVar17 + 8) = *(undefined4 *)(puVar15 + 0x20);
                            *(undefined4 *)(piVar17 + 10) = *(undefined4 *)(puVar15 + 0x28);
                            *(uint32_t *)(piVar17 + 0xc) = uVar16;
                            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x1c;
                            goto code_r0x00018015fedb;
                        }
                        unaff_RBP = ((int64_t)piVar17 - *(int64_t *)arg1) / 0x1c;
                        if (unaff_RBP == 0x924924924924924) {
                            *(undefined8 *)(puVar15 + -8) = 0x1801600db;
                            func_0x000180010010();
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        uVar19 = ((int64_t)*(int16_t **)(arg1 + 0x10) - *(int64_t *)arg1 >> 2) * 0x6db6db6db6db6db7;
                        uVar7 = 0x924924924924924 - (uVar19 >> 1);
                        if (uVar7 <= uVar19 && uVar19 - uVar7 != 0) {
code_r0x0001801600d0:
                            *(undefined8 *)(puVar15 + -8) = 0x1801600d5;
                            func_0x000180004720();
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        unaff_R12 = unaff_RBP + 1;
                        uVar19 = uVar19 + (uVar19 >> 1);
                        uVar7 = unaff_R12;
                        if (unaff_R12 <= uVar19) {
                            uVar7 = uVar19;
                        }
                        if (0x924924924924924 < uVar7) goto code_r0x0001801600d0;
                        unaff_R15 = uVar7 * 0x1c;
                        if (unaff_R15 == 0) {
                            unaff_RSI = (int16_t *)0x0;
code_r0x00018015fdd9:
                            arg2 = (int64_t)(unaff_RSI + unaff_RBP * 0xe);
                            *(undefined2 *)arg2 = **(undefined2 **)(puVar15 + 0x50);
                            *(undefined4 *)(arg2 + 4) = *(undefined4 *)(puVar15 + 0xd0);
                            *(int32_t *)(arg2 + 8) = iVar20;
                            *(undefined2 *)(arg2 + 0xc) = 0;
                            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(puVar15 + 0x20);
                            *(undefined4 *)(arg2 + 0x14) = *(undefined4 *)(puVar15 + 0x28);
                            uVar16 = *(uint32_t *)(puVar15 + 0xd8);
                            unaff_RBP = (uint64_t)uVar16;
                            *(uint32_t *)(arg2 + 0x18) = uVar16;
                            piVar11 = *(int16_t **)arg1;
                            if (piVar17 == *(int16_t **)(arg1 + 8)) {
                                iVar8 = (int64_t)*(int16_t **)(arg1 + 8) - (int64_t)piVar11;
                                piVar10 = unaff_RSI;
                                piVar17 = piVar11;
                            } else {
                                *(undefined8 *)(puVar15 + -8) = 0x18015fe3d;
                                func_0x000180498030(unaff_RSI, piVar11, (int64_t)piVar17 - (int64_t)piVar11);
                                iVar8 = *(int64_t *)(arg1 + 8) - (int64_t)piVar17;
                                piVar10 = (int16_t *)(arg2 + 0x1c);
                            }
                            *(undefined8 *)(puVar15 + -8) = 0x18015fe50;
                            uVar22 = func_0x000180498030(piVar10, piVar17, iVar8);
                            iVar8 = *(int64_t *)arg1;
                            if (iVar8 == 0) goto code_r0x00018015fea5;
                            uVar19 = (*(int64_t *)(arg1 + 0x10) - iVar8 >> 2) * 4;
                            if (uVar19 < 0x1000) goto code_r0x00018015fe9d;
                            if ((iVar8 - *(int64_t *)(iVar8 + -8)) - 8U < 0x20) goto code_r0x00018015fe94;
                        } else {
                            if (unaff_R15 < 0x1000) {
                                *(undefined8 *)(puVar15 + -8) = 0x18015fdd6;
                                unaff_RSI = (int16_t *)func_0x000180459890(unaff_R15);
                                goto code_r0x00018015fdd9;
                            }
                            if (unaff_R15 + 0x27 <= unaff_R15) goto code_r0x0001801600d0;
                            *(undefined8 *)(puVar15 + -8) = 0x18015fdb7;
                            iVar8 = func_0x000180459890();
                            if (iVar8 != 0) {
                                unaff_RSI = (int16_t *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                                *(int64_t *)(unaff_RSI + -4) = iVar8;
                                goto code_r0x00018015fdd9;
                            }
                        }
                        puVar9 = (uint64_t *)0x5;
                        pcVar3 = (code *)swi(0x29);
                        uVar22 = (*pcVar3)();
                        puVar15 = puVar15 + 8;
code_r0x00018016003e:
                        if (puVar9 == (uint64_t *)0x0) {
                            return;
                        }
                        uVar19 = (*(int64_t *)(puVar15 + 0x48) - (int64_t)puVar9 >> 3) * 8;
                        if (uVar19 < 0x1000) {
code_r0x000180160078:
                            *(undefined8 *)(puVar15 + -8) = 0x18016007d;
                            func_0x000180459c3c(uVar22, uVar19);
                            return;
                        }
                        if ((int64_t)puVar9 + (-8 - puVar9[-1]) < 0x20) {
                            uVar19 = uVar19 + 0x27;
                            goto code_r0x000180160078;
                        }
                        pcVar3 = (code *)swi(0x29);
                        (*pcVar3)(5);
                        puVar15 = puVar15 + 8;
                    } while( true );
                }
                goto code_r0x00018015f9f0;
            }
            goto code_r0x00018015fa20;
        }
    } else {
        *(undefined *)(unaff_RSI + 1) = 0x13;
        piVar11 = *(int16_t **)arg2;
        uVar19 = *(uint64_t *)(piVar17 + 2);
        uVar12 = (uint64_t)(int32_t)uVar19;
        uVar7 = ((int64_t)*(int16_t **)(arg2 + 8) - (int64_t)piVar11 >> 3) * 0x6db6db6db6db6db7;
        if (uVar12 <= uVar7 && uVar7 - uVar12 != 0) {
            *(undefined8 *)(puVar15 + -8) = 0x18015fbe6;
            iVar8 = fcn.18015d7b0(arg2, (int64_t)(piVar11 + uVar12 * 0x1c), uVar19 >> 0x20);
            *(undefined *)(*(int64_t *)(piVar11 + (int64_t)*(int32_t *)(piVar17 + 2) * 0x1c) + 2 + iVar8 * 4) = 0x13;
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x1c;
            iVar21 = *(int32_t *)(puVar15 + 0xd0);
            puVar14 = *(uint64_t **)(puVar15 + 0x60);
            uVar22 = extraout_XMM0_Da;
            goto code_r0x00018015ff10;
        }
    }
code_r0x0001801600dc:
    *(undefined8 *)(puVar15 + -8) = 0x1801600e1;
    fcn.180060370();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
code_r0x00018015fe94:
    uVar19 = uVar19 + 0x27;
    iVar8 = *(int64_t *)(iVar8 + -8);
code_r0x00018015fe9d:
    *(undefined8 *)(puVar15 + -8) = 0x18015fea5;
    uVar22 = func_0x000180459c3c(iVar8, uVar19);
code_r0x00018015fea5:
    *(int16_t **)arg1 = unaff_RSI;
    *(int16_t **)(arg1 + 8) = unaff_RSI + unaff_R12 * 0xe;
    *(int16_t **)(arg1 + 0x10) = unaff_RSI + uVar7 * 0xe;
    unaff_RSI = *(int16_t **)(puVar15 + 0x50);
    arg2 = *(int64_t *)(puVar15 + 200);
    unaff_R15 = *(uint64_t *)(puVar15 + 0x68);
    unaff_R12 = *(uint64_t *)(puVar15 + 0x58);
    iVar21 = *(int32_t *)(puVar15 + 0xd0);
code_r0x00018015fedb:
    *(undefined *)(unaff_RSI + 1) =
         puVar15[(int64_t)(int32_t)(uVar16 + ((int32_t)uVar16 / 3 + ((int32_t)uVar16 >> 0x1f) +
                                             (int32_t)(((int64_t)(int32_t)uVar16 / 3 +
                                                        ((int64_t)(int32_t)uVar16 >> 0x3f) & 0xffffffffU) >> 0x1f)) * -3
                                   ) + 0xc0];
    unaff_RBP = (uint64_t)(uVar16 + 1);
    *(uint32_t *)(puVar15 + 0xd8) = uVar16 + 1;
    puVar14 = (uint64_t *)(int64_t)iVar21;
    goto code_r0x00018015ff10;
}

// ============================================================
// Function: FUN_1801600f0
// Address: 0x1801600f0
// Size: 184 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

int64_t fcn.1801600f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int16_t *piVar2;
    int32_t iVar3;
    int16_t *piVar4;
    int16_t *piVar5;
    int32_t iVar6;
    int32_t iVar8;
    int32_t iVar9;
    int16_t *piVar10;
    bool bVar11;
    bool bVar12;
    bool bVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int32_t iVar7;
    
    iVar9 = (int32_t)arg4;
    iVar8 = (int32_t)arg3;
    piVar2 = *(int16_t **)(arg1 + 8);
    piVar5 = *(int16_t **)arg1;
    *(int16_t **)arg2 = piVar2;
    piVar10 = piVar2;
    while( true ) {
        iVar6 = (int32_t)((uint64_t)arg3 >> 0x20);
        iVar7 = (int32_t)((uint64_t)arg4 >> 0x20);
        if (piVar2 <= piVar5) break;
        iVar1 = *(int32_t *)(piVar5 + 2);
        if (iVar1 == iVar8) {
            bVar12 = iVar6 < *(int32_t *)(piVar5 + 4);
        } else {
            bVar12 = iVar1 != iVar8 && iVar8 <= iVar1;
        }
        if (bVar12) break;
        bVar12 = SBORROW4(iVar1, iVar8);
        iVar3 = iVar1 - iVar8;
        if (iVar1 == iVar8) {
            bVar12 = SBORROW4(*(int32_t *)(piVar5 + 4), iVar6);
            iVar3 = *(int32_t *)(piVar5 + 4) - iVar6;
        }
        if (bVar12 != iVar3 < 0) {
            iVar3 = *(int32_t *)(piVar5 + 8);
            if (iVar3 == iVar8) {
                bVar12 = iVar6 <= *(int32_t *)(piVar5 + 10);
            } else {
                bVar12 = iVar3 != iVar8 && iVar8 <= iVar3;
            }
            if (bVar12) {
                bVar12 = SBORROW4(iVar1, iVar9);
                iVar6 = iVar1 - iVar9;
                if (iVar1 == iVar9) {
                    bVar12 = SBORROW4(*(int32_t *)(piVar5 + 4), iVar7);
                    iVar6 = *(int32_t *)(piVar5 + 4) - iVar7;
                }
                if (bVar12 != iVar6 < 0) {
                    if (iVar3 == iVar9) {
                        bVar12 = iVar7 <= *(int32_t *)(piVar5 + 10);
                    } else {
                        bVar12 = iVar3 != iVar9 && iVar9 <= iVar3;
                    }
                    if ((bVar12) && (*piVar5 == 0x7b)) {
                        piVar10 = piVar5;
                    }
                }
            }
        }
        piVar5 = piVar5 + 0xe;
    }
    if (piVar10 == piVar2) {
        return arg2;
    }
    bVar12 = false;
    piVar5 = piVar10;
code_r0x0001801601c1:
    piVar4 = piVar5;
    piVar5 = piVar4 + 0xe;
    if ((piVar2 <= piVar5) || (bVar12)) {
        return arg2;
    }
    if (*(int32_t *)(piVar10 + 0xc) < *(int32_t *)(piVar4 + 0x1a)) goto code_r0x0001801601d6;
    goto code_r0x000180160205;
code_r0x0001801601d6:
    if ((*(int32_t *)(piVar4 + 0x1a) == *(int32_t *)(piVar10 + 0xc) + 1) && (*piVar5 == 0x7b)) {
        iVar1 = *(int32_t *)(piVar4 + 0x10);
        bVar13 = SBORROW4(iVar1, iVar8);
        iVar3 = iVar1 - iVar8;
        bVar11 = iVar1 == iVar8;
        if (bVar11) {
            iVar1 = *(int32_t *)(piVar4 + 0x12);
            bVar13 = SBORROW4(iVar1, iVar6);
            iVar3 = iVar1 - iVar6;
            bVar11 = iVar1 == iVar6;
        }
        if (!bVar11 && bVar13 == iVar3 < 0) {
            iVar1 = *(int32_t *)(piVar4 + 0x16);
            bVar11 = SBORROW4(iVar1, iVar9);
            iVar3 = iVar1 - iVar9;
            if (iVar1 == iVar9) {
                bVar11 = SBORROW4(*(int32_t *)(piVar4 + 0x18), iVar7);
                iVar3 = *(int32_t *)(piVar4 + 0x18) - iVar7;
            }
            if (bVar11 != iVar3 < 0) {
                *(int16_t **)arg2 = piVar5;
code_r0x000180160205:
                bVar12 = true;
            }
        }
    }
    goto code_r0x0001801601c1;
}

