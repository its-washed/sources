// Chunk 85 - 50 functions

// ============================================================
// Function: FUN_18011f38a
// Address: 0x18011f38a
// Size: 119 bytes
// ============================================================
void fcn.18011f38a(int64_t arg1, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t *unaff_RBX;
    int32_t iVar4;
    int32_t unaff_EDI;
    
    iVar3 = (int32_t)arg1;
    if (iVar3 == 0) {
        iVar1 = 8;
    } else {
        arg2 = (int64_t)(uint32_t)(iVar3 >> 0x1f);
        iVar1 = iVar3 / 2 + iVar3;
    }
    iVar4 = unaff_EDI;
    if (unaff_EDI < iVar1) {
        iVar4 = iVar1;
    }
    if (iVar3 < iVar4) {
        uVar2 = func_0x00018046d050((int64_t)iVar4 * 0x78, arg2);
        if (*(int64_t *)(unaff_RBX + 2) != 0) {
            func_0x000180498030(uVar2, *(int64_t *)(unaff_RBX + 2), (int64_t)*unaff_RBX * 0x78);
            func_0x000180460d90(*(undefined8 *)(unaff_RBX + 2));
        }
        *(undefined8 *)(unaff_RBX + 2) = uVar2;
        unaff_RBX[1] = iVar4;
        *unaff_RBX = unaff_EDI;
        return;
    }
    *unaff_RBX = unaff_EDI;
    return;
}

// ============================================================
// Function: FUN_18011f401
// Address: 0x18011f401
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h
// WARNING: Variable defined which should be unmapped: arg_38h

void fcn.18011f38a(int64_t arg1, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t *unaff_RBX;
    int32_t iVar4;
    int32_t unaff_EDI;
    
    iVar3 = (int32_t)arg1;
    if (iVar3 == 0) {
        iVar1 = 8;
    } else {
        arg2 = (int64_t)(uint32_t)(iVar3 >> 0x1f);
        iVar1 = iVar3 / 2 + iVar3;
    }
    iVar4 = unaff_EDI;
    if (unaff_EDI < iVar1) {
        iVar4 = iVar1;
    }
    if (iVar3 < iVar4) {
        uVar2 = func_0x00018046d050((int64_t)iVar4 * 0x78, arg2);
        if (*(int64_t *)(unaff_RBX + 2) != 0) {
            func_0x000180498030(uVar2, *(int64_t *)(unaff_RBX + 2), (int64_t)*unaff_RBX * 0x78);
            func_0x000180460d90(*(undefined8 *)(unaff_RBX + 2));
        }
        *(undefined8 *)(unaff_RBX + 2) = uVar2;
        unaff_RBX[1] = iVar4;
        *unaff_RBX = unaff_EDI;
        return;
    }
    *unaff_RBX = unaff_EDI;
    return;
}

// ============================================================
// Function: FUN_18011f413
// Address: 0x18011f413
// Size: 13 bytes
// ============================================================
void fcn.18011f413(int64_t arg_40h)
{
    undefined4 *unaff_RBX;
    undefined4 unaff_EDI;
    
    *unaff_RBX = unaff_EDI;
    return;
}

// ============================================================
// Function: FUN_18011f420
// Address: 0x18011f420
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f420(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x24);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x24);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f439
// Address: 0x18011f439
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f420(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x24);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x24);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f47b
// Address: 0x18011f47b
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f420(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x24);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x24);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f490
// Address: 0x18011f490
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f490(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar2 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar1 = 8;
        } else {
            iVar1 = iVar1 / 2 + iVar1;
        }
        if (iVar2 < iVar1) {
            iVar2 = iVar1;
        }
        func_0x00018011f4f0(arg1, iVar2);
    }
    *(undefined8 *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 8) = *(undefined8 *)arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f4f0
// Address: 0x18011f4f0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f4f0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 3);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 3);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f508
// Address: 0x18011f508
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f4f0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 3);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 3);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f546
// Address: 0x18011f546
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f4f0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 3);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 3);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f560
// Address: 0x18011f560
// Size: 56 bytes
// ============================================================
void fcn.18011f560(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    if (iVar2 < 0) {
        uVar1 = iVar2 / 2 + iVar2;
        uVar3 = 0;
        if (0 < (int32_t)uVar1) {
            uVar3 = uVar1;
        }
        fcn.18011f4f0(arg1, (uint64_t)uVar3);
    }
    *(undefined4 *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_18011f5a0
// Address: 0x18011f5a0
// Size: 56 bytes
// ============================================================
void fcn.18011f5a0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar1 < 0) {
        iVar1 = iVar1 / 2 + iVar1;
        iVar2 = 0;
        if (0 < iVar1) {
            iVar2 = iVar1;
        }
        fcn.18011fb10(arg1, iVar2);
    }
    *(undefined4 *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_18011f5e0
// Address: 0x18011f5e0
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f5e0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar2 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar1 = 8;
        } else {
            iVar1 = iVar1 / 2 + iVar1;
        }
        if (iVar2 < iVar1) {
            iVar2 = iVar1;
        }
        fcn.18011fb10(arg1, iVar2);
    }
    *(undefined4 *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 4) = *(undefined4 *)arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f640
// Address: 0x18011f640
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f640(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = fcn.18046d050((int64_t)iVar5);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f65a
// Address: 0x18011f65a
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f640(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = fcn.18046d050((int64_t)iVar5);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f6c9
// Address: 0x18011f6c9
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f640(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = fcn.18046d050((int64_t)iVar5);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f6db
// Address: 0x18011f6db
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18011f640(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = (int32_t)arg2;
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar4 <= iVar1) {
        *(int32_t *)arg1 = iVar4;
        return;
    }
    if (iVar1 == 0) {
        iVar2 = 8;
    } else {
        iVar2 = iVar1 / 2 + iVar1;
    }
    iVar5 = iVar4;
    if (iVar4 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar1 < iVar5) {
        uVar3 = fcn.18046d050((int64_t)iVar5);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar3;
        *(int32_t *)(arg1 + 4) = iVar5;
        *(int32_t *)arg1 = iVar4;
        return;
    }
    *(int32_t *)arg1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18011f6f0
// Address: 0x18011f6f0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f6f0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x14);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x14);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f709
// Address: 0x18011f709
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f6f0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x14);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x14);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f74b
// Address: 0x18011f74b
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f6f0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x14);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x14);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f760
// Address: 0x18011f760
// Size: 160 bytes
// ============================================================
int64_t fcn.18011f760(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    
    iVar5 = *(int32_t *)(arg1 + 4);
    iVar7 = arg2 - *(int64_t *)(arg1 + 8) >> 4;
    if (*(int32_t *)arg1 == iVar5) {
        iVar8 = *(int32_t *)arg1 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar8 < iVar5) {
            iVar8 = iVar5;
        }
        func_0x00018011faa0(arg1, iVar8);
    }
    if (iVar7 < *(int32_t *)arg1) {
        iVar6 = iVar7 * 0x10 + *(int64_t *)(arg1 + 8);
        fcn.180498030(iVar6 + 0x10, iVar6, (*(int32_t *)arg1 - iVar7) * 0x10);
    }
    uVar2 = *(undefined4 *)(arg3 + 4);
    uVar3 = *(undefined4 *)(arg3 + 8);
    uVar4 = *(undefined4 *)(arg3 + 0xc);
    puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 8) + iVar7 * 0x10);
    *puVar1 = *(undefined4 *)arg3;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return *(int64_t *)(arg1 + 8) + iVar7 * 0x10;
}

// ============================================================
// Function: FUN_18011f800
// Address: 0x18011f800
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f800(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f818
// Address: 0x18011f818
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f800(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f84e
// Address: 0x18011f84e
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f800(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f860
// Address: 0x18011f860
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f860(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_8h;
    
    iVar5 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar5) {
        iVar6 = *(int32_t *)arg1 + 1;
        if (iVar5 == 0) {
            iVar5 = 8;
        } else {
            iVar5 = iVar5 / 2 + iVar5;
        }
        if (iVar6 < iVar5) {
            iVar6 = iVar5;
        }
        func_0x00018011faa0(arg1, iVar6);
    }
    uVar2 = *(undefined4 *)(arg2 + 4);
    uVar3 = *(undefined4 *)(arg2 + 8);
    uVar4 = *(undefined4 *)(arg2 + 0xc);
    puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 0x10);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011f8d0
// Address: 0x18011f8d0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f8d0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 2);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f8e8
// Address: 0x18011f8e8
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f8d0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 2);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f924
// Address: 0x18011f924
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f8d0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 2);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f930
// Address: 0x18011f930
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f930(int64_t arg1)
{
    int64_t var_8h;
    
    func_0x000180126a10(arg1 + 0x28);
    if (*(int64_t *)(arg1 + 0x38) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_18011f970
// Address: 0x18011f970
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f970(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x38);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x38);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f989
// Address: 0x18011f989
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f970(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x38);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x38);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f9c3
// Address: 0x18011f9c3
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f970(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x38);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x38);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f9d0
// Address: 0x18011f9d0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f9d0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x1c);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x1c);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011f9e9
// Address: 0x18011f9e9
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f9d0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x1c);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x1c);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fa23
// Address: 0x18011fa23
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011f9d0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x1c);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x1c);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fa30
// Address: 0x18011fa30
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fa30(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 6);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 6);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fa48
// Address: 0x18011fa48
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fa30(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 6);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 6);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fa86
// Address: 0x18011fa86
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fa30(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 6);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 6);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011faa0
// Address: 0x18011faa0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011faa0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 4);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 4);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fab8
// Address: 0x18011fab8
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011faa0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 4);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 4);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011faf6
// Address: 0x18011faf6
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011faa0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 4);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 4);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fb10
// Address: 0x18011fb10
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fb10(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 2);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fb28
// Address: 0x18011fb28
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fb10(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 2);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fb66
// Address: 0x18011fb66
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fb10(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 << 2);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 << 2);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fb80
// Address: 0x18011fb80
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fb80(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    
    iVar6 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar6) {
        iVar8 = *(int32_t *)arg1 + 1;
        if (iVar6 == 0) {
            iVar6 = 8;
        } else {
            iVar6 = iVar6 / 2 + iVar6;
        }
        if (iVar8 < iVar6) {
            iVar8 = iVar6;
        }
        func_0x00018011fc10(arg1, iVar8);
    }
    iVar7 = (int64_t)*(int32_t *)arg1;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    iVar2 = *(int64_t *)(arg1 + 8);
    puVar1 = (undefined4 *)(iVar2 + iVar7 * 0x48);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x14);
    uVar4 = *(undefined4 *)(arg2 + 0x18);
    uVar5 = *(undefined4 *)(arg2 + 0x1c);
    puVar1 = (undefined4 *)(iVar2 + 0x10 + iVar7 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x10);
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    uVar4 = *(undefined4 *)(arg2 + 0x28);
    uVar5 = *(undefined4 *)(arg2 + 0x2c);
    puVar1 = (undefined4 *)(iVar2 + 0x20 + iVar7 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x20);
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x34);
    uVar4 = *(undefined4 *)(arg2 + 0x38);
    uVar5 = *(undefined4 *)(arg2 + 0x3c);
    puVar1 = (undefined4 *)(iVar2 + 0x30 + iVar7 * 0x48);
    *puVar1 = *(undefined4 *)(arg2 + 0x30);
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *(undefined8 *)(iVar2 + 0x40 + iVar7 * 0x48) = *(undefined8 *)(arg2 + 0x40);
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_18011fc10
// Address: 0x18011fc10
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fc10(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x48);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x48);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fc29
// Address: 0x18011fc29
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fc10(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x48);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x48);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fc6b
// Address: 0x18011fc6b
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011fc10(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x48);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x48);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011fc80
// Address: 0x18011fc80
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.18011fc80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     undefined8 placeholder_5, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t *piVar9;
    int64_t var_8h;
    
    iVar2 = (int32_t)arg3;
    iVar3 = (int32_t)arg4;
    iVar7 = 0;
    iVar6 = 0;
    iVar8 = 0;
    if (iVar2 + iVar3 <= *(int32_t *)arg2) {
        *(undefined4 *)arg_28h = 0;
        return 0;
    }
    do {
        iVar1 = *(int32_t *)(arg2 + 4);
        if (iVar7 < iVar1) {
            piVar9 = *(int32_t **)(arg2 + 8);
            iVar5 = (iVar1 - iVar7) * iVar8;
            iVar4 = *piVar9;
            iVar7 = iVar1;
            if (*(int32_t *)arg2 < iVar2) {
                iVar8 = iVar8 + (iVar4 - iVar2);
            } else {
                iVar8 = iVar8 + (iVar4 - *(int32_t *)arg2);
            }
        } else {
            piVar9 = *(int32_t **)(arg2 + 8);
            iVar4 = *piVar9;
            iVar5 = iVar3 - iVar8;
            if ((iVar4 - *(int32_t *)arg2) + iVar8 <= iVar3) {
                iVar5 = iVar4 - *(int32_t *)arg2;
            }
            iVar8 = iVar8 + iVar5;
            iVar5 = (iVar7 - iVar1) * iVar5;
        }
        iVar6 = iVar6 + iVar5;
        arg2 = (int64_t)piVar9;
    } while (iVar4 < iVar2 + iVar3);
    *(int32_t *)arg_28h = iVar6;
    return iVar7;
}

// ============================================================
// Function: FUN_18011fca0
// Address: 0x18011fca0
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.18011fc80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     undefined8 placeholder_5, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t *piVar9;
    int64_t var_8h;
    
    iVar2 = (int32_t)arg3;
    iVar3 = (int32_t)arg4;
    iVar7 = 0;
    iVar6 = 0;
    iVar8 = 0;
    if (iVar2 + iVar3 <= *(int32_t *)arg2) {
        *(undefined4 *)arg_28h = 0;
        return 0;
    }
    do {
        iVar1 = *(int32_t *)(arg2 + 4);
        if (iVar7 < iVar1) {
            piVar9 = *(int32_t **)(arg2 + 8);
            iVar5 = (iVar1 - iVar7) * iVar8;
            iVar4 = *piVar9;
            iVar7 = iVar1;
            if (*(int32_t *)arg2 < iVar2) {
                iVar8 = iVar8 + (iVar4 - iVar2);
            } else {
                iVar8 = iVar8 + (iVar4 - *(int32_t *)arg2);
            }
        } else {
            piVar9 = *(int32_t **)(arg2 + 8);
            iVar4 = *piVar9;
            iVar5 = iVar3 - iVar8;
            if ((iVar4 - *(int32_t *)arg2) + iVar8 <= iVar3) {
                iVar5 = iVar4 - *(int32_t *)arg2;
            }
            iVar8 = iVar8 + iVar5;
            iVar5 = (iVar7 - iVar1) * iVar5;
        }
        iVar6 = iVar6 + iVar5;
        arg2 = (int64_t)piVar9;
    } while (iVar4 < iVar2 + iVar3);
    *(int32_t *)arg_28h = iVar6;
    return iVar7;
}

