// Chunk 182 - 50 functions

// ============================================================
// Function: FUN_18023f2a0
// Address: 0x18023f2a0
// Size: 29 bytes
// ============================================================
uint64_t fcn.18023f2a0(int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = in_RCX;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)((int64_t)&arg_98h + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)((int64_t)&arg_a0h + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_18023f2c0
// Address: 0x18023f2c0
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.18023f2c0(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_18023f2e0
// Address: 0x18023f2e0
// Size: 72 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

uint64_t fcn.18023f2e0(int64_t param_1, int64_t param_2, uint64_t param_3)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023f2ec;
    iVar3 = fcn.18045a350();
    if ((*(int32_t *)(param_1 + 0x28) != 0) && (param_2 != 0)) {
        uVar1 = *(undefined8 *)(param_1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x18023f315;
        uVar2 = fcn.180460a38(param_2, (int64_t)(int32_t)param_3, 1, uVar1);
        uVar4 = (uint64_t)uVar2;
        if (uVar2 != 0) {
            uVar4 = param_3 & 0xffffffff;
        }
        return uVar4;
    }
    return 0;
}

// ============================================================
// Function: FUN_18023f330
// Address: 0x18023f330
// Size: 197 bytes
// ============================================================
undefined8 fcn.18023f330(int64_t param_1, int64_t param_2, int32_t param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023f33c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int32_t *)(param_1 + 0x28) != 0) && (param_2 != 0)) {
        uVar3 = *(undefined8 *)(param_1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f36c;
        uVar3 = fcn.1804611b4(param_2, 1, (int64_t)param_3, uVar3);
        if ((int32_t)uVar3 != 0) {
            return uVar3;
        }
        uVar3 = *(undefined8 *)(param_1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f379;
        iVar1 = fcn.18046d7c8(uVar3);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f382;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f39a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f3a0;
            (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f3b3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f3b8;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f3d0;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023f3e2;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023f400
// Address: 0x18023f400
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

uint64_t fcn.18023f400(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023f415;
    iVar3 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18023f426;
    uVar4 = fcn.180498cd0(in_RDX);
    if (0x7fffffff < uVar4) {
        return 0xffffffff;
    }
    uVar5 = 0;
    if ((*(int32_t *)(in_RCX + 0x28) != 0) && (in_RDX != 0)) {
        uVar1 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18023f467;
        uVar2 = fcn.180460a38(in_RDX, (int64_t)(int32_t)uVar4, 1, uVar1);
        uVar5 = (uint64_t)uVar2;
        if (uVar2 != 0) {
            uVar5 = uVar4 & 0xffffffff;
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_18023f480
// Address: 0x18023f480
// Size: 69 bytes
// ============================================================
char * fcn.18023f480(int64_t param_1, uint64_t *param_2, uint64_t param_3)
{
    char cVar1;
    undefined8 uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t *puVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023f48c;
    iVar4 = fcn.18045a350();
    *(char *)param_2 = '\0';
    uVar2 = *(undefined8 *)(param_1 + 0x40);
    *(undefined8 *)((int64_t)&uStack_10 - iVar4) = 0x18023f4a6;
    iVar4 = func_0x000180473cc0(param_2, param_3 & 0xffffffff, uVar2);
    if ((iVar4 == 0) || (*(char *)param_2 == '\0')) {
        return (char *)0x0;
    }
    iVar4 = -(int64_t)param_2;
    do {
        if (((uint64_t)param_2 & 7) == 0) goto code_r0x000180498d01;
        cVar1 = *(char *)param_2;
        param_2 = (uint64_t *)((int64_t)param_2 + 1);
    } while (cVar1 != '\0');
code_r0x000180498d48:
    return (char *)((int64_t)param_2 + iVar4 + -1);
code_r0x000180498d01:
    do {
        do {
            puVar5 = param_2;
            param_2 = puVar5 + 1;
        } while (((~*puVar5 ^ *puVar5 + 0x7efefefefefefeff) & 0x8101010101010100) == 0);
        uVar3 = *puVar5;
        if ((char)uVar3 == '\0') {
            return (char *)((int64_t)puVar5 + iVar4);
        }
        if ((char)(uVar3 >> 8) == '\0') {
            return (char *)((int64_t)puVar5 + iVar4 + 1);
        }
        if ((char)(uVar3 >> 0x10) == '\0') {
            return (char *)((int64_t)puVar5 + iVar4 + 2);
        }
        if ((char)(uVar3 >> 0x18) == '\0') {
            return (char *)((int64_t)puVar5 + iVar4 + 3);
        }
        if ((char)(uVar3 >> 0x20) == '\0') {
            return (char *)((int64_t)puVar5 + iVar4 + 4);
        }
        if ((char)(uVar3 >> 0x28) == '\0') {
            return (char *)((int64_t)puVar5 + iVar4 + 5);
        }
        if ((char)(uVar3 >> 0x30) == '\0') {
            return (char *)((int64_t)puVar5 + iVar4 + 6);
        }
    } while ((char)(uVar3 >> 0x38) != '\0');
    goto code_r0x000180498d48;
}

// ============================================================
// Function: FUN_18023f4d0
// Address: 0x18023f4d0
// Size: 909 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.18023f4d0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined4 in_EDX;
    undefined8 uVar6;
    uint32_t uVar7;
    uint64_t in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    code *pcStack_10;
    
    pcStack_10 = (code *)0x18023f4eb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 0x40);
    uVar1 = 1;
    uVar7 = (uint32_t)in_R8;
    // switch table (133 cases) at 0x18023f7a8
    switch(in_EDX) {
    case 1:
    case 0x80:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f538;
        uVar1 = func_0x000180461598(iVar5, in_R8 & 0xffffffff, 0);
        break;
    case 2:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f544;
        uVar1 = func_0x00018046d79c();
        break;
    case 3:
    case 0x85:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f550;
        uVar1 = func_0x00018046d704();
        break;
    default:
        goto code_r0x00018023f78b;
    case 8:
        uVar1 = *(undefined4 *)(in_RCX + 0x2c);
        break;
    case 9:
        *(uint32_t *)(in_RCX + 0x2c) = uVar7;
        break;
    case 0xb:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f721;
        iVar3 = func_0x00018045fdf8();
        if (iVar3 != -1) {
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f72b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f743;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f749;
        (*(code *)0x699ff6)();
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f75c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f761;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
code_r0x00018023f766:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f779;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        goto code_r0x00018023f77e;
    case 0xc:
        break;
    case 0x6a:
        if (*(int32_t *)(in_RCX + 0x2c) != 0) {
            if ((*(int32_t *)(in_RCX + 0x28) != 0) && (iVar5 != 0)) {
                *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f56d;
                func_0x00018045ff84();
                *(undefined4 *)(in_RCX + 0x30) = 0;
            }
            *(undefined4 *)(in_RCX + 0x28) = 0;
        }
        *(int64_t **)(in_RCX + 0x40) = in_R9;
        *(undefined4 *)(in_RCX + 0x28) = 1;
        *(uint32_t *)(in_RCX + 0x2c) = uVar7 & 1;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f591;
        uVar2 = fcn.180473cc8(in_R9);
        uVar6 = 0x4000;
        if ((in_R8 & 0x10) == 0) {
            uVar6 = 0x8000;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f5a9;
        func_0x000180473d20(uVar2, uVar6);
        break;
    case 0x6b:
        if (in_R9 != (int64_t *)0x0) {
            *in_R9 = iVar5;
        }
        break;
    case 0x6c:
        if (*(int32_t *)(in_RCX + 0x2c) != 0) {
            if ((*(int32_t *)(in_RCX + 0x28) != 0) && (iVar5 != 0)) {
                *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f5c4;
                func_0x00018045ff84();
                *(undefined8 *)(in_RCX + 0x40) = 0;
                *(undefined4 *)(in_RCX + 0x30) = 0;
            }
            *(undefined4 *)(in_RCX + 0x28) = 0;
        }
        *(uint32_t *)(in_RCX + 0x2c) = uVar7 & 1;
        if ((in_R8 & 8) != 0) {
            uVar6 = 0x1804e3db0;
            if ((in_R8 & 2) == 0) {
                uVar6 = 0x1804a59f0;
            }
code_r0x00018023f630:
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f640;
            func_0x000180223790((int64_t)&arg_40h + iVar4, uVar6, 4);
            uVar6 = 0x1804e3dc4;
            if ((in_R8 & 0x10) != 0) {
                uVar6 = 0x1804e3dc8;
            }
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f666;
            func_0x000180223710((int64_t)&arg_40h + iVar4, uVar6, 4);
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f673;
            iVar5 = func_0x0001802aee20(in_R9, (int64_t)&arg_40h + iVar4);
            if (iVar5 != 0) {
                *(int64_t *)(in_RCX + 0x40) = iVar5;
                *(undefined4 *)(in_RCX + 0x28) = 1;
                *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f6db;
                func_0x000180219ce0(in_RCX, 0);
                return 1;
            }
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f67d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f695;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f69b;
            (*(code *)0x699ff6)();
            *(int64_t *)((int64_t)&var_18h + iVar4) = (int64_t)&arg_40h + iVar4;
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f6bb;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f6c0;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            goto code_r0x00018023f766;
        }
        if ((in_R8 & 2) != 0) {
            if ((in_R8 & 4) == 0) {
                uVar6 = 0x1804a59ec;
            } else {
                uVar6 = 0x1804e3db4;
            }
            goto code_r0x00018023f630;
        }
        if ((in_R8 & 4) != 0) {
            uVar6 = 0x180621ec0;
            goto code_r0x00018023f630;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f6e5;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar4) = 0x18023f6fd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x00018023f77e:
        *(code **)((int64_t)&pcStack_10 + iVar4) = case.0x18023f52c.4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x00018023f78b:
        uVar1 = 0;
    }
    return uVar1;
}

// ============================================================
// Function: FUN_18023f880
// Address: 0x18023f880
// Size: 90 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18023f880(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023f88c;
    iVar1 = fcn.18045a350();
    if (param_1 == 0) {
        return 0;
    }
    if (*(int32_t *)(param_1 + 0x2c) != 0) {
        if ((*(int32_t *)(param_1 + 0x28) != 0) && (*(int64_t *)(param_1 + 0x40) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18023f8b9;
            fcn.18045ff84();
            *(undefined8 *)(param_1 + 0x40) = 0;
            *(undefined4 *)(param_1 + 0x30) = 0;
        }
        *(undefined4 *)(param_1 + 0x28) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18023f8e0
// Address: 0x18023f8e0
// Size: 315 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18023f8e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined4 uVar5;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023f8fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f908;
    iVar2 = func_0x0001802aee20();
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f918;
    iVar3 = func_0x00018045b928(in_RDX, 0x62);
    uVar5 = 0x11;
    if (iVar3 != 0) {
        uVar5 = 1;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f936;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f94e;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)((int64_t)&arg_48h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f954;
        (*(code *)0x699ff6)();
        *(undefined8 *)((int64_t)&iStackX_20 + iVar1 + -8) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f96f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f974;
        piVar4 = (int32_t *)fcn.18046b77c();
        if (*piVar4 != 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f97e;
            fcn.18046b77c();
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f99e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f9b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)((int64_t)&arg_48h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f9c2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        iVar3 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f9d2;
        iVar3 = func_0x00018021a7c0(0x1804e3cd0);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f9e2;
            fcn.18045ff84(iVar2);
            iVar3 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023f9f0;
            func_0x000180219ce0(iVar3, 0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023fa03;
            func_0x000180219d10(iVar3, 0x6a, uVar5, iVar2);
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18023fa20
// Address: 0x18023fa20
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18023fa20(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023fa35;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023fa49;
    iVar2 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023fa6b;
    fcn.18021b250(iVar2, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023fa7e;
    fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    return iVar2;
}

// ============================================================
// Function: FUN_18023fab0
// Address: 0x18023fab0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18023fab0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar6;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023fac4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&var_10h + iVar2) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023faec;
    iVar3 = func_0x00018023fde0(0, in_RCX, in_RDX, in_R8 & 0xffffffff);
    if (iVar3 == 0) {
        uVar4 = *in_RDX;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar2) = uVar4;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb16;
        uVar4 = func_0x000180228a30(0, (int64_t)&arg_50h + iVar2, in_R8 & 0xffffffff);
        *(undefined8 *)((int64_t)&arg_50h + iVar2) = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb29;
        iVar1 = func_0x000180222010(uVar4);
        if (iVar1 == 6) {
            uVar6 = 0x74;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb40;
            iVar1 = func_0x000180222010(uVar4);
            if (iVar1 == 4) {
                uVar6 = 0x198;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb57;
                iVar1 = func_0x000180222010(uVar4);
                if (iVar1 == 3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb6f;
                    iVar3 = func_0x0001802af1a0(0, (int64_t)&arg_50h + iVar2, in_R8 & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb81;
                    func_0x000180222050(uVar4, 0x180228940);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb8b;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fba3;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbb5;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar2));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbc4;
                    iVar5 = func_0x0001802af520(iVar3, 0, 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbcf;
                    func_0x0001802af020(iVar3);
                    if (iVar5 == 0) {
                        return 0;
                    }
                    *in_RDX = *(undefined8 *)((int64_t)&arg_50h + iVar2);
                    if (in_RCX == (int64_t *)0x0) {
                        return iVar5;
                    }
                    *in_RCX = iVar5;
                    return iVar5;
                }
                uVar6 = 6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbfd;
        func_0x000180222050(uVar4, 0x180228940);
        *(undefined8 *)((int64_t)&var_10h + iVar2) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fc17;
        iVar3 = func_0x0001802400c0(uVar6, in_RCX, in_RDX, in_R8 & 0xffffffff);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18023fafd
// Address: 0x18023fafd
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18023fab0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar6;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023fac4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&var_10h + iVar2) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023faec;
    iVar3 = func_0x00018023fde0(0, in_RCX, in_RDX, in_R8 & 0xffffffff);
    if (iVar3 == 0) {
        uVar4 = *in_RDX;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar2) = uVar4;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb16;
        uVar4 = func_0x000180228a30(0, (int64_t)&arg_50h + iVar2, in_R8 & 0xffffffff);
        *(undefined8 *)((int64_t)&arg_50h + iVar2) = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb29;
        iVar1 = func_0x000180222010(uVar4);
        if (iVar1 == 6) {
            uVar6 = 0x74;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb40;
            iVar1 = func_0x000180222010(uVar4);
            if (iVar1 == 4) {
                uVar6 = 0x198;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb57;
                iVar1 = func_0x000180222010(uVar4);
                if (iVar1 == 3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb6f;
                    iVar3 = func_0x0001802af1a0(0, (int64_t)&arg_50h + iVar2, in_R8 & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb81;
                    func_0x000180222050(uVar4, 0x180228940);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb8b;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fba3;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbb5;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar2));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbc4;
                    iVar5 = func_0x0001802af520(iVar3, 0, 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbcf;
                    func_0x0001802af020(iVar3);
                    if (iVar5 == 0) {
                        return 0;
                    }
                    *in_RDX = *(undefined8 *)((int64_t)&arg_50h + iVar2);
                    if (in_RCX == (int64_t *)0x0) {
                        return iVar5;
                    }
                    *in_RCX = iVar5;
                    return iVar5;
                }
                uVar6 = 6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbfd;
        func_0x000180222050(uVar4, 0x180228940);
        *(undefined8 *)((int64_t)&var_10h + iVar2) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fc17;
        iVar3 = func_0x0001802400c0(uVar6, in_RCX, in_RDX, in_R8 & 0xffffffff);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18023fc27
// Address: 0x18023fc27
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18023fab0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar6;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023fac4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&var_10h + iVar2) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023faec;
    iVar3 = func_0x00018023fde0(0, in_RCX, in_RDX, in_R8 & 0xffffffff);
    if (iVar3 == 0) {
        uVar4 = *in_RDX;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar2) = uVar4;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb16;
        uVar4 = func_0x000180228a30(0, (int64_t)&arg_50h + iVar2, in_R8 & 0xffffffff);
        *(undefined8 *)((int64_t)&arg_50h + iVar2) = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb29;
        iVar1 = func_0x000180222010(uVar4);
        if (iVar1 == 6) {
            uVar6 = 0x74;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb40;
            iVar1 = func_0x000180222010(uVar4);
            if (iVar1 == 4) {
                uVar6 = 0x198;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb57;
                iVar1 = func_0x000180222010(uVar4);
                if (iVar1 == 3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb6f;
                    iVar3 = func_0x0001802af1a0(0, (int64_t)&arg_50h + iVar2, in_R8 & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb81;
                    func_0x000180222050(uVar4, 0x180228940);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fb8b;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fba3;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbb5;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar2));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbc4;
                    iVar5 = func_0x0001802af520(iVar3, 0, 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbcf;
                    func_0x0001802af020(iVar3);
                    if (iVar5 == 0) {
                        return 0;
                    }
                    *in_RDX = *(undefined8 *)((int64_t)&arg_50h + iVar2);
                    if (in_RCX == (int64_t *)0x0) {
                        return iVar5;
                    }
                    *in_RCX = iVar5;
                    return iVar5;
                }
                uVar6 = 6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fbfd;
        func_0x000180222050(uVar4, 0x180228940);
        *(undefined8 *)((int64_t)&var_10h + iVar2) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023fc17;
        iVar3 = func_0x0001802400c0(uVar6, in_RCX, in_RDX, in_R8 & 0xffffffff);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18023fc40
// Address: 0x18023fc40
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023fc40(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar7;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023fc5a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar3);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = in_R9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fc8b;
    iVar4 = func_0x00018023fde0(0, in_RCX, in_RDX, in_R8 & 0xffffffff);
    if (iVar4 == 0) {
        uVar5 = *in_RDX;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcb5;
        uVar5 = func_0x000180228a30(0, (int64_t)&var_18h + iVar3, in_R8 & 0xffffffff);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcc8;
        iVar2 = func_0x000180222010(uVar5);
        if (iVar2 == 6) {
            uVar7 = 0x74;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcdf;
            iVar2 = func_0x000180222010(uVar5);
            if (iVar2 == 4) {
                uVar7 = 0x198;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcf6;
                iVar2 = func_0x000180222010(uVar5);
                if (iVar2 == 3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd0e;
                    iVar4 = func_0x0001802af1a0(0, (int64_t)&var_18h + iVar3, in_R8 & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd20;
                    func_0x000180222050(uVar5, 0x180228940);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd2a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd42;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd54;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd66;
                        iVar6 = func_0x0001802af520(iVar4, in_R9, uVar1);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd71;
                        func_0x0001802af020(iVar4);
                        if (iVar6 != 0) {
                            *in_RDX = *(undefined8 *)((int64_t)&var_18h + iVar3);
                            if (in_RCX == (int64_t *)0x0) {
                                return iVar6;
                            }
                            *in_RCX = iVar6;
                            return iVar6;
                        }
                    }
                    return 0;
                }
                uVar7 = 6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd9c;
        func_0x000180222050(uVar5, 0x180228940);
        *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fdb6;
        iVar4 = func_0x0001802400c0(uVar7, in_RCX, in_RDX, in_R8 & 0xffffffff);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18023fc9c
// Address: 0x18023fc9c
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023fc40(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar7;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023fc5a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar3);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = in_R9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fc8b;
    iVar4 = func_0x00018023fde0(0, in_RCX, in_RDX, in_R8 & 0xffffffff);
    if (iVar4 == 0) {
        uVar5 = *in_RDX;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcb5;
        uVar5 = func_0x000180228a30(0, (int64_t)&var_18h + iVar3, in_R8 & 0xffffffff);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcc8;
        iVar2 = func_0x000180222010(uVar5);
        if (iVar2 == 6) {
            uVar7 = 0x74;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcdf;
            iVar2 = func_0x000180222010(uVar5);
            if (iVar2 == 4) {
                uVar7 = 0x198;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcf6;
                iVar2 = func_0x000180222010(uVar5);
                if (iVar2 == 3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd0e;
                    iVar4 = func_0x0001802af1a0(0, (int64_t)&var_18h + iVar3, in_R8 & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd20;
                    func_0x000180222050(uVar5, 0x180228940);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd2a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd42;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd54;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd66;
                        iVar6 = func_0x0001802af520(iVar4, in_R9, uVar1);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd71;
                        func_0x0001802af020(iVar4);
                        if (iVar6 != 0) {
                            *in_RDX = *(undefined8 *)((int64_t)&var_18h + iVar3);
                            if (in_RCX == (int64_t *)0x0) {
                                return iVar6;
                            }
                            *in_RCX = iVar6;
                            return iVar6;
                        }
                    }
                    return 0;
                }
                uVar7 = 6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd9c;
        func_0x000180222050(uVar5, 0x180228940);
        *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fdb6;
        iVar4 = func_0x0001802400c0(uVar7, in_RCX, in_RDX, in_R8 & 0xffffffff);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18023fdc6
// Address: 0x18023fdc6
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023fc40(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar7;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023fc5a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar3);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = in_R9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fc8b;
    iVar4 = func_0x00018023fde0(0, in_RCX, in_RDX, in_R8 & 0xffffffff);
    if (iVar4 == 0) {
        uVar5 = *in_RDX;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcb5;
        uVar5 = func_0x000180228a30(0, (int64_t)&var_18h + iVar3, in_R8 & 0xffffffff);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcc8;
        iVar2 = func_0x000180222010(uVar5);
        if (iVar2 == 6) {
            uVar7 = 0x74;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcdf;
            iVar2 = func_0x000180222010(uVar5);
            if (iVar2 == 4) {
                uVar7 = 0x198;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fcf6;
                iVar2 = func_0x000180222010(uVar5);
                if (iVar2 == 3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd0e;
                    iVar4 = func_0x0001802af1a0(0, (int64_t)&var_18h + iVar3, in_R8 & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd20;
                    func_0x000180222050(uVar5, 0x180228940);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd2a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd42;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd54;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd66;
                        iVar6 = func_0x0001802af520(iVar4, in_R9, uVar1);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd71;
                        func_0x0001802af020(iVar4);
                        if (iVar6 != 0) {
                            *in_RDX = *(undefined8 *)((int64_t)&var_18h + iVar3);
                            if (in_RCX == (int64_t *)0x0) {
                                return iVar6;
                            }
                            *in_RCX = iVar6;
                            return iVar6;
                        }
                    }
                    return 0;
                }
                uVar7 = 6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fd9c;
        func_0x000180222050(uVar5, 0x180228940);
        *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023fdb6;
        iVar4 = func_0x0001802400c0(uVar7, in_RCX, in_RDX, in_R8 & 0xffffffff);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18023fde0
// Address: 0x18023fde0
// Size: 597 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18023fde0(int64_t arg_28h, int64_t arg_30h, int64_t arg_68h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_128h
                  )
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int32_t in_ECX;
    int64_t *in_RDX;
    int64_t iVar6;
    int64_t *piVar7;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    uint64_t uStackX_18;
    undefined8 uStackX_20;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    
    uStack_48 = 0x18023fdf7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar3);
    piVar7 = (int64_t *)((int64_t)&uStackX_18 + iVar3 + -8);
    uVar1 = *in_R8;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = *(undefined8 *)((int64_t)&arg_e0h + iVar3);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + -0x20) = *(undefined8 *)((int64_t)&arg_e8h + iVar3);
    *(int64_t *)((int64_t)&arg_28h + iVar3) = (int64_t)(int32_t)in_R9;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + -8) = 0;
    iVar4 = iVar8;
    if (in_ECX != 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023fe50;
        iVar4 = func_0x000180231580();
        if (iVar4 == 0) goto code_r0x000180240011;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023fe61;
    func_0x000180229b10();
    *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023fe6e;
    puVar5 = (undefined8 *)func_0x0001802af1a0(0, in_R8, in_R9 & 0xffffffff);
    *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023fe76;
    func_0x0001802299d0();
    if (puVar5 == (undefined8 *)0x0) {
        uVar9 = 0x1804e3e28;
    } else {
        uVar9 = *puVar5;
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023fe8c;
        iVar2 = func_0x00018025fe40((int64_t)&uStackX_18 + iVar3, uVar9);
        if ((iVar2 == 0) || (1 < *(uint64_t *)((int64_t)&uStackX_18 + iVar3))) {
            *in_R8 = uVar1;
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023fef6;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ff0e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar3), *(int64_t *)(&stack0xfffffffffffffff8 + iVar3)
                          , *(int64_t *)((int64_t)&uStackX_18 + iVar3 + -8));
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ff20;
            fcn.1802296d0(*(int64_t *)((int64_t)&uStackX_20 + iVar3 + -0x20));
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ff28;
            func_0x0001802af020(puVar5);
            goto code_r0x000180240011;
        }
        iVar6 = iVar4;
        if (iVar4 == 0) {
            *(undefined8 **)((int64_t)&var_20h + iVar3) = puVar5;
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023feb4;
            iVar2 = func_0x0001802af070((int64_t)&uStackX_20 + iVar3, 0, 0, 0);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023fecf;
                iVar2 = func_0x00018022cd40((int64_t)&arg_30h + iVar3, 0x32, 
                                            *(undefined8 *)((int64_t)&uStackX_20 + iVar3), 0);
                iVar6 = (int64_t)&arg_30h + iVar3;
                if (iVar2 == 0) {
                    iVar6 = iVar4;
                }
            }
        }
        uVar9 = 0x1804e3e18;
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023feec;
        func_0x0001802af020(puVar5);
        iVar4 = iVar6;
    }
    *in_R8 = uVar1;
    if ((in_RDX == (int64_t *)0x0) || (iVar8 = *in_RDX, iVar8 == 0)) {
        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar3) = *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + -0x20);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&var_8h + iVar3);
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 0x87;
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ffae;
        iVar4 = func_0x000180271890(piVar7, 0x1804e2760, uVar9, iVar4);
        if (in_RDX != (int64_t *)0x0) goto code_r0x00018023ffb6;
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar3) = *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + -0x20);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&var_8h + iVar3);
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 0x87;
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ff78;
        iVar4 = func_0x000180271890(in_RDX, 0x1804e2760, uVar9, iVar4);
        piVar7 = in_RDX;
code_r0x00018023ffb6:
        *in_RDX = iVar8;
    }
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ffce;
        iVar2 = func_0x000180270af0(iVar4, in_R8, (int64_t)&arg_28h + iVar3);
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ffd8;
        func_0x00018026f440(iVar4);
        if ((iVar2 != 0) && (iVar8 = *piVar7, iVar8 != 0)) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18023ffee;
            iVar2 = func_0x00018029f040(iVar8, 1);
            if (iVar2 != 0) {
                if (in_RDX != (int64_t *)0x0) {
                    *in_RDX = *piVar7;
                }
                goto code_r0x000180240011;
            }
        }
    }
    if (piVar7 != in_RDX) {
        iVar8 = *piVar7;
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x18024000f;
        func_0x00018022ecc0(iVar8);
    }
code_r0x000180240011:
    *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x180240021;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180240040
// Address: 0x180240040
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180240040(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024005e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)((int64_t)&arg_60h + iVar3);
    uVar2 = *(undefined8 *)((int64_t)&arg_58h + iVar3);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180240085;
    iVar4 = fcn.18023fde0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)(&stack0x000000c0 + iVar3), 
                          *(int64_t *)(&stack0x000000c8 + iVar3), *(int64_t *)(&stack0x00000108 + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar1;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar2;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802400a4;
        fcn.1802400c0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
    }
    return;
}

// ============================================================
// Function: FUN_1802400c0
// Address: 0x1802400c0
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802400c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802400d9;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *in_R8;
    if ((in_RDX == (int64_t *)0x0) || (iVar6 = *in_RDX, iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024015b;
        iVar6 = func_0x00018022fd80();
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240168;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240180;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240192;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            return 0;
        }
    } else {
        uVar1 = *(undefined8 *)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240106;
        func_0x00018026aee0(uVar1);
        *(undefined8 *)(iVar6 + 0x10) = 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024011e;
    iVar3 = func_0x0001802304b0(iVar6, in_RCX & 0xffffffff);
    iVar8 = iVar6;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240127;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024013f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240151;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024019b;
        func_0x000180229b10();
        pcVar2 = *(code **)(*(int64_t *)(iVar6 + 8) + 0xb8);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401b9;
            iVar3 = (*pcVar2)(iVar6, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401c2;
                func_0x000180229900();
                goto code_r0x0001802401c2;
            }
        }
        if ((*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x40) == 0) && (*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x138) == 0))
        {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240208;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024020d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240225;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240237;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240248;
            iVar7 = func_0x0001802af1a0(0, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240255;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240269;
                iVar8 = func_0x0001802af520(iVar7, *(undefined8 *)((int64_t)&arg_48h + iVar5), 
                                            *(undefined8 *)((int64_t)&arg_50h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240274;
                func_0x0001802af020(iVar7);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024027e;
                    func_0x000180229900();
                    iVar8 = iVar6;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240288;
                    func_0x00018022ecc0(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240290;
                    func_0x0001802299d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240298;
                    iVar3 = func_0x00018022f0c0(iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402a2;
                    iVar4 = func_0x000180299e80(in_RCX & 0xffffffff);
                    if (iVar4 == iVar3) {
code_r0x0001802401c2:
                        *in_R8 = *(undefined8 *)((int64_t)&arg_30h + iVar5);
                        if (in_RDX == (int64_t *)0x0) {
                            return iVar8;
                        }
                        *in_RDX = iVar8;
                        return iVar8;
                    }
                }
            }
        }
    }
    if ((in_RDX == (int64_t *)0x0) || (*in_RDX != iVar8)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402bc;
        func_0x00018022ecc0(iVar8);
    }
    return 0;
}

// ============================================================
// Function: FUN_180240111
// Address: 0x180240111
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802400c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802400d9;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *in_R8;
    if ((in_RDX == (int64_t *)0x0) || (iVar6 = *in_RDX, iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024015b;
        iVar6 = func_0x00018022fd80();
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240168;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240180;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240192;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            return 0;
        }
    } else {
        uVar1 = *(undefined8 *)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240106;
        func_0x00018026aee0(uVar1);
        *(undefined8 *)(iVar6 + 0x10) = 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024011e;
    iVar3 = func_0x0001802304b0(iVar6, in_RCX & 0xffffffff);
    iVar8 = iVar6;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240127;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024013f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240151;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024019b;
        func_0x000180229b10();
        pcVar2 = *(code **)(*(int64_t *)(iVar6 + 8) + 0xb8);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401b9;
            iVar3 = (*pcVar2)(iVar6, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401c2;
                func_0x000180229900();
                goto code_r0x0001802401c2;
            }
        }
        if ((*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x40) == 0) && (*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x138) == 0))
        {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240208;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024020d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240225;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240237;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240248;
            iVar7 = func_0x0001802af1a0(0, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240255;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240269;
                iVar8 = func_0x0001802af520(iVar7, *(undefined8 *)((int64_t)&arg_48h + iVar5), 
                                            *(undefined8 *)((int64_t)&arg_50h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240274;
                func_0x0001802af020(iVar7);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024027e;
                    func_0x000180229900();
                    iVar8 = iVar6;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240288;
                    func_0x00018022ecc0(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240290;
                    func_0x0001802299d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240298;
                    iVar3 = func_0x00018022f0c0(iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402a2;
                    iVar4 = func_0x000180299e80(in_RCX & 0xffffffff);
                    if (iVar4 == iVar3) {
code_r0x0001802401c2:
                        *in_R8 = *(undefined8 *)((int64_t)&arg_30h + iVar5);
                        if (in_RDX == (int64_t *)0x0) {
                            return iVar8;
                        }
                        *in_RDX = iVar8;
                        return iVar8;
                    }
                }
            }
        }
    }
    if ((in_RDX == (int64_t *)0x0) || (*in_RDX != iVar8)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402bc;
        func_0x00018022ecc0(iVar8);
    }
    return 0;
}

// ============================================================
// Function: FUN_180240156
// Address: 0x180240156
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802400c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802400d9;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *in_R8;
    if ((in_RDX == (int64_t *)0x0) || (iVar6 = *in_RDX, iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024015b;
        iVar6 = func_0x00018022fd80();
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240168;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240180;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240192;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            return 0;
        }
    } else {
        uVar1 = *(undefined8 *)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240106;
        func_0x00018026aee0(uVar1);
        *(undefined8 *)(iVar6 + 0x10) = 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024011e;
    iVar3 = func_0x0001802304b0(iVar6, in_RCX & 0xffffffff);
    iVar8 = iVar6;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240127;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024013f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240151;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024019b;
        func_0x000180229b10();
        pcVar2 = *(code **)(*(int64_t *)(iVar6 + 8) + 0xb8);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401b9;
            iVar3 = (*pcVar2)(iVar6, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401c2;
                func_0x000180229900();
                goto code_r0x0001802401c2;
            }
        }
        if ((*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x40) == 0) && (*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x138) == 0))
        {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240208;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024020d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240225;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240237;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240248;
            iVar7 = func_0x0001802af1a0(0, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240255;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240269;
                iVar8 = func_0x0001802af520(iVar7, *(undefined8 *)((int64_t)&arg_48h + iVar5), 
                                            *(undefined8 *)((int64_t)&arg_50h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240274;
                func_0x0001802af020(iVar7);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024027e;
                    func_0x000180229900();
                    iVar8 = iVar6;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240288;
                    func_0x00018022ecc0(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240290;
                    func_0x0001802299d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240298;
                    iVar3 = func_0x00018022f0c0(iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402a2;
                    iVar4 = func_0x000180299e80(in_RCX & 0xffffffff);
                    if (iVar4 == iVar3) {
code_r0x0001802401c2:
                        *in_R8 = *(undefined8 *)((int64_t)&arg_30h + iVar5);
                        if (in_RDX == (int64_t *)0x0) {
                            return iVar8;
                        }
                        *in_RDX = iVar8;
                        return iVar8;
                    }
                }
            }
        }
    }
    if ((in_RDX == (int64_t *)0x0) || (*in_RDX != iVar8)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402bc;
        func_0x00018022ecc0(iVar8);
    }
    return 0;
}

// ============================================================
// Function: FUN_180240196
// Address: 0x180240196
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802400c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802400d9;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *in_R8;
    if ((in_RDX == (int64_t *)0x0) || (iVar6 = *in_RDX, iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024015b;
        iVar6 = func_0x00018022fd80();
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240168;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240180;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240192;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            return 0;
        }
    } else {
        uVar1 = *(undefined8 *)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240106;
        func_0x00018026aee0(uVar1);
        *(undefined8 *)(iVar6 + 0x10) = 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024011e;
    iVar3 = func_0x0001802304b0(iVar6, in_RCX & 0xffffffff);
    iVar8 = iVar6;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240127;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024013f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240151;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024019b;
        func_0x000180229b10();
        pcVar2 = *(code **)(*(int64_t *)(iVar6 + 8) + 0xb8);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401b9;
            iVar3 = (*pcVar2)(iVar6, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401c2;
                func_0x000180229900();
                goto code_r0x0001802401c2;
            }
        }
        if ((*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x40) == 0) && (*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x138) == 0))
        {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240208;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024020d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240225;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240237;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240248;
            iVar7 = func_0x0001802af1a0(0, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240255;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240269;
                iVar8 = func_0x0001802af520(iVar7, *(undefined8 *)((int64_t)&arg_48h + iVar5), 
                                            *(undefined8 *)((int64_t)&arg_50h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240274;
                func_0x0001802af020(iVar7);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024027e;
                    func_0x000180229900();
                    iVar8 = iVar6;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240288;
                    func_0x00018022ecc0(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240290;
                    func_0x0001802299d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240298;
                    iVar3 = func_0x00018022f0c0(iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402a2;
                    iVar4 = func_0x000180299e80(in_RCX & 0xffffffff);
                    if (iVar4 == iVar3) {
code_r0x0001802401c2:
                        *in_R8 = *(undefined8 *)((int64_t)&arg_30h + iVar5);
                        if (in_RDX == (int64_t *)0x0) {
                            return iVar8;
                        }
                        *in_RDX = iVar8;
                        return iVar8;
                    }
                }
            }
        }
    }
    if ((in_RDX == (int64_t *)0x0) || (*in_RDX != iVar8)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402bc;
        func_0x00018022ecc0(iVar8);
    }
    return 0;
}

// ============================================================
// Function: FUN_1802401da
// Address: 0x1802401da
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802400c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802400d9;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *in_R8;
    if ((in_RDX == (int64_t *)0x0) || (iVar6 = *in_RDX, iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024015b;
        iVar6 = func_0x00018022fd80();
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240168;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240180;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240192;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            return 0;
        }
    } else {
        uVar1 = *(undefined8 *)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240106;
        func_0x00018026aee0(uVar1);
        *(undefined8 *)(iVar6 + 0x10) = 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024011e;
    iVar3 = func_0x0001802304b0(iVar6, in_RCX & 0xffffffff);
    iVar8 = iVar6;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240127;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024013f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240151;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024019b;
        func_0x000180229b10();
        pcVar2 = *(code **)(*(int64_t *)(iVar6 + 8) + 0xb8);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401b9;
            iVar3 = (*pcVar2)(iVar6, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401c2;
                func_0x000180229900();
                goto code_r0x0001802401c2;
            }
        }
        if ((*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x40) == 0) && (*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x138) == 0))
        {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240208;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024020d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240225;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240237;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240248;
            iVar7 = func_0x0001802af1a0(0, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240255;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240269;
                iVar8 = func_0x0001802af520(iVar7, *(undefined8 *)((int64_t)&arg_48h + iVar5), 
                                            *(undefined8 *)((int64_t)&arg_50h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240274;
                func_0x0001802af020(iVar7);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024027e;
                    func_0x000180229900();
                    iVar8 = iVar6;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240288;
                    func_0x00018022ecc0(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240290;
                    func_0x0001802299d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240298;
                    iVar3 = func_0x00018022f0c0(iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402a2;
                    iVar4 = func_0x000180299e80(in_RCX & 0xffffffff);
                    if (iVar4 == iVar3) {
code_r0x0001802401c2:
                        *in_R8 = *(undefined8 *)((int64_t)&arg_30h + iVar5);
                        if (in_RDX == (int64_t *)0x0) {
                            return iVar8;
                        }
                        *in_RDX = iVar8;
                        return iVar8;
                    }
                }
            }
        }
    }
    if ((in_RDX == (int64_t *)0x0) || (*in_RDX != iVar8)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402bc;
        func_0x00018022ecc0(iVar8);
    }
    return 0;
}

// ============================================================
// Function: FUN_1802401ee
// Address: 0x1802401ee
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802400c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802400d9;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *in_R8;
    if ((in_RDX == (int64_t *)0x0) || (iVar6 = *in_RDX, iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024015b;
        iVar6 = func_0x00018022fd80();
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240168;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240180;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240192;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            return 0;
        }
    } else {
        uVar1 = *(undefined8 *)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240106;
        func_0x00018026aee0(uVar1);
        *(undefined8 *)(iVar6 + 0x10) = 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024011e;
    iVar3 = func_0x0001802304b0(iVar6, in_RCX & 0xffffffff);
    iVar8 = iVar6;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240127;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024013f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240151;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024019b;
        func_0x000180229b10();
        pcVar2 = *(code **)(*(int64_t *)(iVar6 + 8) + 0xb8);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401b9;
            iVar3 = (*pcVar2)(iVar6, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802401c2;
                func_0x000180229900();
                goto code_r0x0001802401c2;
            }
        }
        if ((*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x40) == 0) && (*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x138) == 0))
        {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240208;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024020d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240225;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240237;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240248;
            iVar7 = func_0x0001802af1a0(0, (int64_t)&arg_30h + iVar5, in_R9 & 0xffffffff);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240255;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240269;
                iVar8 = func_0x0001802af520(iVar7, *(undefined8 *)((int64_t)&arg_48h + iVar5), 
                                            *(undefined8 *)((int64_t)&arg_50h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240274;
                func_0x0001802af020(iVar7);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024027e;
                    func_0x000180229900();
                    iVar8 = iVar6;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240288;
                    func_0x00018022ecc0(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240290;
                    func_0x0001802299d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180240298;
                    iVar3 = func_0x00018022f0c0(iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402a2;
                    iVar4 = func_0x000180299e80(in_RCX & 0xffffffff);
                    if (iVar4 == iVar3) {
code_r0x0001802401c2:
                        *in_R8 = *(undefined8 *)((int64_t)&arg_30h + iVar5);
                        if (in_RDX == (int64_t *)0x0) {
                            return iVar8;
                        }
                        *in_RDX = iVar8;
                        return iVar8;
                    }
                }
            }
        }
    }
    if ((in_RDX == (int64_t *)0x0) || (*in_RDX != iVar8)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802402bc;
        func_0x00018022ecc0(iVar8);
    }
    return 0;
}

// ============================================================
// Function: FUN_1802402d0
// Address: 0x1802402d0
// Size: 276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1802402d0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined4 *in_R8;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802402e4;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802402fd;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180240315;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000038 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180240327;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180240347;
    iVar5 = fcn.18020f860(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
    if ((iVar5 != 0) && ((*(uint32_t *)(in_RCX + 0x7c) & 0x100100) == 0x100)) {
        if (in_R9 != (undefined4 *)0x0) {
            *in_R9 = 0x14;
        }
        uVar2 = *(undefined4 *)(in_RCX + 0xb4);
        uVar3 = *(undefined4 *)(in_RCX + 0xb8);
        uVar4 = *(undefined4 *)(in_RCX + 0xbc);
        *in_R8 = *(undefined4 *)(in_RCX + 0xb0);
        in_R8[1] = uVar2;
        in_R8[2] = uVar3;
        in_R8[3] = uVar4;
        in_R8[4] = *(undefined4 *)(in_RCX + 0xc0);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBX;
    uVar7 = *(undefined8 *)(in_RCX + 0xe8);
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_RDI;
    uVar1 = *(undefined8 *)(in_RCX + 0xe0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802403ab;
    fcn.18028ec30();
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -8) = uVar7;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = uVar1;
    *(undefined4 **)((int64_t)&var_8h + iVar6) = in_R9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802403cb;
    uVar7 = fcn.1802b2fc0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6), 
                          *(int64_t *)(&stack0x00000070 + iVar6));
    return uVar7;
}

// ============================================================
// Function: FUN_1802403f0
// Address: 0x1802403f0
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1802403f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024040a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024041e;
    fcn.180234910();
    *(undefined8 *)((int64_t)&var_18h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180240434;
    fcn.1802b2ec0(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)((int64_t)&arg_38h + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                  *(int64_t *)(&stack0x00000098 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180240450
// Address: 0x180240450
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180240450(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined4 *in_R8;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180240464;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180240482;
    iVar5 = fcn.18020f860(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
    if ((iVar5 != 0) && ((*(uint32_t *)(in_RCX + 0xd8) & 0x100100) == 0x100)) {
        if (in_R9 != (undefined4 *)0x0) {
            *in_R9 = 0x14;
        }
        uVar2 = *(undefined4 *)(in_RCX + 300);
        uVar3 = *(undefined4 *)(in_RCX + 0x130);
        uVar4 = *(undefined4 *)(in_RCX + 0x134);
        *in_R8 = *(undefined4 *)(in_RCX + 0x128);
        in_R8[1] = uVar2;
        in_R8[2] = uVar3;
        in_R8[3] = uVar4;
        in_R8[4] = *(undefined4 *)(in_RCX + 0x138);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBX;
    uVar7 = *(undefined8 *)(in_RCX + 0x168);
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_RDI;
    uVar1 = *(undefined8 *)(in_RCX + 0x160);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802404e9;
    fcn.18021ff00();
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -8) = uVar7;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = uVar1;
    *(undefined4 **)((int64_t)&var_8h + iVar6) = in_R9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180240509;
    uVar7 = fcn.1802b2fc0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6), 
                          *(int64_t *)(&stack0x00000070 + iVar6));
    return uVar7;
}

// ============================================================
// Function: FUN_180240530
// Address: 0x180240530
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180240530(int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180240545;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180240556;
    iVar2 = fcn.180235c90();
    if (iVar2 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024058b;
    fcn.180214220(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802405a0
// Address: 0x1802405a0
// Size: 177 bytes
// ============================================================
undefined8 fcn.1802405a0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802405b0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802405c6;
    iVar3 = fcn.18027cfe0(*(int64_t *)((int64_t)&var_8h + iVar4));
    if (iVar3 != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBX;
    uVar5 = *(undefined8 *)(in_RCX + 0x168);
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RSI;
    uVar1 = *(undefined8 *)(in_RCX + 0x158);
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RDI;
    uVar2 = *(undefined8 *)(in_RCX + 0x160);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180240605;
    fcn.18021fb40();
    *(undefined8 *)((int64_t)&var_20h + iVar4) = uVar5;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar2;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = in_RDX;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180240632;
    uVar5 = fcn.1802afbb0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)((int64_t)&arg_50h + iVar4));
    return uVar5;
}

// ============================================================
// Function: FUN_180240660
// Address: 0x180240660
// Size: 42 bytes
// ============================================================
undefined8
fcn.180240660(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RCX;
    undefined8 in_RDX;
    code *pcVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar6 = fcn.18023fab0;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802afc7a;
    iVar4 = fcn.18045a350(0x18022fd80, fcn.18023fab0, in_RCX, in_RDX);
    iVar4 = -iVar4;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4 + iVar3) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802afc97;
    iVar2 = fcn.1802afe20(*(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar4 + iVar3), *(int64_t *)(&stack0x00000080 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000098 + iVar4 + iVar3));
    iVar1 = *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3);
    if (-1 < iVar2) {
        *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar3) = *(undefined8 *)(iVar1 + 8);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802afcb6;
        uVar5 = (*pcVar6)(in_RDX, (int64_t)&arg_48h + iVar4 + iVar3, iVar2);
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802afcc1;
    fcn.180226310(iVar1);
    return uVar5;
}

// ============================================================
// Function: FUN_180240690
// Address: 0x180240690
// Size: 134 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.180240690(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802406aa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802406c7;
    iVar1 = fcn.1802afe20(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                          *(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)((int64_t)&arg_58h + iVar2), 
                          *(int64_t *)(&stack0x00000070 + iVar2));
    if (-1 < iVar1) {
        *(undefined8 *)((int64_t)&var_18h + iVar2) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)(*(int64_t *)((int64_t)&arg_28h + iVar2) + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802406f1;
        uVar3 = fcn.18023fc40(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                              *(int64_t *)((int64_t)&arg_58h + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802406fe;
    fcn.180226310(*(undefined8 *)((int64_t)&arg_28h + iVar2));
    return uVar3;
}

// ============================================================
// Function: FUN_180240720
// Address: 0x180240720
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180240720(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_70h, int64_t arg_b0h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar6;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180240730;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024073e;
    uVar4 = fcn.18028ec30();
    uVar6 = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -0x10) = 0x1802afcee;
    iVar5 = fcn.18045a350(uVar4, in_RCX, in_RDX);
    iVar5 = -iVar5;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar3) = 0;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&arg_58h + iVar5 + iVar3) = uVar6;
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x1802afd18;
        iVar2 = fcn.1802afe20(*(int64_t *)(&stack0x00000050 + iVar5 + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar3), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar5 + iVar3));
        iVar1 = *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar3);
        if (-1 < iVar2) {
            *(undefined8 *)((int64_t)&arg_70h + iVar5 + iVar3) = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&arg_30h + iVar5 + iVar3) = 0;
            *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar3) = 0;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x1802afd47;
            uVar4 = fcn.180261850(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x000000c0 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x000000c8 + iVar5 + iVar3));
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x1802afd52;
        fcn.180226310(iVar1);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180240760
// Address: 0x180240760
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180240760(int64_t arg_28h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar6;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180240770;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024077e;
    uVar4 = fcn.18021ff00();
    uVar6 = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -0x10) = 0x1802afcee;
    iVar5 = fcn.18045a350(uVar4, in_RCX, in_RDX);
    iVar5 = -iVar5;
    uVar4 = 0;
    *(undefined8 *)(&stack0x00000060 + iVar5 + iVar3) = 0;
    if (in_RCX != 0) {
        *(undefined8 *)(&stack0x00000058 + iVar5 + iVar3) = uVar6;
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x1802afd18;
        iVar2 = fcn.1802afe20(*(int64_t *)(&stack0x00000050 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000058 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar5 + iVar3));
        iVar1 = *(int64_t *)(&stack0x00000060 + iVar5 + iVar3);
        if (-1 < iVar2) {
            *(undefined8 *)(&stack0x00000070 + iVar5 + iVar3) = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)(&stack0x00000030 + iVar5 + iVar3) = 0;
            *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar3) = 0;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x1802afd47;
            uVar4 = fcn.180261850(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x00000070 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x000000c0 + iVar5 + iVar3), 
                                  *(int64_t *)(&stack0x000000c8 + iVar5 + iVar3));
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x1802afd52;
        fcn.180226310(iVar1);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1802407a0
// Address: 0x1802407a0
// Size: 35 bytes
// ============================================================
undefined8 fcn.1802407a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    code *pcVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t iStack_8;
    
    iStack_8 = 0x1802407aa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar6 = (code *)0x1802af1c0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000020 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar3) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar3) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar3 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&iStack_8 + iVar3) = 0x1802b01ec;
    iVar4 = fcn.18045a350(0x1802af1c0, in_RCX, in_RDX);
    iVar4 = -iVar4;
    iVar7 = 0;
    uVar8 = 1;
    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0208;
    iVar1 = (*pcVar6)(in_RDX, 0);
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0224;
        iVar5 = fcn.1802248d0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3) = iVar5;
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b023c;
            (*pcVar6)(in_RDX, (int64_t)&arg_50h + iVar4 + iVar3);
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b024a;
            iVar2 = func_0x00018021b2c0(in_RCX, iVar5, iVar1);
            if (iVar2 != iVar1) {
                do {
                    if (iVar2 < 1) {
                        uVar8 = 0;
                        break;
                    }
                    iVar7 = iVar7 + iVar2;
                    iVar1 = iVar1 - iVar2;
                    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0269;
                    iVar2 = func_0x00018021b2c0(in_RCX, iVar7 + iVar5, iVar1);
                } while (iVar2 != iVar1);
            }
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0287;
            fcn.180224990(iVar5, 0x1804f2950, 0x3e);
            return uVar8;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802407d0
// Address: 0x1802407d0
// Size: 35 bytes
// ============================================================
undefined8 fcn.1802407d0(undefined8 param_1, undefined8 param_2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t iStack_8;
    
    iStack_8 = 0x1802407da;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar6 = (code *)0x1802b2c40;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000020 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar3) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar3) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar3 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&iStack_8 + iVar3) = 0x1802b01ec;
    iVar4 = fcn.18045a350(0x1802b2c40, param_1, param_2);
    iVar4 = -iVar4;
    iVar7 = 0;
    uVar8 = 1;
    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0208;
    iVar1 = (*pcVar6)(param_2, 0);
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0224;
        iVar5 = fcn.1802248d0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
        if (iVar5 != 0) {
            *(int64_t *)(&stack0x00000050 + iVar4 + iVar3) = iVar5;
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b023c;
            (*pcVar6)(param_2, &stack0x00000050 + iVar4 + iVar3);
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b024a;
            iVar2 = func_0x00018021b2c0(param_1, iVar5, iVar1);
            if (iVar2 != iVar1) {
                do {
                    if (iVar2 < 1) {
                        uVar8 = 0;
                        break;
                    }
                    iVar7 = iVar7 + iVar2;
                    iVar1 = iVar1 - iVar2;
                    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0269;
                    iVar2 = func_0x00018021b2c0(param_1, iVar7 + iVar5, iVar1);
                } while (iVar2 != iVar1);
            }
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0287;
            fcn.180224990(iVar5, 0x1804f2950, 0x3e);
            return uVar8;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180240800
// Address: 0x180240800
// Size: 35 bytes
// ============================================================
undefined8 fcn.180240800(undefined8 param_1, undefined8 param_2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t iStack_8;
    
    iStack_8 = 0x18024080a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar6 = (code *)0x180236470;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000020 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar3) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar3) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar3 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&iStack_8 + iVar3) = 0x1802b01ec;
    iVar4 = fcn.18045a350(0x180236470, param_1, param_2);
    iVar4 = -iVar4;
    iVar7 = 0;
    uVar8 = 1;
    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0208;
    iVar1 = (*pcVar6)(param_2, 0);
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0224;
        iVar5 = fcn.1802248d0(*(int64_t *)(&stack0x00000020 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar4 + iVar3));
        if (iVar5 != 0) {
            *(int64_t *)(&stack0x00000050 + iVar4 + iVar3) = iVar5;
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b023c;
            (*pcVar6)(param_2, &stack0x00000050 + iVar4 + iVar3);
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b024a;
            iVar2 = func_0x00018021b2c0(param_1, iVar5, iVar1);
            if (iVar2 != iVar1) {
                do {
                    if (iVar2 < 1) {
                        uVar8 = 0;
                        break;
                    }
                    iVar7 = iVar7 + iVar2;
                    iVar1 = iVar1 - iVar2;
                    *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0269;
                    iVar2 = func_0x00018021b2c0(param_1, iVar7 + iVar5, iVar1);
                } while (iVar2 != iVar1);
            }
            *(undefined8 *)((int64_t)&iStack_8 + iVar4 + iVar3) = 0x1802b0287;
            fcn.180224990(iVar5, 0x1804f2950, 0x3e);
            return uVar8;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180240830
// Address: 0x180240830
// Size: 104 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel

void fcn.180240830(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h)
{
    int64_t iVar1;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024083a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_50h + iVar1) = *(undefined8 *)((int64_t)&arg_b0h + iVar1);
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
    *(undefined4 *)((int64_t)&arg_40h + iVar1) = *(undefined4 *)((int64_t)&arg_a0h + iVar1);
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_98h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_90h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180240893;
    fcn.180240920(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)((int64_t)&arg_50h + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802408a0
// Address: 0x1802408a0
// Size: 115 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel

void fcn.1802408a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802408aa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_50h + iVar1) = *(undefined8 *)((int64_t)&arg_b8h + iVar1);
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = *(undefined8 *)((int64_t)&arg_b0h + iVar1);
    *(undefined4 *)((int64_t)&arg_40h + iVar1) = *(undefined4 *)((int64_t)&arg_a8h + iVar1);
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_a0h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_98h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_90h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024090e;
    fcn.180240920(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)((int64_t)&arg_50h + iVar1));
    return;
}

// ============================================================
// Function: FUN_180240920
// Address: 0x180240920
// Size: 1425 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel

void fcn.180240920(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h)
{
    undefined uVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    code *in_RCX;
    code *in_RDX;
    int64_t iVar10;
    undefined2 *puVar11;
    int32_t iVar12;
    int64_t iVar13;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t *piVar14;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_4b0h;
    int64_t var_498h;
    int64_t var_458h;
    int64_t var_58h;
    undefined8 uStack_48;
    
    uStack_48 = 0x18024093f;
    iVar6 = fcn.18045a350();
    piVar14 = (int64_t *)arg_40h;
    iVar2 = arg_38h;
    iVar9 = arg_30h;
    iVar6 = -iVar6;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar6);
    iVar10 = 0;
    iVar13 = 0;
    var_4b8h = arg_28h;
    var_4c8h = arg_50h;
    *(int64_t *)((int64_t)&arg_28h + iVar6) = arg_58h;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = in_R8;
    *(code **)((int64_t)&arg_38h + iVar6) = in_RDX;
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
    var_4c0h = in_R9;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_4h + iVar6 + 4) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (iVar2 == 0) {
code_r0x000180240a59:
        if (in_RCX == (code *)0x0) {
            if (in_RDX == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240a68;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), 
                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240a80;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), 
                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240a92;
                fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar6));
                *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
                goto code_r0x000180240e3e;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240aa3;
            iVar3 = (*in_RDX)(iVar9, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240aac;
            iVar3 = (*in_RCX)(iVar9, 0);
        }
        *(int32_t *)((int64_t)&var_4h + iVar6) = iVar3;
        if (iVar3 < 1) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240ab9;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), *(int64_t *)(&stack0xffffffffffffffe8 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240ad1;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), *(int64_t *)(&stack0xffffffffffffffe8 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240ae3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar6));
            *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240b02;
            iVar7 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
            *(int64_t *)((int64_t)&var_10h + iVar6) = iVar7;
            if (iVar7 != 0) {
                *(int64_t *)((int64_t)&var_20h + iVar6) = iVar7;
                if (in_RCX == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240b2d;
                    iVar3 = (*in_RDX)(iVar9, (int64_t)&var_20h + iVar6, *(undefined8 *)((int64_t)&var_18h + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240b24;
                    iVar3 = (*in_RCX)();
                }
                *(int32_t *)(&stack0x00000000 + iVar6) = iVar3;
                if (iVar2 == 0) {
                    iVar9 = *(int64_t *)((int64_t)&var_10h + iVar6);
                    var_458h._0_1_ = 0;
                    iVar13 = iVar10;
                } else {
                    iVar3 = (int32_t)arg_48h;
                    if (piVar14 == (int64_t *)0x0) {
                        if (var_4c8h == 0) {
                            iVar9 = *(int64_t *)((int64_t)&arg_28h + iVar6);
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240b93;
                                iVar7 = func_0x0001802b38a0();
                                *(undefined4 *)(&stack0xffffffffffffffe0 + iVar6) = 1;
                                iVar9 = 0x1804e3ea0;
                                if (iVar7 != 0) {
                                    iVar9 = iVar7;
                                }
                                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240bbc;
                                iVar3 = func_0x0001802b38c0(&var_458h, 4, 0x400, iVar9);
                                if (iVar3 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c0d;
                                    iVar3 = fcn.180498cd0(&var_458h);
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240bc5;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240bdd;
                                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240bef;
                                    fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar6));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240bfd;
                                    fcn.1804986e0(&var_458h, 0, 0x400);
                                    iVar3 = -1;
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240b68;
                                iVar3 = fcn.180498cd0(iVar9);
                                if (0x400 < iVar3) {
                                    iVar3 = 0x400;
                                }
                                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240b84;
                                fcn.180498030(&var_458h, iVar9, (int64_t)iVar3);
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c24;
                            iVar3 = (*(code *)var_4c8h)(&var_458h, 0x400, 1, *(undefined8 *)((int64_t)&arg_28h + iVar6))
                            ;
                        }
                        if (iVar3 < 1) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c2f;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c47;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c59;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar6));
                            goto code_r0x000180240e3e;
                        }
                        piVar14 = &var_458h;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c77;
                    uVar4 = func_0x00018020ef90(iVar2);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c82;
                    iVar5 = func_0x00018021b830(&var_4b0h, uVar4);
                    if (iVar5 < 1) goto code_r0x000180240e3e;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240c8f;
                    uVar8 = func_0x00018021daa0();
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
                    *(int64_t **)(&stack0xfffffffffffffff0 + iVar6) = &var_498h;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 1;
                    *(int32_t *)(&stack0xffffffffffffffe0 + iVar6) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240cb8;
                    iVar3 = func_0x0001802b3600(iVar2, uVar8, &var_4b0h, piVar14);
                    if (iVar3 == 0) goto code_r0x000180240e3e;
                    if (piVar14 == &var_458h) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240cd5;
                        func_0x000180244fc0(&var_458h, 0x400);
                    }
                    var_458h._0_1_ = 0;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240ce2;
                    iVar9 = fcn.180498cd0(&var_458h);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240d06;
                    func_0x000180245f70((int64_t)&var_458h + iVar9, (int64_t)&var_58h - ((int64_t)&var_458h + iVar9), 
                                        0x1804e3ef8, 0x1804e3ee8);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240d0e;
                    iVar3 = func_0x00018020ef90(iVar2);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240d1a;
                    iVar9 = fcn.180498cd0(&var_458h);
                    iVar9 = (int64_t)&var_458h + iVar9;
                    iVar12 = (int32_t)&var_58h - (int32_t)iVar9;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240d41;
                    iVar5 = func_0x000180245f70(iVar9, (int64_t)iVar12, 0x1804e3f10, 
                                                *(undefined8 *)((int64_t)&arg_30h + iVar6));
                    if (0 < iVar5) {
                        iVar12 = iVar12 - iVar5;
                        puVar11 = (undefined2 *)(iVar9 + iVar5);
                        if (0 < iVar3) {
                            do {
                                uVar1 = *(undefined *)((int64_t)&var_4b0h + iVar10);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240d78;
                                iVar5 = func_0x000180245f70(puVar11, (int64_t)iVar12, 0x1804e2b4c, uVar1);
                                if (iVar5 < 1) goto code_r0x000180240d95;
                                iVar12 = iVar12 - iVar5;
                                iVar10 = iVar10 + 1;
                                puVar11 = (undefined2 *)((int64_t)puVar11 + (int64_t)iVar5);
                            } while (iVar10 < iVar3);
                        }
                        if (1 < iVar12) {
                            *puVar11 = 10;
                        }
                    }
code_r0x000180240d95:
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240d9a;
                    iVar13 = func_0x000180211490();
                    if (iVar13 == 0) goto code_r0x000180240e3e;
                    *(int64_t **)(&stack0xffffffffffffffe0 + iVar6) = &var_4b0h;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240dc1;
                    iVar3 = func_0x0001802128b0(iVar13, iVar2, 0, &var_498h);
                    if (iVar3 == 0) goto code_r0x000180240e3e;
                    iVar9 = *(int64_t *)((int64_t)&var_10h + iVar6);
                    *(undefined4 *)(&stack0xffffffffffffffe0 + iVar6) = *(undefined4 *)(&stack0x00000000 + iVar6);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240de5;
                    iVar3 = func_0x000180212930(iVar13, iVar9, (int64_t)&var_4h + iVar6 + 4, iVar9);
                    if (iVar3 == 0) goto code_r0x000180240e3e;
                    iVar3 = *(int32_t *)((int64_t)&var_4h + iVar6 + 4);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240dfe;
                    iVar3 = func_0x000180212650(iVar13, iVar3 + iVar9, (int64_t)&stack0x00000000 + iVar6);
                    if (iVar3 == 0) goto code_r0x000180240e3e;
                    iVar3 = *(int32_t *)(&stack0x00000000 + iVar6) + *(int32_t *)((int64_t)&var_4h + iVar6 + 4);
                    *(int32_t *)(&stack0x00000000 + iVar6) = iVar3;
                }
                *(int32_t *)(&stack0xffffffffffffffe0 + iVar6) = iVar3;
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240e31;
                uVar4 = func_0x000180241b00(var_4b8h, var_4c0h, &var_458h, iVar9);
                *(undefined4 *)(&stack0x00000000 + iVar6) = uVar4;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802409ce;
        iVar7 = func_0x00018020ee90(iVar2);
        *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar7;
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802409e3;
            iVar3 = func_0x00018020ef90(iVar2);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802409ef;
                iVar3 = func_0x00018020ef90(iVar2);
                if (iVar3 < 0x11) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x1802409fc;
                    iVar7 = fcn.180498cd0(iVar7);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240a07;
                    iVar3 = func_0x00018020ef90(iVar2);
                    if ((uint64_t)(iVar7 + 0x24 + (int64_t)(iVar3 * 2)) < 0x401) {
                        in_RDX = *(code **)((int64_t)&arg_38h + iVar6);
                        goto code_r0x000180240a59;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240a20;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), *(int64_t *)(&stack0xffffffffffffffe8 + iVar6));
        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240a38;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar6), *(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240a4a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar6));
        iVar13 = iVar10;
    }
code_r0x000180240e3e:
    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240e4c;
    func_0x000180244fc0(&var_498h, 0x40);
    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240e5a;
    func_0x000180244fc0(&var_4b0h, 0x10);
    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240e62;
    func_0x000180211410(iVar13);
    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240e70;
    func_0x000180244fc0(&var_458h, 0x400);
    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240e8b;
    func_0x000180224b90(*(undefined8 *)((int64_t)&var_10h + iVar6), *(undefined4 *)((int64_t)&var_4h + iVar6), 
                        0x1804e3ed0, 0x1a7);
    *(undefined8 *)((int64_t)&uStack_48 + iVar6) = 0x180240e9d;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180240ec0
// Address: 0x180240ec0
// Size: 64 bytes
// ============================================================
void fcn.180240ec0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180240eca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_38h + iVar1) = 2;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_78h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180240efb;
    fcn.180242550(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1));
    return;
}

// ============================================================
// Function: FUN_180240f00
// Address: 0x180240f00
// Size: 64 bytes
// ============================================================
void fcn.180240f00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180240f0a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_38h + iVar1) = 3;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_78h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180240f3b;
    fcn.180242550(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1));
    return;
}

// ============================================================
// Function: FUN_180240f40
// Address: 0x180240f40
// Size: 222 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180240f40(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int32_t in_R8D;
    int64_t in_R9;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180240f5a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_R9 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240f94;
        iVar4 = func_0x0001802b38a0();
        *(int32_t *)((int64_t)&iStackX_20 + iVar3 + -8) = in_R8D;
        iVar6 = 0x1804e3ea0;
        if (iVar4 != 0) {
            iVar6 = iVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240fba;
        iVar2 = func_0x0001802b38c0(in_RCX, -(in_R8D != 0) & 4, in_RDX & 0xffffffff, iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241009;
            uVar5 = fcn.180498cd0(in_RCX);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240fc3;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240fdb;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240fed;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240ffa;
            fcn.1804986e0(in_RCX, 0, in_RDX & 0xffffffff);
            uVar5 = 0xffffffff;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240f75;
        uVar1 = fcn.180498cd0(in_R9);
        if ((int32_t)(uint32_t)in_RDX < (int32_t)uVar1) {
            uVar1 = (uint32_t)in_RDX;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180240f8b;
        fcn.180498030(in_RCX, in_R9, (int64_t)(int32_t)uVar1);
        uVar5 = (uint64_t)uVar1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180241020
// Address: 0x180241020
// Size: 81 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel

void fcn.180241020(int64_t arg_30h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *in_R8;
    code *in_R9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180241031;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000470 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2);
    iVar3 = *in_RCX;
    iVar5 = *(int64_t *)(&stack0x000004e0 + iVar2);
    *(int32_t *)((int64_t)&var_20h + iVar2) = *in_R8;
    if (iVar3 == 0) goto code_r0x0001802412da;
    *(undefined8 *)(&stack0x00000490 + iVar2) = unaff_RSI;
    *(undefined8 *)(&stack0x00000488 + iVar2) = unaff_RDI;
    if (in_R9 == (code *)0x0) {
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410c1;
            iVar3 = func_0x0001802b38a0();
            *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
            iVar5 = 0x1804e3ea0;
            if (iVar3 != 0) {
                iVar5 = iVar3;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410ee;
            iVar1 = func_0x0001802b38c0((int64_t)&arg_70h + iVar2, 0, 0x400, iVar5);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241147;
                iVar1 = fcn.180498cd0((int64_t)&arg_70h + iVar2);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410f7;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024110f;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                              *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241121;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241133;
                fcn.1804986e0((int64_t)&arg_70h + iVar2, 0, 0x400);
                iVar1 = -1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241097;
            iVar1 = fcn.180498cd0(iVar5);
            if (0x400 < iVar1) {
                iVar1 = 0x400;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410b7;
            fcn.180498030((int64_t)&arg_70h + iVar2, iVar5, (int64_t)iVar1);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241161;
        iVar1 = (*in_R9)((int64_t)&arg_70h + iVar2, 0x400, 0, iVar5);
    }
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024116c;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241184;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
        goto code_r0x0001802412da;
    }
    iVar5 = *in_RCX;
    *(undefined8 *)(&stack0x00000480 + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411b1;
    uVar4 = func_0x00018021daa0();
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    *(int64_t *)((int64_t)&var_10h + iVar2) = (int64_t)&arg_30h + iVar2;
    *(undefined4 *)((int64_t)&var_8h + iVar2) = 1;
    *(int32_t *)(&stack0x00000000 + iVar2) = iVar1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411e6;
    iVar1 = func_0x0001802b3600(iVar5, uVar4, in_RCX + 1, (int64_t)&arg_70h + iVar2);
    if (iVar1 == 0) goto code_r0x0001802412da;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411f3;
    iVar5 = func_0x000180211490();
    if (iVar5 == 0) goto code_r0x0001802412da;
    iVar3 = *in_RCX;
    *(int64_t **)(&stack0x00000000 + iVar2) = in_RCX + 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241217;
    iVar1 = func_0x000180212170(iVar5, iVar3, 0, (int64_t)&arg_30h + iVar2);
    if (iVar1 == 0) {
code_r0x000180241266:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024126b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241283;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241295;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    } else {
        *(undefined4 *)(&stack0x00000000 + iVar2) = *(undefined4 *)((int64_t)&var_20h + iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241238;
        iVar1 = func_0x0001802121a0(iVar5, in_RDX, (int64_t)&var_20h + iVar2, in_RDX);
        if (iVar1 == 0) goto code_r0x000180241266;
        iVar1 = *(int32_t *)((int64_t)&var_20h + iVar2);
        *in_R8 = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241257;
        iVar1 = func_0x000180211e00(iVar5, iVar1 + in_RDX, (int64_t)&var_20h + iVar2);
        if (iVar1 == 0) goto code_r0x000180241266;
        *in_R8 = *in_R8 + *(int32_t *)((int64_t)&var_20h + iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024129d;
    func_0x000180211410(iVar5);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ad;
    func_0x000180244fc0((int64_t)&arg_70h + iVar2, 0x400);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412bc;
    func_0x000180244fc0((int64_t)&arg_30h + iVar2, 0x40);
code_r0x0001802412da:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ea;
    func_0x000180459870(*(uint64_t *)(&stack0x00000470 + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180241071
// Address: 0x180241071
// Size: 303 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel

void fcn.180241020(int64_t arg_30h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *in_R8;
    code *in_R9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180241031;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000470 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2);
    iVar3 = *in_RCX;
    iVar5 = *(int64_t *)(&stack0x000004e0 + iVar2);
    *(int32_t *)((int64_t)&var_20h + iVar2) = *in_R8;
    if (iVar3 == 0) goto code_r0x0001802412da;
    *(undefined8 *)(&stack0x00000490 + iVar2) = unaff_RSI;
    *(undefined8 *)(&stack0x00000488 + iVar2) = unaff_RDI;
    if (in_R9 == (code *)0x0) {
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410c1;
            iVar3 = func_0x0001802b38a0();
            *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
            iVar5 = 0x1804e3ea0;
            if (iVar3 != 0) {
                iVar5 = iVar3;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410ee;
            iVar1 = func_0x0001802b38c0((int64_t)&arg_70h + iVar2, 0, 0x400, iVar5);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241147;
                iVar1 = fcn.180498cd0((int64_t)&arg_70h + iVar2);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410f7;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024110f;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                              *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241121;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241133;
                fcn.1804986e0((int64_t)&arg_70h + iVar2, 0, 0x400);
                iVar1 = -1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241097;
            iVar1 = fcn.180498cd0(iVar5);
            if (0x400 < iVar1) {
                iVar1 = 0x400;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410b7;
            fcn.180498030((int64_t)&arg_70h + iVar2, iVar5, (int64_t)iVar1);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241161;
        iVar1 = (*in_R9)((int64_t)&arg_70h + iVar2, 0x400, 0, iVar5);
    }
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024116c;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241184;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
        goto code_r0x0001802412da;
    }
    iVar5 = *in_RCX;
    *(undefined8 *)(&stack0x00000480 + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411b1;
    uVar4 = func_0x00018021daa0();
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    *(int64_t *)((int64_t)&var_10h + iVar2) = (int64_t)&arg_30h + iVar2;
    *(undefined4 *)((int64_t)&var_8h + iVar2) = 1;
    *(int32_t *)(&stack0x00000000 + iVar2) = iVar1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411e6;
    iVar1 = func_0x0001802b3600(iVar5, uVar4, in_RCX + 1, (int64_t)&arg_70h + iVar2);
    if (iVar1 == 0) goto code_r0x0001802412da;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411f3;
    iVar5 = func_0x000180211490();
    if (iVar5 == 0) goto code_r0x0001802412da;
    iVar3 = *in_RCX;
    *(int64_t **)(&stack0x00000000 + iVar2) = in_RCX + 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241217;
    iVar1 = func_0x000180212170(iVar5, iVar3, 0, (int64_t)&arg_30h + iVar2);
    if (iVar1 == 0) {
code_r0x000180241266:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024126b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241283;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241295;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    } else {
        *(undefined4 *)(&stack0x00000000 + iVar2) = *(undefined4 *)((int64_t)&var_20h + iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241238;
        iVar1 = func_0x0001802121a0(iVar5, in_RDX, (int64_t)&var_20h + iVar2, in_RDX);
        if (iVar1 == 0) goto code_r0x000180241266;
        iVar1 = *(int32_t *)((int64_t)&var_20h + iVar2);
        *in_R8 = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241257;
        iVar1 = func_0x000180211e00(iVar5, iVar1 + in_RDX, (int64_t)&var_20h + iVar2);
        if (iVar1 == 0) goto code_r0x000180241266;
        *in_R8 = *in_R8 + *(int32_t *)((int64_t)&var_20h + iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024129d;
    func_0x000180211410(iVar5);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ad;
    func_0x000180244fc0((int64_t)&arg_70h + iVar2, 0x400);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412bc;
    func_0x000180244fc0((int64_t)&arg_30h + iVar2, 0x40);
code_r0x0001802412da:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ea;
    func_0x000180459870(*(uint64_t *)(&stack0x00000470 + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802411a0
// Address: 0x1802411a0
// Size: 298 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel

void fcn.180241020(int64_t arg_30h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *in_R8;
    code *in_R9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180241031;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000470 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2);
    iVar3 = *in_RCX;
    iVar5 = *(int64_t *)(&stack0x000004e0 + iVar2);
    *(int32_t *)((int64_t)&var_20h + iVar2) = *in_R8;
    if (iVar3 == 0) goto code_r0x0001802412da;
    *(undefined8 *)(&stack0x00000490 + iVar2) = unaff_RSI;
    *(undefined8 *)(&stack0x00000488 + iVar2) = unaff_RDI;
    if (in_R9 == (code *)0x0) {
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410c1;
            iVar3 = func_0x0001802b38a0();
            *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
            iVar5 = 0x1804e3ea0;
            if (iVar3 != 0) {
                iVar5 = iVar3;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410ee;
            iVar1 = func_0x0001802b38c0((int64_t)&arg_70h + iVar2, 0, 0x400, iVar5);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241147;
                iVar1 = fcn.180498cd0((int64_t)&arg_70h + iVar2);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410f7;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024110f;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                              *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241121;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241133;
                fcn.1804986e0((int64_t)&arg_70h + iVar2, 0, 0x400);
                iVar1 = -1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241097;
            iVar1 = fcn.180498cd0(iVar5);
            if (0x400 < iVar1) {
                iVar1 = 0x400;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410b7;
            fcn.180498030((int64_t)&arg_70h + iVar2, iVar5, (int64_t)iVar1);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241161;
        iVar1 = (*in_R9)((int64_t)&arg_70h + iVar2, 0x400, 0, iVar5);
    }
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024116c;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241184;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
        goto code_r0x0001802412da;
    }
    iVar5 = *in_RCX;
    *(undefined8 *)(&stack0x00000480 + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411b1;
    uVar4 = func_0x00018021daa0();
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    *(int64_t *)((int64_t)&var_10h + iVar2) = (int64_t)&arg_30h + iVar2;
    *(undefined4 *)((int64_t)&var_8h + iVar2) = 1;
    *(int32_t *)(&stack0x00000000 + iVar2) = iVar1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411e6;
    iVar1 = func_0x0001802b3600(iVar5, uVar4, in_RCX + 1, (int64_t)&arg_70h + iVar2);
    if (iVar1 == 0) goto code_r0x0001802412da;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411f3;
    iVar5 = func_0x000180211490();
    if (iVar5 == 0) goto code_r0x0001802412da;
    iVar3 = *in_RCX;
    *(int64_t **)(&stack0x00000000 + iVar2) = in_RCX + 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241217;
    iVar1 = func_0x000180212170(iVar5, iVar3, 0, (int64_t)&arg_30h + iVar2);
    if (iVar1 == 0) {
code_r0x000180241266:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024126b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241283;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241295;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    } else {
        *(undefined4 *)(&stack0x00000000 + iVar2) = *(undefined4 *)((int64_t)&var_20h + iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241238;
        iVar1 = func_0x0001802121a0(iVar5, in_RDX, (int64_t)&var_20h + iVar2, in_RDX);
        if (iVar1 == 0) goto code_r0x000180241266;
        iVar1 = *(int32_t *)((int64_t)&var_20h + iVar2);
        *in_R8 = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241257;
        iVar1 = func_0x000180211e00(iVar5, iVar1 + in_RDX, (int64_t)&var_20h + iVar2);
        if (iVar1 == 0) goto code_r0x000180241266;
        *in_R8 = *in_R8 + *(int32_t *)((int64_t)&var_20h + iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024129d;
    func_0x000180211410(iVar5);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ad;
    func_0x000180244fc0((int64_t)&arg_70h + iVar2, 0x400);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412bc;
    func_0x000180244fc0((int64_t)&arg_30h + iVar2, 0x40);
code_r0x0001802412da:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ea;
    func_0x000180459870(*(uint64_t *)(&stack0x00000470 + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802412ca
// Address: 0x1802412ca
// Size: 16 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel

void fcn.180241020(int64_t arg_30h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *in_R8;
    code *in_R9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180241031;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000470 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2);
    iVar3 = *in_RCX;
    iVar5 = *(int64_t *)(&stack0x000004e0 + iVar2);
    *(int32_t *)((int64_t)&var_20h + iVar2) = *in_R8;
    if (iVar3 == 0) goto code_r0x0001802412da;
    *(undefined8 *)(&stack0x00000490 + iVar2) = unaff_RSI;
    *(undefined8 *)(&stack0x00000488 + iVar2) = unaff_RDI;
    if (in_R9 == (code *)0x0) {
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410c1;
            iVar3 = func_0x0001802b38a0();
            *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
            iVar5 = 0x1804e3ea0;
            if (iVar3 != 0) {
                iVar5 = iVar3;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410ee;
            iVar1 = func_0x0001802b38c0((int64_t)&arg_70h + iVar2, 0, 0x400, iVar5);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241147;
                iVar1 = fcn.180498cd0((int64_t)&arg_70h + iVar2);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410f7;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024110f;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                              *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241121;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241133;
                fcn.1804986e0((int64_t)&arg_70h + iVar2, 0, 0x400);
                iVar1 = -1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241097;
            iVar1 = fcn.180498cd0(iVar5);
            if (0x400 < iVar1) {
                iVar1 = 0x400;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410b7;
            fcn.180498030((int64_t)&arg_70h + iVar2, iVar5, (int64_t)iVar1);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241161;
        iVar1 = (*in_R9)((int64_t)&arg_70h + iVar2, 0x400, 0, iVar5);
    }
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024116c;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241184;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
        goto code_r0x0001802412da;
    }
    iVar5 = *in_RCX;
    *(undefined8 *)(&stack0x00000480 + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411b1;
    uVar4 = func_0x00018021daa0();
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    *(int64_t *)((int64_t)&var_10h + iVar2) = (int64_t)&arg_30h + iVar2;
    *(undefined4 *)((int64_t)&var_8h + iVar2) = 1;
    *(int32_t *)(&stack0x00000000 + iVar2) = iVar1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411e6;
    iVar1 = func_0x0001802b3600(iVar5, uVar4, in_RCX + 1, (int64_t)&arg_70h + iVar2);
    if (iVar1 == 0) goto code_r0x0001802412da;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411f3;
    iVar5 = func_0x000180211490();
    if (iVar5 == 0) goto code_r0x0001802412da;
    iVar3 = *in_RCX;
    *(int64_t **)(&stack0x00000000 + iVar2) = in_RCX + 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241217;
    iVar1 = func_0x000180212170(iVar5, iVar3, 0, (int64_t)&arg_30h + iVar2);
    if (iVar1 == 0) {
code_r0x000180241266:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024126b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241283;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241295;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    } else {
        *(undefined4 *)(&stack0x00000000 + iVar2) = *(undefined4 *)((int64_t)&var_20h + iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241238;
        iVar1 = func_0x0001802121a0(iVar5, in_RDX, (int64_t)&var_20h + iVar2, in_RDX);
        if (iVar1 == 0) goto code_r0x000180241266;
        iVar1 = *(int32_t *)((int64_t)&var_20h + iVar2);
        *in_R8 = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241257;
        iVar1 = func_0x000180211e00(iVar5, iVar1 + in_RDX, (int64_t)&var_20h + iVar2);
        if (iVar1 == 0) goto code_r0x000180241266;
        *in_R8 = *in_R8 + *(int32_t *)((int64_t)&var_20h + iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024129d;
    func_0x000180211410(iVar5);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ad;
    func_0x000180244fc0((int64_t)&arg_70h + iVar2, 0x400);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412bc;
    func_0x000180244fc0((int64_t)&arg_30h + iVar2, 0x40);
code_r0x0001802412da:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ea;
    func_0x000180459870(*(uint64_t *)(&stack0x00000470 + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802412da
// Address: 0x1802412da
// Size: 30 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel

void fcn.180241020(int64_t arg_30h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *in_R8;
    code *in_R9;
    undefined8 unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180241031;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000470 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2);
    iVar3 = *in_RCX;
    iVar5 = *(int64_t *)(&stack0x000004e0 + iVar2);
    *(int32_t *)((int64_t)&var_20h + iVar2) = *in_R8;
    if (iVar3 == 0) goto code_r0x0001802412da;
    *(undefined8 *)(&stack0x00000490 + iVar2) = unaff_RSI;
    *(undefined8 *)(&stack0x00000488 + iVar2) = unaff_RDI;
    if (in_R9 == (code *)0x0) {
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410c1;
            iVar3 = func_0x0001802b38a0();
            *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
            iVar5 = 0x1804e3ea0;
            if (iVar3 != 0) {
                iVar5 = iVar3;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410ee;
            iVar1 = func_0x0001802b38c0((int64_t)&arg_70h + iVar2, 0, 0x400, iVar5);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241147;
                iVar1 = fcn.180498cd0((int64_t)&arg_70h + iVar2);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410f7;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024110f;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                              *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241121;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241133;
                fcn.1804986e0((int64_t)&arg_70h + iVar2, 0, 0x400);
                iVar1 = -1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241097;
            iVar1 = fcn.180498cd0(iVar5);
            if (0x400 < iVar1) {
                iVar1 = 0x400;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802410b7;
            fcn.180498030((int64_t)&arg_70h + iVar2, iVar5, (int64_t)iVar1);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241161;
        iVar1 = (*in_R9)((int64_t)&arg_70h + iVar2, 0x400, 0, iVar5);
    }
    if (iVar1 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024116c;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241184;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
        goto code_r0x0001802412da;
    }
    iVar5 = *in_RCX;
    *(undefined8 *)(&stack0x00000480 + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411b1;
    uVar4 = func_0x00018021daa0();
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    *(int64_t *)((int64_t)&var_10h + iVar2) = (int64_t)&arg_30h + iVar2;
    *(undefined4 *)((int64_t)&var_8h + iVar2) = 1;
    *(int32_t *)(&stack0x00000000 + iVar2) = iVar1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411e6;
    iVar1 = func_0x0001802b3600(iVar5, uVar4, in_RCX + 1, (int64_t)&arg_70h + iVar2);
    if (iVar1 == 0) goto code_r0x0001802412da;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802411f3;
    iVar5 = func_0x000180211490();
    if (iVar5 == 0) goto code_r0x0001802412da;
    iVar3 = *in_RCX;
    *(int64_t **)(&stack0x00000000 + iVar2) = in_RCX + 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241217;
    iVar1 = func_0x000180212170(iVar5, iVar3, 0, (int64_t)&arg_30h + iVar2);
    if (iVar1 == 0) {
code_r0x000180241266:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024126b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241283;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241295;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    } else {
        *(undefined4 *)(&stack0x00000000 + iVar2) = *(undefined4 *)((int64_t)&var_20h + iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241238;
        iVar1 = func_0x0001802121a0(iVar5, in_RDX, (int64_t)&var_20h + iVar2, in_RDX);
        if (iVar1 == 0) goto code_r0x000180241266;
        iVar1 = *(int32_t *)((int64_t)&var_20h + iVar2);
        *in_R8 = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x180241257;
        iVar1 = func_0x000180211e00(iVar5, iVar1 + in_RDX, (int64_t)&var_20h + iVar2);
        if (iVar1 == 0) goto code_r0x000180241266;
        *in_R8 = *in_R8 + *(int32_t *)((int64_t)&var_20h + iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x18024129d;
    func_0x000180211410(iVar5);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ad;
    func_0x000180244fc0((int64_t)&arg_70h + iVar2, 0x400);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412bc;
    func_0x000180244fc0((int64_t)&arg_30h + iVar2, 0x40);
code_r0x0001802412da:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1802412ea;
    func_0x000180459870(*(uint64_t *)(&stack0x00000470 + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180241300
// Address: 0x180241300
// Size: 343 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180241300(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    char *in_RCX;
    int64_t *in_RDX;
    uint64_t uVar9;
    char *pcVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_RSI;
    char *pcVar14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024131f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    *in_RDX = 0;
    *(undefined (*) [16])(in_RDX + 1) = ZEXT816(0);
    if (((in_RCX == (char *)0x0) || (*in_RCX == '\0')) || (*in_RCX == '\n')) {
code_r0x0001802415c0:
        uVar8 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241362;
        iVar3 = func_0x000180498f90(0, 0x1804e4050, 10);
        if (iVar3 == 0) {
            in_RCX = in_RCX + 10;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024137d;
            iVar6 = func_0x00018046ed00(in_RCX, 0x180645718);
            if ((in_RCX[iVar6] == '4') && (pcVar10 = in_RCX + iVar6 + 2, in_RCX[iVar6 + 1] == ',')) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413aa;
                iVar6 = func_0x00018046ed00(pcVar10, 0x180645718);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413c2;
                iVar3 = func_0x000180498f90(pcVar10 + iVar6, 0x1804e3ee8, 9);
                if (iVar3 != 0) {
code_r0x000180241645:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024164a;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241662;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241674;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                pcVar10 = pcVar10 + iVar6 + 9;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413dd;
                iVar6 = func_0x00018046ed00(pcVar10, 0x1804a6100);
                if (iVar6 == 0) goto code_r0x000180241645;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413f5;
                iVar6 = func_0x00018046ed00(pcVar10, 0x1804e4078);
                if (pcVar10[iVar6] != '\n') {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241404;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024141c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024142e;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024144b;
                iVar3 = func_0x000180498f90(pcVar10 + iVar6 + 1, 0x1804e4080, 9);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241617;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024162f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241641;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024146b;
                iVar7 = func_0x00018046ed00(pcVar10 + iVar6 + 10, 0x180645718);
                pcVar14 = pcVar10 + iVar6 + 10 + iVar7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024147d;
                iVar6 = func_0x000180461e90(pcVar14, 0x1804e408c);
                cVar2 = pcVar14[iVar6];
                pcVar14[iVar6] = '\0';
                pcVar10 = pcVar14 + iVar6;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241491;
                iVar6 = func_0x00018022e080(pcVar14);
                *in_RDX = iVar6;
                *pcVar10 = cVar2;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414a8;
                iVar7 = func_0x00018046ed00(pcVar10, 0x180645718);
                pcVar10 = pcVar10 + iVar7;
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414bb;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414d3;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414e5;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414f4;
                iVar3 = func_0x00018020ef90(iVar6);
                if (iVar3 < 1) {
                    if ((iVar3 == 0) && (*pcVar10 == ',')) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241544;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024155c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                      , *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5)
                                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024156e;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                        return 0;
                    }
                } else {
                    cVar2 = *pcVar10;
                    pcVar10 = pcVar10 + 1;
                    if (cVar2 != ',') {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241507;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024151f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                      , *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5)
                                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241531;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                        return 0;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024157a;
                iVar3 = func_0x00018020ef90(iVar6);
                if (0 < iVar3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024158f;
                    fcn.1804986e0(in_RDX + 1, 0, (int64_t)iVar3);
                }
                if (0 < iVar3 * 2) {
                    do {
                        cVar2 = *pcVar10;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024159d;
                        iVar4 = func_0x000180223440(cVar2);
                        if (iVar4 < 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802415e4;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&var_10h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802415fc;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&var_10h + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024160e;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                            return 0;
                        }
                        uVar11 = (uint32_t)uVar13;
                        uVar9 = uVar13 >> 1;
                        pcVar10 = pcVar10 + 1;
                        uVar12 = uVar11 + 1;
                        uVar13 = (uint64_t)uVar12;
                        puVar1 = (uint8_t *)(uVar9 + 8 + (int64_t)in_RDX);
                        *puVar1 = *puVar1 | (char)iVar4 << (int8_t)((~uVar11 & 1) << 2);
                    } while ((int32_t)uVar12 < iVar3 * 2);
                }
                goto code_r0x0001802415c0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241680;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241698;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802416aa;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        }
        uVar8 = 0;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_180241457
// Address: 0x180241457
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180241300(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    char *in_RCX;
    int64_t *in_RDX;
    uint64_t uVar9;
    char *pcVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_RSI;
    char *pcVar14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024131f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    *in_RDX = 0;
    *(undefined (*) [16])(in_RDX + 1) = ZEXT816(0);
    if (((in_RCX == (char *)0x0) || (*in_RCX == '\0')) || (*in_RCX == '\n')) {
code_r0x0001802415c0:
        uVar8 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241362;
        iVar3 = func_0x000180498f90(0, 0x1804e4050, 10);
        if (iVar3 == 0) {
            in_RCX = in_RCX + 10;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024137d;
            iVar6 = func_0x00018046ed00(in_RCX, 0x180645718);
            if ((in_RCX[iVar6] == '4') && (pcVar10 = in_RCX + iVar6 + 2, in_RCX[iVar6 + 1] == ',')) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413aa;
                iVar6 = func_0x00018046ed00(pcVar10, 0x180645718);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413c2;
                iVar3 = func_0x000180498f90(pcVar10 + iVar6, 0x1804e3ee8, 9);
                if (iVar3 != 0) {
code_r0x000180241645:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024164a;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241662;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241674;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                pcVar10 = pcVar10 + iVar6 + 9;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413dd;
                iVar6 = func_0x00018046ed00(pcVar10, 0x1804a6100);
                if (iVar6 == 0) goto code_r0x000180241645;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413f5;
                iVar6 = func_0x00018046ed00(pcVar10, 0x1804e4078);
                if (pcVar10[iVar6] != '\n') {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241404;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024141c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024142e;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024144b;
                iVar3 = func_0x000180498f90(pcVar10 + iVar6 + 1, 0x1804e4080, 9);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241617;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024162f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241641;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024146b;
                iVar7 = func_0x00018046ed00(pcVar10 + iVar6 + 10, 0x180645718);
                pcVar14 = pcVar10 + iVar6 + 10 + iVar7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024147d;
                iVar6 = func_0x000180461e90(pcVar14, 0x1804e408c);
                cVar2 = pcVar14[iVar6];
                pcVar14[iVar6] = '\0';
                pcVar10 = pcVar14 + iVar6;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241491;
                iVar6 = func_0x00018022e080(pcVar14);
                *in_RDX = iVar6;
                *pcVar10 = cVar2;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414a8;
                iVar7 = func_0x00018046ed00(pcVar10, 0x180645718);
                pcVar10 = pcVar10 + iVar7;
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414bb;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414d3;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414e5;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414f4;
                iVar3 = func_0x00018020ef90(iVar6);
                if (iVar3 < 1) {
                    if ((iVar3 == 0) && (*pcVar10 == ',')) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241544;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024155c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                      , *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5)
                                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024156e;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                        return 0;
                    }
                } else {
                    cVar2 = *pcVar10;
                    pcVar10 = pcVar10 + 1;
                    if (cVar2 != ',') {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241507;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024151f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                      , *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5)
                                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241531;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                        return 0;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024157a;
                iVar3 = func_0x00018020ef90(iVar6);
                if (0 < iVar3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024158f;
                    fcn.1804986e0(in_RDX + 1, 0, (int64_t)iVar3);
                }
                if (0 < iVar3 * 2) {
                    do {
                        cVar2 = *pcVar10;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024159d;
                        iVar4 = func_0x000180223440(cVar2);
                        if (iVar4 < 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802415e4;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&var_10h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802415fc;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&var_10h + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024160e;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                            return 0;
                        }
                        uVar11 = (uint32_t)uVar13;
                        uVar9 = uVar13 >> 1;
                        pcVar10 = pcVar10 + 1;
                        uVar12 = uVar11 + 1;
                        uVar13 = (uint64_t)uVar12;
                        puVar1 = (uint8_t *)(uVar9 + 8 + (int64_t)in_RDX);
                        *puVar1 = *puVar1 | (char)iVar4 << (int8_t)((~uVar11 & 1) << 2);
                    } while ((int32_t)uVar12 < iVar3 * 2);
                }
                goto code_r0x0001802415c0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241680;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241698;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802416aa;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        }
        uVar8 = 0;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1802414b6
// Address: 0x1802414b6
// Size: 507 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180241300(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    char *in_RCX;
    int64_t *in_RDX;
    uint64_t uVar9;
    char *pcVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_RSI;
    char *pcVar14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024131f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    *in_RDX = 0;
    *(undefined (*) [16])(in_RDX + 1) = ZEXT816(0);
    if (((in_RCX == (char *)0x0) || (*in_RCX == '\0')) || (*in_RCX == '\n')) {
code_r0x0001802415c0:
        uVar8 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241362;
        iVar3 = func_0x000180498f90(0, 0x1804e4050, 10);
        if (iVar3 == 0) {
            in_RCX = in_RCX + 10;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024137d;
            iVar6 = func_0x00018046ed00(in_RCX, 0x180645718);
            if ((in_RCX[iVar6] == '4') && (pcVar10 = in_RCX + iVar6 + 2, in_RCX[iVar6 + 1] == ',')) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413aa;
                iVar6 = func_0x00018046ed00(pcVar10, 0x180645718);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413c2;
                iVar3 = func_0x000180498f90(pcVar10 + iVar6, 0x1804e3ee8, 9);
                if (iVar3 != 0) {
code_r0x000180241645:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024164a;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241662;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241674;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                pcVar10 = pcVar10 + iVar6 + 9;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413dd;
                iVar6 = func_0x00018046ed00(pcVar10, 0x1804a6100);
                if (iVar6 == 0) goto code_r0x000180241645;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802413f5;
                iVar6 = func_0x00018046ed00(pcVar10, 0x1804e4078);
                if (pcVar10[iVar6] != '\n') {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241404;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024141c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024142e;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024144b;
                iVar3 = func_0x000180498f90(pcVar10 + iVar6 + 1, 0x1804e4080, 9);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241617;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024162f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241641;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024146b;
                iVar7 = func_0x00018046ed00(pcVar10 + iVar6 + 10, 0x180645718);
                pcVar14 = pcVar10 + iVar6 + 10 + iVar7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024147d;
                iVar6 = func_0x000180461e90(pcVar14, 0x1804e408c);
                cVar2 = pcVar14[iVar6];
                pcVar14[iVar6] = '\0';
                pcVar10 = pcVar14 + iVar6;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241491;
                iVar6 = func_0x00018022e080(pcVar14);
                *in_RDX = iVar6;
                *pcVar10 = cVar2;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414a8;
                iVar7 = func_0x00018046ed00(pcVar10, 0x180645718);
                pcVar10 = pcVar10 + iVar7;
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414bb;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414d3;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414e5;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802414f4;
                iVar3 = func_0x00018020ef90(iVar6);
                if (iVar3 < 1) {
                    if ((iVar3 == 0) && (*pcVar10 == ',')) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241544;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024155c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                      , *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5)
                                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024156e;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                        return 0;
                    }
                } else {
                    cVar2 = *pcVar10;
                    pcVar10 = pcVar10 + 1;
                    if (cVar2 != ',') {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241507;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024151f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5)
                                      , *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5)
                                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241531;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                        return 0;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024157a;
                iVar3 = func_0x00018020ef90(iVar6);
                if (0 < iVar3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024158f;
                    fcn.1804986e0(in_RDX + 1, 0, (int64_t)iVar3);
                }
                if (0 < iVar3 * 2) {
                    do {
                        cVar2 = *pcVar10;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024159d;
                        iVar4 = func_0x000180223440(cVar2);
                        if (iVar4 < 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802415e4;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&var_10h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802415fc;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&var_10h + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024160e;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
                            return 0;
                        }
                        uVar11 = (uint32_t)uVar13;
                        uVar9 = uVar13 >> 1;
                        pcVar10 = pcVar10 + 1;
                        uVar12 = uVar11 + 1;
                        uVar13 = (uint64_t)uVar12;
                        puVar1 = (uint8_t *)(uVar9 + 8 + (int64_t)in_RDX);
                        *puVar1 = *puVar1 | (char)iVar4 << (int8_t)((~uVar11 & 1) << 2);
                    } while ((int32_t)uVar12 < iVar3 * 2);
                }
                goto code_r0x0001802415c0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241680;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180241698;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802416aa;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        }
        uVar8 = 0;
    }
    return uVar8;
}

