// Chunk 162 - 50 functions

// ============================================================
// Function: FUN_180219540
// Address: 0x180219540
// Size: 717 bytes
// ============================================================
uint64_t fcn.180219540(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint64_t **ppuVar1;
    uint64_t *puVar2;
    uint64_t *puVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    uint64_t *puVar11;
    int64_t in_RCX;
    undefined4 in_EDX;
    uint64_t uVar12;
    uint64_t uVar13;
    int32_t in_R8D;
    uint64_t uVar14;
    uint64_t **in_R9;
    uint64_t *puVar15;
    uint32_t uVar16;
    uint64_t uVar17;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18021955a;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    ppuVar1 = *(uint64_t ***)(in_RCX + 0x40);
    uVar16 = *(uint32_t *)(in_RCX + 0x30) & 0x200;
    *(uint32_t *)((int64_t)&arg_40h + iVar10) = *(uint32_t *)(in_RCX + 0x30);
    uVar13 = (uint64_t)in_R8D;
    uVar12 = 1;
    puVar2 = ppuVar1[1];
    puVar3 = *ppuVar1;
    puVar11 = puVar2;
    if (uVar16 == 0) {
        puVar11 = puVar3;
    }
    *(uint64_t **)((int64_t)&arg_38h + iVar10) = puVar11;
    puVar15 = puVar3;
    if (uVar16 == 0) {
        puVar15 = puVar2;
    }
    uVar17 = puVar11[1];
    uVar4 = puVar15[1];
    uVar5 = *puVar15;
    *(uint64_t *)(&stack0xffffffffffffffe8 + iVar10) = uVar4;
    uVar14 = 0;
    if (uVar4 != uVar17) {
        uVar14 = uVar4 - uVar17;
    }
    // switch table (133 cases) at 0x180219750
    switch(in_EDX) {
    case 1:
        uVar13 = puVar3[1];
        if (uVar13 != 0) {
            if (uVar16 == 0) {
                if ((*(uint32_t *)((int64_t)&arg_40h + iVar10) & 0x400) == 0) {
                    uVar17 = puVar3[2];
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x180219610;
                    func_0x0001804986e0(uVar13, 0, uVar17);
                    *puVar3 = 0;
                }
                puVar2 = *ppuVar1;
                puVar3 = ppuVar1[1];
                uVar7 = *(undefined4 *)((int64_t)puVar2 + 4);
                uVar8 = *(undefined4 *)(puVar2 + 1);
                uVar9 = *(undefined4 *)((int64_t)puVar2 + 0xc);
                *(undefined4 *)puVar3 = *(undefined4 *)puVar2;
                *(undefined4 *)((int64_t)puVar3 + 4) = uVar7;
                *(undefined4 *)(puVar3 + 1) = uVar8;
                *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar9;
                uVar7 = *(undefined4 *)((int64_t)puVar2 + 0x14);
                uVar8 = *(undefined4 *)(puVar2 + 3);
                uVar9 = *(undefined4 *)((int64_t)puVar2 + 0x1c);
                *(undefined4 *)(puVar3 + 2) = *(undefined4 *)(puVar2 + 2);
                *(undefined4 *)((int64_t)puVar3 + 0x14) = uVar7;
                *(undefined4 *)(puVar3 + 3) = uVar8;
                *(undefined4 *)((int64_t)puVar3 + 0x1c) = uVar9;
            } else {
                uVar7 = *(undefined4 *)((int64_t)puVar2 + 4);
                uVar8 = *(undefined4 *)(puVar2 + 1);
                uVar9 = *(undefined4 *)((int64_t)puVar2 + 0xc);
                *(undefined4 *)puVar3 = *(undefined4 *)puVar2;
                *(undefined4 *)((int64_t)puVar3 + 4) = uVar7;
                *(undefined4 *)(puVar3 + 1) = uVar8;
                *(undefined4 *)((int64_t)puVar3 + 0xc) = uVar9;
                uVar7 = *(undefined4 *)((int64_t)puVar2 + 0x14);
                uVar8 = *(undefined4 *)(puVar2 + 3);
                uVar9 = *(undefined4 *)((int64_t)puVar2 + 0x1c);
                *(undefined4 *)(puVar3 + 2) = *(undefined4 *)(puVar2 + 2);
                *(undefined4 *)((int64_t)puVar3 + 0x14) = uVar7;
                *(undefined4 *)(puVar3 + 3) = uVar8;
                *(undefined4 *)((int64_t)puVar3 + 0x1c) = uVar9;
            }
        }
        break;
    case 2:
        uVar12 = (uint64_t)(uVar5 == 0);
        break;
    case 3:
        uVar12 = uVar5 & 0xffffffff;
        if (in_R9 != (uint64_t **)0x0) {
            *in_R9 = *(uint64_t **)(&stack0xffffffffffffffe8 + iVar10);
        }
        break;
    default:
        uVar12 = 0;
        break;
    case 8:
        uVar12 = (uint64_t)*(uint32_t *)(in_RCX + 0x2c);
        break;
    case 9:
        *(int32_t *)(in_RCX + 0x2c) = in_R8D;
        break;
    case 10:
        uVar12 = uVar5 & 0xffffffff;
        break;
    case 0xb:
    case 0xc:
        break;
    case 0x72:
        if (((*(int32_t *)(in_RCX + 0x2c) != 0) && (*(int32_t *)(in_RCX + 0x28) != 0)) && (ppuVar1 != (uint64_t **)0x0))
        {
            if (uVar16 != 0) {
                puVar3[1] = 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1802196ee;
            func_0x000180226310(puVar3);
        }
        *(int32_t *)(in_RCX + 0x2c) = in_R8D;
        puVar2 = ppuVar1[1];
        *ppuVar1 = (uint64_t *)in_R9;
        uVar7 = *(undefined4 *)((int64_t)in_R9 + 4);
        uVar8 = *(undefined4 *)(in_R9 + 1);
        uVar9 = *(undefined4 *)((int64_t)in_R9 + 0xc);
        *(undefined4 *)puVar2 = *(undefined4 *)in_R9;
        *(undefined4 *)((int64_t)puVar2 + 4) = uVar7;
        *(undefined4 *)(puVar2 + 1) = uVar8;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = uVar9;
        uVar7 = *(undefined4 *)((int64_t)in_R9 + 0x14);
        uVar8 = *(undefined4 *)(in_R9 + 3);
        uVar9 = *(undefined4 *)((int64_t)in_R9 + 0x1c);
        *(undefined4 *)(puVar2 + 2) = *(undefined4 *)(in_R9 + 2);
        *(undefined4 *)((int64_t)puVar2 + 0x14) = uVar7;
        *(undefined4 *)(puVar2 + 3) = uVar8;
        *(undefined4 *)((int64_t)puVar2 + 0x1c) = uVar9;
        break;
    case 0x73:
        if (in_R9 != (uint64_t **)0x0) {
            if (uVar16 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x18021971a;
                func_0x0001802199d0(in_RCX);
            }
            *in_R9 = *ppuVar1;
        }
        break;
    case 0x80:
        if ((in_R8D < 0) || ((int64_t)(uVar14 + uVar5) < (int64_t)uVar13)) {
            return 0xffffffff;
        }
        if (in_R8D != 0) {
            uVar17 = uVar17 + uVar13;
        }
        piVar6 = *(int64_t **)((int64_t)&arg_38h + iVar10);
        puVar15[1] = uVar17;
        *puVar15 = *piVar6 - uVar13;
        puVar15[2] = piVar6[2] - uVar13;
        uVar14 = uVar13;
    case 0x85:
        uVar12 = uVar14 & 0xffffffff;
        if (0x7fffffff < (int64_t)uVar14) {
            uVar12 = 0xffffffff;
        }
        break;
    case 0x82:
        *(int32_t *)(in_RCX + 0x38) = in_R8D;
    }
    return uVar12;
}

// ============================================================
// Function: FUN_180219810
// Address: 0x180219810
// Size: 24 bytes
// ============================================================
undefined8 fcn.180219810(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t in_RCX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180219a65;
    iVar5 = fcn.18045a350(extraout_XMM0_Da, 0);
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219a84;
    piVar6 = (int64_t *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4));
    if (piVar6 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219a93;
        iVar7 = fcn.180226640(uVar9);
        *piVar6 = iVar7;
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219ad2;
            puVar8 = (undefined4 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4));
            puVar1 = (undefined4 *)*piVar6;
            piVar6[1] = (int64_t)puVar8;
            if (puVar8 == (undefined4 *)0x0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219ae3;
                fcn.180226310();
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219af8;
                fcn.180224990(piVar6, 0x1804be5e8, 0x79);
                return 0;
            }
            uVar9 = puVar1[1];
            uVar2 = puVar1[2];
            uVar3 = puVar1[3];
            *puVar8 = *puVar1;
            puVar8[1] = uVar9;
            puVar8[2] = uVar2;
            puVar8[3] = uVar3;
            uVar9 = puVar1[5];
            uVar2 = puVar1[6];
            uVar3 = puVar1[7];
            puVar8[4] = puVar1[4];
            puVar8[5] = uVar9;
            puVar8[6] = uVar2;
            puVar8[7] = uVar3;
            *(int64_t **)(in_RCX + 0x40) = piVar6;
            *(undefined4 *)(in_RCX + 0x2c) = 1;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            *(undefined4 *)(in_RCX + 0x38) = 0xffffffff;
            return 1;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219ab0;
        fcn.180224990(piVar6, 0x1804be5e8, 0x74);
    }
    return 0;
}

// ============================================================
// Function: FUN_180219830
// Address: 0x180219830
// Size: 27 bytes
// ============================================================
undefined8 fcn.180219830(int64_t param_1)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar10 = 1;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x180219a65;
    iVar6 = fcn.18045a350(extraout_XMM0_Da, 1);
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x180219a84;
    piVar7 = (int64_t *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5));
    if (piVar7 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x180219a93;
        iVar8 = fcn.180226640(uVar10 & 0xffffffff);
        *piVar7 = iVar8;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x180219ad2;
            puVar9 = (undefined4 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5));
            puVar1 = (undefined4 *)*piVar7;
            piVar7[1] = (int64_t)puVar9;
            if (puVar9 == (undefined4 *)0x0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x180219ae3;
                fcn.180226310();
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x180219af8;
                fcn.180224990(piVar7, 0x1804be5e8, 0x79);
                return 0;
            }
            uVar2 = puVar1[1];
            uVar3 = puVar1[2];
            uVar4 = puVar1[3];
            *puVar9 = *puVar1;
            puVar9[1] = uVar2;
            puVar9[2] = uVar3;
            puVar9[3] = uVar4;
            uVar2 = puVar1[5];
            uVar3 = puVar1[6];
            uVar4 = puVar1[7];
            puVar9[4] = puVar1[4];
            puVar9[5] = uVar2;
            puVar9[6] = uVar3;
            puVar9[7] = uVar4;
            *(int64_t **)(param_1 + 0x40) = piVar7;
            *(undefined4 *)(param_1 + 0x2c) = 1;
            *(undefined4 *)(param_1 + 0x28) = 1;
            *(undefined4 *)(param_1 + 0x38) = 0xffffffff;
            return 1;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x180219ab0;
        fcn.180224990(piVar7, 0x1804be5e8, 0x74);
    }
    return 0;
}

// ============================================================
// Function: FUN_180219850
// Address: 0x180219850
// Size: 137 bytes
// ============================================================
undefined8 fcn.180219850(int64_t param_1)
{
    int32_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021985a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 == 0) {
        return 0;
    }
    iVar1 = *(int32_t *)(param_1 + 0x2c);
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RBX;
    piVar2 = *(int64_t **)(param_1 + 0x40);
    if (((iVar1 != 0) && (*(int32_t *)(param_1 + 0x28) != 0)) && (piVar2 != (int64_t *)0x0)) {
        iVar3 = *piVar2;
        if ((*(uint32_t *)(param_1 + 0x30) & 0x200) != 0) {
            *(undefined8 *)(iVar3 + 8) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18021989f;
        fcn.180226310(iVar3);
    }
    iVar3 = piVar2[1];
    *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802198b5;
    fcn.180224990(iVar3, 0x1804be5e8, 0x98);
    *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802198ca;
    fcn.180224990(piVar2, 0x1804be5e8, 0x99);
    return 1;
}

// ============================================================
// Function: FUN_1802198e0
// Address: 0x1802198e0
// Size: 78 bytes
// ============================================================
int64_t fcn.1802198e0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802198ec;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802198fc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219914;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219926;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
    if (in_EDX < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021993c;
        iVar8 = fcn.180498cd0();
    } else {
        iVar8 = (int64_t)in_EDX;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219950;
    iVar7 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar7));
    if (iVar7 == 0) {
        return 0;
    }
    ppiVar1 = *(int64_t ***)(iVar7 + 0x40);
    piVar2 = *ppiVar1;
    *piVar2 = iVar8;
    piVar2[2] = iVar8;
    piVar2[1] = in_RCX;
    piVar2 = *ppiVar1;
    piVar3 = ppiVar1[1];
    uVar4 = *(undefined4 *)((int64_t)piVar2 + 4);
    uVar5 = *(undefined4 *)(piVar2 + 1);
    uVar6 = *(undefined4 *)((int64_t)piVar2 + 0xc);
    *(undefined4 *)piVar3 = *(undefined4 *)piVar2;
    *(undefined4 *)((int64_t)piVar3 + 4) = uVar4;
    *(undefined4 *)(piVar3 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar3 + 0xc) = uVar6;
    uVar4 = *(undefined4 *)((int64_t)piVar2 + 0x14);
    uVar5 = *(undefined4 *)(piVar2 + 3);
    uVar6 = *(undefined4 *)((int64_t)piVar2 + 0x1c);
    *(undefined4 *)(piVar3 + 2) = *(undefined4 *)(piVar2 + 2);
    *(undefined4 *)((int64_t)piVar3 + 0x14) = uVar4;
    *(undefined4 *)(piVar3 + 3) = uVar5;
    *(undefined4 *)((int64_t)piVar3 + 0x1c) = uVar6;
    *(uint32_t *)(iVar7 + 0x30) = *(uint32_t *)(iVar7 + 0x30) | 0x200;
    *(undefined4 *)(iVar7 + 0x38) = 0;
    return iVar7;
}

// ============================================================
// Function: FUN_18021992e
// Address: 0x18021992e
// Size: 53 bytes
// ============================================================
int64_t fcn.1802198e0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802198ec;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802198fc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219914;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219926;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
    if (in_EDX < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021993c;
        iVar8 = fcn.180498cd0();
    } else {
        iVar8 = (int64_t)in_EDX;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219950;
    iVar7 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar7));
    if (iVar7 == 0) {
        return 0;
    }
    ppiVar1 = *(int64_t ***)(iVar7 + 0x40);
    piVar2 = *ppiVar1;
    *piVar2 = iVar8;
    piVar2[2] = iVar8;
    piVar2[1] = in_RCX;
    piVar2 = *ppiVar1;
    piVar3 = ppiVar1[1];
    uVar4 = *(undefined4 *)((int64_t)piVar2 + 4);
    uVar5 = *(undefined4 *)(piVar2 + 1);
    uVar6 = *(undefined4 *)((int64_t)piVar2 + 0xc);
    *(undefined4 *)piVar3 = *(undefined4 *)piVar2;
    *(undefined4 *)((int64_t)piVar3 + 4) = uVar4;
    *(undefined4 *)(piVar3 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar3 + 0xc) = uVar6;
    uVar4 = *(undefined4 *)((int64_t)piVar2 + 0x14);
    uVar5 = *(undefined4 *)(piVar2 + 3);
    uVar6 = *(undefined4 *)((int64_t)piVar2 + 0x1c);
    *(undefined4 *)(piVar3 + 2) = *(undefined4 *)(piVar2 + 2);
    *(undefined4 *)((int64_t)piVar3 + 0x14) = uVar4;
    *(undefined4 *)(piVar3 + 3) = uVar5;
    *(undefined4 *)((int64_t)piVar3 + 0x1c) = uVar6;
    *(uint32_t *)(iVar7 + 0x30) = *(uint32_t *)(iVar7 + 0x30) | 0x200;
    *(undefined4 *)(iVar7 + 0x38) = 0;
    return iVar7;
}

// ============================================================
// Function: FUN_180219963
// Address: 0x180219963
// Size: 67 bytes
// ============================================================
int64_t fcn.1802198e0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802198ec;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802198fc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219914;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219926;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
    if (in_EDX < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021993c;
        iVar8 = fcn.180498cd0();
    } else {
        iVar8 = (int64_t)in_EDX;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180219950;
    iVar7 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar7));
    if (iVar7 == 0) {
        return 0;
    }
    ppiVar1 = *(int64_t ***)(iVar7 + 0x40);
    piVar2 = *ppiVar1;
    *piVar2 = iVar8;
    piVar2[2] = iVar8;
    piVar2[1] = in_RCX;
    piVar2 = *ppiVar1;
    piVar3 = ppiVar1[1];
    uVar4 = *(undefined4 *)((int64_t)piVar2 + 4);
    uVar5 = *(undefined4 *)(piVar2 + 1);
    uVar6 = *(undefined4 *)((int64_t)piVar2 + 0xc);
    *(undefined4 *)piVar3 = *(undefined4 *)piVar2;
    *(undefined4 *)((int64_t)piVar3 + 4) = uVar4;
    *(undefined4 *)(piVar3 + 1) = uVar5;
    *(undefined4 *)((int64_t)piVar3 + 0xc) = uVar6;
    uVar4 = *(undefined4 *)((int64_t)piVar2 + 0x14);
    uVar5 = *(undefined4 *)(piVar2 + 3);
    uVar6 = *(undefined4 *)((int64_t)piVar2 + 0x1c);
    *(undefined4 *)(piVar3 + 2) = *(undefined4 *)(piVar2 + 2);
    *(undefined4 *)((int64_t)piVar3 + 0x14) = uVar4;
    *(undefined4 *)(piVar3 + 3) = uVar5;
    *(undefined4 *)((int64_t)piVar3 + 0x1c) = uVar6;
    *(uint32_t *)(iVar7 + 0x30) = *(uint32_t *)(iVar7 + 0x30) | 0x200;
    *(undefined4 *)(iVar7 + 0x38) = 0;
    return iVar7;
}

// ============================================================
// Function: FUN_1802199d0
// Address: 0x1802199d0
// Size: 24 bytes
// ============================================================
undefined8 fcn.1802199d0(int64_t param_1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802199da;
    iVar5 = fcn.18045a350();
    if ((param_1 != 0) && (*(int32_t *)(param_1 + 0x28) != 0)) {
        *(undefined8 *)((int64_t)&var_20h + -iVar5) = unaff_RBX;
        piVar1 = *(int64_t **)(param_1 + 0x40);
        if (piVar1 != (int64_t *)0x0) {
            iVar2 = *(int64_t *)(*piVar1 + 8);
            iVar3 = ((undefined8 *)piVar1[1])[1];
            if (iVar3 != iVar2) {
                uVar4 = *(undefined8 *)piVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + -iVar5) = 0x180219a12;
                fcn.180498030(iVar2, iVar3, uVar4);
                *(undefined8 *)*piVar1 = *(undefined8 *)piVar1[1];
                *(undefined8 *)(piVar1[1] + 8) = *(undefined8 *)(*piVar1 + 8);
            }
        }
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802199e8
// Address: 0x1802199e8
// Size: 82 bytes
// ============================================================
undefined8 fcn.1802199d0(int64_t param_1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802199da;
    iVar5 = fcn.18045a350();
    if ((param_1 != 0) && (*(int32_t *)(param_1 + 0x28) != 0)) {
        *(undefined8 *)((int64_t)&var_20h + -iVar5) = unaff_RBX;
        piVar1 = *(int64_t **)(param_1 + 0x40);
        if (piVar1 != (int64_t *)0x0) {
            iVar2 = *(int64_t *)(*piVar1 + 8);
            iVar3 = ((undefined8 *)piVar1[1])[1];
            if (iVar3 != iVar2) {
                uVar4 = *(undefined8 *)piVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + -iVar5) = 0x180219a12;
                fcn.180498030(iVar2, iVar3, uVar4);
                *(undefined8 *)*piVar1 = *(undefined8 *)piVar1[1];
                *(undefined8 *)(piVar1[1] + 8) = *(undefined8 *)(*piVar1 + 8);
            }
        }
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_180219a3a
// Address: 0x180219a3a
// Size: 7 bytes
// ============================================================
undefined8 fcn.1802199d0(int64_t param_1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802199da;
    iVar5 = fcn.18045a350();
    if ((param_1 != 0) && (*(int32_t *)(param_1 + 0x28) != 0)) {
        *(undefined8 *)((int64_t)&var_20h + -iVar5) = unaff_RBX;
        piVar1 = *(int64_t **)(param_1 + 0x40);
        if (piVar1 != (int64_t *)0x0) {
            iVar2 = *(int64_t *)(*piVar1 + 8);
            iVar3 = ((undefined8 *)piVar1[1])[1];
            if (iVar3 != iVar2) {
                uVar4 = *(undefined8 *)piVar1[1];
                *(undefined8 *)((int64_t)&uStack_8 + -iVar5) = 0x180219a12;
                fcn.180498030(iVar2, iVar3, uVar4);
                *(undefined8 *)*piVar1 = *(undefined8 *)piVar1[1];
                *(undefined8 *)(piVar1[1] + 8) = *(undefined8 *)(*piVar1 + 8);
            }
        }
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_180219a50
// Address: 0x180219a50
// Size: 246 bytes
// ============================================================
undefined8 fcn.180219810(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t in_RCX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180219a65;
    iVar5 = fcn.18045a350(extraout_XMM0_Da, 0);
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219a84;
    piVar6 = (int64_t *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4));
    if (piVar6 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219a93;
        iVar7 = fcn.180226640(uVar9);
        *piVar6 = iVar7;
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219ad2;
            puVar8 = (undefined4 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4));
            puVar1 = (undefined4 *)*piVar6;
            piVar6[1] = (int64_t)puVar8;
            if (puVar8 == (undefined4 *)0x0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219ae3;
                fcn.180226310();
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219af8;
                fcn.180224990(piVar6, 0x1804be5e8, 0x79);
                return 0;
            }
            uVar9 = puVar1[1];
            uVar2 = puVar1[2];
            uVar3 = puVar1[3];
            *puVar8 = *puVar1;
            puVar8[1] = uVar9;
            puVar8[2] = uVar2;
            puVar8[3] = uVar3;
            uVar9 = puVar1[5];
            uVar2 = puVar1[6];
            uVar3 = puVar1[7];
            puVar8[4] = puVar1[4];
            puVar8[5] = uVar9;
            puVar8[6] = uVar2;
            puVar8[7] = uVar3;
            *(int64_t **)(in_RCX + 0x40) = piVar6;
            *(undefined4 *)(in_RCX + 0x2c) = 1;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            *(undefined4 *)(in_RCX + 0x38) = 0xffffffff;
            return 1;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180219ab0;
        fcn.180224990(piVar6, 0x1804be5e8, 0x74);
    }
    return 0;
}

// ============================================================
// Function: FUN_180219b50
// Address: 0x180219b50
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180219b50(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180219b60;
    var_18h = arg3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        return 0xfffffffe;
    }
    if (((*(int64_t *)(placeholder_0 + 8) == 0) || (*(int64_t *)(*(int64_t *)(placeholder_0 + 8) + 0x58) == 0)) ||
       ((int32_t)placeholder_1 != 0xe)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219caa;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cc2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cd4;
        fcn.1802296d0(*(int64_t *)((int64_t)&stack0x00000038 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(placeholder_0 + 0x18);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219c1b;
        pcVar4 = *ppcVar1;
code_r0x000180219bc9:
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
        *(undefined4 *)((int64_t)&arg_28h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219bf1;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(placeholder_0 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219bc9;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c12;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219c1b:
    pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c2e;
    uVar5 = (*pcVar2)(placeholder_0, 0xe);
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_20h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219ca3;
            uVar5 = (*pcVar2)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0xe);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(int32_t *)((int64_t)&arg_28h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c70;
    uVar5 = (*pcVar4)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219b94
// Address: 0x180219b94
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180219b50(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180219b60;
    var_18h = arg3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        return 0xfffffffe;
    }
    if (((*(int64_t *)(placeholder_0 + 8) == 0) || (*(int64_t *)(*(int64_t *)(placeholder_0 + 8) + 0x58) == 0)) ||
       ((int32_t)placeholder_1 != 0xe)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219caa;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cc2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cd4;
        fcn.1802296d0(*(int64_t *)((int64_t)&stack0x00000038 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(placeholder_0 + 0x18);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219c1b;
        pcVar4 = *ppcVar1;
code_r0x000180219bc9:
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
        *(undefined4 *)((int64_t)&arg_28h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219bf1;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(placeholder_0 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219bc9;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c12;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219c1b:
    pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c2e;
    uVar5 = (*pcVar2)(placeholder_0, 0xe);
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_20h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219ca3;
            uVar5 = (*pcVar2)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0xe);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(int32_t *)((int64_t)&arg_28h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c70;
    uVar5 = (*pcVar4)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219c85
// Address: 0x180219c85
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180219b50(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180219b60;
    var_18h = arg3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        return 0xfffffffe;
    }
    if (((*(int64_t *)(placeholder_0 + 8) == 0) || (*(int64_t *)(*(int64_t *)(placeholder_0 + 8) + 0x58) == 0)) ||
       ((int32_t)placeholder_1 != 0xe)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219caa;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cc2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cd4;
        fcn.1802296d0(*(int64_t *)((int64_t)&stack0x00000038 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(placeholder_0 + 0x18);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219c1b;
        pcVar4 = *ppcVar1;
code_r0x000180219bc9:
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
        *(undefined4 *)((int64_t)&arg_28h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219bf1;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(placeholder_0 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219bc9;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c12;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219c1b:
    pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c2e;
    uVar5 = (*pcVar2)(placeholder_0, 0xe);
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_20h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219ca3;
            uVar5 = (*pcVar2)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0xe);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(int32_t *)((int64_t)&arg_28h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c70;
    uVar5 = (*pcVar4)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219ca5
// Address: 0x180219ca5
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180219b50(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180219b60;
    var_18h = arg3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (placeholder_0 == 0) {
        return 0xfffffffe;
    }
    if (((*(int64_t *)(placeholder_0 + 8) == 0) || (*(int64_t *)(*(int64_t *)(placeholder_0 + 8) + 0x58) == 0)) ||
       ((int32_t)placeholder_1 != 0xe)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219caa;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cc2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219cd4;
        fcn.1802296d0(*(int64_t *)((int64_t)&stack0x00000038 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(placeholder_0 + 0x18);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219c1b;
        pcVar4 = *ppcVar1;
code_r0x000180219bc9:
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
        *(undefined4 *)((int64_t)&arg_28h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219bf1;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(placeholder_0 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219bc9;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c12;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219c1b:
    pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c2e;
    uVar5 = (*pcVar2)(placeholder_0, 0xe);
    pcVar2 = *(code **)(placeholder_0 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_20h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219ca3;
            uVar5 = (*pcVar2)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0xe);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(int32_t *)((int64_t)&arg_28h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xe;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219c70;
    uVar5 = (*pcVar4)(placeholder_0, 0x86, (int64_t)&arg_58h + iVar3, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219d10
// Address: 0x180219d10
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180219d10(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined4 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180219d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x40) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e72;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e8a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e9c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    uVar6 = (undefined4)in_R8;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219ddf;
        pcVar4 = *ppcVar1;
code_r0x000180219d96:
        *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
        *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219dbe;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(in_RCX + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219d96;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219ddb;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219ddf:
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x40);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219df6;
    uVar5 = (*pcVar2)(in_RCX, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_10h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e6b;
            uVar5 = (*pcVar2)(in_RCX, 0x86, in_R9, in_RDX & 0xffffffff);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(int32_t *)((int64_t)&var_18h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
    *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e38;
    uVar5 = (*pcVar4)(in_RCX, 0x86, in_R9, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219d68
// Address: 0x180219d68
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180219d10(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined4 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180219d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x40) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e72;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e8a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e9c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    uVar6 = (undefined4)in_R8;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219ddf;
        pcVar4 = *ppcVar1;
code_r0x000180219d96:
        *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
        *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219dbe;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(in_RCX + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219d96;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219ddb;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219ddf:
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x40);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219df6;
    uVar5 = (*pcVar2)(in_RCX, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_10h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e6b;
            uVar5 = (*pcVar2)(in_RCX, 0x86, in_R9, in_RDX & 0xffffffff);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(int32_t *)((int64_t)&var_18h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
    *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e38;
    uVar5 = (*pcVar4)(in_RCX, 0x86, in_R9, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219e51
// Address: 0x180219e51
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180219d10(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined4 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180219d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x40) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e72;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e8a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e9c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    uVar6 = (undefined4)in_R8;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219ddf;
        pcVar4 = *ppcVar1;
code_r0x000180219d96:
        *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
        *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219dbe;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(in_RCX + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219d96;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219ddb;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219ddf:
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x40);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219df6;
    uVar5 = (*pcVar2)(in_RCX, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_10h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e6b;
            uVar5 = (*pcVar2)(in_RCX, 0x86, in_R9, in_RDX & 0xffffffff);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(int32_t *)((int64_t)&var_18h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
    *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e38;
    uVar5 = (*pcVar4)(in_RCX, 0x86, in_R9, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219e6d
// Address: 0x180219e6d
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180219d10(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined4 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180219d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x40) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e72;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e8a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e9c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RDI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    uVar6 = (undefined4)in_R8;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219ddf;
        pcVar4 = *ppcVar1;
code_r0x000180219d96:
        *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
        *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219dbe;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(in_RCX + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219d96;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219ddb;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219ddf:
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x40);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219df6;
    uVar5 = (*pcVar2)(in_RCX, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&var_10h + iVar3) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e6b;
            uVar5 = (*pcVar2)(in_RCX, 0x86, in_R9, in_RDX & 0xffffffff);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(int32_t *)((int64_t)&var_18h + iVar3) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&var_10h + iVar3) = uVar6;
    *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180219e38;
    uVar5 = (*pcVar4)(in_RCX, 0x86, in_R9, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_180219eb0
// Address: 0x180219eb0
// Size: 70 bytes
// ============================================================
bool fcn.180219eb0(uint32_t param_1)
{
    bool bVar1;
    
    fcn.18045a350();
    if (-1 < (int32_t)param_1) {
        if ((param_1 & 0xff800000) != 0x10000000) {
            return false;
        }
        return (param_1 & 0x7fffff) == 0x70;
    }
    param_1 = param_1 & 0x7fffffff;
    if (param_1 < 0x7f) {
        if ((param_1 - 0x67 < 0x18) && ((0x800201U >> (param_1 - 0x67 & 0x1f) & 1) != 0)) {
            return true;
        }
        if (param_1 == 4) {
            return true;
        }
        bVar1 = param_1 == 0xb;
    } else {
        if (param_1 == 0x86) {
            return true;
        }
        if (param_1 == 0x8c) {
            return true;
        }
        bVar1 = param_1 == 0x2733;
    }
    if (bVar1) {
        return true;
    }
    return false;
}

// ============================================================
// Function: FUN_180219f00
// Address: 0x180219f00
// Size: 127 bytes
// ============================================================
int64_t fcn.180219f00(int64_t param_1, uint32_t param_2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180219f0a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180219f17;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180219f2f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180219f41;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    do {
        if (*(uint32_t **)(param_1 + 8) != (uint32_t *)0x0) {
            uVar1 = **(uint32_t **)(param_1 + 8);
            if ((char)param_2 == '\0') {
                if ((param_2 & uVar1) != 0) {
                    return param_1;
                }
            } else if (uVar1 == param_2) {
                return param_1;
            }
        }
        param_1 = *(int64_t *)(param_1 + 0x48);
    } while (param_1 != 0);
    return 0;
}

// ============================================================
// Function: FUN_180219f80
// Address: 0x180219f80
// Size: 232 bytes
// ============================================================
undefined8 fcn.180219f80(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180219f8c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        return 0;
    }
    LOCK();
    piVar1 = (int32_t *)(in_RCX + 0x58);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (1 < iVar3) {
        return 1;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021a018;
        pcVar5 = *(code **)(in_RCX + 0x18);
code_r0x000180219fcc:
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
        *(undefined4 *)((int64_t)&arg_28h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_20h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180219ff3;
        iVar3 = (*pcVar5)(in_RCX, 1, 0, 0);
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 != (code *)0x0) goto code_r0x000180219fcc;
        *(undefined4 *)((int64_t)&var_20h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021a014;
        iVar3 = (*pcVar2)(in_RCX, 1, 0, 0);
    }
    if (iVar3 < 1) {
        return 0;
    }
code_r0x00018021a018:
    if ((*(int64_t *)(in_RCX + 8) != 0) && (pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x50), pcVar2 != (code *)0x0)
       ) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021a02f;
        (*pcVar2)(in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021a040;
    fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x00000100 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021a055;
    fcn.180224990(in_RCX, 0x1804be610, 0x93);
    return 1;
}

// ============================================================
// Function: FUN_18021a070
// Address: 0x18021a070
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18021a070(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021a084;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RSI;
        do {
            piVar1 = (int32_t *)(arg1 + 0x58);
            LOCK();
            iVar2 = *piVar1;
            *piVar1 = *piVar1;
            UNLOCK();
            iVar3 = *(int64_t *)(arg1 + 0x48);
            LOCK();
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar5 < 2) {
                pcVar4 = *(code **)(arg1 + 0x10);
                if (pcVar4 == (code *)0x0) {
                    if (*(int64_t *)(arg1 + 0x18) != 0) {
                        pcVar7 = *(code **)(arg1 + 0x18);
code_r0x00018021a0e4:
                        *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&arg_28h + iVar6) = 1;
                        *(undefined4 *)((int64_t)&var_20h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_18h + iVar6) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a109;
                        iVar5 = (*pcVar7)(arg1, 1);
                        goto code_r0x00018021a128;
                    }
                } else {
                    pcVar7 = *(code **)(arg1 + 0x18);
                    if (pcVar7 != (code *)0x0) goto code_r0x00018021a0e4;
                    *(undefined4 *)((int64_t)&var_20h + iVar6) = 1;
                    *(undefined4 *)((int64_t)&var_18h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a128;
                    iVar5 = (*pcVar4)(arg1, 1, 0, 0);
code_r0x00018021a128:
                    if (iVar5 < 1) goto code_r0x00018021a169;
                }
                if ((*(int64_t *)(arg1 + 8) != 0) &&
                   (pcVar4 = *(code **)(*(int64_t *)(arg1 + 8) + 0x50), pcVar4 != (code *)0x0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a143;
                    (*pcVar4)(arg1);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a154;
                fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x00000100 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a169;
                fcn.180224990(arg1, 0x1804be610);
            }
code_r0x00018021a169:
        } while ((iVar2 < 2) && (arg1 = iVar3, iVar3 != 0));
    }
    return;
}

// ============================================================
// Function: FUN_18021a087
// Address: 0x18021a087
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18021a070(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021a084;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RSI;
        do {
            piVar1 = (int32_t *)(arg1 + 0x58);
            LOCK();
            iVar2 = *piVar1;
            *piVar1 = *piVar1;
            UNLOCK();
            iVar3 = *(int64_t *)(arg1 + 0x48);
            LOCK();
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar5 < 2) {
                pcVar4 = *(code **)(arg1 + 0x10);
                if (pcVar4 == (code *)0x0) {
                    if (*(int64_t *)(arg1 + 0x18) != 0) {
                        pcVar7 = *(code **)(arg1 + 0x18);
code_r0x00018021a0e4:
                        *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&arg_28h + iVar6) = 1;
                        *(undefined4 *)((int64_t)&var_20h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_18h + iVar6) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a109;
                        iVar5 = (*pcVar7)(arg1, 1);
                        goto code_r0x00018021a128;
                    }
                } else {
                    pcVar7 = *(code **)(arg1 + 0x18);
                    if (pcVar7 != (code *)0x0) goto code_r0x00018021a0e4;
                    *(undefined4 *)((int64_t)&var_20h + iVar6) = 1;
                    *(undefined4 *)((int64_t)&var_18h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a128;
                    iVar5 = (*pcVar4)(arg1, 1, 0, 0);
code_r0x00018021a128:
                    if (iVar5 < 1) goto code_r0x00018021a169;
                }
                if ((*(int64_t *)(arg1 + 8) != 0) &&
                   (pcVar4 = *(code **)(*(int64_t *)(arg1 + 8) + 0x50), pcVar4 != (code *)0x0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a143;
                    (*pcVar4)(arg1);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a154;
                fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x00000100 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a169;
                fcn.180224990(arg1, 0x1804be610);
            }
code_r0x00018021a169:
        } while ((iVar2 < 2) && (arg1 = iVar3, iVar3 != 0));
    }
    return;
}

// ============================================================
// Function: FUN_18021a18b
// Address: 0x18021a18b
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18021a070(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021a084;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RSI;
        do {
            piVar1 = (int32_t *)(arg1 + 0x58);
            LOCK();
            iVar2 = *piVar1;
            *piVar1 = *piVar1;
            UNLOCK();
            iVar3 = *(int64_t *)(arg1 + 0x48);
            LOCK();
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar5 < 2) {
                pcVar4 = *(code **)(arg1 + 0x10);
                if (pcVar4 == (code *)0x0) {
                    if (*(int64_t *)(arg1 + 0x18) != 0) {
                        pcVar7 = *(code **)(arg1 + 0x18);
code_r0x00018021a0e4:
                        *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&arg_28h + iVar6) = 1;
                        *(undefined4 *)((int64_t)&var_20h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_18h + iVar6) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a109;
                        iVar5 = (*pcVar7)(arg1, 1);
                        goto code_r0x00018021a128;
                    }
                } else {
                    pcVar7 = *(code **)(arg1 + 0x18);
                    if (pcVar7 != (code *)0x0) goto code_r0x00018021a0e4;
                    *(undefined4 *)((int64_t)&var_20h + iVar6) = 1;
                    *(undefined4 *)((int64_t)&var_18h + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a128;
                    iVar5 = (*pcVar4)(arg1, 1, 0, 0);
code_r0x00018021a128:
                    if (iVar5 < 1) goto code_r0x00018021a169;
                }
                if ((*(int64_t *)(arg1 + 8) != 0) &&
                   (pcVar4 = *(code **)(*(int64_t *)(arg1 + 8) + 0x50), pcVar4 != (code *)0x0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a143;
                    (*pcVar4)(arg1);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a154;
                fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x00000100 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18021a169;
                fcn.180224990(arg1, 0x1804be610);
            }
code_r0x00018021a169:
        } while ((iVar2 < 2) && (arg1 = iVar3, iVar3 != 0));
    }
    return;
}

// ============================================================
// Function: FUN_18021a190
// Address: 0x18021a190
// Size: 33 bytes
// ============================================================
undefined8 fcn.18021a190(int64_t param_1, undefined8 param_2)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    undefined4 uVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    uVar7 = 0x5b;
    *(undefined8 *)(&stack0x00000040 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6) = 0x180219d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        return 0xffffffff;
    }
    if ((*(int64_t *)(param_1 + 8) == 0) || (*(int64_t *)(*(int64_t *)(param_1 + 8) + 0x40) == 0)) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e72;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar6), *(int64_t *)(&stack0x00000038 + iVar3 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e8a;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar6), *(int64_t *)(&stack0x00000038 + iVar3 + iVar6), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar6), *(int64_t *)(&stack0x00000048 + iVar3 + iVar6), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e9c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar6));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(param_1 + 0x10);
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000078 + iVar3 + iVar6) = unaff_RDI;
    ppcVar1 = (code **)(param_1 + 0x18);
    uVar9 = (undefined4)uVar8;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219ddf;
        pcVar4 = *ppcVar1;
code_r0x000180219d96:
        *(undefined8 *)(&stack0x00000048 + iVar3 + iVar6) = 0;
        *(undefined4 *)(&stack0x00000040 + iVar3 + iVar6) = 1;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar6) = uVar9;
        *(int32_t *)(&stack0x00000030 + iVar3 + iVar6) = (int32_t)uVar7;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219dbe;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(param_1 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219d96;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar6) = 1;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar6) = uVar9;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219ddb;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219ddf:
    pcVar2 = *(code **)(*(int64_t *)(param_1 + 8) + 0x40);
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219df6;
    uVar5 = (*pcVar2)(param_1, uVar7 & 0xffffffff, uVar8 & 0xffffffff, param_2);
    pcVar2 = *(code **)(param_1 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)(&stack0x00000038 + iVar3 + iVar6) = (int32_t)uVar5;
            *(undefined4 *)(&stack0x00000030 + iVar3 + iVar6) = uVar9;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e6b;
            uVar5 = (*pcVar2)(param_1, 0x86, param_2, uVar7 & 0xffffffff);
            return uVar5;
        }
    }
    *(undefined8 *)(&stack0x00000048 + iVar3 + iVar6) = 0;
    *(int32_t *)(&stack0x00000040 + iVar3 + iVar6) = (int32_t)uVar5;
    *(undefined4 *)(&stack0x00000038 + iVar3 + iVar6) = uVar9;
    *(int32_t *)(&stack0x00000030 + iVar3 + iVar6) = (int32_t)uVar7;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e38;
    uVar5 = (*pcVar4)(param_1, 0x86, param_2, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_18021a1d0
// Address: 0x18021a1d0
// Size: 33 bytes
// ============================================================
undefined8 fcn.18021a1d0(int64_t param_1, undefined8 param_2)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    undefined4 uVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    uVar7 = 0x5c;
    *(undefined8 *)(&stack0x00000040 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6) = 0x180219d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        return 0xffffffff;
    }
    if ((*(int64_t *)(param_1 + 8) == 0) || (*(int64_t *)(*(int64_t *)(param_1 + 8) + 0x40) == 0)) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e72;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar6), *(int64_t *)(&stack0x00000038 + iVar3 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e8a;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar6), *(int64_t *)(&stack0x00000038 + iVar3 + iVar6), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar6), *(int64_t *)(&stack0x00000048 + iVar3 + iVar6), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e9c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar6));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(param_1 + 0x10);
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000078 + iVar3 + iVar6) = unaff_RDI;
    ppcVar1 = (code **)(param_1 + 0x18);
    uVar9 = (undefined4)uVar8;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219ddf;
        pcVar4 = *ppcVar1;
code_r0x000180219d96:
        *(undefined8 *)(&stack0x00000048 + iVar3 + iVar6) = 0;
        *(undefined4 *)(&stack0x00000040 + iVar3 + iVar6) = 1;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar6) = uVar9;
        *(int32_t *)(&stack0x00000030 + iVar3 + iVar6) = (int32_t)uVar7;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219dbe;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(param_1 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219d96;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar6) = 1;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar6) = uVar9;
        *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219ddb;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219ddf:
    pcVar2 = *(code **)(*(int64_t *)(param_1 + 8) + 0x40);
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219df6;
    uVar5 = (*pcVar2)(param_1, uVar7 & 0xffffffff, uVar8 & 0xffffffff, param_2);
    pcVar2 = *(code **)(param_1 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)(&stack0x00000038 + iVar3 + iVar6) = (int32_t)uVar5;
            *(undefined4 *)(&stack0x00000030 + iVar3 + iVar6) = uVar9;
            *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e6b;
            uVar5 = (*pcVar2)(param_1, 0x86, param_2, uVar7 & 0xffffffff);
            return uVar5;
        }
    }
    *(undefined8 *)(&stack0x00000048 + iVar3 + iVar6) = 0;
    *(int32_t *)(&stack0x00000040 + iVar3 + iVar6) = (int32_t)uVar5;
    *(undefined4 *)(&stack0x00000038 + iVar3 + iVar6) = uVar9;
    *(int32_t *)(&stack0x00000030 + iVar3 + iVar6) = (int32_t)uVar7;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + iVar6) = 0x180219e38;
    uVar5 = (*pcVar4)(param_1, 0x86, param_2, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_18021a200
// Address: 0x18021a200
// Size: 670 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18021a200(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    code *pcVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 in_RDX;
    uint32_t uVar9;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021a218;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = (uint32_t)in_R8;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a236;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a24e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a260;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x38) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a45c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a474;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a486;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
        return 0xfffffffe;
    }
    if ((int32_t)uVar9 < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a28b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a2a3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a2b5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
        return 0xffffffff;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar6 = *(code **)(in_RCX + 0x18);
code_r0x00018021a2dd:
            *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
            *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a301;
            uVar5 = (*pcVar6)();
            goto code_r0x00018021a332;
        }
    } else {
        pcVar6 = *(code **)(in_RCX + 0x18);
        if (pcVar6 != (code *)0x0) goto code_r0x00018021a2dd;
        if (0x7fffffff < uVar9) {
            return 0xffffffff;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a332;
        uVar5 = (*pcVar1)();
code_r0x00018021a332:
        if ((int32_t)uVar5 < 1) {
            return uVar5;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a348;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a360;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a372;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x38);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a390;
    iVar2 = (*pcVar1)(in_RCX, in_RDX, in_R8 & 0xffffffff);
    uVar5 = (uint64_t)iVar2;
    if (iVar2 < 1) {
        uVar7 = *(uint64_t *)((int64_t)&arg_48h + iVar4);
        uVar8 = uVar5;
    } else {
        *(uint64_t *)((int64_t)&arg_48h + iVar4) = uVar5;
        uVar8 = 1;
        uVar7 = uVar5;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    iVar2 = (int32_t)uVar8;
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021a3fd;
        pcVar6 = *(code **)(in_RCX + 0x18);
code_r0x00018021a3ce:
        *(int64_t *)((int64_t)&var_20h + iVar4) = (int64_t)&arg_48h + iVar4;
        *(int32_t *)((int64_t)&var_18h + iVar4) = iVar2;
        *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a3f6;
        uVar3 = (*pcVar6)(in_RCX, 0x85, in_RDX, (int64_t)(int32_t)uVar9);
        uVar8 = (uint64_t)uVar3;
    } else {
        pcVar6 = *(code **)(in_RCX + 0x18);
        if (pcVar6 != (code *)0x0) goto code_r0x00018021a3ce;
        if (0x7fffffff < uVar9) {
            uVar8 = 0xffffffff;
            goto code_r0x00018021a3fd;
        }
        if (0 < iVar2) {
            if (0x7fffffff < uVar7) {
                uVar8 = 0xffffffff;
                goto code_r0x00018021a3fd;
            }
            iVar2 = (int32_t)uVar7;
        }
        *(int32_t *)((int64_t)&var_10h + iVar4) = iVar2;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021a446;
        iVar2 = (*pcVar1)(in_RCX, 0x85, in_RDX, in_R8 & 0xffffffff);
        uVar7 = (uint64_t)iVar2;
        uVar8 = uVar7;
        if (0 < iVar2) {
            uVar8 = 1;
            goto code_r0x00018021a3fd;
        }
    }
    uVar7 = *(uint64_t *)((int64_t)&arg_48h + iVar4);
code_r0x00018021a3fd:
    if ((0 < (int32_t)uVar8) && (uVar8 = uVar7 & 0xffffffff, (uint64_t)(int64_t)(int32_t)uVar9 < uVar7)) {
        uVar8 = 0xffffffff;
    }
    return uVar8 & 0xffffffff;
}

// ============================================================
// Function: FUN_18021a4a0
// Address: 0x18021a4a0
// Size: 752 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.18021a4a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_b0h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    int32_t in_EDX;
    int32_t iVar6;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021a4b5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 0;
    if (-1 < in_EDX) {
        iVar6 = in_EDX;
    }
    if (in_R8D < iVar6) {
        iVar6 = in_R8D;
    }
    if (iVar6 == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a73f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a757;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a769;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    do {
        iVar6 = iVar6 + -1;
        if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x30) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a6fe;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a716;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a728;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
            return 0;
        }
        pcVar1 = *(code **)(in_RCX + 0x10);
        if (pcVar1 == (code *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) != 0) {
                pcVar4 = *(code **)(in_RCX + 0x18);
code_r0x00018021a525:
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                *(undefined4 *)((int64_t)&arg_28h + iVar3) = 1;
                *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
                *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a54e;
                iVar2 = (*pcVar4)(in_RCX, 4, 0x1805ab2c4);
                goto code_r0x00018021a571;
            }
        } else {
            pcVar4 = *(code **)(in_RCX + 0x18);
            if (pcVar4 != (code *)0x0) goto code_r0x00018021a525;
            *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a571;
            iVar2 = (*pcVar1)(in_RCX, 4, 0x1805ab2c4, 0);
code_r0x00018021a571:
            if (iVar2 < 1) {
                return 0;
            }
        }
        if (*(int32_t *)(in_RCX + 0x28) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a6bd;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a6d5;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a6e7;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
            return 0;
        }
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a597;
        iVar2 = (*pcVar1)(in_RCX, 0x1805ab2c4);
        if (iVar2 < 1) {
            uVar5 = *(uint64_t *)((int64_t)&arg_60h + iVar3);
        } else {
            uVar5 = (uint64_t)iVar2;
            iVar2 = 1;
            *(int64_t *)(in_RCX + 0x68) = *(int64_t *)(in_RCX + 0x68) + uVar5;
            *(uint64_t *)((int64_t)&arg_60h + iVar3) = uVar5;
        }
        pcVar1 = *(code **)(in_RCX + 0x10);
        if (pcVar1 == (code *)0x0) {
            if (*(int64_t *)(in_RCX + 0x18) != 0) {
                pcVar4 = *(code **)(in_RCX + 0x18);
code_r0x00018021a5d1:
                *(int64_t *)((int64_t)&arg_30h + iVar3) = (int64_t)&arg_60h + iVar3;
                *(int32_t *)((int64_t)&arg_28h + iVar3) = iVar2;
                *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
                *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a5fc;
                iVar2 = (*pcVar4)(in_RCX, 0x84, 0x1805ab2c4);
                goto code_r0x00018021a5fc;
            }
        } else {
            pcVar4 = *(code **)(in_RCX + 0x18);
            if (pcVar4 != (code *)0x0) goto code_r0x00018021a5d1;
            if (0 < iVar2) {
                if (0x7fffffff < uVar5) {
                    iVar2 = -1;
                    goto code_r0x00018021a601;
                }
                iVar2 = (int32_t)uVar5;
            }
            *(int32_t *)((int64_t)&var_20h + iVar3) = iVar2;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a67f;
            iVar2 = (*pcVar1)(in_RCX, 0x84, 0x1805ab2c4);
            if (0 < iVar2) {
                uVar5 = (uint64_t)iVar2;
                iVar2 = 1;
                *(uint64_t *)((int64_t)&arg_60h + iVar3) = uVar5;
                goto code_r0x00018021a601;
            }
code_r0x00018021a5fc:
            uVar5 = *(uint64_t *)((int64_t)&arg_60h + iVar3);
        }
code_r0x00018021a601:
        if (0 < iVar2) {
            if (uVar5 < 0x80000000) {
                iVar2 = (int32_t)uVar5;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a61b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a633;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a645;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                iVar2 = -1;
            }
        }
        if (iVar2 != 1) {
            return 0;
        }
        if (iVar6 == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&arg_60h + iVar3) = 0;
    } while( true );
}

// ============================================================
// Function: FUN_18021a790
// Address: 0x18021a790
// Size: 33 bytes
// ============================================================
void fcn.18021a790(int64_t arg_48h)
{
    int64_t iVar1;
    undefined4 in_R9D;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021a79a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_48h + iVar1) = in_R9D;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18021a7ac;
    fcn.180219d10(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18021a7c0
// Address: 0x18021a7c0
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18021a7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021a7d0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a7ed;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *puVar4 = 0;
    puVar4[1] = in_RCX;
    *(undefined4 *)((int64_t)puVar4 + 0x2c) = 1;
    *(undefined4 *)(puVar4 + 0xb) = 1;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a82f;
    iVar2 = fcn.180224430(*(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar2 != 0) {
        pcVar1 = *(code **)(in_RCX + 0x48);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a841;
            iVar2 = (*pcVar1)(puVar4);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a84a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a862;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a874;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a885;
                fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar3), *(int64_t *)(&stack0x00000100 + iVar3));
                goto code_r0x00018021a885;
            }
        }
        if (*(int64_t *)(in_RCX + 0x48) == 0) {
            *(undefined4 *)(puVar4 + 5) = 1;
        }
        return puVar4;
    }
code_r0x00018021a885:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a89a;
    fcn.180224990(puVar4, 0x1804be610, 0x6e);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18021a825
// Address: 0x18021a825
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18021a7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021a7d0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a7ed;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *puVar4 = 0;
    puVar4[1] = in_RCX;
    *(undefined4 *)((int64_t)puVar4 + 0x2c) = 1;
    *(undefined4 *)(puVar4 + 0xb) = 1;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a82f;
    iVar2 = fcn.180224430(*(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar2 != 0) {
        pcVar1 = *(code **)(in_RCX + 0x48);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a841;
            iVar2 = (*pcVar1)(puVar4);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a84a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a862;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a874;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a885;
                fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar3), *(int64_t *)(&stack0x00000100 + iVar3));
                goto code_r0x00018021a885;
            }
        }
        if (*(int64_t *)(in_RCX + 0x48) == 0) {
            *(undefined4 *)(puVar4 + 5) = 1;
        }
        return puVar4;
    }
code_r0x00018021a885:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a89a;
    fcn.180224990(puVar4, 0x1804be610, 0x6e);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18021a8ac
// Address: 0x18021a8ac
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18021a7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021a7d0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a7ed;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *puVar4 = 0;
    puVar4[1] = in_RCX;
    *(undefined4 *)((int64_t)puVar4 + 0x2c) = 1;
    *(undefined4 *)(puVar4 + 0xb) = 1;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a82f;
    iVar2 = fcn.180224430(*(int64_t *)(&stack0x00000058 + iVar3));
    if (iVar2 != 0) {
        pcVar1 = *(code **)(in_RCX + 0x48);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a841;
            iVar2 = (*pcVar1)(puVar4);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a84a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a862;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a874;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a885;
                fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar3), *(int64_t *)(&stack0x00000100 + iVar3));
                goto code_r0x00018021a885;
            }
        }
        if (*(int64_t *)(in_RCX + 0x48) == 0) {
            *(undefined4 *)(puVar4 + 5) = 1;
        }
        return puVar4;
    }
code_r0x00018021a885:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021a89a;
    fcn.180224990(puVar4, 0x1804be610, 0x6e);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18021a8e0
// Address: 0x18021a8e0
// Size: 114 bytes
// ============================================================
undefined8 fcn.18021a8e0(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021a8ec;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    uVar1 = *(undefined8 *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021a918;
    fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    if (*(int64_t *)(in_RCX + 0x50) != 0) {
        *(undefined8 *)(*(int64_t *)(in_RCX + 0x50) + 0x48) = *(undefined8 *)(in_RCX + 0x48);
    }
    if (*(int64_t *)(in_RCX + 0x48) != 0) {
        *(undefined8 *)(*(int64_t *)(in_RCX + 0x48) + 0x50) = *(undefined8 *)(in_RCX + 0x50);
    }
    *(undefined8 *)(in_RCX + 0x48) = 0;
    *(undefined8 *)(in_RCX + 0x50) = 0;
    return uVar1;
}

// ============================================================
// Function: FUN_18021a960
// Address: 0x18021a960
// Size: 101 bytes
// ============================================================
int64_t fcn.18021a960(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021a96c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 != 0) {
        iVar3 = *(int64_t *)(param_1 + 0x48);
        iVar2 = param_1;
        while (iVar1 = iVar3, iVar1 != 0) {
            iVar2 = iVar1;
            iVar3 = *(int64_t *)(iVar1 + 0x48);
        }
        *(int64_t *)(iVar2 + 0x48) = param_2;
        if (param_2 != 0) {
            *(int64_t *)(param_2 + 0x50) = iVar2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021a9bc;
        fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        return param_1;
    }
    return param_2;
}

// ============================================================
// Function: FUN_18021a9d0
// Address: 0x18021a9d0
// Size: 677 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18021a9d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_80h)
{
    code *pcVar1;
    int64_t iVar2;
    code *pcVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    undefined8 in_RDX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021a9e5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021a9ff;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021aa17;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021aa29;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x30) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ac36;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ac4e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ac60;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0xfffffffe;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar3 = *(code **)(in_RCX + 0x18);
code_r0x00018021aa73:
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0;
            *(undefined4 *)((int64_t)&arg_28h + iVar2) = 1;
            *(undefined4 *)((int64_t)&var_20h + iVar2) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021aa95;
            uVar4 = (*pcVar3)();
            goto code_r0x00018021aab1;
        }
    } else {
        pcVar3 = *(code **)(in_RCX + 0x18);
        if (pcVar3 != (code *)0x0) goto code_r0x00018021aa73;
        *(undefined4 *)((int64_t)&var_20h + iVar2) = 1;
        *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021aab1;
        uVar4 = (*pcVar1)();
code_r0x00018021aab1:
        if ((int32_t)uVar4 < 1) {
            return uVar4;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021aac3;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021aadb;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021aaed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ab13;
    uVar4 = (*pcVar1)(in_RCX, in_RDX);
    if ((int32_t)uVar4 < 1) {
        uVar5 = *(uint64_t *)((int64_t)&arg_48h + iVar2);
    } else {
        uVar5 = (uint64_t)(int32_t)uVar4;
        uVar4 = 1;
        *(int64_t *)(in_RCX + 0x68) = *(int64_t *)(in_RCX + 0x68) + uVar5;
        *(uint64_t *)((int64_t)&arg_48h + iVar2) = uVar5;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021ab7d;
        pcVar3 = *(code **)(in_RCX + 0x18);
code_r0x00018021ab51:
        *(int64_t *)((int64_t)&arg_30h + iVar2) = (int64_t)&arg_48h + iVar2;
        *(int32_t *)((int64_t)&arg_28h + iVar2) = (int32_t)uVar4;
        *(undefined4 *)((int64_t)&var_20h + iVar2) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ab78;
        uVar4 = (*pcVar3)(in_RCX, 0x84, in_RDX, 0);
    } else {
        pcVar3 = *(code **)(in_RCX + 0x18);
        if (pcVar3 != (code *)0x0) goto code_r0x00018021ab51;
        if (0 < (int32_t)uVar4) {
            if (0x7fffffff < uVar5) {
                uVar4 = 0xffffffff;
                goto code_r0x00018021ab7d;
            }
            uVar4 = uVar5 & 0xffffffff;
        }
        *(int32_t *)((int64_t)&var_20h + iVar2) = (int32_t)uVar4;
        *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ac05;
        uVar4 = (*pcVar1)(in_RCX, 0x84, in_RDX, 0);
        if (0 < (int32_t)uVar4) {
            uVar5 = (uint64_t)(int32_t)uVar4;
            uVar4 = 1;
            *(uint64_t *)((int64_t)&arg_48h + iVar2) = uVar5;
            goto code_r0x00018021ab7d;
        }
    }
    uVar5 = *(uint64_t *)((int64_t)&arg_48h + iVar2);
code_r0x00018021ab7d:
    if ((int32_t)uVar4 < 1) {
        return uVar4;
    }
    if (uVar5 < 0x80000000) {
        return uVar5 & 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ab97;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021abaf;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021abc1;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18021ac80
// Address: 0x18021ac80
// Size: 50 bytes
// ============================================================
int32_t fcn.18021ac80(int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t in_R8D;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021ac8a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021aca6;
    iVar1 = fcn.18021b380(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (0 < iVar1) {
        iVar1 = *(int32_t *)((int64_t)&arg_48h + iVar2);
    }
    return iVar1;
}

// ============================================================
// Function: FUN_18021acc0
// Address: 0x18021acc0
// Size: 32 bytes
// ============================================================
bool fcn.18021acc0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021acca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021acd2;
    iVar1 = fcn.18021b380(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    return 0 < iVar1;
}

// ============================================================
// Function: FUN_18021ace0
// Address: 0x18021ace0
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021ace0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021acf2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad18;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad30;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad42;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x68) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af4f;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af67;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af79;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021adfd;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ade9;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae0e;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae26;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae38;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x68);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae7f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021af30:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af19;
            iVar5 = (*pcVar2)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021af30;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aec5;
    iVar5 = (*pcVar9)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021ad6e
// Address: 0x18021ad6e
// Size: 240 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021ace0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021acf2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad18;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad30;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad42;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x68) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af4f;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af67;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af79;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021adfd;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ade9;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae0e;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae26;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae38;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x68);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae7f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021af30:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af19;
            iVar5 = (*pcVar2)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021af30;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aec5;
    iVar5 = (*pcVar9)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021ae5e
// Address: 0x18021ae5e
// Size: 223 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021ace0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021acf2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad18;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad30;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad42;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x68) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af4f;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af67;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af79;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021adfd;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ade9;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae0e;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae26;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae38;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x68);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae7f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021af30:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af19;
            iVar5 = (*pcVar2)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021af30;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aec5;
    iVar5 = (*pcVar9)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021af3d
// Address: 0x18021af3d
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021ace0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021acf2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad18;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad30;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ad42;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x68) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af4f;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af67;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af79;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021adfd;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ade9;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae0e;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae26;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae38;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x68);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021ae7f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021af30:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021af19;
            iVar5 = (*pcVar2)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021af30;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aec5;
    iVar5 = (*pcVar9)(in_RCX, 0x87, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021af90
// Address: 0x18021af90
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021af90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021afa2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afc8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afe0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aff2;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x60) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1ff;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b217;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b229;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0ad;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b099;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0be;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0d6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0e8;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x60);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b12f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021b1e0:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1c9;
            iVar5 = (*pcVar2)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021b1e0;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b175;
    iVar5 = (*pcVar9)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021b01e
// Address: 0x18021b01e
// Size: 240 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021af90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021afa2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afc8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afe0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aff2;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x60) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1ff;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b217;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b229;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0ad;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b099;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0be;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0d6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0e8;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x60);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b12f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021b1e0:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1c9;
            iVar5 = (*pcVar2)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021b1e0;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b175;
    iVar5 = (*pcVar9)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021b10e
// Address: 0x18021b10e
// Size: 223 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021af90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021afa2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afc8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afe0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aff2;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x60) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1ff;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b217;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b229;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0ad;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b099;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0be;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0d6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0e8;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x60);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b12f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021b1e0:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1c9;
            iVar5 = (*pcVar2)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021b1e0;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b175;
    iVar5 = (*pcVar9)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021b1ed
// Address: 0x18021b1ed
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021af90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h)
{
    code **ppcVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    code *pcVar9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021afa2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afc8;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021afe0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021aff2;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x60) == 0)) {
        **(undefined8 **)((int64_t)&arg_a0h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1ff;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b217;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b229;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    pcVar2 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_R13;
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar6);
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_R14;
    puVar4 = *(undefined8 **)((int64_t)&arg_a0h + iVar6);
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RSI;
    ppcVar1 = (code **)(in_RCX + 0x18);
    if ((pcVar2 != (code *)0x0) || (*ppcVar1 != (code *)0x0)) {
        pcVar9 = *ppcVar1;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = uVar3;
        *(undefined8 **)((int64_t)&arg_38h + iVar6) = puVar4;
        if (pcVar9 == (code *)0x0) {
            *(undefined4 *)(&stack0x00000000 + iVar6) = 1;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0ad;
            iVar5 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
            *(undefined4 *)((int64_t)&iStackX_8 + iVar6) = 1;
            *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b099;
            iVar5 = (*pcVar9)();
        }
        if (iVar5 == 0) {
            return false;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *puVar4 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0be;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0d6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b0e8;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        return false;
    }
    iVar8 = *(int64_t *)(in_RCX + 8);
    *(undefined8 **)(&stack0x00000000 + iVar6) = puVar4;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar3;
    pcVar2 = *(code **)(iVar8 + 0x60);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b12f;
    uVar7 = (*pcVar2)(in_RCX, in_RDX, in_R8, in_R9);
    pcVar2 = *(code **)(in_RCX + 0x10);
    iVar5 = (int32_t)uVar7;
    iVar8 = (int64_t)iVar5;
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
code_r0x00018021b1e0:
            return iVar8 != 0;
        }
        pcVar9 = *ppcVar1;
    } else {
        pcVar9 = *ppcVar1;
        if (pcVar9 == (code *)0x0) {
            if ((0 < iVar5) && (uVar7 = *(uint64_t *)0x0, 0x7fffffff < *(uint64_t *)0x0)) {
                return true;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b1c9;
            iVar5 = (*pcVar2)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, 0);
            if (0 < iVar5) {
                *(uint64_t *)0x0 = (uint64_t)iVar5;
                iVar5 = 1;
            }
            iVar8 = (int64_t)iVar5;
            goto code_r0x00018021b1e0;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(int32_t *)((int64_t)&iStackX_8 + iVar6) = iVar5;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18021b175;
    iVar5 = (*pcVar9)(in_RCX, 0x88, (int64_t)&var_18h + iVar6, iVar8);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_18021b2a0
// Address: 0x18021b2a0
// Size: 22 bytes
// ============================================================
undefined8 fcn.18021b2a0(int64_t param_1)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6) = 0x180219f8c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 == 0) {
        return 0;
    }
    LOCK();
    piVar1 = (int32_t *)(param_1 + 0x58);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (1 < iVar3) {
        return 1;
    }
    pcVar2 = *(code **)(param_1 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*(int64_t *)(param_1 + 0x18) == 0) goto code_r0x00018021a018;
        pcVar5 = *(code **)(param_1 + 0x18);
code_r0x000180219fcc:
        *(undefined8 *)(&stack0x00000058 + iVar4 + iVar6) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar4 + iVar6) = 1;
        *(undefined4 *)(&stack0x00000048 + iVar4 + iVar6) = 0;
        *(undefined4 *)(&stack0x00000040 + iVar4 + iVar6) = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180219ff3;
        iVar3 = (*pcVar5)(param_1, 1, 0, 0);
    } else {
        pcVar5 = *(code **)(param_1 + 0x18);
        if (pcVar5 != (code *)0x0) goto code_r0x000180219fcc;
        *(undefined4 *)(&stack0x00000048 + iVar4 + iVar6) = 1;
        *(undefined4 *)(&stack0x00000040 + iVar4 + iVar6) = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18021a014;
        iVar3 = (*pcVar2)(param_1, 1, 0, 0);
    }
    if (iVar3 < 1) {
        return 0;
    }
code_r0x00018021a018:
    if ((*(int64_t *)(param_1 + 8) != 0) &&
       (pcVar2 = *(code **)(*(int64_t *)(param_1 + 8) + 0x50), pcVar2 != (code *)0x0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18021a02f;
        (*pcVar2)(param_1);
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18021a040;
    fcn.180223fb0(*(int64_t *)(&stack0x000000c0 + iVar4 + iVar6), *(int64_t *)(&stack0x00000128 + iVar4 + iVar6));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18021a055;
    fcn.180224990(param_1, 0x1804be610, 0x93);
    return 1;
}

// ============================================================
// Function: FUN_18021b2c0
// Address: 0x18021b2c0
// Size: 50 bytes
// ============================================================
int32_t fcn.18021b2c0(int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t in_R8D;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021b2ca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D < 1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021b2e6;
    iVar1 = fcn.18021b610(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (0 < iVar1) {
        iVar1 = *(int32_t *)((int64_t)&arg_48h + iVar2);
    }
    return iVar1;
}

// ============================================================
// Function: FUN_18021b300
// Address: 0x18021b300
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021b300(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b310;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021b31e;
    iVar1 = fcn.18021b610(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if ((iVar1 < 1) && ((in_RCX == 0 || (in_R8 != 0)))) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18021b350
// Address: 0x18021b350
// Size: 46 bytes
// ============================================================
void fcn.18021b350(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021b35a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x18021b362;
    fcn.180274ae0();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x18021b36e;
    fcn.1802227d0(*(undefined8 *)0x180782f88);
    *(undefined8 *)0x180782f88 = 0;
    return;
}

