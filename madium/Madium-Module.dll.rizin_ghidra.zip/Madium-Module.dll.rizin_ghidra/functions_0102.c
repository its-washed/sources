// Chunk 102 - 50 functions

// ============================================================
// Function: FUN_1801633e0
// Address: 0x1801633e0
// Size: 687 bytes
// ============================================================
int64_t fcn.1801633e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined *puVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined *puVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_90;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar10 = auStack_88;
    puVar11 = auStack_88;
    puVar1 = *(undefined **)(arg1 + 8);
    if (puVar1 != *(undefined **)(arg1 + 0x10)) {
        uVar2 = *(undefined8 *)arg4;
        uVar3 = *(undefined8 *)arg3;
        *puVar1 = *(undefined *)arg2;
        *(undefined8 *)(puVar1 + 4) = uVar3;
        *(undefined8 *)(puVar1 + 0xc) = uVar2;
        *(undefined (*) [16])(puVar1 + 0x18) = ZEXT816(0);
        *(undefined8 *)(puVar1 + 0x28) = 0;
        *(undefined8 *)(puVar1 + 0x30) = 0;
        func_0x000180004830((undefined (*) [16])(puVar1 + 0x18), *(undefined8 *)arg_28h, *(undefined8 *)(arg_28h + 8));
        iVar6 = *(int64_t *)(arg1 + 8);
        *(int64_t *)(arg1 + 8) = iVar6 + 0x38;
        return iVar6;
    }
    iVar6 = ((int64_t)puVar1 - *(int64_t *)arg1) / 0x38;
    if (iVar6 == 0x492492492492492) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar15 = ((int64_t)*(undefined **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar5 = 0x492492492492492 - (uVar15 >> 1);
    if (uVar15 < uVar5 || uVar15 - uVar5 == 0) {
        uVar5 = iVar6 + 1;
        uVar15 = uVar15 + (uVar15 >> 1);
        uVar12 = uVar5;
        if (uVar5 <= uVar15) {
            uVar12 = uVar15;
        }
        if (uVar12 < 0x492492492492493) {
            uVar15 = uVar12 * 0x38;
            if (uVar15 == 0) {
                uVar13 = 0;
                puVar11 = auStack_88;
            } else if (uVar15 < 0x1000) {
                uVar13 = func_0x000180459890(uVar15);
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x000180163689;
                iVar9 = func_0x000180459890();
                if (iVar9 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar9 = (*pcVar4)(5);
                    puVar10 = auStack_80;
                }
                uVar13 = iVar9 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar13 - 8) = iVar9;
                puVar11 = puVar10;
            }
            puVar14 = (undefined *)(iVar6 * 0x38 + uVar13);
            puVar8 = puVar14 + 0x38;
            *(undefined **)(puVar11 + 0x90) = puVar8;
            *(int64_t *)(puVar11 + 0x20) = arg1;
            *(uint64_t *)(puVar11 + 0x28) = uVar13;
            *(uint64_t *)(puVar11 + 0x30) = uVar12;
            *(undefined **)(puVar11 + 0x38) = puVar8;
            *(undefined **)(puVar11 + 0x40) = puVar8;
            uVar2 = **(undefined8 **)(puVar11 + 0xa8);
            uVar3 = **(undefined8 **)(puVar11 + 0xa0);
            *puVar14 = **(undefined **)(puVar11 + 0x98);
            *(undefined8 *)(puVar14 + 4) = uVar3;
            *(undefined8 *)(puVar14 + 0xc) = uVar2;
            *(undefined (*) [16])(puVar14 + 0x18) = ZEXT816(0);
            *(undefined8 *)(puVar14 + 0x28) = 0;
            *(undefined8 *)(puVar14 + 0x30) = 0;
            uVar2 = (*(undefined8 **)(puVar11 + 0xb0))[1];
            uVar3 = **(undefined8 **)(puVar11 + 0xb0);
            *(undefined8 *)(puVar11 + -8) = 0x1801635b1;
            func_0x000180004830((undefined (*) [16])(puVar14 + 0x18), uVar3, uVar2);
            puVar8 = *(undefined **)(arg1 + 8);
            puVar14 = *(undefined **)arg1;
            uVar12 = uVar13;
            if (puVar1 != puVar8) {
                *(undefined8 *)(puVar11 + -8) = 0x1801635c8;
                func_0x000180165630(puVar14, puVar1, uVar13);
                uVar12 = *(uint64_t *)(puVar11 + 0x90);
                puVar8 = *(undefined **)(arg1 + 8);
                puVar14 = puVar1;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1801635dc;
            func_0x000180165630(puVar14, puVar8, uVar12);
            iVar9 = *(int64_t *)arg1;
            if (iVar9 != 0) {
                iVar7 = *(int64_t *)(arg1 + 8);
                for (; iVar9 != iVar7; iVar9 = iVar9 + 0x38) {
                    *(undefined8 *)(puVar11 + -8) = 0x1801635f9;
                    func_0x000180004e40(iVar9 + 0x18);
                }
                iVar9 = *(int64_t *)arg1;
                iVar7 = iVar9;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar9 >> 3) * 8)) &&
                   (iVar7 = *(int64_t *)(iVar9 + -8), 0x1f < (iVar9 - iVar7) - 8U)) {
                    iVar7 = 5;
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    puVar11 = puVar11 + 8;
                }
                *(undefined8 *)(puVar11 + -8) = 0x180163654;
                func_0x000180459c3c(iVar7);
            }
            *(uint64_t *)arg1 = uVar13;
            *(uint64_t *)(arg1 + 8) = uVar5 * 0x38 + uVar13;
            *(uint64_t *)(arg1 + 0x10) = uVar15 + uVar13;
            return iVar6 * 0x38 + uVar13;
        }
    }
code_r0x000180163689:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    iVar6 = (*pcVar4)();
    return iVar6;
}

// ============================================================
// Function: FUN_180163690
// Address: 0x180163690
// Size: 423 bytes
// ============================================================
undefined8 * fcn.180163690(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    puVar9 = auStack_68;
    puVar10 = auStack_68;
    puVar7 = *(undefined8 **)(arg1 + 8);
    if (puVar7 != *(undefined8 **)(arg1 + 0x10)) {
        uVar2 = *(undefined8 *)arg3;
        *puVar7 = *(undefined8 *)arg2;
        puVar7[1] = uVar2;
        *(undefined2 *)(puVar7 + 2) = 0x100;
        *(undefined *)((int64_t)puVar7 + 0x12) = 1;
        puVar7 = *(undefined8 **)(arg1 + 8);
        *(int64_t *)(arg1 + 8) = (int64_t)puVar7 + 0x14;
        return puVar7;
    }
    iVar11 = ((int64_t)puVar7 - *(int64_t *)arg1) / 0x14;
    if (iVar11 == 0xccccccccccccccc) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar7 = (undefined8 *)(*pcVar4)();
        return puVar7;
    }
    uVar12 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
    uVar5 = 0xccccccccccccccc - (uVar12 >> 1);
    if (uVar12 < uVar5 || uVar12 - uVar5 == 0) {
        uVar5 = iVar11 + 1;
        uVar12 = uVar12 + (uVar12 >> 1);
        uVar13 = uVar5;
        if (uVar5 <= uVar12) {
            uVar13 = uVar12;
        }
        if (uVar13 < 0xccccccccccccccd) {
            uVar12 = uVar13 * 0x14;
            if (uVar12 == 0) {
                uVar12 = 0;
                puVar10 = auStack_68;
            } else if (uVar12 < 0x1000) {
                uVar12 = func_0x000180459890();
            } else {
                if (uVar12 + 0x27 <= uVar12) goto code_r0x000180163831;
                iVar6 = func_0x000180459890(uVar12 + 0x27);
                if (iVar6 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar6 = (*pcVar4)(5);
                    puVar9 = auStack_60;
                }
                uVar12 = iVar6 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar12 - 8) = iVar6;
                puVar10 = puVar9;
            }
            puVar1 = (undefined8 *)(uVar12 + iVar11 * 0x14);
            uVar2 = *(undefined8 *)arg2;
            puVar1[1] = *(undefined8 *)arg3;
            *puVar1 = uVar2;
            *(undefined2 *)(puVar1 + 2) = 0x100;
            *(undefined *)((int64_t)puVar1 + 0x12) = 1;
            puVar3 = *(undefined8 **)arg1;
            if (puVar7 == *(undefined8 **)(arg1 + 8)) {
                iVar11 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar3;
                uVar8 = uVar12;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1801637f3;
                func_0x000180498030(uVar12, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                uVar8 = (int64_t)puVar1 + 0x14;
                iVar11 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
            }
            *(undefined8 *)(puVar10 + -8) = 0x180163806;
            func_0x000180498030(uVar8, puVar7, iVar11);
            *(undefined8 *)(puVar10 + -8) = 0x180163817;
            func_0x000180165b20(arg1, uVar12, uVar5, uVar13);
            return puVar1;
        }
    }
code_r0x000180163831:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar7 = (undefined8 *)(*pcVar4)();
    return puVar7;
}

// ============================================================
// Function: FUN_180163960
// Address: 0x180163960
// Size: 320 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180163960(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t var_10h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    var_98h = 0x180645e68;
    var_60h = (int64_t)&var_98h;
    var_20h = 0;
    var_90h = arg2;
    var_20h = func_0x000180165930(&var_98h, &var_58h);
    if (var_60h != 0) {
        (**(code **)(*(int64_t *)var_60h + 0x20))
                  (var_60h, CONCAT71((unkint7)((uint64_t)&var_98h >> 8), (int64_t *)var_60h != &var_98h));
        var_60h = 0;
    }
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg1) {
            var_60h = (**(code **)(*piVar1 + 8))(piVar1, &var_98h);
            piVar1 = *(int64_t **)(arg1 + 0x38);
            if (piVar1 == (int64_t *)0x0) goto code_r0x000180163a18;
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg1);
            piVar1 = (int64_t *)var_60h;
        }
        var_60h = (int64_t)piVar1;
        *(undefined8 *)(arg1 + 0x38) = 0;
    }
code_r0x000180163a18:
    if (var_20h != 0) {
        if ((int64_t *)var_20h == &var_58h) {
            uVar2 = (**(code **)(*(int64_t *)var_20h + 8))(var_20h, arg1);
            *(undefined8 *)(arg1 + 0x38) = uVar2;
            if (var_20h != 0) {
                (**(code **)(*(int64_t *)var_20h + 0x20))
                          (var_20h, CONCAT71((unkint7)((uint64_t)&var_58h >> 8), (int64_t *)var_20h != &var_58h));
            }
        } else {
            *(int64_t *)(arg1 + 0x38) = var_20h;
        }
    }
    if (var_60h != 0) {
        (**(code **)(*(int64_t *)var_60h + 0x20))(var_60h, (int64_t *)var_60h != &var_98h);
    }
    func_0x000180459870(var_18h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_180163aa0
// Address: 0x180163aa0
// Size: 49 bytes
// ============================================================
void fcn.180163aa0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t var_10h;
    int64_t var_18h;
    
    var_18h._0_4_ = (undefined4)arg3;
    var_10h._0_4_ = (undefined4)arg2;
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))(piVar1, &var_10h, &var_18h);
        return;
    }
    fcn.180454690();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180163ae0
// Address: 0x180163ae0
// Size: 39 bytes
// ============================================================
void fcn.180163ae0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t var_10h;
    
    var_10h._0_4_ = (undefined4)arg2;
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))(piVar1, &var_10h);
        return;
    }
    fcn.180454690();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180163b10
// Address: 0x180163b10
// Size: 55 bytes
// ============================================================
int64_t fcn.180163b10(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    
    uVar2 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if ((uint64_t)arg2 <= uVar2 && uVar2 - arg2 != 0) {
        return arg2 * 0x38 + *(int64_t *)arg1;
    }
    fcn.180060370();
    pcVar1 = (code *)swi(3);
    iVar3 = (*pcVar1)();
    return iVar3;
}

// ============================================================
// Function: FUN_180163b50
// Address: 0x180163b50
// Size: 986 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h

int64_t ** fcn.180163b50(int64_t arg1, int64_t arg2, int64_t arg_30h, int64_t arg_38h)
{
    float fVar1;
    int16_t iVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    code *pcVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint64_t uVar13;
    int64_t iVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t **ppiVar17;
    undefined8 in_R8;
    undefined8 in_R9;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    
    uVar18 = (((uint64_t)*(uint8_t *)arg2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 1)) *
             0x100000001b3;
    uVar13 = uVar18 & *(uint64_t *)(arg1 + 0x30);
    iVar14 = *(int64_t *)(arg1 + 0x18);
    ppiVar11 = *(int64_t ***)(iVar14 + 8 + uVar13 * 0x10);
    ppiVar12 = (int64_t **)(arg1 + 8);
    ppiVar17 = (int64_t **)*ppiVar12;
    if (ppiVar11 != ppiVar17) {
        iVar2 = *(int16_t *)(ppiVar11 + 2);
        ppiVar17 = ppiVar11;
        while (ppiVar11 = ppiVar17, *(int16_t *)arg2 != iVar2) {
            if (ppiVar17 == *(int64_t ***)(iVar14 + uVar13 * 0x10)) goto code_r0x000180163bdf;
            ppiVar17 = (int64_t **)ppiVar17[1];
            iVar2 = *(int16_t *)(ppiVar17 + 2);
        }
        goto code_r0x000180163efb;
    }
code_r0x000180163bdf:
    if (*(int64_t *)(arg1 + 0x10) == 0x7ffffffffffffff) {
code_r0x000180163f1d:
        func_0x0001804546d4(0x180620428);
        pcVar10 = (code *)swi(3);
        ppiVar12 = (int64_t **)(*pcVar10)();
        return ppiVar12;
    }
    ppiVar11 = (int64_t **)func_0x000180459890(0x20, iVar14, in_R8, in_R9, ppiVar12, 0);
    *(undefined2 *)(ppiVar11 + 2) = *(undefined2 *)arg2;
    ppiVar11[3] = (int64_t *)0x0;
    uVar13 = *(int64_t *)(arg1 + 0x10) + 1;
    if ((int64_t)uVar13 < 0) {
        fVar19 = (float)(uVar13 >> 1 | (uint64_t)((uint32_t)uVar13 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar13;
    }
    uVar13 = *(uint64_t *)(arg1 + 0x38);
    fVar1 = *(float *)arg1;
    if ((int64_t)uVar13 < 0) {
        fVar20 = (float)(uVar13 >> 1 | (uint64_t)((uint32_t)uVar13 & 1));
        fVar20 = fVar20 + fVar20;
    } else {
        fVar20 = (float)uVar13;
    }
    if (fVar1 < fVar19 / fVar20) {
        fVar19 = (float)func_0x000180471c90(fVar19 / fVar1, fVar19 / fVar20, fVar20, fVar1, ppiVar12, ppiVar11);
        iVar14 = 0;
        if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
            iVar14 = -0x8000000000000000;
        }
        uVar15 = 8;
        if (8 < (uint64_t)((int64_t)fVar19 + iVar14)) {
            uVar15 = (int64_t)fVar19 + iVar14;
        }
        uVar16 = uVar13;
        if ((uVar13 < uVar15) && ((0x1ff < uVar13 || (uVar16 = uVar13 * 8, uVar13 * 8 < uVar15)))) {
            uVar16 = uVar15;
        }
        for (iVar14 = 0x3f; 0xfffffffffffffffU >> iVar14 == 0; iVar14 = iVar14 + -1) {
        }
        if ((uint64_t)(1LL << ((uint8_t)iVar14 & 0x3f)) < uVar16) {
            func_0x0001804546d4(0x180620448);
            goto code_r0x000180163f1d;
        }
        uVar13 = uVar16 - 1 | 1;
        iVar14 = 0x3f;
        if (uVar13 != 0) {
            for (; uVar13 >> iVar14 == 0; iVar14 = iVar14 + -1) {
            }
        }
        iVar14 = 1LL << ((char)iVar14 + 1U & 0x3f);
        ppiVar17 = (int64_t **)*ppiVar12;
        func_0x00018000f7e0(arg1 + 0x18, iVar14 * 2, ppiVar17);
        *(int64_t *)(arg1 + 0x30) = iVar14 + -1;
        *(int64_t *)(arg1 + 0x38) = iVar14;
        ppiVar8 = (int64_t **)**ppiVar12;
joined_r0x000180163d44:
        if (ppiVar8 != ppiVar17) {
            ppiVar3 = (int64_t **)*ppiVar8;
            uVar13 = (((uint64_t)*(uint8_t *)(ppiVar8 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x11)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
            iVar14 = *(int64_t *)(arg1 + 0x18);
            ppiVar4 = *(int64_t ***)(iVar14 + uVar13 * 0x10);
            if (ppiVar4 == ppiVar17) {
                *(int64_t ***)(iVar14 + uVar13 * 0x10) = ppiVar8;
                *(int64_t ***)(iVar14 + 8 + uVar13 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar3;
            } else {
                ppiVar5 = *(int64_t ***)(iVar14 + 8 + uVar13 * 0x10);
                if (*(int16_t *)(ppiVar8 + 2) == *(int16_t *)(ppiVar5 + 2)) {
                    ppiVar5 = (int64_t **)*ppiVar5;
                    if (ppiVar5 != ppiVar8) {
                        piVar6 = ppiVar8[1];
                        *piVar6 = (int64_t)ppiVar3;
                        ppiVar4 = (int64_t **)ppiVar3[1];
                        *ppiVar4 = (int64_t *)ppiVar5;
                        piVar7 = ppiVar5[1];
                        *piVar7 = (int64_t)ppiVar8;
                        ppiVar5[1] = (int64_t *)ppiVar4;
                        ppiVar3[1] = piVar6;
                        ppiVar8[1] = piVar7;
                    }
                    *(int64_t ***)(iVar14 + 8 + uVar13 * 0x10) = ppiVar8;
                    ppiVar8 = ppiVar3;
                } else {
                    do {
                        if (ppiVar4 == ppiVar5) {
                            piVar6 = ppiVar8[1];
                            *piVar6 = (int64_t)ppiVar3;
                            ppiVar4 = (int64_t **)ppiVar3[1];
                            *ppiVar4 = (int64_t *)ppiVar5;
                            piVar7 = ppiVar5[1];
                            *piVar7 = (int64_t)ppiVar8;
                            ppiVar5[1] = (int64_t *)ppiVar4;
                            ppiVar3[1] = piVar6;
                            ppiVar8[1] = piVar7;
                            *(int64_t ***)(iVar14 + uVar13 * 0x10) = ppiVar8;
                            ppiVar8 = ppiVar3;
                            goto joined_r0x000180163d44;
                        }
                        ppiVar5 = (int64_t **)ppiVar5[1];
                    } while (*(int16_t *)(ppiVar8 + 2) != *(int16_t *)(ppiVar5 + 2));
                    piVar6 = *ppiVar5;
                    piVar7 = ppiVar8[1];
                    *piVar7 = (int64_t)ppiVar3;
                    ppiVar4 = (int64_t **)ppiVar3[1];
                    *ppiVar4 = piVar6;
                    piVar9 = (int64_t *)piVar6[1];
                    *piVar9 = (int64_t)ppiVar8;
                    piVar6[1] = (int64_t)ppiVar4;
                    ppiVar3[1] = piVar7;
                    ppiVar8[1] = piVar9;
                    ppiVar8 = ppiVar3;
                }
            }
            goto joined_r0x000180163d44;
        }
        uVar13 = uVar18 & *(uint64_t *)(arg1 + 0x30);
        ppiVar8 = *(int64_t ***)(*(int64_t *)(arg1 + 0x18) + 8 + uVar13 * 0x10);
        ppiVar17 = (int64_t **)*ppiVar12;
        if (ppiVar8 != ppiVar17) {
            iVar2 = *(int16_t *)(ppiVar8 + 2);
            ppiVar17 = ppiVar8;
            while (*(int16_t *)(ppiVar11 + 2) != iVar2) {
                if (ppiVar17 == *(int64_t ***)(*(int64_t *)(arg1 + 0x18) + uVar13 * 0x10)) goto code_r0x000180163e82;
                ppiVar17 = (int64_t **)ppiVar17[1];
                iVar2 = *(int16_t *)(ppiVar17 + 2);
            }
            ppiVar17 = (int64_t **)*ppiVar17;
        }
    }
code_r0x000180163e82:
    ppiVar8 = (int64_t **)ppiVar17[1];
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    *ppiVar11 = (int64_t *)ppiVar17;
    ppiVar11[1] = (int64_t *)ppiVar8;
    *ppiVar8 = (int64_t *)ppiVar11;
    ppiVar17[1] = (int64_t *)ppiVar11;
    iVar14 = *(int64_t *)(arg1 + 0x18);
    uVar18 = *(uint64_t *)(arg1 + 0x30) & uVar18;
    ppiVar3 = *(int64_t ***)(iVar14 + uVar18 * 0x10);
    if (ppiVar3 == (int64_t **)*ppiVar12) {
        *(int64_t ***)(iVar14 + uVar18 * 0x10) = ppiVar11;
    } else {
        if (ppiVar3 == ppiVar17) {
            *(int64_t ***)(iVar14 + uVar18 * 0x10) = ppiVar11;
            goto code_r0x000180163efb;
        }
        if (*(int64_t ***)(iVar14 + 8 + uVar18 * 0x10) != ppiVar8) goto code_r0x000180163efb;
    }
    *(int64_t ***)(iVar14 + 8 + uVar18 * 0x10) = ppiVar11;
code_r0x000180163efb:
    return ppiVar11 + 3;
}

// ============================================================
// Function: FUN_180163f30
// Address: 0x180163f30
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180163f30(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x000180004e40(iVar3 + 0x20);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180163fa7;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180163f45
// Address: 0x180163f45
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180163f30(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x000180004e40(iVar3 + 0x20);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180163fa7;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180163f81
// Address: 0x180163f81
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180163f30(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x000180004e40(iVar3 + 0x20);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180163fa7;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180163fc0
// Address: 0x180163fc0
// Size: 2605 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.180163fc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int32_t iVar14;
    int32_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t iVar19;
    undefined8 *puVar18;
    int32_t *piVar20;
    undefined8 *puVar21;
    undefined8 *puVar22;
    int32_t iVar23;
    undefined8 *puVar24;
    undefined in_R9B;
    undefined8 *puVar25;
    int64_t iVar26;
    bool bVar27;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int32_t var_58h;
    int32_t var_54h;
    int32_t var_50h;
    
    iVar11 = arg2 - arg1;
    var_8h = arg1;
    var_10h = arg2;
    do {
        if (iVar11 < 0x294) {
            if ((arg1 != arg2) && (puVar24 = (undefined8 *)(arg1 + 0x14), puVar24 != (undefined8 *)arg2)) {
                puVar21 = (undefined8 *)(arg1 + 8);
                do {
                    iVar15 = *(int32_t *)puVar24;
                    iVar7 = *(int32_t *)(puVar24 + 1);
                    iVar14 = *(int32_t *)((int64_t)puVar24 + 4);
                    iVar8 = *(int32_t *)((int64_t)puVar24 + 0xc);
                    iVar16 = *(int32_t *)(puVar24 + 2);
                    bVar27 = SBORROW4(iVar15, iVar7);
                    iVar10 = iVar15 - iVar7;
                    if (iVar15 == iVar7) {
                        bVar27 = SBORROW4(iVar14, iVar8);
                        iVar10 = iVar14 - iVar8;
                    }
                    iVar9 = *(int32_t *)puVar21;
                    iVar23 = iVar7;
                    iVar19 = iVar8;
                    if (bVar27 != iVar10 < 0) {
                        iVar23 = iVar15;
                        iVar19 = iVar14;
                    }
                    iVar10 = *(int32_t *)var_8h;
                    bVar27 = SBORROW4(iVar10, iVar9);
                    iVar4 = iVar10 - iVar9;
                    if (iVar10 == iVar9) {
                        bVar27 = SBORROW4(*(int32_t *)(var_8h + 4), *(int32_t *)(arg1 + 0xc));
                        iVar4 = *(int32_t *)(var_8h + 4) - *(int32_t *)(arg1 + 0xc);
                    }
                    puVar22 = puVar21;
                    if (bVar27 != iVar4 < 0) {
                        puVar22 = (undefined8 *)var_8h;
                    }
                    iVar9 = (int32_t)*puVar22;
                    bVar27 = SBORROW4(iVar23, iVar9);
                    iVar10 = iVar23 - iVar9;
                    if (iVar23 == iVar9) {
                        iVar10 = (int32_t)((uint64_t)*puVar22 >> 0x20);
                        bVar27 = SBORROW4(iVar19, iVar10);
                        iVar10 = iVar19 - iVar10;
                    }
                    puVar22 = puVar24;
                    if (bVar27 == iVar10 < 0) {
                        while( true ) {
                            puVar18 = (undefined8 *)((int64_t)puVar22 - 0x14);
                            bVar27 = SBORROW4(iVar15, iVar7);
                            iVar10 = iVar15 - iVar7;
                            if (iVar15 == iVar7) {
                                bVar27 = SBORROW4(iVar14, iVar8);
                                iVar10 = iVar14 - iVar8;
                            }
                            iVar9 = *(int32_t *)(undefined8 *)((int64_t)puVar22 - 0xcU);
                            iVar23 = iVar7;
                            iVar19 = iVar8;
                            if (bVar27 != iVar10 < 0) {
                                iVar23 = iVar15;
                                iVar19 = iVar14;
                            }
                            iVar10 = *(int32_t *)puVar18;
                            bVar27 = SBORROW4(iVar10, iVar9);
                            iVar4 = iVar10 - iVar9;
                            if (iVar10 == iVar9) {
                                bVar27 = SBORROW4(*(int32_t *)(puVar22 + -2), *(int32_t *)(puVar22 + -1));
                                iVar4 = *(int32_t *)(puVar22 + -2) - *(int32_t *)(puVar22 + -1);
                            }
                            puVar12 = (undefined8 *)((int64_t)puVar22 - 0xcU);
                            if (bVar27 != iVar4 < 0) {
                                puVar12 = puVar18;
                            }
                            iVar9 = (int32_t)*puVar12;
                            bVar27 = SBORROW4(iVar23, iVar9);
                            iVar10 = iVar23 - iVar9;
                            if (iVar23 == iVar9) {
                                iVar10 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                                bVar27 = SBORROW4(iVar19, iVar10);
                                iVar10 = iVar19 - iVar10;
                            }
                            if (bVar27 == iVar10 < 0) break;
                            iVar10 = *(int32_t *)((int64_t)puVar22 - 0xc);
                            *(int32_t *)puVar22 = *(int32_t *)puVar18;
                            *(int32_t *)((int64_t)puVar22 + 4) = *(int32_t *)(puVar22 + -2);
                            *(int32_t *)(puVar22 + 1) = iVar10;
                            *(int32_t *)((int64_t)puVar22 + 0xc) = *(int32_t *)(puVar22 + -1);
                            *(int32_t *)(puVar22 + 2) = *(int32_t *)((int64_t)puVar22 - 4);
                            puVar22 = puVar18;
                        }
                        *(int32_t *)puVar22 = iVar15;
                        *(int32_t *)((int64_t)puVar22 + 4) = iVar14;
                        *(int32_t *)(puVar22 + 1) = iVar7;
                        *(int32_t *)((int64_t)puVar22 + 0xc) = iVar8;
                        *(int32_t *)(puVar22 + 2) = iVar16;
                    } else {
                        var_60h._0_4_ = iVar15;
                        var_60h._4_4_ = iVar14;
                        var_58h = iVar7;
                        var_54h = iVar8;
                        func_0x000180498030((int64_t)puVar24 + (0x14 - ((int64_t)puVar24 - var_8h)), var_8h, 
                                            (int64_t)puVar24 - var_8h);
                        *(int32_t *)var_8h = iVar15;
                        *(int32_t *)(var_8h + 4) = iVar14;
                        *(int32_t *)puVar21 = iVar7;
                        *(int32_t *)(var_8h + 0xc) = iVar8;
                        *(int32_t *)(var_8h + 0x10) = iVar16;
                    }
                    puVar24 = (undefined8 *)((int64_t)puVar24 + 0x14);
                } while (puVar24 != (undefined8 *)var_10h);
            }
            return;
        }
        uVar5 = (arg2 - arg1) / 0x14;
        iVar11 = (int64_t)uVar5 >> 1;
        if (arg3 < 1) {
            if (0 < iVar11) {
                iVar17 = (int64_t)(uVar5 - 1) >> 1;
                do {
                    iVar11 = iVar11 + -1;
                    piVar20 = (int32_t *)(arg1 + iVar11 * 0x14);
                    iVar15 = *piVar20;
                    iVar7 = piVar20[1];
                    iVar14 = piVar20[2];
                    iVar8 = piVar20[3];
                    uVar3 = *(undefined4 *)(arg1 + iVar11 * 0x14 + 0x10);
                    iVar6 = iVar11;
                    while (iVar6 < iVar17) {
                        iVar26 = iVar6 * 2 + 2;
                        iVar2 = iVar26 * 0x14;
                        puVar21 = (undefined8 *)(iVar2 + 8 + arg1);
                        puVar24 = (undefined8 *)(iVar2 + arg1);
                        puVar22 = (undefined8 *)(iVar2 + -0x14 + arg1);
                        iVar16 = *(int32_t *)puVar21;
                        iVar10 = *(int32_t *)puVar24;
                        bVar27 = SBORROW4(iVar10, iVar16);
                        iVar9 = iVar10 - iVar16;
                        if (iVar10 == iVar16) {
                            bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar24 + 4), *(int32_t *)((int64_t)puVar21 + 4));
                            iVar9 = *(int32_t *)((int64_t)puVar24 + 4) - *(int32_t *)((int64_t)puVar21 + 4);
                        }
                        if (bVar27 != iVar9 < 0) {
                            puVar21 = puVar24;
                        }
                        puVar24 = (undefined8 *)(iVar2 + -0xc + arg1);
                        iVar16 = *(int32_t *)puVar24;
                        iVar10 = *(int32_t *)puVar22;
                        bVar27 = SBORROW4(iVar10, iVar16);
                        iVar9 = iVar10 - iVar16;
                        if (iVar10 == iVar16) {
                            bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar22 + 4), *(int32_t *)((int64_t)puVar24 + 4));
                            iVar9 = *(int32_t *)((int64_t)puVar22 + 4) - *(int32_t *)((int64_t)puVar24 + 4);
                        }
                        if (bVar27 != iVar9 < 0) {
                            puVar24 = puVar22;
                        }
                        iVar10 = (int32_t)*puVar24;
                        iVar9 = (int32_t)*puVar21;
                        bVar27 = SBORROW4(iVar9, iVar10);
                        iVar16 = iVar9 - iVar10;
                        if (iVar9 == iVar10) {
                            iVar10 = (int32_t)((uint64_t)*puVar24 >> 0x20);
                            iVar16 = (int32_t)((uint64_t)*puVar21 >> 0x20);
                            bVar27 = SBORROW4(iVar16, iVar10);
                            iVar16 = iVar16 - iVar10;
                        }
                        if (bVar27 != iVar16 < 0) {
                            iVar26 = iVar6 * 2 + 1;
                        }
                        piVar20 = (int32_t *)(arg1 + iVar6 * 0x14);
                        piVar1 = (int32_t *)(arg1 + iVar26 * 0x14);
                        iVar16 = piVar1[1];
                        iVar10 = piVar1[2];
                        iVar9 = piVar1[3];
                        *piVar20 = *piVar1;
                        piVar20[1] = iVar16;
                        piVar20[2] = iVar10;
                        piVar20[3] = iVar9;
                        piVar20[4] = *(int32_t *)(arg1 + iVar26 * 0x14 + 0x10);
                        iVar6 = iVar26;
                    }
                    if ((iVar6 == iVar17) && ((uVar5 & 1) == 0)) {
                        piVar20 = (int32_t *)(arg1 + iVar6 * 0x14);
                        piVar1 = (int32_t *)(arg1 + uVar5 * 0x14 + -0x14);
                        iVar16 = piVar1[1];
                        iVar10 = piVar1[2];
                        iVar9 = piVar1[3];
                        *piVar20 = *piVar1;
                        piVar20[1] = iVar16;
                        piVar20[2] = iVar10;
                        piVar20[3] = iVar9;
                        piVar20[4] = *(int32_t *)(arg1 + uVar5 * 0x14 + -4);
                        iVar6 = uVar5 - 1;
                    }
                    while (iVar11 < iVar6) {
                        iVar26 = iVar6 + -1 >> 1;
                        iVar16 = *(int32_t *)(var_8h + iVar26 * 0x14 + 8);
                        puVar24 = (undefined8 *)(var_8h + iVar26 * 0x14 + 8);
                        iVar10 = *(int32_t *)(var_8h + iVar26 * 0x14);
                        bVar27 = SBORROW4(iVar10, iVar16);
                        iVar9 = iVar10 - iVar16;
                        puVar21 = (undefined8 *)(var_8h + iVar26 * 0x14);
                        if (iVar10 == iVar16) {
                            iVar9 = *(int32_t *)((int64_t)puVar24 + 4);
                            bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar21 + 4), iVar9);
                            iVar9 = *(int32_t *)((int64_t)puVar21 + 4) - iVar9;
                        }
                        if (bVar27 != iVar9 < 0) {
                            puVar24 = puVar21;
                        }
                        bVar27 = SBORROW4(iVar15, iVar14);
                        iVar16 = iVar15 - iVar14;
                        if (iVar15 == iVar14) {
                            bVar27 = SBORROW4(iVar7, iVar8);
                            iVar16 = iVar7 - iVar8;
                        }
                        iVar10 = iVar14;
                        iVar9 = iVar8;
                        if (bVar27 != iVar16 < 0) {
                            iVar10 = iVar15;
                            iVar9 = iVar7;
                        }
                        iVar23 = (int32_t)*puVar24;
                        bVar27 = SBORROW4(iVar23, iVar10);
                        iVar16 = iVar23 - iVar10;
                        if (iVar23 == iVar10) {
                            iVar16 = (int32_t)((uint64_t)*puVar24 >> 0x20);
                            bVar27 = SBORROW4(iVar16, iVar9);
                            iVar16 = iVar16 - iVar9;
                        }
                        arg1 = var_8h;
                        if (bVar27 == iVar16 < 0) break;
                        piVar20 = (int32_t *)(var_8h + iVar6 * 0x14);
                        iVar16 = *(int32_t *)((int64_t)puVar21 + 4);
                        iVar10 = *(int32_t *)(puVar21 + 1);
                        iVar9 = *(int32_t *)((int64_t)puVar21 + 0xc);
                        *piVar20 = *(int32_t *)puVar21;
                        piVar20[1] = iVar16;
                        piVar20[2] = iVar10;
                        piVar20[3] = iVar9;
                        piVar20[4] = *(int32_t *)(puVar21 + 2);
                        iVar6 = iVar26;
                    }
                    *(int32_t *)(arg1 + iVar6 * 0x14 + 8) = iVar14;
                    *(int32_t *)(arg1 + iVar6 * 0x14) = iVar15;
                    *(int32_t *)(arg1 + iVar6 * 0x14 + 4) = iVar7;
                    *(int32_t *)(arg1 + iVar6 * 0x14 + 0xc) = iVar8;
                    *(undefined4 *)(arg1 + iVar6 * 0x14 + 0x10) = uVar3;
                    arg2 = var_10h;
                } while (0 < iVar11);
            }
            if ((int64_t)uVar5 < 2) {
                return;
            }
            do {
                puVar24 = (undefined8 *)(arg2 - 0x14);
                if (1 < (arg2 - arg1 >> 2) * -0x3333333333333333) {
                    var_60h._0_4_ = *(int32_t *)puVar24;
                    var_60h._4_4_ = *(int32_t *)(arg2 + -0x10);
                    var_58h = *(int32_t *)(arg2 - 0xc);
                    var_54h = *(int32_t *)(arg2 + -8);
                    var_50h = *(int32_t *)(arg2 - 4);
                    iVar15 = *(int32_t *)(arg1 + 4);
                    iVar7 = *(int32_t *)(arg1 + 8);
                    iVar14 = *(int32_t *)(arg1 + 0xc);
                    *(int32_t *)puVar24 = *(int32_t *)arg1;
                    *(int32_t *)(arg2 + -0x10) = iVar15;
                    *(int32_t *)(arg2 - 0xc) = iVar7;
                    *(int32_t *)(arg2 + -8) = iVar14;
                    *(int32_t *)(arg2 - 4) = *(int32_t *)(arg1 + 0x10);
                    func_0x0001801656a0(arg1, 0, ((int64_t)puVar24 - arg1 >> 2) * -0x3333333333333333, &var_60h, in_R9B)
                    ;
                }
                arg2 = (int64_t)puVar24;
            } while (0x27 < (int64_t)puVar24 - arg1);
            return;
        }
        iVar17 = (arg2 + (-0x14 - arg1) >> 2) * -0x3333333333333333;
        puVar24 = (undefined8 *)(arg1 + iVar11 * 0x14);
        if (iVar17 < 0x29) {
            piVar20 = (int32_t *)(arg2 + -0x14);
            puVar21 = (undefined8 *)arg1;
        } else {
            iVar11 = iVar17 + 1 >> 3;
            puVar21 = (undefined8 *)(iVar11 * 0x14 + arg1);
            func_0x000180165bc0(arg1, puVar21, (undefined8 *)(arg1 + iVar11 * 5 * 8));
            func_0x000180165bc0((int32_t *)((int64_t)puVar24 + iVar11 * -0x14), puVar24, 
                                (int32_t *)(iVar11 * 0x14 + (int64_t)puVar24));
            piVar20 = (int32_t *)(arg2 + iVar11 * -0x14 + -0x14);
            func_0x000180165bc0(arg2 + iVar11 * -0x28 + -0x14, piVar20, (int32_t *)(arg2 + -0x14));
        }
        func_0x000180165bc0(puVar21, puVar24, piVar20);
        puVar21 = (undefined8 *)((int64_t)puVar24 + 0x14);
        if ((uint64_t)arg1 < puVar24) {
            while( true ) {
                iVar15 = *(int32_t *)((int64_t)puVar24 - 0xc);
                iVar7 = *(int32_t *)((int64_t)puVar24 - 0x14);
                puVar22 = (undefined8 *)((int64_t)puVar24 - 0x14);
                bVar27 = SBORROW4(iVar7, iVar15);
                iVar14 = iVar7 - iVar15;
                if (iVar7 == iVar15) {
                    bVar27 = SBORROW4(*(int32_t *)(puVar24 + -2), *(int32_t *)(puVar24 + -1));
                    iVar14 = *(int32_t *)(puVar24 + -2) - *(int32_t *)(puVar24 + -1);
                }
                iVar8 = *(int32_t *)(puVar24 + 1);
                iVar16 = *(int32_t *)puVar24;
                puVar18 = (undefined8 *)((int64_t)puVar24 - 0xcU);
                if (bVar27 != iVar14 < 0) {
                    puVar18 = puVar22;
                }
                bVar27 = SBORROW4(iVar16, iVar8);
                iVar14 = iVar16 - iVar8;
                if (iVar16 == iVar8) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar24 + 4), *(int32_t *)((int64_t)puVar24 + 0xc));
                    iVar14 = *(int32_t *)((int64_t)puVar24 + 4) - *(int32_t *)((int64_t)puVar24 + 0xc);
                }
                puVar12 = puVar24 + 1;
                if (bVar27 != iVar14 < 0) {
                    puVar12 = puVar24;
                }
                iVar10 = (int32_t)*puVar12;
                iVar9 = (int32_t)*puVar18;
                bVar27 = SBORROW4(iVar9, iVar10);
                iVar14 = iVar9 - iVar10;
                if (iVar9 == iVar10) {
                    iVar10 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                    iVar14 = (int32_t)((uint64_t)*puVar18 >> 0x20);
                    bVar27 = SBORROW4(iVar14, iVar10);
                    iVar14 = iVar14 - iVar10;
                }
                if (bVar27 != iVar14 < 0) break;
                bVar27 = SBORROW4(iVar16, iVar8);
                iVar14 = iVar16 - iVar8;
                if (iVar16 == iVar8) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar24 + 4), *(int32_t *)((int64_t)puVar24 + 0xc));
                    iVar14 = *(int32_t *)((int64_t)puVar24 + 4) - *(int32_t *)((int64_t)puVar24 + 0xc);
                }
                puVar18 = puVar24 + 1;
                if (bVar27 != iVar14 < 0) {
                    puVar18 = puVar24;
                }
                bVar27 = SBORROW4(iVar7, iVar15);
                iVar14 = iVar7 - iVar15;
                if (iVar7 == iVar15) {
                    bVar27 = SBORROW4(*(int32_t *)(puVar24 + -2), *(int32_t *)(puVar24 + -1));
                    iVar14 = *(int32_t *)(puVar24 + -2) - *(int32_t *)(puVar24 + -1);
                }
                puVar12 = (undefined8 *)((int64_t)puVar24 - 0xcU);
                if (bVar27 != iVar14 < 0) {
                    puVar12 = puVar22;
                }
                iVar7 = (int32_t)*puVar12;
                iVar14 = (int32_t)*puVar18;
                bVar27 = SBORROW4(iVar14, iVar7);
                iVar15 = iVar14 - iVar7;
                if (iVar14 == iVar7) {
                    iVar7 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                    iVar15 = (int32_t)((uint64_t)*puVar18 >> 0x20);
                    bVar27 = SBORROW4(iVar15, iVar7);
                    iVar15 = iVar15 - iVar7;
                }
                if ((bVar27 != iVar15 < 0) || (puVar24 = puVar22, puVar22 <= (uint64_t)arg1)) break;
            }
        }
        puVar22 = puVar21;
        puVar12 = (undefined8 *)arg2;
        puVar18 = puVar24;
        if (puVar21 < (uint64_t)arg2) {
            iVar15 = *(int32_t *)puVar24;
            iVar7 = *(int32_t *)(puVar24 + 1);
            while( true ) {
                iVar14 = *(int32_t *)(puVar21 + 1);
                iVar8 = *(int32_t *)puVar21;
                bVar27 = SBORROW4(iVar8, iVar14);
                iVar16 = iVar8 - iVar14;
                if (iVar8 == iVar14) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar21 + 4), *(int32_t *)((int64_t)puVar21 + 0xc));
                    iVar16 = *(int32_t *)((int64_t)puVar21 + 4) - *(int32_t *)((int64_t)puVar21 + 0xc);
                }
                puVar22 = puVar21 + 1;
                if (bVar27 != iVar16 < 0) {
                    puVar22 = puVar21;
                }
                bVar27 = SBORROW4(iVar15, iVar7);
                iVar16 = iVar15 - iVar7;
                if (iVar15 == iVar7) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar24 + 4), *(int32_t *)((int64_t)puVar24 + 0xc));
                    iVar16 = *(int32_t *)((int64_t)puVar24 + 4) - *(int32_t *)((int64_t)puVar24 + 0xc);
                }
                puVar25 = puVar24 + 1;
                if (bVar27 != iVar16 < 0) {
                    puVar25 = puVar24;
                }
                iVar10 = (int32_t)*puVar25;
                iVar9 = (int32_t)*puVar22;
                bVar27 = SBORROW4(iVar9, iVar10);
                iVar16 = iVar9 - iVar10;
                if (iVar9 == iVar10) {
                    iVar10 = (int32_t)((uint64_t)*puVar25 >> 0x20);
                    iVar16 = (int32_t)((uint64_t)*puVar22 >> 0x20);
                    bVar27 = SBORROW4(iVar16, iVar10);
                    iVar16 = iVar16 - iVar10;
                }
                puVar22 = puVar21;
                if (bVar27 != iVar16 < 0) break;
                bVar27 = SBORROW4(iVar15, iVar7);
                iVar16 = iVar15 - iVar7;
                if (iVar15 == iVar7) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar24 + 4), *(int32_t *)((int64_t)puVar24 + 0xc));
                    iVar16 = *(int32_t *)((int64_t)puVar24 + 4) - *(int32_t *)((int64_t)puVar24 + 0xc);
                }
                puVar25 = puVar24 + 1;
                if (bVar27 != iVar16 < 0) {
                    puVar25 = puVar24;
                }
                bVar27 = SBORROW4(iVar8, iVar14);
                iVar16 = iVar8 - iVar14;
                if (iVar8 == iVar14) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar21 + 4), *(int32_t *)((int64_t)puVar21 + 0xc));
                    iVar16 = *(int32_t *)((int64_t)puVar21 + 4) - *(int32_t *)((int64_t)puVar21 + 0xc);
                }
                puVar13 = puVar21 + 1;
                if (bVar27 != iVar16 < 0) {
                    puVar13 = puVar21;
                }
                iVar8 = (int32_t)*puVar13;
                iVar16 = (int32_t)*puVar25;
                bVar27 = SBORROW4(iVar16, iVar8);
                iVar14 = iVar16 - iVar8;
                if (iVar16 == iVar8) {
                    iVar8 = (int32_t)((uint64_t)*puVar13 >> 0x20);
                    iVar14 = (int32_t)((uint64_t)*puVar25 >> 0x20);
                    bVar27 = SBORROW4(iVar14, iVar8);
                    iVar14 = iVar14 - iVar8;
                }
                if ((bVar27 != iVar14 < 0) ||
                   (puVar21 = (undefined8 *)((int64_t)puVar21 + 0x14), puVar22 = puVar21, (uint64_t)arg2 <= puVar21))
                break;
            }
        }
joined_r0x000180164273:
        if (puVar21 < puVar12) {
            iVar15 = *(int32_t *)(puVar18 + 1);
            iVar7 = *(int32_t *)puVar18;
            bVar27 = SBORROW4(iVar7, iVar15);
            iVar14 = iVar7 - iVar15;
            if (iVar7 == iVar15) {
                bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
                iVar14 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
            }
            iVar8 = *(int32_t *)(puVar21 + 1);
            iVar16 = *(int32_t *)puVar21;
            puVar25 = puVar18 + 1;
            if (bVar27 != iVar14 < 0) {
                puVar25 = puVar18;
            }
            bVar27 = SBORROW4(iVar16, iVar8);
            iVar14 = iVar16 - iVar8;
            if (iVar16 == iVar8) {
                bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar21 + 4), *(int32_t *)((int64_t)puVar21 + 0xc));
                iVar14 = *(int32_t *)((int64_t)puVar21 + 4) - *(int32_t *)((int64_t)puVar21 + 0xc);
            }
            puVar13 = puVar21 + 1;
            if (bVar27 != iVar14 < 0) {
                puVar13 = puVar21;
            }
            iVar10 = (int32_t)*puVar13;
            iVar9 = (int32_t)*puVar25;
            bVar27 = SBORROW4(iVar9, iVar10);
            iVar14 = iVar9 - iVar10;
            if (iVar9 == iVar10) {
                iVar10 = (int32_t)((uint64_t)*puVar13 >> 0x20);
                iVar14 = (int32_t)((uint64_t)*puVar25 >> 0x20);
                bVar27 = SBORROW4(iVar14, iVar10);
                iVar14 = iVar14 - iVar10;
            }
            if (bVar27 == iVar14 < 0) {
                bVar27 = SBORROW4(iVar16, iVar8);
                iVar14 = iVar16 - iVar8;
                if (iVar16 == iVar8) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar21 + 4), *(int32_t *)((int64_t)puVar21 + 0xc));
                    iVar14 = *(int32_t *)((int64_t)puVar21 + 4) - *(int32_t *)((int64_t)puVar21 + 0xc);
                }
                puVar25 = puVar21 + 1;
                if (bVar27 != iVar14 < 0) {
                    puVar25 = puVar21;
                }
                bVar27 = SBORROW4(iVar7, iVar15);
                iVar14 = iVar7 - iVar15;
                if (iVar7 == iVar15) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
                    iVar14 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
                }
                puVar13 = puVar18 + 1;
                if (bVar27 != iVar14 < 0) {
                    puVar13 = puVar18;
                }
                iVar7 = (int32_t)*puVar13;
                iVar14 = (int32_t)*puVar25;
                bVar27 = SBORROW4(iVar14, iVar7);
                iVar15 = iVar14 - iVar7;
                if (iVar14 == iVar7) {
                    iVar7 = (int32_t)((uint64_t)*puVar13 >> 0x20);
                    iVar15 = (int32_t)((uint64_t)*puVar25 >> 0x20);
                    bVar27 = SBORROW4(iVar15, iVar7);
                    iVar15 = iVar15 - iVar7;
                }
                arg1 = var_8h;
                if (bVar27 != iVar15 < 0) goto code_r0x00018016435c;
                if (puVar22 != puVar21) {
                    iVar7 = *(int32_t *)((int64_t)puVar21 + 4);
                    iVar14 = *(int32_t *)(puVar21 + 1);
                    iVar8 = *(int32_t *)((int64_t)puVar21 + 0xc);
                    iVar15 = *(int32_t *)(puVar22 + 2);
                    iVar16 = *(int32_t *)puVar22;
                    iVar10 = *(int32_t *)((int64_t)puVar22 + 4);
                    iVar9 = *(int32_t *)(puVar22 + 1);
                    iVar23 = *(int32_t *)((int64_t)puVar22 + 0xc);
                    *(int32_t *)puVar22 = *(int32_t *)puVar21;
                    *(int32_t *)((int64_t)puVar22 + 4) = iVar7;
                    *(int32_t *)(puVar22 + 1) = iVar14;
                    *(int32_t *)((int64_t)puVar22 + 0xc) = iVar8;
                    *(int32_t *)(puVar22 + 2) = *(int32_t *)(puVar21 + 2);
                    *(int32_t *)puVar21 = iVar16;
                    *(int32_t *)((int64_t)puVar21 + 4) = iVar10;
                    *(int32_t *)(puVar21 + 1) = iVar9;
                    *(int32_t *)((int64_t)puVar21 + 0xc) = iVar23;
                    *(int32_t *)(puVar21 + 2) = iVar15;
                }
                puVar22 = (undefined8 *)((int64_t)puVar22 + 0x14);
            }
            puVar21 = (undefined8 *)((int64_t)puVar21 + 0x14);
            arg1 = var_8h;
            goto joined_r0x000180164273;
        }
code_r0x00018016435c:
        bVar27 = puVar24 == (undefined8 *)arg1;
        arg2 = (int64_t)puVar18;
        if ((uint64_t)arg1 < puVar24) {
            do {
                iVar15 = *(int32_t *)((int64_t)puVar24 - 0xc);
                puVar12 = (undefined8 *)((int64_t)puVar24 - 0x14);
                iVar7 = *(int32_t *)puVar12;
                bVar27 = SBORROW4(iVar7, iVar15);
                iVar14 = iVar7 - iVar15;
                if (iVar7 == iVar15) {
                    bVar27 = SBORROW4(*(int32_t *)(puVar24 + -2), *(int32_t *)(puVar24 + -1));
                    iVar14 = *(int32_t *)(puVar24 + -2) - *(int32_t *)(puVar24 + -1);
                }
                iVar8 = *(int32_t *)(puVar18 + 1);
                iVar16 = *(int32_t *)puVar18;
                puVar25 = (undefined8 *)((int64_t)puVar24 - 0xcU);
                if (bVar27 != iVar14 < 0) {
                    puVar25 = puVar12;
                }
                bVar27 = SBORROW4(iVar16, iVar8);
                iVar14 = iVar16 - iVar8;
                if (iVar16 == iVar8) {
                    bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
                    iVar14 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
                }
                puVar13 = puVar18 + 1;
                if (bVar27 != iVar14 < 0) {
                    puVar13 = puVar18;
                }
                iVar10 = (int32_t)*puVar13;
                iVar9 = (int32_t)*puVar25;
                bVar27 = SBORROW4(iVar9, iVar10);
                iVar14 = iVar9 - iVar10;
                if (iVar9 == iVar10) {
                    iVar10 = (int32_t)((uint64_t)*puVar13 >> 0x20);
                    iVar14 = (int32_t)((uint64_t)*puVar25 >> 0x20);
                    bVar27 = SBORROW4(iVar14, iVar10);
                    iVar14 = iVar14 - iVar10;
                }
                arg2 = (int64_t)puVar18;
                if (bVar27 == iVar14 < 0) {
                    bVar27 = SBORROW4(iVar16, iVar8);
                    iVar14 = iVar16 - iVar8;
                    if (iVar16 == iVar8) {
                        bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
                        iVar14 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
                    }
                    puVar25 = puVar18 + 1;
                    if (bVar27 != iVar14 < 0) {
                        puVar25 = puVar18;
                    }
                    bVar27 = SBORROW4(iVar7, iVar15);
                    iVar14 = iVar7 - iVar15;
                    if (iVar7 == iVar15) {
                        bVar27 = SBORROW4(*(int32_t *)(puVar24 + -2), *(int32_t *)(puVar24 + -1));
                        iVar14 = *(int32_t *)(puVar24 + -2) - *(int32_t *)(puVar24 + -1);
                    }
                    puVar13 = (undefined8 *)((int64_t)puVar24 - 0xcU);
                    if (bVar27 != iVar14 < 0) {
                        puVar13 = puVar12;
                    }
                    iVar7 = (int32_t)*puVar13;
                    iVar14 = (int32_t)*puVar25;
                    bVar27 = SBORROW4(iVar14, iVar7);
                    iVar15 = iVar14 - iVar7;
                    if (iVar14 == iVar7) {
                        iVar7 = (int32_t)((uint64_t)*puVar13 >> 0x20);
                        iVar15 = (int32_t)((uint64_t)*puVar25 >> 0x20);
                        bVar27 = SBORROW4(iVar15, iVar7);
                        iVar15 = iVar15 - iVar7;
                    }
                    if (bVar27 != iVar15 < 0) break;
                    arg2 = (int64_t)puVar18 - 0x14;
                    if ((undefined8 *)arg2 != puVar12) {
                        iVar7 = *(int32_t *)(puVar24 + -2);
                        iVar14 = *(int32_t *)((int64_t)puVar24 - 0xc);
                        iVar8 = *(int32_t *)(puVar24 + -1);
                        iVar15 = *(int32_t *)((int64_t)puVar18 - 4);
                        iVar16 = *(int32_t *)arg2;
                        iVar10 = *(int32_t *)(puVar18 + -2);
                        iVar9 = *(int32_t *)((int64_t)puVar18 - 0xc);
                        iVar23 = *(int32_t *)(puVar18 + -1);
                        *(int32_t *)arg2 = *(int32_t *)puVar12;
                        *(int32_t *)(puVar18 + -2) = iVar7;
                        *(int32_t *)((int64_t)puVar18 - 0xc) = iVar14;
                        *(int32_t *)(puVar18 + -1) = iVar8;
                        *(int32_t *)((int64_t)puVar18 - 4) = *(int32_t *)((int64_t)puVar24 - 4);
                        *(int32_t *)puVar12 = iVar16;
                        *(int32_t *)(puVar24 + -2) = iVar10;
                        *(int32_t *)((int64_t)puVar24 - 0xc) = iVar9;
                        *(int32_t *)(puVar24 + -1) = iVar23;
                        *(int32_t *)((int64_t)puVar24 - 4) = iVar15;
                    }
                }
                puVar18 = (undefined8 *)arg2;
                puVar24 = puVar12;
            } while ((uint64_t)var_8h < puVar12);
            bVar27 = puVar24 == (undefined8 *)var_8h;
            arg1 = var_8h;
            puVar12 = (undefined8 *)var_10h;
        }
        if (!bVar27) {
            puVar25 = (undefined8 *)((int64_t)puVar24 - 0x14);
            if (puVar21 == puVar12) {
                puVar18 = (undefined8 *)(arg2 - 0x14);
                if (puVar25 != puVar18) {
                    iVar7 = *(int32_t *)(arg2 + -0x10);
                    iVar14 = *(int32_t *)(arg2 - 0xc);
                    iVar8 = *(int32_t *)(arg2 + -8);
                    iVar15 = *(int32_t *)((int64_t)puVar24 - 4);
                    iVar16 = *(int32_t *)puVar25;
                    iVar10 = *(int32_t *)(puVar24 + -2);
                    iVar9 = *(int32_t *)((int64_t)puVar24 - 0xc);
                    iVar23 = *(int32_t *)(puVar24 + -1);
                    *(int32_t *)puVar25 = *(int32_t *)puVar18;
                    *(int32_t *)(puVar24 + -2) = iVar7;
                    *(int32_t *)((int64_t)puVar24 - 0xc) = iVar14;
                    *(int32_t *)(puVar24 + -1) = iVar8;
                    *(int32_t *)((int64_t)puVar24 - 4) = *(int32_t *)(arg2 - 4);
                    *(int32_t *)puVar18 = iVar16;
                    *(int32_t *)(arg2 + -0x10) = iVar10;
                    *(int32_t *)(arg2 - 0xc) = iVar9;
                    *(int32_t *)(arg2 + -8) = iVar23;
                    *(int32_t *)(arg2 - 4) = iVar15;
                }
                iVar7 = *(int32_t *)(puVar22 + -2);
                iVar14 = *(int32_t *)((int64_t)puVar22 - 0xc);
                iVar8 = *(int32_t *)(puVar22 + -1);
                iVar15 = *(int32_t *)(arg2 - 4);
                iVar16 = *(int32_t *)puVar18;
                iVar10 = *(int32_t *)(arg2 + -0x10);
                iVar9 = *(int32_t *)(arg2 - 0xc);
                iVar23 = *(int32_t *)(arg2 + -8);
                *(int32_t *)puVar18 = *(int32_t *)((int64_t)puVar22 - 0x14);
                *(int32_t *)(arg2 + -0x10) = iVar7;
                *(int32_t *)(arg2 - 0xc) = iVar14;
                *(int32_t *)(arg2 + -8) = iVar8;
                *(int32_t *)(arg2 - 4) = *(int32_t *)((int64_t)puVar22 - 4);
                *(int32_t *)(undefined8 *)((int64_t)puVar22 - 0x14U) = iVar16;
                *(int32_t *)(puVar22 + -2) = iVar10;
                *(int32_t *)((int64_t)puVar22 - 0xc) = iVar9;
                *(int32_t *)(puVar22 + -1) = iVar23;
                *(int32_t *)((int64_t)puVar22 - 4) = iVar15;
                puVar22 = (undefined8 *)((int64_t)puVar22 - 0x14U);
                puVar24 = puVar25;
            } else {
                iVar7 = *(int32_t *)puVar21;
                iVar14 = *(int32_t *)((int64_t)puVar21 + 4);
                iVar8 = *(int32_t *)(puVar21 + 1);
                iVar16 = *(int32_t *)((int64_t)puVar21 + 0xc);
                iVar15 = *(int32_t *)(puVar21 + 2);
                iVar10 = *(int32_t *)(puVar24 + -2);
                iVar9 = *(int32_t *)((int64_t)puVar24 - 0xc);
                iVar23 = *(int32_t *)(puVar24 + -1);
                *(int32_t *)puVar21 = *(int32_t *)puVar25;
                *(int32_t *)((int64_t)puVar21 + 4) = iVar10;
                *(int32_t *)(puVar21 + 1) = iVar9;
                *(int32_t *)((int64_t)puVar21 + 0xc) = iVar23;
                *(int32_t *)(puVar21 + 2) = *(int32_t *)((int64_t)puVar24 - 4);
                puVar21 = (undefined8 *)((int64_t)puVar21 + 0x14);
                *(int32_t *)puVar25 = iVar7;
                *(int32_t *)(puVar24 + -2) = iVar14;
                *(int32_t *)((int64_t)puVar24 - 0xc) = iVar8;
                *(int32_t *)(puVar24 + -1) = iVar16;
                *(int32_t *)((int64_t)puVar24 - 4) = iVar15;
                puVar24 = puVar25;
                puVar18 = (undefined8 *)arg2;
            }
            goto joined_r0x000180164273;
        }
        if (puVar21 != puVar12) {
            if (puVar22 != puVar21) {
                iVar7 = *(int32_t *)((int64_t)puVar22 + 4);
                iVar14 = *(int32_t *)(puVar22 + 1);
                iVar8 = *(int32_t *)((int64_t)puVar22 + 0xc);
                iVar15 = *(int32_t *)(arg2 + 0x10);
                iVar16 = *(int32_t *)arg2;
                iVar10 = *(int32_t *)(arg2 + 4);
                iVar9 = *(int32_t *)(arg2 + 8);
                iVar23 = *(int32_t *)(arg2 + 0xc);
                *(int32_t *)arg2 = *(int32_t *)puVar22;
                *(int32_t *)(arg2 + 4) = iVar7;
                *(int32_t *)(arg2 + 8) = iVar14;
                *(int32_t *)(arg2 + 0xc) = iVar8;
                *(int32_t *)(arg2 + 0x10) = *(int32_t *)(puVar22 + 2);
                *(int32_t *)puVar22 = iVar16;
                *(int32_t *)((int64_t)puVar22 + 4) = iVar10;
                *(int32_t *)(puVar22 + 1) = iVar9;
                *(int32_t *)((int64_t)puVar22 + 0xc) = iVar23;
                *(int32_t *)(puVar22 + 2) = iVar15;
            }
            iVar7 = *(int32_t *)((int64_t)puVar21 + 4);
            iVar14 = *(int32_t *)(puVar21 + 1);
            iVar8 = *(int32_t *)((int64_t)puVar21 + 0xc);
            iVar15 = *(int32_t *)(arg2 + 0x10);
            iVar16 = *(int32_t *)arg2;
            iVar10 = *(int32_t *)(arg2 + 4);
            iVar9 = *(int32_t *)(arg2 + 8);
            iVar23 = *(int32_t *)(arg2 + 0xc);
            *(int32_t *)arg2 = *(int32_t *)puVar21;
            *(int32_t *)(arg2 + 4) = iVar7;
            *(int32_t *)(arg2 + 8) = iVar14;
            *(int32_t *)(arg2 + 0xc) = iVar8;
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(puVar21 + 2);
            *(int32_t *)puVar21 = iVar16;
            *(int32_t *)((int64_t)puVar21 + 4) = iVar10;
            *(int32_t *)(puVar21 + 1) = iVar9;
            *(int32_t *)((int64_t)puVar21 + 0xc) = iVar23;
            *(int32_t *)(puVar21 + 2) = iVar15;
            puVar21 = (undefined8 *)((int64_t)puVar21 + 0x14);
            puVar22 = (undefined8 *)((int64_t)puVar22 + 0x14);
            puVar18 = (undefined8 *)(arg2 + 0x14);
            goto joined_r0x000180164273;
        }
        arg3 = (arg3 >> 2) + (arg3 >> 1);
        if ((arg2 - arg1 >> 2) * -0x3333333333333333 < ((int64_t)puVar12 - (int64_t)puVar22 >> 2) * -0x3333333333333333)
        {
            fcn.180163fc0(arg1, arg2, arg3);
            arg1 = (int64_t)puVar22;
            arg2 = (int64_t)puVar12;
            var_8h = (int64_t)puVar22;
        } else {
            fcn.180163fc0((int64_t)puVar22, (int64_t)puVar12, arg3);
            var_10h = arg2;
        }
        iVar11 = arg2 - arg1;
    } while( true );
}

// ============================================================
// Function: FUN_1801649f0
// Address: 0x1801649f0
// Size: 624 bytes
// ============================================================
void fcn.1801649f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    undefined *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    
    if (arg4 == 0) {
        return;
    }
    puVar7 = auStack_88;
    puVar8 = auStack_88;
    piVar1 = (int64_t *)(arg1 + 8);
    iVar9 = *piVar1;
    if ((uint64_t)arg4 <= (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar9 >> 2)) {
        uVar6 = iVar9 - arg2 >> 2;
        iVar2 = arg4 * 4;
        var_68h = (int64_t)piVar1;
        if ((uint64_t)arg4 < uVar6) {
            iVar4 = iVar9 + arg4 * -4;
            func_0x000180498030(iVar9, iVar4, iVar2);
            *piVar1 = iVar9 + (iVar2 >> 2) * 4;
            iVar4 = iVar4 - arg2;
            func_0x000180498030(iVar9 - iVar4, arg2, iVar4);
            func_0x000180498030(arg2, arg3, iVar2);
        } else {
            func_0x000180498030(iVar2 + arg2, arg2);
            *piVar1 = iVar2 + arg2 + uVar6 * 4;
            func_0x000180498030(arg2, arg3, iVar2);
        }
        return;
    }
    iVar2 = *(int64_t *)arg1;
    iVar4 = iVar9 - iVar2 >> 2;
    if (0x3fffffffffffffffU - iVar4 < (uint64_t)arg4) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar6 = *(int64_t *)(arg1 + 0x10) - iVar2 >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        var_68h = iVar4 + arg4;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar10 = var_68h;
        if ((uint64_t)var_68h <= uVar6) {
            uVar10 = uVar6;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar6 = uVar10 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar8 = auStack_88;
            } else if (uVar6 < 0x1000) {
                uVar6 = func_0x000180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x000180164c5a;
                iVar4 = func_0x000180459890(uVar6 + 0x27);
                if (iVar4 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar4 = (*pcVar3)(5);
                    puVar7 = auStack_80;
                }
                uVar6 = iVar4 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar4;
                puVar8 = puVar7;
            }
            *(int64_t *)(puVar8 + 0xa8) = arg2 - iVar2;
            iVar4 = arg2 - iVar2 >> 2;
            *(int64_t *)(puVar8 + 0x90) = iVar4;
            *(undefined8 *)(puVar8 + -8) = 0x180164b2f;
            func_0x000180498030(uVar6 + iVar4 * 4, *(undefined8 *)(puVar8 + 0xa0), arg4 * 4);
            if ((arg4 == 1) && (arg2 == iVar9)) {
                iVar9 = *(int64_t *)(puVar8 + 0x98);
                uVar5 = uVar6;
                arg2 = iVar2;
            } else {
                *(undefined8 *)(puVar8 + -8) = 0x180164b5d;
                func_0x000180498030(uVar6, iVar2, *(undefined8 *)(puVar8 + 0xa8));
                iVar9 = iVar9 - arg2;
                uVar5 = uVar6 + (*(int64_t *)(puVar8 + 0x90) + arg4) * 4;
            }
            *(undefined8 *)(puVar8 + -8) = 0x180164b7a;
            func_0x000180498030(uVar5, arg2, iVar9);
            *(undefined8 *)(puVar8 + -8) = 0x180164b8d;
            func_0x000180030d40(arg1, uVar6, *(undefined8 *)(puVar8 + 0x20), uVar10);
            return;
        }
    }
code_r0x000180164c5a:
    func_0x000180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180164cd0
// Address: 0x180164cd0
// Size: 204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180164cd0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (arg1 != arg2) {
        iVar1 = *(int64_t *)arg1;
        if (iVar1 != 0) {
            iVar3 = iVar1;
            puVar4 = auStack_28;
            if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar1 >> 2) * 4)) &&
               (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
                iVar3 = 5;
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar4 = auStack_20;
            }
            *(undefined8 *)(puVar4 + -8) = 0x180164d39;
            func_0x000180459c3c(iVar3);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
        }
        *(undefined8 *)arg1 = *(undefined8 *)arg2;
        *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg2 + 8);
        *(undefined8 *)(arg1 + 0x10) = *(undefined8 *)(arg2 + 0x10);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)(arg2 + 0x10) = 0;
    }
    *(undefined *)(arg1 + 0x18) = *(undefined *)(arg2 + 0x18);
    *(undefined8 *)(arg1 + 0x20) = *(undefined8 *)(arg2 + 0x20);
    *(undefined4 *)(arg1 + 0x28) = *(undefined4 *)(arg2 + 0x28);
    *(undefined *)(arg1 + 0x2c) = *(undefined *)(arg2 + 0x2c);
    *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg2 + 0x30);
    return arg1;
}

// ============================================================
// Function: FUN_180164da0
// Address: 0x180164da0
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180164da0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    piVar1 = (int64_t *)(arg1 + 0x10);
    func_0x00018007c820(arg1 + 0x50);
    func_0x00018007c820(arg1 + 0x28);
    iVar4 = *piVar1;
    if (iVar4 != 0) {
        iVar3 = *(int64_t *)(arg1 + 0x18);
        for (; iVar4 != iVar3; iVar4 = iVar4 + 0x38) {
            func_0x000180004e40(iVar4 + 0x18);
        }
        iVar4 = *piVar1;
        iVar3 = iVar4;
        puVar5 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x20) - iVar4 >> 3) * 8)) &&
           (iVar3 = *(int64_t *)(iVar4 + -8), puVar5 = auStack_28, 0x1f < (iVar4 - iVar3) - 8U)) {
            iVar3 = 5;
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c0a20;
        func_0x000180459c3c(iVar3);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180164dd0
// Address: 0x180164dd0
// Size: 43 bytes
// ============================================================
int64_t fcn.180164dd0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180645d88;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x78);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180164e00
// Address: 0x180164e00
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.180164e00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar8 = auStack_38;
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 8) - iVar3 >> 2;
    if (iVar11 == 0x3fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar7 = (undefined4 *)(*pcVar4)();
        return puVar7;
    }
    uVar5 = *(int64_t *)(arg1 + 0x10) - iVar3 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar7 = (undefined4 *)0x0;
                puVar9 = auStack_38;
            } else if (uVar5 < 0x1000) {
                puVar7 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x000180164f52;
                iVar11 = func_0x000180459890(uVar5 + 0x27);
                if (iVar11 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar11 = (*pcVar4)(5);
                    puVar8 = auStack_30;
                }
                puVar7 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar7 + -2) = iVar11;
                puVar9 = puVar8;
            }
            puVar2 = puVar7 + (arg2 - iVar3 >> 2);
            *puVar2 = *(undefined4 *)arg3;
            iVar3 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar11 = *(int64_t *)(arg1 + 8) - iVar3;
                puVar6 = puVar7;
                arg2 = iVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180164f07;
                func_0x000180498030(puVar7, iVar3, arg2 - iVar3);
                puVar6 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180164f1a;
            func_0x000180498030(puVar6, arg2, iVar11);
            *(undefined8 *)(puVar9 + -8) = 0x180164f2b;
            func_0x000180030d40(arg1, puVar7, uVar1, uVar10);
            return puVar2;
        }
    }
code_r0x000180164f52:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar7 = (undefined4 *)(*pcVar4)();
    return puVar7;
}

// ============================================================
// Function: FUN_180164e42
// Address: 0x180164e42
// Size: 266 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.180164e00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar8 = auStack_38;
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 8) - iVar3 >> 2;
    if (iVar11 == 0x3fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar7 = (undefined4 *)(*pcVar4)();
        return puVar7;
    }
    uVar5 = *(int64_t *)(arg1 + 0x10) - iVar3 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar7 = (undefined4 *)0x0;
                puVar9 = auStack_38;
            } else if (uVar5 < 0x1000) {
                puVar7 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x000180164f52;
                iVar11 = func_0x000180459890(uVar5 + 0x27);
                if (iVar11 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar11 = (*pcVar4)(5);
                    puVar8 = auStack_30;
                }
                puVar7 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar7 + -2) = iVar11;
                puVar9 = puVar8;
            }
            puVar2 = puVar7 + (arg2 - iVar3 >> 2);
            *puVar2 = *(undefined4 *)arg3;
            iVar3 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar11 = *(int64_t *)(arg1 + 8) - iVar3;
                puVar6 = puVar7;
                arg2 = iVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180164f07;
                func_0x000180498030(puVar7, iVar3, arg2 - iVar3);
                puVar6 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180164f1a;
            func_0x000180498030(puVar6, arg2, iVar11);
            *(undefined8 *)(puVar9 + -8) = 0x180164f2b;
            func_0x000180030d40(arg1, puVar7, uVar1, uVar10);
            return puVar2;
        }
    }
code_r0x000180164f52:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar7 = (undefined4 *)(*pcVar4)();
    return puVar7;
}

// ============================================================
// Function: FUN_180164f4c
// Address: 0x180164f4c
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.180164e00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar8 = auStack_38;
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 8) - iVar3 >> 2;
    if (iVar11 == 0x3fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar7 = (undefined4 *)(*pcVar4)();
        return puVar7;
    }
    uVar5 = *(int64_t *)(arg1 + 0x10) - iVar3 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar7 = (undefined4 *)0x0;
                puVar9 = auStack_38;
            } else if (uVar5 < 0x1000) {
                puVar7 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x000180164f52;
                iVar11 = func_0x000180459890(uVar5 + 0x27);
                if (iVar11 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar11 = (*pcVar4)(5);
                    puVar8 = auStack_30;
                }
                puVar7 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar7 + -2) = iVar11;
                puVar9 = puVar8;
            }
            puVar2 = puVar7 + (arg2 - iVar3 >> 2);
            *puVar2 = *(undefined4 *)arg3;
            iVar3 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar11 = *(int64_t *)(arg1 + 8) - iVar3;
                puVar6 = puVar7;
                arg2 = iVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180164f07;
                func_0x000180498030(puVar7, iVar3, arg2 - iVar3);
                puVar6 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180164f1a;
            func_0x000180498030(puVar6, arg2, iVar11);
            *(undefined8 *)(puVar9 + -8) = 0x180164f2b;
            func_0x000180030d40(arg1, puVar7, uVar1, uVar10);
            return puVar2;
        }
    }
code_r0x000180164f52:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar7 = (undefined4 *)(*pcVar4)();
    return puVar7;
}

// ============================================================
// Function: FUN_180164f52
// Address: 0x180164f52
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.180164e00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar8 = auStack_38;
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 8) - iVar3 >> 2;
    if (iVar11 == 0x3fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar7 = (undefined4 *)(*pcVar4)();
        return puVar7;
    }
    uVar5 = *(int64_t *)(arg1 + 0x10) - iVar3 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar7 = (undefined4 *)0x0;
                puVar9 = auStack_38;
            } else if (uVar5 < 0x1000) {
                puVar7 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x000180164f52;
                iVar11 = func_0x000180459890(uVar5 + 0x27);
                if (iVar11 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar11 = (*pcVar4)(5);
                    puVar8 = auStack_30;
                }
                puVar7 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar7 + -2) = iVar11;
                puVar9 = puVar8;
            }
            puVar2 = puVar7 + (arg2 - iVar3 >> 2);
            *puVar2 = *(undefined4 *)arg3;
            iVar3 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar11 = *(int64_t *)(arg1 + 8) - iVar3;
                puVar6 = puVar7;
                arg2 = iVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180164f07;
                func_0x000180498030(puVar7, iVar3, arg2 - iVar3);
                puVar6 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180164f1a;
            func_0x000180498030(puVar6, arg2, iVar11);
            *(undefined8 *)(puVar9 + -8) = 0x180164f2b;
            func_0x000180030d40(arg1, puVar7, uVar1, uVar10);
            return puVar2;
        }
    }
code_r0x000180164f52:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar7 = (undefined4 *)(*pcVar4)();
    return puVar7;
}

// ============================================================
// Function: FUN_180164f60
// Address: 0x180164f60
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180164f60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    
    fcn.180498030(arg3, arg1, arg2 - arg1);
    return arg3 + (arg2 - arg1 >> 2) * 4;
}

// ============================================================
// Function: FUN_180164fa0
// Address: 0x180164fa0
// Size: 1396 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180164fa0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined8 *puVar11;
    uint64_t uVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    undefined8 *puVar16;
    undefined8 *puVar17;
    undefined8 *arg1_00;
    undefined8 *puVar18;
    int64_t iVar19;
    int64_t var_58h;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar12 = arg2 - arg1;
    do {
        if ((int64_t)(uVar12 & 0xfffffffffffffff0) < 0x201) {
            puVar16 = (undefined8 *)arg1;
            if (arg1 != arg2) {
                while (puVar17 = puVar16 + 2, puVar17 != (undefined8 *)arg2) {
                    uVar12 = puVar16[3];
                    uVar3 = *puVar17;
                    if (uVar12 < *(uint64_t *)(arg1 + 8)) {
                        fcn.180498030((int64_t)puVar16 + (0x20 - ((int64_t)puVar17 - arg1)), arg1, 
                                      (int64_t)puVar17 - arg1);
                        *(undefined8 *)arg1 = uVar3;
                        *(uint64_t *)(arg1 + 8) = uVar12;
                        puVar16 = puVar17;
                    } else {
                        uVar2 = puVar16[1];
                        puVar16 = puVar17;
                        while (uVar12 < uVar2) {
                            *(undefined4 *)puVar16 = *(undefined4 *)(puVar16 + -2);
                            *(undefined4 *)((int64_t)puVar16 + 4) = *(undefined4 *)((int64_t)puVar16 + -0xc);
                            *(undefined4 *)(puVar16 + 1) = *(undefined4 *)(puVar16 + -1);
                            *(undefined4 *)((int64_t)puVar16 + 0xc) = *(undefined4 *)((int64_t)puVar16 + -4);
                            uVar2 = puVar16[-3];
                            puVar16 = puVar16 + -2;
                        }
                        *puVar16 = uVar3;
                        puVar16[1] = uVar12;
                        puVar16 = puVar17;
                    }
                }
            }
            return;
        }
        iVar19 = arg2 - arg1 >> 5;
        if (arg3 < 1) {
            uVar12 = arg2 - arg1 >> 4;
            if (0 < iVar19) {
                iVar13 = (int64_t)(uVar12 - 1) >> 1;
                do {
                    iVar19 = iVar19 + -1;
                    uVar3 = *(undefined8 *)(arg1 + iVar19 * 2 * 8);
                    uVar2 = *(uint64_t *)(arg1 + (iVar19 * 2 + 1) * 8);
                    iVar1 = iVar19;
                    while (iVar1 < iVar13) {
                        iVar15 = (2 - (uint64_t)
                                      (*(uint64_t *)(arg1 + (iVar1 * 4 + 5) * 8) <
                                      *(uint64_t *)(arg1 + ((iVar1 * 2 + 1) * 2 + 1) * 8))) + iVar1 * 2;
                        puVar16 = (undefined8 *)(arg1 + iVar15 * 2 * 8);
                        uVar4 = *(undefined4 *)((int64_t)puVar16 + 4);
                        uVar5 = *(undefined4 *)(puVar16 + 1);
                        uVar6 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                        puVar17 = (undefined8 *)(arg1 + iVar1 * 2 * 8);
                        *(undefined4 *)puVar17 = *(undefined4 *)puVar16;
                        *(undefined4 *)((int64_t)puVar17 + 4) = uVar4;
                        *(undefined4 *)(puVar17 + 1) = uVar5;
                        *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar6;
                        iVar1 = iVar15;
                    }
                    if ((iVar1 == iVar13) && ((uVar12 & 1) == 0)) {
                        puVar17 = (undefined8 *)(arg1 + (uVar12 * 2 + -2) * 8);
                        uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
                        uVar5 = *(undefined4 *)(puVar17 + 1);
                        uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                        puVar16 = (undefined8 *)(arg1 + iVar1 * 2 * 8);
                        *(undefined4 *)puVar16 = *(undefined4 *)puVar17;
                        *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                        *(undefined4 *)(puVar16 + 1) = uVar5;
                        *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                        iVar1 = uVar12 - 1;
                    }
                    while ((iVar19 < iVar1 &&
                           (iVar15 = iVar1 + -1 >> 1, *(uint64_t *)(arg1 + (iVar15 * 2 + 1) * 8) < uVar2))) {
                        puVar16 = (undefined8 *)(arg1 + iVar15 * 2 * 8);
                        uVar4 = *(undefined4 *)((int64_t)puVar16 + 4);
                        uVar5 = *(undefined4 *)(puVar16 + 1);
                        uVar6 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                        puVar17 = (undefined8 *)(arg1 + iVar1 * 2 * 8);
                        *(undefined4 *)puVar17 = *(undefined4 *)puVar16;
                        *(undefined4 *)((int64_t)puVar17 + 4) = uVar4;
                        *(undefined4 *)(puVar17 + 1) = uVar5;
                        *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar6;
                        iVar1 = iVar15;
                    }
                    *(undefined8 *)(arg1 + iVar1 * 2 * 8) = uVar3;
                    *(uint64_t *)(arg1 + (iVar1 * 2 + 1) * 8) = uVar2;
                } while (0 < iVar19);
            }
            if ((int64_t)uVar12 < 2) {
                return;
            }
            do {
                puVar16 = (undefined8 *)(arg2 + -0x10);
                if (0x1f < (int64_t)(arg2 - arg1 & 0xfffffffffffffff0U)) {
                    var_48h._0_4_ = *(undefined4 *)puVar16;
                    var_48h._4_4_ = *(undefined4 *)(arg2 + -0xc);
                    uStack_40 = *(undefined4 *)(arg2 + -8);
                    uStack_3c = *(undefined4 *)(arg2 + -4);
                    uVar4 = *(undefined4 *)(arg1 + 4);
                    uVar5 = *(undefined4 *)(arg1 + 8);
                    uVar6 = *(undefined4 *)(arg1 + 0xc);
                    *(undefined4 *)puVar16 = *(undefined4 *)arg1;
                    *(undefined4 *)(arg2 + -0xc) = uVar4;
                    *(undefined4 *)(arg2 + -8) = uVar5;
                    *(undefined4 *)(arg2 + -4) = uVar6;
                    func_0x000180165d30(arg1, 0, (int64_t)puVar16 - arg1 >> 4, &var_48h);
                }
                arg2 = (int64_t)puVar16;
            } while (0x1f < (int64_t)(arg2 - arg1 & 0xfffffffffffffff0U));
            return;
        }
        iVar13 = arg2 + (-0x10 - arg1) >> 4;
        puVar16 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
        if (iVar13 < 0x29) {
            if ((uint64_t)puVar16[1] < *(uint64_t *)(arg1 + 8)) {
                uVar4 = *(undefined4 *)(arg1 + 4);
                uVar5 = *(undefined4 *)(arg1 + 8);
                uVar6 = *(undefined4 *)(arg1 + 0xc);
                uVar7 = *(undefined4 *)puVar16;
                uVar8 = *(undefined4 *)((int64_t)puVar16 + 4);
                uVar9 = *(undefined4 *)(puVar16 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                *(undefined4 *)puVar16 = *(undefined4 *)arg1;
                *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                *(undefined4 *)(puVar16 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                *(undefined4 *)arg1 = uVar7;
                *(undefined4 *)(arg1 + 4) = uVar8;
                *(undefined4 *)(arg1 + 8) = uVar9;
                *(undefined4 *)(arg1 + 0xc) = uVar10;
            }
            if (*(uint64_t *)(arg2 + -8) < (uint64_t)puVar16[1]) {
                uVar4 = *(undefined4 *)((int64_t)puVar16 + 4);
                uVar5 = *(undefined4 *)(puVar16 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                uVar7 = *(undefined4 *)(arg2 + -0x10);
                uVar8 = *(undefined4 *)(arg2 + -0xc);
                uVar9 = *(undefined4 *)(arg2 + -8);
                uVar10 = *(undefined4 *)(arg2 + -4);
                *(undefined4 *)(arg2 + -0x10) = *(undefined4 *)puVar16;
                *(undefined4 *)(arg2 + -0xc) = uVar4;
                *(undefined4 *)(arg2 + -8) = uVar5;
                *(undefined4 *)(arg2 + -4) = uVar6;
                *(undefined4 *)puVar16 = uVar7;
                *(undefined4 *)((int64_t)puVar16 + 4) = uVar8;
                *(undefined4 *)(puVar16 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar10;
                if ((uint64_t)puVar16[1] < *(uint64_t *)(arg1 + 8)) {
                    uVar4 = *(undefined4 *)(arg1 + 4);
                    uVar5 = *(undefined4 *)(arg1 + 8);
                    uVar6 = *(undefined4 *)(arg1 + 0xc);
                    *(undefined4 *)puVar16 = *(undefined4 *)arg1;
                    *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                    *(undefined4 *)(puVar16 + 1) = uVar5;
                    *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                    *(undefined4 *)arg1 = uVar7;
                    *(undefined4 *)(arg1 + 4) = uVar8;
                    *(undefined4 *)(arg1 + 8) = uVar9;
                    *(undefined4 *)(arg1 + 0xc) = uVar10;
                }
            }
        } else {
            iVar19 = iVar13 + 1 >> 3;
            if (*(uint64_t *)(arg1 + (iVar19 * 2 + 1) * 8) < *(uint64_t *)(arg1 + 8)) {
                uVar4 = *(undefined4 *)(arg1 + 4);
                uVar5 = *(undefined4 *)(arg1 + 8);
                uVar6 = *(undefined4 *)(arg1 + 0xc);
                puVar17 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                uVar7 = *(undefined4 *)puVar17;
                uVar8 = *(undefined4 *)((int64_t)puVar17 + 4);
                uVar9 = *(undefined4 *)(puVar17 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                puVar17 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                *(undefined4 *)puVar17 = *(undefined4 *)arg1;
                *(undefined4 *)((int64_t)puVar17 + 4) = uVar4;
                *(undefined4 *)(puVar17 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar6;
                *(undefined4 *)arg1 = uVar7;
                *(undefined4 *)(arg1 + 4) = uVar8;
                *(undefined4 *)(arg1 + 8) = uVar9;
                *(undefined4 *)(arg1 + 0xc) = uVar10;
            }
            if (*(uint64_t *)(arg1 + (iVar19 * 4 + 1) * 8) < *(uint64_t *)(arg1 + (iVar19 * 2 + 1) * 8)) {
                puVar17 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
                uVar5 = *(undefined4 *)(puVar17 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                puVar14 = (undefined8 *)(arg1 + iVar19 * 4 * 8);
                uVar7 = *(undefined4 *)puVar14;
                uVar8 = *(undefined4 *)((int64_t)puVar14 + 4);
                uVar9 = *(undefined4 *)(puVar14 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar14 + 0xc);
                puVar14 = (undefined8 *)(arg1 + iVar19 * 4 * 8);
                *(undefined4 *)puVar14 = *(undefined4 *)puVar17;
                *(undefined4 *)((int64_t)puVar14 + 4) = uVar4;
                *(undefined4 *)(puVar14 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar14 + 0xc) = uVar6;
                puVar17 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                *(undefined4 *)puVar17 = uVar7;
                *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
                *(undefined4 *)(puVar17 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
                if (*(uint64_t *)(arg1 + (iVar19 * 2 + 1) * 8) < *(uint64_t *)(arg1 + 8)) {
                    uVar4 = *(undefined4 *)(arg1 + 4);
                    uVar5 = *(undefined4 *)(arg1 + 8);
                    uVar6 = *(undefined4 *)(arg1 + 0xc);
                    puVar17 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                    *(undefined4 *)puVar17 = *(undefined4 *)arg1;
                    *(undefined4 *)((int64_t)puVar17 + 4) = uVar4;
                    *(undefined4 *)(puVar17 + 1) = uVar5;
                    *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar6;
                    *(undefined4 *)arg1 = uVar7;
                    *(undefined4 *)(arg1 + 4) = uVar8;
                    *(undefined4 *)(arg1 + 8) = uVar9;
                    *(undefined4 *)(arg1 + 0xc) = uVar10;
                }
            }
            puVar17 = puVar16 + iVar19 * -2;
            if ((uint64_t)puVar16[1] < (uint64_t)puVar17[1]) {
                uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
                uVar5 = *(undefined4 *)(puVar17 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                uVar7 = *(undefined4 *)puVar16;
                uVar8 = *(undefined4 *)((int64_t)puVar16 + 4);
                uVar9 = *(undefined4 *)(puVar16 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                *(undefined4 *)puVar16 = *(undefined4 *)puVar17;
                *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                *(undefined4 *)(puVar16 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                *(undefined4 *)puVar17 = uVar7;
                *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
                *(undefined4 *)(puVar17 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
            }
            if ((uint64_t)puVar16[iVar19 * 2 + 1] < (uint64_t)puVar16[1]) {
                uVar4 = *(undefined4 *)((int64_t)puVar16 + 4);
                uVar5 = *(undefined4 *)(puVar16 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                puVar14 = puVar16 + iVar19 * 2;
                uVar7 = *(undefined4 *)puVar14;
                uVar8 = *(undefined4 *)((int64_t)puVar14 + 4);
                uVar9 = *(undefined4 *)(puVar14 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar14 + 0xc);
                puVar14 = puVar16 + iVar19 * 2;
                *(undefined4 *)puVar14 = *(undefined4 *)puVar16;
                *(undefined4 *)((int64_t)puVar14 + 4) = uVar4;
                *(undefined4 *)(puVar14 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar14 + 0xc) = uVar6;
                *(undefined4 *)puVar16 = uVar7;
                *(undefined4 *)((int64_t)puVar16 + 4) = uVar8;
                *(undefined4 *)(puVar16 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar10;
                if ((uint64_t)puVar16[1] < (uint64_t)puVar17[1]) {
                    uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
                    uVar5 = *(undefined4 *)(puVar17 + 1);
                    uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                    *(undefined4 *)puVar16 = *(undefined4 *)puVar17;
                    *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                    *(undefined4 *)(puVar16 + 1) = uVar5;
                    *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                    *(undefined4 *)puVar17 = uVar7;
                    *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
                    *(undefined4 *)(puVar17 + 1) = uVar9;
                    *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
                }
            }
            puVar14 = (undefined8 *)(arg2 + (iVar19 * -4 + -2) * 8);
            puVar17 = (undefined8 *)(arg2 + (iVar19 * -2 + -2) * 8);
            if ((uint64_t)puVar17[1] < (uint64_t)puVar14[1]) {
                uVar4 = *(undefined4 *)((int64_t)puVar14 + 4);
                uVar5 = *(undefined4 *)(puVar14 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar14 + 0xc);
                uVar7 = *(undefined4 *)puVar17;
                uVar8 = *(undefined4 *)((int64_t)puVar17 + 4);
                uVar9 = *(undefined4 *)(puVar17 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                *(undefined4 *)puVar17 = *(undefined4 *)puVar14;
                *(undefined4 *)((int64_t)puVar17 + 4) = uVar4;
                *(undefined4 *)(puVar17 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar6;
                *(undefined4 *)puVar14 = uVar7;
                *(undefined4 *)((int64_t)puVar14 + 4) = uVar8;
                *(undefined4 *)(puVar14 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar14 + 0xc) = uVar10;
            }
            if (*(uint64_t *)(arg2 + -8) < (uint64_t)puVar17[1]) {
                uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
                uVar5 = *(undefined4 *)(puVar17 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                uVar7 = *(undefined4 *)(arg2 + -0x10);
                uVar8 = *(undefined4 *)(arg2 + -0xc);
                uVar9 = *(undefined4 *)(arg2 + -8);
                uVar10 = *(undefined4 *)(arg2 + -4);
                *(undefined4 *)(arg2 + -0x10) = *(undefined4 *)puVar17;
                *(undefined4 *)(arg2 + -0xc) = uVar4;
                *(undefined4 *)(arg2 + -8) = uVar5;
                *(undefined4 *)(arg2 + -4) = uVar6;
                *(undefined4 *)puVar17 = uVar7;
                *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
                *(undefined4 *)(puVar17 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
                if ((uint64_t)puVar17[1] < (uint64_t)puVar14[1]) {
                    uVar4 = *(undefined4 *)((int64_t)puVar14 + 4);
                    uVar5 = *(undefined4 *)(puVar14 + 1);
                    uVar6 = *(undefined4 *)((int64_t)puVar14 + 0xc);
                    *(undefined4 *)puVar17 = *(undefined4 *)puVar14;
                    *(undefined4 *)((int64_t)puVar17 + 4) = uVar4;
                    *(undefined4 *)(puVar17 + 1) = uVar5;
                    *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar6;
                    *(undefined4 *)puVar14 = uVar7;
                    *(undefined4 *)((int64_t)puVar14 + 4) = uVar8;
                    *(undefined4 *)(puVar14 + 1) = uVar9;
                    *(undefined4 *)((int64_t)puVar14 + 0xc) = uVar10;
                }
            }
            if ((uint64_t)puVar16[1] < *(uint64_t *)(arg1 + (iVar19 * 2 + 1) * 8)) {
                puVar14 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                uVar4 = *(undefined4 *)((int64_t)puVar14 + 4);
                uVar5 = *(undefined4 *)(puVar14 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar14 + 0xc);
                uVar7 = *(undefined4 *)puVar16;
                uVar8 = *(undefined4 *)((int64_t)puVar16 + 4);
                uVar9 = *(undefined4 *)(puVar16 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                *(undefined4 *)puVar16 = *(undefined4 *)puVar14;
                *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                *(undefined4 *)(puVar16 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                puVar14 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                *(undefined4 *)puVar14 = uVar7;
                *(undefined4 *)((int64_t)puVar14 + 4) = uVar8;
                *(undefined4 *)(puVar14 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar14 + 0xc) = uVar10;
            }
            if ((uint64_t)puVar17[1] < (uint64_t)puVar16[1]) {
                uVar4 = *(undefined4 *)((int64_t)puVar16 + 4);
                uVar5 = *(undefined4 *)(puVar16 + 1);
                uVar6 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                uVar7 = *(undefined4 *)puVar17;
                uVar8 = *(undefined4 *)((int64_t)puVar17 + 4);
                uVar9 = *(undefined4 *)(puVar17 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                *(undefined4 *)puVar17 = *(undefined4 *)puVar16;
                *(undefined4 *)((int64_t)puVar17 + 4) = uVar4;
                *(undefined4 *)(puVar17 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar6;
                *(undefined4 *)puVar16 = uVar7;
                *(undefined4 *)((int64_t)puVar16 + 4) = uVar8;
                *(undefined4 *)(puVar16 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar10;
                if ((uint64_t)puVar16[1] < *(uint64_t *)(arg1 + (iVar19 * 2 + 1) * 8)) {
                    puVar17 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                    uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
                    uVar5 = *(undefined4 *)(puVar17 + 1);
                    uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                    *(undefined4 *)puVar16 = *(undefined4 *)puVar17;
                    *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                    *(undefined4 *)(puVar16 + 1) = uVar5;
                    *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                    puVar17 = (undefined8 *)(arg1 + iVar19 * 2 * 8);
                    *(undefined4 *)puVar17 = uVar7;
                    *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
                    *(undefined4 *)(puVar17 + 1) = uVar9;
                    *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
                }
            }
        }
        puVar17 = puVar16 + 2;
        for (; (uint64_t)arg1 < puVar16; puVar16 = puVar16 + -2) {
            uVar12 = puVar16[1];
            uVar2 = puVar16[-1];
            if ((uVar2 < uVar12) || (uVar2 >= uVar12 && uVar2 != uVar12)) break;
        }
        arg1_00 = puVar17;
        puVar14 = puVar16;
        if (puVar17 < (uint64_t)arg2) {
            uVar12 = puVar16[1];
            do {
                uVar2 = puVar17[1];
                arg1_00 = puVar17;
                if ((uVar2 < uVar12) || (uVar2 >= uVar12 && uVar2 != uVar12)) break;
                puVar17 = puVar17 + 2;
                arg1_00 = puVar17;
            } while (puVar17 < (uint64_t)arg2);
        }
joined_r0x0001801651da:
        puVar18 = puVar16;
        if (puVar17 < (uint64_t)arg2) {
            if ((uint64_t)puVar17[1] <= (uint64_t)puVar16[1]) {
                if ((uint64_t)puVar17[1] < (uint64_t)puVar16[1]) goto joined_r0x00018016520d;
                if (arg1_00 != puVar17) {
                    uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
                    uVar5 = *(undefined4 *)(puVar17 + 1);
                    uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                    uVar7 = *(undefined4 *)arg1_00;
                    uVar8 = *(undefined4 *)((int64_t)arg1_00 + 4);
                    uVar9 = *(undefined4 *)(arg1_00 + 1);
                    uVar10 = *(undefined4 *)((int64_t)arg1_00 + 0xc);
                    *(undefined4 *)arg1_00 = *(undefined4 *)puVar17;
                    *(undefined4 *)((int64_t)arg1_00 + 4) = uVar4;
                    *(undefined4 *)(arg1_00 + 1) = uVar5;
                    *(undefined4 *)((int64_t)arg1_00 + 0xc) = uVar6;
                    *(undefined4 *)puVar17 = uVar7;
                    *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
                    *(undefined4 *)(puVar17 + 1) = uVar9;
                    *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
                }
                arg1_00 = arg1_00 + 2;
            }
            puVar17 = puVar17 + 2;
            goto joined_r0x0001801651da;
        }
joined_r0x00018016520d:
        while (puVar11 = puVar14, puVar16 = puVar18, (uint64_t)arg1 < puVar11) {
            puVar14 = puVar11 + -2;
            puVar18 = puVar16;
            if ((uint64_t)puVar16[1] <= (uint64_t)puVar11[-1]) {
                if ((uint64_t)puVar16[1] < (uint64_t)puVar11[-1]) break;
                puVar18 = puVar16 + -2;
                if (puVar18 != puVar14) {
                    uVar4 = *(undefined4 *)((int64_t)puVar11 + -0xc);
                    uVar5 = *(undefined4 *)(puVar11 + -1);
                    uVar6 = *(undefined4 *)((int64_t)puVar11 + -4);
                    uVar7 = *(undefined4 *)puVar18;
                    uVar8 = *(undefined4 *)((int64_t)puVar16 + -0xc);
                    uVar9 = *(undefined4 *)(puVar16 + -1);
                    uVar10 = *(undefined4 *)((int64_t)puVar16 + -4);
                    *(undefined4 *)puVar18 = *(undefined4 *)puVar14;
                    *(undefined4 *)((int64_t)puVar16 + -0xc) = uVar4;
                    *(undefined4 *)(puVar16 + -1) = uVar5;
                    *(undefined4 *)((int64_t)puVar16 + -4) = uVar6;
                    *(undefined4 *)puVar14 = uVar7;
                    *(undefined4 *)((int64_t)puVar11 + -0xc) = uVar8;
                    *(undefined4 *)(puVar11 + -1) = uVar9;
                    *(undefined4 *)((int64_t)puVar11 + -4) = uVar10;
                }
            }
        }
        if (puVar11 != (undefined8 *)arg1) {
            puVar14 = puVar11 + -2;
            if (puVar17 == (undefined8 *)arg2) {
                puVar18 = puVar16 + -2;
                if (puVar14 != puVar18) {
                    uVar4 = *(undefined4 *)((int64_t)puVar16 + -0xc);
                    uVar5 = *(undefined4 *)(puVar16 + -1);
                    uVar6 = *(undefined4 *)((int64_t)puVar16 + -4);
                    uVar7 = *(undefined4 *)puVar14;
                    uVar8 = *(undefined4 *)((int64_t)puVar11 + -0xc);
                    uVar9 = *(undefined4 *)(puVar11 + -1);
                    uVar10 = *(undefined4 *)((int64_t)puVar11 + -4);
                    *(undefined4 *)puVar14 = *(undefined4 *)puVar18;
                    *(undefined4 *)((int64_t)puVar11 + -0xc) = uVar4;
                    *(undefined4 *)(puVar11 + -1) = uVar5;
                    *(undefined4 *)((int64_t)puVar11 + -4) = uVar6;
                    *(undefined4 *)puVar18 = uVar7;
                    *(undefined4 *)((int64_t)puVar16 + -0xc) = uVar8;
                    *(undefined4 *)(puVar16 + -1) = uVar9;
                    *(undefined4 *)((int64_t)puVar16 + -4) = uVar10;
                }
                uVar4 = *(undefined4 *)((int64_t)arg1_00 - 0xc);
                uVar5 = *(undefined4 *)(arg1_00 + -1);
                uVar6 = *(undefined4 *)((int64_t)arg1_00 - 4);
                uVar7 = *(undefined4 *)puVar18;
                uVar8 = *(undefined4 *)((int64_t)puVar16 + -0xc);
                uVar9 = *(undefined4 *)(puVar16 + -1);
                uVar10 = *(undefined4 *)((int64_t)puVar16 + -4);
                *(undefined4 *)puVar18 = *(undefined4 *)(arg1_00 + -2);
                *(undefined4 *)((int64_t)puVar16 + -0xc) = uVar4;
                *(undefined4 *)(puVar16 + -1) = uVar5;
                *(undefined4 *)((int64_t)puVar16 + -4) = uVar6;
                *(undefined4 *)(arg1_00 + -2) = uVar7;
                *(undefined4 *)((int64_t)arg1_00 - 0xc) = uVar8;
                *(undefined4 *)(arg1_00 + -1) = uVar9;
                *(undefined4 *)((int64_t)arg1_00 - 4) = uVar10;
                arg1_00 = arg1_00 + -2;
                puVar16 = puVar18;
            } else {
                uVar4 = *(undefined4 *)puVar17;
                uVar5 = *(undefined4 *)((int64_t)puVar17 + 4);
                uVar6 = *(undefined4 *)(puVar17 + 1);
                uVar7 = *(undefined4 *)((int64_t)puVar17 + 0xc);
                uVar8 = *(undefined4 *)((int64_t)puVar11 + -0xc);
                uVar9 = *(undefined4 *)(puVar11 + -1);
                uVar10 = *(undefined4 *)((int64_t)puVar11 + -4);
                *(undefined4 *)puVar17 = *(undefined4 *)puVar14;
                *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
                *(undefined4 *)(puVar17 + 1) = uVar9;
                *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
                puVar17 = puVar17 + 2;
                *(undefined4 *)puVar14 = uVar4;
                *(undefined4 *)((int64_t)puVar11 + -0xc) = uVar5;
                *(undefined4 *)(puVar11 + -1) = uVar6;
                *(undefined4 *)((int64_t)puVar11 + -4) = uVar7;
            }
            goto joined_r0x0001801651da;
        }
        if (puVar17 != (undefined8 *)arg2) {
            if (arg1_00 != puVar17) {
                uVar4 = *(undefined4 *)((int64_t)arg1_00 + 4);
                uVar5 = *(undefined4 *)(arg1_00 + 1);
                uVar6 = *(undefined4 *)((int64_t)arg1_00 + 0xc);
                uVar7 = *(undefined4 *)puVar16;
                uVar8 = *(undefined4 *)((int64_t)puVar16 + 4);
                uVar9 = *(undefined4 *)(puVar16 + 1);
                uVar10 = *(undefined4 *)((int64_t)puVar16 + 0xc);
                *(undefined4 *)puVar16 = *(undefined4 *)arg1_00;
                *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
                *(undefined4 *)(puVar16 + 1) = uVar5;
                *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                *(undefined4 *)arg1_00 = uVar7;
                *(undefined4 *)((int64_t)arg1_00 + 4) = uVar8;
                *(undefined4 *)(arg1_00 + 1) = uVar9;
                *(undefined4 *)((int64_t)arg1_00 + 0xc) = uVar10;
            }
            uVar4 = *(undefined4 *)((int64_t)puVar17 + 4);
            uVar5 = *(undefined4 *)(puVar17 + 1);
            uVar6 = *(undefined4 *)((int64_t)puVar17 + 0xc);
            uVar7 = *(undefined4 *)puVar16;
            uVar8 = *(undefined4 *)((int64_t)puVar16 + 4);
            uVar9 = *(undefined4 *)(puVar16 + 1);
            uVar10 = *(undefined4 *)((int64_t)puVar16 + 0xc);
            *(undefined4 *)puVar16 = *(undefined4 *)puVar17;
            *(undefined4 *)((int64_t)puVar16 + 4) = uVar4;
            *(undefined4 *)(puVar16 + 1) = uVar5;
            *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
            *(undefined4 *)puVar17 = uVar7;
            *(undefined4 *)((int64_t)puVar17 + 4) = uVar8;
            *(undefined4 *)(puVar17 + 1) = uVar9;
            *(undefined4 *)((int64_t)puVar17 + 0xc) = uVar10;
            puVar17 = puVar17 + 2;
            arg1_00 = arg1_00 + 2;
            puVar16 = puVar16 + 2;
            puVar14 = puVar11;
            goto joined_r0x0001801651da;
        }
        arg3 = (arg3 >> 1) + (arg3 >> 2);
        if ((int64_t)((int64_t)puVar16 - arg1 & 0xfffffffffffffff0U) <
            (int64_t)(arg2 - (int64_t)arg1_00 & 0xfffffffffffffff0U)) {
            fcn.180164fa0(arg1, (int64_t)puVar16, arg3);
            puVar16 = (undefined8 *)arg2;
            arg1 = (int64_t)arg1_00;
        } else {
            fcn.180164fa0((int64_t)arg1_00, arg2, arg3);
        }
        uVar12 = (int64_t)puVar16 - arg1;
        arg2 = (int64_t)puVar16;
    } while( true );
}

// ============================================================
// Function: FUN_180165520
// Address: 0x180165520
// Size: 53 bytes
// ============================================================
undefined8 * fcn.180165520(int64_t arg1, int64_t arg2)
{
    if (arg2 != 0) {
        do {
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            arg1 = arg1 + 0x10;
            arg2 = arg2 + -1;
        } while (arg2 != 0);
    }
    func_0x00018000d5d0(arg1, arg1);
    return (undefined8 *)arg1;
}

// ============================================================
// Function: FUN_180165560
// Address: 0x180165560
// Size: 66 bytes
// ============================================================
void fcn.180165560(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if ((iVar1 != 0) && (*(int64_t *)(iVar1 + 0x18) != 0)) {
        func_0x00018007d7d0(iVar1 + 0x18);
    }
    iVar1 = *(int64_t *)(arg1 + 8);
    if (iVar1 == 0) {
        return;
    }
    if ((iVar1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar4 = (undefined4 *)fcn.18046b77c();
        *puVar4 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1801655b0
// Address: 0x1801655b0
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1801655b0(int64_t arg1)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    fcn.18015c180();
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0;
    fcn.18015c180();
    return arg1;
}

// ============================================================
// Function: FUN_1801656a0
// Address: 0x1801656a0
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801656a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar1 = arg1 + 8;
    iVar13 = arg3 + -1 >> 1;
    iVar15 = arg2;
    iVar16 = arg2;
    if (arg2 < iVar13) {
        do {
            iVar16 = iVar15 * 2 + 2;
            iVar4 = iVar16 * 0x14;
            iVar11 = *(int32_t *)(iVar4 + iVar1);
            puVar14 = (undefined8 *)(arg1 + -0x14 + iVar4);
            iVar8 = *(int32_t *)(iVar4 + arg1);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + iVar1) + 4);
                iVar10 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + arg1) + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            puVar9 = (undefined8 *)(iVar4 + iVar1);
            if (bVar17 != iVar10 < 0) {
                puVar9 = (undefined8 *)(iVar4 + arg1);
            }
            puVar12 = (undefined8 *)(iVar4 + -0xc + arg1);
            iVar11 = *(int32_t *)puVar12;
            iVar8 = *(int32_t *)puVar14;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)((int64_t)puVar14 + 4), *(int32_t *)((int64_t)puVar12 + 4));
                iVar10 = *(int32_t *)((int64_t)puVar14 + 4) - *(int32_t *)((int64_t)puVar12 + 4);
            }
            if (bVar17 != iVar10 < 0) {
                puVar12 = puVar14;
            }
            iVar8 = (int32_t)*puVar12;
            iVar10 = (int32_t)*puVar9;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 != iVar11 < 0) {
                iVar16 = iVar15 * 2 + 1;
            }
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            uVar5 = puVar3[1];
            uVar6 = puVar3[2];
            uVar7 = puVar3[3];
            *puVar2 = *puVar3;
            puVar2[1] = uVar5;
            puVar2[2] = uVar6;
            puVar2[3] = uVar7;
            puVar2[4] = *(undefined4 *)(arg1 + 0x10 + iVar16 * 0x14);
            iVar15 = iVar16;
        } while (iVar16 < iVar13);
    }
    if ((iVar16 == iVar13) && ((arg3 & 1U) == 0)) {
        puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
        puVar3 = (undefined4 *)(arg1 + -0x14 + arg3 * 0x14);
        uVar5 = puVar3[1];
        uVar6 = puVar3[2];
        uVar7 = puVar3[3];
        iVar16 = arg3 + -1;
        *puVar2 = *puVar3;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2[4] = *(undefined4 *)(arg1 + -4 + arg3 * 0x14);
    }
    if (arg2 < iVar16) {
        do {
            iVar15 = iVar16 + -1 >> 1;
            iVar11 = *(int32_t *)(iVar1 + iVar15 * 0x14);
            puVar14 = (undefined8 *)(iVar1 + iVar15 * 0x14);
            iVar8 = *(int32_t *)(arg1 + iVar15 * 0x14);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            puVar9 = (undefined8 *)(arg1 + iVar15 * 0x14);
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)puVar14 + 4);
                iVar10 = *(int32_t *)((int64_t)puVar9 + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            iVar11 = *(int32_t *)(undefined8 *)(arg4 + 8);
            if (bVar17 != iVar10 < 0) {
                puVar14 = puVar9;
            }
            iVar8 = *(int32_t *)arg4;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)(arg4 + 4), *(int32_t *)(arg4 + 0xc));
                iVar10 = *(int32_t *)(arg4 + 4) - *(int32_t *)(arg4 + 0xc);
            }
            puVar9 = (undefined8 *)arg4;
            if (bVar17 == iVar10 < 0) {
                puVar9 = (undefined8 *)(arg4 + 8);
            }
            iVar8 = (int32_t)*puVar9;
            iVar10 = (int32_t)*puVar14;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar14 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 == iVar11 < 0) break;
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            uVar5 = puVar2[1];
            uVar6 = puVar2[2];
            uVar7 = puVar2[3];
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            *puVar3 = *puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            puVar3[4] = *(undefined4 *)(arg1 + 0x10 + iVar15 * 0x14);
            iVar16 = iVar15;
        } while (arg2 < iVar15);
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
    *puVar2 = *(undefined4 *)arg4;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar2[4] = *(undefined4 *)(arg4 + 0x10);
    return;
}

// ============================================================
// Function: FUN_1801656ab
// Address: 0x1801656ab
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801656a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar1 = arg1 + 8;
    iVar13 = arg3 + -1 >> 1;
    iVar15 = arg2;
    iVar16 = arg2;
    if (arg2 < iVar13) {
        do {
            iVar16 = iVar15 * 2 + 2;
            iVar4 = iVar16 * 0x14;
            iVar11 = *(int32_t *)(iVar4 + iVar1);
            puVar14 = (undefined8 *)(arg1 + -0x14 + iVar4);
            iVar8 = *(int32_t *)(iVar4 + arg1);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + iVar1) + 4);
                iVar10 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + arg1) + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            puVar9 = (undefined8 *)(iVar4 + iVar1);
            if (bVar17 != iVar10 < 0) {
                puVar9 = (undefined8 *)(iVar4 + arg1);
            }
            puVar12 = (undefined8 *)(iVar4 + -0xc + arg1);
            iVar11 = *(int32_t *)puVar12;
            iVar8 = *(int32_t *)puVar14;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)((int64_t)puVar14 + 4), *(int32_t *)((int64_t)puVar12 + 4));
                iVar10 = *(int32_t *)((int64_t)puVar14 + 4) - *(int32_t *)((int64_t)puVar12 + 4);
            }
            if (bVar17 != iVar10 < 0) {
                puVar12 = puVar14;
            }
            iVar8 = (int32_t)*puVar12;
            iVar10 = (int32_t)*puVar9;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 != iVar11 < 0) {
                iVar16 = iVar15 * 2 + 1;
            }
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            uVar5 = puVar3[1];
            uVar6 = puVar3[2];
            uVar7 = puVar3[3];
            *puVar2 = *puVar3;
            puVar2[1] = uVar5;
            puVar2[2] = uVar6;
            puVar2[3] = uVar7;
            puVar2[4] = *(undefined4 *)(arg1 + 0x10 + iVar16 * 0x14);
            iVar15 = iVar16;
        } while (iVar16 < iVar13);
    }
    if ((iVar16 == iVar13) && ((arg3 & 1U) == 0)) {
        puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
        puVar3 = (undefined4 *)(arg1 + -0x14 + arg3 * 0x14);
        uVar5 = puVar3[1];
        uVar6 = puVar3[2];
        uVar7 = puVar3[3];
        iVar16 = arg3 + -1;
        *puVar2 = *puVar3;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2[4] = *(undefined4 *)(arg1 + -4 + arg3 * 0x14);
    }
    if (arg2 < iVar16) {
        do {
            iVar15 = iVar16 + -1 >> 1;
            iVar11 = *(int32_t *)(iVar1 + iVar15 * 0x14);
            puVar14 = (undefined8 *)(iVar1 + iVar15 * 0x14);
            iVar8 = *(int32_t *)(arg1 + iVar15 * 0x14);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            puVar9 = (undefined8 *)(arg1 + iVar15 * 0x14);
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)puVar14 + 4);
                iVar10 = *(int32_t *)((int64_t)puVar9 + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            iVar11 = *(int32_t *)(undefined8 *)(arg4 + 8);
            if (bVar17 != iVar10 < 0) {
                puVar14 = puVar9;
            }
            iVar8 = *(int32_t *)arg4;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)(arg4 + 4), *(int32_t *)(arg4 + 0xc));
                iVar10 = *(int32_t *)(arg4 + 4) - *(int32_t *)(arg4 + 0xc);
            }
            puVar9 = (undefined8 *)arg4;
            if (bVar17 == iVar10 < 0) {
                puVar9 = (undefined8 *)(arg4 + 8);
            }
            iVar8 = (int32_t)*puVar9;
            iVar10 = (int32_t)*puVar14;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar14 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 == iVar11 < 0) break;
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            uVar5 = puVar2[1];
            uVar6 = puVar2[2];
            uVar7 = puVar2[3];
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            *puVar3 = *puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            puVar3[4] = *(undefined4 *)(arg1 + 0x10 + iVar15 * 0x14);
            iVar16 = iVar15;
        } while (arg2 < iVar15);
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
    *puVar2 = *(undefined4 *)arg4;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar2[4] = *(undefined4 *)(arg4 + 0x10);
    return;
}

// ============================================================
// Function: FUN_1801656df
// Address: 0x1801656df
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801656a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar1 = arg1 + 8;
    iVar13 = arg3 + -1 >> 1;
    iVar15 = arg2;
    iVar16 = arg2;
    if (arg2 < iVar13) {
        do {
            iVar16 = iVar15 * 2 + 2;
            iVar4 = iVar16 * 0x14;
            iVar11 = *(int32_t *)(iVar4 + iVar1);
            puVar14 = (undefined8 *)(arg1 + -0x14 + iVar4);
            iVar8 = *(int32_t *)(iVar4 + arg1);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + iVar1) + 4);
                iVar10 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + arg1) + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            puVar9 = (undefined8 *)(iVar4 + iVar1);
            if (bVar17 != iVar10 < 0) {
                puVar9 = (undefined8 *)(iVar4 + arg1);
            }
            puVar12 = (undefined8 *)(iVar4 + -0xc + arg1);
            iVar11 = *(int32_t *)puVar12;
            iVar8 = *(int32_t *)puVar14;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)((int64_t)puVar14 + 4), *(int32_t *)((int64_t)puVar12 + 4));
                iVar10 = *(int32_t *)((int64_t)puVar14 + 4) - *(int32_t *)((int64_t)puVar12 + 4);
            }
            if (bVar17 != iVar10 < 0) {
                puVar12 = puVar14;
            }
            iVar8 = (int32_t)*puVar12;
            iVar10 = (int32_t)*puVar9;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 != iVar11 < 0) {
                iVar16 = iVar15 * 2 + 1;
            }
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            uVar5 = puVar3[1];
            uVar6 = puVar3[2];
            uVar7 = puVar3[3];
            *puVar2 = *puVar3;
            puVar2[1] = uVar5;
            puVar2[2] = uVar6;
            puVar2[3] = uVar7;
            puVar2[4] = *(undefined4 *)(arg1 + 0x10 + iVar16 * 0x14);
            iVar15 = iVar16;
        } while (iVar16 < iVar13);
    }
    if ((iVar16 == iVar13) && ((arg3 & 1U) == 0)) {
        puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
        puVar3 = (undefined4 *)(arg1 + -0x14 + arg3 * 0x14);
        uVar5 = puVar3[1];
        uVar6 = puVar3[2];
        uVar7 = puVar3[3];
        iVar16 = arg3 + -1;
        *puVar2 = *puVar3;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2[4] = *(undefined4 *)(arg1 + -4 + arg3 * 0x14);
    }
    if (arg2 < iVar16) {
        do {
            iVar15 = iVar16 + -1 >> 1;
            iVar11 = *(int32_t *)(iVar1 + iVar15 * 0x14);
            puVar14 = (undefined8 *)(iVar1 + iVar15 * 0x14);
            iVar8 = *(int32_t *)(arg1 + iVar15 * 0x14);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            puVar9 = (undefined8 *)(arg1 + iVar15 * 0x14);
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)puVar14 + 4);
                iVar10 = *(int32_t *)((int64_t)puVar9 + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            iVar11 = *(int32_t *)(undefined8 *)(arg4 + 8);
            if (bVar17 != iVar10 < 0) {
                puVar14 = puVar9;
            }
            iVar8 = *(int32_t *)arg4;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)(arg4 + 4), *(int32_t *)(arg4 + 0xc));
                iVar10 = *(int32_t *)(arg4 + 4) - *(int32_t *)(arg4 + 0xc);
            }
            puVar9 = (undefined8 *)arg4;
            if (bVar17 == iVar10 < 0) {
                puVar9 = (undefined8 *)(arg4 + 8);
            }
            iVar8 = (int32_t)*puVar9;
            iVar10 = (int32_t)*puVar14;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar14 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 == iVar11 < 0) break;
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            uVar5 = puVar2[1];
            uVar6 = puVar2[2];
            uVar7 = puVar2[3];
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            *puVar3 = *puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            puVar3[4] = *(undefined4 *)(arg1 + 0x10 + iVar15 * 0x14);
            iVar16 = iVar15;
        } while (arg2 < iVar15);
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
    *puVar2 = *(undefined4 *)arg4;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar2[4] = *(undefined4 *)(arg4 + 0x10);
    return;
}

// ============================================================
// Function: FUN_180165795
// Address: 0x180165795
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801656a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar1 = arg1 + 8;
    iVar13 = arg3 + -1 >> 1;
    iVar15 = arg2;
    iVar16 = arg2;
    if (arg2 < iVar13) {
        do {
            iVar16 = iVar15 * 2 + 2;
            iVar4 = iVar16 * 0x14;
            iVar11 = *(int32_t *)(iVar4 + iVar1);
            puVar14 = (undefined8 *)(arg1 + -0x14 + iVar4);
            iVar8 = *(int32_t *)(iVar4 + arg1);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + iVar1) + 4);
                iVar10 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + arg1) + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            puVar9 = (undefined8 *)(iVar4 + iVar1);
            if (bVar17 != iVar10 < 0) {
                puVar9 = (undefined8 *)(iVar4 + arg1);
            }
            puVar12 = (undefined8 *)(iVar4 + -0xc + arg1);
            iVar11 = *(int32_t *)puVar12;
            iVar8 = *(int32_t *)puVar14;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)((int64_t)puVar14 + 4), *(int32_t *)((int64_t)puVar12 + 4));
                iVar10 = *(int32_t *)((int64_t)puVar14 + 4) - *(int32_t *)((int64_t)puVar12 + 4);
            }
            if (bVar17 != iVar10 < 0) {
                puVar12 = puVar14;
            }
            iVar8 = (int32_t)*puVar12;
            iVar10 = (int32_t)*puVar9;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 != iVar11 < 0) {
                iVar16 = iVar15 * 2 + 1;
            }
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            uVar5 = puVar3[1];
            uVar6 = puVar3[2];
            uVar7 = puVar3[3];
            *puVar2 = *puVar3;
            puVar2[1] = uVar5;
            puVar2[2] = uVar6;
            puVar2[3] = uVar7;
            puVar2[4] = *(undefined4 *)(arg1 + 0x10 + iVar16 * 0x14);
            iVar15 = iVar16;
        } while (iVar16 < iVar13);
    }
    if ((iVar16 == iVar13) && ((arg3 & 1U) == 0)) {
        puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
        puVar3 = (undefined4 *)(arg1 + -0x14 + arg3 * 0x14);
        uVar5 = puVar3[1];
        uVar6 = puVar3[2];
        uVar7 = puVar3[3];
        iVar16 = arg3 + -1;
        *puVar2 = *puVar3;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2[4] = *(undefined4 *)(arg1 + -4 + arg3 * 0x14);
    }
    if (arg2 < iVar16) {
        do {
            iVar15 = iVar16 + -1 >> 1;
            iVar11 = *(int32_t *)(iVar1 + iVar15 * 0x14);
            puVar14 = (undefined8 *)(iVar1 + iVar15 * 0x14);
            iVar8 = *(int32_t *)(arg1 + iVar15 * 0x14);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            puVar9 = (undefined8 *)(arg1 + iVar15 * 0x14);
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)puVar14 + 4);
                iVar10 = *(int32_t *)((int64_t)puVar9 + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            iVar11 = *(int32_t *)(undefined8 *)(arg4 + 8);
            if (bVar17 != iVar10 < 0) {
                puVar14 = puVar9;
            }
            iVar8 = *(int32_t *)arg4;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)(arg4 + 4), *(int32_t *)(arg4 + 0xc));
                iVar10 = *(int32_t *)(arg4 + 4) - *(int32_t *)(arg4 + 0xc);
            }
            puVar9 = (undefined8 *)arg4;
            if (bVar17 == iVar10 < 0) {
                puVar9 = (undefined8 *)(arg4 + 8);
            }
            iVar8 = (int32_t)*puVar9;
            iVar10 = (int32_t)*puVar14;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar14 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 == iVar11 < 0) break;
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            uVar5 = puVar2[1];
            uVar6 = puVar2[2];
            uVar7 = puVar2[3];
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            *puVar3 = *puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            puVar3[4] = *(undefined4 *)(arg1 + 0x10 + iVar15 * 0x14);
            iVar16 = iVar15;
        } while (arg2 < iVar15);
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
    *puVar2 = *(undefined4 *)arg4;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar2[4] = *(undefined4 *)(arg4 + 0x10);
    return;
}

// ============================================================
// Function: FUN_18016579f
// Address: 0x18016579f
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801656a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar1 = arg1 + 8;
    iVar13 = arg3 + -1 >> 1;
    iVar15 = arg2;
    iVar16 = arg2;
    if (arg2 < iVar13) {
        do {
            iVar16 = iVar15 * 2 + 2;
            iVar4 = iVar16 * 0x14;
            iVar11 = *(int32_t *)(iVar4 + iVar1);
            puVar14 = (undefined8 *)(arg1 + -0x14 + iVar4);
            iVar8 = *(int32_t *)(iVar4 + arg1);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + iVar1) + 4);
                iVar10 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + arg1) + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            puVar9 = (undefined8 *)(iVar4 + iVar1);
            if (bVar17 != iVar10 < 0) {
                puVar9 = (undefined8 *)(iVar4 + arg1);
            }
            puVar12 = (undefined8 *)(iVar4 + -0xc + arg1);
            iVar11 = *(int32_t *)puVar12;
            iVar8 = *(int32_t *)puVar14;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)((int64_t)puVar14 + 4), *(int32_t *)((int64_t)puVar12 + 4));
                iVar10 = *(int32_t *)((int64_t)puVar14 + 4) - *(int32_t *)((int64_t)puVar12 + 4);
            }
            if (bVar17 != iVar10 < 0) {
                puVar12 = puVar14;
            }
            iVar8 = (int32_t)*puVar12;
            iVar10 = (int32_t)*puVar9;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 != iVar11 < 0) {
                iVar16 = iVar15 * 2 + 1;
            }
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            uVar5 = puVar3[1];
            uVar6 = puVar3[2];
            uVar7 = puVar3[3];
            *puVar2 = *puVar3;
            puVar2[1] = uVar5;
            puVar2[2] = uVar6;
            puVar2[3] = uVar7;
            puVar2[4] = *(undefined4 *)(arg1 + 0x10 + iVar16 * 0x14);
            iVar15 = iVar16;
        } while (iVar16 < iVar13);
    }
    if ((iVar16 == iVar13) && ((arg3 & 1U) == 0)) {
        puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
        puVar3 = (undefined4 *)(arg1 + -0x14 + arg3 * 0x14);
        uVar5 = puVar3[1];
        uVar6 = puVar3[2];
        uVar7 = puVar3[3];
        iVar16 = arg3 + -1;
        *puVar2 = *puVar3;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2[4] = *(undefined4 *)(arg1 + -4 + arg3 * 0x14);
    }
    if (arg2 < iVar16) {
        do {
            iVar15 = iVar16 + -1 >> 1;
            iVar11 = *(int32_t *)(iVar1 + iVar15 * 0x14);
            puVar14 = (undefined8 *)(iVar1 + iVar15 * 0x14);
            iVar8 = *(int32_t *)(arg1 + iVar15 * 0x14);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            puVar9 = (undefined8 *)(arg1 + iVar15 * 0x14);
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)puVar14 + 4);
                iVar10 = *(int32_t *)((int64_t)puVar9 + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            iVar11 = *(int32_t *)(undefined8 *)(arg4 + 8);
            if (bVar17 != iVar10 < 0) {
                puVar14 = puVar9;
            }
            iVar8 = *(int32_t *)arg4;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)(arg4 + 4), *(int32_t *)(arg4 + 0xc));
                iVar10 = *(int32_t *)(arg4 + 4) - *(int32_t *)(arg4 + 0xc);
            }
            puVar9 = (undefined8 *)arg4;
            if (bVar17 == iVar10 < 0) {
                puVar9 = (undefined8 *)(arg4 + 8);
            }
            iVar8 = (int32_t)*puVar9;
            iVar10 = (int32_t)*puVar14;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar14 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 == iVar11 < 0) break;
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            uVar5 = puVar2[1];
            uVar6 = puVar2[2];
            uVar7 = puVar2[3];
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            *puVar3 = *puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            puVar3[4] = *(undefined4 *)(arg1 + 0x10 + iVar15 * 0x14);
            iVar16 = iVar15;
        } while (arg2 < iVar15);
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
    *puVar2 = *(undefined4 *)arg4;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar2[4] = *(undefined4 *)(arg4 + 0x10);
    return;
}

// ============================================================
// Function: FUN_1801657d7
// Address: 0x1801657d7
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801656a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar1 = arg1 + 8;
    iVar13 = arg3 + -1 >> 1;
    iVar15 = arg2;
    iVar16 = arg2;
    if (arg2 < iVar13) {
        do {
            iVar16 = iVar15 * 2 + 2;
            iVar4 = iVar16 * 0x14;
            iVar11 = *(int32_t *)(iVar4 + iVar1);
            puVar14 = (undefined8 *)(arg1 + -0x14 + iVar4);
            iVar8 = *(int32_t *)(iVar4 + arg1);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + iVar1) + 4);
                iVar10 = *(int32_t *)((int64_t)(undefined8 *)(iVar4 + arg1) + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            puVar9 = (undefined8 *)(iVar4 + iVar1);
            if (bVar17 != iVar10 < 0) {
                puVar9 = (undefined8 *)(iVar4 + arg1);
            }
            puVar12 = (undefined8 *)(iVar4 + -0xc + arg1);
            iVar11 = *(int32_t *)puVar12;
            iVar8 = *(int32_t *)puVar14;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)((int64_t)puVar14 + 4), *(int32_t *)((int64_t)puVar12 + 4));
                iVar10 = *(int32_t *)((int64_t)puVar14 + 4) - *(int32_t *)((int64_t)puVar12 + 4);
            }
            if (bVar17 != iVar10 < 0) {
                puVar12 = puVar14;
            }
            iVar8 = (int32_t)*puVar12;
            iVar10 = (int32_t)*puVar9;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 != iVar11 < 0) {
                iVar16 = iVar15 * 2 + 1;
            }
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            uVar5 = puVar3[1];
            uVar6 = puVar3[2];
            uVar7 = puVar3[3];
            *puVar2 = *puVar3;
            puVar2[1] = uVar5;
            puVar2[2] = uVar6;
            puVar2[3] = uVar7;
            puVar2[4] = *(undefined4 *)(arg1 + 0x10 + iVar16 * 0x14);
            iVar15 = iVar16;
        } while (iVar16 < iVar13);
    }
    if ((iVar16 == iVar13) && ((arg3 & 1U) == 0)) {
        puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
        puVar3 = (undefined4 *)(arg1 + -0x14 + arg3 * 0x14);
        uVar5 = puVar3[1];
        uVar6 = puVar3[2];
        uVar7 = puVar3[3];
        iVar16 = arg3 + -1;
        *puVar2 = *puVar3;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2[4] = *(undefined4 *)(arg1 + -4 + arg3 * 0x14);
    }
    if (arg2 < iVar16) {
        do {
            iVar15 = iVar16 + -1 >> 1;
            iVar11 = *(int32_t *)(iVar1 + iVar15 * 0x14);
            puVar14 = (undefined8 *)(iVar1 + iVar15 * 0x14);
            iVar8 = *(int32_t *)(arg1 + iVar15 * 0x14);
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            puVar9 = (undefined8 *)(arg1 + iVar15 * 0x14);
            if (iVar8 == iVar11) {
                iVar11 = *(int32_t *)((int64_t)puVar14 + 4);
                iVar10 = *(int32_t *)((int64_t)puVar9 + 4);
                bVar17 = SBORROW4(iVar10, iVar11);
                iVar10 = iVar10 - iVar11;
            }
            iVar11 = *(int32_t *)(undefined8 *)(arg4 + 8);
            if (bVar17 != iVar10 < 0) {
                puVar14 = puVar9;
            }
            iVar8 = *(int32_t *)arg4;
            bVar17 = SBORROW4(iVar8, iVar11);
            iVar10 = iVar8 - iVar11;
            if (iVar8 == iVar11) {
                bVar17 = SBORROW4(*(int32_t *)(arg4 + 4), *(int32_t *)(arg4 + 0xc));
                iVar10 = *(int32_t *)(arg4 + 4) - *(int32_t *)(arg4 + 0xc);
            }
            puVar9 = (undefined8 *)arg4;
            if (bVar17 == iVar10 < 0) {
                puVar9 = (undefined8 *)(arg4 + 8);
            }
            iVar8 = (int32_t)*puVar9;
            iVar10 = (int32_t)*puVar14;
            bVar17 = SBORROW4(iVar10, iVar8);
            iVar11 = iVar10 - iVar8;
            if (iVar10 == iVar8) {
                iVar8 = (int32_t)((uint64_t)*puVar9 >> 0x20);
                iVar11 = (int32_t)((uint64_t)*puVar14 >> 0x20);
                bVar17 = SBORROW4(iVar11, iVar8);
                iVar11 = iVar11 - iVar8;
            }
            if (bVar17 == iVar11 < 0) break;
            puVar2 = (undefined4 *)(arg1 + iVar15 * 0x14);
            uVar5 = puVar2[1];
            uVar6 = puVar2[2];
            uVar7 = puVar2[3];
            puVar3 = (undefined4 *)(arg1 + iVar16 * 0x14);
            *puVar3 = *puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            puVar3[4] = *(undefined4 *)(arg1 + 0x10 + iVar15 * 0x14);
            iVar16 = iVar15;
        } while (arg2 < iVar15);
    }
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    puVar2 = (undefined4 *)(arg1 + iVar16 * 0x14);
    *puVar2 = *(undefined4 *)arg4;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar2[4] = *(undefined4 *)(arg4 + 0x10);
    return;
}

// ============================================================
// Function: FUN_1801658a0
// Address: 0x1801658a0
// Size: 78 bytes
// ============================================================
undefined8 * fcn.1801658a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    if (arg1 != arg2) {
        do {
            *(undefined8 *)arg3 = 0;
            *(undefined8 *)(arg3 + 8) = 0;
            *(undefined8 *)arg3 = *(undefined8 *)arg1;
            *(undefined8 *)(arg3 + 8) = *(undefined8 *)(arg1 + 8);
            arg3 = arg3 + 0x10;
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            arg1 = arg1 + 0x10;
        } while (arg1 != arg2);
    }
    func_0x00018000d5d0(arg3, arg3);
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_180165900
// Address: 0x180165900
// Size: 37 bytes
// ============================================================
int64_t fcn.180165900(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    (**(code **)(arg1 + 8))(arg2, *(undefined8 *)arg3, *(undefined8 *)arg4);
    return arg2;
}

// ============================================================
// Function: FUN_180165990
// Address: 0x180165990
// Size: 107 bytes
// ============================================================
void fcn.180165990(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined *puVar7;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    func_0x00018000d5d0(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20));
    iVar4 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x10)) {
        iVar6 = *(int64_t *)(iVar4 + -8);
        if ((iVar4 - iVar6) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar4 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    unaff_RBX = *(undefined8 *)(puVar7 + 0x20);
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar6 = iVar4;
code_r0x0001800f4640:
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180165a00
// Address: 0x180165a00
// Size: 133 bytes
// ============================================================
void fcn.180165a00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    if (*(int64_t *)arg1 != 0) {
        func_0x00018000d5d0(*(int64_t *)arg1, *(undefined8 *)(arg1 + 8));
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_48;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar1 & 0xfffffffffffffff0U)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_48, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_40;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180165a63;
        fcn.180459c3c(iVar3);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x10 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x10 + arg2;
    return;
}

// ============================================================
// Function: FUN_180165a90
// Address: 0x180165a90
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180165a90(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x38) {
        func_0x000180004e40(iVar6 + 0x18);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x38)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180165aa0
// Address: 0x180165aa0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180165a90(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x38) {
        func_0x000180004e40(iVar6 + 0x18);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x38)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180165ae5
// Address: 0x180165ae5
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180165a90(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x38) {
        func_0x000180004e40(iVar6 + 0x18);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x38)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180165b20
// Address: 0x180165b20
// Size: 151 bytes
// ============================================================
void fcn.180165b20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 2) * 4)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x180165b92;
        fcn.180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 0x14;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 0x14;
    return;
}

// ============================================================
// Function: FUN_180165bc0
// Address: 0x180165bc0
// Size: 220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180165bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    bool bVar16;
    int64_t var_8h;
    
    iVar15 = *(int32_t *)(arg2 + 8);
    puVar12 = (undefined8 *)(arg2 + 8);
    iVar13 = *(int32_t *)arg2;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
        iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
    }
    puVar1 = (undefined8 *)(arg1 + 8);
    puVar11 = (undefined8 *)arg2;
    if (bVar16 == iVar14 < 0) {
        puVar11 = puVar12;
    }
    iVar15 = *(int32_t *)puVar1;
    iVar13 = *(int32_t *)arg1;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg1 + 4), *(int32_t *)(arg1 + 0xc));
        iVar14 = *(int32_t *)(arg1 + 4) - *(int32_t *)(arg1 + 0xc);
    }
    puVar10 = (undefined8 *)arg1;
    if (bVar16 == iVar14 < 0) {
        puVar10 = puVar1;
    }
    iVar13 = (int32_t)*puVar10;
    iVar14 = (int32_t)*puVar11;
    bVar16 = SBORROW4(iVar14, iVar13);
    iVar15 = iVar14 - iVar13;
    if (iVar14 == iVar13) {
        iVar13 = (int32_t)((uint64_t)*puVar10 >> 0x20);
        iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        bVar16 = SBORROW4(iVar15, iVar13);
        iVar15 = iVar15 - iVar13;
    }
    if (bVar16 != iVar15 < 0) {
        uVar3 = *(undefined4 *)(arg1 + 4);
        uVar4 = *(undefined4 *)(arg1 + 8);
        uVar5 = *(undefined4 *)(arg1 + 0xc);
        uVar2 = *(undefined4 *)(arg2 + 0x10);
        uVar6 = *(undefined4 *)arg2;
        uVar7 = *(undefined4 *)(arg2 + 4);
        uVar8 = *(undefined4 *)(arg2 + 8);
        uVar9 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)arg1;
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(undefined4 *)(arg2 + 8) = uVar4;
        *(undefined4 *)(arg2 + 0xc) = uVar5;
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
        *(undefined4 *)arg1 = uVar6;
        *(undefined4 *)(arg1 + 4) = uVar7;
        *(undefined4 *)(arg1 + 8) = uVar8;
        *(undefined4 *)(arg1 + 0xc) = uVar9;
        *(undefined4 *)(arg1 + 0x10) = uVar2;
    }
    iVar15 = *(int32_t *)(arg3 + 8);
    iVar13 = *(int32_t *)arg3;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg3 + 4), *(int32_t *)(arg3 + 0xc));
        iVar14 = *(int32_t *)(arg3 + 4) - *(int32_t *)(arg3 + 0xc);
    }
    puVar11 = (undefined8 *)arg3;
    if (bVar16 == iVar14 < 0) {
        puVar11 = (undefined8 *)(arg3 + 8);
    }
    iVar15 = *(int32_t *)puVar12;
    iVar13 = *(int32_t *)arg2;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
        iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
    }
    puVar10 = (undefined8 *)arg2;
    if (bVar16 == iVar14 < 0) {
        puVar10 = puVar12;
    }
    iVar13 = (int32_t)*puVar10;
    iVar14 = (int32_t)*puVar11;
    bVar16 = SBORROW4(iVar14, iVar13);
    iVar15 = iVar14 - iVar13;
    if (iVar14 == iVar13) {
        iVar13 = (int32_t)((uint64_t)*puVar10 >> 0x20);
        iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        bVar16 = SBORROW4(iVar15, iVar13);
        iVar15 = iVar15 - iVar13;
    }
    if (bVar16 != iVar15 < 0) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        uVar6 = *(undefined4 *)arg3;
        uVar7 = *(undefined4 *)(arg3 + 4);
        uVar8 = *(undefined4 *)(arg3 + 8);
        uVar9 = *(undefined4 *)(arg3 + 0xc);
        uVar2 = *(undefined4 *)(arg3 + 0x10);
        *(undefined4 *)arg3 = *(undefined4 *)arg2;
        *(undefined4 *)(arg3 + 4) = uVar3;
        *(undefined4 *)(arg3 + 8) = uVar4;
        *(undefined4 *)(arg3 + 0xc) = uVar5;
        *(undefined4 *)(arg3 + 0x10) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)arg2 = uVar6;
        *(undefined4 *)(arg2 + 4) = uVar7;
        *(undefined4 *)(arg2 + 8) = uVar8;
        *(undefined4 *)(arg2 + 0xc) = uVar9;
        *(undefined4 *)(arg2 + 0x10) = uVar2;
        iVar15 = *(int32_t *)puVar12;
        iVar13 = *(int32_t *)arg2;
        bVar16 = SBORROW4(iVar13, iVar15);
        iVar14 = iVar13 - iVar15;
        if (iVar13 == iVar15) {
            bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
            iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
        }
        puVar11 = (undefined8 *)arg2;
        if (bVar16 == iVar14 < 0) {
            puVar11 = puVar12;
        }
        iVar15 = *(int32_t *)puVar1;
        iVar13 = *(int32_t *)arg1;
        bVar16 = SBORROW4(iVar13, iVar15);
        iVar14 = iVar13 - iVar15;
        if (iVar13 == iVar15) {
            bVar16 = SBORROW4(*(int32_t *)(arg1 + 4), *(int32_t *)(arg1 + 0xc));
            iVar14 = *(int32_t *)(arg1 + 4) - *(int32_t *)(arg1 + 0xc);
        }
        puVar12 = (undefined8 *)arg1;
        if (bVar16 == iVar14 < 0) {
            puVar12 = puVar1;
        }
        iVar13 = (int32_t)*puVar12;
        iVar14 = (int32_t)*puVar11;
        bVar16 = SBORROW4(iVar14, iVar13);
        iVar15 = iVar14 - iVar13;
        if (iVar14 == iVar13) {
            iVar13 = (int32_t)((uint64_t)*puVar12 >> 0x20);
            iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
            bVar16 = SBORROW4(iVar15, iVar13);
            iVar15 = iVar15 - iVar13;
        }
        if (bVar16 != iVar15 < 0) {
            uVar3 = *(undefined4 *)(arg1 + 4);
            uVar4 = *(undefined4 *)(arg1 + 8);
            uVar5 = *(undefined4 *)(arg1 + 0xc);
            *(undefined4 *)arg2 = *(undefined4 *)arg1;
            *(undefined4 *)(arg2 + 4) = uVar3;
            *(undefined4 *)(arg2 + 8) = uVar4;
            *(undefined4 *)(arg2 + 0xc) = uVar5;
            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
            *(undefined4 *)arg1 = uVar6;
            *(undefined4 *)(arg1 + 4) = uVar7;
            *(undefined4 *)(arg1 + 8) = uVar8;
            *(undefined4 *)(arg1 + 0xc) = uVar9;
            *(undefined4 *)(arg1 + 0x10) = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180165c9c
// Address: 0x180165c9c
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180165bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    bool bVar16;
    int64_t var_8h;
    
    iVar15 = *(int32_t *)(arg2 + 8);
    puVar12 = (undefined8 *)(arg2 + 8);
    iVar13 = *(int32_t *)arg2;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
        iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
    }
    puVar1 = (undefined8 *)(arg1 + 8);
    puVar11 = (undefined8 *)arg2;
    if (bVar16 == iVar14 < 0) {
        puVar11 = puVar12;
    }
    iVar15 = *(int32_t *)puVar1;
    iVar13 = *(int32_t *)arg1;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg1 + 4), *(int32_t *)(arg1 + 0xc));
        iVar14 = *(int32_t *)(arg1 + 4) - *(int32_t *)(arg1 + 0xc);
    }
    puVar10 = (undefined8 *)arg1;
    if (bVar16 == iVar14 < 0) {
        puVar10 = puVar1;
    }
    iVar13 = (int32_t)*puVar10;
    iVar14 = (int32_t)*puVar11;
    bVar16 = SBORROW4(iVar14, iVar13);
    iVar15 = iVar14 - iVar13;
    if (iVar14 == iVar13) {
        iVar13 = (int32_t)((uint64_t)*puVar10 >> 0x20);
        iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        bVar16 = SBORROW4(iVar15, iVar13);
        iVar15 = iVar15 - iVar13;
    }
    if (bVar16 != iVar15 < 0) {
        uVar3 = *(undefined4 *)(arg1 + 4);
        uVar4 = *(undefined4 *)(arg1 + 8);
        uVar5 = *(undefined4 *)(arg1 + 0xc);
        uVar2 = *(undefined4 *)(arg2 + 0x10);
        uVar6 = *(undefined4 *)arg2;
        uVar7 = *(undefined4 *)(arg2 + 4);
        uVar8 = *(undefined4 *)(arg2 + 8);
        uVar9 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)arg1;
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(undefined4 *)(arg2 + 8) = uVar4;
        *(undefined4 *)(arg2 + 0xc) = uVar5;
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
        *(undefined4 *)arg1 = uVar6;
        *(undefined4 *)(arg1 + 4) = uVar7;
        *(undefined4 *)(arg1 + 8) = uVar8;
        *(undefined4 *)(arg1 + 0xc) = uVar9;
        *(undefined4 *)(arg1 + 0x10) = uVar2;
    }
    iVar15 = *(int32_t *)(arg3 + 8);
    iVar13 = *(int32_t *)arg3;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg3 + 4), *(int32_t *)(arg3 + 0xc));
        iVar14 = *(int32_t *)(arg3 + 4) - *(int32_t *)(arg3 + 0xc);
    }
    puVar11 = (undefined8 *)arg3;
    if (bVar16 == iVar14 < 0) {
        puVar11 = (undefined8 *)(arg3 + 8);
    }
    iVar15 = *(int32_t *)puVar12;
    iVar13 = *(int32_t *)arg2;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
        iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
    }
    puVar10 = (undefined8 *)arg2;
    if (bVar16 == iVar14 < 0) {
        puVar10 = puVar12;
    }
    iVar13 = (int32_t)*puVar10;
    iVar14 = (int32_t)*puVar11;
    bVar16 = SBORROW4(iVar14, iVar13);
    iVar15 = iVar14 - iVar13;
    if (iVar14 == iVar13) {
        iVar13 = (int32_t)((uint64_t)*puVar10 >> 0x20);
        iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        bVar16 = SBORROW4(iVar15, iVar13);
        iVar15 = iVar15 - iVar13;
    }
    if (bVar16 != iVar15 < 0) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        uVar6 = *(undefined4 *)arg3;
        uVar7 = *(undefined4 *)(arg3 + 4);
        uVar8 = *(undefined4 *)(arg3 + 8);
        uVar9 = *(undefined4 *)(arg3 + 0xc);
        uVar2 = *(undefined4 *)(arg3 + 0x10);
        *(undefined4 *)arg3 = *(undefined4 *)arg2;
        *(undefined4 *)(arg3 + 4) = uVar3;
        *(undefined4 *)(arg3 + 8) = uVar4;
        *(undefined4 *)(arg3 + 0xc) = uVar5;
        *(undefined4 *)(arg3 + 0x10) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)arg2 = uVar6;
        *(undefined4 *)(arg2 + 4) = uVar7;
        *(undefined4 *)(arg2 + 8) = uVar8;
        *(undefined4 *)(arg2 + 0xc) = uVar9;
        *(undefined4 *)(arg2 + 0x10) = uVar2;
        iVar15 = *(int32_t *)puVar12;
        iVar13 = *(int32_t *)arg2;
        bVar16 = SBORROW4(iVar13, iVar15);
        iVar14 = iVar13 - iVar15;
        if (iVar13 == iVar15) {
            bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
            iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
        }
        puVar11 = (undefined8 *)arg2;
        if (bVar16 == iVar14 < 0) {
            puVar11 = puVar12;
        }
        iVar15 = *(int32_t *)puVar1;
        iVar13 = *(int32_t *)arg1;
        bVar16 = SBORROW4(iVar13, iVar15);
        iVar14 = iVar13 - iVar15;
        if (iVar13 == iVar15) {
            bVar16 = SBORROW4(*(int32_t *)(arg1 + 4), *(int32_t *)(arg1 + 0xc));
            iVar14 = *(int32_t *)(arg1 + 4) - *(int32_t *)(arg1 + 0xc);
        }
        puVar12 = (undefined8 *)arg1;
        if (bVar16 == iVar14 < 0) {
            puVar12 = puVar1;
        }
        iVar13 = (int32_t)*puVar12;
        iVar14 = (int32_t)*puVar11;
        bVar16 = SBORROW4(iVar14, iVar13);
        iVar15 = iVar14 - iVar13;
        if (iVar14 == iVar13) {
            iVar13 = (int32_t)((uint64_t)*puVar12 >> 0x20);
            iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
            bVar16 = SBORROW4(iVar15, iVar13);
            iVar15 = iVar15 - iVar13;
        }
        if (bVar16 != iVar15 < 0) {
            uVar3 = *(undefined4 *)(arg1 + 4);
            uVar4 = *(undefined4 *)(arg1 + 8);
            uVar5 = *(undefined4 *)(arg1 + 0xc);
            *(undefined4 *)arg2 = *(undefined4 *)arg1;
            *(undefined4 *)(arg2 + 4) = uVar3;
            *(undefined4 *)(arg2 + 8) = uVar4;
            *(undefined4 *)(arg2 + 0xc) = uVar5;
            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
            *(undefined4 *)arg1 = uVar6;
            *(undefined4 *)(arg1 + 4) = uVar7;
            *(undefined4 *)(arg1 + 8) = uVar8;
            *(undefined4 *)(arg1 + 0xc) = uVar9;
            *(undefined4 *)(arg1 + 0x10) = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180165d24
// Address: 0x180165d24
// Size: 2 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180165bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    bool bVar16;
    int64_t var_8h;
    
    iVar15 = *(int32_t *)(arg2 + 8);
    puVar12 = (undefined8 *)(arg2 + 8);
    iVar13 = *(int32_t *)arg2;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
        iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
    }
    puVar1 = (undefined8 *)(arg1 + 8);
    puVar11 = (undefined8 *)arg2;
    if (bVar16 == iVar14 < 0) {
        puVar11 = puVar12;
    }
    iVar15 = *(int32_t *)puVar1;
    iVar13 = *(int32_t *)arg1;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg1 + 4), *(int32_t *)(arg1 + 0xc));
        iVar14 = *(int32_t *)(arg1 + 4) - *(int32_t *)(arg1 + 0xc);
    }
    puVar10 = (undefined8 *)arg1;
    if (bVar16 == iVar14 < 0) {
        puVar10 = puVar1;
    }
    iVar13 = (int32_t)*puVar10;
    iVar14 = (int32_t)*puVar11;
    bVar16 = SBORROW4(iVar14, iVar13);
    iVar15 = iVar14 - iVar13;
    if (iVar14 == iVar13) {
        iVar13 = (int32_t)((uint64_t)*puVar10 >> 0x20);
        iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        bVar16 = SBORROW4(iVar15, iVar13);
        iVar15 = iVar15 - iVar13;
    }
    if (bVar16 != iVar15 < 0) {
        uVar3 = *(undefined4 *)(arg1 + 4);
        uVar4 = *(undefined4 *)(arg1 + 8);
        uVar5 = *(undefined4 *)(arg1 + 0xc);
        uVar2 = *(undefined4 *)(arg2 + 0x10);
        uVar6 = *(undefined4 *)arg2;
        uVar7 = *(undefined4 *)(arg2 + 4);
        uVar8 = *(undefined4 *)(arg2 + 8);
        uVar9 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)arg2 = *(undefined4 *)arg1;
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(undefined4 *)(arg2 + 8) = uVar4;
        *(undefined4 *)(arg2 + 0xc) = uVar5;
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
        *(undefined4 *)arg1 = uVar6;
        *(undefined4 *)(arg1 + 4) = uVar7;
        *(undefined4 *)(arg1 + 8) = uVar8;
        *(undefined4 *)(arg1 + 0xc) = uVar9;
        *(undefined4 *)(arg1 + 0x10) = uVar2;
    }
    iVar15 = *(int32_t *)(arg3 + 8);
    iVar13 = *(int32_t *)arg3;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg3 + 4), *(int32_t *)(arg3 + 0xc));
        iVar14 = *(int32_t *)(arg3 + 4) - *(int32_t *)(arg3 + 0xc);
    }
    puVar11 = (undefined8 *)arg3;
    if (bVar16 == iVar14 < 0) {
        puVar11 = (undefined8 *)(arg3 + 8);
    }
    iVar15 = *(int32_t *)puVar12;
    iVar13 = *(int32_t *)arg2;
    bVar16 = SBORROW4(iVar13, iVar15);
    iVar14 = iVar13 - iVar15;
    if (iVar13 == iVar15) {
        bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
        iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
    }
    puVar10 = (undefined8 *)arg2;
    if (bVar16 == iVar14 < 0) {
        puVar10 = puVar12;
    }
    iVar13 = (int32_t)*puVar10;
    iVar14 = (int32_t)*puVar11;
    bVar16 = SBORROW4(iVar14, iVar13);
    iVar15 = iVar14 - iVar13;
    if (iVar14 == iVar13) {
        iVar13 = (int32_t)((uint64_t)*puVar10 >> 0x20);
        iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
        bVar16 = SBORROW4(iVar15, iVar13);
        iVar15 = iVar15 - iVar13;
    }
    if (bVar16 != iVar15 < 0) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        uVar6 = *(undefined4 *)arg3;
        uVar7 = *(undefined4 *)(arg3 + 4);
        uVar8 = *(undefined4 *)(arg3 + 8);
        uVar9 = *(undefined4 *)(arg3 + 0xc);
        uVar2 = *(undefined4 *)(arg3 + 0x10);
        *(undefined4 *)arg3 = *(undefined4 *)arg2;
        *(undefined4 *)(arg3 + 4) = uVar3;
        *(undefined4 *)(arg3 + 8) = uVar4;
        *(undefined4 *)(arg3 + 0xc) = uVar5;
        *(undefined4 *)(arg3 + 0x10) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)arg2 = uVar6;
        *(undefined4 *)(arg2 + 4) = uVar7;
        *(undefined4 *)(arg2 + 8) = uVar8;
        *(undefined4 *)(arg2 + 0xc) = uVar9;
        *(undefined4 *)(arg2 + 0x10) = uVar2;
        iVar15 = *(int32_t *)puVar12;
        iVar13 = *(int32_t *)arg2;
        bVar16 = SBORROW4(iVar13, iVar15);
        iVar14 = iVar13 - iVar15;
        if (iVar13 == iVar15) {
            bVar16 = SBORROW4(*(int32_t *)(arg2 + 4), *(int32_t *)(arg2 + 0xc));
            iVar14 = *(int32_t *)(arg2 + 4) - *(int32_t *)(arg2 + 0xc);
        }
        puVar11 = (undefined8 *)arg2;
        if (bVar16 == iVar14 < 0) {
            puVar11 = puVar12;
        }
        iVar15 = *(int32_t *)puVar1;
        iVar13 = *(int32_t *)arg1;
        bVar16 = SBORROW4(iVar13, iVar15);
        iVar14 = iVar13 - iVar15;
        if (iVar13 == iVar15) {
            bVar16 = SBORROW4(*(int32_t *)(arg1 + 4), *(int32_t *)(arg1 + 0xc));
            iVar14 = *(int32_t *)(arg1 + 4) - *(int32_t *)(arg1 + 0xc);
        }
        puVar12 = (undefined8 *)arg1;
        if (bVar16 == iVar14 < 0) {
            puVar12 = puVar1;
        }
        iVar13 = (int32_t)*puVar12;
        iVar14 = (int32_t)*puVar11;
        bVar16 = SBORROW4(iVar14, iVar13);
        iVar15 = iVar14 - iVar13;
        if (iVar14 == iVar13) {
            iVar13 = (int32_t)((uint64_t)*puVar12 >> 0x20);
            iVar15 = (int32_t)((uint64_t)*puVar11 >> 0x20);
            bVar16 = SBORROW4(iVar15, iVar13);
            iVar15 = iVar15 - iVar13;
        }
        if (bVar16 != iVar15 < 0) {
            uVar3 = *(undefined4 *)(arg1 + 4);
            uVar4 = *(undefined4 *)(arg1 + 8);
            uVar5 = *(undefined4 *)(arg1 + 0xc);
            *(undefined4 *)arg2 = *(undefined4 *)arg1;
            *(undefined4 *)(arg2 + 4) = uVar3;
            *(undefined4 *)(arg2 + 8) = uVar4;
            *(undefined4 *)(arg2 + 0xc) = uVar5;
            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
            *(undefined4 *)arg1 = uVar6;
            *(undefined4 *)(arg1 + 4) = uVar7;
            *(undefined4 *)(arg1 + 8) = uVar8;
            *(undefined4 *)(arg1 + 0xc) = uVar9;
            *(undefined4 *)(arg1 + 0x10) = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180165d30
// Address: 0x180165d30
// Size: 201 bytes
// ============================================================
void fcn.180165d30(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    
    iVar9 = arg3 + -1 >> 1;
    iVar7 = arg2;
    iVar8 = arg2;
    if (arg2 < iVar9) {
        do {
            iVar8 = (2 - (uint64_t)
                         (*(uint64_t *)(arg1 + 0x28 + iVar7 * 0x20) < *(uint64_t *)(arg1 + 8 + (iVar7 * 2 + 1) * 0x10)))
                    + iVar7 * 2;
            puVar1 = (undefined4 *)(arg1 + iVar8 * 0x10);
            uVar4 = puVar1[1];
            uVar5 = puVar1[2];
            uVar6 = puVar1[3];
            puVar2 = (undefined4 *)(arg1 + iVar7 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            iVar7 = iVar8;
        } while (iVar8 < iVar9);
    }
    if ((iVar8 == iVar9) && ((arg3 & 1U) == 0)) {
        puVar2 = (undefined4 *)(arg1 + -0x10 + arg3 * 0x10);
        uVar4 = puVar2[1];
        uVar5 = puVar2[2];
        uVar6 = puVar2[3];
        puVar1 = (undefined4 *)(arg1 + iVar8 * 0x10);
        *puVar1 = *puVar2;
        puVar1[1] = uVar4;
        puVar1[2] = uVar5;
        puVar1[3] = uVar6;
        iVar8 = arg3 + -1;
    }
    if (arg2 < iVar8) {
        uVar3 = *(uint64_t *)(arg4 + 8);
        do {
            iVar7 = iVar8 + -1 >> 1;
            if (uVar3 <= *(uint64_t *)(arg1 + 8 + iVar7 * 0x10)) break;
            puVar1 = (undefined4 *)(arg1 + iVar7 * 0x10);
            uVar4 = puVar1[1];
            uVar5 = puVar1[2];
            uVar6 = puVar1[3];
            puVar2 = (undefined4 *)(arg1 + iVar8 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            iVar8 = iVar7;
        } while (arg2 < iVar7);
    }
    uVar4 = *(undefined4 *)(arg4 + 4);
    uVar5 = *(undefined4 *)(arg4 + 8);
    uVar6 = *(undefined4 *)(arg4 + 0xc);
    puVar1 = (undefined4 *)(arg1 + iVar8 * 0x10);
    *puVar1 = *(undefined4 *)arg4;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_180165e00
// Address: 0x180165e00
// Size: 223 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.180165e00(int64_t arg1, int64_t arg2)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    undefined4 var_78h;
    undefined4 var_74h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined var_48h [16];
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar4 = 0;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd8);
    }
    var_58h._0_4_ = *(float *)(arg1 + 0x30) * *(float *)(arg1 + 0x28);
    var_58h._4_4_ = *(float *)(arg1 + 0x34) * *(float *)(arg1 + 0x2c);
    var_50h._0_4_ = 0;
    var_50h._4_4_ = 0x3f800000;
    var_60h = 0;
    (**(code **)(*(int64_t *)arg2 + 0x160))(arg2, 1, &var_60h);
    var_80h = (int64_t)&var_70h;
    var_88h = (uint64_t)var_88h._4_4_ << 0x20;
    iVar3 = (**(code **)(*(int64_t *)arg2 + 0x70))(arg2, *(undefined8 *)(iVar4 + 0x38), 0, 4);
    if (iVar3 == 0) {
        fVar1 = *(float *)(arg1 + 0x20);
        fVar2 = *(float *)(arg1 + 0x24);
        fVar5 = fVar1 + *(float *)(arg1 + 0x28);
        fVar6 = fVar2 + *(float *)(arg1 + 0x2c);
        *(float *)var_70h = 2.0 / (fVar5 - fVar1);
        *(undefined8 *)(var_70h + 4) = 0;
        *(undefined8 *)(var_70h + 0xc) = 0;
        *(float *)(var_70h + 0x14) = 2.0 / (fVar2 - fVar6);
        *(undefined8 *)(var_70h + 0x18) = 0;
        *(undefined8 *)(var_70h + 0x20) = 0;
        *(undefined8 *)(var_70h + 0x28) = 0x3f000000;
        *(float *)(var_70h + 0x30) = (fVar5 + fVar1) / (fVar1 - fVar5);
        *(float *)(var_70h + 0x34) = (fVar6 + fVar2) / (fVar6 - fVar2);
        *(undefined4 *)(var_70h + 0x38) = 0x3f000000;
        *(undefined4 *)(var_70h + 0x3c) = 0x3f800000;
        (**(code **)(*(int64_t *)arg2 + 0x78))(arg2, *(undefined8 *)(iVar4 + 0x38), 0);
    }
    var_74h = 0x14;
    var_78h = 0;
    (**(code **)(*(int64_t *)arg2 + 0x88))(arg2, *(undefined8 *)(iVar4 + 0x30));
    var_80h = (int64_t)&var_78h;
    var_88h = (int64_t)&var_74h;
    (**(code **)(*(int64_t *)arg2 + 0x90))(arg2, 0, 1, iVar4 + 0x18);
    (**(code **)(*(int64_t *)arg2 + 0x98))(arg2, *(undefined8 *)(iVar4 + 0x20), 0x39, 0);
    (**(code **)(*(int64_t *)arg2 + 0xc0))(arg2, 4);
    (**(code **)(*(int64_t *)arg2 + 0x58))(arg2, *(undefined8 *)(iVar4 + 0x28), 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x38))(arg2, 0, 1, iVar4 + 0x38);
    (**(code **)(*(int64_t *)arg2 + 0x48))(arg2, *(undefined8 *)(iVar4 + 0x40), 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x50))(arg2, 0, 1, iVar4 + 0x48);
    (**(code **)(*(int64_t *)arg2 + 0xb8))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x1e0))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x200))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x228))(arg2, 0, 0, 0);
    var_48h = ZEXT816(0);
    (**(code **)(*(int64_t *)arg2 + 0x118))(arg2, *(undefined8 *)(iVar4 + 0x60), var_48h, 0xffffffff);
    (**(code **)(*(int64_t *)arg2 + 0x120))(arg2, *(undefined8 *)(iVar4 + 0x68), 0);
    (**(code **)(*(int64_t *)arg2 + 0x158))(arg2, *(undefined8 *)(iVar4 + 0x58));
    func_0x000180459870(var_38h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180165edf
// Address: 0x180165edf
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.180165e00(int64_t arg1, int64_t arg2)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    undefined4 var_78h;
    undefined4 var_74h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined var_48h [16];
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar4 = 0;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd8);
    }
    var_58h._0_4_ = *(float *)(arg1 + 0x30) * *(float *)(arg1 + 0x28);
    var_58h._4_4_ = *(float *)(arg1 + 0x34) * *(float *)(arg1 + 0x2c);
    var_50h._0_4_ = 0;
    var_50h._4_4_ = 0x3f800000;
    var_60h = 0;
    (**(code **)(*(int64_t *)arg2 + 0x160))(arg2, 1, &var_60h);
    var_80h = (int64_t)&var_70h;
    var_88h = (uint64_t)var_88h._4_4_ << 0x20;
    iVar3 = (**(code **)(*(int64_t *)arg2 + 0x70))(arg2, *(undefined8 *)(iVar4 + 0x38), 0, 4);
    if (iVar3 == 0) {
        fVar1 = *(float *)(arg1 + 0x20);
        fVar2 = *(float *)(arg1 + 0x24);
        fVar5 = fVar1 + *(float *)(arg1 + 0x28);
        fVar6 = fVar2 + *(float *)(arg1 + 0x2c);
        *(float *)var_70h = 2.0 / (fVar5 - fVar1);
        *(undefined8 *)(var_70h + 4) = 0;
        *(undefined8 *)(var_70h + 0xc) = 0;
        *(float *)(var_70h + 0x14) = 2.0 / (fVar2 - fVar6);
        *(undefined8 *)(var_70h + 0x18) = 0;
        *(undefined8 *)(var_70h + 0x20) = 0;
        *(undefined8 *)(var_70h + 0x28) = 0x3f000000;
        *(float *)(var_70h + 0x30) = (fVar5 + fVar1) / (fVar1 - fVar5);
        *(float *)(var_70h + 0x34) = (fVar6 + fVar2) / (fVar6 - fVar2);
        *(undefined4 *)(var_70h + 0x38) = 0x3f000000;
        *(undefined4 *)(var_70h + 0x3c) = 0x3f800000;
        (**(code **)(*(int64_t *)arg2 + 0x78))(arg2, *(undefined8 *)(iVar4 + 0x38), 0);
    }
    var_74h = 0x14;
    var_78h = 0;
    (**(code **)(*(int64_t *)arg2 + 0x88))(arg2, *(undefined8 *)(iVar4 + 0x30));
    var_80h = (int64_t)&var_78h;
    var_88h = (int64_t)&var_74h;
    (**(code **)(*(int64_t *)arg2 + 0x90))(arg2, 0, 1, iVar4 + 0x18);
    (**(code **)(*(int64_t *)arg2 + 0x98))(arg2, *(undefined8 *)(iVar4 + 0x20), 0x39, 0);
    (**(code **)(*(int64_t *)arg2 + 0xc0))(arg2, 4);
    (**(code **)(*(int64_t *)arg2 + 0x58))(arg2, *(undefined8 *)(iVar4 + 0x28), 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x38))(arg2, 0, 1, iVar4 + 0x38);
    (**(code **)(*(int64_t *)arg2 + 0x48))(arg2, *(undefined8 *)(iVar4 + 0x40), 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x50))(arg2, 0, 1, iVar4 + 0x48);
    (**(code **)(*(int64_t *)arg2 + 0xb8))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x1e0))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x200))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x228))(arg2, 0, 0, 0);
    var_48h = ZEXT816(0);
    (**(code **)(*(int64_t *)arg2 + 0x118))(arg2, *(undefined8 *)(iVar4 + 0x60), var_48h, 0xffffffff);
    (**(code **)(*(int64_t *)arg2 + 0x120))(arg2, *(undefined8 *)(iVar4 + 0x68), 0);
    (**(code **)(*(int64_t *)arg2 + 0x158))(arg2, *(undefined8 *)(iVar4 + 0x58));
    func_0x000180459870(var_38h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180165f6e
// Address: 0x180165f6e
// Size: 381 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.180165e00(int64_t arg1, int64_t arg2)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    undefined4 var_78h;
    undefined4 var_74h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined var_48h [16];
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar4 = 0;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd8);
    }
    var_58h._0_4_ = *(float *)(arg1 + 0x30) * *(float *)(arg1 + 0x28);
    var_58h._4_4_ = *(float *)(arg1 + 0x34) * *(float *)(arg1 + 0x2c);
    var_50h._0_4_ = 0;
    var_50h._4_4_ = 0x3f800000;
    var_60h = 0;
    (**(code **)(*(int64_t *)arg2 + 0x160))(arg2, 1, &var_60h);
    var_80h = (int64_t)&var_70h;
    var_88h = (uint64_t)var_88h._4_4_ << 0x20;
    iVar3 = (**(code **)(*(int64_t *)arg2 + 0x70))(arg2, *(undefined8 *)(iVar4 + 0x38), 0, 4);
    if (iVar3 == 0) {
        fVar1 = *(float *)(arg1 + 0x20);
        fVar2 = *(float *)(arg1 + 0x24);
        fVar5 = fVar1 + *(float *)(arg1 + 0x28);
        fVar6 = fVar2 + *(float *)(arg1 + 0x2c);
        *(float *)var_70h = 2.0 / (fVar5 - fVar1);
        *(undefined8 *)(var_70h + 4) = 0;
        *(undefined8 *)(var_70h + 0xc) = 0;
        *(float *)(var_70h + 0x14) = 2.0 / (fVar2 - fVar6);
        *(undefined8 *)(var_70h + 0x18) = 0;
        *(undefined8 *)(var_70h + 0x20) = 0;
        *(undefined8 *)(var_70h + 0x28) = 0x3f000000;
        *(float *)(var_70h + 0x30) = (fVar5 + fVar1) / (fVar1 - fVar5);
        *(float *)(var_70h + 0x34) = (fVar6 + fVar2) / (fVar6 - fVar2);
        *(undefined4 *)(var_70h + 0x38) = 0x3f000000;
        *(undefined4 *)(var_70h + 0x3c) = 0x3f800000;
        (**(code **)(*(int64_t *)arg2 + 0x78))(arg2, *(undefined8 *)(iVar4 + 0x38), 0);
    }
    var_74h = 0x14;
    var_78h = 0;
    (**(code **)(*(int64_t *)arg2 + 0x88))(arg2, *(undefined8 *)(iVar4 + 0x30));
    var_80h = (int64_t)&var_78h;
    var_88h = (int64_t)&var_74h;
    (**(code **)(*(int64_t *)arg2 + 0x90))(arg2, 0, 1, iVar4 + 0x18);
    (**(code **)(*(int64_t *)arg2 + 0x98))(arg2, *(undefined8 *)(iVar4 + 0x20), 0x39, 0);
    (**(code **)(*(int64_t *)arg2 + 0xc0))(arg2, 4);
    (**(code **)(*(int64_t *)arg2 + 0x58))(arg2, *(undefined8 *)(iVar4 + 0x28), 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x38))(arg2, 0, 1, iVar4 + 0x38);
    (**(code **)(*(int64_t *)arg2 + 0x48))(arg2, *(undefined8 *)(iVar4 + 0x40), 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x50))(arg2, 0, 1, iVar4 + 0x48);
    (**(code **)(*(int64_t *)arg2 + 0xb8))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x1e0))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x200))(arg2, 0, 0, 0);
    (**(code **)(*(int64_t *)arg2 + 0x228))(arg2, 0, 0, 0);
    var_48h = ZEXT816(0);
    (**(code **)(*(int64_t *)arg2 + 0x118))(arg2, *(undefined8 *)(iVar4 + 0x60), var_48h, 0xffffffff);
    (**(code **)(*(int64_t *)arg2 + 0x120))(arg2, *(undefined8 *)(iVar4 + 0x68), 0);
    (**(code **)(*(int64_t *)arg2 + 0x158))(arg2, *(undefined8 *)(iVar4 + 0x58));
    func_0x000180459870(var_38h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_1801660f0
// Address: 0x1801660f0
// Size: 73 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c18h
// WARNING: [rz-ghidra] Detected overlap for variable var_196ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1968h
// WARNING: [rz-ghidra] Detected overlap for variable var_1934h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.1801660f0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    uint16_t *puVar1;
    float *pfVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    uint16_t uVar7;
    uint16_t uVar8;
    int32_t *piVar9;
    int64_t iVar10;
    int64_t iVar11;
    code *pcVar12;
    undefined8 *puVar13;
    int64_t *piVar14;
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int32_t iVar19;
    int64_t iVar20;
    undefined (*pauVar21) [16];
    undefined8 uVar22;
    int32_t **ppiVar23;
    int64_t in_RCX;
    int32_t **ppiVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    undefined8 unaff_RBX;
    int64_t **ppiVar27;
    uint16_t *puVar28;
    uint64_t uVar29;
    int32_t iVar30;
    undefined8 unaff_RSI;
    int64_t *piVar31;
    undefined8 unaff_RDI;
    undefined (*pauVar32) [16];
    int64_t *piVar33;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int32_t iVar34;
    undefined8 unaff_R15;
    undefined (*pauVar35) [16];
    float fVar36;
    float fVar37;
    float fVar38;
    float fVar39;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_1c48h;
    int64_t var_1c40h;
    int64_t var_1c30h;
    undefined4 var_1c18h;
    undefined4 var_1c14h;
    int64_t var_1c10h;
    int64_t var_1b10h;
    int64_t var_1990h;
    int64_t var_1988h;
    int64_t var_1980h;
    int64_t var_1970h;
    int64_t *var_1968h;
    int64_t var_1960h;
    int64_t var_1958h;
    int64_t var_1950h;
    int64_t var_1948h;
    int64_t var_1940h;
    int64_t var_1938h;
    int64_t var_1930h;
    int64_t var_1928h;
    int64_t var_1128h;
    int64_t var_928h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    undefined var_100h [4];
    int64_t var_fch;
    int64_t var_e8h;
    undefined4 var_e0h;
    int32_t var_dch;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t var_c8h;
    int32_t var_c4h;
    int64_t var_c0h;
    undefined4 var_b4h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 var_a0h;
    undefined4 var_9ch;
    undefined4 var_98h;
    int64_t var_94h;
    int64_t var_8ch;
    int64_t var_84h;
    int64_t var_78h;
    undefined8 uStack_18;
    
    uStack_18 = 0x180166106;
    iVar20 = func_0x00018045a350();
    iVar20 = -iVar20;
    var_78h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20);
    *(int64_t *)((int64_t)&arg_48h + iVar20) = in_RCX;
    if ((*(float *)(in_RCX + 0x28) <= 0.0) || (*(float *)(in_RCX + 0x2c) <= 0.0)) goto code_r0x000180166cee;
    *(undefined8 *)(&stack0x00001cc8 + iVar20) = unaff_RBX;
    *(undefined8 *)(&stack0x00001cd0 + iVar20) = unaff_RSI;
    *(undefined8 *)(&stack0x00001cd8 + iVar20) = unaff_RDI;
    *(undefined8 *)(&stack0x00001c90 + iVar20) = unaff_R15;
    if (*(int64_t *)0x180781f28 == 0) {
        ppiVar27 = (int64_t **)0x0;
    } else {
        ppiVar27 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    piVar9 = *(int32_t **)(in_RCX + 0x40);
    piVar33 = ppiVar27[1];
    *(undefined8 *)(&stack0x00001ca0 + iVar20) = unaff_R12;
    *(int64_t ***)((int64_t)&arg_30h + iVar20) = ppiVar27;
    *(undefined8 *)(&stack0x00001c98 + iVar20) = unaff_R14;
    *(int64_t **)((int64_t)&arg_40h + iVar20) = piVar33;
    if (piVar9 != (int32_t *)0x0) {
        piVar31 = *(int64_t **)(piVar9 + 2);
        piVar14 = piVar31 + *piVar9;
        if (piVar31 != piVar14) {
            do {
                iVar10 = *piVar31;
                iVar19 = *(int32_t *)(iVar10 + 4);
                if (iVar19 != 0) {
                    pauVar32 = (undefined (*) [16])0x0;
                    pauVar35 = pauVar32;
                    if (*(int64_t *)0x180781f28 != 0) {
                        pauVar35 = *(undefined (**) [16])(*(int64_t *)0x180781f28 + 0xd8);
                    }
                    if (iVar19 == 2) {
                        iVar11 = *(int64_t *)(iVar10 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166200;
                        pauVar21 = (undefined (*) [16])func_0x00018046d050(0x10);
                        if (pauVar21 != (undefined (*) [16])0x0) {
                            *pauVar21 = ZEXT816(0);
                            pauVar32 = pauVar21;
                        }
                        var_a8h._0_4_ = *(int32_t *)(iVar10 + 0x1c);
                        var_a8h._4_4_ = *(undefined4 *)(iVar10 + 0x20);
                        var_c8h = (int32_t)var_a8h * 4;
                        var_94h = 1;
                        piVar33 = *(int64_t **)*pauVar35;
                        var_84h = 0;
                        var_a0h = 1;
                        var_9ch = 1;
                        var_98h = 0x1c;
                        var_8ch._0_4_ = 0;
                        var_8ch._4_4_ = 8;
                        var_c4h = 0;
                        pcVar12 = *(code **)(*piVar33 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016629d;
                        var_d0h = iVar11;
                        (*pcVar12)(piVar33, &var_a8h, &var_d0h, pauVar32);
                        piVar33 = *(int64_t **)*pauVar35;
                        var_b0h = 0;
                        var_c0h._0_4_ = 0x1c;
                        stack0xffffffffffffff44 = 4;
                        var_b4h = var_a0h;
                        uVar22 = *(undefined8 *)*pauVar32;
                        pcVar12 = *(code **)(*piVar33 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801662dc;
                        (*pcVar12)(piVar33, uVar22, &var_c0h, *pauVar32 + 8);
                        *(undefined8 *)(iVar10 + 0x10) = *(undefined8 *)(*pauVar32 + 8);
                        *(undefined4 *)(iVar10 + 4) = 0;
                        *(undefined (**) [16])(iVar10 + 8) = pauVar32;
                    } else if (iVar19 == 3) {
                        puVar28 = *(uint16_t **)(iVar10 + 0x48);
                        *(undefined8 *)((int64_t)&arg_38h + iVar20) = *(undefined8 *)(iVar10 + 8);
                        puVar1 = puVar28 + (int64_t)*(int32_t *)(iVar10 + 0x40) * 4;
                        if (puVar28 != puVar1) {
                            puVar13 = *(undefined8 **)((int64_t)&arg_38h + iVar20);
                            do {
                                uVar7 = *puVar28;
                                uVar8 = puVar28[1];
                                iVar19 = *(int32_t *)(iVar10 + 0x24);
                                var_e8h._0_4_ = (uint32_t)uVar7;
                                var_dch = puVar28[2] + (uint32_t)var_e8h;
                                piVar33 = *(int64_t **)(*pauVar35 + 8);
                                uVar22 = *puVar13;
                                iVar34 = *(int32_t *)(iVar10 + 0x1c);
                                var_e8h._4_4_ = (uint32_t)uVar8;
                                var_e0h = 0;
                                var_d8h = CONCAT44(1, (uint32_t)puVar28[3] + (uint32_t)uVar8);
                                iVar11 = *piVar33;
                                *(undefined4 *)((int64_t)&var_20h + iVar20) = 0;
                                iVar30 = *(int32_t *)(iVar10 + 0x24);
                                *(int32_t *)((int64_t)&var_18h + iVar20) = iVar19 * iVar34;
                                *(int64_t *)((int64_t)&var_10h + iVar20) =
                                     (int64_t)(int32_t)((iVar34 * (uint32_t)uVar8 + (uint32_t)uVar7) * iVar30) +
                                     *(int64_t *)(iVar10 + 0x28);
                                pcVar12 = *(code **)(iVar11 + 0x180);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663ae;
                                (*pcVar12)(piVar33, uVar22, 0, &var_e8h);
                                puVar28 = puVar28 + 4;
                            } while (puVar28 != puVar1);
                        }
                        *(undefined4 *)(iVar10 + 4) = 0;
                    } else if ((iVar19 == 4) && (0 < *(int32_t *)(iVar10 + 0x50))) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663d7;
                        func_0x000180166d10(iVar10);
                    }
                }
                piVar31 = piVar31 + 1;
            } while (piVar31 != piVar14);
            piVar33 = *(int64_t **)((int64_t)&arg_40h + iVar20);
            in_RCX = *(int64_t *)((int64_t)&arg_48h + iVar20);
            ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
        }
    }
    if (ppiVar27[3] == (int64_t *)0x0) {
code_r0x000180166413:
        piVar14 = *ppiVar27;
        iVar19 = *(int32_t *)(in_RCX + 0xc) + 5000;
        var_d8h = 0;
        *(int32_t *)(ppiVar27 + 0xe) = iVar19;
        var_e8h._4_4_ = 2;
        var_e0h = 1;
        var_dch = 0x10000;
        var_e8h._0_4_ = iVar19 * 0x14;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016646b;
        iVar19 = (*pcVar12)(piVar14, &var_e8h, 0, ppiVar27 + 3);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)(ppiVar27 + 0xe) < *(int32_t *)(in_RCX + 0xc)) {
        pcVar12 = *(code **)(*ppiVar27[3] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016640b;
        (*pcVar12)();
        ppiVar27[3] = (int64_t *)0x0;
        goto code_r0x000180166413;
    }
    if (ppiVar27[4] == (int64_t *)0x0) {
code_r0x000180166493:
        piVar14 = *ppiVar27;
        var_c0h._0_4_ = *(int32_t *)(in_RCX + 8) + 10000;
        var_b0h = 0;
        *(int32_t *)((int64_t)ppiVar27 + 0x74) = (int32_t)var_c0h;
        var_c0h._0_4_ = (int32_t)var_c0h * 2;
        stack0xffffffffffffff44 = 0x200000002;
        var_b4h = 0x10000;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801664e7;
        iVar19 = (*pcVar12)(piVar14, &var_c0h, 0, ppiVar27 + 4);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)((int64_t)ppiVar27 + 0x74) < *(int32_t *)(in_RCX + 8)) {
        pcVar12 = *(code **)(*ppiVar27[4] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016648b;
        (*pcVar12)();
        ppiVar27[4] = (int64_t *)0x0;
        goto code_r0x000180166493;
    }
    iVar10 = *piVar33;
    piVar14 = ppiVar27[3];
    *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c40h;
    *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
    pcVar12 = *(code **)(iVar10 + 0x70);
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166516;
    iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
    if (iVar19 == 0) {
        iVar10 = *piVar33;
        piVar14 = ppiVar27[4];
        *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c30h;
        *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
        pcVar12 = *(code **)(iVar10 + 0x70);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166545;
        iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
        if (iVar19 == 0) {
            piVar31 = *(int64_t **)(in_RCX + 0x18);
            iVar19 = *(int32_t *)(in_RCX + 0x10);
            auVar15._4_4_ = unaff_XMM6_Db;
            auVar15._0_4_ = unaff_XMM6_Da;
            auVar15._8_4_ = unaff_XMM6_Dc;
            auVar15._12_4_ = unaff_XMM6_Dd;
            *(undefined (*) [16])(&stack0x00001c80 + iVar20) = auVar15;
            auVar16._4_4_ = unaff_XMM7_Db;
            auVar16._0_4_ = unaff_XMM7_Da;
            auVar16._8_4_ = unaff_XMM7_Dc;
            auVar16._12_4_ = unaff_XMM7_Dd;
            *(undefined (*) [16])(&stack0x00001c70 + iVar20) = auVar16;
            piVar14 = piVar31 + iVar19;
            auVar17._4_4_ = unaff_XMM8_Db;
            auVar17._0_4_ = unaff_XMM8_Da;
            auVar17._8_4_ = unaff_XMM8_Dc;
            auVar17._12_4_ = unaff_XMM8_Dd;
            *(undefined (*) [16])(&stack0x00001c60 + iVar20) = auVar17;
            auVar18._4_4_ = unaff_XMM9_Db;
            auVar18._0_4_ = unaff_XMM9_Da;
            auVar18._8_4_ = unaff_XMM9_Dc;
            auVar18._12_4_ = unaff_XMM9_Dd;
            *(undefined (*) [16])(&stack0x00001c50 + iVar20) = auVar18;
            if (piVar31 != piVar14) {
                do {
                    iVar10 = *piVar31;
                    iVar19 = *(int32_t *)(iVar10 + 0x20);
                    uVar22 = *(undefined8 *)(iVar10 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665ab;
                    fcn.180498030(var_1c40h, uVar22, (int64_t)iVar19 * 0x14);
                    iVar19 = *(int32_t *)(iVar10 + 0x10);
                    uVar22 = *(undefined8 *)(iVar10 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665be;
                    fcn.180498030(var_1c30h, uVar22, (int64_t)iVar19 * 2);
                    piVar31 = piVar31 + 1;
                    var_1c40h = var_1c40h + (int64_t)*(int32_t *)(iVar10 + 0x20) * 0x14;
                    var_1c30h = var_1c30h + (int64_t)*(int32_t *)(iVar10 + 0x10) * 2;
                } while (piVar31 != piVar14);
                ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
            }
            piVar14 = ppiVar27[3];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665f0;
            (*pcVar12)(piVar33, piVar14, 0);
            piVar14 = ppiVar27[4];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166600;
            (*pcVar12)(piVar33, piVar14, 0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166611;
            func_0x0001804986e0(&var_1c10h, 0, 0x1b20);
            var_1c14h = 0x10;
            var_1c18h = 0x10;
            pcVar12 = *(code **)(*piVar33 + 0x300);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166633;
            (*pcVar12)(piVar33, &var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016664a;
            (*pcVar12)(piVar33, &var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016665d;
            (*pcVar12)(piVar33, &var_1990h);
            pcVar12 = *(code **)(*piVar33 + 0x2d8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016667e;
            (*pcVar12)(piVar33, &var_1988h, &var_1980h, &var_1970h);
            pcVar12 = *(code **)(*piVar33 + 0x2e0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166698;
            (*pcVar12)(piVar33, &var_1968h, (int64_t)&var_1970h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x248);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666b3;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            pcVar12 = *(code **)(*piVar33 + 600);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666ce;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            var_1930h._0_4_ = 0x100;
            var_1938h._4_4_ = 0x100;
            var_1938h._0_4_ = 0x100;
            pcVar12 = *(code **)(*piVar33 + 0x250);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016670d;
            (*pcVar12)(piVar33, &var_1950h, &var_1928h, &var_1938h);
            pcVar12 = *(code **)(*piVar33 + 0x260);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016672e;
            (*pcVar12)(piVar33, &var_1948h, &var_1128h, (int64_t)&var_1938h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x240);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166749;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            pcVar12 = *(code **)(*piVar33 + 0x290);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016676a;
            (*pcVar12)(piVar33, &var_1940h, &var_928h, &var_1930h);
            pcVar12 = *(code **)(*piVar33 + 0x298);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016677d;
            (*pcVar12)(piVar33, &var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x280);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016679e;
            (*pcVar12)(piVar33, &var_120h, &var_fch, &var_108h);
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x278);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667d1;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            pcVar12 = *(code **)(*piVar33 + 0x270);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667e4;
            (*pcVar12)(piVar33, (int64_t)&var_fch + 4);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667ef;
            fcn.180165e00(in_RCX, (int64_t)piVar33);
            *(int64_t **)((int64_t)&arg_50h + iVar20) = *ppiVar27;
            iVar34 = 0;
            iVar19 = 0;
            *(int64_t **)((int64_t)&arg_58h + iVar20) = ppiVar27[1];
            *(int64_t **)((int64_t)&arg_60h + iVar20) = ppiVar27[9];
            *(int64_t **)((int64_t)&arg_68h + iVar20) = ppiVar27[10];
            *(int64_t *)((int64_t)&arg_38h + iVar20) = *(int64_t *)0x180781f28;
            *(int64_t *)(*(int64_t *)0x180781f28 + 0xc90) = (int64_t)&arg_50h + iVar20;
            ppiVar24 = *(int32_t ***)(in_RCX + 0x18);
            fVar3 = *(float *)(in_RCX + 0x20);
            fVar4 = *(float *)(in_RCX + 0x24);
            fVar5 = *(float *)(in_RCX + 0x30);
            fVar6 = *(float *)(in_RCX + 0x34);
            ppiVar23 = ppiVar24 + *(int32_t *)(in_RCX + 0x10);
            *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
            *(int32_t ***)((int64_t)&arg_40h + iVar20) = ppiVar23;
            if (ppiVar24 != ppiVar23) {
                do {
                    piVar9 = *ppiVar24;
                    iVar30 = 0;
                    if (0 < *piVar9) {
                        do {
                            pfVar2 = (float *)(*(int64_t *)(piVar9 + 2) + (int64_t)iVar30 * 0x48);
                            pcVar12 = *(code **)(*(int64_t *)(piVar9 + 2) + 0x30 + (int64_t)iVar30 * 0x48);
                            if (pcVar12 == (code *)0x0) {
                                fVar36 = (*pfVar2 - fVar3) * fVar5;
                                fVar37 = (pfVar2[2] - fVar3) * fVar5;
                                if (fVar36 < fVar37) {
                                    fVar38 = (pfVar2[1] - fVar4) * fVar6;
                                    fVar39 = (pfVar2[3] - fVar4) * fVar6;
                                    if (fVar38 < fVar39) {
                                        var_d0h = CONCAT44((int32_t)fVar38, (int32_t)fVar36);
                                        var_c8h = (int32_t)fVar37;
                                        var_c4h = (int32_t)fVar39;
                                        pcVar12 = *(code **)(*piVar33 + 0x168);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166945;
                                        (*pcVar12)(piVar33, 1, &var_d0h);
                                        if (*(int64_t *)(pfVar2 + 4) == 0) {
                                            uVar22 = *(undefined8 *)(pfVar2 + 6);
                                        } else {
                                            uVar22 = *(undefined8 *)(*(int64_t *)(pfVar2 + 4) + 0x10);
                                        }
                                        *(undefined8 *)((int64_t)&arg_48h + iVar20) = uVar22;
                                        pcVar12 = *(code **)(*piVar33 + 0x40);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166973;
                                        (*pcVar12)(piVar33, 0, 1, (int64_t)&arg_48h + iVar20);
                                        fVar36 = pfVar2[8];
                                        fVar37 = pfVar2[9];
                                        fVar38 = pfVar2[10];
                                        pcVar12 = *(code **)(*piVar33 + 0x60);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016698e;
                                        (*pcVar12)(piVar33, fVar38, (int32_t)fVar37 + iVar34, (int32_t)fVar36 + iVar19);
                                    }
                                }
                            } else if (pcVar12 == (code *)0xfffffffffffffff8) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668aa;
                                fcn.180165e00(in_RCX, (int64_t)piVar33);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668b7;
                                (*pcVar12)(piVar9, pfVar2);
                            }
                            iVar30 = iVar30 + 1;
                        } while (iVar30 < *piVar9);
                        ppiVar24 = *(int32_t ***)((int64_t)&arg_30h + iVar20);
                        ppiVar23 = *(int32_t ***)((int64_t)&arg_40h + iVar20);
                    }
                    iVar34 = iVar34 + piVar9[4];
                    ppiVar24 = ppiVar24 + 1;
                    iVar19 = iVar19 + piVar9[8];
                    *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
                } while (ppiVar24 != ppiVar23);
            }
            *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar20) + 0xc90) = 0;
            pcVar12 = *(code **)(*piVar33 + 0x168);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669e0;
            (*pcVar12)(piVar33, var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x160);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669f6;
            (*pcVar12)(piVar33, var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x158);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a09;
            (*pcVar12)(piVar33, var_1990h);
            if (var_1990h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1990h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a3d;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x118);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a5e;
            (*pcVar12)(piVar33, var_1988h, &var_1980h, (undefined4)var_1970h);
            if (var_1988h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1988h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a70;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x120);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a8a;
            (*pcVar12)(piVar33, var_1968h, var_1970h._4_4_);
            if (var_1968h != (int64_t *)0x0) {
                pcVar12 = *(code **)(*var_1968h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a9c;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ab4;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            if (var_1960h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1960h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ac6;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x50);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ade;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            if (var_1958h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1958h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166af0;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x48);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b0e;
            (*pcVar12)(piVar33, var_1950h, &var_1928h, (uint32_t)var_1938h);
            if (var_1950h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1950h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b20;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = (uint32_t)var_1938h;
            if ((uint32_t)var_1938h != 0) {
                do {
                    if ((int64_t *)(&var_1928h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1928h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b43;
                        (*pcVar12)();
                        uVar25 = (uint32_t)var_1938h;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0x58);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b6d;
            (*pcVar12)(piVar33, var_1948h, &var_1128h, var_1938h._4_4_);
            if (var_1948h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1948h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b7f;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b97;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            if (var_110h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_110h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ba9;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0xb8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bca;
            (*pcVar12)(piVar33, var_1940h, &var_928h, (undefined4)var_1930h);
            if (var_1940h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1940h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bdc;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = var_1938h._4_4_;
            if (var_1938h._4_4_ != 0) {
                do {
                    if ((int64_t *)(&var_1128h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1128h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c03;
                        (*pcVar12)();
                        uVar25 = var_1938h._4_4_;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0xc0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c21;
            (*pcVar12)(piVar33, (undefined4)var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x98);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c42;
            (*pcVar12)(piVar33, var_120h, (undefined4)var_fch, (undefined4)var_108h);
            if (var_120h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_120h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c54;
                (*pcVar12)();
            }
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x90);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c87;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            if (var_118h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_118h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c99;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x88);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cac;
            (*pcVar12)(piVar33, stack0xffffffffffffff08);
            if (stack0xffffffffffffff08 != (int64_t *)0x0) {
                pcVar12 = *(code **)(*stack0xffffffffffffff08 + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cbe;
                (*pcVar12)();
            }
        }
    }
code_r0x000180166cee:
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cfd;
    func_0x000180459870(var_78h ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20));
    return;
}

// ============================================================
// Function: FUN_180166139
// Address: 0x180166139
// Size: 1060 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c18h
// WARNING: [rz-ghidra] Detected overlap for variable var_196ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1968h
// WARNING: [rz-ghidra] Detected overlap for variable var_1934h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.1801660f0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    uint16_t *puVar1;
    float *pfVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    uint16_t uVar7;
    uint16_t uVar8;
    int32_t *piVar9;
    int64_t iVar10;
    int64_t iVar11;
    code *pcVar12;
    undefined8 *puVar13;
    int64_t *piVar14;
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int32_t iVar19;
    int64_t iVar20;
    undefined (*pauVar21) [16];
    undefined8 uVar22;
    int32_t **ppiVar23;
    int64_t in_RCX;
    int32_t **ppiVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    undefined8 unaff_RBX;
    int64_t **ppiVar27;
    uint16_t *puVar28;
    uint64_t uVar29;
    int32_t iVar30;
    undefined8 unaff_RSI;
    int64_t *piVar31;
    undefined8 unaff_RDI;
    undefined (*pauVar32) [16];
    int64_t *piVar33;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int32_t iVar34;
    undefined8 unaff_R15;
    undefined (*pauVar35) [16];
    float fVar36;
    float fVar37;
    float fVar38;
    float fVar39;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_1c48h;
    int64_t var_1c40h;
    int64_t var_1c30h;
    undefined4 var_1c18h;
    undefined4 var_1c14h;
    int64_t var_1c10h;
    int64_t var_1b10h;
    int64_t var_1990h;
    int64_t var_1988h;
    int64_t var_1980h;
    int64_t var_1970h;
    int64_t *var_1968h;
    int64_t var_1960h;
    int64_t var_1958h;
    int64_t var_1950h;
    int64_t var_1948h;
    int64_t var_1940h;
    int64_t var_1938h;
    int64_t var_1930h;
    int64_t var_1928h;
    int64_t var_1128h;
    int64_t var_928h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    undefined var_100h [4];
    int64_t var_fch;
    int64_t var_e8h;
    undefined4 var_e0h;
    int32_t var_dch;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t var_c8h;
    int32_t var_c4h;
    int64_t var_c0h;
    undefined4 var_b4h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 var_a0h;
    undefined4 var_9ch;
    undefined4 var_98h;
    int64_t var_94h;
    int64_t var_8ch;
    int64_t var_84h;
    int64_t var_78h;
    undefined8 uStack_18;
    
    uStack_18 = 0x180166106;
    iVar20 = func_0x00018045a350();
    iVar20 = -iVar20;
    var_78h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20);
    *(int64_t *)((int64_t)&arg_48h + iVar20) = in_RCX;
    if ((*(float *)(in_RCX + 0x28) <= 0.0) || (*(float *)(in_RCX + 0x2c) <= 0.0)) goto code_r0x000180166cee;
    *(undefined8 *)(&stack0x00001cc8 + iVar20) = unaff_RBX;
    *(undefined8 *)(&stack0x00001cd0 + iVar20) = unaff_RSI;
    *(undefined8 *)(&stack0x00001cd8 + iVar20) = unaff_RDI;
    *(undefined8 *)(&stack0x00001c90 + iVar20) = unaff_R15;
    if (*(int64_t *)0x180781f28 == 0) {
        ppiVar27 = (int64_t **)0x0;
    } else {
        ppiVar27 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    piVar9 = *(int32_t **)(in_RCX + 0x40);
    piVar33 = ppiVar27[1];
    *(undefined8 *)(&stack0x00001ca0 + iVar20) = unaff_R12;
    *(int64_t ***)((int64_t)&arg_30h + iVar20) = ppiVar27;
    *(undefined8 *)(&stack0x00001c98 + iVar20) = unaff_R14;
    *(int64_t **)((int64_t)&arg_40h + iVar20) = piVar33;
    if (piVar9 != (int32_t *)0x0) {
        piVar31 = *(int64_t **)(piVar9 + 2);
        piVar14 = piVar31 + *piVar9;
        if (piVar31 != piVar14) {
            do {
                iVar10 = *piVar31;
                iVar19 = *(int32_t *)(iVar10 + 4);
                if (iVar19 != 0) {
                    pauVar32 = (undefined (*) [16])0x0;
                    pauVar35 = pauVar32;
                    if (*(int64_t *)0x180781f28 != 0) {
                        pauVar35 = *(undefined (**) [16])(*(int64_t *)0x180781f28 + 0xd8);
                    }
                    if (iVar19 == 2) {
                        iVar11 = *(int64_t *)(iVar10 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166200;
                        pauVar21 = (undefined (*) [16])func_0x00018046d050(0x10);
                        if (pauVar21 != (undefined (*) [16])0x0) {
                            *pauVar21 = ZEXT816(0);
                            pauVar32 = pauVar21;
                        }
                        var_a8h._0_4_ = *(int32_t *)(iVar10 + 0x1c);
                        var_a8h._4_4_ = *(undefined4 *)(iVar10 + 0x20);
                        var_c8h = (int32_t)var_a8h * 4;
                        var_94h = 1;
                        piVar33 = *(int64_t **)*pauVar35;
                        var_84h = 0;
                        var_a0h = 1;
                        var_9ch = 1;
                        var_98h = 0x1c;
                        var_8ch._0_4_ = 0;
                        var_8ch._4_4_ = 8;
                        var_c4h = 0;
                        pcVar12 = *(code **)(*piVar33 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016629d;
                        var_d0h = iVar11;
                        (*pcVar12)(piVar33, &var_a8h, &var_d0h, pauVar32);
                        piVar33 = *(int64_t **)*pauVar35;
                        var_b0h = 0;
                        var_c0h._0_4_ = 0x1c;
                        stack0xffffffffffffff44 = 4;
                        var_b4h = var_a0h;
                        uVar22 = *(undefined8 *)*pauVar32;
                        pcVar12 = *(code **)(*piVar33 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801662dc;
                        (*pcVar12)(piVar33, uVar22, &var_c0h, *pauVar32 + 8);
                        *(undefined8 *)(iVar10 + 0x10) = *(undefined8 *)(*pauVar32 + 8);
                        *(undefined4 *)(iVar10 + 4) = 0;
                        *(undefined (**) [16])(iVar10 + 8) = pauVar32;
                    } else if (iVar19 == 3) {
                        puVar28 = *(uint16_t **)(iVar10 + 0x48);
                        *(undefined8 *)((int64_t)&arg_38h + iVar20) = *(undefined8 *)(iVar10 + 8);
                        puVar1 = puVar28 + (int64_t)*(int32_t *)(iVar10 + 0x40) * 4;
                        if (puVar28 != puVar1) {
                            puVar13 = *(undefined8 **)((int64_t)&arg_38h + iVar20);
                            do {
                                uVar7 = *puVar28;
                                uVar8 = puVar28[1];
                                iVar19 = *(int32_t *)(iVar10 + 0x24);
                                var_e8h._0_4_ = (uint32_t)uVar7;
                                var_dch = puVar28[2] + (uint32_t)var_e8h;
                                piVar33 = *(int64_t **)(*pauVar35 + 8);
                                uVar22 = *puVar13;
                                iVar34 = *(int32_t *)(iVar10 + 0x1c);
                                var_e8h._4_4_ = (uint32_t)uVar8;
                                var_e0h = 0;
                                var_d8h = CONCAT44(1, (uint32_t)puVar28[3] + (uint32_t)uVar8);
                                iVar11 = *piVar33;
                                *(undefined4 *)((int64_t)&var_20h + iVar20) = 0;
                                iVar30 = *(int32_t *)(iVar10 + 0x24);
                                *(int32_t *)((int64_t)&var_18h + iVar20) = iVar19 * iVar34;
                                *(int64_t *)((int64_t)&var_10h + iVar20) =
                                     (int64_t)(int32_t)((iVar34 * (uint32_t)uVar8 + (uint32_t)uVar7) * iVar30) +
                                     *(int64_t *)(iVar10 + 0x28);
                                pcVar12 = *(code **)(iVar11 + 0x180);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663ae;
                                (*pcVar12)(piVar33, uVar22, 0, &var_e8h);
                                puVar28 = puVar28 + 4;
                            } while (puVar28 != puVar1);
                        }
                        *(undefined4 *)(iVar10 + 4) = 0;
                    } else if ((iVar19 == 4) && (0 < *(int32_t *)(iVar10 + 0x50))) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663d7;
                        func_0x000180166d10(iVar10);
                    }
                }
                piVar31 = piVar31 + 1;
            } while (piVar31 != piVar14);
            piVar33 = *(int64_t **)((int64_t)&arg_40h + iVar20);
            in_RCX = *(int64_t *)((int64_t)&arg_48h + iVar20);
            ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
        }
    }
    if (ppiVar27[3] == (int64_t *)0x0) {
code_r0x000180166413:
        piVar14 = *ppiVar27;
        iVar19 = *(int32_t *)(in_RCX + 0xc) + 5000;
        var_d8h = 0;
        *(int32_t *)(ppiVar27 + 0xe) = iVar19;
        var_e8h._4_4_ = 2;
        var_e0h = 1;
        var_dch = 0x10000;
        var_e8h._0_4_ = iVar19 * 0x14;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016646b;
        iVar19 = (*pcVar12)(piVar14, &var_e8h, 0, ppiVar27 + 3);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)(ppiVar27 + 0xe) < *(int32_t *)(in_RCX + 0xc)) {
        pcVar12 = *(code **)(*ppiVar27[3] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016640b;
        (*pcVar12)();
        ppiVar27[3] = (int64_t *)0x0;
        goto code_r0x000180166413;
    }
    if (ppiVar27[4] == (int64_t *)0x0) {
code_r0x000180166493:
        piVar14 = *ppiVar27;
        var_c0h._0_4_ = *(int32_t *)(in_RCX + 8) + 10000;
        var_b0h = 0;
        *(int32_t *)((int64_t)ppiVar27 + 0x74) = (int32_t)var_c0h;
        var_c0h._0_4_ = (int32_t)var_c0h * 2;
        stack0xffffffffffffff44 = 0x200000002;
        var_b4h = 0x10000;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801664e7;
        iVar19 = (*pcVar12)(piVar14, &var_c0h, 0, ppiVar27 + 4);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)((int64_t)ppiVar27 + 0x74) < *(int32_t *)(in_RCX + 8)) {
        pcVar12 = *(code **)(*ppiVar27[4] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016648b;
        (*pcVar12)();
        ppiVar27[4] = (int64_t *)0x0;
        goto code_r0x000180166493;
    }
    iVar10 = *piVar33;
    piVar14 = ppiVar27[3];
    *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c40h;
    *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
    pcVar12 = *(code **)(iVar10 + 0x70);
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166516;
    iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
    if (iVar19 == 0) {
        iVar10 = *piVar33;
        piVar14 = ppiVar27[4];
        *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c30h;
        *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
        pcVar12 = *(code **)(iVar10 + 0x70);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166545;
        iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
        if (iVar19 == 0) {
            piVar31 = *(int64_t **)(in_RCX + 0x18);
            iVar19 = *(int32_t *)(in_RCX + 0x10);
            auVar15._4_4_ = unaff_XMM6_Db;
            auVar15._0_4_ = unaff_XMM6_Da;
            auVar15._8_4_ = unaff_XMM6_Dc;
            auVar15._12_4_ = unaff_XMM6_Dd;
            *(undefined (*) [16])(&stack0x00001c80 + iVar20) = auVar15;
            auVar16._4_4_ = unaff_XMM7_Db;
            auVar16._0_4_ = unaff_XMM7_Da;
            auVar16._8_4_ = unaff_XMM7_Dc;
            auVar16._12_4_ = unaff_XMM7_Dd;
            *(undefined (*) [16])(&stack0x00001c70 + iVar20) = auVar16;
            piVar14 = piVar31 + iVar19;
            auVar17._4_4_ = unaff_XMM8_Db;
            auVar17._0_4_ = unaff_XMM8_Da;
            auVar17._8_4_ = unaff_XMM8_Dc;
            auVar17._12_4_ = unaff_XMM8_Dd;
            *(undefined (*) [16])(&stack0x00001c60 + iVar20) = auVar17;
            auVar18._4_4_ = unaff_XMM9_Db;
            auVar18._0_4_ = unaff_XMM9_Da;
            auVar18._8_4_ = unaff_XMM9_Dc;
            auVar18._12_4_ = unaff_XMM9_Dd;
            *(undefined (*) [16])(&stack0x00001c50 + iVar20) = auVar18;
            if (piVar31 != piVar14) {
                do {
                    iVar10 = *piVar31;
                    iVar19 = *(int32_t *)(iVar10 + 0x20);
                    uVar22 = *(undefined8 *)(iVar10 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665ab;
                    fcn.180498030(var_1c40h, uVar22, (int64_t)iVar19 * 0x14);
                    iVar19 = *(int32_t *)(iVar10 + 0x10);
                    uVar22 = *(undefined8 *)(iVar10 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665be;
                    fcn.180498030(var_1c30h, uVar22, (int64_t)iVar19 * 2);
                    piVar31 = piVar31 + 1;
                    var_1c40h = var_1c40h + (int64_t)*(int32_t *)(iVar10 + 0x20) * 0x14;
                    var_1c30h = var_1c30h + (int64_t)*(int32_t *)(iVar10 + 0x10) * 2;
                } while (piVar31 != piVar14);
                ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
            }
            piVar14 = ppiVar27[3];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665f0;
            (*pcVar12)(piVar33, piVar14, 0);
            piVar14 = ppiVar27[4];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166600;
            (*pcVar12)(piVar33, piVar14, 0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166611;
            func_0x0001804986e0(&var_1c10h, 0, 0x1b20);
            var_1c14h = 0x10;
            var_1c18h = 0x10;
            pcVar12 = *(code **)(*piVar33 + 0x300);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166633;
            (*pcVar12)(piVar33, &var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016664a;
            (*pcVar12)(piVar33, &var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016665d;
            (*pcVar12)(piVar33, &var_1990h);
            pcVar12 = *(code **)(*piVar33 + 0x2d8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016667e;
            (*pcVar12)(piVar33, &var_1988h, &var_1980h, &var_1970h);
            pcVar12 = *(code **)(*piVar33 + 0x2e0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166698;
            (*pcVar12)(piVar33, &var_1968h, (int64_t)&var_1970h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x248);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666b3;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            pcVar12 = *(code **)(*piVar33 + 600);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666ce;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            var_1930h._0_4_ = 0x100;
            var_1938h._4_4_ = 0x100;
            var_1938h._0_4_ = 0x100;
            pcVar12 = *(code **)(*piVar33 + 0x250);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016670d;
            (*pcVar12)(piVar33, &var_1950h, &var_1928h, &var_1938h);
            pcVar12 = *(code **)(*piVar33 + 0x260);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016672e;
            (*pcVar12)(piVar33, &var_1948h, &var_1128h, (int64_t)&var_1938h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x240);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166749;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            pcVar12 = *(code **)(*piVar33 + 0x290);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016676a;
            (*pcVar12)(piVar33, &var_1940h, &var_928h, &var_1930h);
            pcVar12 = *(code **)(*piVar33 + 0x298);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016677d;
            (*pcVar12)(piVar33, &var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x280);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016679e;
            (*pcVar12)(piVar33, &var_120h, &var_fch, &var_108h);
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x278);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667d1;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            pcVar12 = *(code **)(*piVar33 + 0x270);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667e4;
            (*pcVar12)(piVar33, (int64_t)&var_fch + 4);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667ef;
            fcn.180165e00(in_RCX, (int64_t)piVar33);
            *(int64_t **)((int64_t)&arg_50h + iVar20) = *ppiVar27;
            iVar34 = 0;
            iVar19 = 0;
            *(int64_t **)((int64_t)&arg_58h + iVar20) = ppiVar27[1];
            *(int64_t **)((int64_t)&arg_60h + iVar20) = ppiVar27[9];
            *(int64_t **)((int64_t)&arg_68h + iVar20) = ppiVar27[10];
            *(int64_t *)((int64_t)&arg_38h + iVar20) = *(int64_t *)0x180781f28;
            *(int64_t *)(*(int64_t *)0x180781f28 + 0xc90) = (int64_t)&arg_50h + iVar20;
            ppiVar24 = *(int32_t ***)(in_RCX + 0x18);
            fVar3 = *(float *)(in_RCX + 0x20);
            fVar4 = *(float *)(in_RCX + 0x24);
            fVar5 = *(float *)(in_RCX + 0x30);
            fVar6 = *(float *)(in_RCX + 0x34);
            ppiVar23 = ppiVar24 + *(int32_t *)(in_RCX + 0x10);
            *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
            *(int32_t ***)((int64_t)&arg_40h + iVar20) = ppiVar23;
            if (ppiVar24 != ppiVar23) {
                do {
                    piVar9 = *ppiVar24;
                    iVar30 = 0;
                    if (0 < *piVar9) {
                        do {
                            pfVar2 = (float *)(*(int64_t *)(piVar9 + 2) + (int64_t)iVar30 * 0x48);
                            pcVar12 = *(code **)(*(int64_t *)(piVar9 + 2) + 0x30 + (int64_t)iVar30 * 0x48);
                            if (pcVar12 == (code *)0x0) {
                                fVar36 = (*pfVar2 - fVar3) * fVar5;
                                fVar37 = (pfVar2[2] - fVar3) * fVar5;
                                if (fVar36 < fVar37) {
                                    fVar38 = (pfVar2[1] - fVar4) * fVar6;
                                    fVar39 = (pfVar2[3] - fVar4) * fVar6;
                                    if (fVar38 < fVar39) {
                                        var_d0h = CONCAT44((int32_t)fVar38, (int32_t)fVar36);
                                        var_c8h = (int32_t)fVar37;
                                        var_c4h = (int32_t)fVar39;
                                        pcVar12 = *(code **)(*piVar33 + 0x168);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166945;
                                        (*pcVar12)(piVar33, 1, &var_d0h);
                                        if (*(int64_t *)(pfVar2 + 4) == 0) {
                                            uVar22 = *(undefined8 *)(pfVar2 + 6);
                                        } else {
                                            uVar22 = *(undefined8 *)(*(int64_t *)(pfVar2 + 4) + 0x10);
                                        }
                                        *(undefined8 *)((int64_t)&arg_48h + iVar20) = uVar22;
                                        pcVar12 = *(code **)(*piVar33 + 0x40);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166973;
                                        (*pcVar12)(piVar33, 0, 1, (int64_t)&arg_48h + iVar20);
                                        fVar36 = pfVar2[8];
                                        fVar37 = pfVar2[9];
                                        fVar38 = pfVar2[10];
                                        pcVar12 = *(code **)(*piVar33 + 0x60);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016698e;
                                        (*pcVar12)(piVar33, fVar38, (int32_t)fVar37 + iVar34, (int32_t)fVar36 + iVar19);
                                    }
                                }
                            } else if (pcVar12 == (code *)0xfffffffffffffff8) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668aa;
                                fcn.180165e00(in_RCX, (int64_t)piVar33);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668b7;
                                (*pcVar12)(piVar9, pfVar2);
                            }
                            iVar30 = iVar30 + 1;
                        } while (iVar30 < *piVar9);
                        ppiVar24 = *(int32_t ***)((int64_t)&arg_30h + iVar20);
                        ppiVar23 = *(int32_t ***)((int64_t)&arg_40h + iVar20);
                    }
                    iVar34 = iVar34 + piVar9[4];
                    ppiVar24 = ppiVar24 + 1;
                    iVar19 = iVar19 + piVar9[8];
                    *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
                } while (ppiVar24 != ppiVar23);
            }
            *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar20) + 0xc90) = 0;
            pcVar12 = *(code **)(*piVar33 + 0x168);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669e0;
            (*pcVar12)(piVar33, var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x160);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669f6;
            (*pcVar12)(piVar33, var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x158);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a09;
            (*pcVar12)(piVar33, var_1990h);
            if (var_1990h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1990h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a3d;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x118);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a5e;
            (*pcVar12)(piVar33, var_1988h, &var_1980h, (undefined4)var_1970h);
            if (var_1988h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1988h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a70;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x120);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a8a;
            (*pcVar12)(piVar33, var_1968h, var_1970h._4_4_);
            if (var_1968h != (int64_t *)0x0) {
                pcVar12 = *(code **)(*var_1968h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a9c;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ab4;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            if (var_1960h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1960h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ac6;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x50);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ade;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            if (var_1958h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1958h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166af0;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x48);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b0e;
            (*pcVar12)(piVar33, var_1950h, &var_1928h, (uint32_t)var_1938h);
            if (var_1950h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1950h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b20;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = (uint32_t)var_1938h;
            if ((uint32_t)var_1938h != 0) {
                do {
                    if ((int64_t *)(&var_1928h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1928h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b43;
                        (*pcVar12)();
                        uVar25 = (uint32_t)var_1938h;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0x58);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b6d;
            (*pcVar12)(piVar33, var_1948h, &var_1128h, var_1938h._4_4_);
            if (var_1948h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1948h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b7f;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b97;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            if (var_110h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_110h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ba9;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0xb8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bca;
            (*pcVar12)(piVar33, var_1940h, &var_928h, (undefined4)var_1930h);
            if (var_1940h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1940h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bdc;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = var_1938h._4_4_;
            if (var_1938h._4_4_ != 0) {
                do {
                    if ((int64_t *)(&var_1128h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1128h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c03;
                        (*pcVar12)();
                        uVar25 = var_1938h._4_4_;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0xc0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c21;
            (*pcVar12)(piVar33, (undefined4)var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x98);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c42;
            (*pcVar12)(piVar33, var_120h, (undefined4)var_fch, (undefined4)var_108h);
            if (var_120h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_120h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c54;
                (*pcVar12)();
            }
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x90);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c87;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            if (var_118h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_118h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c99;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x88);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cac;
            (*pcVar12)(piVar33, stack0xffffffffffffff08);
            if (stack0xffffffffffffff08 != (int64_t *)0x0) {
                pcVar12 = *(code **)(*stack0xffffffffffffff08 + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cbe;
                (*pcVar12)();
            }
        }
    }
code_r0x000180166cee:
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cfd;
    func_0x000180459870(var_78h ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20));
    return;
}

// ============================================================
// Function: FUN_18016655d
// Address: 0x18016655d
// Size: 1242 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c18h
// WARNING: [rz-ghidra] Detected overlap for variable var_196ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1968h
// WARNING: [rz-ghidra] Detected overlap for variable var_1934h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.1801660f0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    uint16_t *puVar1;
    float *pfVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    uint16_t uVar7;
    uint16_t uVar8;
    int32_t *piVar9;
    int64_t iVar10;
    int64_t iVar11;
    code *pcVar12;
    undefined8 *puVar13;
    int64_t *piVar14;
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int32_t iVar19;
    int64_t iVar20;
    undefined (*pauVar21) [16];
    undefined8 uVar22;
    int32_t **ppiVar23;
    int64_t in_RCX;
    int32_t **ppiVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    undefined8 unaff_RBX;
    int64_t **ppiVar27;
    uint16_t *puVar28;
    uint64_t uVar29;
    int32_t iVar30;
    undefined8 unaff_RSI;
    int64_t *piVar31;
    undefined8 unaff_RDI;
    undefined (*pauVar32) [16];
    int64_t *piVar33;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int32_t iVar34;
    undefined8 unaff_R15;
    undefined (*pauVar35) [16];
    float fVar36;
    float fVar37;
    float fVar38;
    float fVar39;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_1c48h;
    int64_t var_1c40h;
    int64_t var_1c30h;
    undefined4 var_1c18h;
    undefined4 var_1c14h;
    int64_t var_1c10h;
    int64_t var_1b10h;
    int64_t var_1990h;
    int64_t var_1988h;
    int64_t var_1980h;
    int64_t var_1970h;
    int64_t *var_1968h;
    int64_t var_1960h;
    int64_t var_1958h;
    int64_t var_1950h;
    int64_t var_1948h;
    int64_t var_1940h;
    int64_t var_1938h;
    int64_t var_1930h;
    int64_t var_1928h;
    int64_t var_1128h;
    int64_t var_928h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    undefined var_100h [4];
    int64_t var_fch;
    int64_t var_e8h;
    undefined4 var_e0h;
    int32_t var_dch;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t var_c8h;
    int32_t var_c4h;
    int64_t var_c0h;
    undefined4 var_b4h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 var_a0h;
    undefined4 var_9ch;
    undefined4 var_98h;
    int64_t var_94h;
    int64_t var_8ch;
    int64_t var_84h;
    int64_t var_78h;
    undefined8 uStack_18;
    
    uStack_18 = 0x180166106;
    iVar20 = func_0x00018045a350();
    iVar20 = -iVar20;
    var_78h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20);
    *(int64_t *)((int64_t)&arg_48h + iVar20) = in_RCX;
    if ((*(float *)(in_RCX + 0x28) <= 0.0) || (*(float *)(in_RCX + 0x2c) <= 0.0)) goto code_r0x000180166cee;
    *(undefined8 *)(&stack0x00001cc8 + iVar20) = unaff_RBX;
    *(undefined8 *)(&stack0x00001cd0 + iVar20) = unaff_RSI;
    *(undefined8 *)(&stack0x00001cd8 + iVar20) = unaff_RDI;
    *(undefined8 *)(&stack0x00001c90 + iVar20) = unaff_R15;
    if (*(int64_t *)0x180781f28 == 0) {
        ppiVar27 = (int64_t **)0x0;
    } else {
        ppiVar27 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    piVar9 = *(int32_t **)(in_RCX + 0x40);
    piVar33 = ppiVar27[1];
    *(undefined8 *)(&stack0x00001ca0 + iVar20) = unaff_R12;
    *(int64_t ***)((int64_t)&arg_30h + iVar20) = ppiVar27;
    *(undefined8 *)(&stack0x00001c98 + iVar20) = unaff_R14;
    *(int64_t **)((int64_t)&arg_40h + iVar20) = piVar33;
    if (piVar9 != (int32_t *)0x0) {
        piVar31 = *(int64_t **)(piVar9 + 2);
        piVar14 = piVar31 + *piVar9;
        if (piVar31 != piVar14) {
            do {
                iVar10 = *piVar31;
                iVar19 = *(int32_t *)(iVar10 + 4);
                if (iVar19 != 0) {
                    pauVar32 = (undefined (*) [16])0x0;
                    pauVar35 = pauVar32;
                    if (*(int64_t *)0x180781f28 != 0) {
                        pauVar35 = *(undefined (**) [16])(*(int64_t *)0x180781f28 + 0xd8);
                    }
                    if (iVar19 == 2) {
                        iVar11 = *(int64_t *)(iVar10 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166200;
                        pauVar21 = (undefined (*) [16])func_0x00018046d050(0x10);
                        if (pauVar21 != (undefined (*) [16])0x0) {
                            *pauVar21 = ZEXT816(0);
                            pauVar32 = pauVar21;
                        }
                        var_a8h._0_4_ = *(int32_t *)(iVar10 + 0x1c);
                        var_a8h._4_4_ = *(undefined4 *)(iVar10 + 0x20);
                        var_c8h = (int32_t)var_a8h * 4;
                        var_94h = 1;
                        piVar33 = *(int64_t **)*pauVar35;
                        var_84h = 0;
                        var_a0h = 1;
                        var_9ch = 1;
                        var_98h = 0x1c;
                        var_8ch._0_4_ = 0;
                        var_8ch._4_4_ = 8;
                        var_c4h = 0;
                        pcVar12 = *(code **)(*piVar33 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016629d;
                        var_d0h = iVar11;
                        (*pcVar12)(piVar33, &var_a8h, &var_d0h, pauVar32);
                        piVar33 = *(int64_t **)*pauVar35;
                        var_b0h = 0;
                        var_c0h._0_4_ = 0x1c;
                        stack0xffffffffffffff44 = 4;
                        var_b4h = var_a0h;
                        uVar22 = *(undefined8 *)*pauVar32;
                        pcVar12 = *(code **)(*piVar33 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801662dc;
                        (*pcVar12)(piVar33, uVar22, &var_c0h, *pauVar32 + 8);
                        *(undefined8 *)(iVar10 + 0x10) = *(undefined8 *)(*pauVar32 + 8);
                        *(undefined4 *)(iVar10 + 4) = 0;
                        *(undefined (**) [16])(iVar10 + 8) = pauVar32;
                    } else if (iVar19 == 3) {
                        puVar28 = *(uint16_t **)(iVar10 + 0x48);
                        *(undefined8 *)((int64_t)&arg_38h + iVar20) = *(undefined8 *)(iVar10 + 8);
                        puVar1 = puVar28 + (int64_t)*(int32_t *)(iVar10 + 0x40) * 4;
                        if (puVar28 != puVar1) {
                            puVar13 = *(undefined8 **)((int64_t)&arg_38h + iVar20);
                            do {
                                uVar7 = *puVar28;
                                uVar8 = puVar28[1];
                                iVar19 = *(int32_t *)(iVar10 + 0x24);
                                var_e8h._0_4_ = (uint32_t)uVar7;
                                var_dch = puVar28[2] + (uint32_t)var_e8h;
                                piVar33 = *(int64_t **)(*pauVar35 + 8);
                                uVar22 = *puVar13;
                                iVar34 = *(int32_t *)(iVar10 + 0x1c);
                                var_e8h._4_4_ = (uint32_t)uVar8;
                                var_e0h = 0;
                                var_d8h = CONCAT44(1, (uint32_t)puVar28[3] + (uint32_t)uVar8);
                                iVar11 = *piVar33;
                                *(undefined4 *)((int64_t)&var_20h + iVar20) = 0;
                                iVar30 = *(int32_t *)(iVar10 + 0x24);
                                *(int32_t *)((int64_t)&var_18h + iVar20) = iVar19 * iVar34;
                                *(int64_t *)((int64_t)&var_10h + iVar20) =
                                     (int64_t)(int32_t)((iVar34 * (uint32_t)uVar8 + (uint32_t)uVar7) * iVar30) +
                                     *(int64_t *)(iVar10 + 0x28);
                                pcVar12 = *(code **)(iVar11 + 0x180);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663ae;
                                (*pcVar12)(piVar33, uVar22, 0, &var_e8h);
                                puVar28 = puVar28 + 4;
                            } while (puVar28 != puVar1);
                        }
                        *(undefined4 *)(iVar10 + 4) = 0;
                    } else if ((iVar19 == 4) && (0 < *(int32_t *)(iVar10 + 0x50))) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663d7;
                        func_0x000180166d10(iVar10);
                    }
                }
                piVar31 = piVar31 + 1;
            } while (piVar31 != piVar14);
            piVar33 = *(int64_t **)((int64_t)&arg_40h + iVar20);
            in_RCX = *(int64_t *)((int64_t)&arg_48h + iVar20);
            ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
        }
    }
    if (ppiVar27[3] == (int64_t *)0x0) {
code_r0x000180166413:
        piVar14 = *ppiVar27;
        iVar19 = *(int32_t *)(in_RCX + 0xc) + 5000;
        var_d8h = 0;
        *(int32_t *)(ppiVar27 + 0xe) = iVar19;
        var_e8h._4_4_ = 2;
        var_e0h = 1;
        var_dch = 0x10000;
        var_e8h._0_4_ = iVar19 * 0x14;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016646b;
        iVar19 = (*pcVar12)(piVar14, &var_e8h, 0, ppiVar27 + 3);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)(ppiVar27 + 0xe) < *(int32_t *)(in_RCX + 0xc)) {
        pcVar12 = *(code **)(*ppiVar27[3] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016640b;
        (*pcVar12)();
        ppiVar27[3] = (int64_t *)0x0;
        goto code_r0x000180166413;
    }
    if (ppiVar27[4] == (int64_t *)0x0) {
code_r0x000180166493:
        piVar14 = *ppiVar27;
        var_c0h._0_4_ = *(int32_t *)(in_RCX + 8) + 10000;
        var_b0h = 0;
        *(int32_t *)((int64_t)ppiVar27 + 0x74) = (int32_t)var_c0h;
        var_c0h._0_4_ = (int32_t)var_c0h * 2;
        stack0xffffffffffffff44 = 0x200000002;
        var_b4h = 0x10000;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801664e7;
        iVar19 = (*pcVar12)(piVar14, &var_c0h, 0, ppiVar27 + 4);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)((int64_t)ppiVar27 + 0x74) < *(int32_t *)(in_RCX + 8)) {
        pcVar12 = *(code **)(*ppiVar27[4] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016648b;
        (*pcVar12)();
        ppiVar27[4] = (int64_t *)0x0;
        goto code_r0x000180166493;
    }
    iVar10 = *piVar33;
    piVar14 = ppiVar27[3];
    *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c40h;
    *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
    pcVar12 = *(code **)(iVar10 + 0x70);
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166516;
    iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
    if (iVar19 == 0) {
        iVar10 = *piVar33;
        piVar14 = ppiVar27[4];
        *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c30h;
        *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
        pcVar12 = *(code **)(iVar10 + 0x70);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166545;
        iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
        if (iVar19 == 0) {
            piVar31 = *(int64_t **)(in_RCX + 0x18);
            iVar19 = *(int32_t *)(in_RCX + 0x10);
            auVar15._4_4_ = unaff_XMM6_Db;
            auVar15._0_4_ = unaff_XMM6_Da;
            auVar15._8_4_ = unaff_XMM6_Dc;
            auVar15._12_4_ = unaff_XMM6_Dd;
            *(undefined (*) [16])(&stack0x00001c80 + iVar20) = auVar15;
            auVar16._4_4_ = unaff_XMM7_Db;
            auVar16._0_4_ = unaff_XMM7_Da;
            auVar16._8_4_ = unaff_XMM7_Dc;
            auVar16._12_4_ = unaff_XMM7_Dd;
            *(undefined (*) [16])(&stack0x00001c70 + iVar20) = auVar16;
            piVar14 = piVar31 + iVar19;
            auVar17._4_4_ = unaff_XMM8_Db;
            auVar17._0_4_ = unaff_XMM8_Da;
            auVar17._8_4_ = unaff_XMM8_Dc;
            auVar17._12_4_ = unaff_XMM8_Dd;
            *(undefined (*) [16])(&stack0x00001c60 + iVar20) = auVar17;
            auVar18._4_4_ = unaff_XMM9_Db;
            auVar18._0_4_ = unaff_XMM9_Da;
            auVar18._8_4_ = unaff_XMM9_Dc;
            auVar18._12_4_ = unaff_XMM9_Dd;
            *(undefined (*) [16])(&stack0x00001c50 + iVar20) = auVar18;
            if (piVar31 != piVar14) {
                do {
                    iVar10 = *piVar31;
                    iVar19 = *(int32_t *)(iVar10 + 0x20);
                    uVar22 = *(undefined8 *)(iVar10 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665ab;
                    fcn.180498030(var_1c40h, uVar22, (int64_t)iVar19 * 0x14);
                    iVar19 = *(int32_t *)(iVar10 + 0x10);
                    uVar22 = *(undefined8 *)(iVar10 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665be;
                    fcn.180498030(var_1c30h, uVar22, (int64_t)iVar19 * 2);
                    piVar31 = piVar31 + 1;
                    var_1c40h = var_1c40h + (int64_t)*(int32_t *)(iVar10 + 0x20) * 0x14;
                    var_1c30h = var_1c30h + (int64_t)*(int32_t *)(iVar10 + 0x10) * 2;
                } while (piVar31 != piVar14);
                ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
            }
            piVar14 = ppiVar27[3];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665f0;
            (*pcVar12)(piVar33, piVar14, 0);
            piVar14 = ppiVar27[4];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166600;
            (*pcVar12)(piVar33, piVar14, 0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166611;
            func_0x0001804986e0(&var_1c10h, 0, 0x1b20);
            var_1c14h = 0x10;
            var_1c18h = 0x10;
            pcVar12 = *(code **)(*piVar33 + 0x300);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166633;
            (*pcVar12)(piVar33, &var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016664a;
            (*pcVar12)(piVar33, &var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016665d;
            (*pcVar12)(piVar33, &var_1990h);
            pcVar12 = *(code **)(*piVar33 + 0x2d8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016667e;
            (*pcVar12)(piVar33, &var_1988h, &var_1980h, &var_1970h);
            pcVar12 = *(code **)(*piVar33 + 0x2e0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166698;
            (*pcVar12)(piVar33, &var_1968h, (int64_t)&var_1970h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x248);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666b3;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            pcVar12 = *(code **)(*piVar33 + 600);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666ce;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            var_1930h._0_4_ = 0x100;
            var_1938h._4_4_ = 0x100;
            var_1938h._0_4_ = 0x100;
            pcVar12 = *(code **)(*piVar33 + 0x250);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016670d;
            (*pcVar12)(piVar33, &var_1950h, &var_1928h, &var_1938h);
            pcVar12 = *(code **)(*piVar33 + 0x260);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016672e;
            (*pcVar12)(piVar33, &var_1948h, &var_1128h, (int64_t)&var_1938h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x240);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166749;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            pcVar12 = *(code **)(*piVar33 + 0x290);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016676a;
            (*pcVar12)(piVar33, &var_1940h, &var_928h, &var_1930h);
            pcVar12 = *(code **)(*piVar33 + 0x298);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016677d;
            (*pcVar12)(piVar33, &var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x280);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016679e;
            (*pcVar12)(piVar33, &var_120h, &var_fch, &var_108h);
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x278);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667d1;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            pcVar12 = *(code **)(*piVar33 + 0x270);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667e4;
            (*pcVar12)(piVar33, (int64_t)&var_fch + 4);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667ef;
            fcn.180165e00(in_RCX, (int64_t)piVar33);
            *(int64_t **)((int64_t)&arg_50h + iVar20) = *ppiVar27;
            iVar34 = 0;
            iVar19 = 0;
            *(int64_t **)((int64_t)&arg_58h + iVar20) = ppiVar27[1];
            *(int64_t **)((int64_t)&arg_60h + iVar20) = ppiVar27[9];
            *(int64_t **)((int64_t)&arg_68h + iVar20) = ppiVar27[10];
            *(int64_t *)((int64_t)&arg_38h + iVar20) = *(int64_t *)0x180781f28;
            *(int64_t *)(*(int64_t *)0x180781f28 + 0xc90) = (int64_t)&arg_50h + iVar20;
            ppiVar24 = *(int32_t ***)(in_RCX + 0x18);
            fVar3 = *(float *)(in_RCX + 0x20);
            fVar4 = *(float *)(in_RCX + 0x24);
            fVar5 = *(float *)(in_RCX + 0x30);
            fVar6 = *(float *)(in_RCX + 0x34);
            ppiVar23 = ppiVar24 + *(int32_t *)(in_RCX + 0x10);
            *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
            *(int32_t ***)((int64_t)&arg_40h + iVar20) = ppiVar23;
            if (ppiVar24 != ppiVar23) {
                do {
                    piVar9 = *ppiVar24;
                    iVar30 = 0;
                    if (0 < *piVar9) {
                        do {
                            pfVar2 = (float *)(*(int64_t *)(piVar9 + 2) + (int64_t)iVar30 * 0x48);
                            pcVar12 = *(code **)(*(int64_t *)(piVar9 + 2) + 0x30 + (int64_t)iVar30 * 0x48);
                            if (pcVar12 == (code *)0x0) {
                                fVar36 = (*pfVar2 - fVar3) * fVar5;
                                fVar37 = (pfVar2[2] - fVar3) * fVar5;
                                if (fVar36 < fVar37) {
                                    fVar38 = (pfVar2[1] - fVar4) * fVar6;
                                    fVar39 = (pfVar2[3] - fVar4) * fVar6;
                                    if (fVar38 < fVar39) {
                                        var_d0h = CONCAT44((int32_t)fVar38, (int32_t)fVar36);
                                        var_c8h = (int32_t)fVar37;
                                        var_c4h = (int32_t)fVar39;
                                        pcVar12 = *(code **)(*piVar33 + 0x168);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166945;
                                        (*pcVar12)(piVar33, 1, &var_d0h);
                                        if (*(int64_t *)(pfVar2 + 4) == 0) {
                                            uVar22 = *(undefined8 *)(pfVar2 + 6);
                                        } else {
                                            uVar22 = *(undefined8 *)(*(int64_t *)(pfVar2 + 4) + 0x10);
                                        }
                                        *(undefined8 *)((int64_t)&arg_48h + iVar20) = uVar22;
                                        pcVar12 = *(code **)(*piVar33 + 0x40);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166973;
                                        (*pcVar12)(piVar33, 0, 1, (int64_t)&arg_48h + iVar20);
                                        fVar36 = pfVar2[8];
                                        fVar37 = pfVar2[9];
                                        fVar38 = pfVar2[10];
                                        pcVar12 = *(code **)(*piVar33 + 0x60);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016698e;
                                        (*pcVar12)(piVar33, fVar38, (int32_t)fVar37 + iVar34, (int32_t)fVar36 + iVar19);
                                    }
                                }
                            } else if (pcVar12 == (code *)0xfffffffffffffff8) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668aa;
                                fcn.180165e00(in_RCX, (int64_t)piVar33);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668b7;
                                (*pcVar12)(piVar9, pfVar2);
                            }
                            iVar30 = iVar30 + 1;
                        } while (iVar30 < *piVar9);
                        ppiVar24 = *(int32_t ***)((int64_t)&arg_30h + iVar20);
                        ppiVar23 = *(int32_t ***)((int64_t)&arg_40h + iVar20);
                    }
                    iVar34 = iVar34 + piVar9[4];
                    ppiVar24 = ppiVar24 + 1;
                    iVar19 = iVar19 + piVar9[8];
                    *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
                } while (ppiVar24 != ppiVar23);
            }
            *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar20) + 0xc90) = 0;
            pcVar12 = *(code **)(*piVar33 + 0x168);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669e0;
            (*pcVar12)(piVar33, var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x160);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669f6;
            (*pcVar12)(piVar33, var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x158);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a09;
            (*pcVar12)(piVar33, var_1990h);
            if (var_1990h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1990h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a3d;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x118);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a5e;
            (*pcVar12)(piVar33, var_1988h, &var_1980h, (undefined4)var_1970h);
            if (var_1988h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1988h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a70;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x120);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a8a;
            (*pcVar12)(piVar33, var_1968h, var_1970h._4_4_);
            if (var_1968h != (int64_t *)0x0) {
                pcVar12 = *(code **)(*var_1968h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a9c;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ab4;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            if (var_1960h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1960h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ac6;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x50);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ade;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            if (var_1958h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1958h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166af0;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x48);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b0e;
            (*pcVar12)(piVar33, var_1950h, &var_1928h, (uint32_t)var_1938h);
            if (var_1950h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1950h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b20;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = (uint32_t)var_1938h;
            if ((uint32_t)var_1938h != 0) {
                do {
                    if ((int64_t *)(&var_1928h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1928h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b43;
                        (*pcVar12)();
                        uVar25 = (uint32_t)var_1938h;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0x58);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b6d;
            (*pcVar12)(piVar33, var_1948h, &var_1128h, var_1938h._4_4_);
            if (var_1948h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1948h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b7f;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b97;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            if (var_110h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_110h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ba9;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0xb8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bca;
            (*pcVar12)(piVar33, var_1940h, &var_928h, (undefined4)var_1930h);
            if (var_1940h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1940h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bdc;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = var_1938h._4_4_;
            if (var_1938h._4_4_ != 0) {
                do {
                    if ((int64_t *)(&var_1128h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1128h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c03;
                        (*pcVar12)();
                        uVar25 = var_1938h._4_4_;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0xc0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c21;
            (*pcVar12)(piVar33, (undefined4)var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x98);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c42;
            (*pcVar12)(piVar33, var_120h, (undefined4)var_fch, (undefined4)var_108h);
            if (var_120h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_120h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c54;
                (*pcVar12)();
            }
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x90);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c87;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            if (var_118h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_118h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c99;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x88);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cac;
            (*pcVar12)(piVar33, stack0xffffffffffffff08);
            if (stack0xffffffffffffff08 != (int64_t *)0x0) {
                pcVar12 = *(code **)(*stack0xffffffffffffff08 + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cbe;
                (*pcVar12)();
            }
        }
    }
code_r0x000180166cee:
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cfd;
    func_0x000180459870(var_78h ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20));
    return;
}

// ============================================================
// Function: FUN_180166a37
// Address: 0x180166a37
// Size: 695 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c18h
// WARNING: [rz-ghidra] Detected overlap for variable var_196ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1968h
// WARNING: [rz-ghidra] Detected overlap for variable var_1934h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.1801660f0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    uint16_t *puVar1;
    float *pfVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    uint16_t uVar7;
    uint16_t uVar8;
    int32_t *piVar9;
    int64_t iVar10;
    int64_t iVar11;
    code *pcVar12;
    undefined8 *puVar13;
    int64_t *piVar14;
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int32_t iVar19;
    int64_t iVar20;
    undefined (*pauVar21) [16];
    undefined8 uVar22;
    int32_t **ppiVar23;
    int64_t in_RCX;
    int32_t **ppiVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    undefined8 unaff_RBX;
    int64_t **ppiVar27;
    uint16_t *puVar28;
    uint64_t uVar29;
    int32_t iVar30;
    undefined8 unaff_RSI;
    int64_t *piVar31;
    undefined8 unaff_RDI;
    undefined (*pauVar32) [16];
    int64_t *piVar33;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int32_t iVar34;
    undefined8 unaff_R15;
    undefined (*pauVar35) [16];
    float fVar36;
    float fVar37;
    float fVar38;
    float fVar39;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_1c48h;
    int64_t var_1c40h;
    int64_t var_1c30h;
    undefined4 var_1c18h;
    undefined4 var_1c14h;
    int64_t var_1c10h;
    int64_t var_1b10h;
    int64_t var_1990h;
    int64_t var_1988h;
    int64_t var_1980h;
    int64_t var_1970h;
    int64_t *var_1968h;
    int64_t var_1960h;
    int64_t var_1958h;
    int64_t var_1950h;
    int64_t var_1948h;
    int64_t var_1940h;
    int64_t var_1938h;
    int64_t var_1930h;
    int64_t var_1928h;
    int64_t var_1128h;
    int64_t var_928h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    undefined var_100h [4];
    int64_t var_fch;
    int64_t var_e8h;
    undefined4 var_e0h;
    int32_t var_dch;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t var_c8h;
    int32_t var_c4h;
    int64_t var_c0h;
    undefined4 var_b4h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 var_a0h;
    undefined4 var_9ch;
    undefined4 var_98h;
    int64_t var_94h;
    int64_t var_8ch;
    int64_t var_84h;
    int64_t var_78h;
    undefined8 uStack_18;
    
    uStack_18 = 0x180166106;
    iVar20 = func_0x00018045a350();
    iVar20 = -iVar20;
    var_78h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20);
    *(int64_t *)((int64_t)&arg_48h + iVar20) = in_RCX;
    if ((*(float *)(in_RCX + 0x28) <= 0.0) || (*(float *)(in_RCX + 0x2c) <= 0.0)) goto code_r0x000180166cee;
    *(undefined8 *)(&stack0x00001cc8 + iVar20) = unaff_RBX;
    *(undefined8 *)(&stack0x00001cd0 + iVar20) = unaff_RSI;
    *(undefined8 *)(&stack0x00001cd8 + iVar20) = unaff_RDI;
    *(undefined8 *)(&stack0x00001c90 + iVar20) = unaff_R15;
    if (*(int64_t *)0x180781f28 == 0) {
        ppiVar27 = (int64_t **)0x0;
    } else {
        ppiVar27 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    piVar9 = *(int32_t **)(in_RCX + 0x40);
    piVar33 = ppiVar27[1];
    *(undefined8 *)(&stack0x00001ca0 + iVar20) = unaff_R12;
    *(int64_t ***)((int64_t)&arg_30h + iVar20) = ppiVar27;
    *(undefined8 *)(&stack0x00001c98 + iVar20) = unaff_R14;
    *(int64_t **)((int64_t)&arg_40h + iVar20) = piVar33;
    if (piVar9 != (int32_t *)0x0) {
        piVar31 = *(int64_t **)(piVar9 + 2);
        piVar14 = piVar31 + *piVar9;
        if (piVar31 != piVar14) {
            do {
                iVar10 = *piVar31;
                iVar19 = *(int32_t *)(iVar10 + 4);
                if (iVar19 != 0) {
                    pauVar32 = (undefined (*) [16])0x0;
                    pauVar35 = pauVar32;
                    if (*(int64_t *)0x180781f28 != 0) {
                        pauVar35 = *(undefined (**) [16])(*(int64_t *)0x180781f28 + 0xd8);
                    }
                    if (iVar19 == 2) {
                        iVar11 = *(int64_t *)(iVar10 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166200;
                        pauVar21 = (undefined (*) [16])func_0x00018046d050(0x10);
                        if (pauVar21 != (undefined (*) [16])0x0) {
                            *pauVar21 = ZEXT816(0);
                            pauVar32 = pauVar21;
                        }
                        var_a8h._0_4_ = *(int32_t *)(iVar10 + 0x1c);
                        var_a8h._4_4_ = *(undefined4 *)(iVar10 + 0x20);
                        var_c8h = (int32_t)var_a8h * 4;
                        var_94h = 1;
                        piVar33 = *(int64_t **)*pauVar35;
                        var_84h = 0;
                        var_a0h = 1;
                        var_9ch = 1;
                        var_98h = 0x1c;
                        var_8ch._0_4_ = 0;
                        var_8ch._4_4_ = 8;
                        var_c4h = 0;
                        pcVar12 = *(code **)(*piVar33 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016629d;
                        var_d0h = iVar11;
                        (*pcVar12)(piVar33, &var_a8h, &var_d0h, pauVar32);
                        piVar33 = *(int64_t **)*pauVar35;
                        var_b0h = 0;
                        var_c0h._0_4_ = 0x1c;
                        stack0xffffffffffffff44 = 4;
                        var_b4h = var_a0h;
                        uVar22 = *(undefined8 *)*pauVar32;
                        pcVar12 = *(code **)(*piVar33 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801662dc;
                        (*pcVar12)(piVar33, uVar22, &var_c0h, *pauVar32 + 8);
                        *(undefined8 *)(iVar10 + 0x10) = *(undefined8 *)(*pauVar32 + 8);
                        *(undefined4 *)(iVar10 + 4) = 0;
                        *(undefined (**) [16])(iVar10 + 8) = pauVar32;
                    } else if (iVar19 == 3) {
                        puVar28 = *(uint16_t **)(iVar10 + 0x48);
                        *(undefined8 *)((int64_t)&arg_38h + iVar20) = *(undefined8 *)(iVar10 + 8);
                        puVar1 = puVar28 + (int64_t)*(int32_t *)(iVar10 + 0x40) * 4;
                        if (puVar28 != puVar1) {
                            puVar13 = *(undefined8 **)((int64_t)&arg_38h + iVar20);
                            do {
                                uVar7 = *puVar28;
                                uVar8 = puVar28[1];
                                iVar19 = *(int32_t *)(iVar10 + 0x24);
                                var_e8h._0_4_ = (uint32_t)uVar7;
                                var_dch = puVar28[2] + (uint32_t)var_e8h;
                                piVar33 = *(int64_t **)(*pauVar35 + 8);
                                uVar22 = *puVar13;
                                iVar34 = *(int32_t *)(iVar10 + 0x1c);
                                var_e8h._4_4_ = (uint32_t)uVar8;
                                var_e0h = 0;
                                var_d8h = CONCAT44(1, (uint32_t)puVar28[3] + (uint32_t)uVar8);
                                iVar11 = *piVar33;
                                *(undefined4 *)((int64_t)&var_20h + iVar20) = 0;
                                iVar30 = *(int32_t *)(iVar10 + 0x24);
                                *(int32_t *)((int64_t)&var_18h + iVar20) = iVar19 * iVar34;
                                *(int64_t *)((int64_t)&var_10h + iVar20) =
                                     (int64_t)(int32_t)((iVar34 * (uint32_t)uVar8 + (uint32_t)uVar7) * iVar30) +
                                     *(int64_t *)(iVar10 + 0x28);
                                pcVar12 = *(code **)(iVar11 + 0x180);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663ae;
                                (*pcVar12)(piVar33, uVar22, 0, &var_e8h);
                                puVar28 = puVar28 + 4;
                            } while (puVar28 != puVar1);
                        }
                        *(undefined4 *)(iVar10 + 4) = 0;
                    } else if ((iVar19 == 4) && (0 < *(int32_t *)(iVar10 + 0x50))) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663d7;
                        func_0x000180166d10(iVar10);
                    }
                }
                piVar31 = piVar31 + 1;
            } while (piVar31 != piVar14);
            piVar33 = *(int64_t **)((int64_t)&arg_40h + iVar20);
            in_RCX = *(int64_t *)((int64_t)&arg_48h + iVar20);
            ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
        }
    }
    if (ppiVar27[3] == (int64_t *)0x0) {
code_r0x000180166413:
        piVar14 = *ppiVar27;
        iVar19 = *(int32_t *)(in_RCX + 0xc) + 5000;
        var_d8h = 0;
        *(int32_t *)(ppiVar27 + 0xe) = iVar19;
        var_e8h._4_4_ = 2;
        var_e0h = 1;
        var_dch = 0x10000;
        var_e8h._0_4_ = iVar19 * 0x14;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016646b;
        iVar19 = (*pcVar12)(piVar14, &var_e8h, 0, ppiVar27 + 3);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)(ppiVar27 + 0xe) < *(int32_t *)(in_RCX + 0xc)) {
        pcVar12 = *(code **)(*ppiVar27[3] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016640b;
        (*pcVar12)();
        ppiVar27[3] = (int64_t *)0x0;
        goto code_r0x000180166413;
    }
    if (ppiVar27[4] == (int64_t *)0x0) {
code_r0x000180166493:
        piVar14 = *ppiVar27;
        var_c0h._0_4_ = *(int32_t *)(in_RCX + 8) + 10000;
        var_b0h = 0;
        *(int32_t *)((int64_t)ppiVar27 + 0x74) = (int32_t)var_c0h;
        var_c0h._0_4_ = (int32_t)var_c0h * 2;
        stack0xffffffffffffff44 = 0x200000002;
        var_b4h = 0x10000;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801664e7;
        iVar19 = (*pcVar12)(piVar14, &var_c0h, 0, ppiVar27 + 4);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)((int64_t)ppiVar27 + 0x74) < *(int32_t *)(in_RCX + 8)) {
        pcVar12 = *(code **)(*ppiVar27[4] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016648b;
        (*pcVar12)();
        ppiVar27[4] = (int64_t *)0x0;
        goto code_r0x000180166493;
    }
    iVar10 = *piVar33;
    piVar14 = ppiVar27[3];
    *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c40h;
    *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
    pcVar12 = *(code **)(iVar10 + 0x70);
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166516;
    iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
    if (iVar19 == 0) {
        iVar10 = *piVar33;
        piVar14 = ppiVar27[4];
        *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c30h;
        *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
        pcVar12 = *(code **)(iVar10 + 0x70);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166545;
        iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
        if (iVar19 == 0) {
            piVar31 = *(int64_t **)(in_RCX + 0x18);
            iVar19 = *(int32_t *)(in_RCX + 0x10);
            auVar15._4_4_ = unaff_XMM6_Db;
            auVar15._0_4_ = unaff_XMM6_Da;
            auVar15._8_4_ = unaff_XMM6_Dc;
            auVar15._12_4_ = unaff_XMM6_Dd;
            *(undefined (*) [16])(&stack0x00001c80 + iVar20) = auVar15;
            auVar16._4_4_ = unaff_XMM7_Db;
            auVar16._0_4_ = unaff_XMM7_Da;
            auVar16._8_4_ = unaff_XMM7_Dc;
            auVar16._12_4_ = unaff_XMM7_Dd;
            *(undefined (*) [16])(&stack0x00001c70 + iVar20) = auVar16;
            piVar14 = piVar31 + iVar19;
            auVar17._4_4_ = unaff_XMM8_Db;
            auVar17._0_4_ = unaff_XMM8_Da;
            auVar17._8_4_ = unaff_XMM8_Dc;
            auVar17._12_4_ = unaff_XMM8_Dd;
            *(undefined (*) [16])(&stack0x00001c60 + iVar20) = auVar17;
            auVar18._4_4_ = unaff_XMM9_Db;
            auVar18._0_4_ = unaff_XMM9_Da;
            auVar18._8_4_ = unaff_XMM9_Dc;
            auVar18._12_4_ = unaff_XMM9_Dd;
            *(undefined (*) [16])(&stack0x00001c50 + iVar20) = auVar18;
            if (piVar31 != piVar14) {
                do {
                    iVar10 = *piVar31;
                    iVar19 = *(int32_t *)(iVar10 + 0x20);
                    uVar22 = *(undefined8 *)(iVar10 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665ab;
                    fcn.180498030(var_1c40h, uVar22, (int64_t)iVar19 * 0x14);
                    iVar19 = *(int32_t *)(iVar10 + 0x10);
                    uVar22 = *(undefined8 *)(iVar10 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665be;
                    fcn.180498030(var_1c30h, uVar22, (int64_t)iVar19 * 2);
                    piVar31 = piVar31 + 1;
                    var_1c40h = var_1c40h + (int64_t)*(int32_t *)(iVar10 + 0x20) * 0x14;
                    var_1c30h = var_1c30h + (int64_t)*(int32_t *)(iVar10 + 0x10) * 2;
                } while (piVar31 != piVar14);
                ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
            }
            piVar14 = ppiVar27[3];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665f0;
            (*pcVar12)(piVar33, piVar14, 0);
            piVar14 = ppiVar27[4];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166600;
            (*pcVar12)(piVar33, piVar14, 0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166611;
            func_0x0001804986e0(&var_1c10h, 0, 0x1b20);
            var_1c14h = 0x10;
            var_1c18h = 0x10;
            pcVar12 = *(code **)(*piVar33 + 0x300);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166633;
            (*pcVar12)(piVar33, &var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016664a;
            (*pcVar12)(piVar33, &var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016665d;
            (*pcVar12)(piVar33, &var_1990h);
            pcVar12 = *(code **)(*piVar33 + 0x2d8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016667e;
            (*pcVar12)(piVar33, &var_1988h, &var_1980h, &var_1970h);
            pcVar12 = *(code **)(*piVar33 + 0x2e0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166698;
            (*pcVar12)(piVar33, &var_1968h, (int64_t)&var_1970h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x248);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666b3;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            pcVar12 = *(code **)(*piVar33 + 600);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666ce;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            var_1930h._0_4_ = 0x100;
            var_1938h._4_4_ = 0x100;
            var_1938h._0_4_ = 0x100;
            pcVar12 = *(code **)(*piVar33 + 0x250);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016670d;
            (*pcVar12)(piVar33, &var_1950h, &var_1928h, &var_1938h);
            pcVar12 = *(code **)(*piVar33 + 0x260);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016672e;
            (*pcVar12)(piVar33, &var_1948h, &var_1128h, (int64_t)&var_1938h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x240);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166749;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            pcVar12 = *(code **)(*piVar33 + 0x290);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016676a;
            (*pcVar12)(piVar33, &var_1940h, &var_928h, &var_1930h);
            pcVar12 = *(code **)(*piVar33 + 0x298);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016677d;
            (*pcVar12)(piVar33, &var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x280);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016679e;
            (*pcVar12)(piVar33, &var_120h, &var_fch, &var_108h);
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x278);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667d1;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            pcVar12 = *(code **)(*piVar33 + 0x270);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667e4;
            (*pcVar12)(piVar33, (int64_t)&var_fch + 4);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667ef;
            fcn.180165e00(in_RCX, (int64_t)piVar33);
            *(int64_t **)((int64_t)&arg_50h + iVar20) = *ppiVar27;
            iVar34 = 0;
            iVar19 = 0;
            *(int64_t **)((int64_t)&arg_58h + iVar20) = ppiVar27[1];
            *(int64_t **)((int64_t)&arg_60h + iVar20) = ppiVar27[9];
            *(int64_t **)((int64_t)&arg_68h + iVar20) = ppiVar27[10];
            *(int64_t *)((int64_t)&arg_38h + iVar20) = *(int64_t *)0x180781f28;
            *(int64_t *)(*(int64_t *)0x180781f28 + 0xc90) = (int64_t)&arg_50h + iVar20;
            ppiVar24 = *(int32_t ***)(in_RCX + 0x18);
            fVar3 = *(float *)(in_RCX + 0x20);
            fVar4 = *(float *)(in_RCX + 0x24);
            fVar5 = *(float *)(in_RCX + 0x30);
            fVar6 = *(float *)(in_RCX + 0x34);
            ppiVar23 = ppiVar24 + *(int32_t *)(in_RCX + 0x10);
            *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
            *(int32_t ***)((int64_t)&arg_40h + iVar20) = ppiVar23;
            if (ppiVar24 != ppiVar23) {
                do {
                    piVar9 = *ppiVar24;
                    iVar30 = 0;
                    if (0 < *piVar9) {
                        do {
                            pfVar2 = (float *)(*(int64_t *)(piVar9 + 2) + (int64_t)iVar30 * 0x48);
                            pcVar12 = *(code **)(*(int64_t *)(piVar9 + 2) + 0x30 + (int64_t)iVar30 * 0x48);
                            if (pcVar12 == (code *)0x0) {
                                fVar36 = (*pfVar2 - fVar3) * fVar5;
                                fVar37 = (pfVar2[2] - fVar3) * fVar5;
                                if (fVar36 < fVar37) {
                                    fVar38 = (pfVar2[1] - fVar4) * fVar6;
                                    fVar39 = (pfVar2[3] - fVar4) * fVar6;
                                    if (fVar38 < fVar39) {
                                        var_d0h = CONCAT44((int32_t)fVar38, (int32_t)fVar36);
                                        var_c8h = (int32_t)fVar37;
                                        var_c4h = (int32_t)fVar39;
                                        pcVar12 = *(code **)(*piVar33 + 0x168);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166945;
                                        (*pcVar12)(piVar33, 1, &var_d0h);
                                        if (*(int64_t *)(pfVar2 + 4) == 0) {
                                            uVar22 = *(undefined8 *)(pfVar2 + 6);
                                        } else {
                                            uVar22 = *(undefined8 *)(*(int64_t *)(pfVar2 + 4) + 0x10);
                                        }
                                        *(undefined8 *)((int64_t)&arg_48h + iVar20) = uVar22;
                                        pcVar12 = *(code **)(*piVar33 + 0x40);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166973;
                                        (*pcVar12)(piVar33, 0, 1, (int64_t)&arg_48h + iVar20);
                                        fVar36 = pfVar2[8];
                                        fVar37 = pfVar2[9];
                                        fVar38 = pfVar2[10];
                                        pcVar12 = *(code **)(*piVar33 + 0x60);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016698e;
                                        (*pcVar12)(piVar33, fVar38, (int32_t)fVar37 + iVar34, (int32_t)fVar36 + iVar19);
                                    }
                                }
                            } else if (pcVar12 == (code *)0xfffffffffffffff8) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668aa;
                                fcn.180165e00(in_RCX, (int64_t)piVar33);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668b7;
                                (*pcVar12)(piVar9, pfVar2);
                            }
                            iVar30 = iVar30 + 1;
                        } while (iVar30 < *piVar9);
                        ppiVar24 = *(int32_t ***)((int64_t)&arg_30h + iVar20);
                        ppiVar23 = *(int32_t ***)((int64_t)&arg_40h + iVar20);
                    }
                    iVar34 = iVar34 + piVar9[4];
                    ppiVar24 = ppiVar24 + 1;
                    iVar19 = iVar19 + piVar9[8];
                    *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
                } while (ppiVar24 != ppiVar23);
            }
            *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar20) + 0xc90) = 0;
            pcVar12 = *(code **)(*piVar33 + 0x168);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669e0;
            (*pcVar12)(piVar33, var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x160);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669f6;
            (*pcVar12)(piVar33, var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x158);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a09;
            (*pcVar12)(piVar33, var_1990h);
            if (var_1990h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1990h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a3d;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x118);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a5e;
            (*pcVar12)(piVar33, var_1988h, &var_1980h, (undefined4)var_1970h);
            if (var_1988h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1988h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a70;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x120);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a8a;
            (*pcVar12)(piVar33, var_1968h, var_1970h._4_4_);
            if (var_1968h != (int64_t *)0x0) {
                pcVar12 = *(code **)(*var_1968h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a9c;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ab4;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            if (var_1960h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1960h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ac6;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x50);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ade;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            if (var_1958h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1958h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166af0;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x48);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b0e;
            (*pcVar12)(piVar33, var_1950h, &var_1928h, (uint32_t)var_1938h);
            if (var_1950h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1950h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b20;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = (uint32_t)var_1938h;
            if ((uint32_t)var_1938h != 0) {
                do {
                    if ((int64_t *)(&var_1928h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1928h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b43;
                        (*pcVar12)();
                        uVar25 = (uint32_t)var_1938h;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0x58);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b6d;
            (*pcVar12)(piVar33, var_1948h, &var_1128h, var_1938h._4_4_);
            if (var_1948h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1948h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b7f;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b97;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            if (var_110h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_110h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ba9;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0xb8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bca;
            (*pcVar12)(piVar33, var_1940h, &var_928h, (undefined4)var_1930h);
            if (var_1940h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1940h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bdc;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = var_1938h._4_4_;
            if (var_1938h._4_4_ != 0) {
                do {
                    if ((int64_t *)(&var_1128h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1128h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c03;
                        (*pcVar12)();
                        uVar25 = var_1938h._4_4_;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0xc0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c21;
            (*pcVar12)(piVar33, (undefined4)var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x98);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c42;
            (*pcVar12)(piVar33, var_120h, (undefined4)var_fch, (undefined4)var_108h);
            if (var_120h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_120h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c54;
                (*pcVar12)();
            }
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x90);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c87;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            if (var_118h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_118h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c99;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x88);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cac;
            (*pcVar12)(piVar33, stack0xffffffffffffff08);
            if (stack0xffffffffffffff08 != (int64_t *)0x0) {
                pcVar12 = *(code **)(*stack0xffffffffffffff08 + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cbe;
                (*pcVar12)();
            }
        }
    }
code_r0x000180166cee:
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cfd;
    func_0x000180459870(var_78h ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20));
    return;
}

// ============================================================
// Function: FUN_180166cee
// Address: 0x180166cee
// Size: 26 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c18h
// WARNING: [rz-ghidra] Detected overlap for variable var_196ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1968h
// WARNING: [rz-ghidra] Detected overlap for variable var_1934h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.1801660f0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    uint16_t *puVar1;
    float *pfVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    uint16_t uVar7;
    uint16_t uVar8;
    int32_t *piVar9;
    int64_t iVar10;
    int64_t iVar11;
    code *pcVar12;
    undefined8 *puVar13;
    int64_t *piVar14;
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int32_t iVar19;
    int64_t iVar20;
    undefined (*pauVar21) [16];
    undefined8 uVar22;
    int32_t **ppiVar23;
    int64_t in_RCX;
    int32_t **ppiVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    undefined8 unaff_RBX;
    int64_t **ppiVar27;
    uint16_t *puVar28;
    uint64_t uVar29;
    int32_t iVar30;
    undefined8 unaff_RSI;
    int64_t *piVar31;
    undefined8 unaff_RDI;
    undefined (*pauVar32) [16];
    int64_t *piVar33;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int32_t iVar34;
    undefined8 unaff_R15;
    undefined (*pauVar35) [16];
    float fVar36;
    float fVar37;
    float fVar38;
    float fVar39;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_1c48h;
    int64_t var_1c40h;
    int64_t var_1c30h;
    undefined4 var_1c18h;
    undefined4 var_1c14h;
    int64_t var_1c10h;
    int64_t var_1b10h;
    int64_t var_1990h;
    int64_t var_1988h;
    int64_t var_1980h;
    int64_t var_1970h;
    int64_t *var_1968h;
    int64_t var_1960h;
    int64_t var_1958h;
    int64_t var_1950h;
    int64_t var_1948h;
    int64_t var_1940h;
    int64_t var_1938h;
    int64_t var_1930h;
    int64_t var_1928h;
    int64_t var_1128h;
    int64_t var_928h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    undefined var_100h [4];
    int64_t var_fch;
    int64_t var_e8h;
    undefined4 var_e0h;
    int32_t var_dch;
    int64_t var_d8h;
    int64_t var_d0h;
    int32_t var_c8h;
    int32_t var_c4h;
    int64_t var_c0h;
    undefined4 var_b4h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 var_a0h;
    undefined4 var_9ch;
    undefined4 var_98h;
    int64_t var_94h;
    int64_t var_8ch;
    int64_t var_84h;
    int64_t var_78h;
    undefined8 uStack_18;
    
    uStack_18 = 0x180166106;
    iVar20 = func_0x00018045a350();
    iVar20 = -iVar20;
    var_78h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20);
    *(int64_t *)((int64_t)&arg_48h + iVar20) = in_RCX;
    if ((*(float *)(in_RCX + 0x28) <= 0.0) || (*(float *)(in_RCX + 0x2c) <= 0.0)) goto code_r0x000180166cee;
    *(undefined8 *)(&stack0x00001cc8 + iVar20) = unaff_RBX;
    *(undefined8 *)(&stack0x00001cd0 + iVar20) = unaff_RSI;
    *(undefined8 *)(&stack0x00001cd8 + iVar20) = unaff_RDI;
    *(undefined8 *)(&stack0x00001c90 + iVar20) = unaff_R15;
    if (*(int64_t *)0x180781f28 == 0) {
        ppiVar27 = (int64_t **)0x0;
    } else {
        ppiVar27 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    piVar9 = *(int32_t **)(in_RCX + 0x40);
    piVar33 = ppiVar27[1];
    *(undefined8 *)(&stack0x00001ca0 + iVar20) = unaff_R12;
    *(int64_t ***)((int64_t)&arg_30h + iVar20) = ppiVar27;
    *(undefined8 *)(&stack0x00001c98 + iVar20) = unaff_R14;
    *(int64_t **)((int64_t)&arg_40h + iVar20) = piVar33;
    if (piVar9 != (int32_t *)0x0) {
        piVar31 = *(int64_t **)(piVar9 + 2);
        piVar14 = piVar31 + *piVar9;
        if (piVar31 != piVar14) {
            do {
                iVar10 = *piVar31;
                iVar19 = *(int32_t *)(iVar10 + 4);
                if (iVar19 != 0) {
                    pauVar32 = (undefined (*) [16])0x0;
                    pauVar35 = pauVar32;
                    if (*(int64_t *)0x180781f28 != 0) {
                        pauVar35 = *(undefined (**) [16])(*(int64_t *)0x180781f28 + 0xd8);
                    }
                    if (iVar19 == 2) {
                        iVar11 = *(int64_t *)(iVar10 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166200;
                        pauVar21 = (undefined (*) [16])func_0x00018046d050(0x10);
                        if (pauVar21 != (undefined (*) [16])0x0) {
                            *pauVar21 = ZEXT816(0);
                            pauVar32 = pauVar21;
                        }
                        var_a8h._0_4_ = *(int32_t *)(iVar10 + 0x1c);
                        var_a8h._4_4_ = *(undefined4 *)(iVar10 + 0x20);
                        var_c8h = (int32_t)var_a8h * 4;
                        var_94h = 1;
                        piVar33 = *(int64_t **)*pauVar35;
                        var_84h = 0;
                        var_a0h = 1;
                        var_9ch = 1;
                        var_98h = 0x1c;
                        var_8ch._0_4_ = 0;
                        var_8ch._4_4_ = 8;
                        var_c4h = 0;
                        pcVar12 = *(code **)(*piVar33 + 0x28);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016629d;
                        var_d0h = iVar11;
                        (*pcVar12)(piVar33, &var_a8h, &var_d0h, pauVar32);
                        piVar33 = *(int64_t **)*pauVar35;
                        var_b0h = 0;
                        var_c0h._0_4_ = 0x1c;
                        stack0xffffffffffffff44 = 4;
                        var_b4h = var_a0h;
                        uVar22 = *(undefined8 *)*pauVar32;
                        pcVar12 = *(code **)(*piVar33 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801662dc;
                        (*pcVar12)(piVar33, uVar22, &var_c0h, *pauVar32 + 8);
                        *(undefined8 *)(iVar10 + 0x10) = *(undefined8 *)(*pauVar32 + 8);
                        *(undefined4 *)(iVar10 + 4) = 0;
                        *(undefined (**) [16])(iVar10 + 8) = pauVar32;
                    } else if (iVar19 == 3) {
                        puVar28 = *(uint16_t **)(iVar10 + 0x48);
                        *(undefined8 *)((int64_t)&arg_38h + iVar20) = *(undefined8 *)(iVar10 + 8);
                        puVar1 = puVar28 + (int64_t)*(int32_t *)(iVar10 + 0x40) * 4;
                        if (puVar28 != puVar1) {
                            puVar13 = *(undefined8 **)((int64_t)&arg_38h + iVar20);
                            do {
                                uVar7 = *puVar28;
                                uVar8 = puVar28[1];
                                iVar19 = *(int32_t *)(iVar10 + 0x24);
                                var_e8h._0_4_ = (uint32_t)uVar7;
                                var_dch = puVar28[2] + (uint32_t)var_e8h;
                                piVar33 = *(int64_t **)(*pauVar35 + 8);
                                uVar22 = *puVar13;
                                iVar34 = *(int32_t *)(iVar10 + 0x1c);
                                var_e8h._4_4_ = (uint32_t)uVar8;
                                var_e0h = 0;
                                var_d8h = CONCAT44(1, (uint32_t)puVar28[3] + (uint32_t)uVar8);
                                iVar11 = *piVar33;
                                *(undefined4 *)((int64_t)&var_20h + iVar20) = 0;
                                iVar30 = *(int32_t *)(iVar10 + 0x24);
                                *(int32_t *)((int64_t)&var_18h + iVar20) = iVar19 * iVar34;
                                *(int64_t *)((int64_t)&var_10h + iVar20) =
                                     (int64_t)(int32_t)((iVar34 * (uint32_t)uVar8 + (uint32_t)uVar7) * iVar30) +
                                     *(int64_t *)(iVar10 + 0x28);
                                pcVar12 = *(code **)(iVar11 + 0x180);
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663ae;
                                (*pcVar12)(piVar33, uVar22, 0, &var_e8h);
                                puVar28 = puVar28 + 4;
                            } while (puVar28 != puVar1);
                        }
                        *(undefined4 *)(iVar10 + 4) = 0;
                    } else if ((iVar19 == 4) && (0 < *(int32_t *)(iVar10 + 0x50))) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801663d7;
                        func_0x000180166d10(iVar10);
                    }
                }
                piVar31 = piVar31 + 1;
            } while (piVar31 != piVar14);
            piVar33 = *(int64_t **)((int64_t)&arg_40h + iVar20);
            in_RCX = *(int64_t *)((int64_t)&arg_48h + iVar20);
            ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
        }
    }
    if (ppiVar27[3] == (int64_t *)0x0) {
code_r0x000180166413:
        piVar14 = *ppiVar27;
        iVar19 = *(int32_t *)(in_RCX + 0xc) + 5000;
        var_d8h = 0;
        *(int32_t *)(ppiVar27 + 0xe) = iVar19;
        var_e8h._4_4_ = 2;
        var_e0h = 1;
        var_dch = 0x10000;
        var_e8h._0_4_ = iVar19 * 0x14;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016646b;
        iVar19 = (*pcVar12)(piVar14, &var_e8h, 0, ppiVar27 + 3);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)(ppiVar27 + 0xe) < *(int32_t *)(in_RCX + 0xc)) {
        pcVar12 = *(code **)(*ppiVar27[3] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016640b;
        (*pcVar12)();
        ppiVar27[3] = (int64_t *)0x0;
        goto code_r0x000180166413;
    }
    if (ppiVar27[4] == (int64_t *)0x0) {
code_r0x000180166493:
        piVar14 = *ppiVar27;
        var_c0h._0_4_ = *(int32_t *)(in_RCX + 8) + 10000;
        var_b0h = 0;
        *(int32_t *)((int64_t)ppiVar27 + 0x74) = (int32_t)var_c0h;
        var_c0h._0_4_ = (int32_t)var_c0h * 2;
        stack0xffffffffffffff44 = 0x200000002;
        var_b4h = 0x10000;
        pcVar12 = *(code **)(*piVar14 + 0x18);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801664e7;
        iVar19 = (*pcVar12)(piVar14, &var_c0h, 0, ppiVar27 + 4);
        if (iVar19 < 0) goto code_r0x000180166cee;
    } else if (*(int32_t *)((int64_t)ppiVar27 + 0x74) < *(int32_t *)(in_RCX + 8)) {
        pcVar12 = *(code **)(*ppiVar27[4] + 0x10);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016648b;
        (*pcVar12)();
        ppiVar27[4] = (int64_t *)0x0;
        goto code_r0x000180166493;
    }
    iVar10 = *piVar33;
    piVar14 = ppiVar27[3];
    *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c40h;
    *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
    pcVar12 = *(code **)(iVar10 + 0x70);
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166516;
    iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
    if (iVar19 == 0) {
        iVar10 = *piVar33;
        piVar14 = ppiVar27[4];
        *(int64_t **)((int64_t)&var_18h + iVar20) = &var_1c30h;
        *(undefined4 *)((int64_t)&var_10h + iVar20) = 0;
        pcVar12 = *(code **)(iVar10 + 0x70);
        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166545;
        iVar19 = (*pcVar12)(piVar33, piVar14, 0, 4);
        if (iVar19 == 0) {
            piVar31 = *(int64_t **)(in_RCX + 0x18);
            iVar19 = *(int32_t *)(in_RCX + 0x10);
            auVar15._4_4_ = unaff_XMM6_Db;
            auVar15._0_4_ = unaff_XMM6_Da;
            auVar15._8_4_ = unaff_XMM6_Dc;
            auVar15._12_4_ = unaff_XMM6_Dd;
            *(undefined (*) [16])(&stack0x00001c80 + iVar20) = auVar15;
            auVar16._4_4_ = unaff_XMM7_Db;
            auVar16._0_4_ = unaff_XMM7_Da;
            auVar16._8_4_ = unaff_XMM7_Dc;
            auVar16._12_4_ = unaff_XMM7_Dd;
            *(undefined (*) [16])(&stack0x00001c70 + iVar20) = auVar16;
            piVar14 = piVar31 + iVar19;
            auVar17._4_4_ = unaff_XMM8_Db;
            auVar17._0_4_ = unaff_XMM8_Da;
            auVar17._8_4_ = unaff_XMM8_Dc;
            auVar17._12_4_ = unaff_XMM8_Dd;
            *(undefined (*) [16])(&stack0x00001c60 + iVar20) = auVar17;
            auVar18._4_4_ = unaff_XMM9_Db;
            auVar18._0_4_ = unaff_XMM9_Da;
            auVar18._8_4_ = unaff_XMM9_Dc;
            auVar18._12_4_ = unaff_XMM9_Dd;
            *(undefined (*) [16])(&stack0x00001c50 + iVar20) = auVar18;
            if (piVar31 != piVar14) {
                do {
                    iVar10 = *piVar31;
                    iVar19 = *(int32_t *)(iVar10 + 0x20);
                    uVar22 = *(undefined8 *)(iVar10 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665ab;
                    fcn.180498030(var_1c40h, uVar22, (int64_t)iVar19 * 0x14);
                    iVar19 = *(int32_t *)(iVar10 + 0x10);
                    uVar22 = *(undefined8 *)(iVar10 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665be;
                    fcn.180498030(var_1c30h, uVar22, (int64_t)iVar19 * 2);
                    piVar31 = piVar31 + 1;
                    var_1c40h = var_1c40h + (int64_t)*(int32_t *)(iVar10 + 0x20) * 0x14;
                    var_1c30h = var_1c30h + (int64_t)*(int32_t *)(iVar10 + 0x10) * 2;
                } while (piVar31 != piVar14);
                ppiVar27 = *(int64_t ***)((int64_t)&arg_30h + iVar20);
            }
            piVar14 = ppiVar27[3];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801665f0;
            (*pcVar12)(piVar33, piVar14, 0);
            piVar14 = ppiVar27[4];
            pcVar12 = *(code **)(*piVar33 + 0x78);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166600;
            (*pcVar12)(piVar33, piVar14, 0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166611;
            func_0x0001804986e0(&var_1c10h, 0, 0x1b20);
            var_1c14h = 0x10;
            var_1c18h = 0x10;
            pcVar12 = *(code **)(*piVar33 + 0x300);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166633;
            (*pcVar12)(piVar33, &var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016664a;
            (*pcVar12)(piVar33, &var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x2f0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016665d;
            (*pcVar12)(piVar33, &var_1990h);
            pcVar12 = *(code **)(*piVar33 + 0x2d8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016667e;
            (*pcVar12)(piVar33, &var_1988h, &var_1980h, &var_1970h);
            pcVar12 = *(code **)(*piVar33 + 0x2e0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166698;
            (*pcVar12)(piVar33, &var_1968h, (int64_t)&var_1970h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x248);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666b3;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            pcVar12 = *(code **)(*piVar33 + 600);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801666ce;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            var_1930h._0_4_ = 0x100;
            var_1938h._4_4_ = 0x100;
            var_1938h._0_4_ = 0x100;
            pcVar12 = *(code **)(*piVar33 + 0x250);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016670d;
            (*pcVar12)(piVar33, &var_1950h, &var_1928h, &var_1938h);
            pcVar12 = *(code **)(*piVar33 + 0x260);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016672e;
            (*pcVar12)(piVar33, &var_1948h, &var_1128h, (int64_t)&var_1938h + 4);
            pcVar12 = *(code **)(*piVar33 + 0x240);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166749;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            pcVar12 = *(code **)(*piVar33 + 0x290);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016676a;
            (*pcVar12)(piVar33, &var_1940h, &var_928h, &var_1930h);
            pcVar12 = *(code **)(*piVar33 + 0x298);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016677d;
            (*pcVar12)(piVar33, &var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x280);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016679e;
            (*pcVar12)(piVar33, &var_120h, &var_fch, &var_108h);
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x278);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667d1;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            pcVar12 = *(code **)(*piVar33 + 0x270);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667e4;
            (*pcVar12)(piVar33, (int64_t)&var_fch + 4);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801667ef;
            fcn.180165e00(in_RCX, (int64_t)piVar33);
            *(int64_t **)((int64_t)&arg_50h + iVar20) = *ppiVar27;
            iVar34 = 0;
            iVar19 = 0;
            *(int64_t **)((int64_t)&arg_58h + iVar20) = ppiVar27[1];
            *(int64_t **)((int64_t)&arg_60h + iVar20) = ppiVar27[9];
            *(int64_t **)((int64_t)&arg_68h + iVar20) = ppiVar27[10];
            *(int64_t *)((int64_t)&arg_38h + iVar20) = *(int64_t *)0x180781f28;
            *(int64_t *)(*(int64_t *)0x180781f28 + 0xc90) = (int64_t)&arg_50h + iVar20;
            ppiVar24 = *(int32_t ***)(in_RCX + 0x18);
            fVar3 = *(float *)(in_RCX + 0x20);
            fVar4 = *(float *)(in_RCX + 0x24);
            fVar5 = *(float *)(in_RCX + 0x30);
            fVar6 = *(float *)(in_RCX + 0x34);
            ppiVar23 = ppiVar24 + *(int32_t *)(in_RCX + 0x10);
            *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
            *(int32_t ***)((int64_t)&arg_40h + iVar20) = ppiVar23;
            if (ppiVar24 != ppiVar23) {
                do {
                    piVar9 = *ppiVar24;
                    iVar30 = 0;
                    if (0 < *piVar9) {
                        do {
                            pfVar2 = (float *)(*(int64_t *)(piVar9 + 2) + (int64_t)iVar30 * 0x48);
                            pcVar12 = *(code **)(*(int64_t *)(piVar9 + 2) + 0x30 + (int64_t)iVar30 * 0x48);
                            if (pcVar12 == (code *)0x0) {
                                fVar36 = (*pfVar2 - fVar3) * fVar5;
                                fVar37 = (pfVar2[2] - fVar3) * fVar5;
                                if (fVar36 < fVar37) {
                                    fVar38 = (pfVar2[1] - fVar4) * fVar6;
                                    fVar39 = (pfVar2[3] - fVar4) * fVar6;
                                    if (fVar38 < fVar39) {
                                        var_d0h = CONCAT44((int32_t)fVar38, (int32_t)fVar36);
                                        var_c8h = (int32_t)fVar37;
                                        var_c4h = (int32_t)fVar39;
                                        pcVar12 = *(code **)(*piVar33 + 0x168);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166945;
                                        (*pcVar12)(piVar33, 1, &var_d0h);
                                        if (*(int64_t *)(pfVar2 + 4) == 0) {
                                            uVar22 = *(undefined8 *)(pfVar2 + 6);
                                        } else {
                                            uVar22 = *(undefined8 *)(*(int64_t *)(pfVar2 + 4) + 0x10);
                                        }
                                        *(undefined8 *)((int64_t)&arg_48h + iVar20) = uVar22;
                                        pcVar12 = *(code **)(*piVar33 + 0x40);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166973;
                                        (*pcVar12)(piVar33, 0, 1, (int64_t)&arg_48h + iVar20);
                                        fVar36 = pfVar2[8];
                                        fVar37 = pfVar2[9];
                                        fVar38 = pfVar2[10];
                                        pcVar12 = *(code **)(*piVar33 + 0x60);
                                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x18016698e;
                                        (*pcVar12)(piVar33, fVar38, (int32_t)fVar37 + iVar34, (int32_t)fVar36 + iVar19);
                                    }
                                }
                            } else if (pcVar12 == (code *)0xfffffffffffffff8) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668aa;
                                fcn.180165e00(in_RCX, (int64_t)piVar33);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801668b7;
                                (*pcVar12)(piVar9, pfVar2);
                            }
                            iVar30 = iVar30 + 1;
                        } while (iVar30 < *piVar9);
                        ppiVar24 = *(int32_t ***)((int64_t)&arg_30h + iVar20);
                        ppiVar23 = *(int32_t ***)((int64_t)&arg_40h + iVar20);
                    }
                    iVar34 = iVar34 + piVar9[4];
                    ppiVar24 = ppiVar24 + 1;
                    iVar19 = iVar19 + piVar9[8];
                    *(int32_t ***)((int64_t)&arg_30h + iVar20) = ppiVar24;
                } while (ppiVar24 != ppiVar23);
            }
            *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar20) + 0xc90) = 0;
            pcVar12 = *(code **)(*piVar33 + 0x168);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669e0;
            (*pcVar12)(piVar33, var_1c18h, &var_1c10h);
            pcVar12 = *(code **)(*piVar33 + 0x160);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x1801669f6;
            (*pcVar12)(piVar33, var_1c14h, &var_1b10h);
            pcVar12 = *(code **)(*piVar33 + 0x158);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a09;
            (*pcVar12)(piVar33, var_1990h);
            if (var_1990h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1990h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a3d;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x118);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a5e;
            (*pcVar12)(piVar33, var_1988h, &var_1980h, (undefined4)var_1970h);
            if (var_1988h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1988h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a70;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x120);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a8a;
            (*pcVar12)(piVar33, var_1968h, var_1970h._4_4_);
            if (var_1968h != (int64_t *)0x0) {
                pcVar12 = *(code **)(*var_1968h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166a9c;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ab4;
            (*pcVar12)(piVar33, 0, 1, &var_1960h);
            if (var_1960h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1960h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ac6;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x50);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ade;
            (*pcVar12)(piVar33, 0, 1, &var_1958h);
            if (var_1958h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1958h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166af0;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x48);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b0e;
            (*pcVar12)(piVar33, var_1950h, &var_1928h, (uint32_t)var_1938h);
            if (var_1950h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1950h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b20;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = (uint32_t)var_1938h;
            if ((uint32_t)var_1938h != 0) {
                do {
                    if ((int64_t *)(&var_1928h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1928h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b43;
                        (*pcVar12)();
                        uVar25 = (uint32_t)var_1938h;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0x58);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b6d;
            (*pcVar12)(piVar33, var_1948h, &var_1128h, var_1938h._4_4_);
            if (var_1948h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1948h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b7f;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x38);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166b97;
            (*pcVar12)(piVar33, 0, 1, &var_110h);
            if (var_110h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_110h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166ba9;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0xb8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bca;
            (*pcVar12)(piVar33, var_1940h, &var_928h, (undefined4)var_1930h);
            if (var_1940h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_1940h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166bdc;
                (*pcVar12)();
            }
            uVar29 = 0;
            uVar25 = var_1938h._4_4_;
            if (var_1938h._4_4_ != 0) {
                do {
                    if ((int64_t *)(&var_1128h)[uVar29] != (int64_t *)0x0) {
                        pcVar12 = *(code **)(*(int64_t *)(&var_1128h)[uVar29] + 0x10);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c03;
                        (*pcVar12)();
                        uVar25 = var_1938h._4_4_;
                    }
                    uVar26 = (int32_t)uVar29 + 1;
                    uVar29 = (uint64_t)uVar26;
                } while (uVar26 < uVar25);
            }
            pcVar12 = *(code **)(*piVar33 + 0xc0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c21;
            (*pcVar12)(piVar33, (undefined4)var_128h);
            pcVar12 = *(code **)(*piVar33 + 0x98);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c42;
            (*pcVar12)(piVar33, var_120h, (undefined4)var_fch, (undefined4)var_108h);
            if (var_120h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_120h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c54;
                (*pcVar12)();
            }
            iVar10 = *piVar33;
            *(undefined **)((int64_t)&var_18h + iVar20) = var_100h;
            *(int64_t *)((int64_t)&var_10h + iVar20) = (int64_t)&var_108h + 4;
            pcVar12 = *(code **)(iVar10 + 0x90);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c87;
            (*pcVar12)(piVar33, 0, 1, &var_118h);
            if (var_118h != 0) {
                pcVar12 = *(code **)(*(int64_t *)var_118h + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166c99;
                (*pcVar12)();
            }
            pcVar12 = *(code **)(*piVar33 + 0x88);
            *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cac;
            (*pcVar12)(piVar33, stack0xffffffffffffff08);
            if (stack0xffffffffffffff08 != (int64_t *)0x0) {
                pcVar12 = *(code **)(*stack0xffffffffffffff08 + 0x10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cbe;
                (*pcVar12)();
            }
        }
    }
code_r0x000180166cee:
    *(undefined8 *)((int64_t)&uStack_18 + iVar20) = 0x180166cfd;
    func_0x000180459870(var_78h ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar20));
    return;
}

