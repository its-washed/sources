// Chunk 21 - 50 functions

// ============================================================
// Function: FUN_18003b3c0
// Address: 0x18003b3c0
// Size: 1005 bytes
// ============================================================
undefined8 fcn.18003b3c0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined uVar9;
    char cVar10;
    int32_t iVar11;
    uint64_t **ppuVar12;
    uint64_t **ppuVar13;
    undefined8 uVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    uint64_t **ppuVar18;
    uint64_t *puVar19;
    uint64_t **ppuVar20;
    int64_t iVar21;
    double dVar22;
    double dVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    ppuVar12 = *(uint64_t ***)(arg1 + 0x28);
    if (*(uint64_t ***)(arg1 + 0x40) <= *(uint64_t ***)(arg1 + 0x28)) {
        ppuVar12 = *(uint64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppuVar12 + 0xc) == 9) && (puVar19 = *ppuVar12, *(char *)((int64_t)puVar19 + 3) == '{'))
       && (puVar19 + 2 != (uint64_t *)0x0)) {
        if (puVar19[3] != 0) {
            LOCK();
            piVar1 = (int32_t *)(puVar19[3] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        uVar4 = puVar19[2];
        piVar5 = (int64_t *)puVar19[3];
        iVar21 = *(int64_t *)(arg1 + 0x28);
        ppuVar12 = *(uint64_t ***)(arg1 + 0x40);
        ppuVar13 = (uint64_t **)(iVar21 + 0x10);
        if (ppuVar12 <= (uint64_t **)(iVar21 + 0x10)) {
            ppuVar13 = *(uint64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppuVar13 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar11 = func_0x0001800a8360(arg1);
            if (iVar11 == 0) goto code_r0x00018003b789;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            iVar21 = *(int64_t *)(arg1 + 0x28);
            ppuVar12 = *(uint64_t ***)(arg1 + 0x40);
            ppuVar13 = (uint64_t **)(iVar21 + 0x10);
            if (ppuVar12 <= (uint64_t **)(iVar21 + 0x10)) {
                ppuVar13 = *(uint64_t ***)0x180782430;
            }
        }
        puVar19 = *ppuVar13 + 3;
        if (puVar19 == (uint64_t *)0x0) goto code_r0x00018003b789;
        ppuVar13 = (uint64_t **)(iVar21 + 0x10);
        ppuVar18 = ppuVar13;
        if (ppuVar12 <= ppuVar13) {
            ppuVar18 = *(uint64_t ***)0x180782430;
        }
        if ((ppuVar18 == *(uint64_t ***)0x180782430) ||
           ((*(int32_t *)((int64_t)ppuVar18 + 0xc) != 6 && (*(int32_t *)((int64_t)ppuVar18 + 0xc) != 3)))) {
            ppuVar20 = (uint64_t **)0x0;
        } else {
            if (ppuVar12 <= ppuVar13) {
                ppuVar13 = *(uint64_t ***)0x180782430;
            }
            ppuVar20 = (uint64_t **)0x0;
            if (ppuVar13 == *(uint64_t ***)0x180782430) {
                ppuVar13 = ppuVar20;
            }
            ppuVar18 = (uint64_t **)*ppuVar13;
            if (ppuVar18 != (uint64_t **)0x0) {
                ppuVar20 = (uint64_t **)(uint64_t)(uint32_t)(*(int32_t *)(ppuVar18 + 2) + 0x10 + (int32_t)ppuVar18);
            }
        }
        ppuVar13 = (uint64_t **)(iVar21 + 0x20);
        if (ppuVar12 <= (uint64_t **)(iVar21 + 0x20)) {
            ppuVar13 = *(uint64_t ***)0x180782430;
        }
        if ((ppuVar13 == *(uint64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppuVar13 + 0xc) == -1)) {
            func_0x000180088560(arg1, 0x18063da20, 3);
            pcVar6 = (code *)swi(3);
            uVar14 = (*pcVar6)();
            return uVar14;
        }
        iVar11 = (int32_t)ppuVar20;
        if (iVar11 == 0x7898f5) {
            uVar14 = func_0x000180038c70(arg1, ppuVar18, puVar19, 0);
            uVar15 = func_0x000180498cd0(uVar14);
            func_0x00018000f180(uVar4 + 0x38, uVar14, uVar15);
code_r0x00018003b70a:
            if (piVar5 != (int64_t *)0x0) {
                LOCK();
                piVar2 = piVar5 + 1;
                iVar11 = *(int32_t *)piVar2;
                *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                UNLOCK();
                if (iVar11 == 1) {
                    (**(code **)*piVar5)(piVar5);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                    iVar11 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)(*piVar5 + 8))(piVar5);
                    }
                }
            }
            return 0;
        }
        if (iVar11 == 0x7c9ab53b) {
            puVar16 = (undefined4 *)func_0x000180038a40(&var_8h, arg1, ppuVar12, puVar19);
            uVar3 = puVar16[1];
            *(undefined4 *)(uVar4 + 0x58) = *puVar16;
            *(undefined4 *)(uVar4 + 0x5c) = uVar3;
            goto code_r0x00018003b70a;
        }
        if (iVar11 == 0x766319ea) {
            uVar9 = func_0x000180038b70(arg1, ppuVar18, puVar19);
            *(undefined *)(uVar4 + 0x78) = uVar9;
            goto code_r0x00018003b70a;
        }
        if (iVar11 == -0x6268e4a0) {
            uVar9 = func_0x000180038b70(arg1, ppuVar18, puVar19);
            *(undefined *)(uVar4 + 0x79) = uVar9;
            goto code_r0x00018003b70a;
        }
        if (iVar11 == 0x5a7e3adc) {
            puVar16 = (undefined4 *)func_0x000180038ad0(&var_28h, arg1, ppuVar12, puVar19);
            uVar3 = puVar16[1];
            uVar7 = puVar16[2];
            uVar8 = puVar16[3];
            *(undefined4 *)(uVar4 + 0x60) = *puVar16;
            *(undefined4 *)(uVar4 + 100) = uVar3;
            *(undefined4 *)(uVar4 + 0x68) = uVar7;
            *(undefined4 *)(uVar4 + 0x6c) = uVar8;
            goto code_r0x00018003b70a;
        }
        if (iVar11 == 0x70002f) {
            dVar22 = (double)func_0x000180038be0(arg1, ppuVar18, puVar19, ppuVar20, uVar4, piVar5);
            *(float *)(uVar4 + 0x7c) = (float)dVar22;
            goto code_r0x00018003b70a;
        }
        if ((iVar11 == 0x73574aa2) || (iVar11 == 0x2132d063)) {
            dVar22 = (double)func_0x000180038be0(arg1, ppuVar18, puVar19);
            *(float *)(uVar4 + 0x74) = (float)dVar22;
            goto code_r0x00018003b70a;
        }
        if (iVar11 == 0x78f039) {
            dVar22 = (double)func_0x000180038be0(arg1, ppuVar18, puVar19, ppuVar20, uVar4, piVar5);
            uVar17 = *(int64_t *)0x180782330 - *(int64_t *)0x180782328 >> 3;
            if ((int64_t)uVar17 < 0) {
                dVar23 = (double)(uVar17 >> 1 | (uint64_t)((uint32_t)uVar17 & 1));
                dVar23 = dVar23 + dVar23;
            } else {
                dVar23 = (double)uVar17;
            }
            if (dVar23 < dVar22) {
                dVar22 = 0.0;
            }
            *(int32_t *)(uVar4 + 0x70) = (int32_t)dVar22;
            goto code_r0x00018003b70a;
        }
        if (iVar11 == 0xf6000a1) {
            func_0x000180088560(arg1, 0x180622d50);
            pcVar6 = (code *)swi(3);
            uVar14 = (*pcVar6)();
            return uVar14;
        }
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar5 + 1) = *(int32_t *)(piVar5 + 1) + 1;
            UNLOCK();
        }
        var_38h._0_4_ = (undefined4)uVar4;
        var_38h._4_4_ = (undefined4)(uVar4 >> 0x20);
        var_30h._0_4_ = SUB84(piVar5, 0);
        var_30h._4_4_ = (undefined4)((uint64_t)piVar5 >> 0x20);
        var_28h._0_4_ = (undefined4)var_38h;
        var_28h._4_4_ = var_38h._4_4_;
        uStack_20 = (undefined4)var_30h;
        uStack_1c = var_30h._4_4_;
        cVar10 = func_0x000180038ff0(arg1, &var_28h, puVar19);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar5 + 1;
            iVar11 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar11 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar11 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar11 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        if (cVar10 != '\0') goto code_r0x00018003b70a;
        func_0x000180088560(arg1, 0x180622d90, puVar19);
    }
    func_0x0001800883d0(arg1, 1, 0x180622ca0);
code_r0x00018003b789:
    func_0x000180088470(arg1, 2, 6);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_18003b7b0
// Address: 0x18003b7b0
// Size: 816 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 fcn.18003b7b0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar8 + 0xc) != 9) || (iVar3 = *piVar8, *(char *)(iVar3 + 3) != '{')) ||
       ((int64_t *)(iVar3 + 0x10) == (int64_t *)0x0)) goto code_r0x00018003bacb;
    if (*(int64_t *)(iVar3 + 0x18) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar3 + 0x18) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar12 = *(int64_t *)(iVar3 + 0x10);
    piVar8 = *(int64_t **)(iVar3 + 0x18);
    uVar13 = *(uint64_t *)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar9 = (int64_t *)(uVar13 + 0x10);
    if (piVar14 <= (int64_t *)(uVar13 + 0x10)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x00018003baa4;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        uVar13 = *(uint64_t *)(arg1 + 0x28);
        piVar14 = *(int64_t **)(arg1 + 0x40);
        piVar9 = (int64_t *)(uVar13 + 0x10);
        if (piVar14 <= (int64_t *)(uVar13 + 0x10)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar3 = *piVar9;
    if (iVar3 + 0x18 == 0) {
code_r0x00018003baa4:
        func_0x000180088470(arg1, 2, 6);
        pcVar5 = (code *)swi(3);
        uVar10 = (*pcVar5)();
        return uVar10;
    }
    piVar9 = (int64_t *)(uVar13 + 0x10);
    piVar11 = piVar9;
    if (piVar14 <= piVar9) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (piVar11 == *(int64_t **)0x180782430) {
code_r0x00018003ba45:
        iVar7 = 0;
    } else {
        uVar2 = *(uint32_t *)((int64_t)piVar11 + 0xc);
        uVar13 = (uint64_t)uVar2;
        if ((uVar2 != 6) && (uVar2 != 3)) goto code_r0x00018003ba45;
        if (piVar14 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (piVar9 == *(int64_t **)0x180782430) {
            piVar9 = (int64_t *)0x0;
        }
        iVar4 = *piVar9;
        if (iVar4 == 0) goto code_r0x00018003ba45;
        iVar7 = *(int32_t *)(iVar4 + 0x10) + 0x10 + (int32_t)iVar4;
        if (iVar7 == 0x76dac6) {
            iVar3 = *(int64_t *)(iVar12 + 0x38);
            if (iVar3 == *(int64_t *)(iVar12 + 0x40)) {
                func_0x0001800867f0(arg1, 0x1805aadb1, 0);
            } else {
                func_0x0001800867f0(arg1, iVar3, *(int64_t *)(iVar12 + 0x40) - iVar3);
            }
            goto code_r0x00018003b9f0;
        }
        if (iVar7 == 0x3354e) {
            iVar12 = iVar12 + 0x50;
            if (iVar12 == 0) {
                func_0x000180086510(arg1);
            } else {
                uVar10 = func_0x000180498cd0(iVar12);
                func_0x0001800867f0(arg1, iVar12, uVar10);
            }
            goto code_r0x00018003b9f0;
        }
        if (iVar7 == 0x76ee0404) {
            func_0x000180086b20(arg1, *(undefined *)(iVar12 + 0x278));
            goto code_r0x00018003b9f0;
        }
        if (iVar7 == 0x7c9ab53b) {
            func_0x000180038820(arg1, iVar12 + 0x250);
            goto code_r0x00018003b9f0;
        }
        if (iVar7 == 0x70002f) {
            func_0x000180038820(arg1, iVar12 + 600);
            goto code_r0x00018003b9f0;
        }
        if (iVar7 == 0x6528b22) {
            func_0x000180038820(arg1, iVar12 + 0x260);
            goto code_r0x00018003b9f0;
        }
        if ((iVar7 == 0x16ed11af) || (iVar7 == 0x432f6d27)) {
            func_0x000180086570(arg1, 0, uVar13, iVar7, iVar12, piVar8);
            goto code_r0x00018003b9f0;
        }
    }
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar8 + 1) = *(int32_t *)(piVar8 + 1) + 1;
        UNLOCK();
    }
    var_48h._0_4_ = (undefined4)iVar12;
    var_48h._4_4_ = (undefined4)((uint64_t)iVar12 >> 0x20);
    var_40h._0_4_ = SUB84(piVar8, 0);
    var_40h._4_4_ = (undefined4)((uint64_t)piVar8 >> 0x20);
    var_38h._0_4_ = (undefined4)var_48h;
    var_38h._4_4_ = var_48h._4_4_;
    uStack_30 = (undefined4)var_40h;
    uStack_2c = var_40h._4_4_;
    cVar6 = func_0x000180038ef0(arg1, &var_38h, uVar13, iVar7);
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        piVar14 = piVar8 + 1;
        iVar7 = *(int32_t *)piVar14;
        *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
        UNLOCK();
        if (iVar7 == 1) {
            (**(code **)*piVar8)(piVar8);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)(*piVar8 + 8))(piVar8);
            }
        }
    }
    if (cVar6 != '\0') {
code_r0x00018003b9f0:
        if (piVar8 != (int64_t *)0x0) {
            LOCK();
            piVar14 = piVar8 + 1;
            iVar7 = *(int32_t *)piVar14;
            *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar8)(piVar8);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
                iVar7 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar8 + 8))(piVar8);
                }
            }
        }
        return 1;
    }
    func_0x000180088560(arg1, 0x180622dd0, iVar3 + 0x18);
code_r0x00018003bacb:
    func_0x0001800883d0(arg1, 1, 0x180622ca0);
    pcVar5 = (code *)swi(3);
    uVar10 = (*pcVar5)();
    return uVar10;
}

// ============================================================
// Function: FUN_18003bae0
// Address: 0x18003bae0
// Size: 2105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch

undefined8 fcn.18003bae0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t *piVar13;
    int64_t *piVar14;
    undefined8 *puVar15;
    undefined8 uVar16;
    int64_t *piVar17;
    int64_t iVar18;
    undefined4 *puVar19;
    undefined8 uVar20;
    int64_t *piVar21;
    int64_t *piVar22;
    undefined (*pauVar23) [16];
    int64_t *piVar24;
    int64_t iVar25;
    bool bVar26;
    double dVar27;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    piVar17 = (int64_t *)0x0;
    piVar13 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar13 + 0xc) != 9) || (iVar25 = *piVar13, *(char *)(iVar25 + 3) != '{')) ||
       (pauVar23 = (undefined (*) [16])(iVar25 + 0x10), pauVar23 == (undefined (*) [16])0x0)) {
code_r0x00018003c294:
        func_0x0001800883d0(arg1, 1, 0x180622ca0);
code_r0x00018003c2a9:
        func_0x000180088470(arg1, 2, 6);
        pcVar7 = (code *)swi(3);
        uVar20 = (*pcVar7)();
        return uVar20;
    }
    if (*(int64_t *)(iVar25 + 0x18) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar25 + 0x18) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar5 = *(int64_t *)*pauVar23;
    piVar13 = *(int64_t **)(iVar25 + 0x18);
    auVar8 = *pauVar23;
    _var_a8h = *pauVar23;
    piVar21 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar21) {
        piVar21 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar21 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar12 = func_0x0001800a8360(arg1);
        if (iVar12 == 0) goto code_r0x00018003c2a9;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar21 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar21) {
            piVar21 = *(int64_t **)0x180782430;
        }
    }
    iVar25 = *piVar21 + 0x18;
    if (iVar25 == 0) goto code_r0x00018003c2a9;
    piVar21 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar22 = *(int64_t **)(arg1 + 0x40);
    piVar14 = piVar21;
    if (piVar22 <= piVar21) {
        piVar14 = *(int64_t **)0x180782430;
    }
    piVar24 = piVar17;
    if ((piVar14 != *(int64_t **)0x180782430) &&
       ((*(int32_t *)((int64_t)piVar14 + 0xc) == 6 || (*(int32_t *)((int64_t)piVar14 + 0xc) == 3)))) {
        if (piVar22 <= piVar21) {
            piVar21 = *(int64_t **)0x180782430;
        }
        if (piVar21 == *(int64_t **)0x180782430) {
            piVar21 = piVar17;
        }
        iVar6 = *piVar21;
        if (iVar6 != 0) {
            piVar24 = (int64_t *)(uint64_t)((int32_t)iVar6 + *(int32_t *)(iVar6 + 0x10) + 0x10);
        }
    }
    piVar21 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar14 = piVar21;
    if (piVar22 <= piVar21) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) == -1)) {
        func_0x000180088560(arg1, 0x18063da20, 3);
        pcVar7 = (code *)swi(3);
        uVar20 = (*pcVar7)();
        return uVar20;
    }
    iVar12 = (int32_t)piVar24;
    if (iVar12 == 0x76dac6) {
        piVar14 = piVar21;
        if (piVar22 <= piVar21) {
            piVar14 = *(int64_t **)0x180782430;
        }
        if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 6)) {
            uVar20 = func_0x000180038990(arg1);
            func_0x000180088560(arg1, 0x180622bb8, iVar25, uVar20);
code_r0x00018003c2db:
            func_0x00018045f7d4();
code_r0x00018003c2e1:
            func_0x0001804542e8(1);
            goto code_r0x00018003c2ec;
        }
        if (piVar22 <= piVar21) {
            piVar21 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar21 + 0xc) == 6) {
code_r0x00018003bce3:
            piVar17 = (int64_t *)(*piVar21 + 0x18);
            piVar21 = (int64_t *)(uint64_t)*(uint32_t *)(*piVar21 + 0x14);
        } else {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar12 = func_0x0001800a8360(arg1);
            piVar21 = piVar17;
            if (iVar12 != 0) {
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg1, 1);
                }
                piVar21 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
                if (*(int64_t **)(arg1 + 0x40) <= piVar21) {
                    piVar21 = *(int64_t **)0x180782430;
                }
                goto code_r0x00018003bce3;
            }
        }
        func_0x00018003e340(iVar5 + 0x38, piVar17, piVar21);
        puVar15 = (undefined8 *)func_0x0001800137d0();
        uVar20 = *puVar15;
        if (piVar13 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar13 + 1) = *(int32_t *)(piVar13 + 1) + 1;
            UNLOCK();
        }
        _var_98h = _var_a8h;
        uVar16 = func_0x00018045838c();
        piVar17 = (int64_t *)func_0x000180459890(0x10);
        *piVar17 = 0;
        piVar17[1] = 0;
        if (piVar13 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar13 + 1) = *(int32_t *)(piVar13 + 1) + 1;
            UNLOCK();
        }
        *piVar17 = iVar5;
        piVar17[1] = (int64_t)piVar13;
        var_8h = (int64_t)piVar17;
        var_b0h = func_0x000180459890(0x38);
        _var_78h = ZEXT816(0);
        *(undefined (*) [16])var_b0h = _var_78h;
        *(undefined4 *)((undefined *)var_b0h + 8) = 1;
        *(undefined4 *)((undefined *)var_b0h + 0xc) = 1;
        *(undefined8 *)(undefined *)var_b0h = 0x180622900;
        var_b8h = var_b0h + 0x10;
        *(undefined4 *)(*(undefined (*) [16])(var_b0h + 0x10) + 8) = 2;
        *(undefined8 *)(undefined *)var_b8h = 0x1806229b8;
        var_8h = 0;
        *(int64_t **)*(undefined (*) [16])(var_b0h + 0x20) = piVar17;
        *(undefined8 *)(*(undefined (*) [16])(var_b0h + 0x20) + 8) = 0x18003e4b0;
        *(undefined8 *)*(undefined (*) [16])(var_b0h + 0x30) = uVar16;
        func_0x00018000a9d0(uVar20, &var_b8h);
        iVar25 = var_b0h;
        if (var_b0h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_b0h + 8);
            iVar12 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar12 == 1) {
                (***(code ***)var_b0h)(var_b0h);
                LOCK();
                piVar1 = (int32_t *)(iVar25 + 0xc);
                iVar12 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar12 == 1) {
                    (**(code **)(*(int64_t *)iVar25 + 8))(iVar25);
                }
            }
        }
        if (piVar13 == (int64_t *)0x0) goto code_r0x00018003be19;
        LOCK();
        piVar17 = piVar13 + 1;
        iVar12 = *(int32_t *)piVar17;
        *(int32_t *)piVar17 = *(int32_t *)piVar17 + -1;
        UNLOCK();
        if (iVar12 != 1) goto code_r0x00018003be19;
        (**(code **)*piVar13)(piVar13);
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar13 + 0xc);
        iVar12 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar12 != 1) goto code_r0x00018003be19;
        iVar25 = *piVar13;
        piVar17 = piVar13;
    } else {
        if (iVar12 != 0x3354e) {
            if (iVar12 == 0x7c9ab53b) {
                puVar19 = (undefined4 *)func_0x000180038a40(&var_8h, arg1, piVar22, iVar25);
                uVar4 = puVar19[1];
                *(undefined4 *)(iVar5 + 0x250) = *puVar19;
                *(undefined4 *)(iVar5 + 0x254) = uVar4;
                goto code_r0x00018003be19;
            }
            if (iVar12 == 0x70002f) {
                puVar19 = (undefined4 *)func_0x000180038a40(&var_8h, arg1, piVar22, iVar25);
                uVar4 = puVar19[1];
                *(undefined4 *)(iVar5 + 600) = *puVar19;
                *(undefined4 *)(iVar5 + 0x25c) = uVar4;
                *(undefined4 *)(iVar5 + 0x260) = *(undefined4 *)(iVar5 + 600);
                *(undefined4 *)(iVar5 + 0x264) = uVar4;
                goto code_r0x00018003be19;
            }
            if (iVar12 == 0x432f6d27) {
                dVar27 = (double)func_0x000180038be0(arg1, piVar21, iVar25);
                *(int32_t *)(iVar5 + 0x27c) = (int32_t)dVar27;
                goto code_r0x00018003be19;
            }
            if (iVar12 == 0x16ed11af) {
                dVar27 = (double)func_0x000180038be0(arg1, piVar21, iVar25);
                *(double *)(iVar5 + 0x280) = dVar27;
                *(float *)(iVar5 + 600) = *(float *)(iVar5 + 0x260) / (float)dVar27;
                *(float *)(iVar5 + 0x25c) = *(float *)(iVar5 + 0x264) / (float)dVar27;
                goto code_r0x00018003be19;
            }
            if (iVar12 == 0x76ee0404) {
                uVar10 = func_0x000180038b70(arg1, piVar21, iVar25);
                *(undefined *)(iVar5 + 0x278) = uVar10;
                goto code_r0x00018003be19;
            }
            if (piVar13 != (int64_t *)0x0) {
                LOCK();
                *(int32_t *)(piVar13 + 1) = *(int32_t *)(piVar13 + 1) + 1;
                UNLOCK();
            }
            var_b8h = SUB168(_var_a8h, 0);
            var_b0h = SUB168(_var_a8h, 8);
            cVar11 = func_0x000180038ff0(arg1, &var_b8h, iVar25);
            if (piVar13 != (int64_t *)0x0) {
                LOCK();
                piVar17 = piVar13 + 1;
                iVar12 = *(int32_t *)piVar17;
                *(int32_t *)piVar17 = *(int32_t *)piVar17 + -1;
                UNLOCK();
                if (iVar12 == 1) {
                    (**(code **)*piVar13)(piVar13);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar13 + 0xc);
                    iVar12 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar12 == 1) {
                        (**(code **)(*piVar13 + 8))(piVar13);
                    }
                }
            }
            if (cVar11 != '\0') goto code_r0x00018003be19;
            func_0x000180088560(arg1, 0x180622dd0, iVar25);
            goto code_r0x00018003c294;
        }
        *(undefined *)(iVar5 + 0x278) = 0;
        piVar22 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        piVar21 = piVar22;
        if (*(int64_t **)(arg1 + 0x40) <= piVar22) {
            piVar21 = *(int64_t **)0x180782430;
        }
        if ((piVar21 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar21 + 0xc) != 6))
        goto code_r0x00018003c2fb;
        if (*(int64_t **)(arg1 + 0x40) <= piVar22) {
            piVar22 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar22 + 0xc) == 6) {
code_r0x00018003bf14:
            piVar17 = (int64_t *)(*piVar22 + 0x18);
            piVar21 = (int64_t *)(uint64_t)*(uint32_t *)(*piVar22 + 0x14);
        } else {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar12 = func_0x0001800a8360(arg1);
            piVar21 = piVar17;
            if (iVar12 != 0) {
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg1, 1);
                }
                piVar22 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
                if (*(int64_t **)(arg1 + 0x40) <= piVar22) {
                    piVar22 = *(int64_t **)0x180782430;
                }
                goto code_r0x00018003bf14;
            }
        }
        func_0x000180498030(iVar5 + 0x50, piVar17, piVar21);
        func_0x0001800137d0();
        if (piVar13 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar13 + 1) = *(int32_t *)(piVar13 + 1) + 1;
            UNLOCK();
        }
        var_8h = (int64_t)&var_98h;
        _var_98h = auVar8;
        var_88h = (int64_t)piVar21;
        arg1 = func_0x00018045838c();
        iVar6 = var_88h;
        iVar5 = var_90h;
        if (var_90h != 0) {
            LOCK();
            *(int32_t *)(var_90h + 8) = *(int32_t *)(var_90h + 8) + 1;
            UNLOCK();
        }
        iVar25 = var_98h;
        var_60h = var_98h;
        var_58h = var_90h;
        var_50h = var_88h;
        _var_78h = ZEXT816(0);
        var_48h = arg1;
        var_68h = func_0x000180459890();
        *(undefined4 *)var_68h = 1;
        *(undefined4 *)(var_68h + 4) = 2;
        *(undefined8 *)(var_68h + 8) = 0;
        *(undefined8 *)(var_68h + 0x10) = 0;
        *(undefined4 *)(var_68h + 0x18) = 0;
        var_10h = func_0x000180459890(0x20);
        *(int64_t *)var_10h = 0;
        *(int64_t *)(var_10h + 8) = 0;
        if (iVar5 != 0) {
            LOCK();
            *(int32_t *)(iVar5 + 8) = *(int32_t *)(iVar5 + 8) + 1;
            UNLOCK();
        }
        *(int64_t *)var_10h = iVar25;
        *(int64_t *)(var_10h + 8) = iVar5;
        *(int64_t *)(var_10h + 0x10) = iVar6;
        *(int64_t *)(var_10h + 0x18) = arg1;
        iVar18 = func_0x00018045f6e8(0, 0, 0x18003eb60, var_10h, 0, &var_70h);
        auVar8 = _var_78h;
        iVar6 = var_70h;
        var_78h = iVar18;
        auVar9 = _var_78h;
        if (iVar18 == 0) {
code_r0x00018003c2ec:
            var_70h._0_4_ = 0;
            func_0x0001804542e8(6);
code_r0x00018003c2fb:
            uVar20 = func_0x000180038990(arg1);
            func_0x000180088560(arg1, 0x180622bb8, iVar25, uVar20);
            pcVar7 = (code *)swi(3);
            uVar20 = (*pcVar7)();
            return uVar20;
        }
        var_70h._0_4_ = auVar8._8_4_;
        bVar26 = (int32_t)var_70h == 0;
        _var_78h = auVar9;
        if ((bVar26) || (var_b8h = iVar18, var_b0h = iVar6, iVar12 = func_0x000180454a0c(&var_b8h), iVar12 != 0))
        goto code_r0x00018003c2e1;
        _var_a8h = ZEXT816(0);
        _var_78h = ZEXT812(0);
        var_70h._4_4_ = 0;
        if (var_68h != 0) {
            LOCK();
            puVar2 = (uint32_t *)(var_68h + 4);
            uVar3 = *puVar2;
            *puVar2 = *puVar2 - 2;
            UNLOCK();
            if ((uVar3 & 0xfffffffe) == 2) {
                LOCK();
                iVar12 = *(int32_t *)var_68h;
                *(int32_t *)var_68h = *(int32_t *)var_68h + -1;
                UNLOCK();
                if (iVar12 == 1) {
                    func_0x000180459c3c(var_68h, 0x20);
                }
            }
        }
        if ((int32_t)var_70h != 0) goto code_r0x00018003c2db;
        if (iVar5 != 0) {
            LOCK();
            piVar1 = (int32_t *)(iVar5 + 8);
            iVar12 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar12 == 1) {
                (***(code ***)iVar5)(iVar5);
                LOCK();
                piVar1 = (int32_t *)(iVar5 + 0xc);
                iVar12 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar12 == 1) {
                    (**(code **)(*(int64_t *)iVar5 + 8))(iVar5);
                }
            }
        }
        piVar17 = (int64_t *)var_90h;
        if (var_90h == 0) goto code_r0x00018003be19;
        LOCK();
        piVar1 = (int32_t *)(var_90h + 8);
        iVar12 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar12 != 1) goto code_r0x00018003be19;
        (***(code ***)var_90h)(var_90h);
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar17 + 0xc);
        iVar12 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar12 != 1) goto code_r0x00018003be19;
        iVar25 = *piVar17;
    }
    (**(code **)(iVar25 + 8))(piVar17);
code_r0x00018003be19:
    if (piVar13 != (int64_t *)0x0) {
        LOCK();
        piVar17 = piVar13 + 1;
        iVar12 = *(int32_t *)piVar17;
        *(int32_t *)piVar17 = *(int32_t *)piVar17 + -1;
        UNLOCK();
        if (iVar12 == 1) {
            (**(code **)*piVar13)(piVar13);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar13 + 0xc);
            iVar12 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar12 == 1) {
                (**(code **)(*piVar13 + 8))(piVar13);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18003c320
// Address: 0x18003c320
// Size: 293 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18003c320(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    if (*(int64_t *)(arg2 + 8) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    *(undefined8 *)arg1 = *(undefined8 *)arg2;
    *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg2 + 8);
    *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg2 + 0x10);
    fcn.18000b4d0(arg1 + 0x18, arg2 + 0x18);
    fcn.18003e190(arg1 + 0x38, arg2 + 0x38);
    *(undefined8 *)(arg1 + 0x48) = 0x1804a56e0;
    fcn.18000b4d0(arg1 + 0x50, arg2 + 0x50);
    *(undefined8 *)(arg1 + 0x48) = 0x1804a56f0;
    *(undefined8 *)(arg1 + 0x70) = *(undefined8 *)(arg2 + 0x70);
    fcn.18003c450(arg1 + 0x78, arg2 + 0x78);
    *(undefined4 *)(arg1 + 0x98) = *(undefined4 *)(arg2 + 0x98);
    fcn.18000b4d0(arg1 + 0xa0, arg2 + 0xa0);
    fcn.18000b4d0(arg1 + 0xc0, arg2 + 0xc0);
    fcn.18000b4d0(arg1 + 0xe0, arg2 + 0xe0);
    fcn.18000b4d0(arg1 + 0x100, arg2 + 0x100);
    *(undefined8 *)(arg1 + 0x120) = *(undefined8 *)(arg2 + 0x120);
    *(undefined8 *)(arg1 + 0x128) = *(undefined8 *)(arg2 + 0x128);
    *(undefined4 *)(arg1 + 0x130) = *(undefined4 *)(arg2 + 0x130);
    return arg1;
}

// ============================================================
// Function: FUN_18003c450
// Address: 0x18003c450
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18003c450(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    *(undefined *)arg1 = *(undefined *)arg2;
    piVar1 = (int64_t *)(arg1 + 8);
    *piVar1 = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    if ((*(int64_t *)(arg2 + 0x10) - *(int64_t *)(arg2 + 8) >> 3) * -0x79435e50d79435e5 != 0) {
        func_0x00018003e9b0(piVar1);
        iVar2 = *piVar1;
        iVar3 = *(int64_t *)(arg2 + 0x10);
        iVar4 = iVar2;
        for (iVar5 = *(int64_t *)(arg2 + 8); iVar5 != iVar3; iVar5 = iVar5 + 0x98) {
            func_0x0001800385d0(iVar4, iVar5, in_R8, in_R9, iVar2, iVar4, piVar1);
            iVar4 = iVar4 + 0x98;
        }
        *(int64_t *)(arg1 + 0x10) = iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003c510
// Address: 0x18003c510
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003c510(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t unaff_RBX;
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x100);
    fcn.180004e40(arg1 + 0xe0);
    fcn.180004e40(arg1 + 0xc0);
    fcn.180004e40(arg1 + 0xa0);
    fcn.18003e790(unaff_RBX);
    fcn.180004e40(arg1 + 0x50);
    fcn.180015170(unaff_RBX);
    fcn.180459c3c(*(undefined8 *)(arg1 + 0x38), 0x60);
    fcn.180004e40(arg1 + 0x18);
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18003c5d0
// Address: 0x18003c5d0
// Size: 1978 bytes
// ============================================================
undefined8 fcn.18003c5d0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t iVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    undefined8 uVar19;
    int64_t **ppiVar20;
    float fVar21;
    float fVar22;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar11 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) != 6)) {
        func_0x000180088470(arg1, 1, 6);
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        iVar16 = 0;
        if (*(int32_t *)((int64_t)piVar13 + 0xc) == 6) {
code_r0x00018003c675:
            iVar16 = *piVar13 + 0x18;
        } else {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar10 = func_0x0001800a8360(arg1);
            if (iVar10 != 0) {
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg1, 1);
                }
                piVar13 = *(int64_t **)(arg1 + 0x28);
                if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
                    piVar13 = *(int64_t **)0x180782430;
                }
                goto code_r0x00018003c675;
            }
        }
        iVar12 = func_0x000180498cd0(iVar16);
        if (iVar12 == 4) {
            iVar10 = func_0x000180497f30(iVar16, 0x180622a34, 4);
            if (iVar10 == 0) {
                iVar10 = 1;
                uVar19 = 0x180622db8;
            } else {
code_r0x00018003c745:
                if (iVar12 == 4) {
                    iVar10 = func_0x000180497f30(iVar16, 0x180622a54, 4);
                    if (iVar10 == 0) {
                        iVar10 = 5;
                        uVar19 = 0x180622e28;
                    } else {
                        iVar10 = func_0x000180497f30(iVar16, 0x180622a3c, 4);
                        if (iVar10 != 0) goto code_r0x00018003cd49;
                        iVar10 = 0;
                        uVar19 = 0x180622e70;
                    }
                } else {
                    if ((iVar12 != 5) || (iVar10 = func_0x000180497f30(iVar16, 0x180622a7c, 5), iVar10 != 0)) {
code_r0x00018003cd49:
                        func_0x000180088560(arg1, 0x180622e88, iVar16);
                        pcVar8 = (code *)swi(3);
                        uVar19 = (*pcVar8)();
                        return uVar19;
                    }
                    iVar10 = 6;
                    uVar19 = 0x180622e58;
                }
            }
        } else if (iVar12 == 6) {
            iVar10 = func_0x000180497f30(iVar16, 0x180622a4c, 6);
            if (iVar10 == 0) {
                iVar10 = 4;
                uVar19 = 0x180622e10;
            } else {
                iVar10 = func_0x000180497f30(iVar16, 0x180622a44, 6);
                if (iVar10 != 0) goto code_r0x00018003cd49;
                iVar10 = 2;
                uVar19 = 0x180622df8;
            }
        } else {
            if (iVar12 != 8) goto code_r0x00018003c745;
            iVar10 = func_0x000180497f30(iVar16, 0x180622a60, 8);
            if (iVar10 != 0) goto code_r0x00018003cd49;
            iVar10 = 3;
            uVar19 = 0x180622e40;
        }
        (**(code **)((int64_t)iVar10 * 8 + 0x1805ab328))(&var_58h);
        piVar13 = (int64_t *)func_0x000180087f70(arg1, 0x10, 0x7b);
        *piVar13 = 0;
        piVar13[1] = 0;
        if (var_50h != 0) {
            LOCK();
            *(int32_t *)(var_50h + 8) = *(int32_t *)(var_50h + 8) + 1;
            UNLOCK();
        }
        *piVar13 = var_58h;
        piVar13[1] = var_50h;
        *(int32_t *)(var_58h + 0x30) = iVar10;
        LOCK();
        UNLOCK();
        iVar16 = *(int64_t *)0x180782498 + 1;
        *(int64_t *)(var_58h + 0x28) = *(int64_t *)0x180782498;
        *(int64_t *)0x180782498 = iVar16;
        func_0x000180086cc0(arg1, 0xffffd8f0, uVar19);
        func_0x000180087650(arg1, 0xfffffffe);
        uVar18 = ((((((((var_58h & 0xffU ^ 0xcbf29ce484222325) * 0x100000001b3 ^ var_58h >> 8 & 0xffU) * 0x100000001b3 ^
                      var_58h >> 0x10 & 0xffU) * 0x100000001b3 ^ var_58h >> 0x18 & 0xffU) * 0x100000001b3 ^
                    var_58h >> 0x20 & 0xffU) * 0x100000001b3 ^ var_58h >> 0x28 & 0xffU) * 0x100000001b3 ^
                  var_58h >> 0x30 & 0xffU) * 0x100000001b3 ^ var_58h >> 0x38 & 0xffU) * 0x100000001b3;
        ppiVar14 = *(int64_t ***)(*(int64_t *)0x18077af58 + 8 + (uVar18 & *(uint64_t *)0x18077af70) * 0x10);
        ppiVar20 = *(int64_t ***)0x18077af48;
        if (ppiVar14 != *(int64_t ***)0x18077af48) {
            piVar13 = ppiVar14[2];
            ppiVar20 = ppiVar14;
            while ((int64_t *)var_58h != piVar13) {
                if (ppiVar20 == *(int64_t ***)(*(int64_t *)0x18077af58 + (uVar18 & *(uint64_t *)0x18077af70) * 0x10))
                goto code_r0x00018003c937;
                ppiVar20 = (int64_t **)ppiVar20[1];
                piVar13 = ppiVar20[2];
            }
            goto code_r0x00018003ccff;
        }
code_r0x00018003c937:
        if (*(int64_t *)0x18077af50 != 0x7ffffffffffffff) {
            var_48h = 0x18077af48;
            var_40h = 0;
            ppiVar14 = (int64_t **)func_0x000180459890(0x20);
            ppiVar14[2] = (int64_t *)0x0;
            ppiVar14[3] = (int64_t *)0x0;
            if (var_50h != 0) {
                LOCK();
                *(int32_t *)(var_50h + 8) = *(int32_t *)(var_50h + 8) + 1;
                UNLOCK();
            }
            ppiVar14[2] = (int64_t *)var_58h;
            ppiVar14[3] = (int64_t *)var_50h;
            uVar9 = *(uint64_t *)0x18077af78;
            uVar15 = *(int64_t *)0x18077af50 + 1;
            if ((int64_t)uVar15 < 0) {
                fVar21 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
                fVar21 = fVar21 + fVar21;
            } else {
                fVar21 = (float)uVar15;
            }
            if ((int64_t)*(uint64_t *)0x18077af78 < 0) {
                fVar22 = (float)(*(uint64_t *)0x18077af78 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x18077af78 & 1));
                fVar22 = fVar22 + fVar22;
            } else {
                fVar22 = (float)*(uint64_t *)0x18077af78;
            }
            var_40h = (int64_t)ppiVar14;
            if (*(float *)0x18077af40 < fVar21 / fVar22) {
                fVar21 = (float)func_0x000180471c90(fVar21 / *(float *)0x18077af40);
                ppiVar20 = *(int64_t ***)0x18077af48;
                iVar16 = 0;
                if ((9.223372e+18 <= fVar21) && (fVar21 = fVar21 - 9.223372e+18, fVar21 < 9.223372e+18)) {
                    iVar16 = -0x8000000000000000;
                }
                uVar15 = 8;
                if (8 < (uint64_t)((int64_t)fVar21 + iVar16)) {
                    uVar15 = (int64_t)fVar21 + iVar16;
                }
                uVar17 = uVar9;
                if ((uVar9 < uVar15) && ((0x1ff < uVar9 || (uVar17 = uVar9 * 8, uVar9 * 8 < uVar15)))) {
                    uVar17 = uVar15;
                }
                for (iVar16 = 0x3f; 0xfffffffffffffffU >> iVar16 == 0; iVar16 = iVar16 + -1) {
                }
                if ((uint64_t)(1LL << ((uint8_t)iVar16 & 0x3f)) < uVar17) goto code_r0x00018003cd7d;
                uVar15 = uVar17 - 1 | 1;
                iVar16 = 0x3f;
                if (uVar15 != 0) {
                    for (; uVar15 >> iVar16 == 0; iVar16 = iVar16 + -1) {
                    }
                }
                uVar15 = 1LL << ((char)iVar16 + 1U & 0x3f);
                func_0x00018000f7e0(0x18077af58, uVar15 * 2, *(int64_t ***)0x18077af48);
                *(uint64_t *)0x18077af70 = uVar15 - 1;
                *(uint64_t *)0x18077af78 = uVar15;
                ppiVar7 = (int64_t **)**(int64_t ***)0x18077af48;
                iVar16 = *(int64_t *)0x18077af58;
joined_r0x00018003cadf:
                *(int64_t *)0x18077af58 = iVar16;
                if (ppiVar7 != ppiVar20) {
                    ppiVar2 = (int64_t **)*ppiVar7;
                    piVar13 = ppiVar7[2];
                    uVar15 = (((((((((uint64_t)piVar13 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                   (int64_t)piVar13 >> 8 & 0xffU) * 0x100000001b3 ^ (int64_t)piVar13 >> 0x10 & 0xffU) *
                                  0x100000001b3 ^ (int64_t)piVar13 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                (int64_t)piVar13 >> 0x20 & 0xffU) * 0x100000001b3 ^ (int64_t)piVar13 >> 0x28 & 0xffU) *
                               0x100000001b3 ^ (int64_t)piVar13 >> 0x30 & 0xffU) * 0x100000001b3 ^
                             (int64_t)piVar13 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)0x18077af70;
                    ppiVar3 = *(int64_t ***)(iVar16 + uVar15 * 0x10);
                    if (ppiVar3 == ppiVar20) {
                        *(int64_t ***)(iVar16 + uVar15 * 0x10) = ppiVar7;
                        *(int64_t ***)(iVar16 + 8 + uVar15 * 0x10) = ppiVar7;
                        ppiVar7 = ppiVar2;
                        iVar16 = *(int64_t *)0x18077af58;
                    } else {
                        ppiVar4 = *(int64_t ***)(iVar16 + 8 + uVar15 * 0x10);
                        if (piVar13 == ppiVar4[2]) {
                            ppiVar4 = (int64_t **)*ppiVar4;
                            if (ppiVar4 != ppiVar7) {
                                ppiVar3 = (int64_t **)ppiVar7[1];
                                *ppiVar3 = (int64_t *)ppiVar2;
                                ppiVar5 = (int64_t **)ppiVar2[1];
                                *ppiVar5 = (int64_t *)ppiVar4;
                                ppiVar6 = (int64_t **)ppiVar4[1];
                                *ppiVar6 = (int64_t *)ppiVar7;
                                ppiVar4[1] = (int64_t *)ppiVar5;
                                ppiVar2[1] = (int64_t *)ppiVar3;
                                ppiVar7[1] = (int64_t *)ppiVar6;
                            }
                            *(int64_t ***)(iVar16 + 8 + uVar15 * 0x10) = ppiVar7;
                            ppiVar7 = ppiVar2;
                            iVar16 = *(int64_t *)0x18077af58;
                        } else {
                            do {
                                if (ppiVar3 == ppiVar4) {
                                    ppiVar3 = (int64_t **)ppiVar7[1];
                                    *ppiVar3 = (int64_t *)ppiVar2;
                                    piVar13 = ppiVar2[1];
                                    *piVar13 = (int64_t)ppiVar4;
                                    ppiVar5 = (int64_t **)ppiVar4[1];
                                    *ppiVar5 = (int64_t *)ppiVar7;
                                    ppiVar4[1] = piVar13;
                                    ppiVar2[1] = (int64_t *)ppiVar3;
                                    ppiVar7[1] = (int64_t *)ppiVar5;
                                    *(int64_t ***)(iVar16 + uVar15 * 0x10) = ppiVar7;
                                    ppiVar7 = ppiVar2;
                                    iVar16 = *(int64_t *)0x18077af58;
                                    goto joined_r0x00018003cadf;
                                }
                                ppiVar4 = (int64_t **)ppiVar4[1];
                            } while (piVar13 != ppiVar4[2]);
                            iVar16 = (int64_t)*ppiVar4;
                            ppiVar3 = (int64_t **)ppiVar7[1];
                            *ppiVar3 = (int64_t *)ppiVar2;
                            piVar13 = ppiVar2[1];
                            *piVar13 = iVar16;
                            ppiVar4 = *(int64_t ***)(iVar16 + 8);
                            *ppiVar4 = (int64_t *)ppiVar7;
                            *(int64_t **)(iVar16 + 8) = piVar13;
                            ppiVar2[1] = (int64_t *)ppiVar3;
                            ppiVar7[1] = (int64_t *)ppiVar4;
                            ppiVar7 = ppiVar2;
                            iVar16 = *(int64_t *)0x18077af58;
                        }
                    }
                    goto joined_r0x00018003cadf;
                }
                ppiVar7 = *(int64_t ***)(iVar16 + 8 + (uVar18 & *(uint64_t *)0x18077af70) * 0x10);
                ppiVar20 = *(int64_t ***)0x18077af48;
                if (ppiVar7 != *(int64_t ***)0x18077af48) {
                    piVar13 = ppiVar7[2];
                    ppiVar20 = ppiVar7;
                    while (ppiVar14[2] != piVar13) {
                        if (ppiVar20 == *(int64_t ***)(iVar16 + (uVar18 & *(uint64_t *)0x18077af70) * 0x10))
                        goto code_r0x00018003cc7a;
                        ppiVar20 = (int64_t **)ppiVar20[1];
                        piVar13 = ppiVar20[2];
                    }
                    ppiVar20 = (int64_t **)*ppiVar20;
                }
            }
code_r0x00018003cc7a:
            piVar13 = ppiVar20[1];
            *(int64_t *)0x18077af50 = *(int64_t *)0x18077af50 + 1;
            *ppiVar14 = (int64_t *)ppiVar20;
            ppiVar14[1] = piVar13;
            *piVar13 = (int64_t)ppiVar14;
            ppiVar20[1] = (int64_t *)ppiVar14;
            iVar16 = *(int64_t *)0x18077af58;
            uVar18 = uVar18 & *(uint64_t *)0x18077af70;
            ppiVar7 = *(int64_t ***)(*(int64_t *)0x18077af58 + uVar18 * 0x10);
            if (ppiVar7 == *(int64_t ***)0x18077af48) {
                *(int64_t ***)(*(int64_t *)0x18077af58 + uVar18 * 0x10) = ppiVar14;
            } else {
                if (ppiVar7 == ppiVar20) {
                    *(int64_t ***)(*(int64_t *)0x18077af58 + uVar18 * 0x10) = ppiVar14;
                    goto code_r0x00018003ccff;
                }
                if (*(int64_t **)(*(int64_t *)0x18077af58 + 8 + uVar18 * 0x10) != piVar13) goto code_r0x00018003ccff;
            }
            *(int64_t ***)(iVar16 + 8 + uVar18 * 0x10) = ppiVar14;
code_r0x00018003ccff:
            if (var_50h != 0) {
                LOCK();
                piVar1 = (int32_t *)(var_50h + 8);
                iVar10 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar10 == 1) {
                    (***(code ***)var_50h)(var_50h);
                    LOCK();
                    piVar1 = (int32_t *)(var_50h + 0xc);
                    iVar10 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)(*(int64_t *)var_50h + 8))(var_50h);
                    }
                }
            }
            return 1;
        }
    }
    func_0x0001804546d4(0x180620428);
code_r0x00018003cd7d:
    func_0x0001804546d4(0x180620448);
    pcVar8 = (code *)swi(3);
    uVar19 = (*pcVar8)();
    return uVar19;
}

// ============================================================
// Function: FUN_18003cd90
// Address: 0x18003cd90
// Size: 66 bytes
// ============================================================
undefined8 fcn.18003cd90(int64_t arg1)
{
    int64_t *piVar1;
    uint32_t uVar2;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar1 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar1 + 0xc) == 9) {
        uVar2 = (uint32_t)*(uint8_t *)(*piVar1 + 3);
    } else {
        uVar2 = 0xffffffff;
    }
    func_0x000180086b20(arg1, uVar2 == 0x7b);
    return 1;
}

// ============================================================
// Function: FUN_18003cde0
// Address: 0x18003cde0
// Size: 664 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.18003cde0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    int64_t **ppiVar11;
    int64_t *piVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t *piStack_10;
    
    ppiVar11 = *(int64_t ***)(arg1 + 0x28);
    ppiVar3 = *(int64_t ***)(arg1 + 0x40);
    ppiVar7 = ppiVar11;
    if (ppiVar3 <= ppiVar11) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar7 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar7 + 0xc) != 9)) {
        func_0x000180088470(arg1, 1, 9);
code_r0x00018003d00d:
        iVar8 = func_0x00018001ed90(&var_18h);
        uVar9 = func_0x0001800387a0(*(undefined4 *)(iVar8 + 0x30));
        func_0x000180088560(arg1, 0x180622ee8, 0x180622ea8, uVar9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    ppiVar7 = ppiVar11 + 2;
    if (ppiVar3 <= ppiVar11 + 2) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar7 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar7 + 0xc) != 6)) {
        func_0x000180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    ppiVar7 = ppiVar11;
    if (ppiVar3 <= ppiVar11) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if ((*(int32_t *)((int64_t)ppiVar7 + 0xc) != 9) || (*(char *)((int64_t)*ppiVar7 + 3) != '{')) {
code_r0x00018003d049:
        func_0x000180088560(arg1, 0x180622eb8);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    if (ppiVar3 <= ppiVar11) {
        ppiVar11 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 9) {
        piVar12 = *ppiVar11 + 2;
    } else if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 2) {
        piVar12 = *ppiVar11;
    } else {
        piVar12 = (int64_t *)0x0;
    }
    if (piVar12[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar12[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar8 = *piVar12;
    piVar12 = (int64_t *)piVar12[1];
    ppiVar11 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar11) {
        ppiVar11 = *(int64_t ***)0x180782430;
    }
    var_18h = iVar8;
    piStack_10 = piVar12;
    if (*(int32_t *)((int64_t)ppiVar11 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018003d00d;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        ppiVar11 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar11) {
            ppiVar11 = *(int64_t ***)0x180782430;
        }
    }
    if (*ppiVar11 == (int64_t *)0xffffffffffffffe8) goto code_r0x00018003d00d;
    // switch table (7 cases) at 0x18003d05c
    switch(*(undefined4 *)(iVar8 + 0x30)) {
    case 0:
        uVar6 = func_0x00018003aea0(arg1);
        break;
    case 1:
        uVar6 = func_0x000180039100(arg1);
        break;
    case 2:
        uVar6 = func_0x000180039c70(arg1);
        break;
    case 3:
        uVar6 = func_0x00018003a240(arg1);
        break;
    case 4:
        uVar6 = func_0x000180039690(arg1);
        break;
    case 5:
        uVar6 = func_0x00018003a850(arg1);
        break;
    case 6:
        uVar6 = fcn.18003b7b0(arg1);
        uVar10 = (uint64_t)uVar6;
        if (piVar12 == (int64_t *)0x0) {
            return uVar10;
        }
        LOCK();
        piVar2 = piVar12 + 1;
        iVar5 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        goto code_r0x00018003cf61;
    default:
        func_0x000180088560(arg1, 0x180622ed0);
        goto code_r0x00018003d049;
    }
    uVar10 = (uint64_t)uVar6;
    if (piVar12 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar12 + 1;
        iVar5 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
code_r0x00018003cf61:
        if (iVar5 == 1) {
            (**(code **)*piVar12)(piVar12);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar12 + 0xc);
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar12 + 8))(piVar12);
            }
        }
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18003d080
// Address: 0x18003d080
// Size: 720 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch

uint64_t fcn.18003d080(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    code *pcVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t *piStack_10;
    
    ppiVar12 = *(int64_t ***)(arg1 + 0x28);
    ppiVar3 = *(int64_t ***)(arg1 + 0x40);
    ppiVar7 = ppiVar12;
    if (ppiVar3 <= ppiVar12) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar7 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar7 + 0xc) != 9)) {
        func_0x000180088470(arg1, 1, 9);
code_r0x00018003d2cf:
        iVar8 = func_0x00018001ed90(&var_18h);
        uVar9 = func_0x0001800387a0(*(undefined4 *)(iVar8 + 0x30));
        func_0x000180088560(arg1, 0x180622ee8, 0x180622ea8, uVar9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    ppiVar7 = ppiVar12 + 2;
    if (ppiVar3 <= ppiVar12 + 2) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar7 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar7 + 0xc) != 6)) {
        func_0x000180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    ppiVar7 = ppiVar12 + 4;
    if (ppiVar3 <= ppiVar12 + 4) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar7 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar7 + 0xc) == -1)) {
        func_0x000180088560(arg1, 0x18063da20, 3);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    ppiVar7 = ppiVar12;
    if (ppiVar3 <= ppiVar12) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if ((*(int32_t *)((int64_t)ppiVar7 + 0xc) != 9) || (*(char *)((int64_t)*ppiVar7 + 3) != '{')) {
code_r0x00018003d30b:
        func_0x000180088560(arg1, 0x180622eb8);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    if (ppiVar3 <= ppiVar12) {
        ppiVar12 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar12 + 0xc) == 9) {
        piVar11 = *ppiVar12 + 2;
    } else if (*(int32_t *)((int64_t)ppiVar12 + 0xc) == 2) {
        piVar11 = *ppiVar12;
    } else {
        piVar11 = (int64_t *)0x0;
    }
    if (piVar11[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar11[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar8 = *piVar11;
    piVar11 = (int64_t *)piVar11[1];
    ppiVar12 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar12) {
        ppiVar12 = *(int64_t ***)0x180782430;
    }
    var_18h = iVar8;
    piStack_10 = piVar11;
    if (*(int32_t *)((int64_t)ppiVar12 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1, ppiVar12);
        if (iVar5 == 0) goto code_r0x00018003d2cf;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        ppiVar12 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar12) {
            ppiVar12 = *(int64_t ***)0x180782430;
        }
    }
    if (*ppiVar12 == (int64_t *)0xffffffffffffffe8) goto code_r0x00018003d2cf;
    // switch table (7 cases) at 0x18003d334
    switch(*(undefined4 *)(iVar8 + 0x30)) {
    case 0:
        uVar6 = fcn.18003b3c0(arg1);
        break;
    case 1:
        uVar6 = func_0x000180039360(arg1);
        break;
    case 2:
        uVar6 = func_0x000180039ef0(arg1);
        break;
    case 3:
        uVar6 = func_0x00018003a4d0(arg1);
        break;
    case 4:
        uVar6 = func_0x000180039920(arg1);
        break;
    case 5:
        uVar6 = func_0x00018003aaf0(arg1);
        break;
    case 6:
        uVar6 = fcn.18003bae0(arg1);
        uVar10 = (uint64_t)uVar6;
        if (piVar11 == (int64_t *)0x0) {
            return uVar10;
        }
        LOCK();
        piVar2 = piVar11 + 1;
        iVar5 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        goto code_r0x00018003d223;
    default:
        func_0x000180088560(arg1, 0x180622ed0);
        goto code_r0x00018003d30b;
    }
    uVar10 = (uint64_t)uVar6;
    if (piVar11 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar11 + 1;
        iVar5 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
code_r0x00018003d223:
        if (iVar5 == 1) {
            (**(code **)*piVar11)(piVar11);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar11 + 0xc);
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar11 + 8))(piVar11);
            }
        }
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18003d350
// Address: 0x18003d350
// Size: 721 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch

void fcn.18003d350(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x3808) = 0x180038ce0;
    var_10h = arg2;
    fcn.180018f70();
    var_18h = (int64_t)&var_10h;
    fcn.18003d840(&var_18h, 0x180622e70, 0x18003aea0, fcn.18003b3c0);
    fcn.18003d840(&var_18h, 0x180622db8, 0x180039100, 0x180039360);
    fcn.18003d840(&var_18h, 0x180622df8, 0x180039c70, 0x180039ef0);
    fcn.18003d840(&var_18h, 0x180622e40, 0x18003a240, 0x18003a4d0);
    fcn.18003d840(&var_18h, 0x180622e10, 0x180039690, 0x180039920);
    fcn.18003d840(&var_18h, 0x180622e28, 0x18003a850, 0x18003aaf0);
    fcn.18003d840(&var_18h, 0x180622e58, fcn.18003b7b0, fcn.18003bae0);
    fcn.180086fd0(var_10h, 0, 0);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x1805aaeec);
    fcn.180086fd0(var_10h, 0, 0);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f10);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x3ff0000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f08);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x4000000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f24);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x4008000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f18);
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f38);
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f30);
    iVar1 = var_10h;
    var_28h = 0x180622f50;
    uVar7 = *(int64_t *)(var_10h + 0x40) - *(int64_t *)(var_10h + 0x28) >> 4;
    fcn.1800869f0(0);
    fcn.180087370(iVar1, uVar7 & 0xffffffff, 0x180622f40);
    piVar8 = &var_28h;
    do {
        fcn.180086cc0(iVar1, uVar7 & 0xffffffff, 0x180622f40);
        iVar6 = *(int64_t *)(iVar1 + 0x40) + -0x10;
        if ((iVar6 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 0)) {
            fcn.180087370(iVar1, uVar7 & 0xffffffff, *piVar8);
        } else {
            *(int64_t *)(iVar1 + 0x40) = iVar6;
        }
        iVar6 = var_10h;
        piVar8 = piVar8 + 1;
    } while (piVar8 != (int64_t *)&stack0xffffffffffffffe0);
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar3 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar6, iVar1 - iVar3 >> 4 & 0xffffffff, 0x180622f78);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x180622f60);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x180622f90);
    return;
}

// ============================================================
// Function: FUN_18003d621
// Address: 0x18003d621
// Size: 439 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch

void fcn.18003d350(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x3808) = 0x180038ce0;
    var_10h = arg2;
    fcn.180018f70();
    var_18h = (int64_t)&var_10h;
    fcn.18003d840(&var_18h, 0x180622e70, 0x18003aea0, fcn.18003b3c0);
    fcn.18003d840(&var_18h, 0x180622db8, 0x180039100, 0x180039360);
    fcn.18003d840(&var_18h, 0x180622df8, 0x180039c70, 0x180039ef0);
    fcn.18003d840(&var_18h, 0x180622e40, 0x18003a240, 0x18003a4d0);
    fcn.18003d840(&var_18h, 0x180622e10, 0x180039690, 0x180039920);
    fcn.18003d840(&var_18h, 0x180622e28, 0x18003a850, 0x18003aaf0);
    fcn.18003d840(&var_18h, 0x180622e58, fcn.18003b7b0, fcn.18003bae0);
    fcn.180086fd0(var_10h, 0, 0);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x1805aaeec);
    fcn.180086fd0(var_10h, 0, 0);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f10);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x3ff0000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f08);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x4000000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f24);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x4008000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f18);
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f38);
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f30);
    iVar1 = var_10h;
    var_28h = 0x180622f50;
    uVar7 = *(int64_t *)(var_10h + 0x40) - *(int64_t *)(var_10h + 0x28) >> 4;
    fcn.1800869f0(0);
    fcn.180087370(iVar1, uVar7 & 0xffffffff, 0x180622f40);
    piVar8 = &var_28h;
    do {
        fcn.180086cc0(iVar1, uVar7 & 0xffffffff, 0x180622f40);
        iVar6 = *(int64_t *)(iVar1 + 0x40) + -0x10;
        if ((iVar6 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 0)) {
            fcn.180087370(iVar1, uVar7 & 0xffffffff, *piVar8);
        } else {
            *(int64_t *)(iVar1 + 0x40) = iVar6;
        }
        iVar6 = var_10h;
        piVar8 = piVar8 + 1;
    } while (piVar8 != (int64_t *)&stack0xffffffffffffffe0);
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar3 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar6, iVar1 - iVar3 >> 4 & 0xffffffff, 0x180622f78);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x180622f60);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x180622f90);
    return;
}

// ============================================================
// Function: FUN_18003d7d8
// Address: 0x18003d7d8
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch

void fcn.18003d350(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x3808) = 0x180038ce0;
    var_10h = arg2;
    fcn.180018f70();
    var_18h = (int64_t)&var_10h;
    fcn.18003d840(&var_18h, 0x180622e70, 0x18003aea0, fcn.18003b3c0);
    fcn.18003d840(&var_18h, 0x180622db8, 0x180039100, 0x180039360);
    fcn.18003d840(&var_18h, 0x180622df8, 0x180039c70, 0x180039ef0);
    fcn.18003d840(&var_18h, 0x180622e40, 0x18003a240, 0x18003a4d0);
    fcn.18003d840(&var_18h, 0x180622e10, 0x180039690, 0x180039920);
    fcn.18003d840(&var_18h, 0x180622e28, 0x18003a850, 0x18003aaf0);
    fcn.18003d840(&var_18h, 0x180622e58, fcn.18003b7b0, fcn.18003bae0);
    fcn.180086fd0(var_10h, 0, 0);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x1805aaeec);
    fcn.180086fd0(var_10h, 0, 0);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f10);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x3ff0000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f08);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x4000000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f24);
    iVar1 = var_10h;
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(var_10h + 0x18) < *(int64_t *)(var_10h + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar5 == 0) {
            fcn.180099450(iVar1, 0x18063d8d0);
            fcn.180087960(iVar1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar2 = *(undefined8 **)(iVar1 + 0x40);
    *puVar2 = 0x4008000000000000;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 3;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f18);
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f38);
    fcn.180087370(var_10h, 0xfffffffe, 0x180622f30);
    iVar1 = var_10h;
    var_28h = 0x180622f50;
    uVar7 = *(int64_t *)(var_10h + 0x40) - *(int64_t *)(var_10h + 0x28) >> 4;
    fcn.1800869f0(0);
    fcn.180087370(iVar1, uVar7 & 0xffffffff, 0x180622f40);
    piVar8 = &var_28h;
    do {
        fcn.180086cc0(iVar1, uVar7 & 0xffffffff, 0x180622f40);
        iVar6 = *(int64_t *)(iVar1 + 0x40) + -0x10;
        if ((iVar6 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 0)) {
            fcn.180087370(iVar1, uVar7 & 0xffffffff, *piVar8);
        } else {
            *(int64_t *)(iVar1 + 0x40) = iVar6;
        }
        iVar6 = var_10h;
        piVar8 = piVar8 + 1;
    } while (piVar8 != (int64_t *)&stack0xffffffffffffffe0);
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar3 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar6, iVar1 - iVar3 >> 4 & 0xffffffff, 0x180622f78);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x180622f60);
    iVar3 = var_10h;
    iVar1 = *(int64_t *)(var_10h + 0x40);
    iVar6 = *(int64_t *)(var_10h + 0x28);
    fcn.1800869f0(0);
    fcn.180087370(iVar3, iVar1 - iVar6 >> 4 & 0xffffffff, 0x180622f90);
    return;
}

// ============================================================
// Function: FUN_18003d840
// Address: 0x18003d840
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18003d840(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = fcn.1800885b0(**(undefined8 **)arg1);
    if (iVar1 != 0) {
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1805aae90);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806203c0);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806203d0);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x180622440);
        fcn.1800867f0(**(undefined8 **)arg1, 0x180622ca0, 0xd);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x180622470);
        fcn.1800867f0(**(undefined8 **)arg1, 0x180622458, 0x17);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806224a0);
    }
    *(int64_t *)(**(int64_t **)arg1 + 0x40) = *(int64_t *)(**(int64_t **)arg1 + 0x40) + -0x10;
    return;
}

// ============================================================
// Function: FUN_18003d871
// Address: 0x18003d871
// Size: 300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18003d840(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = fcn.1800885b0(**(undefined8 **)arg1);
    if (iVar1 != 0) {
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1805aae90);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806203c0);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806203d0);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x180622440);
        fcn.1800867f0(**(undefined8 **)arg1, 0x180622ca0, 0xd);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x180622470);
        fcn.1800867f0(**(undefined8 **)arg1, 0x180622458, 0x17);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806224a0);
    }
    *(int64_t *)(**(int64_t **)arg1 + 0x40) = *(int64_t *)(**(int64_t **)arg1 + 0x40) + -0x10;
    return;
}

// ============================================================
// Function: FUN_18003d99d
// Address: 0x18003d99d
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18003d840(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = fcn.1800885b0(**(undefined8 **)arg1);
    if (iVar1 != 0) {
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1805aae90);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806203c0);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806203d0);
        fcn.1800869f0(0);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x180622440);
        fcn.1800867f0(**(undefined8 **)arg1, 0x180622ca0, 0xd);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x180622470);
        fcn.1800867f0(**(undefined8 **)arg1, 0x180622458, 0x17);
        fcn.180087370(**(undefined8 **)arg1, 0xfffffffe, 0x1806224a0);
    }
    *(int64_t *)(**(int64_t **)arg1 + 0x40) = *(int64_t *)(**(int64_t **)arg1 + 0x40) + -0x10;
    return;
}

// ============================================================
// Function: FUN_18003d9c0
// Address: 0x18003d9c0
// Size: 32 bytes
// ============================================================
undefined8 fcn.18003d9c0(undefined8 param_1)
{
    fcn.1800867f0(param_1, 0x180622ca0, 0xd);
    return 1;
}

// ============================================================
// Function: FUN_18003d9e0
// Address: 0x18003d9e0
// Size: 34 bytes
// ============================================================
undefined8 fcn.18003d9e0(int64_t arg1)
{
    undefined8 uVar1;
    
    uVar1 = *(undefined8 *)(arg1 + 0x10);
    *(undefined8 *)(arg1 + 0x10) = 0;
    (**(code **)(arg1 + 0x18))(0, uVar1, 0);
    return 0;
}

// ============================================================
// Function: FUN_18003da10
// Address: 0x18003da10
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18003da10(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int64_t var_8h;
    int64_t var_10h;
    
    pauVar1 = (undefined (*) [16])fcn.180459890(0x98);
    *(undefined (**) [16])(arg1 + 8) = pauVar1;
    *pauVar1 = ZEXT816(0);
    *(undefined8 *)*pauVar1 = 0x180622940;
    *(undefined4 *)(*pauVar1 + 8) = 1;
    *(undefined4 *)(*pauVar1 + 0xc) = 1;
    *(undefined2 *)(pauVar1[1] + 9) = 0;
    pauVar1[1][0xb] = 0;
    *(undefined8 *)pauVar1[3] = 0;
    *(undefined8 *)pauVar1[4] = 0;
    pauVar1[1][8] = 0;
    *(undefined8 *)pauVar1[1] = 0x180622968;
    *(undefined4 *)(pauVar1[1] + 0xc) = 1;
    *(undefined8 *)pauVar1[2] = 0x3f800000;
    *(undefined8 *)(pauVar1[3] + 8) = 0;
    *(undefined8 *)(pauVar1[8] + 4) = 0x3f800000;
    *(undefined8 *)(pauVar1[2] + 8) = 0;
    *(undefined (*) [16])(pauVar1[4] + 8) = ZEXT816(0);
    *(undefined8 *)(pauVar1[5] + 8) = 0;
    *(undefined8 *)pauVar1[6] = 0xf;
    pauVar1[4][8] = 0;
    *(undefined (**) [16])arg1 = pauVar1 + 1;
    *(undefined8 *)(pauVar1[6] + 8) = 0;
    *(undefined8 *)pauVar1[7] = 0;
    *(undefined8 *)(pauVar1[7] + 8) = 0;
    *(undefined4 *)pauVar1[8] = 0;
    *(undefined8 *)(pauVar1[8] + 0xc) = 0x41800000;
    *(undefined4 *)(pauVar1[9] + 4) = 0x41800000;
    return arg1;
}

// ============================================================
// Function: FUN_18003dae0
// Address: 0x18003dae0
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18003dae0(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int64_t var_8h;
    int64_t var_10h;
    
    pauVar1 = (undefined (*) [16])fcn.180459890(0x60);
    *pauVar1 = ZEXT816(0);
    *(undefined8 *)*pauVar1 = 0x180622920;
    *(undefined4 *)(*pauVar1 + 8) = 1;
    *(undefined4 *)(*pauVar1 + 0xc) = 1;
    *(undefined2 *)(pauVar1[1] + 9) = 0;
    pauVar1[1][0xb] = 0;
    *(undefined8 *)pauVar1[3] = 0;
    *(undefined8 *)pauVar1[4] = 0;
    *(undefined (**) [16])(arg1 + 8) = pauVar1;
    *(undefined (**) [16])arg1 = pauVar1 + 1;
    *(undefined8 *)(pauVar1[5] + 8) = 0;
    pauVar1[1][8] = 0;
    *(undefined4 *)(pauVar1[1] + 0xc) = 1;
    *(undefined8 *)pauVar1[2] = 0x3f800000;
    *(undefined8 *)(pauVar1[2] + 8) = 0;
    *(undefined8 *)(pauVar1[3] + 8) = 0;
    *(undefined8 *)pauVar1[1] = 0x180622960;
    *(undefined8 *)(pauVar1[4] + 8) = 0;
    *(undefined8 *)pauVar1[5] = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18003db80
// Address: 0x18003db80
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18003db80(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int64_t var_8h;
    int64_t var_10h;
    
    pauVar1 = (undefined (*) [16])fcn.180459890(0x60);
    *pauVar1 = ZEXT816(0);
    *(undefined4 *)(*pauVar1 + 8) = 1;
    *(undefined4 *)(*pauVar1 + 0xc) = 1;
    *(undefined8 *)*pauVar1 = 0x180622920;
    *(undefined2 *)(pauVar1[1] + 9) = 0;
    pauVar1[1][0xb] = 0;
    *(undefined8 *)pauVar1[3] = 0;
    *(undefined8 *)pauVar1[4] = 0;
    *(undefined2 *)(pauVar1[5] + 0xd) = 0;
    pauVar1[5][0xf] = 0;
    *(undefined8 *)pauVar1[1] = 0x180622960;
    *(undefined (**) [16])arg1 = pauVar1 + 1;
    *(undefined (**) [16])(arg1 + 8) = pauVar1;
    pauVar1[1][8] = 0;
    *(undefined4 *)(pauVar1[1] + 0xc) = 1;
    *(undefined8 *)pauVar1[2] = 0x3f800000;
    *(undefined8 *)(pauVar1[2] + 8) = 0;
    *(undefined8 *)(pauVar1[3] + 8) = 0;
    *(undefined8 *)(pauVar1[4] + 8) = 0;
    *(undefined8 *)pauVar1[5] = 0;
    *(undefined4 *)(pauVar1[5] + 8) = 0x10;
    pauVar1[5][0xc] = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18003dc30
// Address: 0x18003dc30
// Size: 165 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18003dc30(int64_t arg1)
{
    undefined (*pauVar1) [16];
    undefined (*pauVar2) [16];
    int64_t var_8h;
    int64_t var_10h;
    
    pauVar2 = (undefined (*) [16])fcn.180459890(0x68);
    *(undefined (**) [16])(arg1 + 8) = pauVar2;
    *pauVar2 = ZEXT816(0);
    *(undefined8 *)*pauVar2 = 0x180622998;
    pauVar1 = pauVar2 + 1;
    *(undefined4 *)(*pauVar2 + 8) = 1;
    *(undefined4 *)(*pauVar2 + 0xc) = 1;
    *pauVar1 = ZEXT816(0);
    *(undefined (**) [16])arg1 = pauVar1;
    pauVar2[2] = ZEXT816(0);
    pauVar2[3] = ZEXT816(0);
    pauVar2[4] = ZEXT816(0);
    pauVar2[5] = ZEXT816(0);
    *(undefined8 *)pauVar2[6] = 0;
    *(undefined8 *)*pauVar1 = 0x1806229d0;
    *(undefined4 *)(pauVar2[1] + 0xc) = 1;
    *(undefined8 *)pauVar2[2] = 0x3f800000;
    *(undefined8 *)(pauVar2[2] + 8) = 0;
    *(undefined4 *)pauVar2[3] = 0;
    *(undefined8 *)(pauVar2[4] + 8) = 0;
    *(undefined8 *)pauVar2[5] = 0;
    *(undefined8 *)(pauVar2[5] + 8) = 0;
    *(undefined4 *)pauVar2[6] = 2;
    pauVar2[6][4] = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18003dce0
// Address: 0x18003dce0
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18003dce0(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int64_t var_8h;
    int64_t var_10h;
    
    pauVar1 = (undefined (*) [16])fcn.180459890(0x60);
    *pauVar1 = ZEXT816(0);
    *(undefined4 *)(*pauVar1 + 8) = 1;
    *(undefined4 *)(*pauVar1 + 0xc) = 1;
    *(undefined8 *)*pauVar1 = 0x180622920;
    *(undefined2 *)(pauVar1[1] + 9) = 0;
    pauVar1[1][0xb] = 0;
    *(undefined8 *)pauVar1[3] = 0;
    *(undefined8 *)pauVar1[4] = 0;
    *(undefined2 *)(pauVar1[5] + 1) = 0;
    pauVar1[5][3] = 0;
    *(undefined8 *)pauVar1[1] = 0x180622960;
    *(undefined (**) [16])arg1 = pauVar1 + 1;
    *(undefined (**) [16])(arg1 + 8) = pauVar1;
    pauVar1[1][8] = 0;
    *(undefined4 *)(pauVar1[1] + 0xc) = 1;
    *(undefined8 *)pauVar1[2] = 0x3f800000;
    *(undefined8 *)(pauVar1[2] + 8) = 0;
    *(undefined8 *)(pauVar1[3] + 8) = 0;
    *(undefined8 *)(pauVar1[4] + 8) = 0;
    pauVar1[5][0] = 0;
    *(undefined4 *)(pauVar1[5] + 4) = 1;
    *(undefined4 *)(pauVar1[5] + 8) = 0x10;
    *(undefined4 *)(pauVar1[5] + 0xc) = 100;
    return arg1;
}

// ============================================================
// Function: FUN_18003dda0
// Address: 0x18003dda0
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18003dda0(int64_t arg1)
{
    undefined (*pauVar1) [16];
    undefined (*pauVar2) [16];
    int64_t var_8h;
    int64_t var_10h;
    
    pauVar2 = (undefined (*) [16])fcn.180459890(0x70);
    *(undefined (**) [16])(arg1 + 8) = pauVar2;
    *pauVar2 = ZEXT816(0);
    *(undefined8 *)*pauVar2 = 0x180622978;
    pauVar1 = pauVar2 + 1;
    *(undefined4 *)(*pauVar2 + 8) = 1;
    *(undefined4 *)(*pauVar2 + 0xc) = 1;
    *pauVar1 = ZEXT816(0);
    *(undefined (**) [16])arg1 = pauVar1;
    pauVar2[2] = ZEXT816(0);
    pauVar2[3] = ZEXT816(0);
    pauVar2[4] = ZEXT816(0);
    pauVar2[5] = ZEXT816(0);
    pauVar2[6] = ZEXT816(0);
    *(undefined4 *)(pauVar2[1] + 0xc) = 1;
    *(undefined8 *)pauVar2[2] = 0x3f800000;
    *(undefined8 *)(pauVar2[2] + 8) = 0;
    *(undefined4 *)pauVar2[3] = 0;
    *(undefined8 *)*pauVar1 = 0x1806229f0;
    *(undefined8 *)(pauVar2[4] + 8) = 0;
    *(undefined8 *)pauVar2[5] = 0;
    *(undefined8 *)(pauVar2[5] + 8) = 0;
    *(undefined8 *)pauVar2[6] = 0;
    *(undefined4 *)(pauVar2[6] + 8) = 2;
    pauVar2[6][0xc] = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18003de50
// Address: 0x18003de50
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18003de50(int64_t arg1)
{
    undefined (*pauVar1) [16];
    undefined (*pauVar2) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pauVar2 = (undefined (*) [16])fcn.180459890(0x298);
    *pauVar2 = ZEXT816(0);
    *(undefined4 *)(*pauVar2 + 8) = 1;
    pauVar1 = pauVar2 + 1;
    *(undefined4 *)(*pauVar2 + 0xc) = 1;
    *(undefined8 *)*pauVar2 = 0x1806228e0;
    fcn.1804986e0(pauVar1, 0, 0x288);
    fcn.18003ef50(pauVar1);
    *(undefined (**) [16])arg1 = pauVar1;
    *(undefined (**) [16])(arg1 + 8) = pauVar2;
    return arg1;
}

// ============================================================
// Function: FUN_18003ded0
// Address: 0x18003ded0
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003ded0(int64_t arg1)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.180015170(unaff_RBX);
        fcn.180459c3c(*(undefined8 *)(arg1 + 0x70), 0x60);
        fcn.18003e790(unaff_RBX);
        fcn.180004e40(arg1 + 0x30);
        fcn.180004e40(arg1 + 8);
        fcn.180459c3c(arg1, 0x80);
    }
    return;
}

// ============================================================
// Function: FUN_18003deea
// Address: 0x18003deea
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003ded0(int64_t arg1)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.180015170(unaff_RBX);
        fcn.180459c3c(*(undefined8 *)(arg1 + 0x70), 0x60);
        fcn.18003e790(unaff_RBX);
        fcn.180004e40(arg1 + 0x30);
        fcn.180004e40(arg1 + 8);
        fcn.180459c3c(arg1, 0x80);
    }
    return;
}

// ============================================================
// Function: FUN_18003df33
// Address: 0x18003df33
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003ded0(int64_t arg1)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.180015170(unaff_RBX);
        fcn.180459c3c(*(undefined8 *)(arg1 + 0x70), 0x60);
        fcn.18003e790(unaff_RBX);
        fcn.180004e40(arg1 + 0x30);
        fcn.180004e40(arg1 + 8);
        fcn.180459c3c(arg1, 0x80);
    }
    return;
}

// ============================================================
// Function: FUN_18003e040
// Address: 0x18003e040
// Size: 42 bytes
// ============================================================
void fcn.18003e040(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    func_0x00018003e860(arg1, arg1, *(undefined8 *)(*(int64_t *)arg1 + 8));
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18003e070
// Address: 0x18003e070
// Size: 286 bytes
// ============================================================
int64_t fcn.18003e070(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 *puVar10;
    undefined4 *puVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    int64_t var_58h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar8 = fcn.180459890(0x48);
    *(int64_t *)iVar8 = iVar8;
    *(int64_t *)(iVar8 + 8) = iVar8;
    *(int64_t *)(iVar8 + 0x10) = iVar8;
    *(undefined2 *)(iVar8 + 0x18) = 0x101;
    *(int64_t *)arg1 = iVar8;
    puVar11 = *(undefined4 **)arg2;
    puVar1 = *(undefined4 **)(arg2 + 8);
    do {
        if (puVar11 == puVar1) {
            return arg1;
        }
        puVar9 = (undefined4 *)func_0x00018003f0d0(arg1, &var_78h, iVar8, puVar11);
        uVar4 = *puVar9;
        uVar5 = puVar9[1];
        uVar6 = puVar9[2];
        uVar7 = puVar9[3];
        if (*(char *)(puVar9 + 4) == '\0') {
            if (*(int64_t *)(arg1 + 8) == 0x38e38e38e38e38e) {
                func_0x000180013c00();
                pcVar3 = (code *)swi(3);
                iVar8 = (*pcVar3)();
                return iVar8;
            }
            uVar2 = *(undefined8 *)arg1;
            puVar10 = (undefined8 *)fcn.180459890(0x48);
            *(undefined4 *)(puVar10 + 4) = *puVar11;
            fcn.18000b4d0(puVar10 + 5, puVar11 + 2);
            *puVar10 = uVar2;
            puVar10[1] = uVar2;
            puVar10[2] = uVar2;
            *(undefined2 *)(puVar10 + 3) = 0;
            var_78h._0_4_ = uVar4;
            var_78h._4_4_ = uVar5;
            uStack_70 = uVar6;
            uStack_6c = uVar7;
            func_0x0001800156d0(arg1, &var_78h, puVar10);
        }
        puVar11 = puVar11 + 10;
    } while( true );
}

// ============================================================
// Function: FUN_18003e190
// Address: 0x18003e190
// Size: 301 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h

int64_t fcn.18003e190(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined8 *puVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    int64_t **ppiVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    undefined8 uVar9;
    undefined8 in_R9;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    puVar7 = (undefined8 *)fcn.180459890(0x60);
    *puVar7 = puVar7;
    puVar7[1] = puVar7;
    puVar7[2] = puVar7;
    *(undefined2 *)(puVar7 + 3) = 0x101;
    *(undefined8 **)arg1 = puVar7;
    puVar2 = *(undefined8 **)(*(int64_t *)arg2 + 8);
    if (*(char *)((int64_t)puVar2 + 0x19) == '\0') {
        puVar8 = (undefined8 *)func_0x000180016a70(arg1, puVar7, puVar2 + 4, in_R9, arg1, arg1);
        puVar8[1] = puVar7;
        *(undefined *)(puVar8 + 3) = *(undefined *)(puVar2 + 3);
        uVar9 = func_0x000180015950(arg1, *puVar2, puVar8);
        *puVar8 = uVar9;
        uVar9 = func_0x000180015950(arg1, puVar2[2], puVar8);
        puVar8[2] = uVar9;
        puVar7 = puVar8;
    }
    *(undefined8 **)(*(int64_t *)arg1 + 8) = puVar7;
    *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg2 + 8);
    ppiVar3 = *(int64_t ***)arg1;
    ppiVar4 = (int64_t **)ppiVar3[1];
    if (*(char *)((int64_t)ppiVar4 + 0x19) == '\0') {
        cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
        ppiVar6 = (int64_t **)*ppiVar4;
        while (cVar1 == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar6 + 0x19);
            ppiVar4 = ppiVar6;
            ppiVar6 = (int64_t **)*ppiVar6;
        }
        *ppiVar3 = (int64_t *)ppiVar4;
        iVar5 = *(int64_t *)(*(int64_t *)arg1 + 8);
        cVar1 = *(char *)(*(int64_t *)(iVar5 + 0x10) + 0x19);
        while (cVar1 == '\0') {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            cVar1 = *(char *)(*(int64_t *)(iVar5 + 0x10) + 0x19);
        }
        *(int64_t *)(*(int64_t *)arg1 + 0x10) = iVar5;
    } else {
        *ppiVar3 = (int64_t *)ppiVar3;
        *(int64_t *)(*(int64_t *)arg1 + 0x10) = *(int64_t *)arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003e2c0
// Address: 0x18003e2c0
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18003e2c0(int64_t arg1, int64_t arg2)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    fcn.18003e720(unaff_RBX, in_stack_00000010);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003e300
// Address: 0x18003e300
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18003e300(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    fcn.18003e6a0(in_stack_00000010);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003e340
// Address: 0x18003e340
// Size: 360 bytes
// ============================================================
void fcn.18003e340(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    
    puVar7 = auStack_48;
    puVar5 = auStack_48;
    puVar6 = auStack_48;
    uVar4 = *(uint64_t *)arg1;
    uVar3 = *(int64_t *)(arg1 + 0x10) - uVar4;
    if ((uint64_t)arg3 <= uVar3) {
        uVar3 = *(int64_t *)(arg1 + 8) - uVar4;
        if (uVar3 < (uint64_t)arg3) {
            fcn.180498030(uVar4, arg2, uVar3);
            iVar2 = *(int64_t *)(arg1 + 8);
            fcn.180498030(iVar2, uVar3 + arg2, arg3 - uVar3);
            *(uint64_t *)(arg1 + 8) = (arg3 - uVar3) + iVar2;
            return;
        }
        goto code_r0x00018003e43b;
    }
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    if ((uVar3 <= 0x7fffffffffffffff - (uVar3 >> 1)) && (uVar8 = uVar3 + (uVar3 >> 1), uVar8 < (uint64_t)arg3)) {
        uVar8 = arg3;
    }
    if (uVar4 == 0) {
code_r0x00018003e3e0:
        if (uVar8 == 0) {
            uVar4 = 0;
            puVar6 = auStack_48;
        } else {
            if (0xfff < uVar8) {
                if (uVar8 + 0x27 <= uVar8) {
                    fcn.180004720();
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                iVar2 = fcn.180459890();
                if (iVar2 == 0) goto code_r0x00018003e409;
                goto code_r0x00018003e410;
            }
            uVar4 = fcn.180459890(uVar8);
        }
    } else {
        uVar3 = *(int64_t *)(arg1 + 0x10) - uVar4;
        if (uVar3 < 0x1000) {
code_r0x00018003e3c4:
            fcn.180459c3c(uVar4, uVar3);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            goto code_r0x00018003e3e0;
        }
        if ((uVar4 - *(uint64_t *)(uVar4 - 8)) - 8 < 0x20) {
            uVar3 = uVar3 + 0x27;
            uVar4 = *(uint64_t *)(uVar4 - 8);
            goto code_r0x00018003e3c4;
        }
code_r0x00018003e409:
        pcVar1 = (code *)swi(0x29);
        iVar2 = (*pcVar1)(5);
        puVar5 = auStack_40;
code_r0x00018003e410:
        uVar4 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar2;
        puVar6 = puVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar8;
    puVar7 = puVar6;
code_r0x00018003e43b:
    *(undefined8 *)(puVar7 + -8) = 0x18003e446;
    fcn.180498030(uVar4, arg2, arg3);
    *(uint64_t *)(arg1 + 8) = uVar4 + arg3;
    return;
}

// ============================================================
// Function: FUN_18003e4b0
// Address: 0x18003e4b0
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18003e4b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = *(undefined *)(*(int64_t *)arg2 + 8);
    *(undefined *)(*(int64_t *)arg2 + 8) = 0;
    iVar4 = *(int64_t *)arg2;
    cVar6 = func_0x000180079c00(*(int64_t *)(iVar4 + 0x38), *(int64_t *)(iVar4 + 0x40) - *(int64_t *)(iVar4 + 0x38), 
                                iVar4 + 0x270, iVar4 + 0x268, iVar4 + 0x26c);
    if (cVar6 != '\0') {
        *(undefined *)(*(int64_t *)arg2 + 8) = uVar3;
    }
    piVar5 = *(int64_t **)(arg2 + 8);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar7 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar7 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    if ((arg2 != 0) && (iVar7 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg2), iVar7 == 0)) {
        uVar8 = (*(code *)0x699ff6)();
        uVar8 = fcn.18046b63c(uVar8);
        puVar9 = (undefined4 *)fcn.18046b77c();
        *puVar9 = uVar8;
    }
    return;
}

// ============================================================
// Function: FUN_18003e560
// Address: 0x18003e560
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18003e560(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined uVar4;
    int64_t *piVar5;
    char cVar6;
    int64_t **arg2_00;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg2 + 0x38) != 0) {
        arg2_00 = (int64_t **)(arg2 + 0x28);
        if (*(uint64_t *)(arg2 + 0x40) < 0x10) {
            iVar7 = *(int64_t *)(arg2 + 0x38) + (int64_t)arg2_00;
        } else {
            iVar7 = (int64_t)*arg2_00 + *(int64_t *)(arg2 + 0x38);
            arg2_00 = (int64_t **)*arg2_00;
        }
        fcn.18003e340(*(int64_t *)arg2 + 0x38, (int64_t)arg2_00, iVar7 - (int64_t)arg2_00);
        uVar4 = *(undefined *)(*(int64_t *)arg2 + 8);
        *(undefined *)(*(int64_t *)arg2 + 8) = 0;
        iVar7 = *(int64_t *)arg2;
        cVar6 = func_0x000180079c00(*(int64_t *)(iVar7 + 0x38), *(int64_t *)(iVar7 + 0x40) - *(int64_t *)(iVar7 + 0x38)
                                    , iVar7 + 0x270, iVar7 + 0x268, iVar7 + 0x26c);
        if (cVar6 != '\0') {
            *(undefined *)(*(int64_t *)arg2 + 8) = uVar4;
            *(undefined *)(*(int64_t *)arg2 + 0x278) = 1;
        }
    }
    if (arg2 != 0) {
        fcn.18003c510(arg2 + 0x10);
        piVar5 = *(int64_t **)(arg2 + 8);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        fcn.180459c3c(arg2, 0x148);
    }
    return;
}

// ============================================================
// Function: FUN_18003e660
// Address: 0x18003e660
// Size: 57 bytes
// ============================================================
void fcn.18003e660(int64_t arg1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    if (*(int64_t *)(arg1 + 8) != 0) {
        func_0x00018000d070(*(int64_t *)(arg1 + 8) + 0x10);
    }
    iVar1 = *(int64_t *)(arg1 + 8);
    if (iVar1 == 0) {
        return;
    }
    if ((iVar1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar2 = (undefined4 *)fcn.18046b77c();
        *puVar2 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18003e6a0
// Address: 0x18003e6a0
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e6a0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.18003c510(arg1 + 0x10);
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x148);
    }
    return;
}

// ============================================================
// Function: FUN_18003e6b2
// Address: 0x18003e6b2
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e6a0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.18003c510(arg1 + 0x10);
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x148);
    }
    return;
}

// ============================================================
// Function: FUN_18003e6c5
// Address: 0x18003e6c5
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e6a0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.18003c510(arg1 + 0x10);
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x148);
    }
    return;
}

// ============================================================
// Function: FUN_18003e6fb
// Address: 0x18003e6fb
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e6a0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.18003c510(arg1 + 0x10);
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x148);
    }
    return;
}

// ============================================================
// Function: FUN_18003e70d
// Address: 0x18003e70d
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e6a0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        fcn.18003c510(arg1 + 0x10);
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x148);
    }
    return;
}

// ============================================================
// Function: FUN_18003e720
// Address: 0x18003e720
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e720(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_18003e72e
// Address: 0x18003e72e
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e720(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_18003e73c
// Address: 0x18003e73c
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e720(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_18003e772
// Address: 0x18003e772
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e720(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_18003e784
// Address: 0x18003e784
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003e720(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_18003e790
// Address: 0x18003e790
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e790(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x98) {
            fcn.180004e40(iVar3 + 0x68);
            fcn.180004e40(iVar3 + 0x40);
            fcn.180004e40(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18003e840;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18003e7a9
// Address: 0x18003e7a9
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e790(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x98) {
            fcn.180004e40(iVar3 + 0x68);
            fcn.180004e40(iVar3 + 0x40);
            fcn.180004e40(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18003e840;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18003e817
// Address: 0x18003e817
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e790(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x98) {
            fcn.180004e40(iVar3 + 0x68);
            fcn.180004e40(iVar3 + 0x40);
            fcn.180004e40(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18003e840;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

