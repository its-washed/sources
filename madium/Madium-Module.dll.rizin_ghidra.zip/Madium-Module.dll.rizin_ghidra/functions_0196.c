// Chunk 196 - 50 functions

// ============================================================
// Function: FUN_180260800
// Address: 0x180260800
// Size: 272 bytes
// ============================================================
int64_t fcn.180260800(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    int64_t *in_RDX;
    int64_t iVar8;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180260818;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    iVar8 = (int64_t)in_R8D;
    iVar6 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180260833;
    uVar5 = func_0x000180260490(0, 0, iVar6, iVar8);
    if (uVar5 != 0) {
        if ((in_RCX == (int64_t *)0x0) || (iVar6 = *in_RCX, iVar6 == 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180260851;
            iVar6 = func_0x000180228860();
            if (iVar6 == 0) {
                return 0;
            }
            *(undefined4 *)(iVar6 + 4) = 2;
        }
        if (uVar5 < 0x80000000) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026087a;
            iVar3 = func_0x0001802968f0(iVar6, 0, uVar5 & 0xffffffff);
            if (iVar3 != 0) {
                iVar1 = *in_RDX;
                uVar2 = *(undefined8 *)(iVar6 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180260892;
                func_0x000180260490(uVar2, (int64_t)&arg_38h + iVar4, iVar1, iVar8);
                uVar7 = *(uint32_t *)(iVar6 + 4) & 0xfffffeff;
                if (*(int32_t *)((int64_t)&arg_38h + iVar4) != 0) {
                    uVar7 = *(uint32_t *)(iVar6 + 4) | 0x100;
                }
                *(uint32_t *)(iVar6 + 4) = uVar7;
                *in_RDX = *in_RDX + iVar8;
                if (in_RCX != (int64_t *)0x0) {
                    *in_RCX = iVar6;
                    return iVar6;
                }
                return iVar6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802608bf;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802608d7;
        func_0x0001802295a0(0x1804e6b10, 0x140, 0x1804e6b60);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802608e9;
        func_0x0001802296d0(0xd, 0x8000d, 0);
        if ((in_RCX == (int64_t *)0x0) || (*in_RCX != iVar6)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802608fb;
            func_0x000180228780(iVar6);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180260910
// Address: 0x180260910
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180260910(uint64_t *param_1, undefined8 param_2, undefined8 *param_3, int32_t param_4)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180260921;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000000 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar2);
    uVar1 = *param_3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026094e;
    uVar3 = func_0x000180260490(0, 0, uVar1, (int64_t)param_4);
    if (uVar3 != 0) {
        if (uVar3 < 9) {
            uVar1 = *param_3;
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802609a2;
            func_0x000180260490((int64_t)&var_8h + iVar2, param_2, uVar1, (int64_t)param_4);
            uVar4 = 0;
            uVar5 = uVar4;
            if (uVar3 != 0) {
                do {
                    uVar6 = uVar5 + 1;
                    uVar4 = uVar4 << 8 | (uint64_t)*(uint8_t *)((int64_t)&var_8h + uVar5 + iVar2);
                    uVar5 = uVar6;
                } while (uVar6 < uVar3);
            }
            *param_1 = uVar4;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180260961;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180260979;
            func_0x0001802295a0(0x1804e6b10, 0x281, 0x1804e6bd8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026098b;
            func_0x0001802296d0(0xd, 0xdf, 0);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802609d9;
    func_0x000180459870(*(uint64_t *)(&stack0x00000000 + iVar2) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802609f0
// Address: 0x1802609f0
// Size: 150 bytes
// ============================================================
uint64_t fcn.1802609f0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802609fc;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_RDX == (undefined8 *)0x0) {
        uVar5 = 0;
    } else {
        uVar5 = *in_RDX;
    }
    uVar1 = in_RCX[1];
    iVar2 = *in_RCX;
    uVar3 = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = uVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180260a2f;
    uVar6 = func_0x000180260680(uVar3, (int64_t)iVar2, uVar1 & 0x100, (int64_t)&arg_28h + iVar4);
    if (0x7fffffff < uVar6) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180260a3f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180260a57;
        func_0x0001802295a0(0x1804e6b10, 0xd5, 0x1804e6b28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180260a69;
        func_0x0001802296d0(0xd, 0xdf, 0);
        return 0;
    }
    if (in_RDX != (undefined8 *)0x0) {
        *in_RDX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    return uVar6 & 0xffffffff;
}

// ============================================================
// Function: FUN_180260a90
// Address: 0x180260a90
// Size: 99 bytes
// ============================================================
void fcn.180260a90(int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined *puVar3;
    uint64_t in_RDX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180260a9a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(uint64_t *)((int64_t)&arg_30h + iVar1) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_RCX;
    iVar2 = 8;
    puVar3 = (undefined *)((int64_t)&arg_30h + iVar1);
    do {
        puVar3 = puVar3 + -1;
        iVar2 = iVar2 + -1;
        *puVar3 = (char)in_RDX;
        in_RDX = in_RDX >> 8;
    } while (in_RDX != 0);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180260ae1;
    fcn.180260680(puVar3, 8 - iVar2, in_R8, (int64_t)&var_20h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180260aee;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar1) ^ (int64_t)&stack0x00000000 + iVar1);
    return;
}

// ============================================================
// Function: FUN_180260b00
// Address: 0x180260b00
// Size: 22 bytes
// ============================================================
uint64_t fcn.180260b00(int64_t arg_30h, int64_t arg_50h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180296540;
    iVar5 = fcn.18045a350();
    uVar3 = *in_RCX - *in_RDX;
    if (uVar3 == 0) {
        if (*in_RCX != 0) {
            uVar1 = *(undefined8 *)(in_RDX + 2);
            uVar2 = *(undefined8 *)(in_RCX + 2);
            *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar5)) = 0x180296565;
            uVar6 = func_0x000180497f30(uVar2, uVar1);
            if ((int32_t)uVar6 != 0) {
                return uVar6;
            }
        }
        uVar3 = in_RCX[1] - in_RDX[1];
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_180260b20
// Address: 0x180260b20
// Size: 22 bytes
// ============================================================
undefined8 fcn.180260b20(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4) = 0x1802968fe;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_R8D < 0) {
        if (in_RDX == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180296919;
        uVar6 = func_0x000180498cd0(in_RDX);
    } else {
        uVar6 = (uint64_t)in_R8D;
    }
    if (uVar6 < 0x7fffffff) {
        iVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RDI;
        piVar1 = (int64_t *)(in_RCX + 2);
        *(undefined8 *)((int64_t)&arg_58h + iVar5 + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar4) = unaff_R15;
        if (((uint64_t)(int64_t)iVar2 <= uVar6) || (iVar7 = *piVar1, iVar7 == 0)) {
            iVar3 = *piVar1;
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x1802969a2;
            iVar7 = func_0x0001802249c0(iVar3, uVar6 + 1, 0x1804ed9c0, 0x13a);
            *piVar1 = iVar7;
            if (iVar7 == 0) {
                *piVar1 = iVar3;
                return 0;
            }
        }
        *in_RCX = (int32_t)uVar6;
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x1802969c4;
            func_0x000180498030(iVar7, in_RDX, uVar6);
            *(undefined *)(uVar6 + *piVar1) = 0;
        }
        return 1;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18029692f;
    func_0x000180229480();
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180296947;
    func_0x0001802295a0(0x1804ed9c0, 0x131, 0x1804ed9d8);
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180296959;
    func_0x0001802296d0(0xd, 0xdf, 0);
    return 0;
}

// ============================================================
// Function: FUN_180260b40
// Address: 0x180260b40
// Size: 63 bytes
// ============================================================
undefined8 fcn.180260b40(int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180260b4c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180260b6e;
    iVar1 = fcn.180260bc0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (0 < iVar1) {
        uVar3 = *(undefined8 *)((int64_t)&arg_40h + iVar2);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180260b80
// Address: 0x180260b80
// Size: 63 bytes
// ============================================================
undefined8 fcn.180260b80(int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_R8;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180260b8c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = in_R8;
    uVar3 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180260bae;
    iVar1 = fcn.180260bc0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (0 < iVar1) {
        uVar3 = *(undefined8 *)((int64_t)&arg_50h + iVar2);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180260bc0
// Address: 0x180260bc0
// Size: 804 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180260bc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    undefined uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar7;
    uint32_t uVar8;
    code *pcVar9;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R13;
    code *pcVar10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180260bd7;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    pcVar9 = (code *)0x0;
    iVar7 = *(int64_t *)(in_RDX + 0x18);
    if ((iVar7 == 0) || (pcVar10 = *(code **)(iVar7 + 0x18), *(code **)(iVar7 + 0x18) == (code *)0x0)) {
        pcVar10 = pcVar9;
    }
    uVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R13;
    iVar4 = (int32_t)in_R8;
    // switch table (7 cases) at 0x180260ec8
    switch(uVar1) {
    case 0:
        iVar7 = *(int64_t *)(in_RDX + 8);
        if (iVar7 == 0) goto code_r0x000180260c78;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260c70;
        iVar4 = func_0x000180261180(in_RCX, iVar7, in_R9, *(undefined8 *)((int64_t)&arg_48h + iVar5));
        break;
    case 1:
    case 6:
        if (pcVar10 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260d51;
            iVar3 = (*pcVar10)(0, in_RCX, in_RDX, 0);
            if (iVar3 == 0) goto code_r0x000180260e4b;
            if (iVar3 == 2) {
                return 1;
            }
        }
        iVar3 = *(int32_t *)(in_RDX + 0x20);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260d8c;
            iVar7 = func_0x000180224d60((int64_t)iVar3, 0x1804e6bf0, 0x88);
            *in_RCX = iVar7;
            if (iVar7 == 0) {
                return 0;
            }
        } else {
            iVar7 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260d78;
            func_0x0001804986e0(iVar7, 0, (int64_t)iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260da5;
        iVar3 = func_0x0001802d40b0(in_RCX, 0, in_RDX);
        if (iVar3 < 0) {
            if (iVar4 == 0) {
                iVar7 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260dc7;
                func_0x000180224990(iVar7, 0x1804e6bf0, 0x8f);
                *in_RCX = 0;
            }
            goto code_r0x000180260e8f;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260dda;
        func_0x0001802d4230(in_RCX, in_RDX);
        iVar7 = *(int64_t *)(in_RDX + 8);
        if (0 < *(int32_t *)(in_RDX + 0x10)) {
            uVar2 = *(undefined8 *)((int64_t)&arg_48h + iVar5);
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260dfb;
                uVar6 = func_0x0001802d4420(in_RCX, iVar7);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e0c;
                iVar4 = func_0x000180261180(uVar6, iVar7, in_R9, uVar2);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e8f;
                    func_0x0001802612e0(in_RCX, in_RDX, in_R8 & 0xffffffff);
                    goto code_r0x000180260e8f;
                }
                iVar7 = iVar7 + 0x20;
                uVar8 = (int32_t)pcVar9 + 1;
                pcVar9 = (code *)(uint64_t)uVar8;
            } while ((int32_t)uVar8 < *(int32_t *)(in_RDX + 0x10));
        }
        if (pcVar10 == (code *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e35;
        iVar4 = (*pcVar10)(1, in_RCX, in_RDX, 0);
        goto joined_r0x000180260d33;
    case 2:
        if (pcVar10 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260cc4;
            iVar3 = (*pcVar10)(0, in_RCX, in_RDX, 0);
            if (iVar3 == 0) goto code_r0x000180260e4b;
            if (iVar3 == 2) {
                return 1;
            }
        }
        iVar3 = *(int32_t *)(in_RDX + 0x20);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260cfb;
            iVar7 = func_0x000180224d60((int64_t)iVar3, 0x1804e6bf0, 0x72);
            *in_RCX = iVar7;
            if (iVar7 == 0) {
                return 0;
            }
        } else {
            iVar7 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260ce7;
            func_0x0001804986e0(iVar7, 0, (int64_t)iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260d17;
        func_0x0001802d4430(in_RCX, 0xffffffff, in_RDX);
        if (pcVar10 == (code *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260d31;
        iVar4 = (*pcVar10)(1, in_RCX, in_RDX, 0);
joined_r0x000180260d33:
        if (iVar4 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e4b;
        func_0x0001802612e0(in_RCX, in_RDX, in_R8 & 0xffffffff);
code_r0x000180260e4b:
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e50;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e68;
        func_0x0001802295a0(0x1804e6bf0, 0xa9, 0x1804e6c08);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e7a;
        func_0x0001802296d0(0xd, 100, 0);
        return 0;
    default:
        goto code_r0x000180260c8a;
    case 4:
        if (iVar7 == 0) {
            return 1;
        }
        pcVar9 = *(code **)(iVar7 + 0x38);
        if (pcVar9 == (code *)0x0) {
            pcVar9 = *(code **)(iVar7 + 8);
            if (pcVar9 == (code *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260c55;
            iVar4 = (*pcVar9)(in_RCX, in_RDX);
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260c42;
            iVar4 = (*pcVar9)(in_RCX, in_RDX, in_R9, *(undefined8 *)((int64_t)&arg_48h + iVar5));
        }
        break;
    case 5:
code_r0x000180260c78:
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260c7d;
        iVar4 = func_0x000180260ef0(in_RCX, in_RDX, in_R8 & 0xffffffff);
    }
    if (iVar4 == 0) {
code_r0x000180260e8f:
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260e94;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260eac;
        func_0x0001802295a0(0x1804e6bf0, 0xa3, 0x1804e6c08);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180260ebe;
        func_0x0001802296d0(0xd, 0x8000d, 0);
        return 0;
    }
code_r0x000180260c8a:
    return 1;
}

// ============================================================
// Function: FUN_180260ef0
// Address: 0x180260ef0
// Size: 426 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180260ef0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined (*pauVar6) [16];
    undefined (**in_RCX) [16];
    char *in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180260f05;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == (char *)0x0) {
        return 0;
    }
    iVar1 = *(int64_t *)(in_RDX + 0x18);
    if (iVar1 != 0) {
        if (in_R8D == 0) {
            if (*(code **)(iVar1 + 0x10) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180260f61. Too many branches
    // WARNING: Treating indirect jump as call
                uVar5 = (**(code **)(iVar1 + 0x10))();
                return uVar5;
            }
        } else {
            pcVar2 = *(code **)(iVar1 + 0x20);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180260f34;
                (*pcVar2)();
                return 1;
            }
        }
    }
    if (*in_RDX == '\x05') {
        iVar3 = -1;
    } else {
        iVar3 = *(int32_t *)(in_RDX + 4);
        if (iVar3 == -4) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026105d;
            pauVar6 = (undefined (*) [16])
                      fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                    *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            if (pauVar6 == (undefined (*) [16])0x0) {
                return 0;
            }
            *(undefined8 *)(*pauVar6 + 8) = 0;
            *(undefined4 *)*pauVar6 = 0xffffffff;
            *in_RCX = pauVar6;
            goto code_r0x00018026106f;
        }
        if (iVar3 == 1) {
            *(undefined4 *)in_RCX = *(undefined4 *)(in_RDX + 0x20);
            return 1;
        }
        if (iVar3 == 5) {
            *in_RCX = (undefined (*) [16])0x1;
            return 1;
        }
        if (iVar3 == 6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180260ff8;
            pauVar6 = (undefined (*) [16])
                      fcn.18022cba0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                    *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                    *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000050 + iVar4));
            *in_RCX = pauVar6;
            return 1;
        }
    }
    if (in_R8D == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180260fbc;
        pauVar6 = (undefined (*) [16])fcn.180296a40(iVar3);
        *in_RCX = pauVar6;
    } else {
        pauVar6 = *in_RCX;
        *pauVar6 = ZEXT816(0);
        *(undefined8 *)pauVar6[1] = 0;
        *(int32_t *)(*pauVar6 + 4) = iVar3;
        *(undefined4 *)pauVar6[1] = 0x80;
    }
    if ((*in_RDX == '\x05') && (pauVar6 != (undefined (*) [16])0x0)) {
        *(uint32_t *)pauVar6[1] = *(uint32_t *)pauVar6[1] | 0x40;
        return (uint64_t)(*in_RCX != (undefined (*) [16])0x0);
    }
code_r0x00018026106f:
    return (uint64_t)(*in_RCX != (undefined (*) [16])0x0);
}

// ============================================================
// Function: FUN_1802610a0
// Address: 0x1802610a0
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1802610a0(int64_t arg_28h)
{
    uint32_t uVar1;
    int64_t iVar2;
    char *pcVar3;
    undefined8 *in_RCX;
    uint32_t *in_RDX;
    code *UNRECOVERED_JUMPTABLE;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802610b0;
    iVar2 = fcn.18045a350();
    uVar1 = *in_RDX;
joined_r0x0001802610bc:
    if ((uVar1 & 0x306) != 0) {
code_r0x0001802610f0:
        *in_RCX = 0;
code_r0x0001802610f7:
        return;
    }
    UNRECOVERED_JUMPTABLE = *(code **)(in_RDX + 6);
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1802610c8;
    pcVar3 = (char *)(*UNRECOVERED_JUMPTABLE)();
    // switch table (7 cases) at 0x180261158
    switch(*pcVar3) {
    case '\0':
        in_RDX = *(uint32_t **)(pcVar3 + 8);
        if (in_RDX == (uint32_t *)0x0) goto code_r0x000180261102;
        uVar1 = *in_RDX;
        goto joined_r0x0001802610bc;
    case '\x01':
    case '\x02':
    case '\x06':
        goto code_r0x0001802610f0;
    default:
        goto code_r0x0001802610f7;
    case '\x04':
        if (*(int64_t *)(pcVar3 + 0x18) == 0) goto code_r0x0001802610f0;
        UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(pcVar3 + 0x18) + 0x18);
        break;
    case '\x05':
code_r0x000180261102:
        if (pcVar3 == (char *)0x0) goto code_r0x0001802610f0;
        if (*(int64_t *)(pcVar3 + 0x18) == 0) {
            if ((*pcVar3 != '\x05') && (*(int32_t *)(pcVar3 + 4) == 1)) {
                *(undefined4 *)in_RCX = *(undefined4 *)(pcVar3 + 0x20);
                return;
            }
            goto code_r0x0001802610f0;
        }
        UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(pcVar3 + 0x18) + 0x20);
    }
    if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180261129. Too many branches
    // WARNING: Treating indirect jump as call
        (*UNRECOVERED_JUMPTABLE)(in_RCX, pcVar3);
        return;
    }
    goto code_r0x0001802610f0;
}

// ============================================================
// Function: FUN_180261180
// Address: 0x180261180
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180261180(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *in_RCX;
    uint32_t *in_RDX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026119a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar2 = *(code **)(in_RDX + 6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802611ac;
    (*pcVar2)();
    uVar1 = *in_RDX;
    if ((uVar1 & 0x1000) != 0) {
        *(int64_t **)((int64_t)&arg_40h + iVar3) = in_RCX;
        in_RCX = (int64_t *)((int64_t)&arg_40h + iVar3);
    }
    if ((uVar1 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802611d4;
        fcn.1802610a0(*(int64_t *)((int64_t)&var_18h + iVar3));
        return 1;
    }
    if ((uVar1 & 0x300) == 0) {
        if ((uVar1 & 6) == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar3) = in_R9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180261244;
            uVar5 = fcn.180260bc0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
            return uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802611f9;
        iVar4 = func_0x000180221f20();
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180261203;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026121b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026122d;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
    } else {
        iVar4 = 0;
    }
    *in_RCX = iVar4;
    return 1;
}

// ============================================================
// Function: FUN_180261260
// Address: 0x180261260
// Size: 34 bytes
// ============================================================
void fcn.180261260(void)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026126a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026127d;
    fcn.180260bc0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180261290
// Address: 0x180261290
// Size: 25 bytes
// ============================================================
void fcn.180261290(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t iVar9;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = 0;
    if (in_RCX == (int64_t *)0x0) {
        return;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x18) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3) = 0x1802612f7;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar9 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*in_RCX == 0)) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = unaff_RBP;
    if ((iVar9 == 0) || (pcVar7 = *(code **)(iVar9 + 0x18), pcVar7 == (code *)0x0)) {
        pcVar7 = (code *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_RBX;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180261361;
            func_0x0001802616b0(in_RCX);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180261374;
        func_0x000180261550(in_RCX, in_RDX, iVar8);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(in_RCX, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar7 != (code *)0x0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180261468;
                iVar2 = (*pcVar7)(2, in_RCX, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180261481;
            func_0x0001802d41c0(in_RCX, in_RDX);
            iVar2 = 0;
            iVar9 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)((int64_t)&arg_68h + iVar4 + iVar3) = unaff_R15;
                do {
                    iVar5 = *in_RCX;
                    iVar9 = iVar9 + -0x20;
                    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802614b2;
                    iVar5 = func_0x0001802d3f90(iVar5, iVar9, 0);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802614c5;
                        uVar6 = func_0x0001802d4420(in_RCX, iVar5);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar6, iVar5);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar7 != (code *)0x0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802614f6;
                (*pcVar7)(3, in_RCX, in_RDX, 0);
            }
            if (iVar8 != 0) {
                return;
            }
            uVar6 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar7 != (code *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar7)(2, in_RCX, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(in_RCX, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar9 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802613c1;
            uVar6 = func_0x0001802d4420(in_RCX, iVar9);
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar6, iVar9);
        }
        if (pcVar7 != (code *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x1802613e1;
            (*pcVar7)(3, in_RCX, in_RDX, 0);
        }
        if (iVar8 != 0) {
            return;
        }
        uVar6 = 0x4b;
code_r0x000180261501:
        iVar9 = *in_RCX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180261510;
        func_0x000180224990(iVar9, 0x1804e6c38, uVar6);
code_r0x000180261510:
        *in_RCX = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar9 == 0) {
            return;
        }
        pcVar7 = *(code **)(iVar9 + 0x10);
        if (pcVar7 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x180261413;
        (*pcVar7)(in_RCX, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1802612b0
// Address: 0x1802612b0
// Size: 36 bytes
// ============================================================
void fcn.1802612b0(int64_t arg1, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_8h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802612bf;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802612e0
// Address: 0x1802612e0
// Size: 57 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180261319
// Address: 0x180261319
// Size: 37 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18026133e
// Address: 0x18026133e
// Size: 310 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180261474
// Address: 0x180261474
// Size: 34 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180261496
// Address: 0x180261496
// Size: 70 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1802614dc
// Address: 0x1802614dc
// Size: 10 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1802614e6
// Address: 0x1802614e6
// Size: 54 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18026151c
// Address: 0x18026151c
// Size: 5 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180261521
// Address: 0x180261521
// Size: 39 bytes
// ============================================================
void fcn.1802612e0(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar6;
    uint64_t in_R8;
    int32_t iVar7;
    undefined8 unaff_R14;
    int64_t iVar8;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    if (arg1 == 0) {
        return;
    }
    uStack_20 = 0x1802612f7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    cVar1 = *in_RDX;
    if ((cVar1 != '\0') && (*(int64_t *)arg1 == 0)) {
        return;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    if ((iVar8 == 0) || (pcVar6 = *(code **)(iVar8 + 0x18), pcVar6 == (code *)0x0)) {
        pcVar6 = (code *)0x0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RBX;
    iVar7 = (int32_t)in_R8;
    // switch table (7 cases) at 0x18026152c
    switch(cVar1) {
    case '\0':
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261361;
            func_0x0001802616b0(arg1);
            return;
        }
    case '\x05':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261374;
        func_0x000180261550(arg1, in_RDX, in_R8 & 0xffffffff);
        break;
    case '\x01':
    case '\x06':
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261428;
        iVar2 = func_0x0001802d40b0(arg1, 0xffffffff, in_RDX);
        if (iVar2 == 0) {
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261468;
                iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
                if (iVar2 == 2) {
                    return;
                }
            }
            *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261481;
            func_0x0001802d41c0(arg1, in_RDX);
            iVar2 = 0;
            iVar8 = (int64_t)*(int32_t *)(in_RDX + 0x10) * 0x20 + *(int64_t *)(in_RDX + 8);
            if (0 < *(int32_t *)(in_RDX + 0x10)) {
                *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_R15;
                do {
                    iVar4 = *(int64_t *)arg1;
                    iVar8 = iVar8 + -0x20;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614b2;
                    iVar4 = func_0x0001802d3f90(iVar4, iVar8, 0);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614c5;
                        uVar5 = func_0x0001802d4420(arg1, iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614d0;
                        func_0x0001802616b0(uVar5, iVar4);
                    }
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(in_RDX + 0x10));
            }
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802614f6;
                (*pcVar6)(3, arg1, in_RDX, 0);
            }
            if (iVar7 != 0) {
                return;
            }
            uVar5 = 0x77;
            goto code_r0x000180261501;
        }
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026144e;
            func_0x00018027bb50(0x1804e6c50, 0x1804e6c38, 0x5a);
        }
        goto code_r0x000180261510;
    case '\x02':
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18026138e;
            iVar2 = (*pcVar6)(2, arg1, in_RDX, 0);
            if (iVar2 == 2) {
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613a2;
        iVar2 = func_0x0001802d4410(arg1, in_RDX);
        if ((-1 < iVar2) && (iVar2 < *(int32_t *)(in_RDX + 0x10))) {
            iVar8 = (int64_t)iVar2 * 0x20 + *(int64_t *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613c1;
            uVar5 = func_0x0001802d4420(arg1, iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613cc;
            func_0x0001802616b0(uVar5, iVar8);
        }
        if (pcVar6 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802613e1;
            (*pcVar6)(3, arg1, in_RDX, 0);
        }
        if (iVar7 != 0) {
            return;
        }
        uVar5 = 0x4b;
code_r0x000180261501:
        iVar8 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261510;
        func_0x000180224990(iVar8, 0x1804e6c38, uVar5);
code_r0x000180261510:
        *(int64_t *)arg1 = 0;
        break;
    default:
        break;
    case '\x04':
        if (iVar8 == 0) {
            return;
        }
        pcVar6 = *(code **)(iVar8 + 0x10);
        if (pcVar6 == (code *)0x0) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180261413;
        (*pcVar6)(arg1, in_RDX);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180261550
// Address: 0x180261550
// Size: 337 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180261550(int64_t arg_28h)
{
    int64_t iVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t **in_RCX;
    char *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180261560;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == (char *)0x0) {
        iVar4 = **in_RCX;
        in_RCX = (int32_t **)(*in_RCX + 2);
    } else {
        iVar1 = *(int64_t *)(in_RDX + 0x18);
        if (iVar1 != 0) {
            if ((int32_t)in_R8 == 0) {
                if (*(code **)(iVar1 + 0x18) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x0001802615a5. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(iVar1 + 0x18))();
                    return;
                }
            } else if (*(code **)(iVar1 + 0x20) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018026158f. Too many branches
    // WARNING: Treating indirect jump as call
                (**(code **)(iVar1 + 0x20))();
                return;
            }
        }
        if (*in_RDX == '\x05') {
            if (*in_RCX == (int32_t *)0x0) {
                return;
            }
            piVar2 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802615c5;
            func_0x000180296e20(piVar2, in_R8 & 0xffffffff);
            *in_RCX = (int32_t *)0x0;
            return;
        }
        iVar4 = *(int32_t *)(in_RDX + 4);
        if (iVar4 == 1) goto code_r0x0001802615f4;
    }
    if (*in_RCX == (int32_t *)0x0) {
        return;
    }
code_r0x0001802615f4:
    if (iVar4 == -4) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026167a;
        fcn.180261550(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
        piVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026168f;
        func_0x000180224990(piVar2, 0x1804e6c38, 0xcc);
    } else {
        if (iVar4 == 1) {
            if (in_RDX != (char *)0x0) {
                *(undefined4 *)in_RCX = *(undefined4 *)(in_RDX + 0x20);
                return;
            }
            *(undefined4 *)in_RCX = 0xffffffff;
            return;
        }
        if (iVar4 != 5) {
            piVar2 = *in_RCX;
            if (iVar4 != 6) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026161a;
                func_0x000180296e20(piVar2, in_R8 & 0xffffffff);
                *in_RCX = (int32_t *)0x0;
                return;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180261634;
            func_0x00018027c100(piVar2);
            *in_RCX = (int32_t *)0x0;
            return;
        }
    }
    *in_RCX = (int32_t *)0x0;
    return;
}

// ============================================================
// Function: FUN_1802616b0
// Address: 0x1802616b0
// Size: 50 bytes
// ============================================================
void fcn.1802616b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 *in_RCX;
    uint32_t *in_RDX;
    int32_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802616bf;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *in_RDX;
    if ((uVar1 & 0x1000) != 0) {
        *(undefined8 **)((int64_t)&arg_30h + iVar5) = in_RCX;
        in_RCX = (undefined8 *)((int64_t)&arg_30h + iVar5);
    }
    if ((uVar1 & 6) != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        iVar7 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
        uVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802616f9;
        iVar4 = func_0x000180222010(uVar2);
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026170a;
                uVar6 = func_0x000180222340(uVar2, iVar7);
                *(undefined8 *)((int64_t)&arg_38h + iVar5) = uVar6;
                pcVar3 = *(code **)(in_RDX + 6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261713;
                (*pcVar3)();
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261723;
                fcn.1802612e0((int64_t)&arg_38h + iVar5, *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026172d;
                iVar4 = func_0x000180222010(uVar2);
            } while (iVar7 < iVar4);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261739;
        func_0x000180221d50(uVar2);
        *in_RCX = 0;
        return;
    }
    pcVar3 = *(code **)(in_RDX + 6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261756;
    (*pcVar3)();
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261764;
    fcn.1802612e0((int64_t)in_RCX, *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5), *(int64_t *)(&stack0x00000048 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1802616e2
// Address: 0x1802616e2
// Size: 113 bytes
// ============================================================
void fcn.1802616b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 *in_RCX;
    uint32_t *in_RDX;
    int32_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802616bf;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *in_RDX;
    if ((uVar1 & 0x1000) != 0) {
        *(undefined8 **)((int64_t)&arg_30h + iVar5) = in_RCX;
        in_RCX = (undefined8 *)((int64_t)&arg_30h + iVar5);
    }
    if ((uVar1 & 6) != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        iVar7 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
        uVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802616f9;
        iVar4 = func_0x000180222010(uVar2);
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026170a;
                uVar6 = func_0x000180222340(uVar2, iVar7);
                *(undefined8 *)((int64_t)&arg_38h + iVar5) = uVar6;
                pcVar3 = *(code **)(in_RDX + 6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261713;
                (*pcVar3)();
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261723;
                fcn.1802612e0((int64_t)&arg_38h + iVar5, *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026172d;
                iVar4 = func_0x000180222010(uVar2);
            } while (iVar7 < iVar4);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261739;
        func_0x000180221d50(uVar2);
        *in_RCX = 0;
        return;
    }
    pcVar3 = *(code **)(in_RDX + 6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261756;
    (*pcVar3)();
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261764;
    fcn.1802612e0((int64_t)in_RCX, *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5), *(int64_t *)(&stack0x00000048 + iVar5));
    return;
}

// ============================================================
// Function: FUN_180261753
// Address: 0x180261753
// Size: 26 bytes
// ============================================================
void fcn.1802616b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 *in_RCX;
    uint32_t *in_RDX;
    int32_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802616bf;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *in_RDX;
    if ((uVar1 & 0x1000) != 0) {
        *(undefined8 **)((int64_t)&arg_30h + iVar5) = in_RCX;
        in_RCX = (undefined8 *)((int64_t)&arg_30h + iVar5);
    }
    if ((uVar1 & 6) != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        iVar7 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
        uVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802616f9;
        iVar4 = func_0x000180222010(uVar2);
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026170a;
                uVar6 = func_0x000180222340(uVar2, iVar7);
                *(undefined8 *)((int64_t)&arg_38h + iVar5) = uVar6;
                pcVar3 = *(code **)(in_RDX + 6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261713;
                (*pcVar3)();
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261723;
                fcn.1802612e0((int64_t)&arg_38h + iVar5, *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026172d;
                iVar4 = func_0x000180222010(uVar2);
            } while (iVar7 < iVar4);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261739;
        func_0x000180221d50(uVar2);
        *in_RCX = 0;
        return;
    }
    pcVar3 = *(code **)(in_RDX + 6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261756;
    (*pcVar3)();
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180261764;
    fcn.1802612e0((int64_t)in_RCX, *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5), *(int64_t *)(&stack0x00000048 + iVar5));
    return;
}

// ============================================================
// Function: FUN_180261770
// Address: 0x180261770
// Size: 220 bytes
// ============================================================
void fcn.180261770(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t iVar3;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18026177e;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_68h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar2);
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
    *(undefined *)((int64_t)&arg_50h + iVar2) = 0;
    iVar3 = (int64_t)&arg_48h + iVar2;
    if (in_RCX != 0) {
        iVar3 = in_RCX;
    }
    if ((iVar3 == 0) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2), 
                      *(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_28h + iVar2) = 0;
        *(int64_t *)((int64_t)&var_20h + iVar2) = (int64_t)&arg_50h + iVar2;
        *(undefined *)((int64_t)&var_18h + iVar2) = 0;
        *(undefined4 *)((int64_t)&var_10h + iVar2) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(iVar3);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802617f8;
            fcn.180261290(iVar3, in_R9);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180261841;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_68h + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180261850
// Address: 0x180261850
// Size: 239 bytes
// ============================================================
void fcn.180261850(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_70h, int64_t arg_c0h, int64_t arg_c8h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t iVar3;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18026185d;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_70h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar2);
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0;
    iVar3 = (int64_t)&arg_50h + iVar2;
    if (in_RCX != 0) {
        iVar3 = in_RCX;
    }
    *(undefined *)((int64_t)&arg_58h + iVar2) = 0;
    if ((iVar3 == 0) || (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x1802618f9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2));
        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180261911;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                      *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_40h + iVar2));
        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180261923;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = *(undefined8 *)((int64_t)&arg_c8h + iVar2);
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = *(undefined8 *)((int64_t)&arg_c0h + iVar2);
        *(undefined4 *)((int64_t)&arg_30h + iVar2) = 0;
        *(int64_t *)((int64_t)&arg_28h + iVar2) = (int64_t)&arg_58h + iVar2;
        *(undefined *)((int64_t)&var_20h + iVar2) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
        *(undefined4 *)((int64_t)&var_10h + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x1802618de;
        iVar1 = func_0x0001802629a0(iVar3);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x1802618ed;
            fcn.180261290(iVar3, in_R9);
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180261935;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_70h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180261940
// Address: 0x180261940
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

int32_t fcn.180261940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_68h, int64_t arg_70h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
                     int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180261950;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_R9 != 0)) {
        *(undefined8 *)((int64_t)&arg_68h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)((int64_t)&arg_a0h + iVar2);
        *(undefined *)((int64_t)&arg_28h + iVar2) = *(undefined *)((int64_t)&arg_98h + iVar2);
        *(undefined4 *)((int64_t)&var_20h + iVar2) = *(undefined4 *)((int64_t)&arg_90h + iVar2);
        *(undefined4 *)((int64_t)&var_18h + iVar2) = *(undefined4 *)((int64_t)&arg_88h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619ac;
        iVar1 = fcn.1802629a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar2), *(int64_t *)((int64_t)&arg_70h + iVar2), 
                              *(int64_t *)(&stack0x000000b0 + iVar2));
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619bd;
            fcn.180261290(in_RCX, in_R9);
        }
        return iVar1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619d4;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619ec;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619fe;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180261965
// Address: 0x180261965
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

int32_t fcn.180261940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_68h, int64_t arg_70h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
                     int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180261950;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_R9 != 0)) {
        *(undefined8 *)((int64_t)&arg_68h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)((int64_t)&arg_a0h + iVar2);
        *(undefined *)((int64_t)&arg_28h + iVar2) = *(undefined *)((int64_t)&arg_98h + iVar2);
        *(undefined4 *)((int64_t)&var_20h + iVar2) = *(undefined4 *)((int64_t)&arg_90h + iVar2);
        *(undefined4 *)((int64_t)&var_18h + iVar2) = *(undefined4 *)((int64_t)&arg_88h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619ac;
        iVar1 = fcn.1802629a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar2), *(int64_t *)((int64_t)&arg_70h + iVar2), 
                              *(int64_t *)(&stack0x000000b0 + iVar2));
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619bd;
            fcn.180261290(in_RCX, in_R9);
        }
        return iVar1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619d4;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619ec;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619fe;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1802619cf
// Address: 0x1802619cf
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

int32_t fcn.180261940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_68h, int64_t arg_70h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
                     int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180261950;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_R9 != 0)) {
        *(undefined8 *)((int64_t)&arg_68h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)((int64_t)&arg_a0h + iVar2);
        *(undefined *)((int64_t)&arg_28h + iVar2) = *(undefined *)((int64_t)&arg_98h + iVar2);
        *(undefined4 *)((int64_t)&var_20h + iVar2) = *(undefined4 *)((int64_t)&arg_90h + iVar2);
        *(undefined4 *)((int64_t)&var_18h + iVar2) = *(undefined4 *)((int64_t)&arg_88h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619ac;
        iVar1 = fcn.1802629a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)((int64_t)&arg_68h + iVar2), *(int64_t *)((int64_t)&arg_70h + iVar2), 
                              *(int64_t *)(&stack0x000000b0 + iVar2));
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619bd;
            fcn.180261290(in_RCX, in_R9);
        }
        return iVar1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619d4;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619ec;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802619fe;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180261a30
// Address: 0x180261a30
// Size: 919 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

undefined8
fcn.180261a30(int32_t *placeholder_0, int64_t arg2, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h,
             int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint8_t uVar11;
    uint64_t in_R9;
    char *pcVar12;
    char *pcVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x180261a42;
    var_10h = arg2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    pcVar13 = *(char **)arg2;
    uVar11 = (uint8_t)in_R9 & 1;
    uVar10 = (uint64_t)in_R8D;
    *(uint32_t *)((int64_t)&arg_90h + iVar5) = (uint32_t)uVar11;
    *(char **)((int64_t)&arg_38h + iVar5) = pcVar13;
    if ((placeholder_0 == (int32_t *)0x0) && ((in_R9 & 1) == 0)) {
        *(char **)arg2 = pcVar13 + uVar10;
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_a0h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_70h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R14;
    if (0 < in_R8D) {
        iVar1 = *(int32_t *)((int64_t)&arg_c0h + iVar5);
        iVar2 = *(int32_t *)((int64_t)&arg_b8h + iVar5);
        iVar3 = *(int32_t *)((int64_t)&arg_b0h + iVar5);
        pcVar12 = pcVar13;
        do {
            uVar9 = (uint32_t)uVar10;
            if (((1 < uVar9) && (*pcVar12 == '\0')) && (pcVar12[1] == '\0')) {
                pcVar13 = pcVar12 + 2;
                *(char **)((int64_t)&arg_38h + iVar5) = pcVar13;
                if (*(char *)((int64_t)&arg_90h + iVar5) == '\0') {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261c5b;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261c73;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                                  *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261c85;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar5));
                    return 0;
                }
                arg2 = *(int64_t *)((int64_t)&arg_98h + iVar5);
                goto code_r0x000180261d90;
            }
            *(char **)((int64_t)&arg_40h + iVar5) = pcVar12;
            *(uint32_t *)((int64_t)&var_10h + iVar5) = uVar9;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261b04;
            uVar11 = fcn.180296a80(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                                   *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5));
            if (((char)uVar11 < '\0') ||
               ((-1 < iVar3 &&
                ((iVar3 != *(int32_t *)((int64_t)&arg_30h + iVar5) ||
                 (iVar2 != *(int32_t *)((int64_t)&arg_30h + iVar5 + 4))))))) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d33;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d4b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d5c;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d61;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d75;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d84;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar5));
                return 0;
            }
            pcVar13 = *(char **)((int64_t)&arg_40h + iVar5);
            if ((uVar11 & 1) == 0) {
                iVar8 = *(int32_t *)((int64_t)&arg_a8h + iVar5);
            } else {
                iVar8 = ((int32_t)pcVar12 - (int32_t)pcVar13) + uVar9;
                *(int32_t *)((int64_t)&arg_a8h + iVar5) = iVar8;
            }
            *(char **)((int64_t)&arg_38h + iVar5) = pcVar13;
            if ((uVar11 & 0x20) == 0) {
                if (iVar8 != 0) {
                    if (placeholder_0 != (int32_t *)0x0) {
                        iVar4 = *placeholder_0;
                        if (iVar4 + iVar8 < 0) {
code_r0x000180261ceb:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d05;
                            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d13;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)(&stack0x00000028 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261d20;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar5));
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261bb3;
                        iVar6 = fcn.1802264b0(*(int64_t *)((int64_t)&var_20h + iVar5), 
                                              *(int64_t *)(&stack0x00000028 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar5));
                        if (iVar6 == 0) goto code_r0x000180261ceb;
                        iVar6 = *(int64_t *)(placeholder_0 + 2);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261bd3;
                        fcn.180498030(iVar4 + iVar6, *(undefined8 *)((int64_t)&arg_38h + iVar5), (int64_t)iVar8);
                        pcVar13 = *(char **)((int64_t)&arg_38h + iVar5);
                    }
                    pcVar13 = pcVar13 + iVar8;
                    *(char **)((int64_t)&arg_38h + iVar5) = pcVar13;
                }
            } else {
                if (4 < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261ca0;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261cb8;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                                  *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261cca;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar5));
                    return 0;
                }
                *(int32_t *)((int64_t)&var_20h + iVar5) = iVar1 + 1;
                *(int32_t *)((int64_t)&var_18h + iVar5) = iVar2;
                *(int32_t *)((int64_t)&var_10h + iVar5) = iVar3;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261b81;
                iVar8 = fcn.180261a30(placeholder_0, (int64_t)&arg_38h + iVar5, *(int64_t *)((int64_t)&var_18h + iVar5)
                                      , *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_38h + iVar5)
                                      , *(int64_t *)((int64_t)&arg_40h + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                      , *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5)
                                      , *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                      *(int64_t *)(&stack0x00000088 + iVar5), *(int64_t *)((int64_t)&arg_90h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_98h + iVar5), *(int64_t *)((int64_t)&arg_a0h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_a8h + iVar5));
                if (iVar8 == 0) goto code_r0x000180261c38;
                pcVar13 = *(char **)((int64_t)&arg_38h + iVar5);
            }
            uVar9 = uVar9 + ((int32_t)pcVar12 - (int32_t)pcVar13);
            uVar10 = (uint64_t)uVar9;
            pcVar12 = pcVar13;
        } while (0 < (int32_t)uVar9);
        uVar11 = (uint8_t)*(undefined4 *)((int64_t)&arg_90h + iVar5);
        arg2 = *(int64_t *)((int64_t)&arg_98h + iVar5);
    }
    if (uVar11 == 0) {
code_r0x000180261d90:
        *(char **)arg2 = pcVar13;
        uVar7 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261c0e;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261c26;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180261c38;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar5));
code_r0x000180261c38:
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_180261dd0
// Address: 0x180261dd0
// Size: 628 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

undefined8
fcn.180261dd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
             int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h, int64_t arg_a0h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char cVar7;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_38;
    undefined8 uVar11;
    
    uStack_38 = 0x180261df6;
    var_8h = arg1;
    var_10h = arg2;
    var_20h = arg4;
    iVar4 = fcn.18045a350();
    iVar5 = arg_40h;
    iVar4 = -iVar4;
    uVar11 = 0;
    uVar10 = 0;
    var_78h._0_1_ = '\0';
    var_60h = 0;
    var_58h = 0;
    var_50h = 0;
    var_48h._0_4_ = 0;
    if (arg1 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e29;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e41;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e53;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        return 0;
    }
    if (*(char *)arg4 == '\x05') {
        uVar9 = 0xffffffff;
        uVar2 = (uint32_t)arg_28h;
    } else {
        uVar2 = *(uint32_t *)(arg4 + 4);
        uVar9 = (uint32_t)arg_28h;
    }
    *(undefined8 *)((int64_t)&arg_a0h + iVar4) = unaff_R12;
    if (uVar2 == 0xfffffffc) {
        if (-1 < (int32_t)uVar9) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e90;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ea8;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261eba;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        if ((char)arg_38h != '\0') {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ecc;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ee4;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ef6;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        iVar8 = *(int64_t *)arg2;
        var_68h = iVar8;
        if ((int32_t)placeholder_2 < 1) goto code_r0x000180261fd0;
        if (arg_40h == 0) {
            *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fb6;
            uVar2 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
code_r0x000180261fbe:
            cVar7 = (char)uVar2;
            arg2 = var_10h;
        } else {
            if (*(char *)arg_40h == '\0') {
                *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261f5e;
                uVar2 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)(&stack0x00000000 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                *(uint32_t *)(iVar5 + 4) = uVar2;
                iVar6 = (int32_t)var_68h - (int32_t)iVar8;
                *(int32_t *)(iVar5 + 8) = var_70h._4_4_;
                *(uint32_t *)(iVar5 + 0x10) = var_78h._4_4_;
                *(uint32_t *)(iVar5 + 0xc) = (uint32_t)var_70h;
                *(int32_t *)(iVar5 + 0x14) = iVar6;
                *(undefined *)iVar5 = 1;
                if (((uVar2 & 0x81) == 0) && ((int32_t)placeholder_2 < iVar6 + var_70h._4_4_))
                goto code_r0x000180261fd0;
                goto code_r0x000180261fbe;
            }
            cVar7 = (char)*(undefined4 *)(arg_40h + 4);
            var_70h._4_4_ = *(int32_t *)(arg_40h + 8);
            var_78h._4_4_ = *(uint32_t *)(arg_40h + 0x10);
            var_68h = iVar8 + *(int32_t *)(arg_40h + 0x14);
            var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
        }
        if (cVar7 < '\0') {
code_r0x000180261fd0:
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fd5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fea;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ff9;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            if (iVar5 != 0) {
                *(undefined *)iVar5 = 0;
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262006;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026201e;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262030;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        uVar2 = (uint32_t)var_70h;
        if ((char)var_78h._4_4_ != '\0') {
            uVar2 = 0xfffffffd;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R13;
    uVar1 = (uint32_t)arg_30h;
    if (uVar9 == 0xffffffff) {
        uVar9 = uVar2;
        uVar1 = 0;
    }
    arg2 = *(int64_t *)arg2;
    var_68h = arg2;
    if ((int32_t)placeholder_2 < 1) {
code_r0x0001802621db:
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621e0;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621f5;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262204;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        if (iVar5 != 0) {
            *(undefined *)iVar5 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262211;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262229;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026223b;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        return 0;
    }
    if ((iVar5 == 0) || (*(char *)iVar5 == '\0')) {
        *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802620c1;
        uVar3 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        if (iVar5 != 0) {
            *(uint32_t *)(iVar5 + 4) = uVar3;
            iVar6 = (int32_t)var_68h - (int32_t)arg2;
            *(int32_t *)(iVar5 + 8) = var_70h._4_4_;
            *(uint32_t *)(iVar5 + 0x10) = (uint32_t)var_70h;
            *(uint32_t *)(iVar5 + 0xc) = var_78h._4_4_;
            *(int32_t *)(iVar5 + 0x14) = iVar6;
            *(undefined *)iVar5 = 1;
            if (((uVar3 & 0x81) == 0) && ((int32_t)placeholder_2 < iVar6 + var_70h._4_4_)) goto code_r0x0001802621db;
        }
    } else {
        uVar3 = *(uint32_t *)(iVar5 + 4);
        var_68h = *(int32_t *)(iVar5 + 0x14) + arg2;
        var_70h._4_4_ = *(int32_t *)(iVar5 + 8);
        var_70h._0_4_ = *(uint32_t *)(iVar5 + 0x10);
        var_78h._4_4_ = *(uint32_t *)(iVar5 + 0xc);
    }
    if ((char)uVar3 < '\0') goto code_r0x0001802621db;
    if (-1 < (int32_t)uVar9) {
        if ((uVar9 != var_78h._4_4_) || (uVar1 != (uint32_t)var_70h)) {
            if ((char)arg_38h != '\0') {
                return 0xffffffff;
            }
            goto code_r0x0001802621db;
        }
        if (iVar5 != 0) {
            *(undefined *)iVar5 = 0;
        }
    }
    iVar6 = var_70h._4_4_;
    if ((uVar3 & 1) != 0) {
        iVar6 = ((int32_t)arg2 - (int32_t)var_68h) + (int32_t)placeholder_2;
    }
    if (uVar2 - 0x10 < 2) {
        if ((uVar3 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262323;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026233b;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026234d;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
code_r0x0001802622ef:
        if ((uVar3 & 1) == 0) {
            iVar5 = (int64_t)iVar6 + var_68h;
        } else {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262306;
            iVar6 = fcn.180262800(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4));
            iVar5 = var_68h;
            if (iVar6 == 0) goto code_r0x000180262393;
        }
    } else {
        if (uVar2 == 0xfffffffd) {
            if (iVar5 != 0) {
                *(undefined *)iVar5 = 0;
            }
            goto code_r0x0001802622ef;
        }
        if ((uVar3 & 0x20) == 0) {
            iVar5 = var_68h + (int64_t)iVar6;
        } else {
            if ((uVar2 < 0xb) && ((0x466U >> (uVar2 & 0x1f) & 1) != 0)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026219a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621b2;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621c4;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                return 0;
            }
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff0 + iVar4) = 0xffffffff;
            var_78h._0_1_ = '\x01';
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262272;
            iVar6 = fcn.180261a30(&var_60h, (int64_t)&var_68h, *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4), 
                                  *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                                  *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                                  *(int64_t *)(&stack0x00000088 + iVar4));
            uVar10 = uVar11;
            if (iVar6 == 0) goto code_r0x000180262393;
            iVar8 = (int64_t)(int32_t)var_60h;
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026228d;
            iVar5 = fcn.1802264b0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar4));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262297;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802622af;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802622c1;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                goto code_r0x000180262393;
            }
            *(undefined *)(iVar8 + var_58h) = 0;
            iVar5 = var_68h;
        }
    }
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar4) = var_20h;
    *(int64_t **)(&stack0xfffffffffffffff0 + iVar4) = &var_78h;
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262382;
    iVar6 = fcn.1802623e0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
    uVar10 = uVar11;
    if (iVar6 != 0) {
        uVar10 = 1;
        *(int64_t *)var_10h = iVar5;
    }
code_r0x000180262393:
    if ((char)var_78h == '\0') {
        return uVar10;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802623af;
    fcn.180224990(var_58h, 0x1804e6d08, 0x339);
    return uVar10;
}

// ============================================================
// Function: FUN_180262044
// Address: 0x180262044
// Size: 886 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

undefined8
fcn.180261dd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
             int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h, int64_t arg_a0h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char cVar7;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_38;
    undefined8 uVar11;
    
    uStack_38 = 0x180261df6;
    var_8h = arg1;
    var_10h = arg2;
    var_20h = arg4;
    iVar4 = fcn.18045a350();
    iVar5 = arg_40h;
    iVar4 = -iVar4;
    uVar11 = 0;
    uVar10 = 0;
    var_78h._0_1_ = '\0';
    var_60h = 0;
    var_58h = 0;
    var_50h = 0;
    var_48h._0_4_ = 0;
    if (arg1 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e29;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e41;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e53;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        return 0;
    }
    if (*(char *)arg4 == '\x05') {
        uVar9 = 0xffffffff;
        uVar2 = (uint32_t)arg_28h;
    } else {
        uVar2 = *(uint32_t *)(arg4 + 4);
        uVar9 = (uint32_t)arg_28h;
    }
    *(undefined8 *)((int64_t)&arg_a0h + iVar4) = unaff_R12;
    if (uVar2 == 0xfffffffc) {
        if (-1 < (int32_t)uVar9) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e90;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ea8;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261eba;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        if ((char)arg_38h != '\0') {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ecc;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ee4;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ef6;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        iVar8 = *(int64_t *)arg2;
        var_68h = iVar8;
        if ((int32_t)placeholder_2 < 1) goto code_r0x000180261fd0;
        if (arg_40h == 0) {
            *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fb6;
            uVar2 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
code_r0x000180261fbe:
            cVar7 = (char)uVar2;
            arg2 = var_10h;
        } else {
            if (*(char *)arg_40h == '\0') {
                *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261f5e;
                uVar2 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)(&stack0x00000000 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                *(uint32_t *)(iVar5 + 4) = uVar2;
                iVar6 = (int32_t)var_68h - (int32_t)iVar8;
                *(int32_t *)(iVar5 + 8) = var_70h._4_4_;
                *(uint32_t *)(iVar5 + 0x10) = var_78h._4_4_;
                *(uint32_t *)(iVar5 + 0xc) = (uint32_t)var_70h;
                *(int32_t *)(iVar5 + 0x14) = iVar6;
                *(undefined *)iVar5 = 1;
                if (((uVar2 & 0x81) == 0) && ((int32_t)placeholder_2 < iVar6 + var_70h._4_4_))
                goto code_r0x000180261fd0;
                goto code_r0x000180261fbe;
            }
            cVar7 = (char)*(undefined4 *)(arg_40h + 4);
            var_70h._4_4_ = *(int32_t *)(arg_40h + 8);
            var_78h._4_4_ = *(uint32_t *)(arg_40h + 0x10);
            var_68h = iVar8 + *(int32_t *)(arg_40h + 0x14);
            var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
        }
        if (cVar7 < '\0') {
code_r0x000180261fd0:
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fd5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fea;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ff9;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            if (iVar5 != 0) {
                *(undefined *)iVar5 = 0;
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262006;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026201e;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262030;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        uVar2 = (uint32_t)var_70h;
        if ((char)var_78h._4_4_ != '\0') {
            uVar2 = 0xfffffffd;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R13;
    uVar1 = (uint32_t)arg_30h;
    if (uVar9 == 0xffffffff) {
        uVar9 = uVar2;
        uVar1 = 0;
    }
    arg2 = *(int64_t *)arg2;
    var_68h = arg2;
    if ((int32_t)placeholder_2 < 1) {
code_r0x0001802621db:
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621e0;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621f5;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262204;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        if (iVar5 != 0) {
            *(undefined *)iVar5 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262211;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262229;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026223b;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        return 0;
    }
    if ((iVar5 == 0) || (*(char *)iVar5 == '\0')) {
        *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802620c1;
        uVar3 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        if (iVar5 != 0) {
            *(uint32_t *)(iVar5 + 4) = uVar3;
            iVar6 = (int32_t)var_68h - (int32_t)arg2;
            *(int32_t *)(iVar5 + 8) = var_70h._4_4_;
            *(uint32_t *)(iVar5 + 0x10) = (uint32_t)var_70h;
            *(uint32_t *)(iVar5 + 0xc) = var_78h._4_4_;
            *(int32_t *)(iVar5 + 0x14) = iVar6;
            *(undefined *)iVar5 = 1;
            if (((uVar3 & 0x81) == 0) && ((int32_t)placeholder_2 < iVar6 + var_70h._4_4_)) goto code_r0x0001802621db;
        }
    } else {
        uVar3 = *(uint32_t *)(iVar5 + 4);
        var_68h = *(int32_t *)(iVar5 + 0x14) + arg2;
        var_70h._4_4_ = *(int32_t *)(iVar5 + 8);
        var_70h._0_4_ = *(uint32_t *)(iVar5 + 0x10);
        var_78h._4_4_ = *(uint32_t *)(iVar5 + 0xc);
    }
    if ((char)uVar3 < '\0') goto code_r0x0001802621db;
    if (-1 < (int32_t)uVar9) {
        if ((uVar9 != var_78h._4_4_) || (uVar1 != (uint32_t)var_70h)) {
            if ((char)arg_38h != '\0') {
                return 0xffffffff;
            }
            goto code_r0x0001802621db;
        }
        if (iVar5 != 0) {
            *(undefined *)iVar5 = 0;
        }
    }
    iVar6 = var_70h._4_4_;
    if ((uVar3 & 1) != 0) {
        iVar6 = ((int32_t)arg2 - (int32_t)var_68h) + (int32_t)placeholder_2;
    }
    if (uVar2 - 0x10 < 2) {
        if ((uVar3 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262323;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026233b;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026234d;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
code_r0x0001802622ef:
        if ((uVar3 & 1) == 0) {
            iVar5 = (int64_t)iVar6 + var_68h;
        } else {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262306;
            iVar6 = fcn.180262800(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4));
            iVar5 = var_68h;
            if (iVar6 == 0) goto code_r0x000180262393;
        }
    } else {
        if (uVar2 == 0xfffffffd) {
            if (iVar5 != 0) {
                *(undefined *)iVar5 = 0;
            }
            goto code_r0x0001802622ef;
        }
        if ((uVar3 & 0x20) == 0) {
            iVar5 = var_68h + (int64_t)iVar6;
        } else {
            if ((uVar2 < 0xb) && ((0x466U >> (uVar2 & 0x1f) & 1) != 0)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026219a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621b2;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621c4;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                return 0;
            }
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff0 + iVar4) = 0xffffffff;
            var_78h._0_1_ = '\x01';
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262272;
            iVar6 = fcn.180261a30(&var_60h, (int64_t)&var_68h, *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4), 
                                  *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                                  *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                                  *(int64_t *)(&stack0x00000088 + iVar4));
            uVar10 = uVar11;
            if (iVar6 == 0) goto code_r0x000180262393;
            iVar8 = (int64_t)(int32_t)var_60h;
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026228d;
            iVar5 = fcn.1802264b0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar4));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262297;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802622af;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802622c1;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                goto code_r0x000180262393;
            }
            *(undefined *)(iVar8 + var_58h) = 0;
            iVar5 = var_68h;
        }
    }
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar4) = var_20h;
    *(int64_t **)(&stack0xfffffffffffffff0 + iVar4) = &var_78h;
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262382;
    iVar6 = fcn.1802623e0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
    uVar10 = uVar11;
    if (iVar6 != 0) {
        uVar10 = 1;
        *(int64_t *)var_10h = iVar5;
    }
code_r0x000180262393:
    if ((char)var_78h == '\0') {
        return uVar10;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802623af;
    fcn.180224990(var_58h, 0x1804e6d08, 0x339);
    return uVar10;
}

// ============================================================
// Function: FUN_1802623ba
// Address: 0x1802623ba
// Size: 24 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

undefined8
fcn.180261dd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
             int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h, int64_t arg_a0h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char cVar7;
    int64_t iVar8;
    uint32_t uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_38;
    undefined8 uVar11;
    
    uStack_38 = 0x180261df6;
    var_8h = arg1;
    var_10h = arg2;
    var_20h = arg4;
    iVar4 = fcn.18045a350();
    iVar5 = arg_40h;
    iVar4 = -iVar4;
    uVar11 = 0;
    uVar10 = 0;
    var_78h._0_1_ = '\0';
    var_60h = 0;
    var_58h = 0;
    var_50h = 0;
    var_48h._0_4_ = 0;
    if (arg1 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e29;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e41;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e53;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        return 0;
    }
    if (*(char *)arg4 == '\x05') {
        uVar9 = 0xffffffff;
        uVar2 = (uint32_t)arg_28h;
    } else {
        uVar2 = *(uint32_t *)(arg4 + 4);
        uVar9 = (uint32_t)arg_28h;
    }
    *(undefined8 *)((int64_t)&arg_a0h + iVar4) = unaff_R12;
    if (uVar2 == 0xfffffffc) {
        if (-1 < (int32_t)uVar9) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261e90;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ea8;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261eba;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        if ((char)arg_38h != '\0') {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ecc;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ee4;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ef6;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        iVar8 = *(int64_t *)arg2;
        var_68h = iVar8;
        if ((int32_t)placeholder_2 < 1) goto code_r0x000180261fd0;
        if (arg_40h == 0) {
            *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fb6;
            uVar2 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
code_r0x000180261fbe:
            cVar7 = (char)uVar2;
            arg2 = var_10h;
        } else {
            if (*(char *)arg_40h == '\0') {
                *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261f5e;
                uVar2 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)(&stack0x00000000 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                *(uint32_t *)(iVar5 + 4) = uVar2;
                iVar6 = (int32_t)var_68h - (int32_t)iVar8;
                *(int32_t *)(iVar5 + 8) = var_70h._4_4_;
                *(uint32_t *)(iVar5 + 0x10) = var_78h._4_4_;
                *(uint32_t *)(iVar5 + 0xc) = (uint32_t)var_70h;
                *(int32_t *)(iVar5 + 0x14) = iVar6;
                *(undefined *)iVar5 = 1;
                if (((uVar2 & 0x81) == 0) && ((int32_t)placeholder_2 < iVar6 + var_70h._4_4_))
                goto code_r0x000180261fd0;
                goto code_r0x000180261fbe;
            }
            cVar7 = (char)*(undefined4 *)(arg_40h + 4);
            var_70h._4_4_ = *(int32_t *)(arg_40h + 8);
            var_78h._4_4_ = *(uint32_t *)(arg_40h + 0x10);
            var_68h = iVar8 + *(int32_t *)(arg_40h + 0x14);
            var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
        }
        if (cVar7 < '\0') {
code_r0x000180261fd0:
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fd5;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261fea;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180261ff9;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            if (iVar5 != 0) {
                *(undefined *)iVar5 = 0;
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262006;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026201e;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262030;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
        uVar2 = (uint32_t)var_70h;
        if ((char)var_78h._4_4_ != '\0') {
            uVar2 = 0xfffffffd;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R13;
    uVar1 = (uint32_t)arg_30h;
    if (uVar9 == 0xffffffff) {
        uVar9 = uVar2;
        uVar1 = 0;
    }
    arg2 = *(int64_t *)arg2;
    var_68h = arg2;
    if ((int32_t)placeholder_2 < 1) {
code_r0x0001802621db:
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621e0;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621f5;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262204;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        if (iVar5 != 0) {
            *(undefined *)iVar5 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262211;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262229;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026223b;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        return 0;
    }
    if ((iVar5 == 0) || (*(char *)iVar5 == '\0')) {
        *(int32_t *)(&stack0xfffffffffffffff0 + iVar4) = (int32_t)placeholder_2;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802620c1;
        uVar3 = fcn.180296a80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        if (iVar5 != 0) {
            *(uint32_t *)(iVar5 + 4) = uVar3;
            iVar6 = (int32_t)var_68h - (int32_t)arg2;
            *(int32_t *)(iVar5 + 8) = var_70h._4_4_;
            *(uint32_t *)(iVar5 + 0x10) = (uint32_t)var_70h;
            *(uint32_t *)(iVar5 + 0xc) = var_78h._4_4_;
            *(int32_t *)(iVar5 + 0x14) = iVar6;
            *(undefined *)iVar5 = 1;
            if (((uVar3 & 0x81) == 0) && ((int32_t)placeholder_2 < iVar6 + var_70h._4_4_)) goto code_r0x0001802621db;
        }
    } else {
        uVar3 = *(uint32_t *)(iVar5 + 4);
        var_68h = *(int32_t *)(iVar5 + 0x14) + arg2;
        var_70h._4_4_ = *(int32_t *)(iVar5 + 8);
        var_70h._0_4_ = *(uint32_t *)(iVar5 + 0x10);
        var_78h._4_4_ = *(uint32_t *)(iVar5 + 0xc);
    }
    if ((char)uVar3 < '\0') goto code_r0x0001802621db;
    if (-1 < (int32_t)uVar9) {
        if ((uVar9 != var_78h._4_4_) || (uVar1 != (uint32_t)var_70h)) {
            if ((char)arg_38h != '\0') {
                return 0xffffffff;
            }
            goto code_r0x0001802621db;
        }
        if (iVar5 != 0) {
            *(undefined *)iVar5 = 0;
        }
    }
    iVar6 = var_70h._4_4_;
    if ((uVar3 & 1) != 0) {
        iVar6 = ((int32_t)arg2 - (int32_t)var_68h) + (int32_t)placeholder_2;
    }
    if (uVar2 - 0x10 < 2) {
        if ((uVar3 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262323;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                         );
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026233b;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0xfffffffffffffff8 + iVar4)
                          , *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026234d;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
            return 0;
        }
code_r0x0001802622ef:
        if ((uVar3 & 1) == 0) {
            iVar5 = (int64_t)iVar6 + var_68h;
        } else {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262306;
            iVar6 = fcn.180262800(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4));
            iVar5 = var_68h;
            if (iVar6 == 0) goto code_r0x000180262393;
        }
    } else {
        if (uVar2 == 0xfffffffd) {
            if (iVar5 != 0) {
                *(undefined *)iVar5 = 0;
            }
            goto code_r0x0001802622ef;
        }
        if ((uVar3 & 0x20) == 0) {
            iVar5 = var_68h + (int64_t)iVar6;
        } else {
            if ((uVar2 < 0xb) && ((0x466U >> (uVar2 & 0x1f) & 1) != 0)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026219a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621b2;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802621c4;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                return 0;
            }
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff0 + iVar4) = 0xffffffff;
            var_78h._0_1_ = '\x01';
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262272;
            iVar6 = fcn.180261a30(&var_60h, (int64_t)&var_68h, *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4), 
                                  *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                                  *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                                  *(int64_t *)(&stack0x00000088 + iVar4));
            uVar10 = uVar11;
            if (iVar6 == 0) goto code_r0x000180262393;
            iVar8 = (int64_t)(int32_t)var_60h;
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026228d;
            iVar5 = fcn.1802264b0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar4));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262297;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802622af;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802622c1;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                goto code_r0x000180262393;
            }
            *(undefined *)(iVar8 + var_58h) = 0;
            iVar5 = var_68h;
        }
    }
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar4) = var_20h;
    *(int64_t **)(&stack0xfffffffffffffff0 + iVar4) = &var_78h;
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x180262382;
    iVar6 = fcn.1802623e0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
    uVar10 = uVar11;
    if (iVar6 != 0) {
        uVar10 = 1;
        *(int64_t *)var_10h = iVar5;
    }
code_r0x000180262393:
    if ((char)var_78h == '\0') {
        return uVar10;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x1802623af;
    fcn.180224990(var_58h, 0x1804e6d08, 0x339);
    return uVar10;
}

// ============================================================
// Function: FUN_1802623e0
// Address: 0x1802623e0
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8
fcn.1802623e0(int64_t **placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    uint64_t in_R8;
    uint32_t in_R9D;
    undefined8 unaff_R12;
    int64_t **ppiVar10;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1802623fb;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar7 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    ppiVar10 = (int64_t **)0x0;
    if ((*(int64_t *)(iVar7 + 0x18) != 0) &&
       (pcVar1 = *(code **)(*(int64_t *)(iVar7 + 0x18) + 0x28), pcVar1 != (code *)0x0)) {
        *(int64_t *)(&stack0x00000000 + iVar4) = iVar7;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026243f;
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar3 = *(int32_t *)(iVar7 + 4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    ppiVar9 = placeholder_0;
    ppiVar6 = ppiVar10;
    if (iVar3 == -4) {
        ppiVar6 = (int64_t **)*placeholder_0;
        if (ppiVar6 == (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026246d;
            ppiVar6 = (int64_t **)fcn.180228960();
            if (ppiVar6 == (int64_t **)0x0) goto code_r0x00018026279c;
            arg2 = *(int64_t *)((int64_t)&arg_40h + iVar4);
            *placeholder_0 = (int64_t *)ppiVar6;
        }
        if (in_R9D != *(uint32_t *)ppiVar6) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262492;
            fcn.18025fc10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            arg2 = *(int64_t *)((int64_t)&arg_40h + iVar4);
        }
        ppiVar9 = ppiVar6 + 1;
        ppiVar10 = placeholder_0;
    }
    iVar3 = (int32_t)in_R8;
    // switch table (34 cases) at 0x1802627b8
    switch(in_R9D) {
    case 1:
        if (iVar3 == 1) {
            *(uint32_t *)ppiVar9 = (uint32_t)*(uint8_t *)arg2;
            break;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026255f;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262577;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262589;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
        goto code_r0x00018026279c;
    case 2:
    case 10:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625bd;
        iVar7 = fcn.180260800(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4));
        if (iVar7 == 0) goto code_r0x00018026279c;
        *(uint32_t *)((int64_t)*ppiVar9 + 4) = *(uint32_t *)((int64_t)*ppiVar9 + 4) & 0x100 | in_R9D;
        break;
    case 3:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625a8;
        iVar7 = fcn.1802a9210(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        goto code_r0x0001802624d9;
    case 5:
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026251d;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262535;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262547;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
            goto code_r0x00018026279c;
        }
        *ppiVar9 = (int64_t *)0x1;
        break;
    case 6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802624d9;
        iVar7 = fcn.18027c930(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001802624d9:
        if (iVar7 == 0) {
code_r0x00018026279c:
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802627a4;
            fcn.180228940(ppiVar6);
            if (ppiVar10 != (int64_t **)0x0) {
                *ppiVar10 = (int64_t *)0x0;
            }
            return 0;
        }
        break;
    default:
        if (in_R9D == 0x1e) {
            if ((in_R8 & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625ef;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262607;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262619;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if (in_R9D == 0x1c) {
            if ((in_R8 & 3) != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262632;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026264a;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026265c;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if (in_R9D == 0x18) {
            if (iVar3 < 0xf) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262670;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262688;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026269a;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if ((in_R9D == 0x17) && (iVar3 < 0xd)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626ae;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626c6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626d8;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
            goto code_r0x00018026279c;
        }
        if (*ppiVar9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626ec;
            piVar8 = (int64_t *)fcn.180296a40(in_R9D);
            if (piVar8 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626f9;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262711;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262723;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
            *ppiVar9 = piVar8;
        } else {
            *(uint32_t *)((int64_t)*ppiVar9 + 4) = in_R9D;
        }
        pcVar2 = *(char **)((int64_t)&arg_58h + iVar4);
        if (*pcVar2 == '\0') {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026275a;
            iVar3 = fcn.1802968f0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                                  *(int64_t *)(&stack0x00000030 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262767;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026277f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262791;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262799;
                fcn.180296840(*(int64_t *)((int64_t)&var_8h + iVar4));
                *ppiVar9 = (int64_t *)0x0;
                goto code_r0x00018026279c;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026274c;
            fcn.1802969f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *pcVar2 = '\0';
        }
    }
    if ((ppiVar6 != (int64_t **)0x0) && (in_R9D == 5)) {
        ppiVar6[1] = (int64_t *)0x0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180262454
// Address: 0x180262454
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8
fcn.1802623e0(int64_t **placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    uint64_t in_R8;
    uint32_t in_R9D;
    undefined8 unaff_R12;
    int64_t **ppiVar10;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1802623fb;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar7 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    ppiVar10 = (int64_t **)0x0;
    if ((*(int64_t *)(iVar7 + 0x18) != 0) &&
       (pcVar1 = *(code **)(*(int64_t *)(iVar7 + 0x18) + 0x28), pcVar1 != (code *)0x0)) {
        *(int64_t *)(&stack0x00000000 + iVar4) = iVar7;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026243f;
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar3 = *(int32_t *)(iVar7 + 4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    ppiVar9 = placeholder_0;
    ppiVar6 = ppiVar10;
    if (iVar3 == -4) {
        ppiVar6 = (int64_t **)*placeholder_0;
        if (ppiVar6 == (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026246d;
            ppiVar6 = (int64_t **)fcn.180228960();
            if (ppiVar6 == (int64_t **)0x0) goto code_r0x00018026279c;
            arg2 = *(int64_t *)((int64_t)&arg_40h + iVar4);
            *placeholder_0 = (int64_t *)ppiVar6;
        }
        if (in_R9D != *(uint32_t *)ppiVar6) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262492;
            fcn.18025fc10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            arg2 = *(int64_t *)((int64_t)&arg_40h + iVar4);
        }
        ppiVar9 = ppiVar6 + 1;
        ppiVar10 = placeholder_0;
    }
    iVar3 = (int32_t)in_R8;
    // switch table (34 cases) at 0x1802627b8
    switch(in_R9D) {
    case 1:
        if (iVar3 == 1) {
            *(uint32_t *)ppiVar9 = (uint32_t)*(uint8_t *)arg2;
            break;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026255f;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262577;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262589;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
        goto code_r0x00018026279c;
    case 2:
    case 10:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625bd;
        iVar7 = fcn.180260800(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4));
        if (iVar7 == 0) goto code_r0x00018026279c;
        *(uint32_t *)((int64_t)*ppiVar9 + 4) = *(uint32_t *)((int64_t)*ppiVar9 + 4) & 0x100 | in_R9D;
        break;
    case 3:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625a8;
        iVar7 = fcn.1802a9210(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        goto code_r0x0001802624d9;
    case 5:
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026251d;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262535;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262547;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
            goto code_r0x00018026279c;
        }
        *ppiVar9 = (int64_t *)0x1;
        break;
    case 6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802624d9;
        iVar7 = fcn.18027c930(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001802624d9:
        if (iVar7 == 0) {
code_r0x00018026279c:
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802627a4;
            fcn.180228940(ppiVar6);
            if (ppiVar10 != (int64_t **)0x0) {
                *ppiVar10 = (int64_t *)0x0;
            }
            return 0;
        }
        break;
    default:
        if (in_R9D == 0x1e) {
            if ((in_R8 & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625ef;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262607;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262619;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if (in_R9D == 0x1c) {
            if ((in_R8 & 3) != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262632;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026264a;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026265c;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if (in_R9D == 0x18) {
            if (iVar3 < 0xf) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262670;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262688;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026269a;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if ((in_R9D == 0x17) && (iVar3 < 0xd)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626ae;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626c6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626d8;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
            goto code_r0x00018026279c;
        }
        if (*ppiVar9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626ec;
            piVar8 = (int64_t *)fcn.180296a40(in_R9D);
            if (piVar8 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626f9;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262711;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262723;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
            *ppiVar9 = piVar8;
        } else {
            *(uint32_t *)((int64_t)*ppiVar9 + 4) = in_R9D;
        }
        pcVar2 = *(char **)((int64_t)&arg_58h + iVar4);
        if (*pcVar2 == '\0') {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026275a;
            iVar3 = fcn.1802968f0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                                  *(int64_t *)(&stack0x00000030 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262767;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026277f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262791;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262799;
                fcn.180296840(*(int64_t *)((int64_t)&var_8h + iVar4));
                *ppiVar9 = (int64_t *)0x0;
                goto code_r0x00018026279c;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026274c;
            fcn.1802969f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *pcVar2 = '\0';
        }
    }
    if ((ppiVar6 != (int64_t **)0x0) && (in_R9D == 5)) {
        ppiVar6[1] = (int64_t *)0x0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180262514
// Address: 0x180262514
// Size: 738 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8
fcn.1802623e0(int64_t **placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t **ppiVar9;
    uint64_t in_R8;
    uint32_t in_R9D;
    undefined8 unaff_R12;
    int64_t **ppiVar10;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1802623fb;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar7 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    ppiVar10 = (int64_t **)0x0;
    if ((*(int64_t *)(iVar7 + 0x18) != 0) &&
       (pcVar1 = *(code **)(*(int64_t *)(iVar7 + 0x18) + 0x28), pcVar1 != (code *)0x0)) {
        *(int64_t *)(&stack0x00000000 + iVar4) = iVar7;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026243f;
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar3 = *(int32_t *)(iVar7 + 4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    ppiVar9 = placeholder_0;
    ppiVar6 = ppiVar10;
    if (iVar3 == -4) {
        ppiVar6 = (int64_t **)*placeholder_0;
        if (ppiVar6 == (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026246d;
            ppiVar6 = (int64_t **)fcn.180228960();
            if (ppiVar6 == (int64_t **)0x0) goto code_r0x00018026279c;
            arg2 = *(int64_t *)((int64_t)&arg_40h + iVar4);
            *placeholder_0 = (int64_t *)ppiVar6;
        }
        if (in_R9D != *(uint32_t *)ppiVar6) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262492;
            fcn.18025fc10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            arg2 = *(int64_t *)((int64_t)&arg_40h + iVar4);
        }
        ppiVar9 = ppiVar6 + 1;
        ppiVar10 = placeholder_0;
    }
    iVar3 = (int32_t)in_R8;
    // switch table (34 cases) at 0x1802627b8
    switch(in_R9D) {
    case 1:
        if (iVar3 == 1) {
            *(uint32_t *)ppiVar9 = (uint32_t)*(uint8_t *)arg2;
            break;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026255f;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262577;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262589;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
        goto code_r0x00018026279c;
    case 2:
    case 10:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625bd;
        iVar7 = fcn.180260800(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4));
        if (iVar7 == 0) goto code_r0x00018026279c;
        *(uint32_t *)((int64_t)*ppiVar9 + 4) = *(uint32_t *)((int64_t)*ppiVar9 + 4) & 0x100 | in_R9D;
        break;
    case 3:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625a8;
        iVar7 = fcn.1802a9210(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
        goto code_r0x0001802624d9;
    case 5:
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026251d;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262535;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262547;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
            goto code_r0x00018026279c;
        }
        *ppiVar9 = (int64_t *)0x1;
        break;
    case 6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802624d9;
        iVar7 = fcn.18027c930(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001802624d9:
        if (iVar7 == 0) {
code_r0x00018026279c:
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802627a4;
            fcn.180228940(ppiVar6);
            if (ppiVar10 != (int64_t **)0x0) {
                *ppiVar10 = (int64_t *)0x0;
            }
            return 0;
        }
        break;
    default:
        if (in_R9D == 0x1e) {
            if ((in_R8 & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802625ef;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262607;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262619;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if (in_R9D == 0x1c) {
            if ((in_R8 & 3) != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262632;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026264a;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026265c;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if (in_R9D == 0x18) {
            if (iVar3 < 0xf) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262670;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262688;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026269a;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
        } else if ((in_R9D == 0x17) && (iVar3 < 0xd)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626ae;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626c6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626d8;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
            goto code_r0x00018026279c;
        }
        if (*ppiVar9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626ec;
            piVar8 = (int64_t *)fcn.180296a40(in_R9D);
            if (piVar8 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802626f9;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262711;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262723;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                goto code_r0x00018026279c;
            }
            *ppiVar9 = piVar8;
        } else {
            *(uint32_t *)((int64_t)*ppiVar9 + 4) = in_R9D;
        }
        pcVar2 = *(char **)((int64_t)&arg_58h + iVar4);
        if (*pcVar2 == '\0') {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026275a;
            iVar3 = fcn.1802968f0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                                  *(int64_t *)(&stack0x00000030 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262767;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026277f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8)
                              , *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262791;
                fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180262799;
                fcn.180296840(*(int64_t *)((int64_t)&var_8h + iVar4));
                *ppiVar9 = (int64_t *)0x0;
                goto code_r0x00018026279c;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18026274c;
            fcn.1802969f0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *pcVar2 = '\0';
        }
    }
    if ((ppiVar6 != (int64_t **)0x0) && (in_R9D == 5)) {
        ppiVar6[1] = (int64_t *)0x0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180262800
// Address: 0x180262800
// Size: 51 bytes
// ============================================================
undefined8 fcn.180262800(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    char *pcVar3;
    char *pcVar4;
    int32_t iVar5;
    char **in_RCX;
    int32_t in_EDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar7;
    uint64_t uVar8;
    char in_R8B;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18026280e;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    pcVar3 = *in_RCX;
    uVar8 = (uint64_t)in_EDX;
    if (in_R8B == '\0') {
        *in_RCX = pcVar3 + uVar8;
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    iVar6 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RSI;
    if (0 < in_EDX) {
        do {
            uVar7 = (uint32_t)uVar8;
            if (((uVar7 < 2) || (*pcVar3 != '\0')) || (pcVar3[1] != '\0')) {
                *(char **)((int64_t)&arg_28h + iVar2) = pcVar3;
                *(uint32_t *)((int64_t)&iStackX_18 + iVar2 + -8) = uVar7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262895;
                uVar1 = fcn.180296a80(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
                if ((char)uVar1 < '\0') {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026291f;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262937;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262949;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026294e;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2));
code_r0x000180262900:
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262913;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
                    goto code_r0x000180262977;
                }
                pcVar4 = *(char **)((int64_t)&arg_28h + iVar2);
                if ((uVar1 & 1) == 0) {
                    iVar5 = *(int32_t *)((int64_t)&arg_60h + iVar2);
                } else {
                    iVar5 = ((int32_t)pcVar3 - (int32_t)pcVar4) + uVar7;
                    *(int32_t *)((int64_t)&arg_60h + iVar2) = iVar5;
                }
                if ((uVar1 & 1) == 0) {
                    pcVar4 = pcVar4 + iVar5;
                } else {
                    if (iVar6 == -1) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x1802628fb;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar2));
                        goto code_r0x000180262900;
                    }
                    iVar6 = iVar6 + 1;
                }
                iVar5 = (int32_t)pcVar3 - (int32_t)pcVar4;
            } else {
                pcVar4 = pcVar3 + 2;
                iVar6 = iVar6 + -1;
                if (iVar6 == 0) goto code_r0x0001802628dc;
                iVar5 = -2;
            }
            uVar8 = (uint64_t)(uVar7 + iVar5);
            pcVar3 = pcVar4;
        } while (0 < (int32_t)(uVar7 + iVar5));
        if (iVar6 == 0) {
code_r0x0001802628dc:
            *in_RCX = pcVar4;
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026295a;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar2));
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262972;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar2), 
                  *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                  *(int64_t *)(&stack0x00000040 + iVar2));
code_r0x000180262977:
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262984;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180262833
// Address: 0x180262833
// Size: 195 bytes
// ============================================================
undefined8 fcn.180262800(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    char *pcVar3;
    char *pcVar4;
    int32_t iVar5;
    char **in_RCX;
    int32_t in_EDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar7;
    uint64_t uVar8;
    char in_R8B;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18026280e;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    pcVar3 = *in_RCX;
    uVar8 = (uint64_t)in_EDX;
    if (in_R8B == '\0') {
        *in_RCX = pcVar3 + uVar8;
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    iVar6 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RSI;
    if (0 < in_EDX) {
        do {
            uVar7 = (uint32_t)uVar8;
            if (((uVar7 < 2) || (*pcVar3 != '\0')) || (pcVar3[1] != '\0')) {
                *(char **)((int64_t)&arg_28h + iVar2) = pcVar3;
                *(uint32_t *)((int64_t)&iStackX_18 + iVar2 + -8) = uVar7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262895;
                uVar1 = fcn.180296a80(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
                if ((char)uVar1 < '\0') {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026291f;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262937;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262949;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026294e;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2));
code_r0x000180262900:
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262913;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
                    goto code_r0x000180262977;
                }
                pcVar4 = *(char **)((int64_t)&arg_28h + iVar2);
                if ((uVar1 & 1) == 0) {
                    iVar5 = *(int32_t *)((int64_t)&arg_60h + iVar2);
                } else {
                    iVar5 = ((int32_t)pcVar3 - (int32_t)pcVar4) + uVar7;
                    *(int32_t *)((int64_t)&arg_60h + iVar2) = iVar5;
                }
                if ((uVar1 & 1) == 0) {
                    pcVar4 = pcVar4 + iVar5;
                } else {
                    if (iVar6 == -1) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x1802628fb;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar2));
                        goto code_r0x000180262900;
                    }
                    iVar6 = iVar6 + 1;
                }
                iVar5 = (int32_t)pcVar3 - (int32_t)pcVar4;
            } else {
                pcVar4 = pcVar3 + 2;
                iVar6 = iVar6 + -1;
                if (iVar6 == 0) goto code_r0x0001802628dc;
                iVar5 = -2;
            }
            uVar8 = (uint64_t)(uVar7 + iVar5);
            pcVar3 = pcVar4;
        } while (0 < (int32_t)(uVar7 + iVar5));
        if (iVar6 == 0) {
code_r0x0001802628dc:
            *in_RCX = pcVar4;
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026295a;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar2));
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262972;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar2), 
                  *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                  *(int64_t *)(&stack0x00000040 + iVar2));
code_r0x000180262977:
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262984;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1802628f6
// Address: 0x1802628f6
// Size: 162 bytes
// ============================================================
undefined8 fcn.180262800(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    char *pcVar3;
    char *pcVar4;
    int32_t iVar5;
    char **in_RCX;
    int32_t in_EDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar7;
    uint64_t uVar8;
    char in_R8B;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18026280e;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    pcVar3 = *in_RCX;
    uVar8 = (uint64_t)in_EDX;
    if (in_R8B == '\0') {
        *in_RCX = pcVar3 + uVar8;
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = unaff_RBX;
    iVar6 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RSI;
    if (0 < in_EDX) {
        do {
            uVar7 = (uint32_t)uVar8;
            if (((uVar7 < 2) || (*pcVar3 != '\0')) || (pcVar3[1] != '\0')) {
                *(char **)((int64_t)&arg_28h + iVar2) = pcVar3;
                *(uint32_t *)((int64_t)&iStackX_18 + iVar2 + -8) = uVar7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262895;
                uVar1 = fcn.180296a80(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
                if ((char)uVar1 < '\0') {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026291f;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262937;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262949;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026294e;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2));
code_r0x000180262900:
                    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262913;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
                    goto code_r0x000180262977;
                }
                pcVar4 = *(char **)((int64_t)&arg_28h + iVar2);
                if ((uVar1 & 1) == 0) {
                    iVar5 = *(int32_t *)((int64_t)&arg_60h + iVar2);
                } else {
                    iVar5 = ((int32_t)pcVar3 - (int32_t)pcVar4) + uVar7;
                    *(int32_t *)((int64_t)&arg_60h + iVar2) = iVar5;
                }
                if ((uVar1 & 1) == 0) {
                    pcVar4 = pcVar4 + iVar5;
                } else {
                    if (iVar6 == -1) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x1802628fb;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_18 + iVar2));
                        goto code_r0x000180262900;
                    }
                    iVar6 = iVar6 + 1;
                }
                iVar5 = (int32_t)pcVar3 - (int32_t)pcVar4;
            } else {
                pcVar4 = pcVar3 + 2;
                iVar6 = iVar6 + -1;
                if (iVar6 == 0) goto code_r0x0001802628dc;
                iVar5 = -2;
            }
            uVar8 = (uint64_t)(uVar7 + iVar5);
            pcVar3 = pcVar4;
        } while (0 < (int32_t)(uVar7 + iVar5));
        if (iVar6 == 0) {
code_r0x0001802628dc:
            *in_RCX = pcVar4;
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18026295a;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar2));
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262972;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar2), 
                  *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                  *(int64_t *)(&stack0x00000040 + iVar2));
code_r0x000180262977:
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x180262984;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1802629a0
// Address: 0x1802629a0
// Size: 127 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

undefined8
fcn.1802629a0(int64_t *placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             undefined8 placeholder_11, undefined8 placeholder_12, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_c0h)
{
    code *pcVar1;
    char *pcVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint8_t *puVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    uint32_t *puVar12;
    int32_t iVar13;
    undefined8 unaff_RSI;
    uint32_t uVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint8_t var_78h;
    int32_t var_74h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1802629ba;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar8 = arg_40h;
    iVar6 = -iVar6;
    iVar5 = (int32_t)placeholder_2;
    if ((placeholder_0 == (int64_t *)0x0) || (placeholder_3 == (undefined *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263535;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026354d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026355f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629e5;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629fd;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a0f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar6) = unaff_RBX;
    iVar11 = *(int64_t *)(placeholder_3 + 0x18);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RSI;
    iVar13 = 0;
    if ((iVar11 == 0) || (var_50h = *(int64_t *)(iVar11 + 0x18), var_50h == 0)) {
        var_50h = 0;
    }
    iVar10 = (int32_t)arg_48h + 1;
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_R15;
    arg_48h._0_4_ = iVar10;
    if (0x1e < iVar10) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a70;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a88;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        goto code_r0x000180262fbf;
    }
    uVar4 = 0;
    // switch table (7 cases) at 0x180263570
    switch(*placeholder_3) {
    case 0:
        if (*(int64_t *)(placeholder_3 + 8) == 0) {
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            goto code_r0x000180262b42;
        }
        if (((uint32_t)arg_28h == 0xffffffff) && ((char)arg_38h == '\0')) {
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
            iVar8 = arg_40h;
            *(int32_t *)((int64_t)&var_10h + iVar6) = iVar10;
            *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
            (&stack0x00000000)[iVar6] = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262af7;
            uVar7 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                  *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar6), *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                  *(int64_t *)(&stack0x00000088 + iVar6), *(int64_t *)(&stack0x00000090 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x000000a0 + iVar6));
            return uVar7;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262afe;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b16;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        break;
    case 1:
    case 6:
        var_48h = *(int64_t *)arg2;
        var_74h = 0;
        var_68h._0_4_ = 0x10;
        if ((uint32_t)arg_28h != 0xffffffff) {
            var_74h = (int32_t)arg_30h;
            var_68h._0_4_ = (uint32_t)arg_28h;
        }
        var_58h = var_48h;
        if (arg_40h == 0) {
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802630d4;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
code_r0x0001802630f1:
            var_68h = (int64_t)pcVar2;
            uVar3 = (uint8_t)uVar4;
            if (-1 < (char)uVar3) {
                if (-1 < (int32_t)uVar14) {
                    if ((uVar14 != (uint32_t)var_70h) || (var_74h != (int32_t)var_60h)) {
                        if ((char)arg_38h != '\0') {
                            return 0xffffffff;
                        }
                        goto code_r0x00018026316c;
                    }
                    if (arg_40h != 0) {
                        *(undefined *)arg_40h = 0;
                    }
                }
                uVar14 = (uint32_t)var_8h;
                if ((uVar4 & 1) != 0) {
                    uVar14 = ((int32_t)var_48h - (int32_t)var_68h) + iVar5;
                }
                var_78h = uVar3 & 1;
                var_8h._0_4_ = CONCAT31(var_8h._1_3_, uVar3) & 0xffffff01;
                if ((iVar11 != 0) && ((*(uint8_t *)(iVar11 + 8) & 4) != 0)) {
                    var_78h = 1;
                    uVar14 = (*(int32_t *)var_10h - (int32_t)var_68h) + iVar5;
                }
                if ((uVar4 & 0x20) == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631bd;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631d5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if (*placeholder_0 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631f7;
                        iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263200;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            goto code_r0x000180262c90;
                        }
                    }
                    if (var_50h != 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263223;
                        iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                        if (iVar5 == 0) goto code_r0x000180262f9d;
                    }
                    iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                    puVar12 = *(uint32_t **)(placeholder_3 + 8);
                    var_74h = 0;
                    if (0 < iVar5) {
                        do {
                            if ((*puVar12 & 0x300) != 0) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263256;
                                iVar8 = fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263269;
                                    fcn.1802d4420(placeholder_0, iVar8);
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263274;
                                    fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar6));
                                }
                            }
                            iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                            var_74h = var_74h + 1;
                            puVar12 = puVar12 + 8;
                        } while (var_74h < iVar5);
                    }
                    if (0 < iVar5) {
                        do {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632b1;
                            puVar9 = (uint8_t *)
                                     fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_18h + iVar6));
                            if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632c8;
                            fcn.1802d4420(placeholder_0, puVar9);
                            if (uVar14 == 0) break;
                            iVar5 = (int32_t)var_68h;
                            if (((1 < (int32_t)uVar14) && (*(char *)var_68h == '\0')) &&
                               (*(char *)(var_68h + 1) == '\0')) {
                                var_68h = var_68h + 2;
                                if ((char)var_8h == '\0') {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633df;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633f7;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    goto code_r0x000180262fbf;
                                }
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                                goto code_r0x000180263396;
                            }
                            if (iVar13 == *(int32_t *)(placeholder_3 + 0x10) + -1) {
                                uVar3 = 0;
                            } else {
                                uVar3 = *puVar9 & 1;
                            }
                            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
                            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                            *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                            *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                            (&stack0x00000000)[iVar6] = uVar3;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263339;
                            iVar10 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                   *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                                   *(int64_t *)(&stack0x00000068 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                                   *(int64_t *)(&stack0x00000088 + iVar6), 
                                                   *(int64_t *)(&stack0x00000090 + iVar6), 
                                                   *(int64_t *)(&stack0x00000098 + iVar6), 
                                                   *(int64_t *)(&stack0x000000a0 + iVar6));
                            if (iVar10 == 0) goto code_r0x000180263504;
                            if (iVar10 == -1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263356;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                            } else {
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                            }
                            iVar13 = iVar13 + 1;
                        } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    }
                    if ((char)var_8h != '\0') {
                        if ((((int32_t)uVar14 < 2) || (*(char *)var_68h != '\0')) || (*(char *)(var_68h + 1) != '\0')) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026340e;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263426;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6));
                            break;
                        }
                        var_68h = var_68h + 2;
                    }
code_r0x000180263396:
                    if ((var_78h != 0) || (uVar14 == 0)) {
                        if (iVar13 < *(int32_t *)(placeholder_3 + 0x10)) {
                            do {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263451;
                                puVar9 = (uint8_t *)
                                         fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                       *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                                if ((*puVar9 & 1) == 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634da;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634f2;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263504;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180263504:
                                    uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
code_r0x000180263508:
                                    *(undefined8 *)(&stack0x00000000 + iVar6) = uVar7;
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263529;
                                    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar6));
                                    return 0;
                                }
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026346d;
                                fcn.1802d4420(placeholder_0, puVar9);
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263478;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                iVar13 = iVar13 + 1;
                            } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026349b;
                        iVar5 = fcn.1802d4310(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6));
                        if (iVar5 != 0) {
                            if (var_50h == 0) goto code_r0x0001802634c4;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634bc;
                            iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
                            goto joined_r0x000180262f97;
                        }
                        goto code_r0x000180262f9d;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633ae;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633c6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        } else {
            if (*(char *)arg_40h != '\0') {
                var_60h._0_4_ = *(int32_t *)(arg_40h + 0x10);
                var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
                uVar4 = *(uint32_t *)(arg_40h + 4);
                var_8h._0_4_ = *(uint32_t *)(arg_40h + 8);
                pcVar2 = (char *)(*(int32_t *)(arg_40h + 0x14) + var_48h);
                uVar14 = (uint32_t)var_68h;
                goto code_r0x0001802630f1;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263067;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            *(uint32_t *)(iVar8 + 4) = uVar4;
            *(int32_t *)(iVar8 + 0x10) = (int32_t)var_60h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(uint32_t *)(iVar8 + 8) = (uint32_t)var_8h;
            *(undefined *)arg_40h = 1;
            iVar10 = (int32_t)var_58h - (int32_t)var_48h;
            *(int32_t *)(arg_40h + 0x14) = iVar10;
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
            if (((uVar4 & 0x81) != 0) || (pcVar2 = (char *)var_58h, (int32_t)(iVar10 + (uint32_t)var_8h) <= iVar5))
            goto code_r0x0001802630f1;
        }
code_r0x00018026316c:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263171;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263187;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (arg_40h != 0) {
            *(undefined *)arg_40h = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631a7;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        goto code_r0x000180262c90;
    case 2:
        if ((uint32_t)arg_28h == 0xffffffff) {
            if (var_50h == 0) {
code_r0x000180262def:
                iVar8 = arg_58h;
                if (*placeholder_0 == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ee0;
                    iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eed;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                        goto code_r0x000180262c90;
                    }
                } else {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e07;
                    iVar5 = fcn.1802d4410();
                    if ((-1 < iVar5) && (iVar5 < *(int32_t *)(placeholder_3 + 0x10))) {
                        iVar11 = *(int64_t *)(placeholder_3 + 8);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e26;
                        fcn.1802d4420(placeholder_0, (int64_t)iVar5 * 0x20 + iVar11);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e31;
                        fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6));
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e41;
                        fcn.1802d4430(placeholder_0, 0xffffffff, placeholder_3);
                    }
                }
                iVar11 = *(int64_t *)(placeholder_3 + 8);
                var_68h = *(int64_t *)var_10h;
                bVar15 = *(int32_t *)(placeholder_3 + 0x10) == 0;
                if (0 < *(int32_t *)(placeholder_3 + 0x10)) {
                    do {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e60;
                        fcn.1802d4420(placeholder_0, iVar11);
                        *(int64_t *)((int64_t)&var_20h + iVar6) = iVar8;
                        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                        *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                        (&stack0x00000000)[iVar6] = 1;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e98;
                        iVar5 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                              *(int64_t *)(&stack0x00000068 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                              *(int64_t *)(&stack0x00000088 + iVar6), 
                                              *(int64_t *)(&stack0x00000090 + iVar6), 
                                              *(int64_t *)(&stack0x00000098 + iVar6), 
                                              *(int64_t *)(&stack0x000000a0 + iVar6));
                        if (iVar5 != -1) {
                            if (iVar5 < 1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f06;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f0b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f23;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f35;
                                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
                                uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
                                if (iVar11 == 0) goto code_r0x000180262fd0;
                                goto code_r0x000180263508;
                            }
                            break;
                        }
                        iVar13 = iVar13 + 1;
                        iVar11 = iVar11 + 0x20;
                    } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    bVar15 = iVar13 == *(int32_t *)(placeholder_3 + 0x10);
                }
                if (bVar15) {
                    if ((char)arg_38h != '\0') {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eca;
                        fcn.180261290(placeholder_0, placeholder_3);
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f4c;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f64;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                    break;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f78;
                fcn.1802d4430(placeholder_0, iVar13, placeholder_3);
                if (var_50h == 0) goto code_r0x0001802634c4;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f95;
                iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
joined_r0x000180262f97:
                if (iVar5 != 0) {
code_r0x0001802634c4:
                    *(int64_t *)var_10h = var_68h;
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262de7;
                iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                if (iVar5 != 0) goto code_r0x000180262def;
            }
code_r0x000180262f9d:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fa2;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fba;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        } else {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262dc7;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262b8b:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b9e;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        }
        break;
    default:
        goto code_r0x000180262b4d;
    case 4:
        pcVar1 = *(code **)(iVar11 + 0x40);
        if (pcVar1 == (code *)0x0) {
            pcVar1 = *(code **)(iVar11 + 0x20);
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262db7;
            uVar7 = (*pcVar1)(placeholder_0, arg2);
            return uVar7;
        }
        *(int64_t *)((int64_t)&arg_28h + iVar6) = arg_58h;
        *(int64_t *)((int64_t)&var_20h + iVar6) = arg_50h;
        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
        *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
        *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d8c;
        uVar7 = (*pcVar1)();
        return uVar7;
    case 5:
        if ((uint32_t)arg_28h != 0xffffffff) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b86;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x000180262b8b;
        }
        iVar11 = *(int64_t *)arg2;
        if ((arg_40h == 0) || (*(char *)arg_40h == '\0')) {
            var_50h._0_4_ = (int32_t)iVar11;
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262bfa;
            uVar14 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                   *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            arg2 = var_10h;
            if (iVar8 == 0) goto code_r0x000180262c44;
            *(uint32_t *)(iVar8 + 4) = uVar14;
            var_50h._0_4_ = (int32_t)var_50h - (int32_t)iVar11;
            *(int32_t *)(iVar8 + 8) = var_74h;
            *(uint32_t *)(iVar8 + 0x10) = (uint32_t)var_8h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(int32_t *)(iVar8 + 0x14) = (int32_t)var_50h;
            *(undefined *)iVar8 = 1;
            if (((uVar14 & 0x81) != 0) || ((int32_t)var_50h + var_74h <= iVar5)) goto code_r0x000180262c44;
        } else {
            var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
            uVar14 = *(uint32_t *)(arg_40h + 4);
            var_8h._0_4_ = *(uint32_t *)(arg_40h + 0x10);
code_r0x000180262c44:
            if (-1 < (char)uVar14) {
                if ((char)(uint32_t)var_8h == '\0') {
                    if ((uint32_t)var_70h < 0x1f) {
                        uVar4 = *(uint32_t *)((int64_t)(int32_t)(uint32_t)var_70h * 4 + 0x1804e6c70);
                    }
                    if ((*(uint32_t *)(placeholder_3 + 4) & uVar4) != 0) {
                        *(int64_t *)((int64_t)&var_18h + iVar6) = iVar8;
                        *(undefined *)((int64_t)&var_10h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)var_70h;
                        placeholder_2 = placeholder_2 & 0xffffffff;
code_r0x000180262b42:
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b4d;
                        uVar7 = fcn.180261dd0((int64_t)placeholder_0, arg2, placeholder_2, (int64_t)placeholder_3, 
                                              *(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(undefined8 *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6));
                        return uVar7;
                    }
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d0a;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d22;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cc0;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cd8;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c59;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c6f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (iVar8 != 0) {
            *(undefined *)iVar8 = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c8b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262c90:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ca3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
    }
code_r0x000180262fbf:
    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fcc;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180262fd0:
    *(code **)((int64_t)&pcStack_28 + iVar6) = case.0x180262ab1.3;
    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6));
code_r0x000180262b4d:
    return 0;
}

// ============================================================
// Function: FUN_180262a1f
// Address: 0x180262a1f
// Size: 348 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

undefined8
fcn.1802629a0(int64_t *placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             undefined8 placeholder_11, undefined8 placeholder_12, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_c0h)
{
    code *pcVar1;
    char *pcVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint8_t *puVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    uint32_t *puVar12;
    int32_t iVar13;
    undefined8 unaff_RSI;
    uint32_t uVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint8_t var_78h;
    int32_t var_74h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1802629ba;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar8 = arg_40h;
    iVar6 = -iVar6;
    iVar5 = (int32_t)placeholder_2;
    if ((placeholder_0 == (int64_t *)0x0) || (placeholder_3 == (undefined *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263535;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026354d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026355f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629e5;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629fd;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a0f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar6) = unaff_RBX;
    iVar11 = *(int64_t *)(placeholder_3 + 0x18);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RSI;
    iVar13 = 0;
    if ((iVar11 == 0) || (var_50h = *(int64_t *)(iVar11 + 0x18), var_50h == 0)) {
        var_50h = 0;
    }
    iVar10 = (int32_t)arg_48h + 1;
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_R15;
    arg_48h._0_4_ = iVar10;
    if (0x1e < iVar10) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a70;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a88;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        goto code_r0x000180262fbf;
    }
    uVar4 = 0;
    // switch table (7 cases) at 0x180263570
    switch(*placeholder_3) {
    case 0:
        if (*(int64_t *)(placeholder_3 + 8) == 0) {
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            goto code_r0x000180262b42;
        }
        if (((uint32_t)arg_28h == 0xffffffff) && ((char)arg_38h == '\0')) {
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
            iVar8 = arg_40h;
            *(int32_t *)((int64_t)&var_10h + iVar6) = iVar10;
            *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
            (&stack0x00000000)[iVar6] = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262af7;
            uVar7 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                  *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar6), *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                  *(int64_t *)(&stack0x00000088 + iVar6), *(int64_t *)(&stack0x00000090 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x000000a0 + iVar6));
            return uVar7;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262afe;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b16;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        break;
    case 1:
    case 6:
        var_48h = *(int64_t *)arg2;
        var_74h = 0;
        var_68h._0_4_ = 0x10;
        if ((uint32_t)arg_28h != 0xffffffff) {
            var_74h = (int32_t)arg_30h;
            var_68h._0_4_ = (uint32_t)arg_28h;
        }
        var_58h = var_48h;
        if (arg_40h == 0) {
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802630d4;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
code_r0x0001802630f1:
            var_68h = (int64_t)pcVar2;
            uVar3 = (uint8_t)uVar4;
            if (-1 < (char)uVar3) {
                if (-1 < (int32_t)uVar14) {
                    if ((uVar14 != (uint32_t)var_70h) || (var_74h != (int32_t)var_60h)) {
                        if ((char)arg_38h != '\0') {
                            return 0xffffffff;
                        }
                        goto code_r0x00018026316c;
                    }
                    if (arg_40h != 0) {
                        *(undefined *)arg_40h = 0;
                    }
                }
                uVar14 = (uint32_t)var_8h;
                if ((uVar4 & 1) != 0) {
                    uVar14 = ((int32_t)var_48h - (int32_t)var_68h) + iVar5;
                }
                var_78h = uVar3 & 1;
                var_8h._0_4_ = CONCAT31(var_8h._1_3_, uVar3) & 0xffffff01;
                if ((iVar11 != 0) && ((*(uint8_t *)(iVar11 + 8) & 4) != 0)) {
                    var_78h = 1;
                    uVar14 = (*(int32_t *)var_10h - (int32_t)var_68h) + iVar5;
                }
                if ((uVar4 & 0x20) == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631bd;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631d5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if (*placeholder_0 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631f7;
                        iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263200;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            goto code_r0x000180262c90;
                        }
                    }
                    if (var_50h != 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263223;
                        iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                        if (iVar5 == 0) goto code_r0x000180262f9d;
                    }
                    iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                    puVar12 = *(uint32_t **)(placeholder_3 + 8);
                    var_74h = 0;
                    if (0 < iVar5) {
                        do {
                            if ((*puVar12 & 0x300) != 0) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263256;
                                iVar8 = fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263269;
                                    fcn.1802d4420(placeholder_0, iVar8);
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263274;
                                    fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar6));
                                }
                            }
                            iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                            var_74h = var_74h + 1;
                            puVar12 = puVar12 + 8;
                        } while (var_74h < iVar5);
                    }
                    if (0 < iVar5) {
                        do {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632b1;
                            puVar9 = (uint8_t *)
                                     fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_18h + iVar6));
                            if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632c8;
                            fcn.1802d4420(placeholder_0, puVar9);
                            if (uVar14 == 0) break;
                            iVar5 = (int32_t)var_68h;
                            if (((1 < (int32_t)uVar14) && (*(char *)var_68h == '\0')) &&
                               (*(char *)(var_68h + 1) == '\0')) {
                                var_68h = var_68h + 2;
                                if ((char)var_8h == '\0') {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633df;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633f7;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    goto code_r0x000180262fbf;
                                }
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                                goto code_r0x000180263396;
                            }
                            if (iVar13 == *(int32_t *)(placeholder_3 + 0x10) + -1) {
                                uVar3 = 0;
                            } else {
                                uVar3 = *puVar9 & 1;
                            }
                            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
                            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                            *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                            *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                            (&stack0x00000000)[iVar6] = uVar3;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263339;
                            iVar10 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                   *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                                   *(int64_t *)(&stack0x00000068 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                                   *(int64_t *)(&stack0x00000088 + iVar6), 
                                                   *(int64_t *)(&stack0x00000090 + iVar6), 
                                                   *(int64_t *)(&stack0x00000098 + iVar6), 
                                                   *(int64_t *)(&stack0x000000a0 + iVar6));
                            if (iVar10 == 0) goto code_r0x000180263504;
                            if (iVar10 == -1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263356;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                            } else {
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                            }
                            iVar13 = iVar13 + 1;
                        } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    }
                    if ((char)var_8h != '\0') {
                        if ((((int32_t)uVar14 < 2) || (*(char *)var_68h != '\0')) || (*(char *)(var_68h + 1) != '\0')) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026340e;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263426;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6));
                            break;
                        }
                        var_68h = var_68h + 2;
                    }
code_r0x000180263396:
                    if ((var_78h != 0) || (uVar14 == 0)) {
                        if (iVar13 < *(int32_t *)(placeholder_3 + 0x10)) {
                            do {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263451;
                                puVar9 = (uint8_t *)
                                         fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                       *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                                if ((*puVar9 & 1) == 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634da;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634f2;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263504;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180263504:
                                    uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
code_r0x000180263508:
                                    *(undefined8 *)(&stack0x00000000 + iVar6) = uVar7;
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263529;
                                    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar6));
                                    return 0;
                                }
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026346d;
                                fcn.1802d4420(placeholder_0, puVar9);
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263478;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                iVar13 = iVar13 + 1;
                            } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026349b;
                        iVar5 = fcn.1802d4310(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6));
                        if (iVar5 != 0) {
                            if (var_50h == 0) goto code_r0x0001802634c4;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634bc;
                            iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
                            goto joined_r0x000180262f97;
                        }
                        goto code_r0x000180262f9d;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633ae;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633c6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        } else {
            if (*(char *)arg_40h != '\0') {
                var_60h._0_4_ = *(int32_t *)(arg_40h + 0x10);
                var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
                uVar4 = *(uint32_t *)(arg_40h + 4);
                var_8h._0_4_ = *(uint32_t *)(arg_40h + 8);
                pcVar2 = (char *)(*(int32_t *)(arg_40h + 0x14) + var_48h);
                uVar14 = (uint32_t)var_68h;
                goto code_r0x0001802630f1;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263067;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            *(uint32_t *)(iVar8 + 4) = uVar4;
            *(int32_t *)(iVar8 + 0x10) = (int32_t)var_60h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(uint32_t *)(iVar8 + 8) = (uint32_t)var_8h;
            *(undefined *)arg_40h = 1;
            iVar10 = (int32_t)var_58h - (int32_t)var_48h;
            *(int32_t *)(arg_40h + 0x14) = iVar10;
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
            if (((uVar4 & 0x81) != 0) || (pcVar2 = (char *)var_58h, (int32_t)(iVar10 + (uint32_t)var_8h) <= iVar5))
            goto code_r0x0001802630f1;
        }
code_r0x00018026316c:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263171;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263187;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (arg_40h != 0) {
            *(undefined *)arg_40h = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631a7;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        goto code_r0x000180262c90;
    case 2:
        if ((uint32_t)arg_28h == 0xffffffff) {
            if (var_50h == 0) {
code_r0x000180262def:
                iVar8 = arg_58h;
                if (*placeholder_0 == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ee0;
                    iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eed;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                        goto code_r0x000180262c90;
                    }
                } else {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e07;
                    iVar5 = fcn.1802d4410();
                    if ((-1 < iVar5) && (iVar5 < *(int32_t *)(placeholder_3 + 0x10))) {
                        iVar11 = *(int64_t *)(placeholder_3 + 8);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e26;
                        fcn.1802d4420(placeholder_0, (int64_t)iVar5 * 0x20 + iVar11);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e31;
                        fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6));
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e41;
                        fcn.1802d4430(placeholder_0, 0xffffffff, placeholder_3);
                    }
                }
                iVar11 = *(int64_t *)(placeholder_3 + 8);
                var_68h = *(int64_t *)var_10h;
                bVar15 = *(int32_t *)(placeholder_3 + 0x10) == 0;
                if (0 < *(int32_t *)(placeholder_3 + 0x10)) {
                    do {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e60;
                        fcn.1802d4420(placeholder_0, iVar11);
                        *(int64_t *)((int64_t)&var_20h + iVar6) = iVar8;
                        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                        *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                        (&stack0x00000000)[iVar6] = 1;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e98;
                        iVar5 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                              *(int64_t *)(&stack0x00000068 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                              *(int64_t *)(&stack0x00000088 + iVar6), 
                                              *(int64_t *)(&stack0x00000090 + iVar6), 
                                              *(int64_t *)(&stack0x00000098 + iVar6), 
                                              *(int64_t *)(&stack0x000000a0 + iVar6));
                        if (iVar5 != -1) {
                            if (iVar5 < 1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f06;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f0b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f23;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f35;
                                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
                                uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
                                if (iVar11 == 0) goto code_r0x000180262fd0;
                                goto code_r0x000180263508;
                            }
                            break;
                        }
                        iVar13 = iVar13 + 1;
                        iVar11 = iVar11 + 0x20;
                    } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    bVar15 = iVar13 == *(int32_t *)(placeholder_3 + 0x10);
                }
                if (bVar15) {
                    if ((char)arg_38h != '\0') {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eca;
                        fcn.180261290(placeholder_0, placeholder_3);
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f4c;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f64;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                    break;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f78;
                fcn.1802d4430(placeholder_0, iVar13, placeholder_3);
                if (var_50h == 0) goto code_r0x0001802634c4;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f95;
                iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
joined_r0x000180262f97:
                if (iVar5 != 0) {
code_r0x0001802634c4:
                    *(int64_t *)var_10h = var_68h;
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262de7;
                iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                if (iVar5 != 0) goto code_r0x000180262def;
            }
code_r0x000180262f9d:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fa2;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fba;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        } else {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262dc7;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262b8b:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b9e;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        }
        break;
    default:
        goto code_r0x000180262b4d;
    case 4:
        pcVar1 = *(code **)(iVar11 + 0x40);
        if (pcVar1 == (code *)0x0) {
            pcVar1 = *(code **)(iVar11 + 0x20);
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262db7;
            uVar7 = (*pcVar1)(placeholder_0, arg2);
            return uVar7;
        }
        *(int64_t *)((int64_t)&arg_28h + iVar6) = arg_58h;
        *(int64_t *)((int64_t)&var_20h + iVar6) = arg_50h;
        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
        *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
        *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d8c;
        uVar7 = (*pcVar1)();
        return uVar7;
    case 5:
        if ((uint32_t)arg_28h != 0xffffffff) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b86;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x000180262b8b;
        }
        iVar11 = *(int64_t *)arg2;
        if ((arg_40h == 0) || (*(char *)arg_40h == '\0')) {
            var_50h._0_4_ = (int32_t)iVar11;
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262bfa;
            uVar14 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                   *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            arg2 = var_10h;
            if (iVar8 == 0) goto code_r0x000180262c44;
            *(uint32_t *)(iVar8 + 4) = uVar14;
            var_50h._0_4_ = (int32_t)var_50h - (int32_t)iVar11;
            *(int32_t *)(iVar8 + 8) = var_74h;
            *(uint32_t *)(iVar8 + 0x10) = (uint32_t)var_8h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(int32_t *)(iVar8 + 0x14) = (int32_t)var_50h;
            *(undefined *)iVar8 = 1;
            if (((uVar14 & 0x81) != 0) || ((int32_t)var_50h + var_74h <= iVar5)) goto code_r0x000180262c44;
        } else {
            var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
            uVar14 = *(uint32_t *)(arg_40h + 4);
            var_8h._0_4_ = *(uint32_t *)(arg_40h + 0x10);
code_r0x000180262c44:
            if (-1 < (char)uVar14) {
                if ((char)(uint32_t)var_8h == '\0') {
                    if ((uint32_t)var_70h < 0x1f) {
                        uVar4 = *(uint32_t *)((int64_t)(int32_t)(uint32_t)var_70h * 4 + 0x1804e6c70);
                    }
                    if ((*(uint32_t *)(placeholder_3 + 4) & uVar4) != 0) {
                        *(int64_t *)((int64_t)&var_18h + iVar6) = iVar8;
                        *(undefined *)((int64_t)&var_10h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)var_70h;
                        placeholder_2 = placeholder_2 & 0xffffffff;
code_r0x000180262b42:
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b4d;
                        uVar7 = fcn.180261dd0((int64_t)placeholder_0, arg2, placeholder_2, (int64_t)placeholder_3, 
                                              *(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(undefined8 *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6));
                        return uVar7;
                    }
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d0a;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d22;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cc0;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cd8;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c59;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c6f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (iVar8 != 0) {
            *(undefined *)iVar8 = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c8b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262c90:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ca3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
    }
code_r0x000180262fbf:
    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fcc;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180262fd0:
    *(code **)((int64_t)&pcStack_28 + iVar6) = case.0x180262ab1.3;
    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6));
code_r0x000180262b4d:
    return 0;
}

// ============================================================
// Function: FUN_180262b7b
// Address: 0x180262b7b
// Size: 2485 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

undefined8
fcn.1802629a0(int64_t *placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             undefined8 placeholder_11, undefined8 placeholder_12, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_c0h)
{
    code *pcVar1;
    char *pcVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint8_t *puVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    uint32_t *puVar12;
    int32_t iVar13;
    undefined8 unaff_RSI;
    uint32_t uVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint8_t var_78h;
    int32_t var_74h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1802629ba;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar8 = arg_40h;
    iVar6 = -iVar6;
    iVar5 = (int32_t)placeholder_2;
    if ((placeholder_0 == (int64_t *)0x0) || (placeholder_3 == (undefined *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263535;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026354d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026355f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629e5;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629fd;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a0f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar6) = unaff_RBX;
    iVar11 = *(int64_t *)(placeholder_3 + 0x18);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RSI;
    iVar13 = 0;
    if ((iVar11 == 0) || (var_50h = *(int64_t *)(iVar11 + 0x18), var_50h == 0)) {
        var_50h = 0;
    }
    iVar10 = (int32_t)arg_48h + 1;
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_R15;
    arg_48h._0_4_ = iVar10;
    if (0x1e < iVar10) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a70;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a88;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        goto code_r0x000180262fbf;
    }
    uVar4 = 0;
    // switch table (7 cases) at 0x180263570
    switch(*placeholder_3) {
    case 0:
        if (*(int64_t *)(placeholder_3 + 8) == 0) {
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            goto code_r0x000180262b42;
        }
        if (((uint32_t)arg_28h == 0xffffffff) && ((char)arg_38h == '\0')) {
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
            iVar8 = arg_40h;
            *(int32_t *)((int64_t)&var_10h + iVar6) = iVar10;
            *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
            (&stack0x00000000)[iVar6] = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262af7;
            uVar7 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                  *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar6), *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                  *(int64_t *)(&stack0x00000088 + iVar6), *(int64_t *)(&stack0x00000090 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x000000a0 + iVar6));
            return uVar7;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262afe;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b16;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        break;
    case 1:
    case 6:
        var_48h = *(int64_t *)arg2;
        var_74h = 0;
        var_68h._0_4_ = 0x10;
        if ((uint32_t)arg_28h != 0xffffffff) {
            var_74h = (int32_t)arg_30h;
            var_68h._0_4_ = (uint32_t)arg_28h;
        }
        var_58h = var_48h;
        if (arg_40h == 0) {
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802630d4;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
code_r0x0001802630f1:
            var_68h = (int64_t)pcVar2;
            uVar3 = (uint8_t)uVar4;
            if (-1 < (char)uVar3) {
                if (-1 < (int32_t)uVar14) {
                    if ((uVar14 != (uint32_t)var_70h) || (var_74h != (int32_t)var_60h)) {
                        if ((char)arg_38h != '\0') {
                            return 0xffffffff;
                        }
                        goto code_r0x00018026316c;
                    }
                    if (arg_40h != 0) {
                        *(undefined *)arg_40h = 0;
                    }
                }
                uVar14 = (uint32_t)var_8h;
                if ((uVar4 & 1) != 0) {
                    uVar14 = ((int32_t)var_48h - (int32_t)var_68h) + iVar5;
                }
                var_78h = uVar3 & 1;
                var_8h._0_4_ = CONCAT31(var_8h._1_3_, uVar3) & 0xffffff01;
                if ((iVar11 != 0) && ((*(uint8_t *)(iVar11 + 8) & 4) != 0)) {
                    var_78h = 1;
                    uVar14 = (*(int32_t *)var_10h - (int32_t)var_68h) + iVar5;
                }
                if ((uVar4 & 0x20) == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631bd;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631d5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if (*placeholder_0 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631f7;
                        iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263200;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            goto code_r0x000180262c90;
                        }
                    }
                    if (var_50h != 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263223;
                        iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                        if (iVar5 == 0) goto code_r0x000180262f9d;
                    }
                    iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                    puVar12 = *(uint32_t **)(placeholder_3 + 8);
                    var_74h = 0;
                    if (0 < iVar5) {
                        do {
                            if ((*puVar12 & 0x300) != 0) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263256;
                                iVar8 = fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263269;
                                    fcn.1802d4420(placeholder_0, iVar8);
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263274;
                                    fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar6));
                                }
                            }
                            iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                            var_74h = var_74h + 1;
                            puVar12 = puVar12 + 8;
                        } while (var_74h < iVar5);
                    }
                    if (0 < iVar5) {
                        do {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632b1;
                            puVar9 = (uint8_t *)
                                     fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_18h + iVar6));
                            if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632c8;
                            fcn.1802d4420(placeholder_0, puVar9);
                            if (uVar14 == 0) break;
                            iVar5 = (int32_t)var_68h;
                            if (((1 < (int32_t)uVar14) && (*(char *)var_68h == '\0')) &&
                               (*(char *)(var_68h + 1) == '\0')) {
                                var_68h = var_68h + 2;
                                if ((char)var_8h == '\0') {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633df;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633f7;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    goto code_r0x000180262fbf;
                                }
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                                goto code_r0x000180263396;
                            }
                            if (iVar13 == *(int32_t *)(placeholder_3 + 0x10) + -1) {
                                uVar3 = 0;
                            } else {
                                uVar3 = *puVar9 & 1;
                            }
                            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
                            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                            *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                            *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                            (&stack0x00000000)[iVar6] = uVar3;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263339;
                            iVar10 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                   *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                                   *(int64_t *)(&stack0x00000068 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                                   *(int64_t *)(&stack0x00000088 + iVar6), 
                                                   *(int64_t *)(&stack0x00000090 + iVar6), 
                                                   *(int64_t *)(&stack0x00000098 + iVar6), 
                                                   *(int64_t *)(&stack0x000000a0 + iVar6));
                            if (iVar10 == 0) goto code_r0x000180263504;
                            if (iVar10 == -1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263356;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                            } else {
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                            }
                            iVar13 = iVar13 + 1;
                        } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    }
                    if ((char)var_8h != '\0') {
                        if ((((int32_t)uVar14 < 2) || (*(char *)var_68h != '\0')) || (*(char *)(var_68h + 1) != '\0')) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026340e;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263426;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6));
                            break;
                        }
                        var_68h = var_68h + 2;
                    }
code_r0x000180263396:
                    if ((var_78h != 0) || (uVar14 == 0)) {
                        if (iVar13 < *(int32_t *)(placeholder_3 + 0x10)) {
                            do {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263451;
                                puVar9 = (uint8_t *)
                                         fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                       *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                                if ((*puVar9 & 1) == 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634da;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634f2;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263504;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180263504:
                                    uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
code_r0x000180263508:
                                    *(undefined8 *)(&stack0x00000000 + iVar6) = uVar7;
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263529;
                                    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar6));
                                    return 0;
                                }
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026346d;
                                fcn.1802d4420(placeholder_0, puVar9);
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263478;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                iVar13 = iVar13 + 1;
                            } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026349b;
                        iVar5 = fcn.1802d4310(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6));
                        if (iVar5 != 0) {
                            if (var_50h == 0) goto code_r0x0001802634c4;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634bc;
                            iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
                            goto joined_r0x000180262f97;
                        }
                        goto code_r0x000180262f9d;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633ae;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633c6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        } else {
            if (*(char *)arg_40h != '\0') {
                var_60h._0_4_ = *(int32_t *)(arg_40h + 0x10);
                var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
                uVar4 = *(uint32_t *)(arg_40h + 4);
                var_8h._0_4_ = *(uint32_t *)(arg_40h + 8);
                pcVar2 = (char *)(*(int32_t *)(arg_40h + 0x14) + var_48h);
                uVar14 = (uint32_t)var_68h;
                goto code_r0x0001802630f1;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263067;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            *(uint32_t *)(iVar8 + 4) = uVar4;
            *(int32_t *)(iVar8 + 0x10) = (int32_t)var_60h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(uint32_t *)(iVar8 + 8) = (uint32_t)var_8h;
            *(undefined *)arg_40h = 1;
            iVar10 = (int32_t)var_58h - (int32_t)var_48h;
            *(int32_t *)(arg_40h + 0x14) = iVar10;
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
            if (((uVar4 & 0x81) != 0) || (pcVar2 = (char *)var_58h, (int32_t)(iVar10 + (uint32_t)var_8h) <= iVar5))
            goto code_r0x0001802630f1;
        }
code_r0x00018026316c:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263171;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263187;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (arg_40h != 0) {
            *(undefined *)arg_40h = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631a7;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        goto code_r0x000180262c90;
    case 2:
        if ((uint32_t)arg_28h == 0xffffffff) {
            if (var_50h == 0) {
code_r0x000180262def:
                iVar8 = arg_58h;
                if (*placeholder_0 == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ee0;
                    iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eed;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                        goto code_r0x000180262c90;
                    }
                } else {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e07;
                    iVar5 = fcn.1802d4410();
                    if ((-1 < iVar5) && (iVar5 < *(int32_t *)(placeholder_3 + 0x10))) {
                        iVar11 = *(int64_t *)(placeholder_3 + 8);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e26;
                        fcn.1802d4420(placeholder_0, (int64_t)iVar5 * 0x20 + iVar11);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e31;
                        fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6));
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e41;
                        fcn.1802d4430(placeholder_0, 0xffffffff, placeholder_3);
                    }
                }
                iVar11 = *(int64_t *)(placeholder_3 + 8);
                var_68h = *(int64_t *)var_10h;
                bVar15 = *(int32_t *)(placeholder_3 + 0x10) == 0;
                if (0 < *(int32_t *)(placeholder_3 + 0x10)) {
                    do {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e60;
                        fcn.1802d4420(placeholder_0, iVar11);
                        *(int64_t *)((int64_t)&var_20h + iVar6) = iVar8;
                        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                        *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                        (&stack0x00000000)[iVar6] = 1;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e98;
                        iVar5 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                              *(int64_t *)(&stack0x00000068 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                              *(int64_t *)(&stack0x00000088 + iVar6), 
                                              *(int64_t *)(&stack0x00000090 + iVar6), 
                                              *(int64_t *)(&stack0x00000098 + iVar6), 
                                              *(int64_t *)(&stack0x000000a0 + iVar6));
                        if (iVar5 != -1) {
                            if (iVar5 < 1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f06;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f0b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f23;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f35;
                                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
                                uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
                                if (iVar11 == 0) goto code_r0x000180262fd0;
                                goto code_r0x000180263508;
                            }
                            break;
                        }
                        iVar13 = iVar13 + 1;
                        iVar11 = iVar11 + 0x20;
                    } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    bVar15 = iVar13 == *(int32_t *)(placeholder_3 + 0x10);
                }
                if (bVar15) {
                    if ((char)arg_38h != '\0') {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eca;
                        fcn.180261290(placeholder_0, placeholder_3);
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f4c;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f64;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                    break;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f78;
                fcn.1802d4430(placeholder_0, iVar13, placeholder_3);
                if (var_50h == 0) goto code_r0x0001802634c4;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f95;
                iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
joined_r0x000180262f97:
                if (iVar5 != 0) {
code_r0x0001802634c4:
                    *(int64_t *)var_10h = var_68h;
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262de7;
                iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                if (iVar5 != 0) goto code_r0x000180262def;
            }
code_r0x000180262f9d:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fa2;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fba;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        } else {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262dc7;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262b8b:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b9e;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        }
        break;
    default:
        goto code_r0x000180262b4d;
    case 4:
        pcVar1 = *(code **)(iVar11 + 0x40);
        if (pcVar1 == (code *)0x0) {
            pcVar1 = *(code **)(iVar11 + 0x20);
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262db7;
            uVar7 = (*pcVar1)(placeholder_0, arg2);
            return uVar7;
        }
        *(int64_t *)((int64_t)&arg_28h + iVar6) = arg_58h;
        *(int64_t *)((int64_t)&var_20h + iVar6) = arg_50h;
        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
        *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
        *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d8c;
        uVar7 = (*pcVar1)();
        return uVar7;
    case 5:
        if ((uint32_t)arg_28h != 0xffffffff) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b86;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x000180262b8b;
        }
        iVar11 = *(int64_t *)arg2;
        if ((arg_40h == 0) || (*(char *)arg_40h == '\0')) {
            var_50h._0_4_ = (int32_t)iVar11;
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262bfa;
            uVar14 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                   *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            arg2 = var_10h;
            if (iVar8 == 0) goto code_r0x000180262c44;
            *(uint32_t *)(iVar8 + 4) = uVar14;
            var_50h._0_4_ = (int32_t)var_50h - (int32_t)iVar11;
            *(int32_t *)(iVar8 + 8) = var_74h;
            *(uint32_t *)(iVar8 + 0x10) = (uint32_t)var_8h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(int32_t *)(iVar8 + 0x14) = (int32_t)var_50h;
            *(undefined *)iVar8 = 1;
            if (((uVar14 & 0x81) != 0) || ((int32_t)var_50h + var_74h <= iVar5)) goto code_r0x000180262c44;
        } else {
            var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
            uVar14 = *(uint32_t *)(arg_40h + 4);
            var_8h._0_4_ = *(uint32_t *)(arg_40h + 0x10);
code_r0x000180262c44:
            if (-1 < (char)uVar14) {
                if ((char)(uint32_t)var_8h == '\0') {
                    if ((uint32_t)var_70h < 0x1f) {
                        uVar4 = *(uint32_t *)((int64_t)(int32_t)(uint32_t)var_70h * 4 + 0x1804e6c70);
                    }
                    if ((*(uint32_t *)(placeholder_3 + 4) & uVar4) != 0) {
                        *(int64_t *)((int64_t)&var_18h + iVar6) = iVar8;
                        *(undefined *)((int64_t)&var_10h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)var_70h;
                        placeholder_2 = placeholder_2 & 0xffffffff;
code_r0x000180262b42:
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b4d;
                        uVar7 = fcn.180261dd0((int64_t)placeholder_0, arg2, placeholder_2, (int64_t)placeholder_3, 
                                              *(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(undefined8 *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6));
                        return uVar7;
                    }
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d0a;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d22;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cc0;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cd8;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c59;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c6f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (iVar8 != 0) {
            *(undefined *)iVar8 = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c8b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262c90:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ca3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
    }
code_r0x000180262fbf:
    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fcc;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180262fd0:
    *(code **)((int64_t)&pcStack_28 + iVar6) = case.0x180262ab1.3;
    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6));
code_r0x000180262b4d:
    return 0;
}

// ============================================================
// Function: FUN_180263530
// Address: 0x180263530
// Size: 92 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

undefined8
fcn.1802629a0(int64_t *placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             undefined8 placeholder_11, undefined8 placeholder_12, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_c0h)
{
    code *pcVar1;
    char *pcVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint8_t *puVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    uint32_t *puVar12;
    int32_t iVar13;
    undefined8 unaff_RSI;
    uint32_t uVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint8_t var_78h;
    int32_t var_74h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1802629ba;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar8 = arg_40h;
    iVar6 = -iVar6;
    iVar5 = (int32_t)placeholder_2;
    if ((placeholder_0 == (int64_t *)0x0) || (placeholder_3 == (undefined *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263535;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026354d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026355f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629e5;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802629fd;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a0f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar6) = unaff_RBX;
    iVar11 = *(int64_t *)(placeholder_3 + 0x18);
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RSI;
    iVar13 = 0;
    if ((iVar11 == 0) || (var_50h = *(int64_t *)(iVar11 + 0x18), var_50h == 0)) {
        var_50h = 0;
    }
    iVar10 = (int32_t)arg_48h + 1;
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_R15;
    arg_48h._0_4_ = iVar10;
    if (0x1e < iVar10) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a70;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262a88;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        goto code_r0x000180262fbf;
    }
    uVar4 = 0;
    // switch table (7 cases) at 0x180263570
    switch(*placeholder_3) {
    case 0:
        if (*(int64_t *)(placeholder_3 + 8) == 0) {
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            goto code_r0x000180262b42;
        }
        if (((uint32_t)arg_28h == 0xffffffff) && ((char)arg_38h == '\0')) {
            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
            iVar8 = arg_40h;
            *(int32_t *)((int64_t)&var_10h + iVar6) = iVar10;
            *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
            (&stack0x00000000)[iVar6] = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262af7;
            uVar7 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                  *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                  *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar6), *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                  *(int64_t *)(&stack0x00000088 + iVar6), *(int64_t *)(&stack0x00000090 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x000000a0 + iVar6));
            return uVar7;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262afe;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b16;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        break;
    case 1:
    case 6:
        var_48h = *(int64_t *)arg2;
        var_74h = 0;
        var_68h._0_4_ = 0x10;
        if ((uint32_t)arg_28h != 0xffffffff) {
            var_74h = (int32_t)arg_30h;
            var_68h._0_4_ = (uint32_t)arg_28h;
        }
        var_58h = var_48h;
        if (arg_40h == 0) {
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802630d4;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
code_r0x0001802630f1:
            var_68h = (int64_t)pcVar2;
            uVar3 = (uint8_t)uVar4;
            if (-1 < (char)uVar3) {
                if (-1 < (int32_t)uVar14) {
                    if ((uVar14 != (uint32_t)var_70h) || (var_74h != (int32_t)var_60h)) {
                        if ((char)arg_38h != '\0') {
                            return 0xffffffff;
                        }
                        goto code_r0x00018026316c;
                    }
                    if (arg_40h != 0) {
                        *(undefined *)arg_40h = 0;
                    }
                }
                uVar14 = (uint32_t)var_8h;
                if ((uVar4 & 1) != 0) {
                    uVar14 = ((int32_t)var_48h - (int32_t)var_68h) + iVar5;
                }
                var_78h = uVar3 & 1;
                var_8h._0_4_ = CONCAT31(var_8h._1_3_, uVar3) & 0xffffff01;
                if ((iVar11 != 0) && ((*(uint8_t *)(iVar11 + 8) & 4) != 0)) {
                    var_78h = 1;
                    uVar14 = (*(int32_t *)var_10h - (int32_t)var_68h) + iVar5;
                }
                if ((uVar4 & 0x20) == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631bd;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631d5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if (*placeholder_0 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631f7;
                        iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263200;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            goto code_r0x000180262c90;
                        }
                    }
                    if (var_50h != 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263223;
                        iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                        if (iVar5 == 0) goto code_r0x000180262f9d;
                    }
                    iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                    puVar12 = *(uint32_t **)(placeholder_3 + 8);
                    var_74h = 0;
                    if (0 < iVar5) {
                        do {
                            if ((*puVar12 & 0x300) != 0) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263256;
                                iVar8 = fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263269;
                                    fcn.1802d4420(placeholder_0, iVar8);
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263274;
                                    fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar6));
                                }
                            }
                            iVar5 = *(int32_t *)(placeholder_3 + 0x10);
                            var_74h = var_74h + 1;
                            puVar12 = puVar12 + 8;
                        } while (var_74h < iVar5);
                    }
                    if (0 < iVar5) {
                        do {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632b1;
                            puVar9 = (uint8_t *)
                                     fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&var_18h + iVar6));
                            if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802632c8;
                            fcn.1802d4420(placeholder_0, puVar9);
                            if (uVar14 == 0) break;
                            iVar5 = (int32_t)var_68h;
                            if (((1 < (int32_t)uVar14) && (*(char *)var_68h == '\0')) &&
                               (*(char *)(var_68h + 1) == '\0')) {
                                var_68h = var_68h + 2;
                                if ((char)var_8h == '\0') {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633df;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633f7;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    goto code_r0x000180262fbf;
                                }
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                                goto code_r0x000180263396;
                            }
                            if (iVar13 == *(int32_t *)(placeholder_3 + 0x10) + -1) {
                                uVar3 = 0;
                            } else {
                                uVar3 = *puVar9 & 1;
                            }
                            *(int64_t *)((int64_t)&var_20h + iVar6) = arg_58h;
                            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                            *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                            *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                            (&stack0x00000000)[iVar6] = uVar3;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263339;
                            iVar10 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                   *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                                   *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                                   *(int64_t *)(&stack0x00000068 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                                   *(int64_t *)(&stack0x00000088 + iVar6), 
                                                   *(int64_t *)(&stack0x00000090 + iVar6), 
                                                   *(int64_t *)(&stack0x00000098 + iVar6), 
                                                   *(int64_t *)(&stack0x000000a0 + iVar6));
                            if (iVar10 == 0) goto code_r0x000180263504;
                            if (iVar10 == -1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263356;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                            } else {
                                uVar14 = uVar14 + (iVar5 - (int32_t)var_68h);
                            }
                            iVar13 = iVar13 + 1;
                        } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    }
                    if ((char)var_8h != '\0') {
                        if ((((int32_t)uVar14 < 2) || (*(char *)var_68h != '\0')) || (*(char *)(var_68h + 1) != '\0')) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026340e;
                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                         );
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263426;
                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                          , *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar6));
                            break;
                        }
                        var_68h = var_68h + 2;
                    }
code_r0x000180263396:
                    if ((var_78h != 0) || (uVar14 == 0)) {
                        if (iVar13 < *(int32_t *)(placeholder_3 + 0x10)) {
                            do {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263451;
                                puVar9 = (uint8_t *)
                                         fcn.1802d3f90(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                       *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                       *(int64_t *)((int64_t)&var_18h + iVar6));
                                if (puVar9 == (uint8_t *)0x0) goto code_r0x000180262fd0;
                                if ((*puVar9 & 1) == 0) {
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634da;
                                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634f2;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263504;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180263504:
                                    uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
code_r0x000180263508:
                                    *(undefined8 *)(&stack0x00000000 + iVar6) = uVar7;
                                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263529;
                                    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar6));
                                    return 0;
                                }
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026346d;
                                fcn.1802d4420(placeholder_0, puVar9);
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263478;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                iVar13 = iVar13 + 1;
                            } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x18026349b;
                        iVar5 = fcn.1802d4310(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6));
                        if (iVar5 != 0) {
                            if (var_50h == 0) goto code_r0x0001802634c4;
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802634bc;
                            iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
                            goto joined_r0x000180262f97;
                        }
                        goto code_r0x000180262f9d;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633ae;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802633c6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        } else {
            if (*(char *)arg_40h != '\0') {
                var_60h._0_4_ = *(int32_t *)(arg_40h + 0x10);
                var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
                uVar4 = *(uint32_t *)(arg_40h + 4);
                var_8h._0_4_ = *(uint32_t *)(arg_40h + 8);
                pcVar2 = (char *)(*(int32_t *)(arg_40h + 0x14) + var_48h);
                uVar14 = (uint32_t)var_68h;
                goto code_r0x0001802630f1;
            }
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263067;
            uVar4 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            *(uint32_t *)(iVar8 + 4) = uVar4;
            *(int32_t *)(iVar8 + 0x10) = (int32_t)var_60h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(uint32_t *)(iVar8 + 8) = (uint32_t)var_8h;
            *(undefined *)arg_40h = 1;
            iVar10 = (int32_t)var_58h - (int32_t)var_48h;
            *(int32_t *)(arg_40h + 0x14) = iVar10;
            pcVar2 = (char *)var_58h;
            uVar14 = (uint32_t)var_68h;
            if (((uVar4 & 0x81) != 0) || (pcVar2 = (char *)var_58h, (int32_t)(iVar10 + (uint32_t)var_8h) <= iVar5))
            goto code_r0x0001802630f1;
        }
code_r0x00018026316c:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263171;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263187;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180263196;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (arg_40h != 0) {
            *(undefined *)arg_40h = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x1802631a7;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        goto code_r0x000180262c90;
    case 2:
        if ((uint32_t)arg_28h == 0xffffffff) {
            if (var_50h == 0) {
code_r0x000180262def:
                iVar8 = arg_58h;
                if (*placeholder_0 == 0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ee0;
                    iVar5 = fcn.180261260(placeholder_0, placeholder_3, arg_50h, arg_58h);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eed;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                        goto code_r0x000180262c90;
                    }
                } else {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e07;
                    iVar5 = fcn.1802d4410();
                    if ((-1 < iVar5) && (iVar5 < *(int32_t *)(placeholder_3 + 0x10))) {
                        iVar11 = *(int64_t *)(placeholder_3 + 8);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e26;
                        fcn.1802d4420(placeholder_0, (int64_t)iVar5 * 0x20 + iVar11);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e31;
                        fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6));
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e41;
                        fcn.1802d4430(placeholder_0, 0xffffffff, placeholder_3);
                    }
                }
                iVar11 = *(int64_t *)(placeholder_3 + 8);
                var_68h = *(int64_t *)var_10h;
                bVar15 = *(int32_t *)(placeholder_3 + 0x10) == 0;
                if (0 < *(int32_t *)(placeholder_3 + 0x10)) {
                    do {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e60;
                        fcn.1802d4420(placeholder_0, iVar11);
                        *(int64_t *)((int64_t)&var_20h + iVar6) = iVar8;
                        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_50h;
                        *(int32_t *)((int64_t)&var_10h + iVar6) = (int32_t)arg_48h;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = arg_40h;
                        (&stack0x00000000)[iVar6] = 1;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262e98;
                        iVar5 = fcn.180263590(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&stack0x00000060 + iVar6), 
                                              *(int64_t *)(&stack0x00000068 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_70h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar6), 
                                              *(int64_t *)(&stack0x00000088 + iVar6), 
                                              *(int64_t *)(&stack0x00000090 + iVar6), 
                                              *(int64_t *)(&stack0x00000098 + iVar6), 
                                              *(int64_t *)(&stack0x000000a0 + iVar6));
                        if (iVar5 != -1) {
                            if (iVar5 < 1) {
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f06;
                                fcn.1802616b0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f0b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f23;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6));
                                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f35;
                                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
                                uVar7 = *(undefined8 *)(placeholder_3 + 0x28);
                                if (iVar11 == 0) goto code_r0x000180262fd0;
                                goto code_r0x000180263508;
                            }
                            break;
                        }
                        iVar13 = iVar13 + 1;
                        iVar11 = iVar11 + 0x20;
                    } while (iVar13 < *(int32_t *)(placeholder_3 + 0x10));
                    bVar15 = iVar13 == *(int32_t *)(placeholder_3 + 0x10);
                }
                if (bVar15) {
                    if ((char)arg_38h != '\0') {
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262eca;
                        fcn.180261290(placeholder_0, placeholder_3);
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f4c;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f64;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                    break;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f78;
                fcn.1802d4430(placeholder_0, iVar13, placeholder_3);
                if (var_50h == 0) goto code_r0x0001802634c4;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262f95;
                iVar5 = (*(code *)var_50h)(5, placeholder_0, placeholder_3, 0);
joined_r0x000180262f97:
                if (iVar5 != 0) {
code_r0x0001802634c4:
                    *(int64_t *)var_10h = var_68h;
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262de7;
                iVar5 = (*(code *)var_50h)(4, placeholder_0, placeholder_3, 0);
                if (iVar5 != 0) goto code_r0x000180262def;
            }
code_r0x000180262f9d:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fa2;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fba;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        } else {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262dc7;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262b8b:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b9e;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar6));
        }
        break;
    default:
        goto code_r0x000180262b4d;
    case 4:
        pcVar1 = *(code **)(iVar11 + 0x40);
        if (pcVar1 == (code *)0x0) {
            pcVar1 = *(code **)(iVar11 + 0x20);
            *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
            *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
            *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
            *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262db7;
            uVar7 = (*pcVar1)(placeholder_0, arg2);
            return uVar7;
        }
        *(int64_t *)((int64_t)&arg_28h + iVar6) = arg_58h;
        *(int64_t *)((int64_t)&var_20h + iVar6) = arg_50h;
        *(int64_t *)((int64_t)&var_18h + iVar6) = arg_40h;
        *(char *)((int64_t)&var_10h + iVar6) = (char)arg_38h;
        *(int32_t *)((int64_t)&var_8h + iVar6) = (int32_t)arg_30h;
        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)arg_28h;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d8c;
        uVar7 = (*pcVar1)();
        return uVar7;
    case 5:
        if ((uint32_t)arg_28h != 0xffffffff) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b86;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x000180262b8b;
        }
        iVar11 = *(int64_t *)arg2;
        if ((arg_40h == 0) || (*(char *)arg_40h == '\0')) {
            var_50h._0_4_ = (int32_t)iVar11;
            *(int32_t *)(&stack0x00000000 + iVar6) = iVar5;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262bfa;
            uVar14 = fcn.180296a80(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                   *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            arg2 = var_10h;
            if (iVar8 == 0) goto code_r0x000180262c44;
            *(uint32_t *)(iVar8 + 4) = uVar14;
            var_50h._0_4_ = (int32_t)var_50h - (int32_t)iVar11;
            *(int32_t *)(iVar8 + 8) = var_74h;
            *(uint32_t *)(iVar8 + 0x10) = (uint32_t)var_8h;
            *(uint32_t *)(iVar8 + 0xc) = (uint32_t)var_70h;
            *(int32_t *)(iVar8 + 0x14) = (int32_t)var_50h;
            *(undefined *)iVar8 = 1;
            if (((uVar14 & 0x81) != 0) || ((int32_t)var_50h + var_74h <= iVar5)) goto code_r0x000180262c44;
        } else {
            var_70h._0_4_ = *(uint32_t *)(arg_40h + 0xc);
            uVar14 = *(uint32_t *)(arg_40h + 4);
            var_8h._0_4_ = *(uint32_t *)(arg_40h + 0x10);
code_r0x000180262c44:
            if (-1 < (char)uVar14) {
                if ((char)(uint32_t)var_8h == '\0') {
                    if ((uint32_t)var_70h < 0x1f) {
                        uVar4 = *(uint32_t *)((int64_t)(int32_t)(uint32_t)var_70h * 4 + 0x1804e6c70);
                    }
                    if ((*(uint32_t *)(placeholder_3 + 4) & uVar4) != 0) {
                        *(int64_t *)((int64_t)&var_18h + iVar6) = iVar8;
                        *(undefined *)((int64_t)&var_10h + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0;
                        *(uint32_t *)(&stack0x00000000 + iVar6) = (uint32_t)var_70h;
                        placeholder_2 = placeholder_2 & 0xffffffff;
code_r0x000180262b42:
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262b4d;
                        uVar7 = fcn.180261dd0((int64_t)placeholder_0, arg2, placeholder_2, (int64_t)placeholder_3, 
                                              *(int64_t *)(&stack0x00000000 + iVar6), 
                                              *(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_18h + iVar6), 
                                              *(undefined8 *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_78h + iVar6));
                        return uVar7;
                    }
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d0a;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262d22;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                } else {
                    if ((char)arg_38h != '\0') {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cc0;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262cd8;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                  *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6));
                }
                break;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c59;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c6f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
        if (iVar8 != 0) {
            *(undefined *)iVar8 = 0;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262c8b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x000180262c90:
        *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262ca3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6));
    }
code_r0x000180262fbf:
    *(undefined8 *)((int64_t)&pcStack_28 + iVar6) = 0x180262fcc;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar6));
code_r0x000180262fd0:
    *(code **)((int64_t)&pcStack_28 + iVar6) = case.0x180262ab1.3;
    fcn.180220250(*(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6));
code_r0x000180262b4d:
    return 0;
}

// ============================================================
// Function: FUN_180263590
// Address: 0x180263590
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

undefined8
fcn.180263590(int64_t arg1, int64_t arg_28h, int64_t arg_38h, int64_t arg_60h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
             int64_t arg_c8h)
{
    uint32_t uVar1;
    char *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    undefined8 uVar8;
    uint32_t uVar9;
    char **in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *pcVar11;
    int32_t in_R8D;
    uint32_t uVar12;
    uint32_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802635a4;
    var_8h = arg1;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg1 == 0) {
        return 0;
    }
    uVar1 = *in_R9;
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_R15;
    pcVar7 = *in_RDX;
    if ((uVar1 & 0x10) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_c8h + iVar6);
        *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
        *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)((int64_t)&arg_b8h + iVar6);
        *(undefined8 *)((int64_t)&var_10h + iVar6) = *(undefined8 *)((int64_t)&arg_b0h + iVar6);
        *(undefined *)((int64_t)&var_8h + iVar6) = *(undefined *)((int64_t)&arg_a8h + iVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802638fd;
        uVar8 = fcn.180263910(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar6), *(int64_t *)((int64_t)&arg_b0h + iVar6));
        return uVar8;
    }
    uVar4 = in_R9[1];
    *(undefined8 *)((int64_t)&arg_90h + iVar6) = unaff_RBX;
    pcVar2 = *(char **)((int64_t)&arg_b0h + iVar6);
    *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar6) = unaff_RDI;
    *(uint32_t *)((int64_t)&arg_40h + iVar6 + 4) = uVar4;
    *(char **)((int64_t)&arg_48h + iVar6) = pcVar7;
    if (in_R8D < 1) {
code_r0x000180263755:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026375a;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026376f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026377e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        if (pcVar2 != (char *)0x0) {
            *pcVar2 = '\0';
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026378b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    } else {
        if ((pcVar2 == (char *)0x0) || (*pcVar2 == '\0')) {
            *(int32_t *)((int64_t)&var_8h + iVar6) = in_R8D;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263678;
            uVar3 = fcn.180296a80(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
            iVar10 = *(int32_t *)((int64_t)&arg_38h + iVar6);
            uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar6 + 4);
            uVar12 = *(uint32_t *)((int64_t)&arg_40h + iVar6);
            pcVar11 = *(char **)((int64_t)&arg_48h + iVar6);
            if (pcVar2 != (char *)0x0) {
                *(uint32_t *)(pcVar2 + 4) = uVar3;
                iVar5 = (int32_t)pcVar11 - (int32_t)pcVar7;
                *(int32_t *)(pcVar2 + 8) = iVar10;
                *(uint32_t *)(pcVar2 + 0x10) = uVar9;
                *(uint32_t *)(pcVar2 + 0xc) = uVar12;
                *(int32_t *)(pcVar2 + 0x14) = iVar5;
                *pcVar2 = '\x01';
                if (((uVar3 & 0x81) == 0) && (in_R8D < iVar5 + iVar10)) goto code_r0x000180263755;
            }
            uVar4 = *(uint32_t *)((int64_t)&arg_40h + iVar6 + 4);
        } else {
            iVar10 = *(int32_t *)(pcVar2 + 8);
            pcVar11 = pcVar7 + *(int32_t *)(pcVar2 + 0x14);
            uVar9 = *(uint32_t *)(pcVar2 + 0x10);
            uVar12 = *(uint32_t *)(pcVar2 + 0xc);
            uVar3 = *(uint32_t *)(pcVar2 + 4);
            *(char **)((int64_t)&arg_48h + iVar6) = pcVar11;
            *(int32_t *)((int64_t)&arg_38h + iVar6) = iVar10;
            *(uint32_t *)((int64_t)&arg_38h + iVar6 + 4) = uVar9;
            *(uint32_t *)((int64_t)&arg_40h + iVar6) = uVar12;
        }
        if ((char)uVar3 < '\0') goto code_r0x000180263755;
        if (-1 < (int32_t)uVar4) {
            if ((uVar4 != uVar12) || ((uVar1 & 0xc0) != uVar9)) {
                if (*(char *)((int64_t)&arg_a8h + iVar6) != '\0') {
                    return 0xffffffff;
                }
                goto code_r0x000180263755;
            }
            if (pcVar2 != (char *)0x0) {
                *pcVar2 = '\0';
            }
        }
        if ((uVar3 & 1) != 0) {
            iVar10 = ((int32_t)pcVar7 - (int32_t)pcVar11) + in_R8D;
        }
        *(char **)((int64_t)&arg_88h + iVar6) = pcVar11;
        if ((uVar3 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026371e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263736;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            goto code_r0x0001802637a8;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_c8h + iVar6);
        *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
        *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)((int64_t)&arg_b8h + iVar6);
        *(char **)((int64_t)&var_10h + iVar6) = pcVar2;
        *(undefined *)((int64_t)&var_8h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263832;
        iVar5 = fcn.180263910(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar6), *(int64_t *)((int64_t)&arg_b0h + iVar6));
        if (iVar5 != 0) {
            pcVar7 = *(char **)((int64_t)&arg_88h + iVar6);
            iVar10 = ((int32_t)pcVar11 - (int32_t)pcVar7) + iVar10;
            if ((uVar3 & 1) == 0) {
                if (iVar10 == 0) goto code_r0x000180263871;
            } else if (((1 < iVar10) && (*pcVar7 == '\0')) && (pcVar7[1] == '\0')) {
                pcVar7 = pcVar7 + 2;
code_r0x000180263871:
                *in_RDX = pcVar7;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026389e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802638b3;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            goto code_r0x0001802637a8;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026383b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802637a3;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x0001802637a8:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802637b5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1802635ca
// Address: 0x1802635ca
// Size: 35 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

undefined8
fcn.180263590(int64_t arg1, int64_t arg_28h, int64_t arg_38h, int64_t arg_60h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
             int64_t arg_c8h)
{
    uint32_t uVar1;
    char *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    undefined8 uVar8;
    uint32_t uVar9;
    char **in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *pcVar11;
    int32_t in_R8D;
    uint32_t uVar12;
    uint32_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802635a4;
    var_8h = arg1;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg1 == 0) {
        return 0;
    }
    uVar1 = *in_R9;
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_R15;
    pcVar7 = *in_RDX;
    if ((uVar1 & 0x10) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_c8h + iVar6);
        *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
        *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)((int64_t)&arg_b8h + iVar6);
        *(undefined8 *)((int64_t)&var_10h + iVar6) = *(undefined8 *)((int64_t)&arg_b0h + iVar6);
        *(undefined *)((int64_t)&var_8h + iVar6) = *(undefined *)((int64_t)&arg_a8h + iVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802638fd;
        uVar8 = fcn.180263910(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar6), *(int64_t *)((int64_t)&arg_b0h + iVar6));
        return uVar8;
    }
    uVar4 = in_R9[1];
    *(undefined8 *)((int64_t)&arg_90h + iVar6) = unaff_RBX;
    pcVar2 = *(char **)((int64_t)&arg_b0h + iVar6);
    *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar6) = unaff_RDI;
    *(uint32_t *)((int64_t)&arg_40h + iVar6 + 4) = uVar4;
    *(char **)((int64_t)&arg_48h + iVar6) = pcVar7;
    if (in_R8D < 1) {
code_r0x000180263755:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026375a;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026376f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026377e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        if (pcVar2 != (char *)0x0) {
            *pcVar2 = '\0';
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026378b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    } else {
        if ((pcVar2 == (char *)0x0) || (*pcVar2 == '\0')) {
            *(int32_t *)((int64_t)&var_8h + iVar6) = in_R8D;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263678;
            uVar3 = fcn.180296a80(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
            iVar10 = *(int32_t *)((int64_t)&arg_38h + iVar6);
            uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar6 + 4);
            uVar12 = *(uint32_t *)((int64_t)&arg_40h + iVar6);
            pcVar11 = *(char **)((int64_t)&arg_48h + iVar6);
            if (pcVar2 != (char *)0x0) {
                *(uint32_t *)(pcVar2 + 4) = uVar3;
                iVar5 = (int32_t)pcVar11 - (int32_t)pcVar7;
                *(int32_t *)(pcVar2 + 8) = iVar10;
                *(uint32_t *)(pcVar2 + 0x10) = uVar9;
                *(uint32_t *)(pcVar2 + 0xc) = uVar12;
                *(int32_t *)(pcVar2 + 0x14) = iVar5;
                *pcVar2 = '\x01';
                if (((uVar3 & 0x81) == 0) && (in_R8D < iVar5 + iVar10)) goto code_r0x000180263755;
            }
            uVar4 = *(uint32_t *)((int64_t)&arg_40h + iVar6 + 4);
        } else {
            iVar10 = *(int32_t *)(pcVar2 + 8);
            pcVar11 = pcVar7 + *(int32_t *)(pcVar2 + 0x14);
            uVar9 = *(uint32_t *)(pcVar2 + 0x10);
            uVar12 = *(uint32_t *)(pcVar2 + 0xc);
            uVar3 = *(uint32_t *)(pcVar2 + 4);
            *(char **)((int64_t)&arg_48h + iVar6) = pcVar11;
            *(int32_t *)((int64_t)&arg_38h + iVar6) = iVar10;
            *(uint32_t *)((int64_t)&arg_38h + iVar6 + 4) = uVar9;
            *(uint32_t *)((int64_t)&arg_40h + iVar6) = uVar12;
        }
        if ((char)uVar3 < '\0') goto code_r0x000180263755;
        if (-1 < (int32_t)uVar4) {
            if ((uVar4 != uVar12) || ((uVar1 & 0xc0) != uVar9)) {
                if (*(char *)((int64_t)&arg_a8h + iVar6) != '\0') {
                    return 0xffffffff;
                }
                goto code_r0x000180263755;
            }
            if (pcVar2 != (char *)0x0) {
                *pcVar2 = '\0';
            }
        }
        if ((uVar3 & 1) != 0) {
            iVar10 = ((int32_t)pcVar7 - (int32_t)pcVar11) + in_R8D;
        }
        *(char **)((int64_t)&arg_88h + iVar6) = pcVar11;
        if ((uVar3 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026371e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263736;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            goto code_r0x0001802637a8;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_c8h + iVar6);
        *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
        *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)((int64_t)&arg_b8h + iVar6);
        *(char **)((int64_t)&var_10h + iVar6) = pcVar2;
        *(undefined *)((int64_t)&var_8h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263832;
        iVar5 = fcn.180263910(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar6), *(int64_t *)((int64_t)&arg_b0h + iVar6));
        if (iVar5 != 0) {
            pcVar7 = *(char **)((int64_t)&arg_88h + iVar6);
            iVar10 = ((int32_t)pcVar11 - (int32_t)pcVar7) + iVar10;
            if ((uVar3 & 1) == 0) {
                if (iVar10 == 0) goto code_r0x000180263871;
            } else if (((1 < iVar10) && (*pcVar7 == '\0')) && (pcVar7[1] == '\0')) {
                pcVar7 = pcVar7 + 2;
code_r0x000180263871:
                *in_RDX = pcVar7;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026389e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802638b3;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            goto code_r0x0001802637a8;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026383b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802637a3;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x0001802637a8:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802637b5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1802635ed
// Address: 0x1802635ed
// Size: 482 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

undefined8
fcn.180263590(int64_t arg1, int64_t arg_28h, int64_t arg_38h, int64_t arg_60h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
             int64_t arg_c8h)
{
    uint32_t uVar1;
    char *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    undefined8 uVar8;
    uint32_t uVar9;
    char **in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *pcVar11;
    int32_t in_R8D;
    uint32_t uVar12;
    uint32_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802635a4;
    var_8h = arg1;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg1 == 0) {
        return 0;
    }
    uVar1 = *in_R9;
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_R15;
    pcVar7 = *in_RDX;
    if ((uVar1 & 0x10) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_c8h + iVar6);
        *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
        *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)((int64_t)&arg_b8h + iVar6);
        *(undefined8 *)((int64_t)&var_10h + iVar6) = *(undefined8 *)((int64_t)&arg_b0h + iVar6);
        *(undefined *)((int64_t)&var_8h + iVar6) = *(undefined *)((int64_t)&arg_a8h + iVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802638fd;
        uVar8 = fcn.180263910(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar6), *(int64_t *)((int64_t)&arg_b0h + iVar6));
        return uVar8;
    }
    uVar4 = in_R9[1];
    *(undefined8 *)((int64_t)&arg_90h + iVar6) = unaff_RBX;
    pcVar2 = *(char **)((int64_t)&arg_b0h + iVar6);
    *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar6) = unaff_RDI;
    *(uint32_t *)((int64_t)&arg_40h + iVar6 + 4) = uVar4;
    *(char **)((int64_t)&arg_48h + iVar6) = pcVar7;
    if (in_R8D < 1) {
code_r0x000180263755:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026375a;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026376f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026377e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        if (pcVar2 != (char *)0x0) {
            *pcVar2 = '\0';
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026378b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    } else {
        if ((pcVar2 == (char *)0x0) || (*pcVar2 == '\0')) {
            *(int32_t *)((int64_t)&var_8h + iVar6) = in_R8D;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263678;
            uVar3 = fcn.180296a80(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
            iVar10 = *(int32_t *)((int64_t)&arg_38h + iVar6);
            uVar9 = *(uint32_t *)((int64_t)&arg_38h + iVar6 + 4);
            uVar12 = *(uint32_t *)((int64_t)&arg_40h + iVar6);
            pcVar11 = *(char **)((int64_t)&arg_48h + iVar6);
            if (pcVar2 != (char *)0x0) {
                *(uint32_t *)(pcVar2 + 4) = uVar3;
                iVar5 = (int32_t)pcVar11 - (int32_t)pcVar7;
                *(int32_t *)(pcVar2 + 8) = iVar10;
                *(uint32_t *)(pcVar2 + 0x10) = uVar9;
                *(uint32_t *)(pcVar2 + 0xc) = uVar12;
                *(int32_t *)(pcVar2 + 0x14) = iVar5;
                *pcVar2 = '\x01';
                if (((uVar3 & 0x81) == 0) && (in_R8D < iVar5 + iVar10)) goto code_r0x000180263755;
            }
            uVar4 = *(uint32_t *)((int64_t)&arg_40h + iVar6 + 4);
        } else {
            iVar10 = *(int32_t *)(pcVar2 + 8);
            pcVar11 = pcVar7 + *(int32_t *)(pcVar2 + 0x14);
            uVar9 = *(uint32_t *)(pcVar2 + 0x10);
            uVar12 = *(uint32_t *)(pcVar2 + 0xc);
            uVar3 = *(uint32_t *)(pcVar2 + 4);
            *(char **)((int64_t)&arg_48h + iVar6) = pcVar11;
            *(int32_t *)((int64_t)&arg_38h + iVar6) = iVar10;
            *(uint32_t *)((int64_t)&arg_38h + iVar6 + 4) = uVar9;
            *(uint32_t *)((int64_t)&arg_40h + iVar6) = uVar12;
        }
        if ((char)uVar3 < '\0') goto code_r0x000180263755;
        if (-1 < (int32_t)uVar4) {
            if ((uVar4 != uVar12) || ((uVar1 & 0xc0) != uVar9)) {
                if (*(char *)((int64_t)&arg_a8h + iVar6) != '\0') {
                    return 0xffffffff;
                }
                goto code_r0x000180263755;
            }
            if (pcVar2 != (char *)0x0) {
                *pcVar2 = '\0';
            }
        }
        if ((uVar3 & 1) != 0) {
            iVar10 = ((int32_t)pcVar7 - (int32_t)pcVar11) + in_R8D;
        }
        *(char **)((int64_t)&arg_88h + iVar6) = pcVar11;
        if ((uVar3 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026371e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263736;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            goto code_r0x0001802637a8;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)((int64_t)&arg_c8h + iVar6);
        *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
        *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)((int64_t)&arg_b8h + iVar6);
        *(char **)((int64_t)&var_10h + iVar6) = pcVar2;
        *(undefined *)((int64_t)&var_8h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180263832;
        iVar5 = fcn.180263910(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar6), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar6), *(int64_t *)((int64_t)&arg_b0h + iVar6));
        if (iVar5 != 0) {
            pcVar7 = *(char **)((int64_t)&arg_88h + iVar6);
            iVar10 = ((int32_t)pcVar11 - (int32_t)pcVar7) + iVar10;
            if ((uVar3 & 1) == 0) {
                if (iVar10 == 0) goto code_r0x000180263871;
            } else if (((1 < iVar10) && (*pcVar7 == '\0')) && (pcVar7[1] == '\0')) {
                pcVar7 = pcVar7 + 2;
code_r0x000180263871:
                *in_RDX = pcVar7;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026389e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802638b3;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            goto code_r0x0001802637a8;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18026383b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802637a3;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x0001802637a8:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802637b5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

