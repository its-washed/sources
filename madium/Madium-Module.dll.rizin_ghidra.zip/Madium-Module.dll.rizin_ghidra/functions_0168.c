// Chunk 168 - 50 functions

// ============================================================
// Function: FUN_180223550
// Address: 0x180223550
// Size: 254 bytes
// ============================================================
int64_t fcn.180223550(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 *in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180223565;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223573;
    uVar3 = fcn.180498cd0();
    if (uVar3 < 2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223581;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223599;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802235ab;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802235da;
    iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    if (iVar4 != 0) {
        if (in_RDX != (undefined4 *)0x0) {
            *in_RDX = 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
        *(undefined *)((int64_t)&var_18h + iVar2) = 0x3a;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022360e;
        iVar1 = fcn.180223a60(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000088 + iVar2));
        if (iVar1 != 0) {
            if (in_RDX == (undefined4 *)0x0) {
                return iVar4;
            }
            *in_RDX = *(undefined4 *)((int64_t)&arg_48h + iVar2);
            return iVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223637;
        fcn.180224990(iVar4, 0x1804bf850, 0x118);
    }
    return 0;
}

// ============================================================
// Function: FUN_180223650
// Address: 0x180223650
// Size: 31 bytes
// ============================================================
undefined8 fcn.180223650(int64_t arg_60h)
{
    char cVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    uint8_t *puVar7;
    undefined8 unaff_RBP;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    uint8_t uVar9;
    undefined8 unaff_RDI;
    uint64_t *in_R8;
    uint8_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined *)((int64_t)&arg_60h + iVar5) = *(undefined *)((int64_t)&arg_60h + iVar5);
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RBP;
    *(undefined8 *)(&stack0x00000058 + iVar5) = unaff_RSI;
    *(uint64_t **)(&stack0x00000050 + iVar5) = in_R8;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RDI;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 0x18) = unaff_R13;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5) = 0x180223a87;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = *in_R9;
    uVar8 = 0;
    if (uVar9 != 0) {
        cVar1 = (&stack0x00000080)[iVar6 + iVar5];
        do {
            puVar7 = in_R9 + 1;
            if (((uint32_t)uVar9 != (int32_t)cVar1) || (cVar1 == '\0')) {
                uVar2 = *puVar7;
                puVar7 = in_R9 + 2;
                if (uVar2 == 0) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223bae;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223bc6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223bd8;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223ad4;
                iVar3 = func_0x000180223440();
                *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223ae0;
                iVar4 = func_0x000180223440(uVar9);
                if ((iVar3 < 0) || (iVar4 < 0)) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223b78;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223b90;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223ba2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                    return 0;
                }
                uVar8 = uVar8 + 1;
                if (in_RCX != (uint8_t *)0x0) {
                    if (in_RDX < uVar8) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223b45;
                        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                      *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223b5d;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                      *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                      *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                                      *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180223b6f;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                        return 0;
                    }
                    *in_RCX = (char)iVar4 << 4 | (uint8_t)iVar3;
                    in_RCX = in_RCX + 1;
                }
            }
            uVar9 = *puVar7;
            in_R9 = puVar7;
        } while (uVar9 != 0);
        in_R8 = *(uint64_t **)(&stack0x00000070 + iVar6 + iVar5);
    }
    if (in_R8 != (uint64_t *)0x0) {
        *in_R8 = uVar8;
    }
    return 1;
}

// ============================================================
// Function: FUN_180223670
// Address: 0x180223670
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180223670(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    char *in_RCX;
    char *in_RDX;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180223690;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    cVar1 = *in_RDX;
    cVar2 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802236a4;
    iVar3 = func_0x0001802754c0((int32_t)cVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802236ad;
    iVar4 = func_0x0001802754c0((int32_t)cVar2);
    iVar4 = iVar4 - iVar3;
    if (iVar4 == 0) {
        iVar6 = (int64_t)in_RDX - (int64_t)in_RCX;
        do {
            cVar1 = *in_RCX;
            in_RCX = in_RCX + 1;
            if (cVar1 == '\0') {
                return 0;
            }
            cVar1 = *in_RCX;
            cVar2 = in_RCX[iVar6];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802236d8;
            iVar4 = func_0x0001802754c0((int32_t)cVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802236e1;
            iVar3 = func_0x0001802754c0((int32_t)cVar2);
            iVar4 = iVar4 - iVar3;
        } while (iVar4 == 0);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180223710
// Address: 0x180223710
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180223710(int64_t arg_28h)
{
    int64_t iVar1;
    char *in_RCX;
    char *in_RDX;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180223720;
    iVar1 = fcn.18045a350();
    iVar3 = 0;
    iVar2 = iVar3;
    for (; (in_R8 != 0 && (*in_RCX != '\0')); in_RCX = in_RCX + 1) {
        iVar2 = iVar2 + 1;
        in_R8 = in_R8 - 1;
    }
    for (; 1 < in_R8; in_R8 = in_R8 - 1) {
        if (*in_RDX == '\0') goto code_r0x000180223767;
        *in_RCX = *in_RDX;
        in_RDX = in_RDX + 1;
        in_RCX = in_RCX + 1;
        iVar3 = iVar3 + 1;
    }
    if (in_R8 != 0) {
code_r0x000180223767:
        *in_RCX = '\0';
    }
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180223772;
    iVar1 = fcn.180498cd0(in_RDX);
    return iVar1 + iVar3 + iVar2;
}

// ============================================================
// Function: FUN_180223790
// Address: 0x180223790
// Size: 75 bytes
// ============================================================
int64_t fcn.180223790(char *param_1, char *param_2, uint64_t param_3)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022379c;
    iVar1 = fcn.18045a350();
    iVar2 = 0;
    for (; 1 < param_3; param_3 = param_3 - 1) {
        if (*param_2 == '\0') goto code_r0x0001802237c7;
        *param_1 = *param_2;
        param_2 = param_2 + 1;
        param_1 = param_1 + 1;
        iVar2 = iVar2 + 1;
    }
    if (param_3 != 0) {
code_r0x0001802237c7:
        *param_1 = '\0';
    }
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1802237d2;
    iVar1 = fcn.180498cd0(param_2);
    return iVar1 + iVar2;
}

// ============================================================
// Function: FUN_1802237e0
// Address: 0x1802237e0
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1802237e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    char *in_RCX;
    char *in_RDX;
    uint64_t uVar6;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802237fe;
    iVar5 = fcn.18045a350();
    uVar6 = 0;
    if (in_R8 != 0) {
        do {
            cVar1 = *in_RCX;
            cVar2 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + -iVar5) = 0x18022381d;
            iVar3 = func_0x0001802754c0((int32_t)cVar1);
            *(undefined8 *)((int64_t)&uStack_20 + -iVar5) = 0x180223826;
            iVar4 = func_0x0001802754c0((int32_t)cVar2);
            in_RDX = in_RDX + 1;
            if (iVar3 - iVar4 != 0) {
                return iVar3 - iVar4;
            }
            cVar1 = *in_RCX;
            in_RCX = in_RCX + 1;
        } while ((cVar1 != '\0') && (uVar6 = uVar6 + 1, uVar6 < in_R8));
    }
    return 0;
}

// ============================================================
// Function: FUN_180223880
// Address: 0x180223880
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180223880(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int32_t *piVar4;
    char *in_RCX;
    char **in_RDX;
    char **ppcVar5;
    uint64_t in_R8;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022389e;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    ppcVar5 = (char **)((int64_t)&var_8h + iVar2);
    if (in_RDX != (char **)0x0) {
        ppcVar5 = in_RDX;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802238be;
    puVar3 = (undefined4 *)fcn.18046b77c();
    *puVar3 = 0;
    *ppcVar5 = in_RCX;
    if (((in_R9 != (undefined4 *)0x0) && (in_RCX != (char *)0x0)) && (*in_RCX != '-')) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802238e2;
        uVar1 = func_0x00018046c694(in_RCX, ppcVar5, in_R8 & 0xffffffff);
        *in_R9 = uVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802238ea;
        piVar4 = (int32_t *)fcn.18046b77c();
        if ((*piVar4 == 0) && ((in_RDX != (char **)0x0 || (**ppcVar5 == '\0')))) {
            return in_RCX != *ppcVar5;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180223930
// Address: 0x180223930
// Size: 298 bytes
// ============================================================
undefined8 fcn.180223930(int64_t arg_48h, int64_t arg_50h)
{
    char cVar1;
    uint8_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *in_RCX;
    uint64_t uVar5;
    uint64_t in_RDX;
    uint64_t uVar6;
    uint64_t *in_R8;
    int64_t in_R9;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022393c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar3 = *(uint64_t *)((int64_t)&arg_48h + iVar4);
    cVar1 = *(char *)((int64_t)&arg_50h + iVar4);
    uVar6 = uVar3 * 3;
    if (cVar1 == '\0') {
        uVar6 = uVar3 * 2 + 1;
    }
    uVar5 = 1;
    if (uVar6 != 0) {
        uVar5 = uVar6;
    }
    if (in_R8 != (uint64_t *)0x0) {
        *in_R8 = uVar5;
    }
    if (in_RCX != (undefined *)0x0) {
        if (in_RDX < uVar5) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180223983;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022399b;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802239ad;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
            return 0;
        }
        uVar6 = 0;
        if (uVar3 != 0) {
            if (cVar1 == '\0') {
                do {
                    uVar2 = *(uint8_t *)(in_R9 + uVar6);
                    uVar6 = uVar6 + 1;
                    *in_RCX = *(undefined *)((uint64_t)(uVar2 >> 4) + 0x1804bf828);
                    in_RCX[1] = *(undefined *)((uint64_t)(uVar2 & 0xf) + 0x1804bf828);
                    in_RCX = in_RCX + 2;
                } while (uVar6 < uVar3);
                *in_RCX = 0;
                return 1;
            }
            do {
                uVar2 = *(uint8_t *)(in_R9 + uVar6);
                uVar6 = uVar6 + 1;
                *in_RCX = *(undefined *)((uint64_t)(uVar2 >> 4) + 0x1804bf828);
                in_RCX[1] = *(undefined *)((uint64_t)(uVar2 & 0xf) + 0x1804bf828);
                in_RCX[2] = cVar1;
                in_RCX = in_RCX + 3;
            } while (uVar6 < uVar3);
        }
        if ((cVar1 != '\0') && (uVar3 != 0)) {
            in_RCX = in_RCX + -1;
        }
        *in_RCX = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180223a60
// Address: 0x180223a60
// Size: 383 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8
fcn.180223a60(uint8_t *placeholder_0, uint64_t placeholder_1, int64_t arg3, uint8_t *placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_98h)
{
    char cVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t *puVar6;
    uint64_t uVar7;
    uint8_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x180223a87;
    var_18h = arg3;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar8 = *placeholder_3;
    uVar7 = 0;
    if (uVar8 != 0) {
        cVar1 = (&stack0x00000048)[iVar5];
        do {
            puVar6 = placeholder_3 + 1;
            if (((uint32_t)uVar8 != (int32_t)cVar1) || (cVar1 == '\0')) {
                uVar2 = *puVar6;
                puVar6 = placeholder_3 + 2;
                if (uVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223bae;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                 );
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223bc6;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223bd8;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223ad4;
                iVar3 = func_0x000180223440();
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223ae0;
                iVar4 = func_0x000180223440(uVar8);
                if ((iVar3 < 0) || (iVar4 < 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223b78;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                 );
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223b90;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223ba2;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                    return 0;
                }
                uVar7 = uVar7 + 1;
                if (placeholder_0 != (uint8_t *)0x0) {
                    if (placeholder_1 < uVar7) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223b45;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223b5d;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180223b6f;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        return 0;
                    }
                    *placeholder_0 = (char)iVar4 << 4 | (uint8_t)iVar3;
                    placeholder_0 = placeholder_0 + 1;
                }
            }
            uVar8 = *puVar6;
            placeholder_3 = puVar6;
        } while (uVar8 != 0);
        arg3 = *(int64_t *)((int64_t)&arg_38h + iVar5);
    }
    if ((uint64_t *)arg3 != (uint64_t *)0x0) {
        *(uint64_t *)arg3 = uVar7;
    }
    return 1;
}

// ============================================================
// Function: FUN_180223be0
// Address: 0x180223be0
// Size: 47 bytes
// ============================================================
bool fcn.180223be0(uint64_t param_1, undefined8 param_2, undefined8 param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x180223bea;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x180223c01;
    iVar1 = fcn.180473740(param_2, param_3, param_1 & 0xffffffff);
    return iVar1 == 0;
}

// ============================================================
// Function: FUN_180223c10
// Address: 0x180223c10
// Size: 221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180223c10(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined in_R8B;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180223c26;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_EDX == 0) {
        uVar5 = 1;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = *(undefined8 *)((int64_t)&arg_48h + iVar2);
        *(undefined8 *)(&stack0x00000028 + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x180224d70;
        iVar3 = fcn.18045a350(1, 0x1804bf850, 0x152);
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&var_20h + iVar3 + iVar2) = 0x180224d7b;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar3 + iVar2) = 0x180224d90;
            fcn.1804986e0(iVar4, 0, uVar5);
        }
        return iVar4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223c8f;
    iVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    if (iVar3 != 0) {
        *(undefined *)((int64_t)&var_20h + iVar2) = in_R8B;
        *(int64_t *)((int64_t)&var_18h + iVar2) = (int64_t)in_EDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223cb2;
        iVar1 = fcn.180223930(*(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2));
        if (iVar1 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223cd0;
        fcn.180224990(iVar3, 0x1804bf850, 0x15a);
    }
    return 0;
}

// ============================================================
// Function: FUN_180223d20
// Address: 0x180223d20
// Size: 647 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.180223d20(int64_t arg_68h, int64_t arg_d0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    uint64_t uVar12;
    uint32_t in_ECX;
    undefined8 *in_RDX;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    undefined8 *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x180223d3a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_68h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7);
    uVar14 = 0;
    *in_RDX = *in_R8;
    *(undefined8 **)(&stack0x00000000 + iVar7) = in_R8;
    *(undefined8 **)((int64_t)&var_8h + iVar7) = in_RDX;
    if (in_R8[1] == 0) goto code_r0x000180223f7c;
    uVar10 = *in_R8;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223d7c;
    piVar8 = (int64_t *)func_0x000180245d40(uVar10);
    if (piVar8 == (int64_t *)0x0) goto code_r0x000180223f7c;
    if (0x11 < in_ECX) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223f49;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223f61;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223f73;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar7));
        goto code_r0x000180223f7c;
    }
    if (*piVar8 == 0) goto code_r0x000180223f7c;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223da2;
    iVar5 = func_0x000180222850();
    if ((iVar5 == 0) || (piVar1 = piVar8 + (int64_t)(int32_t)in_ECX + 1, piVar1 == (int64_t *)0x0))
    goto code_r0x000180223f7c;
    iVar2 = *piVar1;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223dc4;
    iVar5 = func_0x000180222010(iVar2);
    uVar10 = in_R8[1];
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223dcf;
    iVar6 = func_0x000180222010(uVar10);
    if (iVar6 < iVar5) {
        iVar5 = iVar6;
    }
    *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar5;
    uVar9 = uVar14;
    if (iVar5 < 1) {
code_r0x000180223e4c:
        iVar2 = *piVar8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223e58;
        func_0x000180222910(iVar2);
        if (iVar5 == 0) goto code_r0x000180223f7c;
    } else {
        if (iVar5 < 10) {
            uVar9 = (int64_t)&var_18h + iVar7;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223e06;
            uVar9 = func_0x000180224ed0((int64_t)iVar5, 8, 0x1804bf898, 0x131);
            if (uVar9 == 0) goto code_r0x000180223e4c;
        }
        if (iVar5 < 1) goto code_r0x000180223e4c;
        uVar13 = uVar14;
        uVar15 = uVar14;
        do {
            iVar2 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223e2b;
            uVar10 = func_0x000180222340(iVar2, uVar15);
            *(undefined8 *)(uVar9 + uVar13 * 8) = uVar10;
            uVar15 = (uint64_t)((int32_t)uVar15 + 1);
            uVar13 = uVar13 + 1;
        } while ((int64_t)uVar13 < (int64_t)iVar5);
        iVar2 = *piVar8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223e42;
        func_0x000180222910(iVar2);
        in_R8 = *(undefined8 **)(&stack0x00000000 + iVar7);
    }
    if (uVar9 != 0) {
        uVar10 = *(undefined8 *)((int64_t)&var_8h + iVar7);
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223e79;
        uVar11 = func_0x0001802241d0(uVar10, iVar5 + -1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223e87;
        iVar6 = func_0x000180224450(uVar10, iVar5 + -1, uVar11);
        if ((iVar6 != 0) && (uVar13 = uVar14, uVar15 = uVar14, 0 < iVar5)) {
            do {
                uVar12 = uVar14;
                if (in_R8[1] != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223eae;
                    iVar5 = func_0x000180222010();
                    if ((int32_t)uVar13 < iVar5) {
                        uVar11 = in_R8[1];
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223ebd;
                        uVar12 = func_0x000180222340(uVar11, uVar13);
                    }
                }
                *(uint64_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar12;
                puVar3 = *(undefined4 **)(uVar9 + uVar15 * 8);
                if ((puVar3 != (undefined4 *)0x0) && (pcVar4 = *(code **)(puVar3 + 10), pcVar4 != (code *)0x0)) {
                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar7) = *(undefined8 *)(puVar3 + 2);
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = *puVar3;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223efa;
                    iVar5 = (*pcVar4)(uVar10, in_R8, &stack0xfffffffffffffff8 + iVar7, uVar13);
                    if (iVar5 == 0) break;
                    uVar12 = *(uint64_t *)(&stack0xfffffffffffffff8 + iVar7);
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223f10;
                func_0x000180224450(uVar10, uVar13, uVar12);
                uVar15 = uVar15 + 1;
                uVar13 = (uint64_t)((int32_t)uVar13 + 1);
            } while ((int64_t)uVar15 < *(int64_t *)((int64_t)&var_10h + iVar7));
        }
        if (uVar9 != (int64_t)&var_18h + iVar7) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223f40;
            fcn.180224990(uVar9, 0x1804bf898, 0x151);
        }
    }
code_r0x000180223f7c:
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223f8c;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180223fb0
// Address: 0x180223fb0
// Size: 534 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180223fb0(int64_t arg_a8h, int64_t arg_110h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    undefined8 *puVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    uint32_t in_ECX;
    undefined8 in_RDX;
    undefined8 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined8 *in_R8;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x180223fca;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_a8h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7);
    uVar10 = *in_R8;
    puVar9 = (undefined8 *)0x0;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180223ff5;
    piVar8 = (int64_t *)func_0x000180245d40(uVar10);
    if (piVar8 == (int64_t *)0x0) goto code_r0x000180224183;
    if (0x11 < in_ECX) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180224159;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180224171;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180224183;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar7));
        goto code_r0x000180224183;
    }
    if (*piVar8 == 0) goto code_r0x000180224183;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022401b;
    iVar5 = func_0x000180222850();
    if ((iVar5 == 0) || (piVar1 = piVar8 + (int64_t)(int32_t)in_ECX + 1, piVar1 == (int64_t *)0x0))
    goto code_r0x000180224183;
    iVar14 = *piVar1;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022403c;
    iVar5 = func_0x000180222010(iVar14);
    iVar14 = (int64_t)iVar5;
    if (0 < iVar5) {
        if (iVar5 < 10) {
            puVar9 = (undefined8 *)((int64_t)aiStackX_8 + iVar7);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180224069;
            puVar9 = (undefined8 *)func_0x000180224ed0(iVar14, 0x10, 0x1804bf898, 0x185);
            if (puVar9 == (undefined8 *)0x0) goto code_r0x00018022409c;
        }
        iVar5 = 0;
        iVar13 = iVar14;
        puVar12 = puVar9;
        if (0 < iVar14) {
            do {
                iVar2 = *piVar1;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022408a;
                uVar10 = func_0x000180222340(iVar2, iVar5);
                *(int32_t *)(puVar12 + 1) = iVar5;
                iVar5 = iVar5 + 1;
                *puVar12 = uVar10;
                iVar13 = iVar13 + -1;
                puVar12 = puVar12 + 2;
            } while (iVar13 != 0);
        }
    }
code_r0x00018022409c:
    iVar13 = *piVar8;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802240a5;
    func_0x000180222910(iVar13);
    if (puVar9 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802240c6;
        func_0x00018046f0d0(puVar9, iVar14, 0x10, 0x1802245c0);
        if (0 < iVar14) {
            uVar10 = *(undefined8 *)((int64_t)&var_8h + iVar7);
            puVar12 = puVar9 + 1;
            do {
                puVar3 = (undefined4 *)puVar12[-1];
                if ((puVar3 != (undefined4 *)0x0) && (*(int64_t *)(puVar3 + 8) != 0)) {
                    iVar5 = *(int32_t *)puVar12;
                    if (in_R8[1] == 0) {
code_r0x000180224108:
                        uVar11 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802240f4;
                        iVar6 = func_0x000180222010();
                        if (iVar6 <= iVar5) goto code_r0x000180224108;
                        uVar11 = in_R8[1];
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180224103;
                        uVar11 = func_0x000180222340(uVar11, iVar5);
                    }
                    pcVar4 = *(code **)(puVar3 + 8);
                    iVar5 = *(int32_t *)puVar12;
                    *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)(puVar3 + 2);
                    *(undefined4 *)((int64_t)&var_18h + iVar7) = *puVar3;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180224129;
                    (*pcVar4)(uVar10, uVar11, in_R8, iVar5);
                }
                puVar12 = puVar12 + 2;
                iVar14 = iVar14 + -1;
            } while (iVar14 != 0);
        }
        if (puVar9 == (undefined8 *)((int64_t)aiStackX_8 + iVar7)) goto code_r0x000180224183;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180224152;
    fcn.180224990(puVar9, 0x1804bf898, 0x19c);
code_r0x000180224183:
    uVar10 = in_R8[1];
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022418c;
    func_0x000180221d50(uVar10);
    in_R8[1] = 0;
    *in_R8 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802241ab;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_a8h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1802241d0
// Address: 0x1802241d0
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1802241d0(int64_t arg_28h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802241e0;
    iVar3 = fcn.18045a350();
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x1802241f6;
        iVar2 = fcn.180222010();
        if (in_EDX < iVar2) {
            piVar1 = *(int32_t **)(in_RCX + 8);
            if (((piVar1 != (int32_t *)0x0) && (-1 < in_EDX)) && (in_EDX < *piVar1)) {
                return *(undefined8 *)(*(int64_t *)(piVar1 + 2) + (int64_t)in_EDX * 8);
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180224220
// Address: 0x180224220
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180224220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint32_t in_ECX;
    undefined4 in_EDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022423f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = -1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022425a;
    piVar5 = (int64_t *)func_0x000180245d40(0);
    if (piVar5 == (int64_t *)0x0) {
        return -1;
    }
    if (0x11 < in_ECX) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243dd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243f5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224407;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return -1;
    }
    if (*piVar5 == 0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224280;
    iVar2 = func_0x000180222950();
    if (iVar2 == 0) {
        return -1;
    }
    piVar1 = piVar5 + (int64_t)(int32_t)in_ECX + 1;
    if (piVar1 == (int64_t *)0x0) {
        return -1;
    }
    if (*piVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242a3;
        iVar6 = func_0x000180221f20();
        *piVar1 = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242b5;
            iVar2 = func_0x000180222110(iVar6, 0);
            if (iVar2 != 0) goto code_r0x000180224304;
        }
        iVar6 = *piVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242c1;
        func_0x000180221d50(iVar6);
        *piVar1 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242cd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242f7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242ff;
        func_0x000180222910(iVar6);
    } else {
code_r0x000180224304:
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224320;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        if (puVar7 != (undefined4 *)0x0) {
            *(undefined8 *)(puVar7 + 10) = *(undefined8 *)((int64_t)&arg_48h + iVar4);
            *(undefined8 *)(puVar7 + 8) = *(undefined8 *)((int64_t)&arg_50h + iVar4);
            *puVar7 = in_EDX;
            *(undefined8 *)(puVar7 + 2) = in_R8;
            *(undefined8 *)(puVar7 + 6) = in_R9;
            puVar7[4] = 0;
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022435a;
            iVar3 = func_0x000180222110(iVar6, 0);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224363;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022437b;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022438d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243a2;
                fcn.180224990(puVar7, 0x1804bf898, 0xc1);
                iVar6 = *piVar5;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243af;
                func_0x000180222910(iVar6);
                return -1;
            }
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243b9;
            iVar3 = fcn.180222010(iVar6);
            iVar6 = *piVar1;
            iVar3 = iVar3 + -1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243c9;
            func_0x0001802221b0(iVar6, iVar3, puVar7);
        }
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243d6;
        func_0x000180222910(iVar6);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022430a
// Address: 0x18022430a
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180224220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint32_t in_ECX;
    undefined4 in_EDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022423f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = -1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022425a;
    piVar5 = (int64_t *)func_0x000180245d40(0);
    if (piVar5 == (int64_t *)0x0) {
        return -1;
    }
    if (0x11 < in_ECX) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243dd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243f5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224407;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return -1;
    }
    if (*piVar5 == 0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224280;
    iVar2 = func_0x000180222950();
    if (iVar2 == 0) {
        return -1;
    }
    piVar1 = piVar5 + (int64_t)(int32_t)in_ECX + 1;
    if (piVar1 == (int64_t *)0x0) {
        return -1;
    }
    if (*piVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242a3;
        iVar6 = func_0x000180221f20();
        *piVar1 = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242b5;
            iVar2 = func_0x000180222110(iVar6, 0);
            if (iVar2 != 0) goto code_r0x000180224304;
        }
        iVar6 = *piVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242c1;
        func_0x000180221d50(iVar6);
        *piVar1 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242cd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242f7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242ff;
        func_0x000180222910(iVar6);
    } else {
code_r0x000180224304:
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224320;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        if (puVar7 != (undefined4 *)0x0) {
            *(undefined8 *)(puVar7 + 10) = *(undefined8 *)((int64_t)&arg_48h + iVar4);
            *(undefined8 *)(puVar7 + 8) = *(undefined8 *)((int64_t)&arg_50h + iVar4);
            *puVar7 = in_EDX;
            *(undefined8 *)(puVar7 + 2) = in_R8;
            *(undefined8 *)(puVar7 + 6) = in_R9;
            puVar7[4] = 0;
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022435a;
            iVar3 = func_0x000180222110(iVar6, 0);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224363;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022437b;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022438d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243a2;
                fcn.180224990(puVar7, 0x1804bf898, 0xc1);
                iVar6 = *piVar5;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243af;
                func_0x000180222910(iVar6);
                return -1;
            }
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243b9;
            iVar3 = fcn.180222010(iVar6);
            iVar6 = *piVar1;
            iVar3 = iVar3 + -1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243c9;
            func_0x0001802221b0(iVar6, iVar3, puVar7);
        }
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243d6;
        func_0x000180222910(iVar6);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1802243b1
// Address: 0x1802243b1
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180224220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint32_t in_ECX;
    undefined4 in_EDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022423f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = -1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022425a;
    piVar5 = (int64_t *)func_0x000180245d40(0);
    if (piVar5 == (int64_t *)0x0) {
        return -1;
    }
    if (0x11 < in_ECX) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243dd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243f5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224407;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return -1;
    }
    if (*piVar5 == 0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224280;
    iVar2 = func_0x000180222950();
    if (iVar2 == 0) {
        return -1;
    }
    piVar1 = piVar5 + (int64_t)(int32_t)in_ECX + 1;
    if (piVar1 == (int64_t *)0x0) {
        return -1;
    }
    if (*piVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242a3;
        iVar6 = func_0x000180221f20();
        *piVar1 = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242b5;
            iVar2 = func_0x000180222110(iVar6, 0);
            if (iVar2 != 0) goto code_r0x000180224304;
        }
        iVar6 = *piVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242c1;
        func_0x000180221d50(iVar6);
        *piVar1 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242cd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242f7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242ff;
        func_0x000180222910(iVar6);
    } else {
code_r0x000180224304:
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224320;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        if (puVar7 != (undefined4 *)0x0) {
            *(undefined8 *)(puVar7 + 10) = *(undefined8 *)((int64_t)&arg_48h + iVar4);
            *(undefined8 *)(puVar7 + 8) = *(undefined8 *)((int64_t)&arg_50h + iVar4);
            *puVar7 = in_EDX;
            *(undefined8 *)(puVar7 + 2) = in_R8;
            *(undefined8 *)(puVar7 + 6) = in_R9;
            puVar7[4] = 0;
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022435a;
            iVar3 = func_0x000180222110(iVar6, 0);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224363;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022437b;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022438d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243a2;
                fcn.180224990(puVar7, 0x1804bf898, 0xc1);
                iVar6 = *piVar5;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243af;
                func_0x000180222910(iVar6);
                return -1;
            }
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243b9;
            iVar3 = fcn.180222010(iVar6);
            iVar6 = *piVar1;
            iVar3 = iVar3 + -1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243c9;
            func_0x0001802221b0(iVar6, iVar3, puVar7);
        }
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243d6;
        func_0x000180222910(iVar6);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1802243ce
// Address: 0x1802243ce
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180224220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint32_t in_ECX;
    undefined4 in_EDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022423f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = -1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022425a;
    piVar5 = (int64_t *)func_0x000180245d40(0);
    if (piVar5 == (int64_t *)0x0) {
        return -1;
    }
    if (0x11 < in_ECX) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243dd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243f5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224407;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        return -1;
    }
    if (*piVar5 == 0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224280;
    iVar2 = func_0x000180222950();
    if (iVar2 == 0) {
        return -1;
    }
    piVar1 = piVar5 + (int64_t)(int32_t)in_ECX + 1;
    if (piVar1 == (int64_t *)0x0) {
        return -1;
    }
    if (*piVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242a3;
        iVar6 = func_0x000180221f20();
        *piVar1 = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242b5;
            iVar2 = func_0x000180222110(iVar6, 0);
            if (iVar2 != 0) goto code_r0x000180224304;
        }
        iVar6 = *piVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242c1;
        func_0x000180221d50(iVar6);
        *piVar1 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242cd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242e5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242f7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802242ff;
        func_0x000180222910(iVar6);
    } else {
code_r0x000180224304:
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224320;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        if (puVar7 != (undefined4 *)0x0) {
            *(undefined8 *)(puVar7 + 10) = *(undefined8 *)((int64_t)&arg_48h + iVar4);
            *(undefined8 *)(puVar7 + 8) = *(undefined8 *)((int64_t)&arg_50h + iVar4);
            *puVar7 = in_EDX;
            *(undefined8 *)(puVar7 + 2) = in_R8;
            *(undefined8 *)(puVar7 + 6) = in_R9;
            puVar7[4] = 0;
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022435a;
            iVar3 = func_0x000180222110(iVar6, 0);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180224363;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022437b;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022438d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243a2;
                fcn.180224990(puVar7, 0x1804bf898, 0xc1);
                iVar6 = *piVar5;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243af;
                func_0x000180222910(iVar6);
                return -1;
            }
            iVar6 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243b9;
            iVar3 = fcn.180222010(iVar6);
            iVar6 = *piVar1;
            iVar3 = iVar3 + -1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243c9;
            func_0x0001802221b0(iVar6, iVar3, puVar7);
        }
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802243d6;
        func_0x000180222910(iVar6);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180224430
// Address: 0x180224430
// Size: 32 bytes
// ============================================================
void fcn.180224430(int64_t arg_68h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint64_t in_RCX;
    uint32_t uVar12;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar13;
    int64_t iVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar15;
    undefined8 unaff_RDI;
    undefined8 *in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    undefined8 auStack_18 [3];
    
    auStack_18[2] = 0x18022443a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar12 = (uint32_t)in_RCX;
    uVar11 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -0x20) = unaff_R12;
    *(undefined8 *)((int64_t)auStack_18 + iVar7 + 0x10) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_18 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_18 + iVar7) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802246a7;
    iVar8 = fcn.18045a350(0, in_RCX & 0xffffffff, in_RDX);
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_68h + iVar8 + iVar7) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStack_18 + iVar8 + iVar7;
    iVar10 = 0;
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802246cf;
    piVar9 = (int64_t *)func_0x000180245d40();
    if (piVar9 == (int64_t *)0x0) goto code_r0x000180224868;
    if (0x11 < uVar12) {
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022483c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224854;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                     );
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224866;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8 + iVar7));
        goto code_r0x000180224868;
    }
    if (*piVar9 == 0) goto code_r0x000180224868;
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802246f5;
    iVar6 = func_0x000180222850();
    if ((iVar6 == 0) || (piVar1 = piVar9 + (int64_t)(int32_t)uVar12 + 1, piVar1 == (int64_t *)0x0))
    goto code_r0x000180224868;
    *in_R8 = uVar11;
    in_R8[1] = 0;
    iVar13 = *piVar1;
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022471d;
    iVar6 = fcn.180222010(iVar13);
    iVar13 = (int64_t)iVar6;
    if (iVar6 < 1) {
code_r0x000180224786:
        iVar14 = *piVar9;
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224792;
        func_0x000180222910(iVar14);
        if (0 < iVar6) goto code_r0x000180224796;
    } else {
        if (iVar6 < 10) {
            iVar10 = (int64_t)&var_18h + iVar8 + iVar7;
        } else {
            *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022474d;
            iVar10 = func_0x000180224ed0(iVar13, 8, 0x1804bf898, 0xf3);
            if (iVar10 == 0) goto code_r0x000180224786;
        }
        iVar15 = 0;
        if (iVar6 < 1) goto code_r0x000180224786;
        iVar14 = 0;
        do {
            iVar2 = *piVar1;
            *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022476a;
            uVar11 = func_0x000180222340(iVar2, iVar15);
            *(undefined8 *)(iVar10 + iVar14 * 8) = uVar11;
            iVar15 = iVar15 + 1;
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar13);
        iVar14 = *piVar9;
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224781;
        func_0x000180222910(iVar14);
code_r0x000180224796:
        if (iVar10 == 0) goto code_r0x000180224868;
    }
    iVar6 = 0;
    if (0 < iVar13) {
        iVar14 = 0;
        do {
            iVar2 = *(int64_t *)(iVar10 + iVar14 * 8);
            if ((iVar2 != 0) && (*(int64_t *)(iVar2 + 0x18) != 0)) {
                if (in_R8[1] == 0) {
code_r0x0001802247e2:
                    uVar11 = 0;
                } else {
                    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802247ce;
                    iVar15 = fcn.180222010();
                    if (iVar15 <= iVar6) goto code_r0x0001802247e2;
                    uVar11 = in_R8[1];
                    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802247dd;
                    uVar11 = func_0x000180222340(uVar11, iVar6);
                }
                puVar3 = *(undefined4 **)(iVar10 + iVar14 * 8);
                pcVar4 = *(code **)(puVar3 + 6);
                *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar7) = *(undefined8 *)(puVar3 + 2);
                *(undefined4 *)((int64_t)&var_8h + iVar8 + iVar7) = *puVar3;
                *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224807;
                (*pcVar4)(in_RDX, uVar11, in_R8, iVar6);
            }
            iVar6 = iVar6 + 1;
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar13);
    }
    if (iVar10 != (int64_t)&var_18h + iVar8 + iVar7) {
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224830;
        fcn.180224990(iVar10, 0x1804bf898, 0x104);
    }
code_r0x000180224868:
    uVar5 = *(uint64_t *)((int64_t)&arg_68h + iVar8 + iVar7);
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224878;
    func_0x000180459870(uVar5 ^ (int64_t)auStack_18 + iVar8 + iVar7);
    return;
}

// ============================================================
// Function: FUN_180224450
// Address: 0x180224450
// Size: 312 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180224450(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180224465;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 8);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022447e;
        iVar5 = fcn.180221f20();
        *(int64_t *)(in_RCX + 8) = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022448c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802244a4;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802244b6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802244d5;
    iVar2 = fcn.180222010(iVar5);
    while( true ) {
        if ((int32_t)in_RDX < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224503;
            iVar5 = fcn.1802221b0(uVar1, in_RDX & 0xffffffff, in_R8);
            if (iVar5 != in_R8) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022450d;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224525;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224537;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            }
            return iVar5 == in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802244eb;
        iVar3 = fcn.180222110(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar4));
        if (iVar3 == 0) break;
        iVar2 = iVar2 + 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224540;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224558;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022456a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return false;
}

// ============================================================
// Function: FUN_180224590
// Address: 0x180224590
// Size: 35 bytes
// ============================================================
void fcn.180224590(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180224600
// Address: 0x180224600
// Size: 28 bytes
// ============================================================
void fcn.180224600(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 unaff_RBX;
    undefined8 *puVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022460c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180224614;
    puVar3 = (undefined8 *)fcn.180245d40();
    if (puVar3 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        iVar5 = 0x12;
        puVar4 = puVar3;
        do {
            puVar4 = puVar4 + 1;
            uVar1 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022464f;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022465e;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *puVar4 = 0;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        uVar1 = *puVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022467d;
        fcn.1802227d0(uVar1);
        *puVar3 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18022461c
// Address: 0x18022461c
// Size: 105 bytes
// ============================================================
void fcn.180224600(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 unaff_RBX;
    undefined8 *puVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022460c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180224614;
    puVar3 = (undefined8 *)fcn.180245d40();
    if (puVar3 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        iVar5 = 0x12;
        puVar4 = puVar3;
        do {
            puVar4 = puVar4 + 1;
            uVar1 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022464f;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022465e;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *puVar4 = 0;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        uVar1 = *puVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022467d;
        fcn.1802227d0(uVar1);
        *puVar3 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180224685
// Address: 0x180224685
// Size: 6 bytes
// ============================================================
void fcn.180224600(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 unaff_RBX;
    undefined8 *puVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022460c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180224614;
    puVar3 = (undefined8 *)fcn.180245d40();
    if (puVar3 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        iVar5 = 0x12;
        puVar4 = puVar3;
        do {
            puVar4 = puVar4 + 1;
            uVar1 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022464f;
            fcn.180222290(uVar1, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022465e;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *puVar4 = 0;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        uVar1 = *puVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022467d;
        fcn.1802227d0(uVar1);
        *puVar3 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180224690
// Address: 0x180224690
// Size: 508 bytes
// ============================================================
void fcn.180224430(int64_t arg_68h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint64_t in_RCX;
    uint32_t uVar12;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar13;
    int64_t iVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar15;
    undefined8 unaff_RDI;
    undefined8 *in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    undefined8 auStack_18 [3];
    
    auStack_18[2] = 0x18022443a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar12 = (uint32_t)in_RCX;
    uVar11 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -8) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -0x20) = unaff_R12;
    *(undefined8 *)((int64_t)auStack_18 + iVar7 + 0x10) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_18 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_18 + iVar7) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802246a7;
    iVar8 = fcn.18045a350(0, in_RCX & 0xffffffff, in_RDX);
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_68h + iVar8 + iVar7) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStack_18 + iVar8 + iVar7;
    iVar10 = 0;
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802246cf;
    piVar9 = (int64_t *)fcn.180245d40();
    if (piVar9 == (int64_t *)0x0) goto code_r0x000180224868;
    if (0x11 < uVar12) {
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022483c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224854;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                     );
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224866;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8 + iVar7));
        goto code_r0x000180224868;
    }
    if (*piVar9 == 0) goto code_r0x000180224868;
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802246f5;
    iVar6 = func_0x000180222850();
    if ((iVar6 == 0) || (piVar1 = piVar9 + (int64_t)(int32_t)uVar12 + 1, piVar1 == (int64_t *)0x0))
    goto code_r0x000180224868;
    *in_R8 = uVar11;
    in_R8[1] = 0;
    iVar13 = *piVar1;
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022471d;
    iVar6 = fcn.180222010(iVar13);
    iVar13 = (int64_t)iVar6;
    if (iVar6 < 1) {
code_r0x000180224786:
        iVar14 = *piVar9;
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224792;
        func_0x000180222910(iVar14);
        if (0 < iVar6) goto code_r0x000180224796;
    } else {
        if (iVar6 < 10) {
            iVar10 = (int64_t)&var_18h + iVar8 + iVar7;
        } else {
            *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022474d;
            iVar10 = func_0x000180224ed0(iVar13, 8, 0x1804bf898, 0xf3);
            if (iVar10 == 0) goto code_r0x000180224786;
        }
        iVar15 = 0;
        if (iVar6 < 1) goto code_r0x000180224786;
        iVar14 = 0;
        do {
            iVar2 = *piVar1;
            *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x18022476a;
            uVar11 = func_0x000180222340(iVar2, iVar15);
            *(undefined8 *)(iVar10 + iVar14 * 8) = uVar11;
            iVar15 = iVar15 + 1;
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar13);
        iVar14 = *piVar9;
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224781;
        func_0x000180222910(iVar14);
code_r0x000180224796:
        if (iVar10 == 0) goto code_r0x000180224868;
    }
    iVar6 = 0;
    if (0 < iVar13) {
        iVar14 = 0;
        do {
            iVar2 = *(int64_t *)(iVar10 + iVar14 * 8);
            if ((iVar2 != 0) && (*(int64_t *)(iVar2 + 0x18) != 0)) {
                if (in_R8[1] == 0) {
code_r0x0001802247e2:
                    uVar11 = 0;
                } else {
                    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802247ce;
                    iVar15 = fcn.180222010();
                    if (iVar15 <= iVar6) goto code_r0x0001802247e2;
                    uVar11 = in_R8[1];
                    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x1802247dd;
                    uVar11 = func_0x000180222340(uVar11, iVar6);
                }
                puVar3 = *(undefined4 **)(iVar10 + iVar14 * 8);
                pcVar4 = *(code **)(puVar3 + 6);
                *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar7) = *(undefined8 *)(puVar3 + 2);
                *(undefined4 *)((int64_t)&var_8h + iVar8 + iVar7) = *puVar3;
                *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224807;
                (*pcVar4)(in_RDX, uVar11, in_R8, iVar6);
            }
            iVar6 = iVar6 + 1;
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar13);
    }
    if (iVar10 != (int64_t)&var_18h + iVar8 + iVar7) {
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224830;
        fcn.180224990(iVar10, 0x1804bf898, 0x104);
    }
code_r0x000180224868:
    uVar5 = *(uint64_t *)((int64_t)&arg_68h + iVar8 + iVar7);
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7 + -8) = 0x180224878;
    func_0x000180459870(uVar5 ^ (int64_t)auStack_18 + iVar8 + iVar7);
    return;
}

// ============================================================
// Function: FUN_180224890
// Address: 0x180224890
// Size: 58 bytes
// ============================================================
bool fcn.180224890(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022489c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1802248a4;
    piVar2 = (int64_t *)fcn.180245d40();
    if (piVar2 == (int64_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1802248b7;
    iVar1 = fcn.180222800();
    *piVar2 = iVar1;
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1802248d0
// Address: 0x1802248d0
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1802248d0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802248e5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)0x1806a0020 == fcn.1802248d0) {
        if (in_RCX == 0) {
            return 0;
        }
        if (*(int32_t *)0x1806a0018 != 0) {
            *(int32_t *)0x1806a0018 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224943;
        iVar2 = fcn.18046d050(in_RCX);
        if (iVar2 != 0) {
            return iVar2;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224909;
        iVar2 = (**(code **)0x1806a0020)(in_RCX);
        if (iVar2 != 0) {
            return iVar2;
        }
        if (in_RCX == 0) {
            return 0;
        }
    }
    if ((in_RDX != 0) || (in_R8D != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224956;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224963;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224975;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    }
    return 0;
}

// ============================================================
// Function: FUN_180224990
// Address: 0x180224990
// Size: 48 bytes
// ============================================================
void fcn.180224990(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022499a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18047ca54;
                puVar4 = (undefined4 *)fcn.18046b77c();
                *puVar4 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1802249c0
// Address: 0x1802249c0
// Size: 235 bytes
// ============================================================
int64_t fcn.180224f60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_78h)
{
    undefined auVar1 [16];
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    uint64_t in_R8;
    int32_t iVar6;
    int64_t in_R9;
    int64_t iVar7;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224f6c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_R8 != 0) &&
       (auVar1._8_8_ = 0, auVar1._0_8_ = in_R8,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1, 0) < in_RDX)) {
        if ((in_R9 != 0) || (*(int32_t *)((int64_t)&arg_48h + iVar4) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224f9c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224fab;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224fbd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        }
        return 0;
    }
    iVar6 = *(int32_t *)((int64_t)&arg_48h + iVar4);
    iVar7 = in_RDX * in_R8;
    uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = uVar5;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1802249da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(code **)0x1806a0028 == (code *)0x1802249c0) {
        if (in_RCX == 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a27;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar2 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar2 + iVar4));
            return iVar4;
        }
        if (iVar7 == 0) {
            if (*(code **)0x1806a0030 != fcn.180224990) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a49;
                (**(code **)0x1806a0030)();
                return 0;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a52;
            func_0x000180460d90();
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a5e;
        iVar3 = func_0x00018046d060();
    } else {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x1802249fe;
        iVar3 = (**(code **)0x1806a0028)();
        if (iVar7 == 0) {
            return iVar3;
        }
        if (iVar3 != 0) {
            return iVar3;
        }
    }
    if ((iVar3 == 0) && ((in_R9 != 0 || (iVar6 != 0)))) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a74;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar2 + iVar4), *(int64_t *)(&stack0x00000040 + iVar2 + iVar4));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a81;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar2 + iVar4), *(int64_t *)(&stack0x00000040 + iVar2 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2 + iVar4), *(int64_t *)((int64_t)&arg_50h + iVar2 + iVar4), 
                      *(int64_t *)(&stack0x00000068 + iVar2 + iVar4));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a93;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar2 + iVar4));
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180224ab0
// Address: 0x180224ab0
// Size: 222 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180224ab0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_78h)
{
    int64_t iVar1;
    uint64_t in_RCX;
    uint64_t in_RDX;
    int64_t *in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224ac5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *in_R8 = 0;
    if ((in_RDX == 0) || ((in_RDX & in_RDX - 1) != 0)) {
        if ((in_R9 == 0) && (*(int32_t *)((int64_t)&arg_48h + iVar1) == 0)) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224b5d;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224b6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)((int64_t)&arg_48h + iVar1));
    } else {
        if (in_RDX <= ~in_RCX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224b27;
            iVar1 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
            *in_R8 = iVar1;
            if (iVar1 == 0) {
                return 0;
            }
            return iVar1 + -1 + in_RDX & -in_RDX;
        }
        if ((in_R9 == 0) && (*(int32_t *)((int64_t)&arg_48h + iVar1) == 0)) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224b03;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224b10;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)((int64_t)&arg_48h + iVar1));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224b7c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_180224b90
// Address: 0x180224b90
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180224b90(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t in_RDX;
    undefined8 in_R8;
    undefined4 in_R9D;
    int64_t var_10h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180224baa;
        iVar1 = fcn.18045a350();
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180224bc0;
            func_0x000180244fc0();
        }
        if (*(code **)0x1806a0030 != fcn.180224990) {
    // WARNING: Could not recover jumptable at 0x000180224beb. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)0x1806a0030)(arg1, in_R8, in_R9D);
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180224bf3;
        func_0x000180460d90(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_180224c10
// Address: 0x180224c10
// Size: 284 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180224c10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_78h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar4;
    int32_t iVar5;
    uint64_t in_R8;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180224c25;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        if (in_R8 != 0) {
            if (in_R8 < in_RDX) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224cc3;
                func_0x000180244fc0(in_RCX + in_R8, in_RDX - in_R8);
                return in_RCX;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224ceb;
            iVar1 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224d01;
                fcn.180498030(iVar1, in_RCX, in_RDX);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224d14;
                fcn.180224b90(in_RCX, *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            }
            return iVar1;
        }
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224c67;
            func_0x000180244fc0();
        }
        if (*(code **)0x1806a0030 != fcn.180224990) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224c87;
            (**(code **)0x1806a0030)(in_RCX, in_R9, *(undefined4 *)((int64_t)&arg_48h + iVar3));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224c9e;
        func_0x000180460d90(in_RCX);
        return 0;
    }
    iVar5 = *(int32_t *)((int64_t)&arg_48h + iVar3);
    uVar4 = *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_30h + iVar3);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = *(undefined8 *)((int64_t)&arg_38h + iVar3);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar4;
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x1802248e5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)0x1806a0020 == fcn.1802248d0) {
        if (in_R8 == 0) {
            return 0;
        }
        if (*(int32_t *)0x1806a0018 != 0) {
            *(int32_t *)0x1806a0018 = 0;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar1 + iVar3) = 0x180224943;
        iVar2 = fcn.18046d050(in_R8);
        if (iVar2 != 0) {
            return iVar2;
        }
    } else {
        *(undefined8 *)((int64_t)&var_10h + iVar1 + iVar3) = 0x180224909;
        iVar2 = (**(code **)0x1806a0020)(in_R8);
        if (iVar2 != 0) {
            return iVar2;
        }
        if (in_R8 == 0) {
            return 0;
        }
    }
    if ((in_R9 != 0) || (iVar5 != 0)) {
        *(undefined8 *)((int64_t)&var_10h + iVar1 + iVar3) = 0x180224956;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar1 + iVar3), *(int64_t *)(&stack0x00000040 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&var_10h + iVar1 + iVar3) = 0x180224963;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar1 + iVar3), *(int64_t *)(&stack0x00000040 + iVar1 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar1 + iVar3), *(int64_t *)(&stack0x00000050 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000068 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&var_10h + iVar1 + iVar3) = 0x180224975;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar1 + iVar3));
    }
    return 0;
}

// ============================================================
// Function: FUN_180224d60
// Address: 0x180224d60
// Size: 62 bytes
// ============================================================
int64_t fcn.180224d60(int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224d70;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224d7b;
    iVar2 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180224d90;
        fcn.1804986e0(iVar2, 0, in_RCX);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180224da0
// Address: 0x180224da0
// Size: 149 bytes
// ============================================================
uint64_t fcn.180224da0(int64_t arg_58h, int64_t arg_60h, int64_t arg_a0h)
{
    undefined auVar1 [16];
    int64_t iVar2;
    int64_t iVar3;
    uint64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t iVar4;
    int64_t *in_R9;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224dac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != 0) &&
       (auVar1._8_8_ = 0, auVar1._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1, 0) < in_RCX)) {
        if ((*(int64_t *)((int64_t)&arg_58h + iVar3) != 0) || (*(int32_t *)((int64_t)&arg_60h + iVar3) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224de2;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224df3;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180224e05;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        }
        *in_R9 = 0;
        return 0;
    }
    iVar4 = *(int64_t *)((int64_t)&arg_58h + iVar3);
    in_RCX = in_RCX * in_RDX;
    *(undefined4 *)((int64_t)&arg_58h + iVar3) = *(undefined4 *)((int64_t)&arg_60h + iVar3);
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + 8) = 0x180224ac5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *in_R9 = 0;
    if ((in_R8 == 0) || ((in_R8 & in_R8 - 1) != 0)) {
        if ((iVar4 == 0) && (*(int32_t *)(&stack0x00000078 + iVar2 + iVar3) == 0)) {
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar3 + 8) = 0x180224b5d;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar3 + 8) = 0x180224b6a;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar2 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar2 + iVar3));
    } else {
        if (in_R8 <= ~in_RCX) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar3 + 8) = 0x180224b27;
            iVar3 = fcn.1802248d0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar2 + iVar3));
            *in_R9 = iVar3;
            if (iVar3 == 0) {
                return 0;
            }
            return iVar3 + -1 + in_R8 & -in_R8;
        }
        if ((iVar4 == 0) && (*(int32_t *)(&stack0x00000078 + iVar2 + iVar3) == 0)) {
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar3 + 8) = 0x180224b03;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar3 + 8) = 0x180224b10;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar3), *(int64_t *)(&stack0x00000050 + iVar2 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar2 + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar2 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar2 + iVar3));
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar3 + 8) = 0x180224b7c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar2 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180224e40
// Address: 0x180224e40
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180224e40(int64_t arg_28h)
{
    undefined auVar1 [16];
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t in_RCX;
    int64_t iVar5;
    uint64_t in_RDX;
    undefined8 uVar6;
    int64_t in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224e50;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RDX != 0) &&
       (auVar1._8_8_ = 0, auVar1._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224e80;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224e8d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224e9f;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        }
        return 0;
    }
    iVar5 = in_RCX * in_RDX;
    uVar6 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = uVar6;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x180224d70;
    iVar2 = fcn.18045a350(iVar5, in_R8, in_R9D);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224d7b;
    iVar3 = fcn.1802248d0(*(int64_t *)(&stack0x00000038 + iVar2 + iVar4), *(int64_t *)(&stack0x00000040 + iVar2 + iVar4)
                         );
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224d90;
        fcn.1804986e0(iVar3, 0, iVar5);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180224ed0
// Address: 0x180224ed0
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180224ed0(int64_t arg_28h)
{
    undefined auVar1 [16];
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t in_RCX;
    int64_t iVar5;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar6;
    int64_t in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224ee0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RDX != 0) &&
       (auVar1._8_8_ = 0, auVar1._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224f10;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224f1d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224f2f;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        }
        return 0;
    }
    iVar5 = in_RCX * in_RDX;
    uVar6 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = uVar6;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1802248e5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(code **)0x1806a0020 == fcn.1802248d0) {
        if (iVar5 == 0) {
            return 0;
        }
        if (*(int32_t *)0x1806a0018 != 0) {
            *(int32_t *)0x1806a0018 = 0;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224943;
        iVar5 = fcn.18046d050(iVar5);
        if (iVar5 != 0) {
            return iVar5;
        }
    } else {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224909;
        iVar3 = (**(code **)0x1806a0020)(iVar5);
        if (iVar3 != 0) {
            return iVar3;
        }
        if (iVar5 == 0) {
            return 0;
        }
    }
    if ((in_R8 != 0) || (in_R9D != 0)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224956;
        fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar2 + iVar4), *(int64_t *)(&stack0x00000040 + iVar2 + iVar4));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224963;
        fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar2 + iVar4), *(int64_t *)(&stack0x00000040 + iVar2 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), 
                      *(int64_t *)(&stack0x00000068 + iVar2 + iVar4));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224975;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar2 + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180224f60
// Address: 0x180224f60
// Size: 126 bytes
// ============================================================
int64_t fcn.180224f60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_78h)
{
    undefined auVar1 [16];
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    uint64_t in_R8;
    int32_t iVar6;
    int64_t in_R9;
    int64_t iVar7;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224f6c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_R8 != 0) &&
       (auVar1._8_8_ = 0, auVar1._0_8_ = in_R8,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1, 0) < in_RDX)) {
        if ((in_R9 != 0) || (*(int32_t *)((int64_t)&arg_48h + iVar4) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224f9c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224fab;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180224fbd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        }
        return 0;
    }
    iVar6 = *(int32_t *)((int64_t)&arg_48h + iVar4);
    iVar7 = in_RDX * in_R8;
    uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = uVar5;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1802249da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(code **)0x1806a0028 == (code *)0x1802249c0) {
        if (in_RCX == 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a27;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar2 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar2 + iVar4));
            return iVar4;
        }
        if (iVar7 == 0) {
            if (*(code **)0x1806a0030 != fcn.180224990) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a49;
                (**(code **)0x1806a0030)();
                return 0;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a52;
            func_0x000180460d90();
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a5e;
        iVar3 = func_0x00018046d060();
    } else {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x1802249fe;
        iVar3 = (**(code **)0x1806a0028)();
        if (iVar7 == 0) {
            return iVar3;
        }
        if (iVar3 != 0) {
            return iVar3;
        }
    }
    if ((iVar3 == 0) && ((in_R9 != 0 || (iVar6 != 0)))) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a74;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar2 + iVar4), *(int64_t *)(&stack0x00000040 + iVar2 + iVar4));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a81;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar2 + iVar4), *(int64_t *)(&stack0x00000040 + iVar2 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2 + iVar4), *(int64_t *)((int64_t)&arg_50h + iVar2 + iVar4), 
                      *(int64_t *)(&stack0x00000068 + iVar2 + iVar4));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar4) = 0x180224a93;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar2 + iVar4));
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180224fe0
// Address: 0x180224fe0
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180224fe0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t in_RCX;
    int64_t iVar8;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224ff0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RDX != 0) &&
       (auVar2._8_8_ = 0, auVar2._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180225020;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022502d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022503f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        }
        return 0;
    }
    iVar8 = in_RCX * in_RDX;
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar9 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar9;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x1802253f5;
    iVar6 = fcn.18045a350(iVar8);
    iVar6 = -iVar6;
    if (*(int32_t *)0x18077e438 == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5);
        *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0x180224d70;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d7b;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d90;
            fcn.1804986e0(iVar4, 0, iVar8);
        }
        return iVar4;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022542c;
    iVar3 = func_0x000180222950(*(undefined8 *)0x18077e440);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225440;
        iVar8 = func_0x000180225c50(iVar8);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225450;
            iVar7 = func_0x0001802254f0(iVar8);
            *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 + iVar7;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225463;
            func_0x000180222910(*(undefined8 *)0x18077e440);
            return iVar8;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022548c;
        func_0x000180222910(*(undefined8 *)0x18077e440);
    }
    if ((in_R8 != 0) || (in_R9D != 0)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022549a;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254b7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_180225070
// Address: 0x180225070
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180225070(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined auVar1 [16];
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t in_RCX;
    int64_t iVar6;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180225080;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != 0) &&
       (auVar1._8_8_ = 0, auVar1._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802250b0;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802250bd;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802250cf;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        }
        return 0;
    }
    iVar6 = in_RCX * in_RDX;
    uVar7 = *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = uVar7;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar3) = 0x1802252d0;
    iVar4 = fcn.18045a350(iVar6);
    iVar4 = -iVar4;
    if (*(int32_t *)0x18077e438 == 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x1802252f1;
        iVar6 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
    } else {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x1802252ff;
        iVar2 = func_0x000180222950(*(undefined8 *)0x18077e440);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225313;
            iVar6 = func_0x000180225c50(iVar6);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225323;
                iVar5 = func_0x0001802254f0(iVar6);
                *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 + iVar5;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225336;
                func_0x000180222910(*(undefined8 *)0x18077e440);
                return iVar6;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225344;
            func_0x000180222910(*(undefined8 *)0x18077e440);
        }
        iVar6 = 0;
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225352;
            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x18022535f;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x18022536f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3));
        }
    }
    return iVar6;
}

// ============================================================
// Function: FUN_180225130
// Address: 0x180225130
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180225130(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 in_RAX;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_R8;
    undefined4 in_R9D;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18022514e;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (((*(int32_t *)0x18077e438 == 0) || ((uint64_t)arg1 < *(uint64_t *)0x18077e460)) ||
           (*(int64_t *)0x18077e468 + *(uint64_t *)0x18077e460 <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802251d6;
            fcn.180244fc0(arg1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802251e4;
            in_RAX = fcn.180224990(arg1, in_R8, in_R9D);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022518a;
            in_RAX = fcn.180222950(*(int64_t *)0x18077e440);
            if ((int32_t)in_RAX != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180225196;
                iVar3 = fcn.1802254f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802251a4;
                fcn.180244fc0(arg1, iVar3);
                *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 - iVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802251b3;
                fcn.180225910(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2) = 0x18022291a;
                iVar3 = *(int64_t *)0x18077e440;
                iVar1 = fcn.18045a350();
                if (*(int32_t *)(iVar3 + 8) == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222940;
                    (*(code *)0x69a07c)();
                    return 1;
                }
                *(undefined4 *)(iVar3 + 8) = 0;
                *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222930;
                (*(code *)0x69a062)();
                return 1;
            }
        }
    }
    return in_RAX;
}

// ============================================================
// Function: FUN_180225200
// Address: 0x180225200
// Size: 84 bytes
// ============================================================
undefined8 fcn.180225200(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_RAX;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225214;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (((*(int32_t *)0x18077e438 == 0) || ((uint64_t)arg1 < *(uint64_t *)0x18077e460)) ||
           (*(int64_t *)0x18077e468 + *(uint64_t *)0x18077e460 <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022529c;
            in_RAX = fcn.180224990(arg1);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022524d;
            in_RAX = fcn.180222950(*(int64_t *)0x18077e440);
            if ((int32_t)in_RAX != 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022525e;
                iVar3 = fcn.1802254f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022526c;
                fcn.180244fc0(arg1, iVar3);
                *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 - iVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022527b;
                fcn.180225910(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2) = 0x18022291a;
                iVar3 = *(int64_t *)0x18077e440;
                iVar1 = fcn.18045a350();
                if (*(int32_t *)(iVar3 + 8) == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222940;
                    (*(code *)0x69a07c)();
                    return 1;
                }
                *(undefined4 *)(iVar3 + 8) = 0;
                *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222930;
                (*(code *)0x69a062)();
                return 1;
            }
        }
    }
    return in_RAX;
}

// ============================================================
// Function: FUN_180225254
// Address: 0x180225254
// Size: 61 bytes
// ============================================================
undefined8 fcn.180225200(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_RAX;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225214;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (((*(int32_t *)0x18077e438 == 0) || ((uint64_t)arg1 < *(uint64_t *)0x18077e460)) ||
           (*(int64_t *)0x18077e468 + *(uint64_t *)0x18077e460 <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022529c;
            in_RAX = fcn.180224990(arg1);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022524d;
            in_RAX = fcn.180222950(*(int64_t *)0x18077e440);
            if ((int32_t)in_RAX != 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022525e;
                iVar3 = fcn.1802254f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022526c;
                fcn.180244fc0(arg1, iVar3);
                *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 - iVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022527b;
                fcn.180225910(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2) = 0x18022291a;
                iVar3 = *(int64_t *)0x18077e440;
                iVar1 = fcn.18045a350();
                if (*(int32_t *)(iVar3 + 8) == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222940;
                    (*(code *)0x69a07c)();
                    return 1;
                }
                *(undefined4 *)(iVar3 + 8) = 0;
                *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222930;
                (*(code *)0x69a062)();
                return 1;
            }
        }
    }
    return in_RAX;
}

// ============================================================
// Function: FUN_180225291
// Address: 0x180225291
// Size: 17 bytes
// ============================================================
undefined8 fcn.180225200(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_RAX;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225214;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (((*(int32_t *)0x18077e438 == 0) || ((uint64_t)arg1 < *(uint64_t *)0x18077e460)) ||
           (*(int64_t *)0x18077e468 + *(uint64_t *)0x18077e460 <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022529c;
            in_RAX = fcn.180224990(arg1);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022524d;
            in_RAX = fcn.180222950(*(int64_t *)0x18077e440);
            if ((int32_t)in_RAX != 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022525e;
                iVar3 = fcn.1802254f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022526c;
                fcn.180244fc0(arg1, iVar3);
                *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 - iVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022527b;
                fcn.180225910(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2) = 0x18022291a;
                iVar3 = *(int64_t *)0x18077e440;
                iVar1 = fcn.18045a350();
                if (*(int32_t *)(iVar3 + 8) == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222940;
                    (*(code *)0x69a07c)();
                    return 1;
                }
                *(undefined4 *)(iVar3 + 8) = 0;
                *(undefined8 *)((int64_t)aiStackX_18 + -iVar1 + iVar2) = 0x180222930;
                (*(code *)0x69a062)();
                return 1;
            }
        }
    }
    return in_RAX;
}

// ============================================================
// Function: FUN_1802252b0
// Address: 0x1802252b0
// Size: 221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180225070(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined auVar1 [16];
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t in_RCX;
    int64_t iVar6;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180225080;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != 0) &&
       (auVar1._8_8_ = 0, auVar1._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802250b0;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802250bd;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802250cf;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        }
        return 0;
    }
    iVar6 = in_RCX * in_RDX;
    uVar7 = *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = uVar7;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar3) = 0x1802252d0;
    iVar4 = fcn.18045a350(iVar6);
    iVar4 = -iVar4;
    if (*(int32_t *)0x18077e438 == 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x1802252f1;
        iVar6 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
    } else {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x1802252ff;
        iVar2 = fcn.180222950(*(undefined8 *)0x18077e440);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225313;
            iVar6 = func_0x000180225c50(iVar6);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225323;
                iVar5 = fcn.1802254f0(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 + iVar5;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225336;
                func_0x000180222910(*(undefined8 *)0x18077e440);
                return iVar6;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225344;
            func_0x000180222910(*(undefined8 *)0x18077e440);
        }
        iVar6 = 0;
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x180225352;
            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x18022535f;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + iVar3) = 0x18022536f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3));
        }
    }
    return iVar6;
}

// ============================================================
// Function: FUN_180225390
// Address: 0x180225390
// Size: 78 bytes
// ============================================================
undefined8 fcn.180225390(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022539a;
    iVar1 = fcn.18045a350();
    if (*(int64_t *)0x18077e430 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x1802253ac;
        fcn.1802257f0();
        *(undefined4 *)0x18077e438 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x1802253c2;
        fcn.1802227d0(*(undefined8 *)0x18077e440);
        *(undefined8 *)0x18077e440 = 0;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802253e0
// Address: 0x1802253e0
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180224fe0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t in_RCX;
    int64_t iVar8;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224ff0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RDX != 0) &&
       (auVar2._8_8_ = 0, auVar2._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180225020;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022502d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022503f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        }
        return 0;
    }
    iVar8 = in_RCX * in_RDX;
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar9 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar9;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x1802253f5;
    iVar6 = fcn.18045a350(iVar8);
    iVar6 = -iVar6;
    if (*(int32_t *)0x18077e438 == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5);
        *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0x180224d70;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d7b;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d90;
            fcn.1804986e0(iVar4, 0, iVar8);
        }
        return iVar4;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022542c;
    iVar3 = fcn.180222950(*(undefined8 *)0x18077e440);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225440;
        iVar8 = func_0x000180225c50(iVar8);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225450;
            iVar7 = fcn.1802254f0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5));
            *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 + iVar7;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225463;
            func_0x000180222910(*(undefined8 *)0x18077e440);
            return iVar8;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022548c;
        func_0x000180222910(*(undefined8 *)0x18077e440);
    }
    if ((in_R8 != 0) || (in_R9D != 0)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022549a;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254b7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_180225415
// Address: 0x180225415
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180224fe0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t in_RCX;
    int64_t iVar8;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224ff0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RDX != 0) &&
       (auVar2._8_8_ = 0, auVar2._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180225020;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022502d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022503f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        }
        return 0;
    }
    iVar8 = in_RCX * in_RDX;
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar9 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar9;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x1802253f5;
    iVar6 = fcn.18045a350(iVar8);
    iVar6 = -iVar6;
    if (*(int32_t *)0x18077e438 == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5);
        *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0x180224d70;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d7b;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d90;
            fcn.1804986e0(iVar4, 0, iVar8);
        }
        return iVar4;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022542c;
    iVar3 = fcn.180222950(*(undefined8 *)0x18077e440);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225440;
        iVar8 = func_0x000180225c50(iVar8);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225450;
            iVar7 = fcn.1802254f0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5));
            *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 + iVar7;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225463;
            func_0x000180222910(*(undefined8 *)0x18077e440);
            return iVar8;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022548c;
        func_0x000180222910(*(undefined8 *)0x18077e440);
    }
    if ((in_R8 != 0) || (in_R9D != 0)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022549a;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254b7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_180225480
// Address: 0x180225480
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180224fe0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t in_RCX;
    int64_t iVar8;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224ff0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RDX != 0) &&
       (auVar2._8_8_ = 0, auVar2._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180225020;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022502d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022503f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        }
        return 0;
    }
    iVar8 = in_RCX * in_RDX;
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar9 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar9;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x1802253f5;
    iVar6 = fcn.18045a350(iVar8);
    iVar6 = -iVar6;
    if (*(int32_t *)0x18077e438 == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5);
        *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0x180224d70;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d7b;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d90;
            fcn.1804986e0(iVar4, 0, iVar8);
        }
        return iVar4;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022542c;
    iVar3 = fcn.180222950(*(undefined8 *)0x18077e440);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225440;
        iVar8 = func_0x000180225c50(iVar8);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225450;
            iVar7 = fcn.1802254f0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5));
            *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 + iVar7;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225463;
            func_0x000180222910(*(undefined8 *)0x18077e440);
            return iVar8;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022548c;
        func_0x000180222910(*(undefined8 *)0x18077e440);
    }
    if ((in_R8 != 0) || (in_R9D != 0)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022549a;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254b7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_1802254d4
// Address: 0x1802254d4
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180224fe0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t in_RCX;
    int64_t iVar8;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180224ff0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RDX != 0) &&
       (auVar2._8_8_ = 0, auVar2._0_8_ = in_RDX,
       SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0) < in_RCX)) {
        if ((in_R8 != 0) || (in_R9D != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180225020;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022502d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022503f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        }
        return 0;
    }
    iVar8 = in_RCX * in_RDX;
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar9 = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = uVar9;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x1802253f5;
    iVar6 = fcn.18045a350(iVar8);
    iVar6 = -iVar6;
    if (*(int32_t *)0x18077e438 == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5);
        *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0x180224d70;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d7b;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6 + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6 + iVar5) = 0x180224d90;
            fcn.1804986e0(iVar4, 0, iVar8);
        }
        return iVar4;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5) = uVar1;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022542c;
    iVar3 = fcn.180222950(*(undefined8 *)0x18077e440);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225440;
        iVar8 = func_0x000180225c50(iVar8);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225450;
            iVar7 = fcn.1802254f0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5));
            *(int64_t *)0x18077e430 = *(int64_t *)0x18077e430 + iVar7;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x180225463;
            func_0x000180222910(*(undefined8 *)0x18077e440);
            return iVar8;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022548c;
        func_0x000180222910(*(undefined8 *)0x18077e440);
    }
    if ((in_R8 != 0) || (in_R9D != 0)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x18022549a;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254a7;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar5) = 0x1802254b7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_1802254f0
// Address: 0x1802254f0
// Size: 102 bytes
// ============================================================
uint64_t fcn.1802254f0(int64_t arg_28h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802254fc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RCX < *(uint64_t *)0x18077e460) || (*(uint64_t *)0x18077e468 + *(uint64_t *)0x18077e460 <= in_RCX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225537;
        func_0x00018027bb50(0x1804bfa60, 0x1804bf8e8, 0x2e6);
    }
    if ((*(uint64_t *)0x18077e460 <= in_RCX) && (in_RCX < *(uint64_t *)0x18077e468 + *(uint64_t *)0x18077e460)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225560;
        uVar1 = func_0x000180225bb0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225574;
        iVar2 = func_0x0001802261e0(in_RCX, uVar1, *(undefined8 *)0x18077e488);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225591;
            func_0x00018027bb50(0x1804bfdd0, 0x1804bf8e8, 0x2ea);
        }
        return *(uint64_t *)0x18077e468 / (uint64_t)(1LL << ((uint8_t)uVar1 & 0x3f));
    }
    return 0;
}

