// Chunk 89 - 50 functions

// ============================================================
// Function: FUN_180128910
// Address: 0x180128910
// Size: 1090 bytes
// ============================================================
void fcn.180128910(int64_t arg1)
{
    int64_t iVar1;
    char cVar2;
    char cVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    char cVar7;
    char cVar8;
    char cVar9;
    char cVar10;
    char cVar11;
    char cVar12;
    char cVar13;
    char cVar14;
    char cVar15;
    char cVar16;
    char cVar17;
    char cVar18;
    char cVar19;
    char cVar20;
    char cVar21;
    char cVar22;
    char cVar23;
    char cVar24;
    char cVar25;
    char cVar26;
    char cVar27;
    char cVar28;
    char cVar29;
    char cVar30;
    char cVar31;
    char cVar32;
    char cVar33;
    uint32_t uVar34;
    undefined4 uVar35;
    uint16_t *puVar36;
    int64_t iVar37;
    undefined2 *puVar38;
    undefined8 *puVar39;
    char *pcVar40;
    int32_t iVar41;
    int32_t iVar42;
    undefined4 uVar43;
    int32_t iVar44;
    char *pcVar45;
    int64_t iVar46;
    int32_t iVar47;
    char *pcVar48;
    uint32_t uVar49;
    uint32_t uVar50;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    
    _var_68h = ZEXT816(0);
    uVar35 = 2;
    if ((*(uint32_t *)arg1 & 2) == 0) {
        uVar35 = 0xf5;
    }
    iVar41 = 0x1b;
    iVar1 = *(int64_t *)(arg1 + 0x2b0);
    uVar43 = 2;
    if ((*(uint32_t *)arg1 & 2) == 0) {
        uVar43 = 0x1b;
    }
    puVar36 = (uint16_t *)func_0x00018012b530(arg1, *(undefined4 *)(iVar1 + 0xec));
    if (puVar36 == (uint16_t *)0x0) {
        if (*(int64_t *)(arg1 + 0x2b0) == 0) {
            func_0x00018012a190(arg1);
        }
        uVar34 = func_0x00018012ae60(arg1, uVar35, uVar43, 0);
        if ((uVar34 != 0xffffffff) && (func_0x000180128440(arg1, uVar34, &var_68h), *(char *)(arg1 + 0x51) != '\0')) {
            iVar46 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
            iVar37 = (int64_t)(*(int32_t *)
                                (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(uVar34 & 0x7ffff) * 4) <<
                              0xc) >> 0xc;
            func_0x000180127510(arg1, *(undefined8 *)(arg1 + 0x38), *(undefined2 *)(iVar46 + iVar37 * 8), 
                                *(undefined2 *)(iVar46 + 2 + iVar37 * 8), *(undefined2 *)(iVar46 + 4 + iVar37 * 8), 
                                *(undefined2 *)(iVar46 + 6 + iVar37 * 8));
        }
        uVar49 = (uint32_t)var_68h._2_2_;
        uVar50 = (uint32_t)(uint16_t)var_68h;
        *(uint32_t *)(iVar1 + 0xec) = uVar34;
        iVar1 = *(int64_t *)(arg1 + 0x38);
        iVar42 = *(int32_t *)(iVar1 + 0x18);
        if ((*(uint8_t *)arg1 & 2) == 0) {
            pcVar40 = (char *)0x18061ef60;
            pcVar45 = (char *)0x18061ef60;
            if (iVar42 == 0) {
                iVar42 = 0x1b;
                iVar46 = (int64_t)(int32_t)((uVar49 * *(int32_t *)(iVar1 + 0x1c) + uVar50) * *(int32_t *)(iVar1 + 0x24))
                         + *(int64_t *)(iVar1 + 0x28);
                do {
                    iVar37 = 0;
                    do {
                        uVar35 = 0;
                        if (pcVar45[iVar37] == '.') {
                            uVar35 = 0xffffffff;
                        }
                        *(undefined4 *)(iVar46 + iVar37 * 4) = uVar35;
                        uVar35 = 0;
                        if (pcVar45[iVar37 + 1] == '.') {
                            uVar35 = 0xffffffff;
                        }
                        *(undefined4 *)(iVar46 + 4 + iVar37 * 4) = uVar35;
                        iVar37 = iVar37 + 2;
                    } while (iVar37 != 0x7a);
                    pcVar45 = pcVar45 + 0x7a;
                    iVar46 = iVar46 + (int64_t)*(int32_t *)(iVar1 + 0x1c) * 4;
                    iVar42 = iVar42 + -1;
                } while (iVar42 != 0);
            } else if (iVar42 == 1) {
                iVar42 = 0x1b;
                pcVar48 = (char *)((int64_t)(int32_t)(((uint32_t)var_68h._2_2_ * *(int32_t *)(iVar1 + 0x1c) + uVar50) *
                                                     *(int32_t *)(iVar1 + 0x24)) + *(int64_t *)(iVar1 + 0x28));
                do {
                    if ((pcVar45 + 0x79 < pcVar48) || (iVar44 = 0, pcVar48 + 0x79 < pcVar45)) {
                        cVar33 = pcVar45[1];
                        cVar2 = pcVar45[2];
                        cVar3 = pcVar45[3];
                        cVar4 = pcVar45[4];
                        cVar5 = pcVar45[5];
                        cVar6 = pcVar45[6];
                        cVar7 = pcVar45[7];
                        cVar8 = pcVar45[8];
                        cVar9 = pcVar45[9];
                        cVar10 = pcVar45[10];
                        cVar11 = pcVar45[0xb];
                        cVar12 = pcVar45[0xc];
                        cVar13 = pcVar45[0xd];
                        cVar14 = pcVar45[0xe];
                        cVar15 = pcVar45[0xf];
                        cVar16 = pcVar45[0x10];
                        cVar17 = pcVar45[0x11];
                        cVar18 = pcVar45[0x12];
                        cVar19 = pcVar45[0x13];
                        cVar20 = pcVar45[0x14];
                        cVar21 = pcVar45[0x15];
                        cVar22 = pcVar45[0x16];
                        cVar23 = pcVar45[0x17];
                        cVar24 = pcVar45[0x18];
                        cVar25 = pcVar45[0x19];
                        cVar26 = pcVar45[0x1a];
                        cVar27 = pcVar45[0x1b];
                        cVar28 = pcVar45[0x1c];
                        cVar29 = pcVar45[0x1d];
                        cVar30 = pcVar45[0x1e];
                        cVar31 = pcVar45[0x1f];
                        *pcVar48 = -(*pcVar45 == '.');
                        pcVar48[1] = -(cVar33 == '.');
                        pcVar48[2] = -(cVar2 == '.');
                        pcVar48[3] = -(cVar3 == '.');
                        pcVar48[4] = -(cVar4 == '.');
                        pcVar48[5] = -(cVar5 == '.');
                        pcVar48[6] = -(cVar6 == '.');
                        pcVar48[7] = -(cVar7 == '.');
                        pcVar48[8] = -(cVar8 == '.');
                        pcVar48[9] = -(cVar9 == '.');
                        pcVar48[10] = -(cVar10 == '.');
                        pcVar48[0xb] = -(cVar11 == '.');
                        pcVar48[0xc] = -(cVar12 == '.');
                        pcVar48[0xd] = -(cVar13 == '.');
                        pcVar48[0xe] = -(cVar14 == '.');
                        pcVar48[0xf] = -(cVar15 == '.');
                        cVar33 = pcVar45[0x20];
                        cVar2 = pcVar45[0x21];
                        cVar3 = pcVar45[0x22];
                        cVar4 = pcVar45[0x23];
                        cVar5 = pcVar45[0x24];
                        cVar6 = pcVar45[0x25];
                        cVar7 = pcVar45[0x26];
                        cVar8 = pcVar45[0x27];
                        cVar9 = pcVar45[0x28];
                        cVar10 = pcVar45[0x29];
                        cVar11 = pcVar45[0x2a];
                        cVar12 = pcVar45[0x2b];
                        cVar13 = pcVar45[0x2c];
                        cVar14 = pcVar45[0x2d];
                        cVar15 = pcVar45[0x2e];
                        cVar32 = pcVar45[0x2f];
                        pcVar48[0x10] = -(cVar16 == '.');
                        pcVar48[0x11] = -(cVar17 == '.');
                        pcVar48[0x12] = -(cVar18 == '.');
                        pcVar48[0x13] = -(cVar19 == '.');
                        pcVar48[0x14] = -(cVar20 == '.');
                        pcVar48[0x15] = -(cVar21 == '.');
                        pcVar48[0x16] = -(cVar22 == '.');
                        pcVar48[0x17] = -(cVar23 == '.');
                        pcVar48[0x18] = -(cVar24 == '.');
                        pcVar48[0x19] = -(cVar25 == '.');
                        pcVar48[0x1a] = -(cVar26 == '.');
                        pcVar48[0x1b] = -(cVar27 == '.');
                        pcVar48[0x1c] = -(cVar28 == '.');
                        pcVar48[0x1d] = -(cVar29 == '.');
                        pcVar48[0x1e] = -(cVar30 == '.');
                        pcVar48[0x1f] = -(cVar31 == '.');
                        cVar16 = pcVar45[0x30];
                        cVar17 = pcVar45[0x31];
                        cVar18 = pcVar45[0x32];
                        cVar19 = pcVar45[0x33];
                        cVar20 = pcVar45[0x34];
                        cVar21 = pcVar45[0x35];
                        cVar22 = pcVar45[0x36];
                        cVar23 = pcVar45[0x37];
                        cVar24 = pcVar45[0x38];
                        cVar25 = pcVar45[0x39];
                        cVar26 = pcVar45[0x3a];
                        cVar27 = pcVar45[0x3b];
                        cVar28 = pcVar45[0x3c];
                        cVar29 = pcVar45[0x3d];
                        cVar30 = pcVar45[0x3e];
                        cVar31 = pcVar45[0x3f];
                        pcVar48[0x20] = -(cVar33 == '.');
                        pcVar48[0x21] = -(cVar2 == '.');
                        pcVar48[0x22] = -(cVar3 == '.');
                        pcVar48[0x23] = -(cVar4 == '.');
                        pcVar48[0x24] = -(cVar5 == '.');
                        pcVar48[0x25] = -(cVar6 == '.');
                        pcVar48[0x26] = -(cVar7 == '.');
                        pcVar48[0x27] = -(cVar8 == '.');
                        pcVar48[0x28] = -(cVar9 == '.');
                        pcVar48[0x29] = -(cVar10 == '.');
                        pcVar48[0x2a] = -(cVar11 == '.');
                        pcVar48[0x2b] = -(cVar12 == '.');
                        pcVar48[0x2c] = -(cVar13 == '.');
                        pcVar48[0x2d] = -(cVar14 == '.');
                        pcVar48[0x2e] = -(cVar15 == '.');
                        pcVar48[0x2f] = -(cVar32 == '.');
                        pcVar48[0x30] = -(cVar16 == '.');
                        pcVar48[0x31] = -(cVar17 == '.');
                        pcVar48[0x32] = -(cVar18 == '.');
                        pcVar48[0x33] = -(cVar19 == '.');
                        pcVar48[0x34] = -(cVar20 == '.');
                        pcVar48[0x35] = -(cVar21 == '.');
                        pcVar48[0x36] = -(cVar22 == '.');
                        pcVar48[0x37] = -(cVar23 == '.');
                        pcVar48[0x38] = -(cVar24 == '.');
                        pcVar48[0x39] = -(cVar25 == '.');
                        pcVar48[0x3a] = -(cVar26 == '.');
                        pcVar48[0x3b] = -(cVar27 == '.');
                        pcVar48[0x3c] = -(cVar28 == '.');
                        pcVar48[0x3d] = -(cVar29 == '.');
                        pcVar48[0x3e] = -(cVar30 == '.');
                        pcVar48[0x3f] = -(cVar31 == '.');
                        iVar44 = 0x40;
                    }
                    do {
                        cVar33 = '\0';
                        if (pcVar45[iVar44] == '.') {
                            cVar33 = -1;
                        }
                        iVar47 = iVar44 + 1;
                        pcVar48[iVar44] = cVar33;
                        iVar44 = iVar47;
                    } while (iVar47 < 0x7a);
                    pcVar45 = pcVar45 + 0x7a;
                    pcVar48 = pcVar48 + *(int32_t *)(iVar1 + 0x1c);
                    iVar42 = iVar42 + -1;
                } while (iVar42 != 0);
            }
            iVar1 = *(int64_t *)(arg1 + 0x38);
            if (*(int32_t *)(iVar1 + 0x18) == 0) {
                iVar46 = (int64_t)(int32_t)((uVar49 * *(int32_t *)(iVar1 + 0x1c) + (uint16_t)var_68h + 0x7b) *
                                           *(int32_t *)(iVar1 + 0x24)) + *(int64_t *)(iVar1 + 0x28);
                do {
                    iVar37 = 0;
                    do {
                        uVar35 = 0;
                        if (pcVar40[iVar37] == 'X') {
                            uVar35 = 0xffffffff;
                        }
                        *(undefined4 *)(iVar46 + iVar37 * 4) = uVar35;
                        uVar35 = 0;
                        if (pcVar40[iVar37 + 1] == 'X') {
                            uVar35 = 0xffffffff;
                        }
                        *(undefined4 *)(iVar46 + 4 + iVar37 * 4) = uVar35;
                        iVar37 = iVar37 + 2;
                    } while (iVar37 != 0x7a);
                    pcVar40 = pcVar40 + 0x7a;
                    iVar46 = iVar46 + (int64_t)*(int32_t *)(iVar1 + 0x1c) * 4;
                    iVar41 = iVar41 + -1;
                } while (iVar41 != 0);
            } else if (*(int32_t *)(iVar1 + 0x18) == 1) {
                pcVar45 = (char *)((int64_t)(int32_t)((uVar49 * *(int32_t *)(iVar1 + 0x1c) + (uint16_t)var_68h + 0x7b) *
                                                     *(int32_t *)(iVar1 + 0x24)) + *(int64_t *)(iVar1 + 0x28));
                do {
                    if ((pcVar40 + 0x79 < pcVar45) || (iVar42 = 0, pcVar45 + 0x79 < pcVar40)) {
                        cVar33 = pcVar40[1];
                        cVar2 = pcVar40[2];
                        cVar3 = pcVar40[3];
                        cVar4 = pcVar40[4];
                        cVar5 = pcVar40[5];
                        cVar6 = pcVar40[6];
                        cVar7 = pcVar40[7];
                        cVar8 = pcVar40[8];
                        cVar9 = pcVar40[9];
                        cVar10 = pcVar40[10];
                        cVar11 = pcVar40[0xb];
                        cVar12 = pcVar40[0xc];
                        cVar13 = pcVar40[0xd];
                        cVar14 = pcVar40[0xe];
                        cVar15 = pcVar40[0xf];
                        cVar16 = pcVar40[0x10];
                        cVar17 = pcVar40[0x11];
                        cVar18 = pcVar40[0x12];
                        cVar19 = pcVar40[0x13];
                        cVar20 = pcVar40[0x14];
                        cVar21 = pcVar40[0x15];
                        cVar22 = pcVar40[0x16];
                        cVar23 = pcVar40[0x17];
                        cVar24 = pcVar40[0x18];
                        cVar25 = pcVar40[0x19];
                        cVar26 = pcVar40[0x1a];
                        cVar27 = pcVar40[0x1b];
                        cVar28 = pcVar40[0x1c];
                        cVar29 = pcVar40[0x1d];
                        cVar30 = pcVar40[0x1e];
                        cVar31 = pcVar40[0x1f];
                        *pcVar45 = -(*pcVar40 == 'X');
                        pcVar45[1] = -(cVar33 == 'X');
                        pcVar45[2] = -(cVar2 == 'X');
                        pcVar45[3] = -(cVar3 == 'X');
                        pcVar45[4] = -(cVar4 == 'X');
                        pcVar45[5] = -(cVar5 == 'X');
                        pcVar45[6] = -(cVar6 == 'X');
                        pcVar45[7] = -(cVar7 == 'X');
                        pcVar45[8] = -(cVar8 == 'X');
                        pcVar45[9] = -(cVar9 == 'X');
                        pcVar45[10] = -(cVar10 == 'X');
                        pcVar45[0xb] = -(cVar11 == 'X');
                        pcVar45[0xc] = -(cVar12 == 'X');
                        pcVar45[0xd] = -(cVar13 == 'X');
                        pcVar45[0xe] = -(cVar14 == 'X');
                        pcVar45[0xf] = -(cVar15 == 'X');
                        cVar33 = pcVar40[0x20];
                        cVar2 = pcVar40[0x21];
                        cVar3 = pcVar40[0x22];
                        cVar4 = pcVar40[0x23];
                        cVar5 = pcVar40[0x24];
                        cVar6 = pcVar40[0x25];
                        cVar7 = pcVar40[0x26];
                        cVar8 = pcVar40[0x27];
                        cVar9 = pcVar40[0x28];
                        cVar10 = pcVar40[0x29];
                        cVar11 = pcVar40[0x2a];
                        cVar12 = pcVar40[0x2b];
                        cVar13 = pcVar40[0x2c];
                        cVar14 = pcVar40[0x2d];
                        cVar15 = pcVar40[0x2e];
                        cVar32 = pcVar40[0x2f];
                        pcVar45[0x10] = -(cVar16 == 'X');
                        pcVar45[0x11] = -(cVar17 == 'X');
                        pcVar45[0x12] = -(cVar18 == 'X');
                        pcVar45[0x13] = -(cVar19 == 'X');
                        pcVar45[0x14] = -(cVar20 == 'X');
                        pcVar45[0x15] = -(cVar21 == 'X');
                        pcVar45[0x16] = -(cVar22 == 'X');
                        pcVar45[0x17] = -(cVar23 == 'X');
                        pcVar45[0x18] = -(cVar24 == 'X');
                        pcVar45[0x19] = -(cVar25 == 'X');
                        pcVar45[0x1a] = -(cVar26 == 'X');
                        pcVar45[0x1b] = -(cVar27 == 'X');
                        pcVar45[0x1c] = -(cVar28 == 'X');
                        pcVar45[0x1d] = -(cVar29 == 'X');
                        pcVar45[0x1e] = -(cVar30 == 'X');
                        pcVar45[0x1f] = -(cVar31 == 'X');
                        cVar16 = pcVar40[0x30];
                        cVar17 = pcVar40[0x31];
                        cVar18 = pcVar40[0x32];
                        cVar19 = pcVar40[0x33];
                        cVar20 = pcVar40[0x34];
                        cVar21 = pcVar40[0x35];
                        cVar22 = pcVar40[0x36];
                        cVar23 = pcVar40[0x37];
                        cVar24 = pcVar40[0x38];
                        cVar25 = pcVar40[0x39];
                        cVar26 = pcVar40[0x3a];
                        cVar27 = pcVar40[0x3b];
                        cVar28 = pcVar40[0x3c];
                        cVar29 = pcVar40[0x3d];
                        cVar30 = pcVar40[0x3e];
                        cVar31 = pcVar40[0x3f];
                        pcVar45[0x20] = -(cVar33 == 'X');
                        pcVar45[0x21] = -(cVar2 == 'X');
                        pcVar45[0x22] = -(cVar3 == 'X');
                        pcVar45[0x23] = -(cVar4 == 'X');
                        pcVar45[0x24] = -(cVar5 == 'X');
                        pcVar45[0x25] = -(cVar6 == 'X');
                        pcVar45[0x26] = -(cVar7 == 'X');
                        pcVar45[0x27] = -(cVar8 == 'X');
                        pcVar45[0x28] = -(cVar9 == 'X');
                        pcVar45[0x29] = -(cVar10 == 'X');
                        pcVar45[0x2a] = -(cVar11 == 'X');
                        pcVar45[0x2b] = -(cVar12 == 'X');
                        pcVar45[0x2c] = -(cVar13 == 'X');
                        pcVar45[0x2d] = -(cVar14 == 'X');
                        pcVar45[0x2e] = -(cVar15 == 'X');
                        pcVar45[0x2f] = -(cVar32 == 'X');
                        pcVar45[0x30] = -(cVar16 == 'X');
                        pcVar45[0x31] = -(cVar17 == 'X');
                        pcVar45[0x32] = -(cVar18 == 'X');
                        pcVar45[0x33] = -(cVar19 == 'X');
                        pcVar45[0x34] = -(cVar20 == 'X');
                        pcVar45[0x35] = -(cVar21 == 'X');
                        pcVar45[0x36] = -(cVar22 == 'X');
                        pcVar45[0x37] = -(cVar23 == 'X');
                        pcVar45[0x38] = -(cVar24 == 'X');
                        pcVar45[0x39] = -(cVar25 == 'X');
                        pcVar45[0x3a] = -(cVar26 == 'X');
                        pcVar45[0x3b] = -(cVar27 == 'X');
                        pcVar45[0x3c] = -(cVar28 == 'X');
                        pcVar45[0x3d] = -(cVar29 == 'X');
                        pcVar45[0x3e] = -(cVar30 == 'X');
                        pcVar45[0x3f] = -(cVar31 == 'X');
                        iVar42 = 0x40;
                    }
                    do {
                        cVar33 = '\0';
                        if (pcVar40[iVar42] == 'X') {
                            cVar33 = -1;
                        }
                        iVar44 = iVar42 + 1;
                        pcVar45[iVar42] = cVar33;
                        iVar42 = iVar44;
                    } while (iVar44 < 0x7a);
                    pcVar40 = pcVar40 + 0x7a;
                    pcVar45 = pcVar45 + *(int32_t *)(iVar1 + 0x1c);
                    iVar41 = iVar41 + -1;
                } while (iVar41 != 0);
            }
        } else if (iVar42 == 0) {
            puVar39 = (undefined8 *)
                      ((int64_t)(int32_t)((uVar49 * *(int32_t *)(iVar1 + 0x1c) + uVar50) * *(int32_t *)(iVar1 + 0x24)) +
                      *(int64_t *)(iVar1 + 0x28));
            *puVar39 = 0xffffffffffffffff;
            *(undefined8 *)((int64_t)puVar39 + (int64_t)*(int32_t *)(iVar1 + 0x1c) * 4) = 0xffffffffffffffff;
        } else if (iVar42 == 1) {
            puVar38 = (undefined2 *)
                      ((int64_t)(int32_t)((uVar49 * *(int32_t *)(iVar1 + 0x1c) + uVar50) * *(int32_t *)(iVar1 + 0x24)) +
                      *(int64_t *)(iVar1 + 0x28));
            *puVar38 = 0xffff;
            *(undefined2 *)((int64_t)*(int32_t *)(iVar1 + 0x1c) + (int64_t)puVar38) = 0xffff;
        }
    } else {
        uVar50 = (uint32_t)*puVar36;
        uVar49 = (uint32_t)puVar36[1];
    }
    *(float *)(arg1 + 0x5c) = ((float)uVar50 + 0.5) * *(float *)(arg1 + 0x54);
    *(float *)(arg1 + 0x60) = ((float)uVar49 + 0.5) * *(float *)(arg1 + 0x58);
    return;
}

// ============================================================
// Function: FUN_180128d60
// Address: 0x180128d60
// Size: 24 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018012904b)
// WARNING: Removing unreachable block (ram,0x000180129056)
// WARNING: Removing unreachable block (ram,0x000180129082)
// WARNING: Removing unreachable block (ram,0x000180129090)
// WARNING: Removing unreachable block (ram,0x000180129097)
// WARNING: Removing unreachable block (ram,0x00018012909d)
// WARNING: Removing unreachable block (ram,0x0001801290b0)
// WARNING: Removing unreachable block (ram,0x0001801290b6)
// WARNING: Removing unreachable block (ram,0x0001801290bc)
// WARNING: Removing unreachable block (ram,0x0001801290d0)
// WARNING: Removing unreachable block (ram,0x0001801290d6)
// WARNING: Removing unreachable block (ram,0x0001801290d9)
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h

void fcn.180128d60(int64_t arg1)
{
    float fVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint16_t *puVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined4 *puVar15;
    uint32_t uVar16;
    undefined4 *puVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((*(uint8_t *)arg1 & 4) == 0) {
        _var_68h = ZEXT816(0);
        iVar12 = *(int64_t *)(arg1 + 0x2b0);
        iVar5 = *(int64_t *)(arg1 + 0x38);
        puVar9 = (uint16_t *)func_0x00018012b530(arg1, *(undefined4 *)(iVar12 + 0xf0));
        if (puVar9 == (uint16_t *)0x0) {
            if (*(int64_t *)(arg1 + 0x2b0) == 0) {
                func_0x00018012a190(arg1);
            }
            uVar6 = func_0x00018012ae60(arg1, 0x22, 0x21, 0);
            if ((uVar6 != 0xffffffff) && (func_0x000180128440(arg1, uVar6, &var_68h), *(char *)(arg1 + 0x51) != '\0')) {
                iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
                iVar13 = (int64_t)(*(int32_t *)
                                    (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(uVar6 & 0x7ffff) * 4)
                                  << 0xc) >> 0xc;
                func_0x000180127510(arg1, *(undefined8 *)(arg1 + 0x38), *(undefined2 *)(iVar14 + iVar13 * 8), 
                                    *(undefined2 *)(iVar14 + 2 + iVar13 * 8), *(undefined2 *)(iVar14 + 4 + iVar13 * 8), 
                                    *(undefined2 *)(iVar14 + 6 + iVar13 * 8));
            }
            uVar3 = var_68h._4_2_;
            uVar2 = (uint16_t)var_68h;
            uVar16 = (uint32_t)var_68h._2_2_;
            *(uint32_t *)(iVar12 + 0xf0) = uVar6;
            uVar6 = 0;
            do {
                iVar7 = (int32_t)(uVar3 - uVar6) / 2;
                iVar12 = (int64_t)iVar7;
                iVar11 = ((uint32_t)uVar3 - iVar7) - uVar6;
                if (*(int32_t *)(iVar5 + 0x18) == 1) {
                    iVar14 = (int64_t)(int32_t)(((uVar6 + uVar16) * *(int32_t *)(iVar5 + 0x1c) + (uint32_t)uVar2) *
                                               *(int32_t *)(iVar5 + 0x24)) + *(int64_t *)(iVar5 + 0x28);
                    if (0 < iVar7) {
                        func_0x0001804986e0(iVar14, 0, iVar12);
                    }
                    if (uVar6 != 0) {
                        func_0x0001804986e0(iVar14 + iVar12, 0xff, uVar6);
                    }
                    if (0 < iVar11) {
                        func_0x0001804986e0((uint64_t)uVar6 + iVar14 + iVar12, 0, (int64_t)iVar11);
                    }
                } else if (*(int32_t *)(iVar5 + 0x18) == 0) {
                    puVar17 = (undefined4 *)
                              ((int64_t)(int32_t)(((uVar6 + uVar16) * *(int32_t *)(iVar5 + 0x1c) + (uint32_t)uVar2) *
                                                 *(int32_t *)(iVar5 + 0x24)) + *(int64_t *)(iVar5 + 0x28));
                    iVar14 = iVar12;
                    puVar15 = puVar17;
                    if (0 < iVar7) {
                        for (; iVar14 != 0; iVar14 = iVar14 + -1) {
                            *puVar15 = 0xffffff;
                            puVar15 = puVar15 + 1;
                        }
                    }
                    if (uVar6 != 0) {
                        func_0x0001804986e0(puVar17 + iVar12, 0xffffffff, (uint64_t)uVar6 << 2);
                    }
                    if (0 < iVar11) {
                        puVar15 = puVar17 + (uint64_t)uVar6 + iVar12;
                        for (iVar14 = (int64_t)iVar11; iVar14 != 0; iVar14 = iVar14 + -1) {
                            *puVar15 = 0xffffff;
                            puVar15 = puVar15 + 1;
                        }
                    }
                }
                fVar1 = *(float *)(arg1 + 0x54);
                iVar11 = uVar6 + uVar16;
                uVar10 = (uint64_t)uVar6;
                iVar8 = uVar2 + 1 + iVar7 + uVar6;
                uVar6 = uVar6 + 1;
                fVar18 = ((float)(iVar11 + 1) * *(float *)(arg1 + 0x58) + (float)iVar11 * *(float *)(arg1 + 0x58)) * 0.5
                ;
                *(float *)(arg1 + 0x88 + uVar10 * 0x10) = (float)((uVar2 - 1) + iVar7) * fVar1;
                *(float *)(arg1 + 0x8c + uVar10 * 0x10) = fVar18;
                *(float *)(arg1 + 0x90 + uVar10 * 0x10) = (float)iVar8 * fVar1;
                *(float *)(arg1 + 0x94 + uVar10 * 0x10) = fVar18;
            } while ((int32_t)uVar6 < 0x21);
        } else {
            uVar2 = *puVar9;
            uVar3 = puVar9[1];
            uVar6 = 0;
            uVar4 = puVar9[2];
            do {
                iVar7 = (int32_t)(uVar4 - uVar6) / 2;
                fVar1 = *(float *)(arg1 + 0x54);
                iVar8 = uVar3 + uVar6;
                uVar10 = (uint64_t)uVar6;
                iVar11 = uVar2 + 1 + iVar7 + uVar6;
                uVar6 = uVar6 + 1;
                fVar18 = ((float)(iVar8 + 1) * *(float *)(arg1 + 0x58) + (float)iVar8 * *(float *)(arg1 + 0x58)) * 0.5;
                *(float *)(arg1 + 0x88 + uVar10 * 0x10) = (float)((uVar2 - 1) + iVar7) * fVar1;
                *(float *)(arg1 + 0x8c + uVar10 * 0x10) = fVar18;
                *(float *)(arg1 + 0x90 + uVar10 * 0x10) = (float)iVar11 * fVar1;
                *(float *)(arg1 + 0x94 + uVar10 * 0x10) = fVar18;
            } while ((int32_t)uVar6 < 0x21);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180128d78
// Address: 0x180128d78
// Size: 1086 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018012904b)
// WARNING: Removing unreachable block (ram,0x000180129056)
// WARNING: Removing unreachable block (ram,0x000180129082)
// WARNING: Removing unreachable block (ram,0x000180129090)
// WARNING: Removing unreachable block (ram,0x000180129097)
// WARNING: Removing unreachable block (ram,0x00018012909d)
// WARNING: Removing unreachable block (ram,0x0001801290b0)
// WARNING: Removing unreachable block (ram,0x0001801290b6)
// WARNING: Removing unreachable block (ram,0x0001801290bc)
// WARNING: Removing unreachable block (ram,0x0001801290d0)
// WARNING: Removing unreachable block (ram,0x0001801290d6)
// WARNING: Removing unreachable block (ram,0x0001801290d9)
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h

void fcn.180128d60(int64_t arg1)
{
    float fVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint16_t *puVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined4 *puVar15;
    uint32_t uVar16;
    undefined4 *puVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((*(uint8_t *)arg1 & 4) == 0) {
        _var_68h = ZEXT816(0);
        iVar12 = *(int64_t *)(arg1 + 0x2b0);
        iVar5 = *(int64_t *)(arg1 + 0x38);
        puVar9 = (uint16_t *)func_0x00018012b530(arg1, *(undefined4 *)(iVar12 + 0xf0));
        if (puVar9 == (uint16_t *)0x0) {
            if (*(int64_t *)(arg1 + 0x2b0) == 0) {
                func_0x00018012a190(arg1);
            }
            uVar6 = func_0x00018012ae60(arg1, 0x22, 0x21, 0);
            if ((uVar6 != 0xffffffff) && (func_0x000180128440(arg1, uVar6, &var_68h), *(char *)(arg1 + 0x51) != '\0')) {
                iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
                iVar13 = (int64_t)(*(int32_t *)
                                    (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(uVar6 & 0x7ffff) * 4)
                                  << 0xc) >> 0xc;
                func_0x000180127510(arg1, *(undefined8 *)(arg1 + 0x38), *(undefined2 *)(iVar14 + iVar13 * 8), 
                                    *(undefined2 *)(iVar14 + 2 + iVar13 * 8), *(undefined2 *)(iVar14 + 4 + iVar13 * 8), 
                                    *(undefined2 *)(iVar14 + 6 + iVar13 * 8));
            }
            uVar3 = var_68h._4_2_;
            uVar2 = (uint16_t)var_68h;
            uVar16 = (uint32_t)var_68h._2_2_;
            *(uint32_t *)(iVar12 + 0xf0) = uVar6;
            uVar6 = 0;
            do {
                iVar7 = (int32_t)(uVar3 - uVar6) / 2;
                iVar12 = (int64_t)iVar7;
                iVar11 = ((uint32_t)uVar3 - iVar7) - uVar6;
                if (*(int32_t *)(iVar5 + 0x18) == 1) {
                    iVar14 = (int64_t)(int32_t)(((uVar6 + uVar16) * *(int32_t *)(iVar5 + 0x1c) + (uint32_t)uVar2) *
                                               *(int32_t *)(iVar5 + 0x24)) + *(int64_t *)(iVar5 + 0x28);
                    if (0 < iVar7) {
                        func_0x0001804986e0(iVar14, 0, iVar12);
                    }
                    if (uVar6 != 0) {
                        func_0x0001804986e0(iVar14 + iVar12, 0xff, uVar6);
                    }
                    if (0 < iVar11) {
                        func_0x0001804986e0((uint64_t)uVar6 + iVar14 + iVar12, 0, (int64_t)iVar11);
                    }
                } else if (*(int32_t *)(iVar5 + 0x18) == 0) {
                    puVar17 = (undefined4 *)
                              ((int64_t)(int32_t)(((uVar6 + uVar16) * *(int32_t *)(iVar5 + 0x1c) + (uint32_t)uVar2) *
                                                 *(int32_t *)(iVar5 + 0x24)) + *(int64_t *)(iVar5 + 0x28));
                    iVar14 = iVar12;
                    puVar15 = puVar17;
                    if (0 < iVar7) {
                        for (; iVar14 != 0; iVar14 = iVar14 + -1) {
                            *puVar15 = 0xffffff;
                            puVar15 = puVar15 + 1;
                        }
                    }
                    if (uVar6 != 0) {
                        func_0x0001804986e0(puVar17 + iVar12, 0xffffffff, (uint64_t)uVar6 << 2);
                    }
                    if (0 < iVar11) {
                        puVar15 = puVar17 + (uint64_t)uVar6 + iVar12;
                        for (iVar14 = (int64_t)iVar11; iVar14 != 0; iVar14 = iVar14 + -1) {
                            *puVar15 = 0xffffff;
                            puVar15 = puVar15 + 1;
                        }
                    }
                }
                fVar1 = *(float *)(arg1 + 0x54);
                iVar11 = uVar6 + uVar16;
                uVar10 = (uint64_t)uVar6;
                iVar8 = uVar2 + 1 + iVar7 + uVar6;
                uVar6 = uVar6 + 1;
                fVar18 = ((float)(iVar11 + 1) * *(float *)(arg1 + 0x58) + (float)iVar11 * *(float *)(arg1 + 0x58)) * 0.5
                ;
                *(float *)(arg1 + 0x88 + uVar10 * 0x10) = (float)((uVar2 - 1) + iVar7) * fVar1;
                *(float *)(arg1 + 0x8c + uVar10 * 0x10) = fVar18;
                *(float *)(arg1 + 0x90 + uVar10 * 0x10) = (float)iVar8 * fVar1;
                *(float *)(arg1 + 0x94 + uVar10 * 0x10) = fVar18;
            } while ((int32_t)uVar6 < 0x21);
        } else {
            uVar2 = *puVar9;
            uVar3 = puVar9[1];
            uVar6 = 0;
            uVar4 = puVar9[2];
            do {
                iVar7 = (int32_t)(uVar4 - uVar6) / 2;
                fVar1 = *(float *)(arg1 + 0x54);
                iVar8 = uVar3 + uVar6;
                uVar10 = (uint64_t)uVar6;
                iVar11 = uVar2 + 1 + iVar7 + uVar6;
                uVar6 = uVar6 + 1;
                fVar18 = ((float)(iVar8 + 1) * *(float *)(arg1 + 0x58) + (float)iVar8 * *(float *)(arg1 + 0x58)) * 0.5;
                *(float *)(arg1 + 0x88 + uVar10 * 0x10) = (float)((uVar2 - 1) + iVar7) * fVar1;
                *(float *)(arg1 + 0x8c + uVar10 * 0x10) = fVar18;
                *(float *)(arg1 + 0x90 + uVar10 * 0x10) = (float)iVar11 * fVar1;
                *(float *)(arg1 + 0x94 + uVar10 * 0x10) = fVar18;
            } while ((int32_t)uVar6 < 0x21);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801291b6
// Address: 0x1801291b6
// Size: 10 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018012904b)
// WARNING: Removing unreachable block (ram,0x000180129056)
// WARNING: Removing unreachable block (ram,0x000180129082)
// WARNING: Removing unreachable block (ram,0x000180129090)
// WARNING: Removing unreachable block (ram,0x000180129097)
// WARNING: Removing unreachable block (ram,0x00018012909d)
// WARNING: Removing unreachable block (ram,0x0001801290b0)
// WARNING: Removing unreachable block (ram,0x0001801290b6)
// WARNING: Removing unreachable block (ram,0x0001801290bc)
// WARNING: Removing unreachable block (ram,0x0001801290d0)
// WARNING: Removing unreachable block (ram,0x0001801290d6)
// WARNING: Removing unreachable block (ram,0x0001801290d9)
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h

void fcn.180128d60(int64_t arg1)
{
    float fVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint16_t *puVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined4 *puVar15;
    uint32_t uVar16;
    undefined4 *puVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((*(uint8_t *)arg1 & 4) == 0) {
        _var_68h = ZEXT816(0);
        iVar12 = *(int64_t *)(arg1 + 0x2b0);
        iVar5 = *(int64_t *)(arg1 + 0x38);
        puVar9 = (uint16_t *)func_0x00018012b530(arg1, *(undefined4 *)(iVar12 + 0xf0));
        if (puVar9 == (uint16_t *)0x0) {
            if (*(int64_t *)(arg1 + 0x2b0) == 0) {
                func_0x00018012a190(arg1);
            }
            uVar6 = func_0x00018012ae60(arg1, 0x22, 0x21, 0);
            if ((uVar6 != 0xffffffff) && (func_0x000180128440(arg1, uVar6, &var_68h), *(char *)(arg1 + 0x51) != '\0')) {
                iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
                iVar13 = (int64_t)(*(int32_t *)
                                    (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(uVar6 & 0x7ffff) * 4)
                                  << 0xc) >> 0xc;
                func_0x000180127510(arg1, *(undefined8 *)(arg1 + 0x38), *(undefined2 *)(iVar14 + iVar13 * 8), 
                                    *(undefined2 *)(iVar14 + 2 + iVar13 * 8), *(undefined2 *)(iVar14 + 4 + iVar13 * 8), 
                                    *(undefined2 *)(iVar14 + 6 + iVar13 * 8));
            }
            uVar3 = var_68h._4_2_;
            uVar2 = (uint16_t)var_68h;
            uVar16 = (uint32_t)var_68h._2_2_;
            *(uint32_t *)(iVar12 + 0xf0) = uVar6;
            uVar6 = 0;
            do {
                iVar7 = (int32_t)(uVar3 - uVar6) / 2;
                iVar12 = (int64_t)iVar7;
                iVar11 = ((uint32_t)uVar3 - iVar7) - uVar6;
                if (*(int32_t *)(iVar5 + 0x18) == 1) {
                    iVar14 = (int64_t)(int32_t)(((uVar6 + uVar16) * *(int32_t *)(iVar5 + 0x1c) + (uint32_t)uVar2) *
                                               *(int32_t *)(iVar5 + 0x24)) + *(int64_t *)(iVar5 + 0x28);
                    if (0 < iVar7) {
                        func_0x0001804986e0(iVar14, 0, iVar12);
                    }
                    if (uVar6 != 0) {
                        func_0x0001804986e0(iVar14 + iVar12, 0xff, uVar6);
                    }
                    if (0 < iVar11) {
                        func_0x0001804986e0((uint64_t)uVar6 + iVar14 + iVar12, 0, (int64_t)iVar11);
                    }
                } else if (*(int32_t *)(iVar5 + 0x18) == 0) {
                    puVar17 = (undefined4 *)
                              ((int64_t)(int32_t)(((uVar6 + uVar16) * *(int32_t *)(iVar5 + 0x1c) + (uint32_t)uVar2) *
                                                 *(int32_t *)(iVar5 + 0x24)) + *(int64_t *)(iVar5 + 0x28));
                    iVar14 = iVar12;
                    puVar15 = puVar17;
                    if (0 < iVar7) {
                        for (; iVar14 != 0; iVar14 = iVar14 + -1) {
                            *puVar15 = 0xffffff;
                            puVar15 = puVar15 + 1;
                        }
                    }
                    if (uVar6 != 0) {
                        func_0x0001804986e0(puVar17 + iVar12, 0xffffffff, (uint64_t)uVar6 << 2);
                    }
                    if (0 < iVar11) {
                        puVar15 = puVar17 + (uint64_t)uVar6 + iVar12;
                        for (iVar14 = (int64_t)iVar11; iVar14 != 0; iVar14 = iVar14 + -1) {
                            *puVar15 = 0xffffff;
                            puVar15 = puVar15 + 1;
                        }
                    }
                }
                fVar1 = *(float *)(arg1 + 0x54);
                iVar11 = uVar6 + uVar16;
                uVar10 = (uint64_t)uVar6;
                iVar8 = uVar2 + 1 + iVar7 + uVar6;
                uVar6 = uVar6 + 1;
                fVar18 = ((float)(iVar11 + 1) * *(float *)(arg1 + 0x58) + (float)iVar11 * *(float *)(arg1 + 0x58)) * 0.5
                ;
                *(float *)(arg1 + 0x88 + uVar10 * 0x10) = (float)((uVar2 - 1) + iVar7) * fVar1;
                *(float *)(arg1 + 0x8c + uVar10 * 0x10) = fVar18;
                *(float *)(arg1 + 0x90 + uVar10 * 0x10) = (float)iVar8 * fVar1;
                *(float *)(arg1 + 0x94 + uVar10 * 0x10) = fVar18;
            } while ((int32_t)uVar6 < 0x21);
        } else {
            uVar2 = *puVar9;
            uVar3 = puVar9[1];
            uVar6 = 0;
            uVar4 = puVar9[2];
            do {
                iVar7 = (int32_t)(uVar4 - uVar6) / 2;
                fVar1 = *(float *)(arg1 + 0x54);
                iVar8 = uVar3 + uVar6;
                uVar10 = (uint64_t)uVar6;
                iVar11 = uVar2 + 1 + iVar7 + uVar6;
                uVar6 = uVar6 + 1;
                fVar18 = ((float)(iVar8 + 1) * *(float *)(arg1 + 0x58) + (float)iVar8 * *(float *)(arg1 + 0x58)) * 0.5;
                *(float *)(arg1 + 0x88 + uVar10 * 0x10) = (float)((uVar2 - 1) + iVar7) * fVar1;
                *(float *)(arg1 + 0x8c + uVar10 * 0x10) = fVar18;
                *(float *)(arg1 + 0x90 + uVar10 * 0x10) = (float)iVar11 * fVar1;
                *(float *)(arg1 + 0x94 + uVar10 * 0x10) = fVar18;
            } while ((int32_t)uVar6 < 0x21);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801291c0
// Address: 0x1801291c0
// Size: 131 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801291c0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int64_t *)(arg2 + 8) != 0) {
        func_0x000180129580();
    }
    *(undefined *)(arg2 + 0x34) = 0;
    *(undefined8 *)arg2 = 0;
    piVar3 = *(int64_t **)(arg2 + 0x28);
    piVar1 = piVar3 + *(int32_t *)(arg2 + 0x20);
    for (; piVar3 != piVar1; piVar3 = piVar3 + 1) {
        iVar2 = *(int64_t *)(*piVar3 + 0x88);
        if (((iVar2 != 0) || (iVar2 = *(int64_t *)(arg1 + 0x2b8), iVar2 != 0)) &&
           (*(code **)(iVar2 + 0x20) != (code *)0x0)) {
            (**(code **)(iVar2 + 0x20))(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180129250
// Address: 0x180129250
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.180129250(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int16_t iVar1;
    char cVar2;
    int64_t *piVar3;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    int64_t var_18h;
    
    if (*(char *)(arg3 + 0x35) == '\0') {
        if (*(int64_t *)(arg2 + 8) != 0) {
            func_0x000180129580();
        }
        *(undefined *)(arg2 + 0x34) = 0;
        *(undefined8 *)arg2 = 0;
        *(int64_t *)(arg2 + 8) = arg1;
    }
    *(undefined *)(arg1 + 0x52) = 0;
    uStack_20._0_2_ = *(int16_t *)(arg2 + 0x32);
    uStack_20._2_4_ = 0x3ffffd;
    uStack_20._6_2_ = 0x20;
    if (*(int16_t *)(arg2 + 0x32) == 0) {
        piVar3 = &uStack_20;
        do {
            iVar1 = *(int16_t *)piVar3;
            if ((iVar1 != 0) && (cVar2 = func_0x00018012ebf0(arg2, iVar1), cVar2 != '\0')) {
                *(int16_t *)(arg2 + 0x32) = iVar1;
                break;
            }
            piVar3 = (int64_t *)((int64_t)piVar3 + 2);
        } while (piVar3 != &var_18h);
    }
    var_28h._0_2_ = *(undefined2 *)(arg3 + 0x3a);
    var_28h._2_4_ = 0x852026;
    if (*(int16_t *)(arg2 + 0x30) == 0) {
        piVar3 = &var_28h;
        do {
            iVar1 = *(int16_t *)piVar3;
            if ((iVar1 != 0) && (cVar2 = func_0x00018012ebf0(arg2, iVar1), cVar2 != '\0')) {
                *(int16_t *)(arg2 + 0x30) = iVar1;
                break;
            }
            piVar3 = (int64_t *)((int64_t)piVar3 + 2);
        } while (piVar3 != (int64_t *)((int64_t)&var_28h + 6));
    }
    if (*(int16_t *)(arg2 + 0x30) == 0) {
        *(undefined2 *)(arg2 + 0x30) = 0x85;
        *(undefined *)(arg2 + 0x35) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_18012925f
// Address: 0x18012925f
// Size: 222 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.180129250(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int16_t iVar1;
    char cVar2;
    int64_t *piVar3;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    int64_t var_18h;
    
    if (*(char *)(arg3 + 0x35) == '\0') {
        if (*(int64_t *)(arg2 + 8) != 0) {
            func_0x000180129580();
        }
        *(undefined *)(arg2 + 0x34) = 0;
        *(undefined8 *)arg2 = 0;
        *(int64_t *)(arg2 + 8) = arg1;
    }
    *(undefined *)(arg1 + 0x52) = 0;
    uStack_20._0_2_ = *(int16_t *)(arg2 + 0x32);
    uStack_20._2_4_ = 0x3ffffd;
    uStack_20._6_2_ = 0x20;
    if (*(int16_t *)(arg2 + 0x32) == 0) {
        piVar3 = &uStack_20;
        do {
            iVar1 = *(int16_t *)piVar3;
            if ((iVar1 != 0) && (cVar2 = func_0x00018012ebf0(arg2, iVar1), cVar2 != '\0')) {
                *(int16_t *)(arg2 + 0x32) = iVar1;
                break;
            }
            piVar3 = (int64_t *)((int64_t)piVar3 + 2);
        } while (piVar3 != &var_18h);
    }
    var_28h._0_2_ = *(undefined2 *)(arg3 + 0x3a);
    var_28h._2_4_ = 0x852026;
    if (*(int16_t *)(arg2 + 0x30) == 0) {
        piVar3 = &var_28h;
        do {
            iVar1 = *(int16_t *)piVar3;
            if ((iVar1 != 0) && (cVar2 = func_0x00018012ebf0(arg2, iVar1), cVar2 != '\0')) {
                *(int16_t *)(arg2 + 0x30) = iVar1;
                break;
            }
            piVar3 = (int64_t *)((int64_t)piVar3 + 2);
        } while (piVar3 != (int64_t *)((int64_t)&var_28h + 6));
    }
    if (*(int16_t *)(arg2 + 0x30) == 0) {
        *(undefined2 *)(arg2 + 0x30) = 0x85;
        *(undefined *)(arg2 + 0x35) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_18012933d
// Address: 0x18012933d
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.180129250(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int16_t iVar1;
    char cVar2;
    int64_t *piVar3;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    int64_t var_18h;
    
    if (*(char *)(arg3 + 0x35) == '\0') {
        if (*(int64_t *)(arg2 + 8) != 0) {
            func_0x000180129580();
        }
        *(undefined *)(arg2 + 0x34) = 0;
        *(undefined8 *)arg2 = 0;
        *(int64_t *)(arg2 + 8) = arg1;
    }
    *(undefined *)(arg1 + 0x52) = 0;
    uStack_20._0_2_ = *(int16_t *)(arg2 + 0x32);
    uStack_20._2_4_ = 0x3ffffd;
    uStack_20._6_2_ = 0x20;
    if (*(int16_t *)(arg2 + 0x32) == 0) {
        piVar3 = &uStack_20;
        do {
            iVar1 = *(int16_t *)piVar3;
            if ((iVar1 != 0) && (cVar2 = func_0x00018012ebf0(arg2, iVar1), cVar2 != '\0')) {
                *(int16_t *)(arg2 + 0x32) = iVar1;
                break;
            }
            piVar3 = (int64_t *)((int64_t)piVar3 + 2);
        } while (piVar3 != &var_18h);
    }
    var_28h._0_2_ = *(undefined2 *)(arg3 + 0x3a);
    var_28h._2_4_ = 0x852026;
    if (*(int16_t *)(arg2 + 0x30) == 0) {
        piVar3 = &var_28h;
        do {
            iVar1 = *(int16_t *)piVar3;
            if ((iVar1 != 0) && (cVar2 = func_0x00018012ebf0(arg2, iVar1), cVar2 != '\0')) {
                *(int16_t *)(arg2 + 0x30) = iVar1;
                break;
            }
            piVar3 = (int64_t *)((int64_t)piVar3 + 2);
        } while (piVar3 != (int64_t *)((int64_t)&var_28h + 6));
    }
    if (*(int16_t *)(arg2 + 0x30) == 0) {
        *(undefined2 *)(arg2 + 0x30) = 0x85;
        *(undefined *)(arg2 + 0x35) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_180129350
// Address: 0x180129350
// Size: 214 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

void fcn.180129350(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg1 + 0x58);
    if (*(int16_t *)(iVar1 + 0x32) != 0) {
        iVar2 = func_0x00018012eb80();
        if (iVar2 != 0) goto code_r0x0001801293ef;
    }
    iVar2 = func_0x00018012eb80(arg1, 0x20);
    var_10h._0_4_ = 0xffffffff;
    _var_30h = ZEXT816(0);
    var_38h._0_4_ = 0;
    _var_20h = ZEXT816(0);
    if (iVar2 == 0) {
        var_38h._4_4_ = (float)(int32_t)(*(float *)(arg1 + 0x14) * 0.4 + 0.5);
    } else {
        var_38h._4_4_ = *(float *)(iVar2 + 4);
    }
    iVar2 = func_0x00018012e840(*(undefined8 *)(iVar1 + 8), arg1, 0, &var_38h);
code_r0x0001801293ef:
    *(int32_t *)(arg1 + 0x40) = (int32_t)((iVar2 - *(int64_t *)(arg1 + 0x38)) / 0x2c);
    *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(iVar2 + 4);
    return;
}

// ============================================================
// Function: FUN_180129430
// Address: 0x180129430
// Size: 326 bytes
// ============================================================
void fcn.180129430(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    
    iVar6 = *(int64_t *)(arg3 + 0x38);
    iVar3 = *(int64_t *)(arg1 + 0x2b0);
    iVar4 = (int64_t)*(int32_t *)(arg3 + 0x30) * 0x2c + iVar6;
    for (; iVar6 != iVar4; iVar6 = iVar6 + 0x2c) {
        if (*(int32_t *)(iVar6 + 0x28) != -1) {
            func_0x00018012ad90(arg1);
        }
    }
    piVar5 = *(int64_t **)(arg2 + 0x28);
    iVar6 = *(int64_t *)(arg3 + 0x60);
    piVar2 = piVar5 + *(int32_t *)(arg2 + 0x20);
    for (; piVar5 != piVar2; piVar5 = piVar5 + 1) {
        iVar4 = *(int64_t *)(*piVar5 + 0x88);
        if (iVar4 == 0) {
            iVar4 = *(int64_t *)(arg1 + 0x2b8);
        }
        if (*(code **)(iVar4 + 0x38) != (code *)0x0) {
            (**(code **)(iVar4 + 0x38))(arg1, *piVar5, arg3, iVar6);
        }
        iVar6 = iVar6 + *(int64_t *)(iVar4 + 0x48);
    }
    if (*(int64_t *)(arg3 + 0x60) != 0) {
        func_0x000180460d90();
        *(undefined8 *)(arg3 + 0x60) = 0;
    }
    func_0x0001800f6220(iVar3 + 0xd8, *(undefined4 *)(arg3 + 0x54), 0);
    piVar1 = (int32_t *)(iVar3 + 0xe8);
    *piVar1 = *piVar1 + 1;
    *(undefined4 *)(arg3 + 0x10) = 0;
    if (*(int64_t *)(arg3 + 0x38) != 0) {
        *(undefined8 *)(arg3 + 0x30) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg3 + 0x38) = 0;
    }
    if (*(int64_t *)(arg3 + 8) != 0) {
        *(undefined8 *)arg3 = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg3 + 8) = 0;
    }
    if (*(int64_t *)(arg3 + 0x28) != 0) {
        *(undefined8 *)(arg3 + 0x20) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg3 + 0x28) = 0;
    }
    *(uint32_t *)(arg3 + 0x4c) = *(uint32_t *)(arg3 + 0x4c) & 0xfc000000;
    *(uint32_t *)(arg3 + 0x4c) = *(uint32_t *)(arg3 + 0x4c) | 0x4000000;
    *(undefined4 *)(arg3 + 0x40) = 0xffffffff;
    *(undefined8 *)(arg3 + 0x44) = 0;
    *(undefined8 *)arg2 = 0;
    return;
}

// ============================================================
// Function: FUN_180129580
// Address: 0x180129580
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel

void fcn.180129580(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t arg3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x2b0);
    if ((iVar1 != 0) && (uVar4 = 0, 0 < *(int32_t *)(iVar1 + 0xc0))) {
        do {
            uVar2 = uVar4 & 0x1f;
            uVar3 = uVar4;
            if ((int32_t)uVar4 < 0) {
                uVar3 = uVar4 + 0x1f;
                uVar2 = uVar2 - 0x20;
            }
            arg3 = *(int64_t *)(*(int64_t *)(iVar1 + 0xd0) + (int64_t)((int32_t)uVar3 >> 5) * 8) +
                   (int64_t)(int32_t)uVar2 * 0x68;
            if (((*(int32_t *)(arg3 + 0x50) <= *(int32_t *)(*(int64_t *)(arg1 + 0x2b0) + 0xa4)) &&
                (*(int64_t *)(arg3 + 0x58) == arg2)) && ((*(uint32_t *)(arg3 + 0x4c) & 0x4000000) == 0)) {
                fcn.180129430(arg1, arg2, arg3);
            }
            uVar4 = uVar4 + 1;
        } while ((int32_t)uVar4 < *(int32_t *)(iVar1 + 0xc0));
    }
    return;
}

// ============================================================
// Function: FUN_1801295a1
// Address: 0x1801295a1
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel

void fcn.180129580(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t arg3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x2b0);
    if ((iVar1 != 0) && (uVar4 = 0, 0 < *(int32_t *)(iVar1 + 0xc0))) {
        do {
            uVar2 = uVar4 & 0x1f;
            uVar3 = uVar4;
            if ((int32_t)uVar4 < 0) {
                uVar3 = uVar4 + 0x1f;
                uVar2 = uVar2 - 0x20;
            }
            arg3 = *(int64_t *)(*(int64_t *)(iVar1 + 0xd0) + (int64_t)((int32_t)uVar3 >> 5) * 8) +
                   (int64_t)(int32_t)uVar2 * 0x68;
            if (((*(int32_t *)(arg3 + 0x50) <= *(int32_t *)(*(int64_t *)(arg1 + 0x2b0) + 0xa4)) &&
                (*(int64_t *)(arg3 + 0x58) == arg2)) && ((*(uint32_t *)(arg3 + 0x4c) & 0x4000000) == 0)) {
                fcn.180129430(arg1, arg2, arg3);
            }
            uVar4 = uVar4 + 1;
        } while ((int32_t)uVar4 < *(int32_t *)(iVar1 + 0xc0));
    }
    return;
}

// ============================================================
// Function: FUN_180129618
// Address: 0x180129618
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel

void fcn.180129580(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t arg3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x2b0);
    if ((iVar1 != 0) && (uVar4 = 0, 0 < *(int32_t *)(iVar1 + 0xc0))) {
        do {
            uVar2 = uVar4 & 0x1f;
            uVar3 = uVar4;
            if ((int32_t)uVar4 < 0) {
                uVar3 = uVar4 + 0x1f;
                uVar2 = uVar2 - 0x20;
            }
            arg3 = *(int64_t *)(*(int64_t *)(iVar1 + 0xd0) + (int64_t)((int32_t)uVar3 >> 5) * 8) +
                   (int64_t)(int32_t)uVar2 * 0x68;
            if (((*(int32_t *)(arg3 + 0x50) <= *(int32_t *)(*(int64_t *)(arg1 + 0x2b0) + 0xa4)) &&
                (*(int64_t *)(arg3 + 0x58) == arg2)) && ((*(uint32_t *)(arg3 + 0x4c) & 0x4000000) == 0)) {
                fcn.180129430(arg1, arg2, arg3);
            }
            uVar4 = uVar4 + 1;
        } while ((int32_t)uVar4 < *(int32_t *)(iVar1 + 0xc0));
    }
    return;
}

// ============================================================
// Function: FUN_180129630
// Address: 0x180129630
// Size: 146 bytes
// ============================================================
void fcn.180129630(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t arg3;
    
    iVar1 = *(int64_t *)(arg1 + 0x2b0);
    uVar4 = 0;
    if (0 < *(int32_t *)(iVar1 + 0xc0)) {
        do {
            uVar2 = uVar4 & 0x1f;
            uVar3 = uVar4;
            if ((int32_t)uVar4 < 0) {
                uVar3 = uVar4 + 0x1f;
                uVar2 = uVar2 - 0x20;
            }
            arg3 = *(int64_t *)(*(int64_t *)(iVar1 + 0xd0) + (int64_t)((int32_t)uVar3 >> 5) * 8) +
                   (int64_t)(int32_t)uVar2 * 0x68;
            if (((*(int32_t *)(arg3 + 0x50) + (int32_t)arg2 <= *(int32_t *)(*(int64_t *)(arg1 + 0x2b0) + 0xa4)) &&
                ((*(uint32_t *)(arg3 + 0x4c) & 0x4000000) == 0)) &&
               ((*(uint8_t *)(*(int64_t *)(arg3 + 0x58) + 0x10) & 8) == 0)) {
                fcn.180129430(arg1, *(int64_t *)(arg3 + 0x58), arg3);
            }
            uVar4 = uVar4 + 1;
        } while ((int32_t)uVar4 < *(int32_t *)(iVar1 + 0xc0));
    }
    return;
}

// ============================================================
// Function: FUN_1801296d0
// Address: 0x1801296d0
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801296d0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t *piVar1;
    int32_t **ppiVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int32_t **ppiVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)(arg1 + 0x28);
    iVar6 = *(int64_t *)(arg1 + 0x30);
    *(int64_t *)(arg1 + 0x38) = arg2;
    iVar3 = *(int32_t *)(arg2 + 0x20);
    iVar4 = *(int32_t *)(arg2 + 0x1c);
    *(int64_t *)(arg1 + 0x28) = arg2;
    *(float *)(arg1 + 0x58) = 1.0 / (float)iVar3;
    *(float *)(arg1 + 0x54) = 1.0 / (float)iVar4;
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    for (; piVar11 != piVar1; piVar11 = piVar11 + 1) {
        iVar7 = *piVar11;
        if ((*(int64_t *)(iVar7 + 0x68) == 0) || (*(char *)(*(int64_t *)(iVar7 + 0x68) + 1) != '\0')) {
            ppiVar12 = *(int32_t ***)(iVar7 + 0x60);
            ppiVar2 = ppiVar12 + *(int32_t *)(iVar7 + 0x58);
            for (; ppiVar12 != ppiVar2; ppiVar12 = ppiVar12 + 1) {
                piVar8 = *ppiVar12;
                if ((((0 < *piVar8) && (*(int64_t *)(piVar8 + 0x1e) == iVar6)) && (*(int64_t *)(piVar8 + 0x1c) == iVar5)
                    ) && (*(int64_t *)(piVar8 + 0x1c) != arg2)) {
                    *(int64_t *)(piVar8 + 0x1c) = arg2;
                    *(int64_t *)(piVar8 + 0x1e) = iVar6;
                    iVar3 = piVar8[0x2c];
                    iVar7 = *(int64_t *)(piVar8 + 0x2e);
                    *(int64_t *)(iVar7 + -0x10 + (int64_t)iVar3 * 0x10) = arg2;
                    *(int64_t *)(iVar7 + -8 + (int64_t)iVar3 * 0x10) = iVar6;
                    func_0x000180124360(piVar8);
                }
                piVar9 = *(int64_t **)(piVar8 + 0x2e);
                piVar10 = piVar9 + (int64_t)piVar8[0x2c] * 2;
                for (; piVar9 != piVar10; piVar9 = piVar9 + 2) {
                    if ((piVar9[1] == iVar6) && (*piVar9 == iVar5)) {
                        *piVar9 = arg2;
                        piVar9[1] = iVar6;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180129737
// Address: 0x180129737
// Size: 238 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801296d0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t *piVar1;
    int32_t **ppiVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int32_t **ppiVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)(arg1 + 0x28);
    iVar6 = *(int64_t *)(arg1 + 0x30);
    *(int64_t *)(arg1 + 0x38) = arg2;
    iVar3 = *(int32_t *)(arg2 + 0x20);
    iVar4 = *(int32_t *)(arg2 + 0x1c);
    *(int64_t *)(arg1 + 0x28) = arg2;
    *(float *)(arg1 + 0x58) = 1.0 / (float)iVar3;
    *(float *)(arg1 + 0x54) = 1.0 / (float)iVar4;
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    for (; piVar11 != piVar1; piVar11 = piVar11 + 1) {
        iVar7 = *piVar11;
        if ((*(int64_t *)(iVar7 + 0x68) == 0) || (*(char *)(*(int64_t *)(iVar7 + 0x68) + 1) != '\0')) {
            ppiVar12 = *(int32_t ***)(iVar7 + 0x60);
            ppiVar2 = ppiVar12 + *(int32_t *)(iVar7 + 0x58);
            for (; ppiVar12 != ppiVar2; ppiVar12 = ppiVar12 + 1) {
                piVar8 = *ppiVar12;
                if ((((0 < *piVar8) && (*(int64_t *)(piVar8 + 0x1e) == iVar6)) && (*(int64_t *)(piVar8 + 0x1c) == iVar5)
                    ) && (*(int64_t *)(piVar8 + 0x1c) != arg2)) {
                    *(int64_t *)(piVar8 + 0x1c) = arg2;
                    *(int64_t *)(piVar8 + 0x1e) = iVar6;
                    iVar3 = piVar8[0x2c];
                    iVar7 = *(int64_t *)(piVar8 + 0x2e);
                    *(int64_t *)(iVar7 + -0x10 + (int64_t)iVar3 * 0x10) = arg2;
                    *(int64_t *)(iVar7 + -8 + (int64_t)iVar3 * 0x10) = iVar6;
                    func_0x000180124360(piVar8);
                }
                piVar9 = *(int64_t **)(piVar8 + 0x2e);
                piVar10 = piVar9 + (int64_t)piVar8[0x2c] * 2;
                for (; piVar9 != piVar10; piVar9 = piVar9 + 2) {
                    if ((piVar9[1] == iVar6) && (*piVar9 == iVar5)) {
                        *piVar9 = arg2;
                        piVar9[1] = iVar6;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180129825
// Address: 0x180129825
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801296d0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t *piVar1;
    int32_t **ppiVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int32_t **ppiVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)(arg1 + 0x28);
    iVar6 = *(int64_t *)(arg1 + 0x30);
    *(int64_t *)(arg1 + 0x38) = arg2;
    iVar3 = *(int32_t *)(arg2 + 0x20);
    iVar4 = *(int32_t *)(arg2 + 0x1c);
    *(int64_t *)(arg1 + 0x28) = arg2;
    *(float *)(arg1 + 0x58) = 1.0 / (float)iVar3;
    *(float *)(arg1 + 0x54) = 1.0 / (float)iVar4;
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    for (; piVar11 != piVar1; piVar11 = piVar11 + 1) {
        iVar7 = *piVar11;
        if ((*(int64_t *)(iVar7 + 0x68) == 0) || (*(char *)(*(int64_t *)(iVar7 + 0x68) + 1) != '\0')) {
            ppiVar12 = *(int32_t ***)(iVar7 + 0x60);
            ppiVar2 = ppiVar12 + *(int32_t *)(iVar7 + 0x58);
            for (; ppiVar12 != ppiVar2; ppiVar12 = ppiVar12 + 1) {
                piVar8 = *ppiVar12;
                if ((((0 < *piVar8) && (*(int64_t *)(piVar8 + 0x1e) == iVar6)) && (*(int64_t *)(piVar8 + 0x1c) == iVar5)
                    ) && (*(int64_t *)(piVar8 + 0x1c) != arg2)) {
                    *(int64_t *)(piVar8 + 0x1c) = arg2;
                    *(int64_t *)(piVar8 + 0x1e) = iVar6;
                    iVar3 = piVar8[0x2c];
                    iVar7 = *(int64_t *)(piVar8 + 0x2e);
                    *(int64_t *)(iVar7 + -0x10 + (int64_t)iVar3 * 0x10) = arg2;
                    *(int64_t *)(iVar7 + -8 + (int64_t)iVar3 * 0x10) = iVar6;
                    func_0x000180124360(piVar8);
                }
                piVar9 = *(int64_t **)(piVar8 + 0x2e);
                piVar10 = piVar9 + (int64_t)piVar8[0x2c] * 2;
                for (; piVar9 != piVar10; piVar9 = piVar9 + 2) {
                    if ((piVar9[1] == iVar6) && (*piVar9 == iVar5)) {
                        *piVar9 = arg2;
                        piVar9[1] = iVar6;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180129840
// Address: 0x180129840
// Size: 357 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined (*) [16] fcn.180129840(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*arg2_00) [16];
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t in_stack_00000008;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)(arg1 + 0x38);
    arg2_00 = (undefined (*) [16])func_0x00018046d050(0x58);
    iVar4 = 1;
    if (arg2_00 == (undefined (*) [16])0x0) {
        arg2_00 = (undefined (*) [16])0x0;
    } else {
        *arg2_00 = ZEXT816(0);
        arg2_00[1] = ZEXT816(0);
        arg2_00[2] = ZEXT816(0);
        arg2_00[3] = ZEXT816(0);
        arg2_00[4] = ZEXT816(0);
        *(undefined8 *)arg2_00[5] = 0;
        *(undefined4 *)(*arg2_00 + 4) = 1;
    }
    iVar2 = *(int32_t *)(arg1 + 0x298);
    *(int32_t *)(arg1 + 0x298) = iVar2 + 1;
    *(int32_t *)*arg2_00 = iVar2;
    iVar2 = *(int32_t *)(arg1 + 0x44);
    if (*(int32_t *)(arg1 + 0x40) == iVar2) {
        iVar5 = *(int32_t *)(arg1 + 0x40) + 1;
        if (iVar2 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar2 / 2 + iVar2;
        }
        if (iVar5 < iVar2) {
            iVar5 = iVar2;
        }
        func_0x00018011f4f0(arg1 + 0x40, iVar5);
    }
    *(undefined (**) [16])(*(int64_t *)(arg1 + 0x48) + (int64_t)*(int32_t *)(arg1 + 0x40) * 8) = arg2_00;
    *(int32_t *)(arg1 + 0x40) = *(int32_t *)(arg1 + 0x40) + 1;
    if (iVar1 != 0) {
        *(undefined *)(iVar1 + 0x57) = 1;
    }
    iVar2 = *(int32_t *)(arg1 + 4);
    if (*(int64_t *)(arg2_00[2] + 8) != 0) {
        func_0x000180460d90();
    }
    *(undefined8 *)(arg2_00[2] + 8) = 0;
    *(int32_t *)(arg2_00[1] + 8) = iVar2;
    *(undefined4 *)(*arg2_00 + 4) = 2;
    *(int32_t *)(arg2_00[1] + 0xc) = (int32_t)arg2;
    *(int32_t *)arg2_00[2] = (int32_t)arg3;
    if (iVar2 == 0) {
        iVar4 = 4;
    } else if (iVar2 != 1) {
        iVar4 = 0;
    }
    *(int32_t *)(arg2_00[2] + 4) = iVar4;
    arg2_00[5][6] = 0;
    uVar3 = func_0x00018046d050((int64_t)(iVar4 * (int32_t)arg2 * (int32_t)arg3));
    *(undefined8 *)(arg2_00[2] + 8) = uVar3;
    func_0x0001804986e0(uVar3, 0, 
                        (int64_t)(*(int32_t *)arg2_00[2] * *(int32_t *)(arg2_00[2] + 4) * *(int32_t *)(arg2_00[1] + 0xc)
                                 ));
    *(undefined4 *)(arg2_00[3] + 8) = 0xffffffff;
    *(undefined4 *)(arg2_00[3] + 0xc) = 0;
    *(undefined8 *)arg2_00[3] = 0;
    *(undefined *)(arg1 + 0x52) = 0;
    fcn.1801296d0(arg1, (int64_t)arg2_00, in_stack_00000008);
    return arg2_00;
}

// ============================================================
// Function: FUN_1801299b0
// Address: 0x1801299b0
// Size: 1140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Removing arg arg_ech because it doesn't fit into ProtoModel

void fcn.1801299b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t *puVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int16_t iVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int64_t iVar16;
    int32_t iVar17;
    int32_t iVar18;
    uint32_t *puVar19;
    int64_t iVar20;
    uint32_t uVar21;
    int32_t iVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_64h;
    int64_t var_58h;
    
    iVar8 = *(int64_t *)(arg1 + 0x2b0);
    *(undefined *)(iVar8 + 0xb8) = 1;
    iVar20 = *(int64_t *)(arg1 + 0x38);
    iVar12 = fcn.180129840(arg1, arg2, arg3);
    *(undefined *)(iVar12 + 0x56) = *(undefined *)(iVar20 + 0x56);
    func_0x00018012aae0(arg1);
    var_64h._0_4_ = 0;
    stack0xffffffffffffffa0 = 0;
    iVar5 = *(int32_t *)(iVar8 + 0x70);
    iVar22 = 8;
    if (0 < iVar5) {
        iVar17 = iVar5;
        if (iVar5 < 8) {
            iVar17 = 8;
        }
        if (0 < iVar17) {
            *(int64_t *)0x0 = func_0x00018046d050((int64_t)iVar17 << 2);
            var_64h._0_4_ = iVar17;
        }
    }
    if ((stack0xffffffffffffffa0 != 0) && (*(int64_t *)(iVar8 + 0x78) != 0)) {
        func_0x000180498030(stack0xffffffffffffffa0, *(int64_t *)(iVar8 + 0x78), (int64_t)iVar5 << 2);
    }
    uVar6 = *(undefined4 *)(iVar8 + 0x60);
    *(undefined4 *)(iVar8 + 0x60) = 0;
    uVar7 = *(undefined4 *)(iVar8 + 100);
    *(undefined4 *)(iVar8 + 100) = 0;
    iVar13 = *(int64_t *)(iVar8 + 0x68);
    *(undefined8 *)(iVar8 + 0x68) = 0;
    puVar19 = *(uint32_t **)(iVar8 + 0x78);
    puVar1 = puVar19 + *(int32_t *)(iVar8 + 0x70);
    do {
        if (puVar19 == puVar1) {
            *(undefined8 *)(iVar8 + 0x9c) = 0;
            uVar10 = 0;
            if (0 < *(int32_t *)(iVar8 + 0xc0)) {
                do {
                    uVar21 = uVar10 & 0x1f;
                    uVar11 = uVar10;
                    if ((int32_t)uVar10 < 0) {
                        uVar11 = uVar10 + 0x1f;
                        uVar21 = uVar21 - 0x20;
                    }
                    iVar20 = *(int64_t *)(*(int64_t *)(iVar8 + 0xd0) + (int64_t)((int32_t)uVar11 >> 5) * 8);
                    iVar12 = *(int64_t *)(iVar20 + 0x38 + (int64_t)(int32_t)uVar21 * 0x68);
                    iVar20 = (int64_t)*(int32_t *)(iVar20 + 0x30 + (int64_t)(int32_t)uVar21 * 0x68) * 0x2c + iVar12;
                    for (; iVar12 != iVar20; iVar12 = iVar12 + 0x2c) {
                        if (*(uint32_t *)(iVar12 + 0x28) != 0xffffffff) {
                            iVar16 = (int64_t)(*(int32_t *)
                                                (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) +
                                                (uint64_t)(*(uint32_t *)(iVar12 + 0x28) & 0x7ffff) * 4) << 0xc) >> 0xc;
                            iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
                            *(float *)(iVar12 + 0x18) =
                                 (float)(uint32_t)*(uint16_t *)(iVar2 + iVar16 * 8) * *(float *)(arg1 + 0x54);
                            *(float *)(iVar12 + 0x1c) =
                                 (float)(uint32_t)*(uint16_t *)(iVar2 + 2 + iVar16 * 8) * *(float *)(arg1 + 0x58);
                            *(float *)(iVar12 + 0x20) =
                                 (float)((uint32_t)*(uint16_t *)(iVar2 + 4 + iVar16 * 8) +
                                        (uint32_t)*(uint16_t *)(iVar2 + iVar16 * 8)) * *(float *)(arg1 + 0x54);
                            *(float *)(iVar12 + 0x24) =
                                 (float)((uint32_t)*(uint16_t *)(iVar2 + 6 + iVar16 * 8) +
                                        (uint32_t)*(uint16_t *)(iVar2 + 2 + iVar16 * 8)) * *(float *)(arg1 + 0x58);
                        }
                    }
                    uVar10 = uVar10 + 1;
                } while ((int32_t)uVar10 < *(int32_t *)(iVar8 + 0xc0));
            }
            fcn.180128d60(arg1);
            fcn.180128910(arg1);
            *(undefined *)(iVar8 + 0xb8) = 0;
            puVar15 = *(undefined8 **)(arg1 + 0x2a8);
            puVar3 = puVar15 + *(int32_t *)(arg1 + 0x2a0);
            for (; puVar15 != puVar3; puVar15 = puVar15 + 1) {
                puVar9 = (undefined8 *)*puVar15;
                if (puVar9[2] == arg1) {
                    *puVar9 = *(undefined8 *)(arg1 + 0x5c);
                    puVar9[1] = arg1 + 0x88;
                }
            }
code_r0x000180129cf0:
            if (stack0xffffffffffffffa0 != 0) {
                func_0x000180460d90(stack0xffffffffffffffa0);
            }
            if (iVar13 != 0) {
                func_0x000180460d90(iVar13);
            }
            return;
        }
        if ((*puVar19 >> 0x1e & 1) != 0) {
            iVar16 = (int64_t)(int32_t)(*puVar19 << 0xc) >> 0xc;
            iVar4 = *(int16_t *)(iVar13 + 4 + iVar16 * 8);
            iVar2 = iVar13 + iVar16 * 8;
            if ((iVar4 != 0) || (*(int16_t *)(iVar2 + 6) != 0)) {
                uVar10 = func_0x00018012ae60(arg1, iVar4, *(undefined2 *)(iVar2 + 6), puVar19);
                if (uVar10 == 0xffffffff) {
                    *(undefined *)(iVar12 + 0x57) = 1;
                    *(undefined4 *)(iVar8 + 0x60) = uVar6;
                    *(undefined4 *)(iVar8 + 100) = uVar7;
                    iVar12 = *(int64_t *)(iVar8 + 0x68);
                    *(int64_t *)(iVar8 + 0x68) = iVar13;
                    if (*(int64_t *)(iVar8 + 0x78) != 0) {
                        *(undefined8 *)(iVar8 + 0x70) = 0;
                        func_0x000180460d90();
                        *(undefined8 *)(iVar8 + 0x78) = 0;
                    }
                    iVar17 = *(int32_t *)(iVar8 + 0x74);
                    if (iVar17 < iVar5) {
                        if (iVar17 != 0) {
                            iVar22 = iVar17 + iVar17 / 2;
                        }
                        iVar18 = iVar5;
                        if (iVar5 < iVar22) {
                            iVar18 = iVar22;
                        }
                        if (iVar18 <= iVar17) goto code_r0x000180129df1;
                        iVar13 = func_0x00018046d050((int64_t)iVar18 << 2);
                        if (*(int64_t *)(iVar8 + 0x78) != 0) {
                            func_0x000180498030(iVar13, *(int64_t *)(iVar8 + 0x78), 
                                                (int64_t)*(int32_t *)(iVar8 + 0x70) << 2);
                            func_0x000180460d90(*(undefined8 *)(iVar8 + 0x78));
                        }
                        *(int64_t *)(iVar8 + 0x78) = iVar13;
                        *(int32_t *)(iVar8 + 0x74) = iVar18;
                        *(int32_t *)(iVar8 + 0x70) = iVar5;
                        if ((iVar13 != 0) && (stack0xffffffffffffffa0 != 0)) {
                            func_0x000180498030(iVar13, stack0xffffffffffffffa0, (int64_t)iVar5 << 2);
                        }
                    } else {
code_r0x000180129df1:
                        *(int32_t *)(iVar8 + 0x70) = iVar5;
                    }
                    fcn.1801296d0(arg1, iVar20, CONCAT44((int32_t)var_64h, iVar5));
                    func_0x000180129e30(arg1, (int32_t)arg2, (int32_t)arg3);
                    iVar13 = iVar12;
                    goto code_r0x000180129cf0;
                }
                iVar14 = (int64_t)(*(int32_t *)
                                    (*(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x78) + (uint64_t)(uVar10 & 0x7ffff) * 4)
                                  << 0xc) >> 0xc;
                iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x2b0) + 0x68);
                func_0x000180127470(iVar20, *(undefined2 *)(iVar13 + iVar16 * 8), 
                                    *(undefined2 *)(iVar13 + 2 + iVar16 * 8), iVar12, 
                                    *(undefined2 *)(iVar2 + iVar14 * 8), *(undefined2 *)(iVar2 + 2 + iVar14 * 8), 
                                    *(undefined2 *)(iVar2 + 4 + iVar14 * 8), *(undefined2 *)(iVar2 + 6 + iVar14 * 8));
            }
        }
        puVar19 = puVar19 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180129e30
// Address: 0x180129e30
// Size: 264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.180129e30(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t arg2_00;
    uint32_t uVar4;
    uint32_t uVar5;
    uint64_t arg3_00;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = (uint32_t)arg3;
    uVar3 = (uint32_t)arg2;
    if (uVar3 == 0xffffffff) {
        uVar3 = *(uint32_t *)(*(int64_t *)(arg1 + 0x38) + 0x1c);
    }
    if (uVar5 == 0xffffffff) {
        uVar5 = *(uint32_t *)(*(int64_t *)(arg1 + 0x38) + 0x20);
    }
    if ((int32_t)uVar3 < (int32_t)uVar5) {
        uVar2 = uVar3 * 2;
        uVar4 = uVar5;
    } else {
        uVar4 = uVar5 * 2;
        uVar2 = uVar3;
    }
    uVar1 = *(int32_t *)(arg1 + 8) + -1 + *(int32_t *)(*(int64_t *)(arg1 + 0x2b0) + 0xa8);
    uVar1 = (int32_t)uVar1 >> 1 | uVar1;
    uVar1 = (int32_t)uVar1 >> 2 | uVar1;
    uVar1 = (int32_t)uVar1 >> 4 | uVar1;
    uVar1 = (int32_t)uVar1 >> 8 | uVar1;
    arg2_00 = (uint64_t)*(uint32_t *)(arg1 + 0xc);
    uVar1 = ((int32_t)uVar1 >> 0x10 | uVar1) + 1;
    if ((int32_t)uVar1 <= (int32_t)uVar2) {
        uVar1 = uVar2;
    }
    uVar2 = *(int32_t *)(arg1 + 8) + -1 + *(int32_t *)(*(int64_t *)(arg1 + 0x2b0) + 0xac);
    uVar2 = (int32_t)uVar2 >> 1 | uVar2;
    uVar2 = (int32_t)uVar2 >> 2 | uVar2;
    uVar2 = (int32_t)uVar2 >> 4 | uVar2;
    uVar2 = (int32_t)uVar2 >> 8 | uVar2;
    uVar2 = (uVar2 | (int32_t)uVar2 >> 0x10) + 1;
    if ((int32_t)uVar2 <= (int32_t)uVar4) {
        uVar2 = uVar4;
    }
    if ((int32_t)*(uint32_t *)(arg1 + 0xc) <= (int32_t)uVar1) {
        arg2_00 = (uint64_t)uVar1;
        if (*(int32_t *)(arg1 + 0x14) < (int32_t)uVar1) {
            arg2_00 = (uint64_t)*(uint32_t *)(arg1 + 0x14);
        }
    }
    arg3_00 = (uint64_t)*(uint32_t *)(arg1 + 0x10);
    if ((int32_t)*(uint32_t *)(arg1 + 0x10) <= (int32_t)uVar2) {
        arg3_00 = (uint64_t)uVar2;
        if (*(int32_t *)(arg1 + 0x18) < (int32_t)uVar2) {
            arg3_00 = (uint64_t)*(uint32_t *)(arg1 + 0x18);
        }
    }
    if (((uint32_t)arg2_00 != uVar3) || ((uint32_t)arg3_00 != uVar5)) {
        fcn.1801299b0(arg1, arg2_00, arg3_00);
    }
    return;
}

// ============================================================
// Function: FUN_180129f40
// Address: 0x180129f40
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180129f40(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar2 = *(int32_t *)(arg2 + 0xc) - 1;
    iVar1 = *(int64_t *)(arg2 + 0x2b0);
    uVar2 = (int32_t)uVar2 >> 1 | uVar2;
    uVar2 = (int32_t)uVar2 >> 2 | uVar2;
    uVar2 = (int32_t)uVar2 >> 4 | uVar2;
    uVar2 = (int32_t)uVar2 >> 8 | uVar2;
    uVar2 = (int32_t)uVar2 >> 0x10 | uVar2;
    uVar3 = *(int32_t *)(arg2 + 0x10) - 1;
    uVar3 = (int32_t)uVar3 >> 1 | uVar3;
    iVar6 = uVar2 + 1;
    uVar3 = (int32_t)uVar3 >> 2 | uVar3;
    uVar3 = (int32_t)uVar3 >> 4 | uVar3;
    uVar3 = (int32_t)uVar3 >> 8 | uVar3;
    uVar3 = (int32_t)uVar3 >> 0x10 | uVar3;
    iVar7 = uVar3 + 1;
    if (((iVar1 != 0) && (*(int64_t *)(arg2 + 0x38) != 0)) && (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 4) != 4)) {
        uVar4 = *(int32_t *)(iVar1 + 0xa8) - 1;
        uVar4 = (int32_t)uVar4 >> 1 | uVar4;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar6 <= (int32_t)(uVar4 + 1)) {
            uVar2 = uVar4;
        }
        uVar4 = *(int32_t *)(iVar1 + 0xac) - 1;
        uVar4 = (int32_t)uVar4 >> 1 | uVar4;
        iVar6 = uVar2 + 1;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar7 <= (int32_t)(uVar4 + 1)) {
            uVar3 = uVar4;
        }
        iVar9 = *(int32_t *)(iVar1 + 0x98) - *(int32_t *)(iVar1 + 0xa0);
        iVar7 = uVar3 + 1;
        fVar10 = (float)iVar9;
        if (fVar10 < 0.0) {
            fVar10 = (float)func_0x000180494560(fVar10);
        } else {
            fVar10 = SQRT(fVar10);
        }
        uVar4 = (int32_t)((int32_t)fVar10 - 1U) >> 1 | (int32_t)fVar10 - 1U;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar6 < iVar7) {
            if ((int32_t)(uVar4 + 1) <= iVar7) {
                uVar4 = uVar3;
            }
            if ((*(uint32_t *)arg2 & 1) == 0) {
                uVar4 = (int32_t)uVar4 >> 1 | uVar4;
                uVar4 = (int32_t)uVar4 >> 2 | uVar4;
                uVar4 = (int32_t)uVar4 >> 4 | uVar4;
                uVar4 = (int32_t)uVar4 >> 8 | uVar4;
                uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
            }
            iVar5 = uVar4 + 1;
            iVar8 = (iVar9 + -1 + iVar5) / iVar5;
            if (iVar8 <= iVar6) {
                iVar8 = iVar6;
            }
        } else {
            if ((int32_t)(uVar4 + 1) <= iVar6) {
                uVar4 = uVar2;
            }
            iVar8 = uVar4 + 1;
            iVar5 = (iVar9 + -1 + iVar8) / iVar8;
            if (iVar5 <= iVar7) {
                iVar5 = iVar7;
            }
            if ((*(uint32_t *)arg2 & 1) == 0) {
                uVar2 = (int32_t)(iVar5 - 1U) >> 1 | iVar5 - 1U;
                uVar2 = (int32_t)uVar2 >> 2 | uVar2;
                uVar2 = (int32_t)uVar2 >> 4 | uVar2;
                uVar2 = (int32_t)uVar2 >> 8 | uVar2;
                iVar5 = ((int32_t)uVar2 >> 0x10 | uVar2) + 1;
            }
        }
        *(int32_t *)arg1 = iVar8;
        *(int32_t *)(arg1 + 4) = iVar5;
        return arg1;
    }
    *(int32_t *)arg1 = iVar6;
    *(int32_t *)(arg1 + 4) = iVar7;
    return arg1;
}

// ============================================================
// Function: FUN_180129fe6
// Address: 0x180129fe6
// Size: 395 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180129f40(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar2 = *(int32_t *)(arg2 + 0xc) - 1;
    iVar1 = *(int64_t *)(arg2 + 0x2b0);
    uVar2 = (int32_t)uVar2 >> 1 | uVar2;
    uVar2 = (int32_t)uVar2 >> 2 | uVar2;
    uVar2 = (int32_t)uVar2 >> 4 | uVar2;
    uVar2 = (int32_t)uVar2 >> 8 | uVar2;
    uVar2 = (int32_t)uVar2 >> 0x10 | uVar2;
    uVar3 = *(int32_t *)(arg2 + 0x10) - 1;
    uVar3 = (int32_t)uVar3 >> 1 | uVar3;
    iVar6 = uVar2 + 1;
    uVar3 = (int32_t)uVar3 >> 2 | uVar3;
    uVar3 = (int32_t)uVar3 >> 4 | uVar3;
    uVar3 = (int32_t)uVar3 >> 8 | uVar3;
    uVar3 = (int32_t)uVar3 >> 0x10 | uVar3;
    iVar7 = uVar3 + 1;
    if (((iVar1 != 0) && (*(int64_t *)(arg2 + 0x38) != 0)) && (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 4) != 4)) {
        uVar4 = *(int32_t *)(iVar1 + 0xa8) - 1;
        uVar4 = (int32_t)uVar4 >> 1 | uVar4;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar6 <= (int32_t)(uVar4 + 1)) {
            uVar2 = uVar4;
        }
        uVar4 = *(int32_t *)(iVar1 + 0xac) - 1;
        uVar4 = (int32_t)uVar4 >> 1 | uVar4;
        iVar6 = uVar2 + 1;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar7 <= (int32_t)(uVar4 + 1)) {
            uVar3 = uVar4;
        }
        iVar9 = *(int32_t *)(iVar1 + 0x98) - *(int32_t *)(iVar1 + 0xa0);
        iVar7 = uVar3 + 1;
        fVar10 = (float)iVar9;
        if (fVar10 < 0.0) {
            fVar10 = (float)func_0x000180494560(fVar10);
        } else {
            fVar10 = SQRT(fVar10);
        }
        uVar4 = (int32_t)((int32_t)fVar10 - 1U) >> 1 | (int32_t)fVar10 - 1U;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar6 < iVar7) {
            if ((int32_t)(uVar4 + 1) <= iVar7) {
                uVar4 = uVar3;
            }
            if ((*(uint32_t *)arg2 & 1) == 0) {
                uVar4 = (int32_t)uVar4 >> 1 | uVar4;
                uVar4 = (int32_t)uVar4 >> 2 | uVar4;
                uVar4 = (int32_t)uVar4 >> 4 | uVar4;
                uVar4 = (int32_t)uVar4 >> 8 | uVar4;
                uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
            }
            iVar5 = uVar4 + 1;
            iVar8 = (iVar9 + -1 + iVar5) / iVar5;
            if (iVar8 <= iVar6) {
                iVar8 = iVar6;
            }
        } else {
            if ((int32_t)(uVar4 + 1) <= iVar6) {
                uVar4 = uVar2;
            }
            iVar8 = uVar4 + 1;
            iVar5 = (iVar9 + -1 + iVar8) / iVar8;
            if (iVar5 <= iVar7) {
                iVar5 = iVar7;
            }
            if ((*(uint32_t *)arg2 & 1) == 0) {
                uVar2 = (int32_t)(iVar5 - 1U) >> 1 | iVar5 - 1U;
                uVar2 = (int32_t)uVar2 >> 2 | uVar2;
                uVar2 = (int32_t)uVar2 >> 4 | uVar2;
                uVar2 = (int32_t)uVar2 >> 8 | uVar2;
                iVar5 = ((int32_t)uVar2 >> 0x10 | uVar2) + 1;
            }
        }
        *(int32_t *)arg1 = iVar8;
        *(int32_t *)(arg1 + 4) = iVar5;
        return arg1;
    }
    *(int32_t *)arg1 = iVar6;
    *(int32_t *)(arg1 + 4) = iVar7;
    return arg1;
}

// ============================================================
// Function: FUN_18012a171
// Address: 0x18012a171
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180129f40(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar2 = *(int32_t *)(arg2 + 0xc) - 1;
    iVar1 = *(int64_t *)(arg2 + 0x2b0);
    uVar2 = (int32_t)uVar2 >> 1 | uVar2;
    uVar2 = (int32_t)uVar2 >> 2 | uVar2;
    uVar2 = (int32_t)uVar2 >> 4 | uVar2;
    uVar2 = (int32_t)uVar2 >> 8 | uVar2;
    uVar2 = (int32_t)uVar2 >> 0x10 | uVar2;
    uVar3 = *(int32_t *)(arg2 + 0x10) - 1;
    uVar3 = (int32_t)uVar3 >> 1 | uVar3;
    iVar6 = uVar2 + 1;
    uVar3 = (int32_t)uVar3 >> 2 | uVar3;
    uVar3 = (int32_t)uVar3 >> 4 | uVar3;
    uVar3 = (int32_t)uVar3 >> 8 | uVar3;
    uVar3 = (int32_t)uVar3 >> 0x10 | uVar3;
    iVar7 = uVar3 + 1;
    if (((iVar1 != 0) && (*(int64_t *)(arg2 + 0x38) != 0)) && (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 4) != 4)) {
        uVar4 = *(int32_t *)(iVar1 + 0xa8) - 1;
        uVar4 = (int32_t)uVar4 >> 1 | uVar4;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar6 <= (int32_t)(uVar4 + 1)) {
            uVar2 = uVar4;
        }
        uVar4 = *(int32_t *)(iVar1 + 0xac) - 1;
        uVar4 = (int32_t)uVar4 >> 1 | uVar4;
        iVar6 = uVar2 + 1;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar7 <= (int32_t)(uVar4 + 1)) {
            uVar3 = uVar4;
        }
        iVar9 = *(int32_t *)(iVar1 + 0x98) - *(int32_t *)(iVar1 + 0xa0);
        iVar7 = uVar3 + 1;
        fVar10 = (float)iVar9;
        if (fVar10 < 0.0) {
            fVar10 = (float)func_0x000180494560(fVar10);
        } else {
            fVar10 = SQRT(fVar10);
        }
        uVar4 = (int32_t)((int32_t)fVar10 - 1U) >> 1 | (int32_t)fVar10 - 1U;
        uVar4 = (int32_t)uVar4 >> 2 | uVar4;
        uVar4 = (int32_t)uVar4 >> 4 | uVar4;
        uVar4 = (int32_t)uVar4 >> 8 | uVar4;
        uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
        if (iVar6 < iVar7) {
            if ((int32_t)(uVar4 + 1) <= iVar7) {
                uVar4 = uVar3;
            }
            if ((*(uint32_t *)arg2 & 1) == 0) {
                uVar4 = (int32_t)uVar4 >> 1 | uVar4;
                uVar4 = (int32_t)uVar4 >> 2 | uVar4;
                uVar4 = (int32_t)uVar4 >> 4 | uVar4;
                uVar4 = (int32_t)uVar4 >> 8 | uVar4;
                uVar4 = (int32_t)uVar4 >> 0x10 | uVar4;
            }
            iVar5 = uVar4 + 1;
            iVar8 = (iVar9 + -1 + iVar5) / iVar5;
            if (iVar8 <= iVar6) {
                iVar8 = iVar6;
            }
        } else {
            if ((int32_t)(uVar4 + 1) <= iVar6) {
                uVar4 = uVar2;
            }
            iVar8 = uVar4 + 1;
            iVar5 = (iVar9 + -1 + iVar8) / iVar8;
            if (iVar5 <= iVar7) {
                iVar5 = iVar7;
            }
            if ((*(uint32_t *)arg2 & 1) == 0) {
                uVar2 = (int32_t)(iVar5 - 1U) >> 1 | iVar5 - 1U;
                uVar2 = (int32_t)uVar2 >> 2 | uVar2;
                uVar2 = (int32_t)uVar2 >> 4 | uVar2;
                uVar2 = (int32_t)uVar2 >> 8 | uVar2;
                iVar5 = ((int32_t)uVar2 >> 0x10 | uVar2) + 1;
            }
        }
        *(int32_t *)arg1 = iVar8;
        *(int32_t *)(arg1 + 4) = iVar5;
        return arg1;
    }
    *(int32_t *)arg1 = iVar6;
    *(int32_t *)(arg1 + 4) = iVar7;
    return arg1;
}

// ============================================================
// Function: FUN_18012a190
// Address: 0x18012a190
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Removing arg arg_ech because it doesn't fit into ProtoModel

void fcn.18012a190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    uint32_t *puVar4;
    code *pcVar5;
    undefined8 *puVar6;
    int8_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    char *pcVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    undefined8 in_R9;
    int64_t unaff_R15;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if (*(int64_t *)(arg1 + 0x2b8) != 0) goto code_r0x00018012a3e4;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782ad0) {
        func_0x000180459d18(0x180782ad0);
        if (*(int32_t *)0x180782ad0 == -1) {
            *(undefined (*) [16])0x180782ae0 = ZEXT816(0);
            *(undefined (*) [16])0x180782af0 = ZEXT816(0);
            *(undefined (*) [16])0x180782b00 = ZEXT816(0);
            *(undefined (*) [16])0x180782b10 = ZEXT816(0);
            *(undefined (*) [16])0x180782b20 = ZEXT816(0);
            func_0x000180459cac(0x180782ad0);
        }
    }
    *(undefined8 *)0x180782ae0 = 0x180645700;
    *(undefined8 *)0x180782af8 = 0x18012bc40;
    *(undefined8 *)0x180782b08 = 0x18012c420;
    *(undefined8 *)0x180782b00 = 0x18012c3e0;
    *(undefined (*) [16])0x180782b10 = ZEXT816(0x18012c440);
    *(undefined8 *)0x180782b20 = 0x18012c510;
    iVar11 = *(int64_t *)(arg1 + 0x2b8);
    if (iVar11 == 0x180782ae0) goto code_r0x00018012a3e4;
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    if (piVar14 != piVar1) {
        do {
            fcn.1801291c0(arg1, *piVar14);
            piVar14 = piVar14 + 1;
        } while (piVar14 != piVar1);
        iVar11 = *(int64_t *)(arg1 + 0x2b8);
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
        *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
    } else {
        if ((iVar11 == 0) || (*(code **)(iVar11 + 0x10) == (code *)0x0)) {
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
        } else {
            (**(code **)(iVar11 + 0x10))(arg1);
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
            if (*(int64_t *)(arg1 + 0x2b0) == 0) goto code_r0x00018012a306;
        }
        if (*(code **)0x180782ae8 != (code *)0x0) {
            (**(code **)0x180782ae8)(arg1);
        }
    }
code_r0x00018012a306:
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        piVar15 = *(int64_t **)(*piVar14 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(*piVar14 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar11 = *(int64_t *)(*piVar15 + 0x88);
            if (iVar11 == 0) {
                iVar11 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar11 + 0x18) != (code *)0x0) {
                (**(code **)(iVar11 + 0x18))(arg1);
            }
        }
    }
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        iVar11 = *piVar14;
        piVar15 = *(int64_t **)(iVar11 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(iVar11 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            fcn.180129250(arg1, iVar11, *piVar15, in_R9, unaff_R15);
        }
    }
code_r0x00018012a3e4:
    if ((*(int64_t *)(arg1 + 0x38) == 0) || (*(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x28) == 0)) {
        uVar8 = *(int32_t *)(arg1 + 0x10) - 1;
        uVar8 = (int32_t)uVar8 >> 1 | uVar8;
        uVar8 = (int32_t)uVar8 >> 2 | uVar8;
        uVar8 = (int32_t)uVar8 >> 4 | uVar8;
        uVar8 = (int32_t)uVar8 >> 8 | uVar8;
        uVar9 = *(int32_t *)(arg1 + 0xc) - 1;
        uVar9 = (int32_t)uVar9 >> 1 | uVar9;
        uVar9 = (int32_t)uVar9 >> 2 | uVar9;
        uVar9 = (int32_t)uVar9 >> 4 | uVar9;
        uVar9 = (int32_t)uVar9 >> 8 | uVar9;
        fcn.180129840(arg1, (uint64_t)(((int32_t)uVar9 >> 0x10 | uVar9) + 1), 
                      (uint64_t)(((int32_t)uVar8 >> 0x10 | uVar8) + 1));
    }
    iVar11 = func_0x00018046d050(0xf8);
    if (iVar11 == 0) {
        iVar11 = 0;
    } else {
        func_0x0001804986e0(iVar11, 0, 0xf8);
        *(undefined4 *)(iVar11 + 0xa4) = 0xffffffff;
        *(undefined4 *)(iVar11 + 0x90) = 0xffffffff;
        *(undefined8 *)(iVar11 + 0xec) = 0xffffffffffffffff;
    }
    *(int64_t *)(arg1 + 0x2b0) = iVar11;
    pcVar5 = *(code **)(*(int64_t *)(arg1 + 0x2b8) + 8);
    if (pcVar5 != (code *)0x0) {
        (*pcVar5)(arg1);
    }
    piVar14 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar14 == piVar1) {
code_r0x00018012a4f2:
            func_0x00018012aae0(arg1);
            fcn.180128d60(arg1);
            fcn.180128910(arg1);
            func_0x000180128810(arg1);
            puVar12 = *(undefined8 **)(arg1 + 0x2a8);
            puVar3 = puVar12 + *(int32_t *)(arg1 + 0x2a0);
            for (; puVar12 != puVar3; puVar12 = puVar12 + 1) {
                puVar6 = (undefined8 *)*puVar12;
                if (puVar6[2] == arg1) {
                    *puVar6 = *(undefined8 *)(arg1 + 0x5c);
                    puVar6[1] = arg1 + 0x88;
                }
            }
            if ((*(uint32_t *)0x1807823a8 & 0x3000000) == 0) {
                uVar8 = 0;
                do {
                    *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) =
                         *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) & 0xfffffffc | 2;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 1 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffff3 | 8;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 2 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffffcf | 0x20;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 3 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffff3f | 0x80;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 4 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffcff | 0x200;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 5 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffff3ff | 0x800;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 6 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffcfff | 0x2000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 7 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffff3fff | 0x8000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 8 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffcffff | 0x20000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfff3ffff | 0x80000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 10 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffcfffff | 0x200000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xb >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xff3fffff | 0x800000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xc >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfcffffff | 0x2000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xd >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xf3ffffff | 0x8000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xe >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xcfffffff | 0x20000000;
                    uVar9 = uVar8 + 0xf;
                    uVar8 = uVar8 + 0x10;
                    puVar4 = (uint32_t *)((uint64_t)(uVar9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0x3fffffff | 0x80000000;
                } while (uVar8 < 0x80);
                pcVar13 = " \t";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x18064571a);
                    pcVar13 = pcVar13 + iVar10;
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & ~(3 << ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02');
                } while (*pcVar13 != '\0');
                pcVar13 = ".,;!?\"";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x180645722);
                    pcVar13 = pcVar13 + iVar10;
                    iVar7 = ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02';
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = ~(3 << iVar7) & *puVar4 | 1 << iVar7;
                } while (*pcVar13 != '\0');
                *(uint32_t *)0x180782388 = *(uint32_t *)0x180782388 & 0xeaaaaa94 | 0x2aaaaa94;
            }
            return;
        }
        if (*(int64_t *)(*piVar14 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar14 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x00018012a4f2;
        }
        piVar14 = piVar14 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18012a1bc
// Address: 0x18012a1bc
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Removing arg arg_ech because it doesn't fit into ProtoModel

void fcn.18012a190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    uint32_t *puVar4;
    code *pcVar5;
    undefined8 *puVar6;
    int8_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    char *pcVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    undefined8 in_R9;
    int64_t unaff_R15;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if (*(int64_t *)(arg1 + 0x2b8) != 0) goto code_r0x00018012a3e4;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782ad0) {
        func_0x000180459d18(0x180782ad0);
        if (*(int32_t *)0x180782ad0 == -1) {
            *(undefined (*) [16])0x180782ae0 = ZEXT816(0);
            *(undefined (*) [16])0x180782af0 = ZEXT816(0);
            *(undefined (*) [16])0x180782b00 = ZEXT816(0);
            *(undefined (*) [16])0x180782b10 = ZEXT816(0);
            *(undefined (*) [16])0x180782b20 = ZEXT816(0);
            func_0x000180459cac(0x180782ad0);
        }
    }
    *(undefined8 *)0x180782ae0 = 0x180645700;
    *(undefined8 *)0x180782af8 = 0x18012bc40;
    *(undefined8 *)0x180782b08 = 0x18012c420;
    *(undefined8 *)0x180782b00 = 0x18012c3e0;
    *(undefined (*) [16])0x180782b10 = ZEXT816(0x18012c440);
    *(undefined8 *)0x180782b20 = 0x18012c510;
    iVar11 = *(int64_t *)(arg1 + 0x2b8);
    if (iVar11 == 0x180782ae0) goto code_r0x00018012a3e4;
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    if (piVar14 != piVar1) {
        do {
            fcn.1801291c0(arg1, *piVar14);
            piVar14 = piVar14 + 1;
        } while (piVar14 != piVar1);
        iVar11 = *(int64_t *)(arg1 + 0x2b8);
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
        *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
    } else {
        if ((iVar11 == 0) || (*(code **)(iVar11 + 0x10) == (code *)0x0)) {
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
        } else {
            (**(code **)(iVar11 + 0x10))(arg1);
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
            if (*(int64_t *)(arg1 + 0x2b0) == 0) goto code_r0x00018012a306;
        }
        if (*(code **)0x180782ae8 != (code *)0x0) {
            (**(code **)0x180782ae8)(arg1);
        }
    }
code_r0x00018012a306:
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        piVar15 = *(int64_t **)(*piVar14 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(*piVar14 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar11 = *(int64_t *)(*piVar15 + 0x88);
            if (iVar11 == 0) {
                iVar11 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar11 + 0x18) != (code *)0x0) {
                (**(code **)(iVar11 + 0x18))(arg1);
            }
        }
    }
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        iVar11 = *piVar14;
        piVar15 = *(int64_t **)(iVar11 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(iVar11 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            fcn.180129250(arg1, iVar11, *piVar15, in_R9, unaff_R15);
        }
    }
code_r0x00018012a3e4:
    if ((*(int64_t *)(arg1 + 0x38) == 0) || (*(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x28) == 0)) {
        uVar8 = *(int32_t *)(arg1 + 0x10) - 1;
        uVar8 = (int32_t)uVar8 >> 1 | uVar8;
        uVar8 = (int32_t)uVar8 >> 2 | uVar8;
        uVar8 = (int32_t)uVar8 >> 4 | uVar8;
        uVar8 = (int32_t)uVar8 >> 8 | uVar8;
        uVar9 = *(int32_t *)(arg1 + 0xc) - 1;
        uVar9 = (int32_t)uVar9 >> 1 | uVar9;
        uVar9 = (int32_t)uVar9 >> 2 | uVar9;
        uVar9 = (int32_t)uVar9 >> 4 | uVar9;
        uVar9 = (int32_t)uVar9 >> 8 | uVar9;
        fcn.180129840(arg1, (uint64_t)(((int32_t)uVar9 >> 0x10 | uVar9) + 1), 
                      (uint64_t)(((int32_t)uVar8 >> 0x10 | uVar8) + 1));
    }
    iVar11 = func_0x00018046d050(0xf8);
    if (iVar11 == 0) {
        iVar11 = 0;
    } else {
        func_0x0001804986e0(iVar11, 0, 0xf8);
        *(undefined4 *)(iVar11 + 0xa4) = 0xffffffff;
        *(undefined4 *)(iVar11 + 0x90) = 0xffffffff;
        *(undefined8 *)(iVar11 + 0xec) = 0xffffffffffffffff;
    }
    *(int64_t *)(arg1 + 0x2b0) = iVar11;
    pcVar5 = *(code **)(*(int64_t *)(arg1 + 0x2b8) + 8);
    if (pcVar5 != (code *)0x0) {
        (*pcVar5)(arg1);
    }
    piVar14 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar14 == piVar1) {
code_r0x00018012a4f2:
            func_0x00018012aae0(arg1);
            fcn.180128d60(arg1);
            fcn.180128910(arg1);
            func_0x000180128810(arg1);
            puVar12 = *(undefined8 **)(arg1 + 0x2a8);
            puVar3 = puVar12 + *(int32_t *)(arg1 + 0x2a0);
            for (; puVar12 != puVar3; puVar12 = puVar12 + 1) {
                puVar6 = (undefined8 *)*puVar12;
                if (puVar6[2] == arg1) {
                    *puVar6 = *(undefined8 *)(arg1 + 0x5c);
                    puVar6[1] = arg1 + 0x88;
                }
            }
            if ((*(uint32_t *)0x1807823a8 & 0x3000000) == 0) {
                uVar8 = 0;
                do {
                    *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) =
                         *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) & 0xfffffffc | 2;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 1 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffff3 | 8;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 2 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffffcf | 0x20;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 3 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffff3f | 0x80;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 4 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffcff | 0x200;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 5 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffff3ff | 0x800;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 6 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffcfff | 0x2000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 7 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffff3fff | 0x8000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 8 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffcffff | 0x20000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfff3ffff | 0x80000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 10 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffcfffff | 0x200000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xb >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xff3fffff | 0x800000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xc >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfcffffff | 0x2000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xd >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xf3ffffff | 0x8000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xe >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xcfffffff | 0x20000000;
                    uVar9 = uVar8 + 0xf;
                    uVar8 = uVar8 + 0x10;
                    puVar4 = (uint32_t *)((uint64_t)(uVar9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0x3fffffff | 0x80000000;
                } while (uVar8 < 0x80);
                pcVar13 = " \t";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x18064571a);
                    pcVar13 = pcVar13 + iVar10;
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & ~(3 << ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02');
                } while (*pcVar13 != '\0');
                pcVar13 = ".,;!?\"";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x180645722);
                    pcVar13 = pcVar13 + iVar10;
                    iVar7 = ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02';
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = ~(3 << iVar7) & *puVar4 | 1 << iVar7;
                } while (*pcVar13 != '\0');
                *(uint32_t *)0x180782388 = *(uint32_t *)0x180782388 & 0xeaaaaa94 | 0x2aaaaa94;
            }
            return;
        }
        if (*(int64_t *)(*piVar14 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar14 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x00018012a4f2;
        }
        piVar14 = piVar14 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18012a252
// Address: 0x18012a252
// Size: 397 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Removing arg arg_ech because it doesn't fit into ProtoModel

void fcn.18012a190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    uint32_t *puVar4;
    code *pcVar5;
    undefined8 *puVar6;
    int8_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    char *pcVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    undefined8 in_R9;
    int64_t unaff_R15;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if (*(int64_t *)(arg1 + 0x2b8) != 0) goto code_r0x00018012a3e4;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782ad0) {
        func_0x000180459d18(0x180782ad0);
        if (*(int32_t *)0x180782ad0 == -1) {
            *(undefined (*) [16])0x180782ae0 = ZEXT816(0);
            *(undefined (*) [16])0x180782af0 = ZEXT816(0);
            *(undefined (*) [16])0x180782b00 = ZEXT816(0);
            *(undefined (*) [16])0x180782b10 = ZEXT816(0);
            *(undefined (*) [16])0x180782b20 = ZEXT816(0);
            func_0x000180459cac(0x180782ad0);
        }
    }
    *(undefined8 *)0x180782ae0 = 0x180645700;
    *(undefined8 *)0x180782af8 = 0x18012bc40;
    *(undefined8 *)0x180782b08 = 0x18012c420;
    *(undefined8 *)0x180782b00 = 0x18012c3e0;
    *(undefined (*) [16])0x180782b10 = ZEXT816(0x18012c440);
    *(undefined8 *)0x180782b20 = 0x18012c510;
    iVar11 = *(int64_t *)(arg1 + 0x2b8);
    if (iVar11 == 0x180782ae0) goto code_r0x00018012a3e4;
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    if (piVar14 != piVar1) {
        do {
            fcn.1801291c0(arg1, *piVar14);
            piVar14 = piVar14 + 1;
        } while (piVar14 != piVar1);
        iVar11 = *(int64_t *)(arg1 + 0x2b8);
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
        *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
    } else {
        if ((iVar11 == 0) || (*(code **)(iVar11 + 0x10) == (code *)0x0)) {
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
        } else {
            (**(code **)(iVar11 + 0x10))(arg1);
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
            if (*(int64_t *)(arg1 + 0x2b0) == 0) goto code_r0x00018012a306;
        }
        if (*(code **)0x180782ae8 != (code *)0x0) {
            (**(code **)0x180782ae8)(arg1);
        }
    }
code_r0x00018012a306:
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        piVar15 = *(int64_t **)(*piVar14 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(*piVar14 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar11 = *(int64_t *)(*piVar15 + 0x88);
            if (iVar11 == 0) {
                iVar11 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar11 + 0x18) != (code *)0x0) {
                (**(code **)(iVar11 + 0x18))(arg1);
            }
        }
    }
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        iVar11 = *piVar14;
        piVar15 = *(int64_t **)(iVar11 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(iVar11 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            fcn.180129250(arg1, iVar11, *piVar15, in_R9, unaff_R15);
        }
    }
code_r0x00018012a3e4:
    if ((*(int64_t *)(arg1 + 0x38) == 0) || (*(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x28) == 0)) {
        uVar8 = *(int32_t *)(arg1 + 0x10) - 1;
        uVar8 = (int32_t)uVar8 >> 1 | uVar8;
        uVar8 = (int32_t)uVar8 >> 2 | uVar8;
        uVar8 = (int32_t)uVar8 >> 4 | uVar8;
        uVar8 = (int32_t)uVar8 >> 8 | uVar8;
        uVar9 = *(int32_t *)(arg1 + 0xc) - 1;
        uVar9 = (int32_t)uVar9 >> 1 | uVar9;
        uVar9 = (int32_t)uVar9 >> 2 | uVar9;
        uVar9 = (int32_t)uVar9 >> 4 | uVar9;
        uVar9 = (int32_t)uVar9 >> 8 | uVar9;
        fcn.180129840(arg1, (uint64_t)(((int32_t)uVar9 >> 0x10 | uVar9) + 1), 
                      (uint64_t)(((int32_t)uVar8 >> 0x10 | uVar8) + 1));
    }
    iVar11 = func_0x00018046d050(0xf8);
    if (iVar11 == 0) {
        iVar11 = 0;
    } else {
        func_0x0001804986e0(iVar11, 0, 0xf8);
        *(undefined4 *)(iVar11 + 0xa4) = 0xffffffff;
        *(undefined4 *)(iVar11 + 0x90) = 0xffffffff;
        *(undefined8 *)(iVar11 + 0xec) = 0xffffffffffffffff;
    }
    *(int64_t *)(arg1 + 0x2b0) = iVar11;
    pcVar5 = *(code **)(*(int64_t *)(arg1 + 0x2b8) + 8);
    if (pcVar5 != (code *)0x0) {
        (*pcVar5)(arg1);
    }
    piVar14 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar14 == piVar1) {
code_r0x00018012a4f2:
            func_0x00018012aae0(arg1);
            fcn.180128d60(arg1);
            fcn.180128910(arg1);
            func_0x000180128810(arg1);
            puVar12 = *(undefined8 **)(arg1 + 0x2a8);
            puVar3 = puVar12 + *(int32_t *)(arg1 + 0x2a0);
            for (; puVar12 != puVar3; puVar12 = puVar12 + 1) {
                puVar6 = (undefined8 *)*puVar12;
                if (puVar6[2] == arg1) {
                    *puVar6 = *(undefined8 *)(arg1 + 0x5c);
                    puVar6[1] = arg1 + 0x88;
                }
            }
            if ((*(uint32_t *)0x1807823a8 & 0x3000000) == 0) {
                uVar8 = 0;
                do {
                    *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) =
                         *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) & 0xfffffffc | 2;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 1 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffff3 | 8;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 2 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffffcf | 0x20;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 3 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffff3f | 0x80;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 4 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffcff | 0x200;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 5 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffff3ff | 0x800;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 6 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffcfff | 0x2000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 7 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffff3fff | 0x8000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 8 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffcffff | 0x20000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfff3ffff | 0x80000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 10 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffcfffff | 0x200000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xb >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xff3fffff | 0x800000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xc >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfcffffff | 0x2000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xd >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xf3ffffff | 0x8000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xe >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xcfffffff | 0x20000000;
                    uVar9 = uVar8 + 0xf;
                    uVar8 = uVar8 + 0x10;
                    puVar4 = (uint32_t *)((uint64_t)(uVar9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0x3fffffff | 0x80000000;
                } while (uVar8 < 0x80);
                pcVar13 = " \t";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x18064571a);
                    pcVar13 = pcVar13 + iVar10;
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & ~(3 << ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02');
                } while (*pcVar13 != '\0');
                pcVar13 = ".,;!?\"";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x180645722);
                    pcVar13 = pcVar13 + iVar10;
                    iVar7 = ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02';
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = ~(3 << iVar7) & *puVar4 | 1 << iVar7;
                } while (*pcVar13 != '\0');
                *(uint32_t *)0x180782388 = *(uint32_t *)0x180782388 & 0xeaaaaa94 | 0x2aaaaa94;
            }
            return;
        }
        if (*(int64_t *)(*piVar14 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar14 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x00018012a4f2;
        }
        piVar14 = piVar14 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18012a3df
// Address: 0x18012a3df
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Removing arg arg_ech because it doesn't fit into ProtoModel

void fcn.18012a190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    uint32_t *puVar4;
    code *pcVar5;
    undefined8 *puVar6;
    int8_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    char *pcVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    undefined8 in_R9;
    int64_t unaff_R15;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if (*(int64_t *)(arg1 + 0x2b8) != 0) goto code_r0x00018012a3e4;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782ad0) {
        func_0x000180459d18(0x180782ad0);
        if (*(int32_t *)0x180782ad0 == -1) {
            *(undefined (*) [16])0x180782ae0 = ZEXT816(0);
            *(undefined (*) [16])0x180782af0 = ZEXT816(0);
            *(undefined (*) [16])0x180782b00 = ZEXT816(0);
            *(undefined (*) [16])0x180782b10 = ZEXT816(0);
            *(undefined (*) [16])0x180782b20 = ZEXT816(0);
            func_0x000180459cac(0x180782ad0);
        }
    }
    *(undefined8 *)0x180782ae0 = 0x180645700;
    *(undefined8 *)0x180782af8 = 0x18012bc40;
    *(undefined8 *)0x180782b08 = 0x18012c420;
    *(undefined8 *)0x180782b00 = 0x18012c3e0;
    *(undefined (*) [16])0x180782b10 = ZEXT816(0x18012c440);
    *(undefined8 *)0x180782b20 = 0x18012c510;
    iVar11 = *(int64_t *)(arg1 + 0x2b8);
    if (iVar11 == 0x180782ae0) goto code_r0x00018012a3e4;
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    if (piVar14 != piVar1) {
        do {
            fcn.1801291c0(arg1, *piVar14);
            piVar14 = piVar14 + 1;
        } while (piVar14 != piVar1);
        iVar11 = *(int64_t *)(arg1 + 0x2b8);
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
        *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
    } else {
        if ((iVar11 == 0) || (*(code **)(iVar11 + 0x10) == (code *)0x0)) {
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
        } else {
            (**(code **)(iVar11 + 0x10))(arg1);
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
            if (*(int64_t *)(arg1 + 0x2b0) == 0) goto code_r0x00018012a306;
        }
        if (*(code **)0x180782ae8 != (code *)0x0) {
            (**(code **)0x180782ae8)(arg1);
        }
    }
code_r0x00018012a306:
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        piVar15 = *(int64_t **)(*piVar14 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(*piVar14 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar11 = *(int64_t *)(*piVar15 + 0x88);
            if (iVar11 == 0) {
                iVar11 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar11 + 0x18) != (code *)0x0) {
                (**(code **)(iVar11 + 0x18))(arg1);
            }
        }
    }
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        iVar11 = *piVar14;
        piVar15 = *(int64_t **)(iVar11 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(iVar11 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            fcn.180129250(arg1, iVar11, *piVar15, in_R9, unaff_R15);
        }
    }
code_r0x00018012a3e4:
    if ((*(int64_t *)(arg1 + 0x38) == 0) || (*(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x28) == 0)) {
        uVar8 = *(int32_t *)(arg1 + 0x10) - 1;
        uVar8 = (int32_t)uVar8 >> 1 | uVar8;
        uVar8 = (int32_t)uVar8 >> 2 | uVar8;
        uVar8 = (int32_t)uVar8 >> 4 | uVar8;
        uVar8 = (int32_t)uVar8 >> 8 | uVar8;
        uVar9 = *(int32_t *)(arg1 + 0xc) - 1;
        uVar9 = (int32_t)uVar9 >> 1 | uVar9;
        uVar9 = (int32_t)uVar9 >> 2 | uVar9;
        uVar9 = (int32_t)uVar9 >> 4 | uVar9;
        uVar9 = (int32_t)uVar9 >> 8 | uVar9;
        fcn.180129840(arg1, (uint64_t)(((int32_t)uVar9 >> 0x10 | uVar9) + 1), 
                      (uint64_t)(((int32_t)uVar8 >> 0x10 | uVar8) + 1));
    }
    iVar11 = func_0x00018046d050(0xf8);
    if (iVar11 == 0) {
        iVar11 = 0;
    } else {
        func_0x0001804986e0(iVar11, 0, 0xf8);
        *(undefined4 *)(iVar11 + 0xa4) = 0xffffffff;
        *(undefined4 *)(iVar11 + 0x90) = 0xffffffff;
        *(undefined8 *)(iVar11 + 0xec) = 0xffffffffffffffff;
    }
    *(int64_t *)(arg1 + 0x2b0) = iVar11;
    pcVar5 = *(code **)(*(int64_t *)(arg1 + 0x2b8) + 8);
    if (pcVar5 != (code *)0x0) {
        (*pcVar5)(arg1);
    }
    piVar14 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar14 == piVar1) {
code_r0x00018012a4f2:
            func_0x00018012aae0(arg1);
            fcn.180128d60(arg1);
            fcn.180128910(arg1);
            func_0x000180128810(arg1);
            puVar12 = *(undefined8 **)(arg1 + 0x2a8);
            puVar3 = puVar12 + *(int32_t *)(arg1 + 0x2a0);
            for (; puVar12 != puVar3; puVar12 = puVar12 + 1) {
                puVar6 = (undefined8 *)*puVar12;
                if (puVar6[2] == arg1) {
                    *puVar6 = *(undefined8 *)(arg1 + 0x5c);
                    puVar6[1] = arg1 + 0x88;
                }
            }
            if ((*(uint32_t *)0x1807823a8 & 0x3000000) == 0) {
                uVar8 = 0;
                do {
                    *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) =
                         *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) & 0xfffffffc | 2;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 1 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffff3 | 8;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 2 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffffcf | 0x20;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 3 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffff3f | 0x80;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 4 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffcff | 0x200;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 5 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffff3ff | 0x800;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 6 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffcfff | 0x2000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 7 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffff3fff | 0x8000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 8 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffcffff | 0x20000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfff3ffff | 0x80000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 10 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffcfffff | 0x200000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xb >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xff3fffff | 0x800000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xc >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfcffffff | 0x2000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xd >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xf3ffffff | 0x8000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xe >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xcfffffff | 0x20000000;
                    uVar9 = uVar8 + 0xf;
                    uVar8 = uVar8 + 0x10;
                    puVar4 = (uint32_t *)((uint64_t)(uVar9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0x3fffffff | 0x80000000;
                } while (uVar8 < 0x80);
                pcVar13 = " \t";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x18064571a);
                    pcVar13 = pcVar13 + iVar10;
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & ~(3 << ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02');
                } while (*pcVar13 != '\0');
                pcVar13 = ".,;!?\"";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x180645722);
                    pcVar13 = pcVar13 + iVar10;
                    iVar7 = ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02';
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = ~(3 << iVar7) & *puVar4 | 1 << iVar7;
                } while (*pcVar13 != '\0');
                *(uint32_t *)0x180782388 = *(uint32_t *)0x180782388 & 0xeaaaaa94 | 0x2aaaaa94;
            }
            return;
        }
        if (*(int64_t *)(*piVar14 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar14 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x00018012a4f2;
        }
        piVar14 = piVar14 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18012a3e4
// Address: 0x18012a3e4
// Size: 1334 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Removing arg arg_ech because it doesn't fit into ProtoModel

void fcn.18012a190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    uint32_t *puVar4;
    code *pcVar5;
    undefined8 *puVar6;
    int8_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    char *pcVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    undefined8 in_R9;
    int64_t unaff_R15;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if (*(int64_t *)(arg1 + 0x2b8) != 0) goto code_r0x00018012a3e4;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782ad0) {
        func_0x000180459d18(0x180782ad0);
        if (*(int32_t *)0x180782ad0 == -1) {
            *(undefined (*) [16])0x180782ae0 = ZEXT816(0);
            *(undefined (*) [16])0x180782af0 = ZEXT816(0);
            *(undefined (*) [16])0x180782b00 = ZEXT816(0);
            *(undefined (*) [16])0x180782b10 = ZEXT816(0);
            *(undefined (*) [16])0x180782b20 = ZEXT816(0);
            func_0x000180459cac(0x180782ad0);
        }
    }
    *(undefined8 *)0x180782ae0 = 0x180645700;
    *(undefined8 *)0x180782af8 = 0x18012bc40;
    *(undefined8 *)0x180782b08 = 0x18012c420;
    *(undefined8 *)0x180782b00 = 0x18012c3e0;
    *(undefined (*) [16])0x180782b10 = ZEXT816(0x18012c440);
    *(undefined8 *)0x180782b20 = 0x18012c510;
    iVar11 = *(int64_t *)(arg1 + 0x2b8);
    if (iVar11 == 0x180782ae0) goto code_r0x00018012a3e4;
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    if (piVar14 != piVar1) {
        do {
            fcn.1801291c0(arg1, *piVar14);
            piVar14 = piVar14 + 1;
        } while (piVar14 != piVar1);
        iVar11 = *(int64_t *)(arg1 + 0x2b8);
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
        *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
    } else {
        if ((iVar11 == 0) || (*(code **)(iVar11 + 0x10) == (code *)0x0)) {
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
        } else {
            (**(code **)(iVar11 + 0x10))(arg1);
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
            if (*(int64_t *)(arg1 + 0x2b0) == 0) goto code_r0x00018012a306;
        }
        if (*(code **)0x180782ae8 != (code *)0x0) {
            (**(code **)0x180782ae8)(arg1);
        }
    }
code_r0x00018012a306:
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        piVar15 = *(int64_t **)(*piVar14 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(*piVar14 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar11 = *(int64_t *)(*piVar15 + 0x88);
            if (iVar11 == 0) {
                iVar11 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar11 + 0x18) != (code *)0x0) {
                (**(code **)(iVar11 + 0x18))(arg1);
            }
        }
    }
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        iVar11 = *piVar14;
        piVar15 = *(int64_t **)(iVar11 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(iVar11 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            fcn.180129250(arg1, iVar11, *piVar15, in_R9, unaff_R15);
        }
    }
code_r0x00018012a3e4:
    if ((*(int64_t *)(arg1 + 0x38) == 0) || (*(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x28) == 0)) {
        uVar8 = *(int32_t *)(arg1 + 0x10) - 1;
        uVar8 = (int32_t)uVar8 >> 1 | uVar8;
        uVar8 = (int32_t)uVar8 >> 2 | uVar8;
        uVar8 = (int32_t)uVar8 >> 4 | uVar8;
        uVar8 = (int32_t)uVar8 >> 8 | uVar8;
        uVar9 = *(int32_t *)(arg1 + 0xc) - 1;
        uVar9 = (int32_t)uVar9 >> 1 | uVar9;
        uVar9 = (int32_t)uVar9 >> 2 | uVar9;
        uVar9 = (int32_t)uVar9 >> 4 | uVar9;
        uVar9 = (int32_t)uVar9 >> 8 | uVar9;
        fcn.180129840(arg1, (uint64_t)(((int32_t)uVar9 >> 0x10 | uVar9) + 1), 
                      (uint64_t)(((int32_t)uVar8 >> 0x10 | uVar8) + 1));
    }
    iVar11 = func_0x00018046d050(0xf8);
    if (iVar11 == 0) {
        iVar11 = 0;
    } else {
        func_0x0001804986e0(iVar11, 0, 0xf8);
        *(undefined4 *)(iVar11 + 0xa4) = 0xffffffff;
        *(undefined4 *)(iVar11 + 0x90) = 0xffffffff;
        *(undefined8 *)(iVar11 + 0xec) = 0xffffffffffffffff;
    }
    *(int64_t *)(arg1 + 0x2b0) = iVar11;
    pcVar5 = *(code **)(*(int64_t *)(arg1 + 0x2b8) + 8);
    if (pcVar5 != (code *)0x0) {
        (*pcVar5)(arg1);
    }
    piVar14 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar14 == piVar1) {
code_r0x00018012a4f2:
            func_0x00018012aae0(arg1);
            fcn.180128d60(arg1);
            fcn.180128910(arg1);
            func_0x000180128810(arg1);
            puVar12 = *(undefined8 **)(arg1 + 0x2a8);
            puVar3 = puVar12 + *(int32_t *)(arg1 + 0x2a0);
            for (; puVar12 != puVar3; puVar12 = puVar12 + 1) {
                puVar6 = (undefined8 *)*puVar12;
                if (puVar6[2] == arg1) {
                    *puVar6 = *(undefined8 *)(arg1 + 0x5c);
                    puVar6[1] = arg1 + 0x88;
                }
            }
            if ((*(uint32_t *)0x1807823a8 & 0x3000000) == 0) {
                uVar8 = 0;
                do {
                    *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) =
                         *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) & 0xfffffffc | 2;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 1 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffff3 | 8;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 2 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffffcf | 0x20;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 3 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffff3f | 0x80;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 4 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffcff | 0x200;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 5 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffff3ff | 0x800;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 6 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffcfff | 0x2000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 7 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffff3fff | 0x8000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 8 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffcffff | 0x20000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfff3ffff | 0x80000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 10 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffcfffff | 0x200000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xb >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xff3fffff | 0x800000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xc >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfcffffff | 0x2000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xd >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xf3ffffff | 0x8000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xe >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xcfffffff | 0x20000000;
                    uVar9 = uVar8 + 0xf;
                    uVar8 = uVar8 + 0x10;
                    puVar4 = (uint32_t *)((uint64_t)(uVar9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0x3fffffff | 0x80000000;
                } while (uVar8 < 0x80);
                pcVar13 = " \t";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x18064571a);
                    pcVar13 = pcVar13 + iVar10;
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & ~(3 << ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02');
                } while (*pcVar13 != '\0');
                pcVar13 = ".,;!?\"";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x180645722);
                    pcVar13 = pcVar13 + iVar10;
                    iVar7 = ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02';
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = ~(3 << iVar7) & *puVar4 | 1 << iVar7;
                } while (*pcVar13 != '\0');
                *(uint32_t *)0x180782388 = *(uint32_t *)0x180782388 & 0xeaaaaa94 | 0x2aaaaa94;
            }
            return;
        }
        if (*(int64_t *)(*piVar14 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar14 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x00018012a4f2;
        }
        piVar14 = piVar14 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18012a91a
// Address: 0x18012a91a
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Removing arg arg_3ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Removing arg arg_ech because it doesn't fit into ProtoModel

void fcn.18012a190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    uint32_t *puVar4;
    code *pcVar5;
    undefined8 *puVar6;
    int8_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    char *pcVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    undefined8 in_R9;
    int64_t unaff_R15;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if (*(int64_t *)(arg1 + 0x2b8) != 0) goto code_r0x00018012a3e4;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782ad0) {
        func_0x000180459d18(0x180782ad0);
        if (*(int32_t *)0x180782ad0 == -1) {
            *(undefined (*) [16])0x180782ae0 = ZEXT816(0);
            *(undefined (*) [16])0x180782af0 = ZEXT816(0);
            *(undefined (*) [16])0x180782b00 = ZEXT816(0);
            *(undefined (*) [16])0x180782b10 = ZEXT816(0);
            *(undefined (*) [16])0x180782b20 = ZEXT816(0);
            func_0x000180459cac(0x180782ad0);
        }
    }
    *(undefined8 *)0x180782ae0 = 0x180645700;
    *(undefined8 *)0x180782af8 = 0x18012bc40;
    *(undefined8 *)0x180782b08 = 0x18012c420;
    *(undefined8 *)0x180782b00 = 0x18012c3e0;
    *(undefined (*) [16])0x180782b10 = ZEXT816(0x18012c440);
    *(undefined8 *)0x180782b20 = 0x18012c510;
    iVar11 = *(int64_t *)(arg1 + 0x2b8);
    if (iVar11 == 0x180782ae0) goto code_r0x00018012a3e4;
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    if (piVar14 != piVar1) {
        do {
            fcn.1801291c0(arg1, *piVar14);
            piVar14 = piVar14 + 1;
        } while (piVar14 != piVar1);
        iVar11 = *(int64_t *)(arg1 + 0x2b8);
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
        *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
    } else {
        if ((iVar11 == 0) || (*(code **)(iVar11 + 0x10) == (code *)0x0)) {
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
        } else {
            (**(code **)(iVar11 + 0x10))(arg1);
            *(undefined8 *)(arg1 + 0x2b8) = 0x180782ae0;
            *(undefined8 *)(arg1 + 0x2c0) = *(undefined8 *)0x180782ae0;
            if (*(int64_t *)(arg1 + 0x2b0) == 0) goto code_r0x00018012a306;
        }
        if (*(code **)0x180782ae8 != (code *)0x0) {
            (**(code **)0x180782ae8)(arg1);
        }
    }
code_r0x00018012a306:
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        piVar15 = *(int64_t **)(*piVar14 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(*piVar14 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar11 = *(int64_t *)(*piVar15 + 0x88);
            if (iVar11 == 0) {
                iVar11 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar11 + 0x18) != (code *)0x0) {
                (**(code **)(iVar11 + 0x18))(arg1);
            }
        }
    }
    piVar14 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x68);
    for (; piVar14 != piVar1; piVar14 = piVar14 + 1) {
        iVar11 = *piVar14;
        piVar15 = *(int64_t **)(iVar11 + 0x28);
        piVar2 = piVar15 + *(int32_t *)(iVar11 + 0x20);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            fcn.180129250(arg1, iVar11, *piVar15, in_R9, unaff_R15);
        }
    }
code_r0x00018012a3e4:
    if ((*(int64_t *)(arg1 + 0x38) == 0) || (*(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x28) == 0)) {
        uVar8 = *(int32_t *)(arg1 + 0x10) - 1;
        uVar8 = (int32_t)uVar8 >> 1 | uVar8;
        uVar8 = (int32_t)uVar8 >> 2 | uVar8;
        uVar8 = (int32_t)uVar8 >> 4 | uVar8;
        uVar8 = (int32_t)uVar8 >> 8 | uVar8;
        uVar9 = *(int32_t *)(arg1 + 0xc) - 1;
        uVar9 = (int32_t)uVar9 >> 1 | uVar9;
        uVar9 = (int32_t)uVar9 >> 2 | uVar9;
        uVar9 = (int32_t)uVar9 >> 4 | uVar9;
        uVar9 = (int32_t)uVar9 >> 8 | uVar9;
        fcn.180129840(arg1, (uint64_t)(((int32_t)uVar9 >> 0x10 | uVar9) + 1), 
                      (uint64_t)(((int32_t)uVar8 >> 0x10 | uVar8) + 1));
    }
    iVar11 = func_0x00018046d050(0xf8);
    if (iVar11 == 0) {
        iVar11 = 0;
    } else {
        func_0x0001804986e0(iVar11, 0, 0xf8);
        *(undefined4 *)(iVar11 + 0xa4) = 0xffffffff;
        *(undefined4 *)(iVar11 + 0x90) = 0xffffffff;
        *(undefined8 *)(iVar11 + 0xec) = 0xffffffffffffffff;
    }
    *(int64_t *)(arg1 + 0x2b0) = iVar11;
    pcVar5 = *(code **)(*(int64_t *)(arg1 + 0x2b8) + 8);
    if (pcVar5 != (code *)0x0) {
        (*pcVar5)(arg1);
    }
    piVar14 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar14 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar14 == piVar1) {
code_r0x00018012a4f2:
            func_0x00018012aae0(arg1);
            fcn.180128d60(arg1);
            fcn.180128910(arg1);
            func_0x000180128810(arg1);
            puVar12 = *(undefined8 **)(arg1 + 0x2a8);
            puVar3 = puVar12 + *(int32_t *)(arg1 + 0x2a0);
            for (; puVar12 != puVar3; puVar12 = puVar12 + 1) {
                puVar6 = (undefined8 *)*puVar12;
                if (puVar6[2] == arg1) {
                    *puVar6 = *(undefined8 *)(arg1 + 0x5c);
                    puVar6[1] = arg1 + 0x88;
                }
            }
            if ((*(uint32_t *)0x1807823a8 & 0x3000000) == 0) {
                uVar8 = 0;
                do {
                    *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) =
                         *(uint32_t *)((uint64_t)(uVar8 >> 4) * 4 + 0x1807823a0) & 0xfffffffc | 2;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 1 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffff3 | 8;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 2 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffffcf | 0x20;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 3 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffff3f | 0x80;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 4 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffffcff | 0x200;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 5 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffff3ff | 0x800;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 6 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffffcfff | 0x2000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 7 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffff3fff | 0x8000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 8 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfffcffff | 0x20000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfff3ffff | 0x80000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 10 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xffcfffff | 0x200000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xb >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xff3fffff | 0x800000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xc >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xfcffffff | 0x2000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xd >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xf3ffffff | 0x8000000;
                    puVar4 = (uint32_t *)((uint64_t)(uVar8 + 0xe >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0xcfffffff | 0x20000000;
                    uVar9 = uVar8 + 0xf;
                    uVar8 = uVar8 + 0x10;
                    puVar4 = (uint32_t *)((uint64_t)(uVar9 >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & 0x3fffffff | 0x80000000;
                } while (uVar8 < 0x80);
                pcVar13 = " \t";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x18064571a);
                    pcVar13 = pcVar13 + iVar10;
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = *puVar4 & ~(3 << ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02');
                } while (*pcVar13 != '\0');
                pcVar13 = ".,;!?\"";
                do {
                    iVar10 = func_0x0001800f5c80(&var_8h, pcVar13, 0x180645722);
                    pcVar13 = pcVar13 + iVar10;
                    iVar7 = ((uint8_t)(uint32_t)var_8h & 0xf) * '\x02';
                    puVar4 = (uint32_t *)((uint64_t)((uint32_t)var_8h >> 4) * 4 + 0x1807823a0);
                    *puVar4 = ~(3 << iVar7) & *puVar4 | 1 << iVar7;
                } while (*pcVar13 != '\0');
                *(uint32_t *)0x180782388 = *(uint32_t *)0x180782388 & 0xeaaaaa94 | 0x2aaaaa94;
            }
            return;
        }
        if (*(int64_t *)(*piVar14 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar14 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x00018012a4f2;
        }
        piVar14 = piVar14 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18012a970
// Address: 0x18012a970
// Size: 366 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel

void fcn.18012a970(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t *piVar2;
    undefined8 *arg2;
    code *pcVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t unaff_R14;
    undefined8 *puVar6;
    
    puVar6 = *(undefined8 **)(arg1 + 0x70);
    puVar1 = puVar6 + *(int32_t *)(arg1 + 0x68);
    for (; puVar6 != puVar1; puVar6 = puVar6 + 1) {
        arg2 = (undefined8 *)*puVar6;
        if (arg2[1] != 0) {
            fcn.180129580(arg2[1], (int64_t)arg2, unaff_R14);
        }
        *(undefined *)((int64_t)arg2 + 0x34) = 0;
        *arg2 = 0;
        piVar5 = (int64_t *)arg2[5];
        piVar2 = piVar5 + *(int32_t *)(arg2 + 4);
        for (; piVar5 != piVar2; piVar5 = piVar5 + 1) {
            iVar4 = *(int64_t *)(*piVar5 + 0x88);
            if (((iVar4 != 0) || (iVar4 = *(int64_t *)(arg1 + 0x2b8), iVar4 != 0)) &&
               (*(code **)(iVar4 + 0x20) != (code *)0x0)) {
                (**(code **)(iVar4 + 0x20))(arg1);
            }
        }
    }
    if (((*(int64_t *)(arg1 + 0x2b0) != 0) && (*(int64_t *)(arg1 + 0x2b8) != 0)) &&
       (pcVar3 = *(code **)(*(int64_t *)(arg1 + 0x2b8) + 0x10), pcVar3 != (code *)0x0)) {
        (*pcVar3)(arg1);
    }
    iVar4 = *(int64_t *)(arg1 + 0x2b0);
    if (iVar4 != 0) {
        if (*(int64_t *)(iVar4 + 0xe0) != 0) {
            func_0x000180460d90();
        }
        puVar6 = *(undefined8 **)(iVar4 + 0xd0);
        puVar1 = puVar6 + *(int32_t *)(iVar4 + 200);
        for (; puVar6 != puVar1; puVar6 = puVar6 + 1) {
            func_0x000180460d90(*puVar6);
        }
        if (*(int64_t *)(iVar4 + 0xd0) != 0) {
            func_0x000180460d90();
        }
        if (*(int64_t *)(iVar4 + 0x88) != 0) {
            func_0x000180460d90();
        }
        if (*(int64_t *)(iVar4 + 0x78) != 0) {
            func_0x000180460d90();
        }
        if (*(int64_t *)(iVar4 + 0x68) != 0) {
            func_0x000180460d90();
        }
        if (*(int64_t *)(iVar4 + 0x58) != 0) {
            func_0x000180460d90();
        }
        func_0x000180460d90(iVar4);
    }
    *(undefined8 *)(arg1 + 0x2b0) = 0;
    return;
}

// ============================================================
// Function: FUN_18012aae0
// Address: 0x18012aae0
// Size: 193 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.18012aae0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int32_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint64_t uVar19;
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int64_t var_1ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)(arg1 + 0x38);
    piVar3 = *(int32_t **)(arg1 + 0x2b0);
    iVar2 = piVar3[0x15];
    iVar5 = *(int32_t *)(iVar9 + 0x1c) / 2;
    if (iVar2 < iVar5) {
        if (iVar2 == 0) {
            iVar6 = 8;
        } else {
            iVar6 = iVar2 / 2 + iVar2;
        }
        iVar11 = iVar5;
        if (iVar5 < iVar6) {
            iVar11 = iVar6;
        }
        if (iVar2 < iVar11) {
            uVar8 = func_0x00018046d050((int64_t)iVar11 << 4);
            if (*(int64_t *)(piVar3 + 0x16) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(piVar3 + 0x16), (int64_t)piVar3[0x14] << 4);
                func_0x000180460d90(*(undefined8 *)(piVar3 + 0x16));
            }
            *(undefined8 *)(piVar3 + 0x16) = uVar8;
            piVar3[0x15] = iVar11;
        }
    }
    piVar3[0x14] = iVar5;
    uVar1 = iVar5 - 1;
    iVar4 = *(int64_t *)(piVar3 + 0x16);
    iVar2 = *(int32_t *)(iVar9 + 0x20);
    iVar6 = *(int32_t *)(iVar9 + 0x1c);
    iVar11 = 0;
    if (0 < (int32_t)uVar1) {
        iVar10 = 0;
        if ((7 < uVar1) && (iVar10 = 0, 1 < *(int32_t *)0x1806a3990)) {
            uVar7 = uVar1 & 0x80000007;
            if ((int32_t)uVar7 < 0) {
                uVar7 = (uVar7 - 1 | 0xfffffff8) + 1;
            }
            iVar10 = 0;
            do {
                iVar9 = (int64_t)iVar10;
                auVar15._0_4_ = iVar10 + 1;
                auVar15._4_4_ = iVar10 + 2;
                auVar15._8_4_ = iVar10;
                auVar15._12_4_ = iVar10;
                auVar15 = pmovsxdq(in_XMM2, auVar15);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 8 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar16._8_8_ = 0;
                auVar16._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x18 + iVar9 * 0x10) = uVar19;
                auVar12._0_4_ = iVar10 + 3;
                auVar12._4_4_ = iVar10 + 4;
                auVar12._8_4_ = iVar10 + 2;
                auVar12._12_4_ = iVar10 + 2;
                auVar15 = pmovsxdq(auVar16, auVar12);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x28 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar17._8_8_ = 0;
                auVar17._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x38 + iVar9 * 0x10) = uVar19;
                auVar13._0_4_ = iVar10 + 5;
                auVar13._4_4_ = iVar10 + 6;
                auVar13._8_4_ = iVar10 + 4;
                auVar13._12_4_ = iVar10 + 4;
                auVar15 = pmovsxdq(auVar17, auVar13);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x48 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar18._8_8_ = 0;
                auVar18._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x58 + iVar9 * 0x10) = uVar19;
                iVar11 = iVar10 + 8;
                auVar14._0_4_ = iVar10 + 7;
                auVar14._4_4_ = iVar10 + 8;
                auVar14._8_4_ = iVar10 + 6;
                auVar14._12_4_ = iVar10 + 6;
                auVar15 = pmovsxdq(auVar18, auVar14);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x68 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                in_XMM2._8_8_ = 0;
                in_XMM2._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x78 + iVar9 * 0x10) = uVar19;
                iVar10 = iVar11;
            } while (iVar11 < (int32_t)(uVar1 - uVar7));
            if ((int32_t)uVar1 <= iVar11) goto code_r0x00018012ad21;
        }
        do {
            iVar11 = iVar10 + 1;
            *(int64_t *)(iVar4 + 8 + (int64_t)iVar10 * 0x10) = (int64_t)iVar11 * 0x10 + iVar4;
            iVar10 = iVar11;
        } while (iVar11 < (int32_t)uVar1);
    }
code_r0x00018012ad21:
    *(undefined8 *)(iVar4 + 8 + (int64_t)iVar11 * 0x10) = 0;
    *(undefined8 *)(piVar3 + 3) = 1;
    *(int64_t *)(piVar3 + 8) = iVar4;
    *(int32_t **)(piVar3 + 6) = piVar3 + 10;
    *piVar3 = iVar6;
    piVar3[1] = iVar2;
    piVar3[5] = iVar5;
    piVar3[2] = (iVar6 + -1 + iVar5) / iVar5;
    *(int32_t **)(piVar3 + 0xc) = piVar3 + 0xe;
    piVar3[0xe] = iVar6;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    piVar3[0xf] = 0x40000000;
    *(undefined8 *)(piVar3 + 0x10) = 0;
    *(undefined8 *)(piVar3 + 0x25) = 0;
    *(undefined8 *)(piVar3 + 0x2a) = 0;
    *(undefined8 *)(piVar3 + 0x2c) = 0;
    return;
}

// ============================================================
// Function: FUN_18012aba1
// Address: 0x18012aba1
// Size: 351 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.18012aae0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int32_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint64_t uVar19;
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int64_t var_1ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)(arg1 + 0x38);
    piVar3 = *(int32_t **)(arg1 + 0x2b0);
    iVar2 = piVar3[0x15];
    iVar5 = *(int32_t *)(iVar9 + 0x1c) / 2;
    if (iVar2 < iVar5) {
        if (iVar2 == 0) {
            iVar6 = 8;
        } else {
            iVar6 = iVar2 / 2 + iVar2;
        }
        iVar11 = iVar5;
        if (iVar5 < iVar6) {
            iVar11 = iVar6;
        }
        if (iVar2 < iVar11) {
            uVar8 = func_0x00018046d050((int64_t)iVar11 << 4);
            if (*(int64_t *)(piVar3 + 0x16) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(piVar3 + 0x16), (int64_t)piVar3[0x14] << 4);
                func_0x000180460d90(*(undefined8 *)(piVar3 + 0x16));
            }
            *(undefined8 *)(piVar3 + 0x16) = uVar8;
            piVar3[0x15] = iVar11;
        }
    }
    piVar3[0x14] = iVar5;
    uVar1 = iVar5 - 1;
    iVar4 = *(int64_t *)(piVar3 + 0x16);
    iVar2 = *(int32_t *)(iVar9 + 0x20);
    iVar6 = *(int32_t *)(iVar9 + 0x1c);
    iVar11 = 0;
    if (0 < (int32_t)uVar1) {
        iVar10 = 0;
        if ((7 < uVar1) && (iVar10 = 0, 1 < *(int32_t *)0x1806a3990)) {
            uVar7 = uVar1 & 0x80000007;
            if ((int32_t)uVar7 < 0) {
                uVar7 = (uVar7 - 1 | 0xfffffff8) + 1;
            }
            iVar10 = 0;
            do {
                iVar9 = (int64_t)iVar10;
                auVar15._0_4_ = iVar10 + 1;
                auVar15._4_4_ = iVar10 + 2;
                auVar15._8_4_ = iVar10;
                auVar15._12_4_ = iVar10;
                auVar15 = pmovsxdq(in_XMM2, auVar15);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 8 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar16._8_8_ = 0;
                auVar16._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x18 + iVar9 * 0x10) = uVar19;
                auVar12._0_4_ = iVar10 + 3;
                auVar12._4_4_ = iVar10 + 4;
                auVar12._8_4_ = iVar10 + 2;
                auVar12._12_4_ = iVar10 + 2;
                auVar15 = pmovsxdq(auVar16, auVar12);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x28 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar17._8_8_ = 0;
                auVar17._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x38 + iVar9 * 0x10) = uVar19;
                auVar13._0_4_ = iVar10 + 5;
                auVar13._4_4_ = iVar10 + 6;
                auVar13._8_4_ = iVar10 + 4;
                auVar13._12_4_ = iVar10 + 4;
                auVar15 = pmovsxdq(auVar17, auVar13);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x48 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar18._8_8_ = 0;
                auVar18._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x58 + iVar9 * 0x10) = uVar19;
                iVar11 = iVar10 + 8;
                auVar14._0_4_ = iVar10 + 7;
                auVar14._4_4_ = iVar10 + 8;
                auVar14._8_4_ = iVar10 + 6;
                auVar14._12_4_ = iVar10 + 6;
                auVar15 = pmovsxdq(auVar18, auVar14);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x68 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                in_XMM2._8_8_ = 0;
                in_XMM2._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x78 + iVar9 * 0x10) = uVar19;
                iVar10 = iVar11;
            } while (iVar11 < (int32_t)(uVar1 - uVar7));
            if ((int32_t)uVar1 <= iVar11) goto code_r0x00018012ad21;
        }
        do {
            iVar11 = iVar10 + 1;
            *(int64_t *)(iVar4 + 8 + (int64_t)iVar10 * 0x10) = (int64_t)iVar11 * 0x10 + iVar4;
            iVar10 = iVar11;
        } while (iVar11 < (int32_t)uVar1);
    }
code_r0x00018012ad21:
    *(undefined8 *)(iVar4 + 8 + (int64_t)iVar11 * 0x10) = 0;
    *(undefined8 *)(piVar3 + 3) = 1;
    *(int64_t *)(piVar3 + 8) = iVar4;
    *(int32_t **)(piVar3 + 6) = piVar3 + 10;
    *piVar3 = iVar6;
    piVar3[1] = iVar2;
    piVar3[5] = iVar5;
    piVar3[2] = (iVar6 + -1 + iVar5) / iVar5;
    *(int32_t **)(piVar3 + 0xc) = piVar3 + 0xe;
    piVar3[0xe] = iVar6;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    piVar3[0xf] = 0x40000000;
    *(undefined8 *)(piVar3 + 0x10) = 0;
    *(undefined8 *)(piVar3 + 0x25) = 0;
    *(undefined8 *)(piVar3 + 0x2a) = 0;
    *(undefined8 *)(piVar3 + 0x2c) = 0;
    return;
}

// ============================================================
// Function: FUN_18012ad00
// Address: 0x18012ad00
// Size: 142 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.18012aae0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int32_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined in_XMM2 [16];
    undefined auVar15 [16];
    uint64_t uVar19;
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    int64_t var_1ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)(arg1 + 0x38);
    piVar3 = *(int32_t **)(arg1 + 0x2b0);
    iVar2 = piVar3[0x15];
    iVar5 = *(int32_t *)(iVar9 + 0x1c) / 2;
    if (iVar2 < iVar5) {
        if (iVar2 == 0) {
            iVar6 = 8;
        } else {
            iVar6 = iVar2 / 2 + iVar2;
        }
        iVar11 = iVar5;
        if (iVar5 < iVar6) {
            iVar11 = iVar6;
        }
        if (iVar2 < iVar11) {
            uVar8 = func_0x00018046d050((int64_t)iVar11 << 4);
            if (*(int64_t *)(piVar3 + 0x16) != 0) {
                func_0x000180498030(uVar8, *(int64_t *)(piVar3 + 0x16), (int64_t)piVar3[0x14] << 4);
                func_0x000180460d90(*(undefined8 *)(piVar3 + 0x16));
            }
            *(undefined8 *)(piVar3 + 0x16) = uVar8;
            piVar3[0x15] = iVar11;
        }
    }
    piVar3[0x14] = iVar5;
    uVar1 = iVar5 - 1;
    iVar4 = *(int64_t *)(piVar3 + 0x16);
    iVar2 = *(int32_t *)(iVar9 + 0x20);
    iVar6 = *(int32_t *)(iVar9 + 0x1c);
    iVar11 = 0;
    if (0 < (int32_t)uVar1) {
        iVar10 = 0;
        if ((7 < uVar1) && (iVar10 = 0, 1 < *(int32_t *)0x1806a3990)) {
            uVar7 = uVar1 & 0x80000007;
            if ((int32_t)uVar7 < 0) {
                uVar7 = (uVar7 - 1 | 0xfffffff8) + 1;
            }
            iVar10 = 0;
            do {
                iVar9 = (int64_t)iVar10;
                auVar15._0_4_ = iVar10 + 1;
                auVar15._4_4_ = iVar10 + 2;
                auVar15._8_4_ = iVar10;
                auVar15._12_4_ = iVar10;
                auVar15 = pmovsxdq(in_XMM2, auVar15);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 8 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar16._8_8_ = 0;
                auVar16._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x18 + iVar9 * 0x10) = uVar19;
                auVar12._0_4_ = iVar10 + 3;
                auVar12._4_4_ = iVar10 + 4;
                auVar12._8_4_ = iVar10 + 2;
                auVar12._12_4_ = iVar10 + 2;
                auVar15 = pmovsxdq(auVar16, auVar12);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x28 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar17._8_8_ = 0;
                auVar17._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x38 + iVar9 * 0x10) = uVar19;
                auVar13._0_4_ = iVar10 + 5;
                auVar13._4_4_ = iVar10 + 6;
                auVar13._8_4_ = iVar10 + 4;
                auVar13._12_4_ = iVar10 + 4;
                auVar15 = pmovsxdq(auVar17, auVar13);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x48 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                auVar18._8_8_ = 0;
                auVar18._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x58 + iVar9 * 0x10) = uVar19;
                iVar11 = iVar10 + 8;
                auVar14._0_4_ = iVar10 + 7;
                auVar14._4_4_ = iVar10 + 8;
                auVar14._8_4_ = iVar10 + 6;
                auVar14._12_4_ = iVar10 + 6;
                auVar15 = pmovsxdq(auVar18, auVar14);
                uVar19 = auVar15._8_8_ * 0x10 + iVar4;
                *(int64_t *)(iVar4 + 0x68 + iVar9 * 0x10) = auVar15._0_8_ * 0x10 + iVar4;
                in_XMM2._8_8_ = 0;
                in_XMM2._0_8_ = uVar19;
                *(uint64_t *)(iVar4 + 0x78 + iVar9 * 0x10) = uVar19;
                iVar10 = iVar11;
            } while (iVar11 < (int32_t)(uVar1 - uVar7));
            if ((int32_t)uVar1 <= iVar11) goto code_r0x00018012ad21;
        }
        do {
            iVar11 = iVar10 + 1;
            *(int64_t *)(iVar4 + 8 + (int64_t)iVar10 * 0x10) = (int64_t)iVar11 * 0x10 + iVar4;
            iVar10 = iVar11;
        } while (iVar11 < (int32_t)uVar1);
    }
code_r0x00018012ad21:
    *(undefined8 *)(iVar4 + 8 + (int64_t)iVar11 * 0x10) = 0;
    *(undefined8 *)(piVar3 + 3) = 1;
    *(int64_t *)(piVar3 + 8) = iVar4;
    *(int32_t **)(piVar3 + 6) = piVar3 + 10;
    *piVar3 = iVar6;
    piVar3[1] = iVar2;
    piVar3[5] = iVar5;
    piVar3[2] = (iVar6 + -1 + iVar5) / iVar5;
    *(int32_t **)(piVar3 + 0xc) = piVar3 + 0xe;
    piVar3[0xe] = iVar6;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    piVar3[0xf] = 0x40000000;
    *(undefined8 *)(piVar3 + 0x10) = 0;
    *(undefined8 *)(piVar3 + 0x25) = 0;
    *(undefined8 *)(piVar3 + 0x2a) = 0;
    *(undefined8 *)(piVar3 + 0x2c) = 0;
    return;
}

// ============================================================
// Function: FUN_18012ad90
// Address: 0x18012ad90
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18012ad90(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t *puVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 0x2b0);
    uVar6 = *(uint32_t *)(*(int64_t *)(iVar4 + 0x78) + (uint64_t)((uint32_t)arg2 & 0x7ffff) * 4);
    iVar1 = *(int64_t *)(iVar4 + 0x68) + ((int64_t)(int32_t)(uVar6 << 0xc) >> 0xc) * 8;
    if (iVar1 != 0) {
        uVar6 = uVar6 & 0xbfffffff;
        uVar7 = (uint32_t)arg2 & 0x7ffff;
        puVar2 = (uint32_t *)(*(int64_t *)(iVar4 + 0x78) + (uint64_t)uVar7 * 4);
        *puVar2 = uVar6;
        uVar5 = (*(uint32_t *)(iVar4 + 0x90) ^ uVar6) & 0xfff00000 ^ *(uint32_t *)(iVar4 + 0x90);
        uVar5 = (uVar6 + 0x100000 ^ uVar5) & 0x3ff00000 ^ uVar5;
        *puVar2 = uVar5;
        if ((uVar5 & 0x3ff00000) == 0) {
            *puVar2 = (uVar5 + 0x100000 ^ uVar5) & 0x3ff00000 ^ uVar5;
        }
        iVar3 = *(int32_t *)(arg1 + 8);
        *(int32_t *)(iVar4 + 0x9c) = *(int32_t *)(iVar4 + 0x9c) + 1;
        *(uint32_t *)(iVar4 + 0x90) = uVar7;
        *(int32_t *)(iVar4 + 0xa0) =
             *(int32_t *)(iVar4 + 0xa0) +
             ((uint32_t)*(uint16_t *)(iVar1 + 4) + iVar3) * ((uint32_t)*(uint16_t *)(iVar1 + 6) + iVar3);
        *(undefined4 *)(iVar1 + 4) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18012ae60
// Address: 0x18012ae60
// Size: 1735 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.18012ae60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_68h, int64_t arg_b0h,
                  int64_t arg_b8h)
{
    uint32_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t *puVar5;
    int32_t iVar6;
    undefined2 uVar7;
    undefined2 uVar8;
    uint32_t uVar9;
    uint16_t uVar10;
    uint32_t uVar11;
    int32_t **ppiVar12;
    uint32_t uVar13;
    int32_t *piVar14;
    int32_t *piVar15;
    int64_t iVar16;
    uint32_t *puVar17;
    int32_t iVar18;
    int32_t iVar19;
    int32_t iVar20;
    int32_t **ppiVar21;
    int32_t iVar22;
    int32_t iVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_138 [32];
    int64_t var_118h;
    int64_t var_108h;
    int32_t var_100h;
    int32_t var_fch;
    int32_t var_f8h;
    int64_t var_f4h;
    int64_t var_ech;
    int32_t var_e4h;
    uint32_t var_e0h;
    int64_t var_dch;
    int64_t var_c8h;
    undefined4 var_c0h;
    undefined4 uStack_bc;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int32_t var_70h;
    int64_t var_6ch;
    undefined4 var_64h;
    int64_t var_60h;
    int64_t var_58h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_138;
    puVar17 = *(uint32_t **)(arg1 + 0x2b0);
    var_dch._0_4_ = (uint32_t)arg3;
    var_e0h = (uint32_t)arg2;
    var_dch._4_4_ = *(int32_t *)(arg1 + 8);
    uVar11 = var_e0h;
    if ((int32_t)var_e0h <= (int32_t)puVar17[0x2a]) {
        uVar11 = puVar17[0x2a];
    }
    var_f8h = var_e0h + var_dch._4_4_;
    puVar17[0x2a] = uVar11;
    iVar23 = (uint32_t)var_dch + var_dch._4_4_;
    var_f4h._0_4_ = 3;
    uVar11 = (uint32_t)var_dch;
    if ((int32_t)(uint32_t)var_dch <= (int32_t)puVar17[0x2b]) {
        uVar11 = puVar17[0x2b];
    }
    puVar17[0x2b] = uVar11;
    var_fch = iVar23;
    var_98h = (int64_t)puVar17;
    var_90h = arg1;
    var_80h = arg4;
    do {
        var_78h._0_4_ = 0;
        var_6ch = 0;
        var_64h = 0;
        var_78h._4_4_ = var_f8h;
        var_70h = iVar23;
        if ((var_f8h == 0) || (iVar23 == 0)) {
            uVar11 = 0;
            var_6ch = 0;
            iVar22 = 0;
        } else {
            iVar22 = (puVar17[2] - 1) + var_f8h;
            uVar11 = *puVar17;
            piVar14 = (int32_t *)(uint64_t)uVar11;
            iVar22 = iVar22 - iVar22 % (int32_t)puVar17[2];
            if (((int32_t)uVar11 < iVar22) || (var_ech._0_4_ = puVar17[1], (int32_t)(uint32_t)var_ech < iVar23)) {
                ppiVar21 = (int32_t **)0x0;
                var_b8h = 0;
                iVar19 = 0;
            } else {
                piVar15 = *(int32_t **)(puVar17 + 6);
                var_88h = (int64_t)(puVar17 + 6);
                iVar23 = 0x40000000;
                var_108h = 0;
                uVar13 = 0x40000000;
                var_100h = 0x40000000;
                var_ech._4_4_ = *piVar15;
                var_a0h = (int64_t)piVar15;
                if ((int32_t)uVar11 < iVar22 + var_ech._4_4_) {
code_r0x00018012b110:
                    iVar19 = 0;
                } else {
                    var_a8h = var_88h;
                    iVar19 = var_ech._4_4_;
                    do {
                        iVar18 = 0;
                        iVar20 = 0;
                        piVar14 = (int32_t *)var_a0h;
                        iVar6 = iVar23;
                        uVar9 = 0;
                        iVar23 = iVar19;
                        while (iVar23 < iVar19 + iVar22) {
                            uVar1 = piVar14[1];
                            iVar6 = var_100h;
                            if ((int32_t)uVar9 < (int32_t)uVar1) {
                                piVar2 = *(int32_t **)(piVar14 + 2);
                                iVar23 = *piVar2;
                                iVar18 = iVar18 + (uVar1 - uVar9) * iVar20;
                                uVar9 = uVar1;
                                if (*piVar14 < iVar19) {
                                    iVar20 = iVar20 + (iVar23 - iVar19);
                                    piVar14 = piVar2;
                                } else {
                                    iVar20 = iVar20 + (iVar23 - *piVar14);
                                    piVar14 = piVar2;
                                }
                            } else {
                                iVar23 = **(int32_t **)(piVar14 + 2);
                                iVar4 = iVar23 - *piVar14;
                                if (iVar22 < (iVar23 - *piVar14) + iVar20) {
                                    iVar4 = iVar22 - iVar20;
                                }
                                iVar18 = iVar18 + (uVar9 - uVar1) * iVar4;
                                iVar20 = iVar20 + iVar4;
                                piVar14 = *(int32_t **)(piVar14 + 2);
                            }
                        }
                        if (puVar17[4] == 0) {
                            iVar23 = iVar6;
                            iVar18 = var_100h;
                            if ((int32_t)uVar13 <= (int32_t)uVar9) {
code_r0x00018012b0c0:
                                uVar9 = uVar13;
                                iVar23 = iVar6;
                                var_a8h = var_108h;
                                iVar18 = var_100h;
                            }
                        } else if (((int32_t)(uint32_t)var_ech < (int32_t)(var_fch + uVar9)) ||
                                  ((iVar23 = iVar18, (int32_t)uVar13 <= (int32_t)uVar9 &&
                                   ((uVar9 != uVar13 || (iVar6 <= iVar18)))))) goto code_r0x00018012b0c0;
                        var_100h = iVar18;
                        var_108h = var_a8h;
                        uVar13 = uVar9;
                        var_a8h = var_a0h + 8;
                        var_a0h = *(int64_t *)(var_a0h + 8);
                        iVar19 = *(int32_t *)var_a0h;
                    } while (iVar22 + iVar19 <= (int32_t)uVar11);
                    puVar17 = (uint32_t *)var_98h;
                    if (var_108h == 0) goto code_r0x00018012b110;
                    iVar19 = **(int32_t **)var_108h;
                }
                piVar2 = piVar15;
                iVar23 = var_ech._4_4_;
                if (puVar17[4] == 1) {
                    while (var_c8h = (int64_t)piVar15, puVar5 = (uint32_t *)var_88h, iVar23 < iVar22) {
                        ppiVar21 = (int32_t **)(piVar2 + 2);
                        piVar2 = *ppiVar21;
                        iVar23 = **ppiVar21;
                    }
                    for (; piVar2 != (int32_t *)0x0; piVar2 = *(int32_t **)(piVar2 + 2)) {
                        iVar20 = *piVar2 - iVar22;
                        iVar23 = **(int32_t **)(piVar15 + 2);
                        while (iVar23 <= iVar20) {
                            puVar5 = (uint32_t *)(piVar15 + 2);
                            piVar15 = *(int32_t **)(piVar15 + 2);
                            iVar23 = **(int32_t **)(piVar15 + 2);
                        }
                        var_118h = (int64_t)&var_e4h;
                        uVar11 = func_0x00018011fc80(piVar14, piVar15, iVar20, iVar22);
                        piVar14 = (int32_t *)(uint64_t)uVar11;
                        if ((((int32_t)(var_fch + uVar11) <= (int32_t)puVar17[1]) &&
                            ((int32_t)uVar11 <= (int32_t)uVar13)) &&
                           ((((int32_t)uVar11 < (int32_t)uVar13 || (var_e4h < var_100h)) ||
                            ((var_e4h == var_100h && (iVar20 < iVar19)))))) {
                            var_100h = var_e4h;
                            uVar13 = uVar11;
                            iVar19 = iVar20;
                            var_108h = (int64_t)puVar5;
                        }
                    }
                }
                var_b8h = CONCAT44(uVar13, iVar19);
                ppiVar21 = (int32_t **)var_108h;
                iVar23 = var_fch;
            }
            var_b0h._0_4_ = SUB84(ppiVar21, 0);
            var_b0h._4_4_ = (undefined4)((uint64_t)ppiVar21 >> 0x20);
            iVar22 = (int32_t)var_b8h;
            var_c8h = var_b8h;
            var_c0h = (undefined4)var_b0h;
            uStack_bc = var_b0h._4_4_;
            if (((ppiVar21 == (int32_t **)0x0) || ((int32_t)puVar17[1] < (int32_t)(var_b8h._4_4_ + iVar23))) ||
               (piVar14 = *(int32_t **)(puVar17 + 8), piVar14 == (int32_t *)0x0)) {
                ppiVar12 = (int32_t **)0x0;
            } else {
                *piVar14 = iVar19;
                piVar14[1] = var_b8h._4_4_ + iVar23;
                *(undefined8 *)(puVar17 + 8) = *(undefined8 *)(piVar14 + 2);
                piVar15 = *ppiVar21;
                if (*piVar15 < iVar19) {
                    ppiVar12 = (int32_t **)(piVar15 + 2);
                    piVar15 = *(int32_t **)(piVar15 + 2);
                    *ppiVar12 = piVar14;
                } else {
                    *ppiVar21 = piVar14;
                }
                iVar3 = *(int64_t *)(piVar15 + 2);
                while ((iVar3 != 0 && (piVar2 = *(int32_t **)(piVar15 + 2), *piVar2 <= iVar19 + var_f8h))) {
                    *(undefined8 *)(piVar15 + 2) = *(undefined8 *)(puVar17 + 8);
                    *(int32_t **)(puVar17 + 8) = piVar15;
                    iVar3 = *(int64_t *)(piVar2 + 2);
                    piVar15 = piVar2;
                }
                *(int32_t **)(piVar14 + 2) = piVar15;
                ppiVar12 = ppiVar21;
                if (*piVar15 < iVar19 + var_f8h) {
                    *piVar15 = iVar19 + var_f8h;
                }
            }
            arg1 = var_90h;
            var_b0h = (int64_t)ppiVar21;
            if (ppiVar12 == (int32_t **)0x0) {
                uVar11 = 0x7fffffff;
                iVar22 = 0x7fffffff;
                var_6ch = 0x7fffffff7fffffff;
            } else {
                var_6ch = var_b8h;
                uVar11 = var_b8h._4_4_;
            }
        }
        iVar19 = (int32_t)var_f4h;
        if ((iVar22 != 0x7fffffff) || (uVar11 != 0x7fffffff)) {
            var_64h = 1;
            uVar10 = (uint16_t)iVar22;
            uVar11 = uVar11 & 0xffff;
code_r0x00018012b39d:
            uVar7 = (undefined2)var_e0h;
            uVar8 = (undefined2)var_dch;
            uVar13 = (uint32_t)uVar10 + var_dch._4_4_ + (var_e0h & 0xffff);
            if ((int32_t)uVar13 <= (int32_t)puVar17[0x2c]) {
                uVar13 = puVar17[0x2c];
            }
            puVar17[0x2c] = uVar13;
            uVar13 = uVar11 + var_dch._4_4_ + ((uint32_t)var_dch & 0xffff);
            if ((int32_t)uVar13 <= (int32_t)puVar17[0x2d]) {
                uVar13 = puVar17[0x2d];
            }
            puVar17[0x25] = puVar17[0x25] + 1;
            puVar17[0x2d] = uVar13;
            puVar17[0x26] = puVar17[0x26] + iVar23 * var_f8h;
            uVar13 = puVar17[0x19];
            if (puVar17[0x18] == uVar13) {
                iVar23 = puVar17[0x18] + 1;
                if (uVar13 == 0) {
                    iVar22 = 8;
                } else {
                    iVar22 = (int32_t)uVar13 / 2 + uVar13;
                }
                if (iVar23 < iVar22) {
                    iVar23 = iVar22;
                }
                func_0x00018011f4f0(puVar17 + 0x18, iVar23);
            }
            iVar16 = (int64_t)(int32_t)puVar17[0x18];
            iVar3 = *(int64_t *)(puVar17 + 0x1a);
            *(uint16_t *)(iVar3 + iVar16 * 8) = uVar10;
            *(int16_t *)(iVar3 + 2 + iVar16 * 8) = (int16_t)uVar11;
            *(undefined2 *)(iVar3 + 4 + iVar16 * 8) = uVar7;
            *(undefined2 *)(iVar3 + 6 + iVar16 * 8) = uVar8;
            uVar11 = puVar17[0x18];
            puVar17[0x18] = uVar11 + 1;
            iVar3 = *(int64_t *)(arg1 + 0x2b0);
            if (var_80h == 0) {
                iVar23 = *(int32_t *)(iVar3 + 0x90);
                if (iVar23 < 0) {
                    func_0x000180131110(iVar3 + 0x70, *(int32_t *)(iVar3 + 0x70) + 1);
                    puVar17 = (uint32_t *)(*(int64_t *)(iVar3 + 0x78) + (int64_t)(*(int32_t *)(iVar3 + 0x70) + -1) * 4);
                    uVar13 = 0;
                } else {
                    puVar17 = (uint32_t *)(*(int64_t *)(iVar3 + 0x78) + (int64_t)iVar23 * 4);
                    *(int32_t *)(iVar3 + 0x90) =
                         (*(int32_t *)(*(int64_t *)(iVar3 + 0x78) + (int64_t)iVar23 * 4) << 0xc) >> 0xc;
                    uVar13 = *puVar17;
                }
                *puVar17 = (uVar13 ^ uVar11) & 0xfff00000 ^ uVar11 | 0x40000000;
            } else {
                uVar11 = *(int32_t *)(iVar3 + 0x60) - 1;
                *(uint32_t *)var_80h = (uVar11 ^ *(uint32_t *)var_80h) & 0xfff00000 ^ uVar11;
            }
code_r0x00018012b4fb:
            func_0x000180459870(var_60h ^ (uint64_t)auStack_138);
            return;
        }
        var_64h = 0;
        if (((int32_t)var_f4h == 0) || (*(char *)(puVar17 + 0x2e) != '\0')) goto code_r0x00018012b4fb;
        uVar10 = (uint16_t)var_6ch;
        uVar11 = (uint32_t)var_6ch._4_2_;
        iVar3 = *(int64_t *)(arg1 + 0x2b0);
        fcn.180129630(arg1, 2);
        if ((float)*(int32_t *)(iVar3 + 0x98) * 0.2 <= (float)*(int32_t *)(iVar3 + 0xa0)) {
            fcn.1801299b0(arg1, (uint64_t)*(uint32_t *)(*(int64_t *)(arg1 + 0x38) + 0x1c), 
                          (uint64_t)*(uint32_t *)(*(int64_t *)(arg1 + 0x38) + 0x20));
        } else {
            fcn.180129e30(arg1, 0xffffffff, 0xffffffff);
        }
        var_f4h._0_4_ = iVar19 + -1;
        if ((int32_t)var_f4h < 0) goto code_r0x00018012b39d;
    } while( true );
}

// ============================================================
// Function: FUN_18012b530
// Address: 0x18012b530
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18012b530(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar3 = (uint32_t)arg2;
    if (uVar3 != 0xffffffff) {
        if (*(int64_t *)(arg1 + 0x2b0) == 0) {
            fcn.18012a190(arg1);
        }
        iVar2 = *(int64_t *)(arg1 + 0x2b0);
        if ((((int32_t)(uVar3 & 0x7ffff) < *(int32_t *)(iVar2 + 0x70)) &&
            (uVar1 = *(uint32_t *)(*(int64_t *)(iVar2 + 0x78) + (uint64_t)(uVar3 & 0x7ffff) * 4),
            ((uVar1 ^ uVar3) & 0x3ff00000) == 0)) && ((uVar1 >> 0x1e & 1) != 0)) {
            return *(int64_t *)(iVar2 + 0x68) + ((int64_t)(int32_t)(uVar1 << 0xc) >> 0xc) * 8;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18012b5c0
// Address: 0x18012b5c0
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18012b5c0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    undefined2 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x20);
    iVar4 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar4 <= *piVar1) {
        return;
    }
    var_10h._0_4_ = 0xbf800000;
    func_0x0001801311c0(arg1, arg2, &var_10h);
    iVar3 = *(int32_t *)(arg1 + 0x24);
    if (iVar3 < iVar4) {
        if (iVar3 == 0) {
            uVar2 = 8;
        } else {
            uVar2 = iVar3 / 2 + iVar3;
        }
        if (iVar4 < (int32_t)uVar2) {
            uVar6 = (uint64_t)uVar2;
        }
        func_0x00018011f8d0(piVar1, uVar6);
    }
    iVar3 = *piVar1;
    uVar6 = (uint64_t)iVar3;
    if (iVar3 < iVar4) {
        if (7 < (uint32_t)(iVar4 - iVar3)) {
            puVar7 = (undefined2 *)(*(int64_t *)(arg1 + 0x28) + uVar6 * 2);
            if (((undefined2 *)(arg1 + 0x28) < puVar7) ||
               ((undefined2 *)(*(int64_t *)(arg1 + 0x28) + (int64_t)(iVar4 + -1) * 2) < (undefined2 *)(arg1 + 0x28))) {
                uVar2 = iVar4 - iVar3 & 0x80000007;
                if ((int32_t)uVar2 < 0) {
                    uVar2 = (uVar2 - 1 | 0xfffffff8) + 1;
                }
                do {
                    uVar5 = (int32_t)uVar6 + 8;
                    uVar6 = (uint64_t)uVar5;
                } while ((int32_t)uVar5 < (int32_t)(iVar4 - uVar2));
                iVar3 = ((iVar4 - uVar2) - iVar3) + 7;
                for (uVar6 = (uint64_t)((int64_t)((int32_t)(iVar3 + (iVar3 >> 0x1f & 7U)) >> 3) << 4) >> 1; uVar6 != 0;
                    uVar6 = uVar6 - 1) {
                    *puVar7 = 0xffff;
                    puVar7 = puVar7 + 1;
                }
                uVar6 = (uint64_t)uVar5;
                if (iVar4 <= (int32_t)uVar5) goto code_r0x00018012b6c7;
            }
        }
        do {
            iVar3 = (int32_t)uVar6;
            uVar2 = iVar3 + 1;
            uVar6 = (uint64_t)uVar2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x28) + (int64_t)iVar3 * 2) = 0xffff;
        } while ((int32_t)uVar2 < iVar4);
    }
code_r0x00018012b6c7:
    *piVar1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18012b61f
// Address: 0x18012b61f
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18012b5c0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    undefined2 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x20);
    iVar4 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar4 <= *piVar1) {
        return;
    }
    var_10h._0_4_ = 0xbf800000;
    func_0x0001801311c0(arg1, arg2, &var_10h);
    iVar3 = *(int32_t *)(arg1 + 0x24);
    if (iVar3 < iVar4) {
        if (iVar3 == 0) {
            uVar2 = 8;
        } else {
            uVar2 = iVar3 / 2 + iVar3;
        }
        if (iVar4 < (int32_t)uVar2) {
            uVar6 = (uint64_t)uVar2;
        }
        func_0x00018011f8d0(piVar1, uVar6);
    }
    iVar3 = *piVar1;
    uVar6 = (uint64_t)iVar3;
    if (iVar3 < iVar4) {
        if (7 < (uint32_t)(iVar4 - iVar3)) {
            puVar7 = (undefined2 *)(*(int64_t *)(arg1 + 0x28) + uVar6 * 2);
            if (((undefined2 *)(arg1 + 0x28) < puVar7) ||
               ((undefined2 *)(*(int64_t *)(arg1 + 0x28) + (int64_t)(iVar4 + -1) * 2) < (undefined2 *)(arg1 + 0x28))) {
                uVar2 = iVar4 - iVar3 & 0x80000007;
                if ((int32_t)uVar2 < 0) {
                    uVar2 = (uVar2 - 1 | 0xfffffff8) + 1;
                }
                do {
                    uVar5 = (int32_t)uVar6 + 8;
                    uVar6 = (uint64_t)uVar5;
                } while ((int32_t)uVar5 < (int32_t)(iVar4 - uVar2));
                iVar3 = ((iVar4 - uVar2) - iVar3) + 7;
                for (uVar6 = (uint64_t)((int64_t)((int32_t)(iVar3 + (iVar3 >> 0x1f & 7U)) >> 3) << 4) >> 1; uVar6 != 0;
                    uVar6 = uVar6 - 1) {
                    *puVar7 = 0xffff;
                    puVar7 = puVar7 + 1;
                }
                uVar6 = (uint64_t)uVar5;
                if (iVar4 <= (int32_t)uVar5) goto code_r0x00018012b6c7;
            }
        }
        do {
            iVar3 = (int32_t)uVar6;
            uVar2 = iVar3 + 1;
            uVar6 = (uint64_t)uVar2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x28) + (int64_t)iVar3 * 2) = 0xffff;
        } while ((int32_t)uVar2 < iVar4);
    }
code_r0x00018012b6c7:
    *piVar1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18012b6c7
// Address: 0x18012b6c7
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18012b5c0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    undefined2 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x20);
    iVar4 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar4 <= *piVar1) {
        return;
    }
    var_10h._0_4_ = 0xbf800000;
    func_0x0001801311c0(arg1, arg2, &var_10h);
    iVar3 = *(int32_t *)(arg1 + 0x24);
    if (iVar3 < iVar4) {
        if (iVar3 == 0) {
            uVar2 = 8;
        } else {
            uVar2 = iVar3 / 2 + iVar3;
        }
        if (iVar4 < (int32_t)uVar2) {
            uVar6 = (uint64_t)uVar2;
        }
        func_0x00018011f8d0(piVar1, uVar6);
    }
    iVar3 = *piVar1;
    uVar6 = (uint64_t)iVar3;
    if (iVar3 < iVar4) {
        if (7 < (uint32_t)(iVar4 - iVar3)) {
            puVar7 = (undefined2 *)(*(int64_t *)(arg1 + 0x28) + uVar6 * 2);
            if (((undefined2 *)(arg1 + 0x28) < puVar7) ||
               ((undefined2 *)(*(int64_t *)(arg1 + 0x28) + (int64_t)(iVar4 + -1) * 2) < (undefined2 *)(arg1 + 0x28))) {
                uVar2 = iVar4 - iVar3 & 0x80000007;
                if ((int32_t)uVar2 < 0) {
                    uVar2 = (uVar2 - 1 | 0xfffffff8) + 1;
                }
                do {
                    uVar5 = (int32_t)uVar6 + 8;
                    uVar6 = (uint64_t)uVar5;
                } while ((int32_t)uVar5 < (int32_t)(iVar4 - uVar2));
                iVar3 = ((iVar4 - uVar2) - iVar3) + 7;
                for (uVar6 = (uint64_t)((int64_t)((int32_t)(iVar3 + (iVar3 >> 0x1f & 7U)) >> 3) << 4) >> 1; uVar6 != 0;
                    uVar6 = uVar6 - 1) {
                    *puVar7 = 0xffff;
                    puVar7 = puVar7 + 1;
                }
                uVar6 = (uint64_t)uVar5;
                if (iVar4 <= (int32_t)uVar5) goto code_r0x00018012b6c7;
            }
        }
        do {
            iVar3 = (int32_t)uVar6;
            uVar2 = iVar3 + 1;
            uVar6 = (uint64_t)uVar2;
            *(undefined2 *)(*(int64_t *)(arg1 + 0x28) + (int64_t)iVar3 * 2) = 0xffff;
        } while ((int32_t)uVar2 < iVar4);
    }
code_r0x00018012b6c7:
    *piVar1 = iVar4;
    return;
}

// ============================================================
// Function: FUN_18012b6e0
// Address: 0x18012b6e0
// Size: 1258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

int64_t fcn.18012b6e0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                     int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint16_t *puVar1;
    int64_t *piVar2;
    float fVar3;
    uint16_t uVar4;
    int64_t arg1_00;
    undefined8 uVar5;
    undefined auVar6 [12];
    char cVar7;
    uint16_t uVar8;
    uint32_t uVar9;
    uint16_t *puVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    int64_t unaff_R13;
    int32_t iVar16;
    int64_t unaff_R14;
    int64_t iVar17;
    int64_t *piVar18;
    int64_t iVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_38h;
    
    iVar11 = *(int64_t *)(arg1 + 0x58);
    arg1_00 = *(int64_t *)(iVar11 + 8);
    if ((*(char *)(arg1_00 + 0x50) != '\0') || ((*(uint8_t *)(iVar11 + 0x10) & 4) != 0)) {
        if (*(int32_t *)(arg1 + 0x40) != -1) {
            return 0;
        }
        if ((*(uint32_t *)(arg1 + 0x4c) & 0x8000000) != 0) {
            return 0;
        }
        fcn.180129350(arg1);
        return 0;
    }
    uVar8 = (uint16_t)placeholder_1;
    if (*(int32_t *)(iVar11 + 0x38) != 0) {
        uVar8 = func_0x0001800f6060(iVar11 + 0x38, (uint16_t)placeholder_1, (uint16_t)placeholder_1);
    }
    fVar22 = 1.0;
    if ((uVar8 != *(uint16_t *)(iVar11 + 0x30)) || (*(char *)(iVar11 + 0x35) == '\0')) goto code_r0x00018012b98e;
    if (*(uint32_t *)(arg1 + 0x20) < 0x2f) {
code_r0x00018012b79a:
        *(uint32_t *)(arg1 + 0x4c) = *(uint32_t *)(arg1 + 0x4c) | 0x8000000;
        iVar17 = fcn.18012b6e0(arg1, 0x2e, 0, placeholder_3, 
                               CONCAT44(var_b8h._4_4_, CONCAT22(var_b8h._2_2_, (undefined2)var_b8h)), var_b0h, var_a8h, 
                               CONCAT44(var_a0h._4_4_, (uint32_t)var_a0h), var_98h);
        *(uint32_t *)(arg1 + 0x4c) = *(uint32_t *)(arg1 + 0x4c) & 0xf7ffffff;
code_r0x00018012b7bb:
        if (iVar17 == 0) goto code_r0x00018012b7c0;
    } else {
        uVar4 = *(uint16_t *)(*(int64_t *)(arg1 + 0x28) + 0x5c);
        if (uVar4 != 0xfffe) {
            if (uVar4 == 0xffff) goto code_r0x00018012b79a;
            iVar17 = (uint64_t)uVar4 * 0x2c + *(int64_t *)(arg1 + 0x38);
            goto code_r0x00018012b7bb;
        }
code_r0x00018012b7c0:
        iVar17 = func_0x00018012eb80(arg1);
        if (iVar17 == 0) goto code_r0x00018012b98e;
    }
    auVar6 = stack0xffffffffffffff84;
    fVar20 = *(float *)(iVar17 + 0x10);
    uVar12 = (uint64_t)(*(uint32_t *)(iVar17 + 0x28) & 0x7ffff);
    fVar21 = *(float *)(iVar17 + 8);
    iVar14 = *(int64_t *)(*(int64_t *)(arg1_00 + 0x2b0) + 0x68);
    iVar15 = (int64_t)(*(int32_t *)(*(int64_t *)(*(int64_t *)(arg1_00 + 0x2b0) + 0x78) + uVar12 * 4) << 0xc) >> 0xc;
    uVar9 = fcn.18012ae60(arg1_00, (uint64_t)((uint32_t)*(uint16_t *)(iVar14 + 4 + iVar15 * 8) * 3 + 2), 
                          (uint64_t)*(uint16_t *)(iVar14 + 6 + iVar15 * 8), 0, stack0xffffffffffffff88, unaff_R14, 
                          unaff_R13);
    stack0xffffffffffffff84 = auVar6;
    fVar3 = *(float *)(iVar17 + 8);
    iVar14 = *(int64_t *)(*(int64_t *)(arg1_00 + 0x2b0) + 0x68);
    fVar21 = (((fVar20 - fVar21) + 1.0) * 3.0 + fVar3) - 1.0;
    var_80h._0_4_ = fVar3;
    fVar20 = *(float *)(iVar17 + 4);
    if (*(float *)(iVar17 + 4) <= fVar21) {
        fVar20 = fVar21;
    }
    stack0xffffffffffffff88 = fVar21;
    stack0xffffffffffffff8c = *(undefined4 *)(iVar17 + 0x14);
    iVar19 = (int64_t)(*(int32_t *)
                        (*(int64_t *)(*(int64_t *)(arg1_00 + 0x2b0) + 0x78) + (uint64_t)(uVar9 & 0x7ffff) * 4) << 0xc)
             >> 0xc;
    var_88h = CONCAT44(fVar20, (uint32_t)*(uint16_t *)(iVar11 + 0x30) << 6) | 2;
    var_80h = CONCAT44(*(undefined4 *)(iVar17 + 0xc), fVar3);
    iVar15 = func_0x00018012e840(arg1_00, arg1, 0, &var_88h);
    uVar5 = *(undefined8 *)(arg1_00 + 0x38);
    iVar17 = *(int64_t *)(*(int64_t *)(arg1_00 + 0x2b0) + 0x68);
    iVar13 = (int64_t)(*(int32_t *)(*(int64_t *)(*(int64_t *)(arg1_00 + 0x2b0) + 0x78) + uVar12 * 4) << 0xc) >> 0xc;
    iVar16 = 0;
    do {
        uVar4 = *(uint16_t *)(iVar17 + 4 + iVar13 * 8);
        var_a0h._0_4_ = (uint32_t)*(uint16_t *)(iVar17 + 6 + iVar13 * 8);
        var_a8h = CONCAT44(var_a8h._4_4_, (uint32_t)uVar4);
        var_b0h = (int64_t)*(uint16_t *)(iVar14 + 2 + iVar19 * 8);
        var_b8h._0_2_ = (undefined2)((uVar4 + 1) * iVar16 + (uint32_t)*(uint16_t *)(iVar14 + iVar19 * 8));
        func_0x000180127470(uVar5, *(undefined2 *)(iVar17 + iVar13 * 8), *(undefined2 *)(iVar17 + 2 + iVar13 * 8), uVar5
                            , (undefined2)var_b8h, var_b0h);
        iVar16 = iVar16 + 1;
    } while (iVar16 < 3);
    var_b0h = (int64_t)*(uint16_t *)(iVar14 + 6 + iVar19 * 8);
    func_0x000180127510(arg1_00, uVar5, *(undefined2 *)(iVar14 + iVar19 * 8), *(undefined2 *)(iVar14 + 2 + iVar19 * 8), 
                        *(undefined2 *)(iVar14 + 4 + iVar19 * 8), var_b0h);
    if (iVar15 != 0) {
        return iVar15;
    }
code_r0x00018012b98e:
    uVar9 = 0;
    piVar18 = *(int64_t **)(iVar11 + 0x28);
    iVar17 = *(int64_t *)(arg1 + 0x60);
    piVar2 = piVar18 + *(int32_t *)(iVar11 + 0x20);
    do {
        if (piVar18 == piVar2) {
            if ((*(uint32_t *)(arg1 + 0x4c) & 0x8000000) == 0) {
                if (*(int32_t *)(arg1 + 0x40) == -1) {
                    fcn.180129350(arg1);
                }
                fcn.18012b5c0(arg1, (uint64_t)(uVar8 + 1), var_a8h, CONCAT44(var_a0h._4_4_, (uint32_t)var_a0h));
                *(undefined4 *)(*(int64_t *)(arg1 + 8) + (uint64_t)uVar8 * 4) = *(undefined4 *)(arg1 + 0x10);
                *(undefined2 *)(*(int64_t *)(arg1 + 0x28) + (uint64_t)uVar8 * 2) = 0xfffe;
            }
            return 0;
        }
        iVar11 = *piVar18;
        iVar14 = *(int64_t *)(iVar11 + 0x88);
        if (iVar14 == 0) {
            iVar14 = *(int64_t *)(arg1_00 + 0x2b8);
        }
        puVar10 = *(uint16_t **)(iVar11 + 0x48);
        if (puVar10 != (uint16_t *)0x0) {
            uVar4 = *puVar10;
            while (uVar4 != 0) {
                if ((uVar4 <= uVar8) && (uVar8 <= puVar10[1])) goto code_r0x00018012bab0;
                puVar1 = puVar10 + 2;
                puVar10 = puVar10 + 2;
                uVar4 = *puVar1;
            }
        }
        if (arg3 == 0) {
            var_a8h = 0;
            var_88h = 0;
            _var_80h = ZEXT816(0);
            cVar7 = (**(code **)(iVar14 + 0x40))(arg1_00, iVar11, arg1, iVar17, uVar8, &var_88h);
            if (cVar7 != '\0') {
                var_88h = CONCAT44(var_88h._4_4_, 
                                   ((uint32_t)(uint16_t)placeholder_1 << 4 | uVar9 & 0xf) << 2 | (uint32_t)var_88h & 3);
                iVar11 = func_0x00018012e840(arg1_00, arg1, iVar11, &var_88h);
                return iVar11;
            }
        } else {
            cVar7 = (**(code **)(iVar14 + 0x40))(arg1_00, iVar11, arg1, iVar17, uVar8, 0);
            var_a8h = arg3;
            if (cVar7 != '\0') {
                fVar20 = *(float *)arg3;
                fVar21 = *(float *)(**(int64_t **)(*(int64_t *)(arg1 + 0x58) + 0x28) + 0x3c);
                if (fVar21 != 0.0) {
                    fVar22 = *(float *)(arg1 + 0x14) / fVar21;
                }
                fVar21 = fVar22 * *(float *)(iVar11 + 0x58);
                if ((fVar21 <= fVar20) && (fVar21 = fVar22 * *(float *)(iVar11 + 0x5c), fVar20 <= fVar21)) {
                    fVar21 = fVar20;
                }
                if (*(char *)(iVar11 + 0x36) != '\0') {
                    fVar21 = (float)(int32_t)(fVar21 + 0.5);
                }
                fVar22 = *(float *)(iVar11 + 0x60);
                fcn.18012b5c0(arg1, (uint64_t)(uVar8 + 1), arg3, CONCAT44(var_a0h._4_4_, (uint32_t)var_a0h));
                *(float *)(*(int64_t *)(arg1 + 8) + (uint64_t)uVar8 * 4) = fVar21 + fVar22;
                return 0;
            }
        }
code_r0x00018012bab0:
        iVar17 = iVar17 + *(int64_t *)(iVar14 + 0x48);
        uVar9 = uVar9 + 1;
        piVar18 = piVar18 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18012bbd0
// Address: 0x18012bbd0
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

undefined4 fcn.18012bbd0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t unaff_RBX;
    undefined8 in_R9;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    
    if ((128.0 <= *(float *)(arg1 + 0x14)) || ((*(uint32_t *)(arg1 + 0x4c) & 0x10000000) != 0)) {
        var_8h._0_4_ = 0;
        iVar1 = fcn.18012b6e0(arg1, arg2, (int64_t)&var_8h, in_R9, unaff_RBX, unaff_retaddr, 
                              (uint64_t)var_8h._4_4_ << 0x20, in_stack_00000010, in_stack_00000018);
        if (iVar1 == 0) {
            return (undefined4)var_8h;
        }
    } else {
        iVar1 = fcn.18012b6e0(arg1, arg2, 0, in_R9, unaff_RBX, unaff_retaddr, CONCAT44(var_8h._4_4_, (undefined4)var_8h)
                              , in_stack_00000010, in_stack_00000018);
        if (iVar1 == 0) {
            return *(undefined4 *)(arg1 + 0x10);
        }
    }
    return *(undefined4 *)(iVar1 + 4);
}

// ============================================================
// Function: FUN_18012bc40
// Address: 0x18012bc40
// Size: 1948 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

uint64_t fcn.18012bc40(undefined8 placeholder_0, int64_t arg2)
{
    float fVar1;
    char cVar2;
    uint8_t uVar3;
    char *pcVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int16_t iVar7;
    uint32_t uVar8;
    int32_t iVar9;
    undefined4 uVar10;
    uint32_t uVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    code *pcVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int32_t iVar19;
    int64_t iVar20;
    int64_t iVar21;
    bool bVar22;
    float fVar23;
    undefined4 uVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_88h;
    undefined8 var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    
    iVar12 = func_0x00018046d050(0xa8);
    pcVar4 = *(char **)(arg2 + 0x28);
    iVar17 = *(int32_t *)(arg2 + 100);
    cVar2 = *pcVar4;
    if (cVar2 == '1') {
        if ((pcVar4[1] != '\0') || (pcVar4[2] != '\0')) goto code_r0x00018012c38f;
        if (pcVar4[3] != '\0') goto code_r0x00018012bc93;
code_r0x00018012bd08:
        bVar22 = iVar17 != 0;
        iVar17 = -iVar17;
        iVar19 = -(uint32_t)bVar22;
code_r0x00018012bdb3:
        if (iVar19 < 0) goto code_r0x00018012c38f;
        *(char **)(iVar12 + 8) = pcVar4;
        *(int32_t *)(iVar12 + 0x10) = iVar19;
        *(undefined8 *)(iVar12 + 0x40) = 0;
        *(undefined8 *)(iVar12 + 0x48) = 0;
        uVar8 = func_0x0001801202d0(pcVar4, iVar19, 0x18064546c);
        iVar17 = func_0x0001801202d0(pcVar4, iVar19, 0x18064544c);
        *(int32_t *)(iVar12 + 0x18) = iVar17;
        iVar9 = func_0x0001801202d0(pcVar4, iVar19, 0x180645454);
        *(int32_t *)(iVar12 + 0x1c) = iVar9;
        var_20h._0_4_ = func_0x0001801202d0(pcVar4, iVar19, 0x18064545c);
        *(int32_t *)(iVar12 + 0x20) = (int32_t)var_20h;
        var_10h._0_4_ = func_0x0001801202d0(pcVar4, iVar19, 0x180645464);
        *(int32_t *)(iVar12 + 0x24) = (int32_t)var_10h;
        var_18h._0_4_ = func_0x0001801202d0(pcVar4, iVar19, 0x18064547c);
        *(int32_t *)(iVar12 + 0x28) = (int32_t)var_18h;
        uVar10 = func_0x0001801202d0(pcVar4, iVar19, 0x180645484);
        *(undefined4 *)(iVar12 + 0x2c) = uVar10;
        uVar10 = func_0x0001801202d0(pcVar4, iVar19, 0x18064548c);
        *(undefined4 *)(iVar12 + 0x30) = uVar10;
        if (((uVar8 != 0) && (iVar9 != 0)) && (((int32_t)var_10h != 0 && ((int32_t)var_18h != 0)))) {
            if ((int32_t)var_20h == 0) {
                var_20h._0_4_ = 2;
                var_10h._0_4_ = 0;
                var_98h._0_4_ = 0;
                var_98h._4_4_ = 0;
                uVar11 = func_0x0001801202d0(pcVar4, iVar19, 0x180645494);
                if (uVar11 == 0) goto code_r0x00018012bea0;
                *(undefined8 *)(iVar12 + 0x80) = 0;
                *(undefined8 *)(iVar12 + 0x88) = 0;
                *(undefined8 *)(iVar12 + 0x90) = 0;
                *(undefined8 *)(iVar12 + 0x98) = 0;
                *(char **)(iVar12 + 0x40) = pcVar4 + uVar11;
                *(undefined4 *)(iVar12 + 0x48) = 0;
                *(undefined4 *)(iVar12 + 0x4c) = 0x20000000;
                iVar17 = *(int32_t *)(iVar12 + 0x48) + 2;
                var_70h._4_4_ = SUB164(*(undefined (*) [16])(iVar12 + 0x40), 0xc);
                var_78h = SUB168(*(undefined (*) [16])(iVar12 + 0x40), 0);
                if ((((int32_t)((uint64_t)*(undefined8 *)(iVar12 + 0x48) >> 0x20) < iVar17) || (iVar17 < 0)) ||
                   ((int32_t)var_70h._4_4_ <= iVar17)) {
                    uVar16 = 0;
                } else {
                    uVar16 = *(uint8_t *)(iVar17 + var_78h);
                }
                var_70h._0_4_ = var_70h._4_4_;
                if ((int32_t)(uint32_t)uVar16 <= (int32_t)var_70h._4_4_) {
                    var_70h._0_4_ = (uint32_t)uVar16;
                }
                func_0x00018011fd30(&var_48h, &var_78h);
                puVar13 = (undefined4 *)func_0x00018011fd30(&var_48h, &var_78h);
                var_58h._0_4_ = *puVar13;
                var_58h._4_4_ = puVar13[1];
                var_50h._0_4_ = puVar13[2];
                var_50h._4_4_ = puVar13[3];
                piVar14 = (int64_t *)func_0x000180120180(&var_48h, &var_58h, 0);
                var_88h = *piVar14;
                var_80h = piVar14[1];
                func_0x00018011fd30(&var_48h, &var_78h);
                puVar13 = (undefined4 *)func_0x00018011fd30(&var_48h, &var_78h);
                uVar10 = puVar13[1];
                uVar24 = puVar13[2];
                uVar5 = puVar13[3];
                *(undefined4 *)(iVar12 + 0x60) = *puVar13;
                *(undefined4 *)(iVar12 + 100) = uVar10;
                *(undefined4 *)(iVar12 + 0x68) = uVar24;
                *(undefined4 *)(iVar12 + 0x6c) = uVar5;
                func_0x000180120020(&var_88h, 0x11, 1, &var_10h);
                func_0x000180120020(&var_88h, 0x106, 1, &var_20h);
                func_0x000180120020(&var_88h, 0x124, 1, &var_98h);
                func_0x000180120020(&var_88h, 0x125, 1, (int64_t)&var_98h + 4);
                var_48h._0_4_ = (int32_t)var_88h;
                var_48h._4_4_ = var_88h._4_4_;
                uStack_40 = (undefined4)var_80h;
                uStack_3c = var_80h._4_4_;
                var_58h._0_4_ = (undefined4)var_78h;
                var_58h._4_4_ = var_78h._4_4_;
                var_50h._0_4_ = (uint32_t)var_70h;
                var_50h._4_4_ = var_70h._4_4_;
                var_18h._0_4_ = 0;
                var_88h = 0;
                uVar10 = (undefined4)var_78h;
                uVar24 = var_78h._4_4_;
                iVar9 = var_70h._4_4_;
                func_0x000180120020(&var_48h, 0x12, 2);
                iVar21 = var_88h;
                iVar17 = var_88h._4_4_;
                iVar20 = (int64_t)var_88h._4_4_;
                if ((var_88h._4_4_ == 0) || (iVar6 = (int32_t)var_88h, (int32_t)var_88h == 0)) {
code_r0x00018012c0fd:
                    var_68h = 0;
                    var_60h = 0;
                } else {
                    var_88h = 0;
                    var_80h = 0;
                    if (((-1 < iVar21) && ((-1 < iVar6 && (iVar17 <= iVar9)))) && (iVar6 <= iVar9 - iVar17)) {
                        var_80h = iVar21 << 0x20;
                        var_88h = CONCAT44(uVar24, uVar10) + iVar20;
                    }
                    var_48h._0_4_ = (int32_t)var_88h;
                    var_48h._4_4_ = var_88h._4_4_;
                    uStack_40 = 0;
                    uStack_3c = var_80h._4_4_;
                    func_0x000180120020(&var_48h, 0x13, 1);
                    if ((int32_t)var_18h == 0) goto code_r0x00018012c0fd;
                    var_50h._0_4_ = (int32_t)var_18h + iVar17;
                    if ((iVar9 < (int32_t)var_50h) || ((int32_t)var_50h < 0)) {
                        var_50h._0_4_ = iVar9;
                    }
                    func_0x00018011fd30(&var_68h, &var_58h);
                }
                iVar17 = var_98h._4_4_;
                *(undefined4 *)(iVar12 + 0x70) = (undefined4)var_68h;
                *(undefined4 *)(iVar12 + 0x74) = var_68h._4_4_;
                *(undefined4 *)(iVar12 + 0x78) = (undefined4)var_60h;
                *(undefined4 *)(iVar12 + 0x7c) = var_60h._4_4_;
                if (((int32_t)var_20h != 2) || ((int32_t)var_10h == 0)) goto code_r0x00018012bea0;
                if ((int32_t)var_98h != 0) {
                    iVar21 = (int64_t)var_98h._4_4_;
                    if (var_98h._4_4_ == 0) goto code_r0x00018012bea0;
                    if (iVar9 < (int32_t)var_98h) {
code_r0x00018012c143:
                        var_70h._0_4_ = iVar9;
                    } else {
                        var_70h._0_4_ = (int32_t)var_98h;
                        if ((int32_t)var_98h < 0) goto code_r0x00018012c143;
                    }
                    puVar13 = (undefined4 *)func_0x00018011fd30(&var_48h, &var_78h);
                    uVar10 = puVar13[1];
                    uVar24 = puVar13[2];
                    uVar5 = puVar13[3];
                    var_88h = 0;
                    var_80h = 0;
                    *(undefined4 *)(iVar12 + 0x80) = *puVar13;
                    *(undefined4 *)(iVar12 + 0x84) = uVar10;
                    *(undefined4 *)(iVar12 + 0x88) = uVar24;
                    *(undefined4 *)(iVar12 + 0x8c) = uVar5;
                    if ((((-1 < iVar17) && (uVar11 = var_70h._4_4_ - iVar17, -1 < (int32_t)uVar11)) &&
                        (iVar17 <= (int32_t)var_70h._4_4_)) && ((int32_t)uVar11 <= (int32_t)(var_70h._4_4_ - iVar17))) {
                        var_80h = (uint64_t)uVar11 << 0x20;
                        var_88h = iVar21 + var_78h;
                    }
                    *(int32_t *)(iVar12 + 0x90) = (int32_t)var_88h;
                    *(int32_t *)(iVar12 + 0x94) = var_88h._4_4_;
                    *(undefined4 *)(iVar12 + 0x98) = 0;
                    *(undefined4 *)(iVar12 + 0x9c) = var_80h._4_4_;
                    iVar9 = var_70h._4_4_;
                }
                if (iVar9 < (int32_t)var_10h) {
code_r0x00018012c1b0:
                    var_70h._0_4_ = iVar9;
                } else {
                    var_70h._0_4_ = (int32_t)var_10h;
                    if ((int32_t)var_10h < 0) goto code_r0x00018012c1b0;
                }
                puVar13 = (undefined4 *)func_0x00018011fd30(&var_48h, &var_78h);
                uVar10 = puVar13[1];
                uVar24 = puVar13[2];
                uVar5 = puVar13[3];
                *(undefined4 *)(iVar12 + 0x50) = *puVar13;
                *(undefined4 *)(iVar12 + 0x54) = uVar10;
                *(undefined4 *)(iVar12 + 0x58) = uVar24;
                *(undefined4 *)(iVar12 + 0x5c) = uVar5;
            } else if (iVar17 == 0) goto code_r0x00018012bea0;
            uVar11 = func_0x0001801202d0(pcVar4, iVar19, 0x180645474);
            if (uVar11 == 0) {
                iVar17 = 0xffff;
            } else {
                iVar17 = (uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 5] +
                         (uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 4] * 0x100;
            }
            *(int32_t *)(iVar12 + 0x14) = iVar17;
            iVar17 = 0;
            *(undefined4 *)(iVar12 + 0x34) = 0xffffffff;
            uVar16 = pcVar4[(uint64_t)uVar8 + 2];
            uVar3 = pcVar4[(uint64_t)uVar8 + 3];
            *(undefined4 *)(iVar12 + 0x38) = 0;
            iVar19 = (uint32_t)uVar3 + (uint32_t)uVar16 * 0x100;
            if (iVar19 != 0) {
                do {
                    uVar11 = uVar8 + 4 + iVar17 * 8;
                    iVar9 = (uint32_t)(uint8_t)pcVar4[uVar11] * 0x100 + (uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 1];
                    if ((iVar9 == 0) ||
                       ((iVar9 == 3 &&
                        ((iVar9 = (uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 3] +
                                  (uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 2] * 0x100, iVar9 == 1 || (iVar9 == 10)))
                        ))) {
                        *(uint32_t *)(iVar12 + 0x38) =
                             (uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 7] +
                             ((uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 6] +
                             ((uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 5] +
                             (uint32_t)(uint8_t)pcVar4[(uint64_t)uVar11 + 4] * 0x100) * 0x100) * 0x100 + uVar8;
                    }
                    iVar17 = iVar17 + 1;
                } while (iVar17 < iVar19);
            }
            if (*(int32_t *)(iVar12 + 0x38) != 0) {
                *(uint32_t *)(iVar12 + 0x3c) =
                     (uint32_t)(uint8_t)pcVar4[(int64_t)*(int32_t *)(iVar12 + 0x1c) + 0x33] +
                     (uint32_t)(uint8_t)pcVar4[(int64_t)*(int32_t *)(iVar12 + 0x1c) + 0x32] * 0x100;
                *(int64_t *)(arg2 + 0x90) = iVar12;
                fVar1 = *(float *)(**(int64_t **)(*(int64_t *)(arg2 + 0x80) + 0x28) + 0x3c);
                if ((*(char *)(arg2 + 0x35) != '\0') && (*(float *)(arg2 + 0x3c) == 0.0)) {
                    *(float *)(arg2 + 0x3c) = fVar1;
                }
                iVar20 = (int64_t)*(int32_t *)(iVar12 + 0x24);
                iVar21 = *(int64_t *)(iVar12 + 8);
                iVar7 = (uint16_t)*(uint8_t *)(iVar20 + 6 + iVar21) * 0x100 +
                        (uint16_t)*(uint8_t *)(iVar20 + 7 + iVar21);
                fVar23 = 1.0 / (float)((int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar20 + 4 + iVar21) * 0x100 +
                                                         (uint16_t)*(uint8_t *)(iVar20 + 5 + iVar21)) - (int32_t)iVar7);
                *(float *)(iVar12 + 0xa0) = fVar23;
                if (((*(char *)(arg2 + 0x35) != '\0') && (*(float *)(arg2 + 0x3c) != 0.0)) && (fVar1 != 0.0)) {
                    fVar23 = (*(float *)(arg2 + 0x3c) / fVar1) * fVar23;
                    *(float *)(iVar12 + 0xa0) = fVar23;
                }
                *(float *)(iVar12 + 0xa0) = fVar23 * *(float *)(arg2 + 0x74);
                return CONCAT71((unkuint7)(unkuint3)(unkint3)(char)((uint16_t)iVar7 >> 8), 1);
            }
        }
code_r0x00018012bea0:
        func_0x000180460d90(iVar12);
        pcVar15 = *(code **)(*(int64_t *)0x180781f28 + 0x2a40);
        if (pcVar15 == (code *)0x0) goto code_r0x00018012c3bf;
        uVar18 = 0x1806456a0;
    } else {
code_r0x00018012bc93:
        if (cVar2 == 't') {
            if (pcVar4[1] != 'y') goto code_r0x00018012bcee;
            if (pcVar4[2] != 'p') goto code_r0x00018012c38f;
            bVar22 = pcVar4[3] == '1';
code_r0x00018012bd02:
            if (bVar22) goto code_r0x00018012bd08;
        } else {
            if (cVar2 == 'O') {
                if ((pcVar4[1] != 'T') || (pcVar4[2] != 'T')) goto code_r0x00018012c38f;
                if (pcVar4[3] == 'O') goto code_r0x00018012bd08;
            }
            if (cVar2 == '\0') {
                if ((pcVar4[1] != '\x01') || (pcVar4[2] != '\0')) goto code_r0x00018012c38f;
                if (pcVar4[3] == '\0') goto code_r0x00018012bd08;
            }
            if (cVar2 != 't') goto code_r0x00018012c38f;
code_r0x00018012bcee:
            if (pcVar4[1] == 'r') {
                if (pcVar4[2] == 'u') {
                    bVar22 = pcVar4[3] == 'e';
                    goto code_r0x00018012bd02;
                }
            } else if ((((pcVar4[1] == 't') && (pcVar4[2] == 'c')) && (pcVar4[3] == 'f')) &&
                      ((((uint32_t)(uint8_t)pcVar4[5] * 0x10000 + (uint32_t)(uint8_t)pcVar4[6] * 0x100 +
                         (uint32_t)(uint8_t)pcVar4[4] * 0x1000000 + ((uint8_t)pcVar4[7] - 0x10000) & 0xfffeffff) == 0 &&
                       (iVar17 < (int32_t)((((uint32_t)(uint8_t)pcVar4[8] * 0x100 + (uint32_t)(uint8_t)pcVar4[9]) *
                                            0x100 + (uint32_t)(uint8_t)pcVar4[10]) * 0x100 +
                                          (uint32_t)(uint8_t)pcVar4[0xb]))))) {
                iVar21 = (int64_t)(iVar17 * 4);
                iVar19 = (uint32_t)(uint8_t)pcVar4[iVar21 + 0xd] * 0x10000 +
                         (uint32_t)(uint8_t)pcVar4[iVar21 + 0xe] * 0x100 +
                         (uint32_t)(uint8_t)pcVar4[iVar21 + 0xc] * 0x1000000 + (uint32_t)(uint8_t)pcVar4[iVar21 + 0xf];
                goto code_r0x00018012bdb3;
            }
        }
code_r0x00018012c38f:
        if (iVar12 != 0) {
            func_0x000180460d90(iVar12, iVar17);
        }
        pcVar15 = *(code **)(*(int64_t *)0x180781f28 + 0x2a40);
        if (pcVar15 == (code *)0x0) goto code_r0x00018012c3bf;
        uVar18 = 0x180645640;
    }
    pcVar15 = (code *)(*pcVar15)(*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), uVar18);
code_r0x00018012c3bf:
    return (uint64_t)pcVar15 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18012c3e0
// Address: 0x18012c3e0
// Size: 60 bytes
// ============================================================
void fcn.18012c3e0(undefined8 placeholder_0, int64_t arg2)
{
    if (*(int64_t *)(arg2 + 0x90) != 0) {
        fcn.180460d90();
        *(undefined8 *)(arg2 + 0x90) = 0;
        return;
    }
    *(undefined8 *)(arg2 + 0x90) = 0;
    return;
}

// ============================================================
// Function: FUN_18012c420
// Address: 0x18012c420
// Size: 30 bytes
// ============================================================
bool fcn.18012c420(undefined8 placeholder_0, int64_t arg2)
{
    int32_t iVar1;
    undefined2 in_R8W;
    
    iVar1 = fcn.180120380(*(undefined8 *)(arg2 + 0x90), in_R8W);
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_18012c440
// Address: 0x18012c440
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18012c440(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    float fVar8;
    int64_t var_8h;
    int64_t var_18h;
    
    if (*(char *)(arg2 + 0x35) == '\0') {
        iVar3 = *(int64_t *)(arg2 + 0x90);
        iVar6 = (int64_t)*(int32_t *)(iVar3 + 0x24);
        iVar4 = *(int64_t *)(iVar3 + 8);
        fVar8 = (*(float *)(iVar3 + 0xa0) * *(float *)(arg3 + 0x14)) / *(float *)(arg2 + 0x74);
        uVar1 = *(uint8_t *)(iVar6 + 6 + iVar4);
        uVar2 = *(uint8_t *)(iVar6 + 7 + iVar4);
        uVar7 = func_0x000180471c90((float)(int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar6 + 4 + iVar4) * 0x100 +
                                                             (uint16_t)*(uint8_t *)(iVar6 + 5 + iVar4)) * fVar8);
        *(undefined4 *)(arg3 + 0x44) = uVar7;
        fVar8 = (float)(int32_t)(int16_t)((uint16_t)uVar1 * 0x100 + (uint16_t)uVar2) * fVar8;
        iVar5 = (int32_t)fVar8;
        if ((fVar8 < 0.0) && ((float)iVar5 != fVar8)) {
            iVar5 = iVar5 + -1;
        }
        *(float *)(arg3 + 0x48) = (float)iVar5;
    }
    return 1;
}

// ============================================================
// Function: FUN_18012c460
// Address: 0x18012c460
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18012c440(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    float fVar8;
    int64_t var_8h;
    int64_t var_18h;
    
    if (*(char *)(arg2 + 0x35) == '\0') {
        iVar3 = *(int64_t *)(arg2 + 0x90);
        iVar6 = (int64_t)*(int32_t *)(iVar3 + 0x24);
        iVar4 = *(int64_t *)(iVar3 + 8);
        fVar8 = (*(float *)(iVar3 + 0xa0) * *(float *)(arg3 + 0x14)) / *(float *)(arg2 + 0x74);
        uVar1 = *(uint8_t *)(iVar6 + 6 + iVar4);
        uVar2 = *(uint8_t *)(iVar6 + 7 + iVar4);
        uVar7 = func_0x000180471c90((float)(int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar6 + 4 + iVar4) * 0x100 +
                                                             (uint16_t)*(uint8_t *)(iVar6 + 5 + iVar4)) * fVar8);
        *(undefined4 *)(arg3 + 0x44) = uVar7;
        fVar8 = (float)(int32_t)(int16_t)((uint16_t)uVar1 * 0x100 + (uint16_t)uVar2) * fVar8;
        iVar5 = (int32_t)fVar8;
        if ((fVar8 < 0.0) && ((float)iVar5 != fVar8)) {
            iVar5 = iVar5 + -1;
        }
        *(float *)(arg3 + 0x48) = (float)iVar5;
    }
    return 1;
}

// ============================================================
// Function: FUN_18012c4ec
// Address: 0x18012c4ec
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18012c440(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    float fVar8;
    int64_t var_8h;
    int64_t var_18h;
    
    if (*(char *)(arg2 + 0x35) == '\0') {
        iVar3 = *(int64_t *)(arg2 + 0x90);
        iVar6 = (int64_t)*(int32_t *)(iVar3 + 0x24);
        iVar4 = *(int64_t *)(iVar3 + 8);
        fVar8 = (*(float *)(iVar3 + 0xa0) * *(float *)(arg3 + 0x14)) / *(float *)(arg2 + 0x74);
        uVar1 = *(uint8_t *)(iVar6 + 6 + iVar4);
        uVar2 = *(uint8_t *)(iVar6 + 7 + iVar4);
        uVar7 = func_0x000180471c90((float)(int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar6 + 4 + iVar4) * 0x100 +
                                                             (uint16_t)*(uint8_t *)(iVar6 + 5 + iVar4)) * fVar8);
        *(undefined4 *)(arg3 + 0x44) = uVar7;
        fVar8 = (float)(int32_t)(int16_t)((uint16_t)uVar1 * 0x100 + (uint16_t)uVar2) * fVar8;
        iVar5 = (int32_t)fVar8;
        if ((fVar8 < 0.0) && ((float)iVar5 != fVar8)) {
            iVar5 = iVar5 + -1;
        }
        *(float *)(arg3 + 0x48) = (float)iVar5;
    }
    return 1;
}

// ============================================================
// Function: FUN_18012c510
// Address: 0x18012c510
// Size: 1010 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_40ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_400h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_414h
// WARNING: [rz-ghidra] Detected overlap for variable var_408h
// WARNING: [rz-ghidra] Detected overlap for variable var_418h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18012c510(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined auVar5 [12];
    int32_t iVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    float *pfVar14;
    int64_t iVar15;
    undefined *puVar16;
    undefined8 *puVar17;
    int64_t *******pppppppiVar18;
    uint8_t uVar19;
    int64_t *******pppppppiVar20;
    int64_t *******pppppppiVar21;
    uint32_t uVar22;
    int64_t iVar23;
    uint32_t *puVar24;
    int64_t iVar25;
    undefined8 *puVar26;
    uint8_t *puVar27;
    uint8_t *puVar28;
    int64_t *******pppppppiVar29;
    float *pfVar30;
    uint64_t uVar31;
    uint32_t *puVar32;
    int16_t iVar33;
    int64_t iVar34;
    int32_t iVar35;
    uint64_t uVar36;
    int32_t iVar37;
    uint32_t uVar38;
    int32_t iVar39;
    uint32_t uVar40;
    int32_t iVar41;
    undefined *puVar42;
    int32_t iVar43;
    int64_t *******pppppppiVar44;
    float *pfVar45;
    uint32_t uVar46;
    float fVar47;
    undefined4 uVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    float fVar53;
    float fVar54;
    undefined auVar55 [12];
    float fVar56;
    float fVar57;
    float fVar58;
    float fVar59;
    undefined auVar60 [16];
    float fVar61;
    float fVar62;
    float fVar63;
    float fVar64;
    float fVar65;
    float fVar66;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_478 [32];
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_440h;
    int64_t var_438h;
    int64_t var_430h;
    int64_t var_428h;
    int64_t var_420h;
    undefined4 in_stack_fffffffffffffbe8;
    undefined4 in_stack_fffffffffffffbec;
    int64_t var_410h;
    int32_t var_408h;
    int64_t var_404h;
    int64_t var_3fch;
    int64_t iStack_3e8;
    int32_t iStack_3e0;
    undefined4 in_stack_fffffffffffffc34;
    int64_t in_stack_fffffffffffffc38;
    int32_t iStack_3c0;
    int32_t iStack_3b8;
    int32_t iStack_3b4;
    int64_t *******pppppppiStack_3b0;
    float *pfStack_3a8;
    undefined8 uStack_3a0;
    undefined auStack_398 [16];
    undefined auStack_388 [8];
    int32_t iStack_380;
    int32_t iStack_37c;
    undefined8 uStack_378;
    undefined4 uStack_370;
    uint32_t uStack_368;
    undefined8 *puStack_360;
    int64_t iStack_358;
    int64_t iStack_350;
    int64_t iStack_348;
    undefined *puStack_340;
    float *pfStack_338;
    uint32_t *puStack_330;
    int64_t iStack_328;
    int64_t iStack_320;
    undefined *puStack_318;
    int64_t iStack_310;
    float *pfStack_308;
    int64_t iStack_300;
    undefined auStack_2f8 [528];
    undefined8 uStack_e8;
    uint64_t uStack_e0;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_ch;
    
    uStack_e0 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_478;
    iVar12 = *(int64_t *)(arg2 + 0x90);
    puStack_330 = (uint32_t *)arg_30h;
    pfStack_3a8 = (float *)arg_38h;
    iStack_350 = arg1;
    iStack_328 = arg2;
    iStack_300 = arg3;
    iVar6 = fcn.180120380(iVar12, arg_28h & 0xffff);
    if (iVar6 == 0) goto code_r0x00018012e7ec;
    var_410h._0_4_ = (uint32_t)*(char *)(arg2 + 0x37);
    if (*(char *)(arg2 + 0x37) == '\0') {
        if ((36.0 < *(float *)(arg3 + 0x18) * *(float *)(arg3 + 0x14) * *(float *)(arg2 + 0x70)) ||
           (*(char *)(arg2 + 0x36) != '\0')) {
            var_410h._0_4_ = 1;
        } else {
            var_410h._0_4_ = 2;
        }
    }
    uVar7 = (uint32_t)*(char *)(arg2 + 0x38);
    if (*(char *)(arg2 + 0x38) == '\0') {
        uVar7 = 1;
    }
    fVar56 = *(float *)(arg3 + 0x14) * *(float *)(iVar12 + 0xa0);
    fVar58 = *(float *)(arg3 + 0x18) * *(float *)(arg2 + 0x70);
    fVar62 = (float)(uint32_t)var_410h;
    fVar47 = fVar56 * fVar58;
    fVar61 = (float)uVar7;
    fVar64 = fVar62 * fVar47;
    fVar47 = fVar61 * fVar47;
    iVar9 = 0;
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        uVar46 = (uint32_t)var_410h;
        iVar43 = func_0x000180120730(iVar12, iVar6);
        if (-1 < iVar43) {
            iVar34 = *(int64_t *)(iVar12 + 8);
            iVar15 = (int64_t)iVar43;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 3 + iVar15) +
                                      (uint16_t)*(uint8_t *)(iVar34 + 2 + iVar15) * 0x100);
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 4 + iVar15) * 0x100 +
                                       (uint16_t)*(uint8_t *)(iVar34 + 5 + iVar15));
            iVar37 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 7 + iVar15) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 6 + iVar15) * 0x100);
            iVar39 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 9 + iVar15) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 8 + iVar15) * 0x100);
            goto code_r0x00018012c74a;
        }
        iVar39 = 0;
        iVar37 = 0;
        iVar43 = iVar9;
    } else {
        uStack_3a0 = 1;
        auStack_398._0_12_ = ZEXT812(0);
        auStack_398._12_4_ = 0;
        uStack_378 = 0;
        _auStack_388 = ZEXT816(0);
        uStack_370 = 0;
        iVar8 = func_0x000180121980(iVar12, iVar6, &uStack_3a0);
        iVar37 = 0;
        iVar43 = 0;
        if (iVar8 != 0) {
            iVar37 = auStack_388._4_4_;
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_380;
        }
        iVar39 = 0;
        if (iVar8 != 0) {
            iVar39 = iStack_37c;
        }
code_r0x00018012c74a:
        fVar51 = (float)iVar9 * fVar64 + 0.0;
        iVar8 = (int32_t)fVar51;
        if ((fVar51 < 0.0) && ((float)iVar8 != fVar51)) {
            iVar8 = iVar8 + -1;
        }
        fVar51 = 0.0 - (float)iVar39 * fVar47;
        iVar9 = (int32_t)fVar51;
        if ((fVar51 < 0.0) && ((float)iVar9 != fVar51)) {
            iVar9 = iVar9 + -1;
        }
        iVar39 = (int32_t)(float)iVar9;
        fVar51 = (float)func_0x000180471c90((float)iVar37 * fVar64 + 0.0);
        iVar9 = (int32_t)fVar51;
        fVar51 = (float)func_0x000180471c90(0.0 - (float)iVar43 * fVar47);
        iVar37 = (int32_t)fVar51;
        arg_38h = (int64_t)pfStack_3a8;
        iVar43 = (int32_t)(float)iVar8;
        uVar46 = (uint32_t)var_410h;
    }
    iVar15 = iStack_350;
    iVar34 = *(int64_t *)(iVar12 + 8);
    iVar8 = (uint32_t)*(uint8_t *)((int64_t)*(int32_t *)(iVar12 + 0x24) + 0x22 + iVar34) * 0x100 +
            (uint32_t)*(uint8_t *)((int64_t)*(int32_t *)(iVar12 + 0x24) + 0x23 + iVar34);
    if (iVar6 < iVar8) {
        iVar23 = (int64_t)(iVar6 * 4) + (int64_t)*(int32_t *)(iVar12 + 0x28);
        iVar33 = (uint16_t)*(uint8_t *)(iVar23 + iVar34) * 0x100 + (uint16_t)*(uint8_t *)(iVar23 + 1 + iVar34);
    } else {
        iVar23 = (uint64_t)(uint32_t)(iVar8 * 4) + (int64_t)*(int32_t *)(iVar12 + 0x28);
        iVar33 = (uint16_t)*(uint8_t *)(iVar23 + -3 + iVar34) + (uint16_t)*(uint8_t *)(iVar23 + -4 + iVar34) * 0x100;
    }
    fVar56 = (float)(int32_t)iVar33 * fVar56;
    if ((float *)arg_38h != (float *)0x0) {
        *(float *)arg_38h = fVar56;
        goto code_r0x00018012e7ec;
    }
    *puStack_330 = *puStack_330 & 0x3f;
    *puStack_330 = *puStack_330 | (uint32_t)(uint16_t)arg_28h << 6;
    puStack_330[1] = (uint32_t)fVar56;
    if ((iVar43 == iVar9) || (iVar39 == iVar37)) goto code_r0x00018012e7ec;
    uVar40 = (uVar7 - 1) + (iVar37 - iVar39);
    uVar46 = (iVar9 - iVar43) + -1 + uVar46;
    uVar11 = uVar40;
    uStack_368 = fcn.18012ae60(iStack_350, (uint64_t)uVar46, (uint64_t)uVar40, 0, 
                               CONCAT44(in_stack_fffffffffffffbec, in_stack_fffffffffffffbe8), 
                               CONCAT44(in_stack_fffffffffffffc34, uVar40), in_stack_fffffffffffffc38);
    if (uStack_368 == 0xffffffff) goto code_r0x00018012e7ec;
    iVar34 = *(int64_t *)(iVar15 + 0x2b0);
    pfStack_3a8 = *(float **)(iVar34 + 0x68);
    iStack_348 = (int64_t)(*(int32_t *)(*(int64_t *)(iVar34 + 0x78) + (uint64_t)(uStack_368 & 0x7ffff) * 4) << 0xc) >>
                 0xc;
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        iVar9 = func_0x000180120730(iVar12, iVar6);
        if (-1 < iVar9) {
            iVar34 = *(int64_t *)(iVar12 + 8);
            iVar23 = (int64_t)iVar9;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar23 + 2 + iVar34) * 0x100 +
                                      (uint16_t)*(uint8_t *)(iVar23 + 3 + iVar34));
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar23 + 9 + iVar34) +
                                       (uint16_t)*(uint8_t *)(iVar23 + 8 + iVar34) * 0x100);
            goto code_r0x00018012c9d5;
        }
        iStack_3b8 = 0;
        iStack_3b4 = 0;
    } else {
        uStack_3a0 = 1;
        auStack_398 = ZEXT816(0);
        uStack_378 = 0;
        _auStack_388 = ZEXT816(0);
        uStack_370 = 0;
        iVar37 = func_0x000180121980(iVar12, iVar6, &uStack_3a0);
        iVar9 = 0;
        iVar43 = 0;
        if (iVar37 != 0) {
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_37c;
        }
code_r0x00018012c9d5:
        fVar56 = (float)iVar9 * fVar64 + 0.0;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3b8 = (int32_t)(float)iVar9;
        fVar56 = 0.0 - (float)iVar43 * fVar47;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3b4 = (int32_t)(float)iVar9;
    }
    iVar34 = *(int64_t *)(iVar15 + 0x2b0);
    func_0x00018011f640(iVar34 + 0x80, uVar40 * uVar46);
    puVar27 = *(uint8_t **)(iVar34 + 0x88);
    func_0x0001804986e0(puVar27, 0, (int64_t)(int32_t)(uVar40 * uVar46));
    iVar6 = func_0x000180122810(iVar12, iVar6);
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        iVar9 = func_0x000180120730(iVar12);
        if (-1 < iVar9) {
            iVar12 = *(int64_t *)(iVar12 + 8);
            iVar34 = (int64_t)iVar9;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 3 + iVar12) +
                                      (uint16_t)*(uint8_t *)(iVar34 + 2 + iVar12) * 0x100);
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 9 + iVar12) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 8 + iVar12) * 0x100);
            goto code_r0x00018012cb2f;
        }
        iStack_3c0 = 0;
        iStack_3e0 = 0;
    } else {
        auStack_398 = ZEXT816(0);
        uStack_3a0 = 1;
        _auStack_388 = ZEXT816(0);
        uStack_378 = 0;
        uStack_370 = 0;
        iVar37 = func_0x000180121980();
        iVar9 = 0;
        iVar43 = 0;
        if (iVar37 != 0) {
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_37c;
        }
code_r0x00018012cb2f:
        fVar56 = (float)iVar9 * fVar64 + 0.0;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3c0 = (int32_t)(float)iVar9;
        fVar56 = 0.0 - (float)iVar43 * fVar47;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3e0 = (int32_t)(float)iVar9;
    }
    iVar9 = uVar40 - uVar7;
    iVar43 = uVar46 - (uint32_t)var_410h;
    if (iVar43 != -1) {
        uStack_e8 = CONCAT44(uStack_e8._4_4_, iVar9 + 1);
        if (iVar9 + 1 != 0) {
            uVar10 = 0;
            iVar37 = 0;
            uVar31 = 0;
            uVar40 = 0;
            fVar56 = fVar47;
            if (fVar64 <= fVar47) {
                fVar56 = fVar64;
            }
            if (0 < iVar6) {
                do {
                    uVar40 = uVar10 + 1;
                    if (*(char *)(uVar31 * 0xe + 0xc + stack0xfffffffffffffc08) != '\x01') {
                        uVar40 = uVar10;
                    }
                    uVar22 = (int32_t)uVar31 + 1;
                    uVar31 = (uint64_t)uVar22;
                    uVar10 = uVar40;
                } while ((int32_t)uVar22 < iVar6);
            }
            if ((uVar40 != 0) && (iVar12 = func_0x00018046d050((int64_t)(int32_t)uVar40 * 4), iVar12 != 0)) {
                iVar34 = 0;
                iStack_3e8 = 0;
                var_408h = 0;
                fVar56 = (0.35 / fVar56) * (0.35 / fVar56);
                do {
                    if ((var_408h == 1) && (iStack_3e8 = func_0x00018046d050((int64_t)iVar37 << 3), iStack_3e8 == 0)) {
                        fcn.180460d90(0);
                        goto code_r0x00018012cf0c;
                    }
                    iVar37 = 0;
                    iVar41 = 0;
                    iVar39 = 0;
                    iVar8 = -1;
                    if (0 < iVar6) {
                        iVar23 = 0;
                        iVar15 = stack0xfffffffffffffc08;
                        do {
                            iVar25 = iVar23 * 0xe;
                            cVar2 = *(char *)(iVar25 + 0xc + iVar15);
                            if (cVar2 == '\x01') {
                                if (-1 < iVar8) {
                                    *(int32_t *)(iVar12 + (int64_t)iVar8 * 4) = iVar37 - (int32_t)iVar34;
                                }
                                iVar8 = iVar8 + 1;
                                iVar34 = (int64_t)iVar37;
                                iVar33 = *(int16_t *)(iVar25 + 2 + iVar15);
                                iVar37 = iVar37 + 1;
                                iVar39 = iVar37;
                                if (iStack_3e8 != 0) {
                                    *(float *)(iStack_3e8 + iVar34 * 8) = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                    *(float *)(iStack_3e8 + 4 + iVar34 * 8) = (float)(int32_t)iVar33;
                                }
                            } else if (cVar2 == '\x02') {
                                iVar33 = *(int16_t *)(iVar25 + 2 + iVar15);
                                iVar13 = (int64_t)iVar37;
                                iVar37 = iVar37 + 1;
                                iVar39 = iVar37;
                                if (iStack_3e8 != 0) {
                                    *(float *)(iStack_3e8 + iVar13 * 8) = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                    *(float *)(iStack_3e8 + 4 + iVar13 * 8) = (float)(int32_t)iVar33;
                                }
                            } else if (cVar2 == '\x03') {
                                var_430h._0_4_ = 0.0;
                                var_440h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 2 + iVar15);
                                var_448h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                var_450h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 6 + iVar15);
                                var_458h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 4 + iVar15);
                                var_438h._0_4_ = fVar56;
                                iVar37 = iVar39;
                                func_0x000180122bd0(iStack_3e8);
                                iVar39 = iVar37;
                            } else if (cVar2 == '\x04') {
                                var_420h._0_4_ = 0;
                                var_430h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 2 + iVar15);
                                var_438h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                var_440h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 10 + iVar15);
                                var_448h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 8 + iVar15);
                                var_450h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 6 + iVar15);
                                var_458h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 4 + iVar15);
                                var_428h._0_4_ = fVar56;
                                iVar37 = iVar39;
                                func_0x000180122dd0(iStack_3e8);
                                iVar15 = stack0xfffffffffffffc08;
                                iVar39 = iVar37;
                            }
                            iVar41 = iVar41 + 1;
                            iVar23 = iVar23 + 1;
                        } while (iVar41 < iVar6);
                    }
                    *(int32_t *)(iVar12 + (int64_t)iVar8 * 4) = iVar37 - (int32_t)iVar34;
                    var_408h = var_408h + 1;
                } while (var_408h < 2);
                if (iStack_3e8 != 0) {
                    if (0 < (int32_t)uVar40) {
                        iVar37 = 0;
                        iVar6 = 0;
                        if (7 < uVar40) {
                            uVar10 = uVar40 & 0x80000007;
                            if ((int32_t)uVar10 < 0) {
                                uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                            }
                            do {
                                iVar37 = iVar37 + 8;
                            } while (iVar37 < (int32_t)(uVar40 - uVar10));
                            iVar6 = iVar37;
                            if ((int32_t)uVar40 <= iVar37) goto code_r0x00018012d11d;
                        }
                        if (1 < (int32_t)(uVar40 - iVar6)) {
                            do {
                                iVar6 = iVar6 + 2;
                            } while (iVar6 < (int32_t)(uVar40 - 1));
                        }
                    }
code_r0x00018012d11d:
                    uVar10 = uVar40;
                    iStack_358 = iVar12;
                    pfVar14 = (float *)func_0x00018046d050();
                    pfStack_308 = pfVar14;
                    if (pfVar14 != (float *)0x0) {
                        iVar6 = 0;
                        iVar39 = 0;
                        iVar37 = 0;
                        if (0 < (int32_t)uVar40) {
                            do {
                                iVar34 = iStack_3e8 + (int64_t)iVar39 * 8;
                                iVar8 = *(int32_t *)(iVar12 + (int64_t)iVar37 * 4);
                                iVar39 = iVar39 + iVar8;
                                iVar41 = iVar8 + -1;
                                iVar35 = 0;
                                if (0 < iVar8) {
                                    do {
                                        if (*(float *)(iVar34 + 4 + (int64_t)iVar41 * 8) !=
                                            *(float *)(iVar34 + 4 + (int64_t)iVar35 * 8)) {
                                            iVar15 = (int64_t)iVar6;
                                            pfVar14[iVar15 * 5 + 4] = 0.0;
                                            fVar56 = *(float *)(iVar34 + 4 + (int64_t)iVar41 * 8);
                                            pfVar30 = (float *)(iVar34 + 4 + (int64_t)iVar35 * 8);
                                            iVar8 = iVar35;
                                            if (*pfVar30 <= fVar56 && fVar56 != *pfVar30) {
                                                pfVar14[iVar15 * 5 + 4] = 1.401298e-45;
                                                iVar8 = iVar41;
                                                iVar41 = iVar35;
                                            }
                                            iVar6 = iVar6 + 1;
                                            pfVar14[iVar15 * 5] = fVar64 * *(float *)(iVar34 + (int64_t)iVar8 * 8) + 0.0
                                            ;
                                            pfVar14[iVar15 * 5 + 1] =
                                                 (float)((uint32_t)fVar47 ^ 0x80000000) *
                                                 *(float *)(iVar34 + 4 + (int64_t)iVar8 * 8) + 0.0;
                                            pfVar14[iVar15 * 5 + 2] =
                                                 fVar64 * *(float *)(iVar34 + (int64_t)iVar41 * 8) + 0.0;
                                            pfVar14[iVar15 * 5 + 3] =
                                                 (float)((uint32_t)fVar47 ^ 0x80000000) *
                                                 *(float *)(iVar34 + 4 + (int64_t)iVar41 * 8) + 0.0;
                                        }
                                        iVar8 = iVar35 + 1;
                                        uVar40 = uVar10;
                                        iVar41 = iVar35;
                                        iVar35 = iVar8;
                                    } while (iVar8 < *(int32_t *)(iVar12 + (int64_t)iVar37 * 4));
                                }
                                iVar37 = iVar37 + 1;
                            } while (iVar37 < (int32_t)uVar40);
                        }
                        func_0x000180122a30(pfVar14, iVar6);
                        uVar31 = 1;
                        pppppppiVar29 = (int64_t *******)0x0;
                        if (1 < iVar6) {
                            do {
                                uVar40 = (uint32_t)uVar31;
                                fVar56 = pfVar14[uVar31 * 5];
                                fVar47 = pfVar14[uVar31 * 5 + 1];
                                uVar1 = *(undefined8 *)(pfVar14 + uVar31 * 5 + 2);
                                fVar64 = pfVar14[uVar31 * 5 + 4];
                                if (uVar40 < 4) goto code_r0x00018012d37c;
                                do {
                                    uVar10 = (uint32_t)uVar31;
                                    if (pfVar14[uVar31 * 5 + -4] <= fVar47) goto code_r0x00018012d3b6;
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    fVar57 = pfVar45[1];
                                    fVar59 = pfVar45[2];
                                    fVar53 = pfVar45[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -1];
                                    pfVar30 = pfVar14 + uVar31 * 5;
                                    *pfVar30 = *pfVar45;
                                    pfVar30[1] = fVar57;
                                    pfVar30[2] = fVar59;
                                    pfVar30[3] = fVar53;
                                    pfVar14[uVar31 * 5 + 4] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -9] <= fVar47) {
                                        uVar10 = uVar10 - 1;
                                        goto code_r0x00018012d3b6;
                                    }
                                    pfVar30 = pfVar14 + uVar31 * 5 + -10;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -6];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -1] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -0xe] <= fVar47) {
                                        uVar10 = uVar10 - 2;
                                        goto code_r0x00018012d3b6;
                                    }
                                    pfVar30 = pfVar14 + uVar31 * 5 + -0xf;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -0xb];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -10;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -6] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -0x13] <= fVar47) {
                                        uVar10 = uVar10 - 3;
                                        goto code_r0x00018012d3b6;
                                    }
                                    fVar51 = pfVar14[uVar31 * 5 + -0x10];
                                    uVar10 = uVar10 - 4;
                                    pfVar30 = pfVar14 + uVar31 * 5 + -0x14;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -0xf;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -0xb] = fVar51;
                                    uVar31 = (uint64_t)uVar10;
                                } while (3 < (int32_t)uVar10);
                                while (0 < (int32_t)uVar10) {
code_r0x00018012d37c:
                                    uVar10 = (uint32_t)uVar31;
                                    if (pfVar14[uVar31 * 5 + -4] <= fVar47) break;
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    fVar57 = pfVar45[1];
                                    fVar59 = pfVar45[2];
                                    fVar53 = pfVar45[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -1];
                                    uVar10 = uVar10 - 1;
                                    pfVar30 = pfVar14 + uVar31 * 5;
                                    *pfVar30 = *pfVar45;
                                    pfVar30[1] = fVar57;
                                    pfVar30[2] = fVar59;
                                    pfVar30[3] = fVar53;
                                    pfVar14[uVar31 * 5 + 4] = fVar51;
                                    uVar31 = (uint64_t)uVar10;
                                }
code_r0x00018012d3b6:
                                if (uVar40 != uVar10) {
                                    iVar12 = (int64_t)(int32_t)uVar10;
                                    *(undefined8 *)(pfVar14 + iVar12 * 5 + 2) = uVar1;
                                    pfVar14[iVar12 * 5 + 4] = fVar64;
                                    pfVar14[iVar12 * 5 + 1] = fVar47;
                                    pfVar14[iVar12 * 5] = fVar56;
                                }
                                uVar31 = (uint64_t)(uVar40 + 1);
                            } while ((int32_t)(uVar40 + 1) < iVar6);
                        }
                        puStack_360 = (undefined8 *)0x0;
                        uVar40 = 0;
                        pppppppiStack_3b0 = (int64_t *******)0x0;
                        var_408h = 0;
                        iVar37 = iVar43 + 1;
                        pfStack_338 = pfVar14;
                        if (iVar37 < 0x41) {
                            puVar16 = auStack_2f8;
                        } else {
                            puVar16 = (undefined *)func_0x00018046d050((int64_t)(iVar37 * 2 + 1) << 2);
                        }
                        iStack_310 = (int64_t)iVar37 * 4;
                        puVar42 = puVar16 + iStack_310;
                        pfVar14[(int64_t)iVar6 * 5 + 1] = (float)(iStack_3e0 + (int32_t)uStack_e8) + 1.0;
                        puVar26 = puStack_360;
                        puStack_340 = puVar16;
                        puStack_318 = puVar42;
                        pfVar30 = pfVar14;
                        if (0 < (int32_t)uStack_e8) {
                            iStack_320 = (int64_t)(iVar43 + 2) << 2;
                            iVar37 = 0;
                            pppppppiVar44 = pppppppiVar29;
                            pppppppiVar21 = pppppppiVar29;
                            auVar60 = *(undefined (*) [16])0x180646c10;
                            iVar6 = iStack_3e0;
                            do {
                                fVar47 = (float)iVar6 + 1.0;
                                fVar56 = (float)iVar6 + 0.0;
                                func_0x0001804986e0(puVar16, 0, iStack_310);
                                func_0x0001804986e0(puVar42, 0, iStack_320);
                                pppppppiVar20 = pppppppiVar21;
                                if (pppppppiVar21 != (int64_t *******)0x0) {
                                    pppppppiVar18 = (int64_t *******)&pppppppiStack_3b0;
                                    do {
                                        pppppppiVar20 = pppppppiVar21;
                                        if (*(float *)((int64_t)pppppppiVar21 + 0x1c) <= fVar56) {
                                            *pppppppiVar18 = *pppppppiVar21;
                                            *pppppppiVar21 = (int64_t ******)pppppppiVar44;
                                            *(undefined4 *)((int64_t)pppppppiVar21 + 0x14) = 0;
                                            pppppppiVar20 = pppppppiVar18;
                                            pppppppiVar44 = pppppppiVar21;
                                        }
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar20;
                                        pppppppiVar18 = pppppppiVar20;
                                        pppppppiVar20 = pppppppiStack_3b0;
                                    } while (pppppppiVar21 != (int64_t *******)0x0);
                                }
                                puVar26 = puStack_360;
                                if (pfVar14[1] <= fVar47) {
                                    do {
                                        iVar39 = (int32_t)pppppppiVar29;
                                        if (pfVar14[1] != pfVar14[3]) {
                                            puVar17 = puVar26;
                                            if (pppppppiVar44 == (int64_t *******)0x0) {
                                                if (iVar39 == 0) {
                                                    puVar17 = (undefined8 *)func_0x00018046d050(0x6408);
                                                    if (puVar17 == (undefined8 *)0x0) goto code_r0x00018012d652;
                                                    *puVar17 = puVar26;
                                                    iVar39 = 800;
                                                }
                                                pppppppiVar29 = (int64_t *******)(uint64_t)(iVar39 - 1U);
                                                pppppppiVar21 =
                                                     (int64_t *******)
                                                     (puVar17 + (int64_t)(int32_t)(iVar39 - 1U) * 4 + 1);
                                                puVar26 = puVar17;
                                                if (pppppppiVar21 == (int64_t *******)0x0) goto code_r0x00018012d652;
                                            } else {
                                                pppppppiVar21 = pppppppiVar44;
                                                pppppppiVar44 = (int64_t *******)*pppppppiVar44;
                                            }
                                            fVar64 = (pfVar14[2] - *pfVar14) / (pfVar14[3] - pfVar14[1]);
                                            *(float *)((int64_t)pppppppiVar21 + 0xc) = fVar64;
                                            if (fVar64 == 0.0) {
                                                fVar51 = 0.0;
                                            } else {
                                                fVar51 = 1.0 / fVar64;
                                            }
                                            *(float *)(pppppppiVar21 + 2) = fVar51;
                                            *(float *)(pppppppiVar21 + 1) =
                                                 ((fVar56 - pfVar14[1]) * fVar64 + *pfVar14) - (float)iStack_3c0;
                                            uVar48 = 0xbf800000;
                                            if (pfVar14[4] != 0.0) {
                                                uVar48 = 0x3f800000;
                                            }
                                            *(undefined4 *)((int64_t)pppppppiVar21 + 0x14) = uVar48;
                                            *(float *)(pppppppiVar21 + 3) = pfVar14[1];
                                            fVar64 = pfVar14[3];
                                            *(float *)((int64_t)pppppppiVar21 + 0x1c) = fVar64;
                                            if (((var_408h == 0) && (iStack_3e0 != 0)) && (fVar64 < fVar56)) {
                                                *(float *)((int64_t)pppppppiVar21 + 0x1c) = fVar56;
                                            }
                                            *pppppppiVar21 = (int64_t ******)pppppppiVar20;
                                            pppppppiStack_3b0 = pppppppiVar21;
                                            puVar26 = puVar17;
                                            pppppppiVar20 = pppppppiVar21;
                                        }
code_r0x00018012d652:
                                        pfVar45 = pfVar14 + 5;
                                        pfVar30 = pfVar14 + 6;
                                        pfVar14 = pfVar45;
                                    } while (*pfVar30 <= fVar47);
                                    puStack_360 = puVar26;
                                    uVar40 = (uint32_t)pppppppiVar29;
                                    pfStack_338 = pfVar45;
                                    puVar16 = puStack_340;
                                    puVar42 = puStack_318;
                                }
                                iVar39 = iVar43 + 1;
                                if (pppppppiVar20 != (int64_t *******)0x0) {
                                    fVar47 = fVar56 + 1.0;
                                    pppppppiVar21 = pppppppiVar20;
                                    do {
                                        fVar64 = *(float *)((int64_t)pppppppiVar21 + 0xc);
                                        fVar51 = *(float *)(pppppppiVar21 + 1);
                                        if (fVar64 == 0.0) {
                                            if (fVar51 < (float)iVar39) {
                                                var_450h._0_4_ = fVar51;
                                                if (fVar51 < 0.0) {
                                                    var_458h._0_4_ = fVar56;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar42);
                                                } else {
                                                    var_458h._0_4_ = fVar56;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar16);
                                                    var_458h._0_4_ = fVar56;
                                                    var_450h._0_4_ = fVar51;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar42);
                                                }
                                            }
                                        } else {
                                            fVar57 = *(float *)(pppppppiVar21 + 3);
                                            fVar65 = fVar64 + fVar51;
                                            fVar59 = fVar56;
                                            fVar53 = fVar51;
                                            if (fVar56 < fVar57) {
                                                fVar59 = fVar57;
                                                fVar53 = (fVar57 - fVar56) * fVar64 + fVar51;
                                            }
                                            fVar57 = *(float *)((int64_t)pppppppiVar21 + 0x1c);
                                            fVar49 = fVar47;
                                            fVar63 = fVar65;
                                            if (fVar57 < fVar47) {
                                                fVar49 = fVar57;
                                                fVar63 = (fVar57 - fVar56) * fVar64 + fVar51;
                                            }
                                            if (((fVar53 < 0.0) || (fVar63 < 0.0)) ||
                                               (((float)iVar39 <= fVar53 || ((float)iVar39 <= fVar63)))) {
                                                uVar31 = 0;
                                                if (0 < iVar39) {
                                                    do {
                                                        uVar10 = (int32_t)uVar31 + 1;
                                                        uVar36 = (uint64_t)uVar10;
                                                        fVar53 = (float)(int32_t)uVar31;
                                                        fVar57 = (float)uVar10;
                                                        fVar49 = (fVar53 - fVar51) / fVar64 + fVar56;
                                                        fVar59 = (fVar57 - fVar51) / fVar64 + fVar56;
                                                        var_450h._0_4_ = fVar53;
                                                        var_448h._0_4_ = fVar49;
                                                        if ((fVar53 <= fVar51) || (fVar65 <= fVar57)) {
                                                            if ((fVar53 <= fVar65) || (fVar51 <= fVar57)) {
                                                                if (((fVar51 < fVar53) && (fVar53 < fVar65)) ||
                                                                   ((fVar65 < fVar53 && (fVar53 < fVar51)))) {
                                                                    var_458h._0_4_ = fVar56;
                                                                    func_0x0001801228f0(puVar16);
                                                                    var_458h._0_4_ = fVar49;
                                                                } else if (((fVar51 < fVar57) && (fVar57 < fVar65)) ||
                                                                          ((var_458h._0_4_ = fVar56, fVar65 < fVar57 &&
                                                                           (fVar57 < fVar51)))) {
                                                                    var_458h._0_4_ = fVar56;
                                                                    var_450h._0_4_ = fVar57;
                                                                    var_448h._0_4_ = fVar59;
                                                                    func_0x0001801228f0(puVar16);
                                                                    var_458h._0_4_ = fVar59;
                                                                }
                                                            } else {
                                                                var_458h._0_4_ = fVar56;
                                                                var_450h._0_4_ = fVar57;
                                                                var_448h._0_4_ = fVar59;
                                                                func_0x0001801228f0(puVar16);
                                                                var_458h._0_4_ = fVar59;
                                                                var_450h._0_4_ = fVar53;
                                                                var_448h._0_4_ = fVar49;
                                                                func_0x0001801228f0();
                                                                var_458h._0_4_ = fVar49;
                                                            }
                                                        } else {
                                                            var_458h._0_4_ = fVar56;
                                                            func_0x0001801228f0(puVar16);
                                                            var_458h._0_4_ = fVar49;
                                                            var_450h._0_4_ = fVar57;
                                                            var_448h._0_4_ = fVar59;
                                                            func_0x0001801228f0();
                                                            var_458h._0_4_ = fVar59;
                                                        }
                                                        var_450h._0_4_ = fVar65;
                                                        var_448h._0_4_ = fVar47;
                                                        func_0x0001801228f0(puVar16);
                                                        uVar31 = uVar36 & 0xffffffff;
                                                    } while ((int32_t)uVar36 < iVar39);
                                                }
                                            } else {
                                                iVar8 = (int32_t)fVar53;
                                                if (iVar8 == (int32_t)fVar63) {
                                                    iVar12 = (int64_t)iVar8;
                                                    fVar64 = (fVar49 - fVar59) *
                                                             *(float *)((int64_t)pppppppiVar21 + 0x14);
                                                    *(float *)(puVar16 + iVar12 * 4) =
                                                         ((((float)iVar8 + 1.0) - fVar63) +
                                                         (((float)iVar8 + 1.0) - fVar53)) * 0.5 * fVar64 +
                                                         *(float *)(puVar16 + iVar12 * 4);
                                                    *(float *)(puVar42 + iVar12 * 4 + 4) =
                                                         fVar64 + *(float *)(puVar42 + iVar12 * 4 + 4);
                                                } else {
                                                    fVar64 = *(float *)(pppppppiVar21 + 2);
                                                    fVar57 = fVar63;
                                                    if (fVar63 < fVar53) {
                                                        fVar51 = fVar49 - fVar56;
                                                        fVar64 = (float)((uint32_t)fVar64 ^ 0x80000000);
                                                        fVar49 = fVar47 - (fVar59 - fVar56);
                                                        fVar59 = fVar47 - fVar51;
                                                        fVar51 = fVar65;
                                                        fVar57 = fVar53;
                                                        fVar53 = fVar63;
                                                    }
                                                    fVar65 = *(float *)((int64_t)pppppppiVar21 + 0x14);
                                                    iVar35 = (int32_t)fVar53;
                                                    iVar41 = (int32_t)fVar57;
                                                    iVar8 = iVar35 + 1;
                                                    fVar66 = (float)iVar41;
                                                    fVar50 = ((float)iVar8 - fVar51) * fVar64 + fVar56;
                                                    fVar63 = (fVar66 - fVar51) * fVar64 + fVar56;
                                                    fVar51 = fVar47;
                                                    if (fVar50 <= fVar47) {
                                                        fVar51 = fVar50;
                                                    }
                                                    fVar50 = (fVar51 - fVar59) * fVar65;
                                                    *(float *)(puVar16 + (int64_t)iVar35 * 4) =
                                                         ((float)iVar8 - fVar53) * fVar50 * 0.5 +
                                                         *(float *)(puVar16 + (int64_t)iVar35 * 4);
                                                    if ((fVar47 < fVar63) &&
                                                       (iVar35 = (iVar41 - iVar35) + -1, fVar63 = fVar47, iVar35 != 0))
                                                    {
                                                        fVar64 = (fVar47 - fVar51) / (float)iVar35;
                                                    }
                                                    if (iVar8 < iVar41) {
                                                        fVar64 = fVar64 * fVar65;
                                                        fVar51 = fVar64 * 0.5;
                                                        if (3 < iVar41 - iVar8) {
                                                            do {
                                                                iVar12 = (int64_t)iVar8;
                                                                iVar8 = iVar8 + 4;
                                                                *(float *)(puVar16 + iVar12 * 4) =
                                                                     fVar50 + fVar51 + *(float *)(puVar16 + iVar12 * 4);
                                                                fVar53 = fVar50 + fVar64 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 4) =
                                                                     fVar51 + fVar50 + fVar64 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 4);
                                                                fVar54 = fVar53 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 8) =
                                                                     fVar51 + fVar53 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 8);
                                                                fVar50 = fVar54 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 0xc) =
                                                                     fVar51 + fVar54 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 0xc);
                                                            } while (iVar8 < iVar41 + -3);
                                                        }
                                                        for (; iVar8 < iVar41; iVar8 = iVar8 + 1) {
                                                            fVar53 = fVar50 + fVar51;
                                                            fVar50 = fVar50 + fVar64;
                                                            *(float *)(puVar16 + (int64_t)iVar8 * 4) =
                                                                 fVar53 + *(float *)(puVar16 + (int64_t)iVar8 * 4);
                                                        }
                                                    }
                                                    iVar12 = (int64_t)iVar41;
                                                    *(float *)(puVar16 + iVar12 * 4) =
                                                         (((fVar66 + 1.0) - fVar57) + ((fVar66 + 1.0) - fVar66)) * 0.5 *
                                                         (fVar49 - fVar63) * fVar65 + fVar50 +
                                                         *(float *)(puVar16 + iVar12 * 4);
                                                    *(float *)(puVar42 + iVar12 * 4 + 4) =
                                                         (fVar49 - fVar59) * fVar65 +
                                                         *(float *)(puVar42 + iVar12 * 4 + 4);
                                                }
                                            }
                                        }
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar21;
                                        auVar60 = *(undefined (*) [16])0x180646c10;
                                    } while (pppppppiVar21 != (int64_t *******)0x0);
                                }
                                iVar8 = 0;
                                auVar52._0_12_ = ZEXT812(0);
                                auVar52._12_4_ = 0;
                                uVar10 = auVar60._0_4_;
                                if (iVar39 < 4) {
                                    if (0 < iVar39) goto code_r0x00018012dce2;
                                } else {
                                    do {
                                        iVar34 = (int64_t)iVar8;
                                        iVar12 = (int64_t)(iVar8 + iVar37);
                                        fVar47 = auVar52._0_4_ + *(float *)(puVar42 + iVar34 * 4);
                                        iVar39 = (int32_t)((float)((uint32_t)(fVar47 + *(float *)(puVar16 + iVar34 * 4))
                                                                  & uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12] = uVar19;
                                        fVar47 = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 4);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (fVar47 + *(float *)(puVar16 + iVar34 * 4 + 4)) &
                                                                  uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12 + 1] = uVar19;
                                        fVar47 = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 8);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (fVar47 + *(float *)(puVar16 + iVar34 * 4 + 8)) &
                                                                  uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12 + 2] = uVar19;
                                        auVar52._0_4_ = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 0xc);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (auVar52._0_4_ +
                                                                   *(float *)(puVar16 + iVar34 * 4 + 0xc)) & uVar10) *
                                                           255.0 + 0.5);
                                        if (0xff < iVar39) {
                                            iVar39 = 0xff;
                                        }
                                        iVar8 = iVar8 + 4;
                                        puVar27[iVar12 + 3] = (uint8_t)iVar39;
                                    } while (iVar8 < iVar43 + -2);
                                    pppppppiVar29 = (int64_t *******)(uint64_t)uVar40;
                                    if (iVar8 < iVar43 + 1) {
code_r0x00018012dce2:
                                        do {
                                            auVar52._0_4_ = auVar52._0_4_ + *(float *)(puVar42 + (int64_t)iVar8 * 4);
                                            iVar39 = iVar37 + iVar8;
                                            iVar41 = (int32_t)((float)((uint32_t)
                                                                       (auVar52._0_4_ +
                                                                       *(float *)(puVar16 + (int64_t)iVar8 * 4)) &
                                                                      uVar10) * 255.0 + 0.5);
                                            if (0xff < iVar41) {
                                                iVar41 = 0xff;
                                            }
                                            iVar8 = iVar8 + 1;
                                            puVar27[iVar39] = (uint8_t)iVar41;
                                        } while (iVar8 < iVar43 + 1);
                                        pppppppiVar29 = (int64_t *******)(uint64_t)uVar40;
                                        pfVar14 = pfStack_338;
                                    }
                                }
                                if (pppppppiVar20 != (int64_t *******)0x0) {
                                    pppppppiVar21 = (int64_t *******)&pppppppiStack_3b0;
                                    pppppppiVar18 = pppppppiVar20;
                                    do {
                                        *(float *)(pppppppiVar18 + 1) =
                                             *(float *)((int64_t)pppppppiVar18 + 0xc) + *(float *)(pppppppiVar18 + 1);
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar21;
                                        pppppppiVar18 = (int64_t *******)*pppppppiVar21;
                                    } while (pppppppiVar18 != (int64_t *******)0x0);
                                }
                                iVar6 = iVar6 + 1;
                                iVar37 = iVar37 + uVar46;
                                var_408h = var_408h + 1;
                                pppppppiVar21 = pppppppiVar20;
                                puVar26 = puStack_360;
                                pfVar30 = pfStack_308;
                            } while (var_408h < (int32_t)uStack_e8);
                        }
                        while (puVar26 != (undefined8 *)0x0) {
                            puVar17 = (undefined8 *)*puVar26;
                            fcn.180460d90(puVar26);
                            puVar26 = puVar17;
                        }
                        if (puVar16 != auStack_2f8) {
                            fcn.180460d90(puVar16);
                        }
                        fcn.180460d90(pfVar30);
                        iVar12 = iStack_358;
                    }
                    fcn.180460d90(iVar12);
                    iVar12 = iStack_3e8;
code_r0x00018012cf0c:
                    fcn.180460d90(iVar12);
                }
            }
        }
    }
    fcn.180460d90(stack0xfffffffffffffc08);
    uVar40 = uVar11;
    puVar28 = puVar27;
    if (1 < (int32_t)(uint32_t)var_410h) {
        iVar6 = 0;
        uStack_e8 = 0;
        if (0 < (int32_t)uVar11) {
            do {
                func_0x0001804986e0(&uStack_e8, 0, (uint32_t)var_410h);
                uVar36 = 0;
                uVar31 = 0;
                if ((uint32_t)var_410h == 2) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 + 2;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 >> 1);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else if ((uint32_t)var_410h == 3) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 + 3;
                            uVar36 = (uint64_t)
                                     ((int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7))));
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar36 / 3);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else if ((uint32_t)var_410h == 4) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 - 4;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 >> 2);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else {
                    uVar10 = 0;
                    uVar31 = uVar36;
                    if ((uint32_t)var_410h == 5) {
                        if (-1 < iVar43) {
                            do {
                                iVar12 = (int64_t)(int32_t)uVar10;
                                iVar34 = (int64_t)(int32_t)uVar10;
                                uVar22 = uVar10 - 3;
                                uVar36 = (uint64_t)
                                         ((int32_t)uVar36 +
                                         ((uint32_t)puVar27[iVar12] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)) = puVar27[iVar12];
                                puVar27[iVar34] = (uint8_t)(uVar36 / 5);
                                uVar31 = uVar36;
                            } while ((int32_t)uVar10 <= iVar43);
                        }
                    } else if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar10;
                            iVar12 = (int64_t)(int32_t)uVar10;
                            uVar22 = uVar10 + (uint32_t)var_410h;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 / (uint32_t)var_410h);
                            uVar31 = uVar36;
                        } while ((int32_t)uVar10 <= iVar43);
                    }
                }
                for (; (int32_t)uVar10 < (int32_t)uVar46; uVar10 = uVar10 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar22 = (int32_t)uVar31 - (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7));
                    puVar27[(int32_t)uVar10] = (uint8_t)(uVar22 / (uint32_t)var_410h);
                    uVar31 = (uint64_t)uVar22;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                puVar27 = puVar27 + (int32_t)uVar46;
                iVar6 = iVar6 + 1;
            } while (iVar6 < (int32_t)uVar11);
        }
    }
    puVar27 = puVar28;
    if (1 < (int32_t)uVar7) {
        iVar6 = 0;
        uStack_e8 = 0;
        if (0 < (int32_t)uVar46) {
            do {
                func_0x0001804986e0(&uStack_e8, 0, uVar7);
                uVar36 = 0;
                uVar31 = 0;
                if (uVar7 == 2) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar22 = (int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar22;
                            uVar11 = uVar10 + 2;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar22 >> 1);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else if (uVar7 == 3) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar36 = (uint64_t)
                                     ((int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                            uVar11 = uVar10 + 3;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar36 / 3);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else if (uVar7 == 4) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar22 = (int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar22;
                            uVar11 = uVar10 - 4;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar22 >> 2);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else {
                    uVar10 = 0;
                    uVar31 = uVar36;
                    if (uVar7 == 5) {
                        uVar11 = 0;
                        if (-1 < iVar9) {
                            do {
                                iVar43 = uVar10 * uVar46;
                                uVar36 = (uint64_t)
                                         ((int32_t)uVar36 +
                                         ((uint32_t)puVar28[iVar43] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                                uVar11 = uVar10 - 3;
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                                puVar28[iVar43] = (uint8_t)(uVar36 / 5);
                                uVar31 = uVar36;
                                uVar11 = uVar10;
                            } while ((int32_t)uVar10 <= iVar9);
                        }
                    } else {
                        uVar11 = uVar10;
                        if (-1 < iVar9) {
                            do {
                                iVar43 = uVar10 * uVar46;
                                uVar22 = (int32_t)uVar36 +
                                         ((uint32_t)puVar28[iVar43] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                                uVar36 = (uint64_t)uVar22;
                                uVar11 = uVar10 + uVar7;
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                                puVar28[iVar43] = (uint8_t)(uVar22 / uVar7);
                                uVar31 = uVar36;
                                uVar11 = uVar10;
                            } while ((int32_t)uVar10 <= iVar9);
                        }
                    }
                }
                for (; (int32_t)uVar11 < (int32_t)uVar40; uVar11 = uVar11 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar10 = (int32_t)uVar31 - (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7));
                    puVar28[(int32_t)(uVar11 * uVar46)] = (uint8_t)(uVar10 / uVar7);
                    uVar31 = (uint64_t)uVar10;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                puVar28 = puVar28 + 1;
                iVar6 = iVar6 + 1;
            } while (iVar6 < (int32_t)uVar46);
        }
    }
    if ((uint32_t)var_410h == 0) {
        fVar47 = 0.0;
    } else {
        fVar47 = (float)(1 - (uint32_t)var_410h) / (fVar62 + fVar62);
    }
    if (uVar7 == 0) {
        fVar56 = 0.0;
    } else {
        fVar56 = (float)(1 - uVar7) / (fVar61 + fVar61);
    }
    fVar64 = *(float *)(**(int64_t **)(*(int64_t *)(iStack_300 + 0x58) + 0x28) + 0x3c);
    if (fVar64 == 0.0) {
        auVar55 = ZEXT812(0x3f800000);
    } else {
        auVar55._4_8_ = 0;
        auVar55._0_4_ = *(float *)(iStack_300 + 0x14) / fVar64;
    }
    auVar5._4_8_ = auVar55._4_8_;
    auVar5._0_4_ = auVar55._0_4_ * *(float *)(iStack_328 + 0x50) + 0.5;
    iVar12 = iStack_300;
    fVar64 = (float)func_0x0001800f4120(auVar5._0_8_);
    fVar64 = fVar64 + fVar47;
    fVar47 = (float)func_0x0001800f4120();
    iVar34 = iStack_348;
    fVar62 = 1.0 / (fVar62 * fVar58);
    fVar47 = fVar47 + (float)(int32_t)(*(float *)(iVar12 + 0x44) + 0.5) + fVar56;
    fVar56 = 1.0 / (fVar61 * fVar58);
    puStack_330[2] = (uint32_t)((float)iStack_3b8 * fVar62 + fVar64);
    puStack_330[3] = (uint32_t)((float)iStack_3b4 * fVar56 + fVar47);
    puStack_330[4] =
         (uint32_t)((float)((uint32_t)*(uint16_t *)(pfStack_3a8 + iStack_348 * 2 + 1) + iStack_3b8) * fVar62 + fVar64);
    uVar3 = *(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 6);
    *puStack_330 = *puStack_330 | 2;
    puStack_330[10] = uStack_368;
    puStack_330[5] = (uint32_t)((float)((uint32_t)uVar3 + iStack_3b4) * fVar56 + fVar47);
    iVar12 = *(int64_t *)(iStack_350 + 0x38);
    uVar3 = *(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 6);
    uVar7 = (uint32_t)uVar3;
    iVar6 = *(int32_t *)(iVar12 + 0x24) * *(int32_t *)(iVar12 + 0x1c);
    uVar4 = *(uint16_t *)(pfStack_3a8 + iStack_348 * 2 + 1);
    puVar32 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 2) *
                                   *(int32_t *)(iVar12 + 0x1c) + (uint32_t)*(uint16_t *)(pfStack_3a8 + iStack_348 * 2))
                                 * *(int32_t *)(iVar12 + 0x24)) + *(int64_t *)(iVar12 + 0x28));
    iStack_348 = iVar12;
    if (*(int32_t *)(iVar12 + 0x18) == 1) {
        if (uVar3 != 0) {
            do {
                func_0x000180498030(puVar32, puVar27, (uint32_t)uVar4);
                uVar7 = uVar7 - 1;
                puVar27 = puVar27 + (int32_t)uVar46;
                puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
            } while (0 < (int32_t)uVar7);
        }
    } else if ((*(int32_t *)(iVar12 + 0x18) == 0) && (uVar7 != 0)) {
        do {
            puVar28 = puVar27;
            puVar24 = puVar32;
            uVar11 = (uint32_t)uVar4;
            if (uVar4 != 0) {
                do {
                    uVar19 = *puVar28;
                    puVar28 = puVar28 + 1;
                    uVar11 = uVar11 - 1;
                    *puVar24 = (uint32_t)uVar19 << 0x18 | 0xffffff;
                    puVar24 = puVar24 + 1;
                } while (0 < (int32_t)uVar11);
            }
            uVar7 = uVar7 - 1;
            puVar27 = puVar27 + (int32_t)uVar46;
            puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
        } while (0 < (int32_t)uVar7);
    }
    uVar3 = *(uint16_t *)(pfStack_3a8 + iVar34 * 2 + 1);
    fVar47 = *(float *)(iStack_328 + 0x6c);
    if (fVar47 != 1.0) {
        uVar4 = *(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 6);
        uVar7 = (uint32_t)uVar4;
        iVar6 = *(int32_t *)(iStack_348 + 0x1c) * *(int32_t *)(iStack_348 + 0x24);
        puVar32 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 2) *
                                       *(int32_t *)(iStack_348 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(pfStack_3a8 + iVar34 * 2)) *
                                     *(int32_t *)(iStack_348 + 0x24)) + *(int64_t *)(iStack_348 + 0x28));
        if (*(int32_t *)(iStack_348 + 0x18) == 1) {
            if (uVar4 != 0) {
                do {
                    uVar46 = (uint32_t)uVar3;
                    puVar24 = puVar32;
                    if (3 < uVar46) {
                        do {
                            uVar19 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47) < 0xff) {
                                uVar19 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47);
                            }
                            *(uint8_t *)puVar24 = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 1) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            *(uint8_t *)((int64_t)puVar24 + 1) = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 2) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            *(uint8_t *)((int64_t)puVar24 + 2) = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            uVar46 = uVar46 - 4;
                            *(uint8_t *)((int64_t)puVar24 + 3) = uVar19;
                            puVar24 = puVar24 + 1;
                        } while (3 < (int32_t)uVar46);
                    }
                    for (; 0 < (int32_t)uVar46; uVar46 = uVar46 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                        uVar19 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47) < 0xff) {
                            uVar19 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47);
                        }
                        *(uint8_t *)puVar24 = uVar19;
                        puVar24 = (uint32_t *)((int64_t)puVar24 + 1);
                    }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar7 = uVar7 - 1;
                    puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
                } while (0 < (int32_t)uVar7);
            }
        } else if ((*(int32_t *)(iStack_348 + 0x18) == 0) && (uVar7 != 0)) {
            do {
                uVar46 = (uint32_t)uVar3;
                puVar24 = puVar32;
                if (3 < uVar46) {
                    do {
                        uVar11 = *puVar24;
                        uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                        uVar40 = 0xff;
                        if (uVar10 < 0xff) {
                            uVar40 = uVar10;
                        }
                        uVar10 = puVar24[1];
                        *puVar24 = ((uVar40 << 8 | uVar11 >> 0x10 & 0xff) << 8 | uVar11 >> 8 & 0xff) << 8 |
                                   uVar11 & 0xff;
                        uVar40 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 7) * fVar47);
                        uVar11 = 0xff;
                        if (uVar40 < 0xff) {
                            uVar11 = uVar40;
                        }
                        uVar40 = puVar24[2];
                        puVar24[1] = ((uVar11 << 8 | uVar10 >> 0x10 & 0xff) << 8 | uVar10 >> 8 & 0xff) << 8 |
                                     uVar10 & 0xff;
                        uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 0xb) * fVar47);
                        uVar11 = 0xff;
                        if (uVar10 < 0xff) {
                            uVar11 = uVar10;
                        }
                        uVar10 = puVar24[3];
                        puVar24[2] = ((uVar11 << 8 | uVar40 >> 0x10 & 0xff) << 8 | uVar40 >> 8 & 0xff) << 8 |
                                     uVar40 & 0xff;
                        uVar40 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 0xf) * fVar47);
                        uVar11 = 0xff;
                        if (uVar40 < 0xff) {
                            uVar11 = uVar40;
                        }
                        uVar46 = uVar46 - 4;
                        puVar24[3] = ((uVar11 << 8 | uVar10 >> 0x10 & 0xff) << 8 | uVar10 >> 8 & 0xff) << 8 |
                                     uVar10 & 0xff;
                        puVar24 = puVar24 + 4;
                    } while (3 < (int32_t)uVar46);
                }
                for (; 0 < (int32_t)uVar46; uVar46 = uVar46 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar11 = *puVar24;
                    uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                    uVar40 = 0xff;
                    if (uVar10 < 0xff) {
                        uVar40 = uVar10;
                    }
                    *puVar24 = ((uVar40 << 8 | uVar11 >> 0x10 & 0xff) << 8 | uVar11 >> 8 & 0xff) << 8 | uVar11 & 0xff;
                    puVar24 = puVar24 + 1;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                uVar7 = uVar7 - 1;
                puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
            } while (0 < (int32_t)uVar7);
        }
    }
    var_450h._0_4_ = (float)(uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 6);
    var_458h._0_4_ = (float)(uint32_t)*(uint16_t *)(pfStack_3a8 + iVar34 * 2 + 1);
    func_0x000180127510(iStack_350, iStack_348, *(undefined2 *)(pfStack_3a8 + iVar34 * 2), 
                        *(undefined2 *)((int64_t)pfStack_3a8 + iVar34 * 8 + 2));
code_r0x00018012e7ec:
    func_0x000180459870(uStack_e0 ^ (uint64_t)auStackY_478);
    return;
}

// ============================================================
// Function: FUN_18012c902
// Address: 0x18012c902
// Size: 713 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_40ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_400h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_414h
// WARNING: [rz-ghidra] Detected overlap for variable var_408h
// WARNING: [rz-ghidra] Detected overlap for variable var_418h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18012c510(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined auVar5 [12];
    int32_t iVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    float *pfVar14;
    int64_t iVar15;
    undefined *puVar16;
    undefined8 *puVar17;
    int64_t *******pppppppiVar18;
    uint8_t uVar19;
    int64_t *******pppppppiVar20;
    int64_t *******pppppppiVar21;
    uint32_t uVar22;
    int64_t iVar23;
    uint32_t *puVar24;
    int64_t iVar25;
    undefined8 *puVar26;
    uint8_t *puVar27;
    uint8_t *puVar28;
    int64_t *******pppppppiVar29;
    float *pfVar30;
    uint64_t uVar31;
    uint32_t *puVar32;
    int16_t iVar33;
    int64_t iVar34;
    int32_t iVar35;
    uint64_t uVar36;
    int32_t iVar37;
    uint32_t uVar38;
    int32_t iVar39;
    uint32_t uVar40;
    int32_t iVar41;
    undefined *puVar42;
    int32_t iVar43;
    int64_t *******pppppppiVar44;
    float *pfVar45;
    uint32_t uVar46;
    float fVar47;
    undefined4 uVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    float fVar53;
    float fVar54;
    undefined auVar55 [12];
    float fVar56;
    float fVar57;
    float fVar58;
    float fVar59;
    undefined auVar60 [16];
    float fVar61;
    float fVar62;
    float fVar63;
    float fVar64;
    float fVar65;
    float fVar66;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_478 [32];
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_440h;
    int64_t var_438h;
    int64_t var_430h;
    int64_t var_428h;
    int64_t var_420h;
    undefined4 in_stack_fffffffffffffbe8;
    undefined4 in_stack_fffffffffffffbec;
    int64_t var_410h;
    int32_t var_408h;
    int64_t var_404h;
    int64_t var_3fch;
    int64_t iStack_3e8;
    int32_t iStack_3e0;
    undefined4 in_stack_fffffffffffffc34;
    int64_t in_stack_fffffffffffffc38;
    int32_t iStack_3c0;
    int32_t iStack_3b8;
    int32_t iStack_3b4;
    int64_t *******pppppppiStack_3b0;
    float *pfStack_3a8;
    undefined8 uStack_3a0;
    undefined auStack_398 [16];
    undefined auStack_388 [8];
    int32_t iStack_380;
    int32_t iStack_37c;
    undefined8 uStack_378;
    undefined4 uStack_370;
    uint32_t uStack_368;
    undefined8 *puStack_360;
    int64_t iStack_358;
    int64_t iStack_350;
    int64_t iStack_348;
    undefined *puStack_340;
    float *pfStack_338;
    uint32_t *puStack_330;
    int64_t iStack_328;
    int64_t iStack_320;
    undefined *puStack_318;
    int64_t iStack_310;
    float *pfStack_308;
    int64_t iStack_300;
    undefined auStack_2f8 [528];
    undefined8 uStack_e8;
    uint64_t uStack_e0;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_ch;
    
    uStack_e0 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_478;
    iVar12 = *(int64_t *)(arg2 + 0x90);
    puStack_330 = (uint32_t *)arg_30h;
    pfStack_3a8 = (float *)arg_38h;
    iStack_350 = arg1;
    iStack_328 = arg2;
    iStack_300 = arg3;
    iVar6 = fcn.180120380(iVar12, arg_28h & 0xffff);
    if (iVar6 == 0) goto code_r0x00018012e7ec;
    var_410h._0_4_ = (uint32_t)*(char *)(arg2 + 0x37);
    if (*(char *)(arg2 + 0x37) == '\0') {
        if ((36.0 < *(float *)(arg3 + 0x18) * *(float *)(arg3 + 0x14) * *(float *)(arg2 + 0x70)) ||
           (*(char *)(arg2 + 0x36) != '\0')) {
            var_410h._0_4_ = 1;
        } else {
            var_410h._0_4_ = 2;
        }
    }
    uVar7 = (uint32_t)*(char *)(arg2 + 0x38);
    if (*(char *)(arg2 + 0x38) == '\0') {
        uVar7 = 1;
    }
    fVar56 = *(float *)(arg3 + 0x14) * *(float *)(iVar12 + 0xa0);
    fVar58 = *(float *)(arg3 + 0x18) * *(float *)(arg2 + 0x70);
    fVar62 = (float)(uint32_t)var_410h;
    fVar47 = fVar56 * fVar58;
    fVar61 = (float)uVar7;
    fVar64 = fVar62 * fVar47;
    fVar47 = fVar61 * fVar47;
    iVar9 = 0;
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        uVar46 = (uint32_t)var_410h;
        iVar43 = func_0x000180120730(iVar12, iVar6);
        if (-1 < iVar43) {
            iVar34 = *(int64_t *)(iVar12 + 8);
            iVar15 = (int64_t)iVar43;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 3 + iVar15) +
                                      (uint16_t)*(uint8_t *)(iVar34 + 2 + iVar15) * 0x100);
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 4 + iVar15) * 0x100 +
                                       (uint16_t)*(uint8_t *)(iVar34 + 5 + iVar15));
            iVar37 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 7 + iVar15) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 6 + iVar15) * 0x100);
            iVar39 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 9 + iVar15) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 8 + iVar15) * 0x100);
            goto code_r0x00018012c74a;
        }
        iVar39 = 0;
        iVar37 = 0;
        iVar43 = iVar9;
    } else {
        uStack_3a0 = 1;
        auStack_398._0_12_ = ZEXT812(0);
        auStack_398._12_4_ = 0;
        uStack_378 = 0;
        _auStack_388 = ZEXT816(0);
        uStack_370 = 0;
        iVar8 = func_0x000180121980(iVar12, iVar6, &uStack_3a0);
        iVar37 = 0;
        iVar43 = 0;
        if (iVar8 != 0) {
            iVar37 = auStack_388._4_4_;
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_380;
        }
        iVar39 = 0;
        if (iVar8 != 0) {
            iVar39 = iStack_37c;
        }
code_r0x00018012c74a:
        fVar51 = (float)iVar9 * fVar64 + 0.0;
        iVar8 = (int32_t)fVar51;
        if ((fVar51 < 0.0) && ((float)iVar8 != fVar51)) {
            iVar8 = iVar8 + -1;
        }
        fVar51 = 0.0 - (float)iVar39 * fVar47;
        iVar9 = (int32_t)fVar51;
        if ((fVar51 < 0.0) && ((float)iVar9 != fVar51)) {
            iVar9 = iVar9 + -1;
        }
        iVar39 = (int32_t)(float)iVar9;
        fVar51 = (float)func_0x000180471c90((float)iVar37 * fVar64 + 0.0);
        iVar9 = (int32_t)fVar51;
        fVar51 = (float)func_0x000180471c90(0.0 - (float)iVar43 * fVar47);
        iVar37 = (int32_t)fVar51;
        arg_38h = (int64_t)pfStack_3a8;
        iVar43 = (int32_t)(float)iVar8;
        uVar46 = (uint32_t)var_410h;
    }
    iVar15 = iStack_350;
    iVar34 = *(int64_t *)(iVar12 + 8);
    iVar8 = (uint32_t)*(uint8_t *)((int64_t)*(int32_t *)(iVar12 + 0x24) + 0x22 + iVar34) * 0x100 +
            (uint32_t)*(uint8_t *)((int64_t)*(int32_t *)(iVar12 + 0x24) + 0x23 + iVar34);
    if (iVar6 < iVar8) {
        iVar23 = (int64_t)(iVar6 * 4) + (int64_t)*(int32_t *)(iVar12 + 0x28);
        iVar33 = (uint16_t)*(uint8_t *)(iVar23 + iVar34) * 0x100 + (uint16_t)*(uint8_t *)(iVar23 + 1 + iVar34);
    } else {
        iVar23 = (uint64_t)(uint32_t)(iVar8 * 4) + (int64_t)*(int32_t *)(iVar12 + 0x28);
        iVar33 = (uint16_t)*(uint8_t *)(iVar23 + -3 + iVar34) + (uint16_t)*(uint8_t *)(iVar23 + -4 + iVar34) * 0x100;
    }
    fVar56 = (float)(int32_t)iVar33 * fVar56;
    if ((float *)arg_38h != (float *)0x0) {
        *(float *)arg_38h = fVar56;
        goto code_r0x00018012e7ec;
    }
    *puStack_330 = *puStack_330 & 0x3f;
    *puStack_330 = *puStack_330 | (uint32_t)(uint16_t)arg_28h << 6;
    puStack_330[1] = (uint32_t)fVar56;
    if ((iVar43 == iVar9) || (iVar39 == iVar37)) goto code_r0x00018012e7ec;
    uVar40 = (uVar7 - 1) + (iVar37 - iVar39);
    uVar46 = (iVar9 - iVar43) + -1 + uVar46;
    uVar11 = uVar40;
    uStack_368 = fcn.18012ae60(iStack_350, (uint64_t)uVar46, (uint64_t)uVar40, 0, 
                               CONCAT44(in_stack_fffffffffffffbec, in_stack_fffffffffffffbe8), 
                               CONCAT44(in_stack_fffffffffffffc34, uVar40), in_stack_fffffffffffffc38);
    if (uStack_368 == 0xffffffff) goto code_r0x00018012e7ec;
    iVar34 = *(int64_t *)(iVar15 + 0x2b0);
    pfStack_3a8 = *(float **)(iVar34 + 0x68);
    iStack_348 = (int64_t)(*(int32_t *)(*(int64_t *)(iVar34 + 0x78) + (uint64_t)(uStack_368 & 0x7ffff) * 4) << 0xc) >>
                 0xc;
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        iVar9 = func_0x000180120730(iVar12, iVar6);
        if (-1 < iVar9) {
            iVar34 = *(int64_t *)(iVar12 + 8);
            iVar23 = (int64_t)iVar9;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar23 + 2 + iVar34) * 0x100 +
                                      (uint16_t)*(uint8_t *)(iVar23 + 3 + iVar34));
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar23 + 9 + iVar34) +
                                       (uint16_t)*(uint8_t *)(iVar23 + 8 + iVar34) * 0x100);
            goto code_r0x00018012c9d5;
        }
        iStack_3b8 = 0;
        iStack_3b4 = 0;
    } else {
        uStack_3a0 = 1;
        auStack_398 = ZEXT816(0);
        uStack_378 = 0;
        _auStack_388 = ZEXT816(0);
        uStack_370 = 0;
        iVar37 = func_0x000180121980(iVar12, iVar6, &uStack_3a0);
        iVar9 = 0;
        iVar43 = 0;
        if (iVar37 != 0) {
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_37c;
        }
code_r0x00018012c9d5:
        fVar56 = (float)iVar9 * fVar64 + 0.0;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3b8 = (int32_t)(float)iVar9;
        fVar56 = 0.0 - (float)iVar43 * fVar47;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3b4 = (int32_t)(float)iVar9;
    }
    iVar34 = *(int64_t *)(iVar15 + 0x2b0);
    func_0x00018011f640(iVar34 + 0x80, uVar40 * uVar46);
    puVar27 = *(uint8_t **)(iVar34 + 0x88);
    func_0x0001804986e0(puVar27, 0, (int64_t)(int32_t)(uVar40 * uVar46));
    iVar6 = func_0x000180122810(iVar12, iVar6);
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        iVar9 = func_0x000180120730(iVar12);
        if (-1 < iVar9) {
            iVar12 = *(int64_t *)(iVar12 + 8);
            iVar34 = (int64_t)iVar9;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 3 + iVar12) +
                                      (uint16_t)*(uint8_t *)(iVar34 + 2 + iVar12) * 0x100);
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 9 + iVar12) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 8 + iVar12) * 0x100);
            goto code_r0x00018012cb2f;
        }
        iStack_3c0 = 0;
        iStack_3e0 = 0;
    } else {
        auStack_398 = ZEXT816(0);
        uStack_3a0 = 1;
        _auStack_388 = ZEXT816(0);
        uStack_378 = 0;
        uStack_370 = 0;
        iVar37 = func_0x000180121980();
        iVar9 = 0;
        iVar43 = 0;
        if (iVar37 != 0) {
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_37c;
        }
code_r0x00018012cb2f:
        fVar56 = (float)iVar9 * fVar64 + 0.0;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3c0 = (int32_t)(float)iVar9;
        fVar56 = 0.0 - (float)iVar43 * fVar47;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3e0 = (int32_t)(float)iVar9;
    }
    iVar9 = uVar40 - uVar7;
    iVar43 = uVar46 - (uint32_t)var_410h;
    if (iVar43 != -1) {
        uStack_e8 = CONCAT44(uStack_e8._4_4_, iVar9 + 1);
        if (iVar9 + 1 != 0) {
            uVar10 = 0;
            iVar37 = 0;
            uVar31 = 0;
            uVar40 = 0;
            fVar56 = fVar47;
            if (fVar64 <= fVar47) {
                fVar56 = fVar64;
            }
            if (0 < iVar6) {
                do {
                    uVar40 = uVar10 + 1;
                    if (*(char *)(uVar31 * 0xe + 0xc + stack0xfffffffffffffc08) != '\x01') {
                        uVar40 = uVar10;
                    }
                    uVar22 = (int32_t)uVar31 + 1;
                    uVar31 = (uint64_t)uVar22;
                    uVar10 = uVar40;
                } while ((int32_t)uVar22 < iVar6);
            }
            if ((uVar40 != 0) && (iVar12 = func_0x00018046d050((int64_t)(int32_t)uVar40 * 4), iVar12 != 0)) {
                iVar34 = 0;
                iStack_3e8 = 0;
                var_408h = 0;
                fVar56 = (0.35 / fVar56) * (0.35 / fVar56);
                do {
                    if ((var_408h == 1) && (iStack_3e8 = func_0x00018046d050((int64_t)iVar37 << 3), iStack_3e8 == 0)) {
                        fcn.180460d90(0);
                        goto code_r0x00018012cf0c;
                    }
                    iVar37 = 0;
                    iVar41 = 0;
                    iVar39 = 0;
                    iVar8 = -1;
                    if (0 < iVar6) {
                        iVar23 = 0;
                        iVar15 = stack0xfffffffffffffc08;
                        do {
                            iVar25 = iVar23 * 0xe;
                            cVar2 = *(char *)(iVar25 + 0xc + iVar15);
                            if (cVar2 == '\x01') {
                                if (-1 < iVar8) {
                                    *(int32_t *)(iVar12 + (int64_t)iVar8 * 4) = iVar37 - (int32_t)iVar34;
                                }
                                iVar8 = iVar8 + 1;
                                iVar34 = (int64_t)iVar37;
                                iVar33 = *(int16_t *)(iVar25 + 2 + iVar15);
                                iVar37 = iVar37 + 1;
                                iVar39 = iVar37;
                                if (iStack_3e8 != 0) {
                                    *(float *)(iStack_3e8 + iVar34 * 8) = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                    *(float *)(iStack_3e8 + 4 + iVar34 * 8) = (float)(int32_t)iVar33;
                                }
                            } else if (cVar2 == '\x02') {
                                iVar33 = *(int16_t *)(iVar25 + 2 + iVar15);
                                iVar13 = (int64_t)iVar37;
                                iVar37 = iVar37 + 1;
                                iVar39 = iVar37;
                                if (iStack_3e8 != 0) {
                                    *(float *)(iStack_3e8 + iVar13 * 8) = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                    *(float *)(iStack_3e8 + 4 + iVar13 * 8) = (float)(int32_t)iVar33;
                                }
                            } else if (cVar2 == '\x03') {
                                var_430h._0_4_ = 0.0;
                                var_440h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 2 + iVar15);
                                var_448h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                var_450h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 6 + iVar15);
                                var_458h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 4 + iVar15);
                                var_438h._0_4_ = fVar56;
                                iVar37 = iVar39;
                                func_0x000180122bd0(iStack_3e8);
                                iVar39 = iVar37;
                            } else if (cVar2 == '\x04') {
                                var_420h._0_4_ = 0;
                                var_430h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 2 + iVar15);
                                var_438h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                var_440h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 10 + iVar15);
                                var_448h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 8 + iVar15);
                                var_450h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 6 + iVar15);
                                var_458h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 4 + iVar15);
                                var_428h._0_4_ = fVar56;
                                iVar37 = iVar39;
                                func_0x000180122dd0(iStack_3e8);
                                iVar15 = stack0xfffffffffffffc08;
                                iVar39 = iVar37;
                            }
                            iVar41 = iVar41 + 1;
                            iVar23 = iVar23 + 1;
                        } while (iVar41 < iVar6);
                    }
                    *(int32_t *)(iVar12 + (int64_t)iVar8 * 4) = iVar37 - (int32_t)iVar34;
                    var_408h = var_408h + 1;
                } while (var_408h < 2);
                if (iStack_3e8 != 0) {
                    if (0 < (int32_t)uVar40) {
                        iVar37 = 0;
                        iVar6 = 0;
                        if (7 < uVar40) {
                            uVar10 = uVar40 & 0x80000007;
                            if ((int32_t)uVar10 < 0) {
                                uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                            }
                            do {
                                iVar37 = iVar37 + 8;
                            } while (iVar37 < (int32_t)(uVar40 - uVar10));
                            iVar6 = iVar37;
                            if ((int32_t)uVar40 <= iVar37) goto code_r0x00018012d11d;
                        }
                        if (1 < (int32_t)(uVar40 - iVar6)) {
                            do {
                                iVar6 = iVar6 + 2;
                            } while (iVar6 < (int32_t)(uVar40 - 1));
                        }
                    }
code_r0x00018012d11d:
                    uVar10 = uVar40;
                    iStack_358 = iVar12;
                    pfVar14 = (float *)func_0x00018046d050();
                    pfStack_308 = pfVar14;
                    if (pfVar14 != (float *)0x0) {
                        iVar6 = 0;
                        iVar39 = 0;
                        iVar37 = 0;
                        if (0 < (int32_t)uVar40) {
                            do {
                                iVar34 = iStack_3e8 + (int64_t)iVar39 * 8;
                                iVar8 = *(int32_t *)(iVar12 + (int64_t)iVar37 * 4);
                                iVar39 = iVar39 + iVar8;
                                iVar41 = iVar8 + -1;
                                iVar35 = 0;
                                if (0 < iVar8) {
                                    do {
                                        if (*(float *)(iVar34 + 4 + (int64_t)iVar41 * 8) !=
                                            *(float *)(iVar34 + 4 + (int64_t)iVar35 * 8)) {
                                            iVar15 = (int64_t)iVar6;
                                            pfVar14[iVar15 * 5 + 4] = 0.0;
                                            fVar56 = *(float *)(iVar34 + 4 + (int64_t)iVar41 * 8);
                                            pfVar30 = (float *)(iVar34 + 4 + (int64_t)iVar35 * 8);
                                            iVar8 = iVar35;
                                            if (*pfVar30 <= fVar56 && fVar56 != *pfVar30) {
                                                pfVar14[iVar15 * 5 + 4] = 1.401298e-45;
                                                iVar8 = iVar41;
                                                iVar41 = iVar35;
                                            }
                                            iVar6 = iVar6 + 1;
                                            pfVar14[iVar15 * 5] = fVar64 * *(float *)(iVar34 + (int64_t)iVar8 * 8) + 0.0
                                            ;
                                            pfVar14[iVar15 * 5 + 1] =
                                                 (float)((uint32_t)fVar47 ^ 0x80000000) *
                                                 *(float *)(iVar34 + 4 + (int64_t)iVar8 * 8) + 0.0;
                                            pfVar14[iVar15 * 5 + 2] =
                                                 fVar64 * *(float *)(iVar34 + (int64_t)iVar41 * 8) + 0.0;
                                            pfVar14[iVar15 * 5 + 3] =
                                                 (float)((uint32_t)fVar47 ^ 0x80000000) *
                                                 *(float *)(iVar34 + 4 + (int64_t)iVar41 * 8) + 0.0;
                                        }
                                        iVar8 = iVar35 + 1;
                                        uVar40 = uVar10;
                                        iVar41 = iVar35;
                                        iVar35 = iVar8;
                                    } while (iVar8 < *(int32_t *)(iVar12 + (int64_t)iVar37 * 4));
                                }
                                iVar37 = iVar37 + 1;
                            } while (iVar37 < (int32_t)uVar40);
                        }
                        func_0x000180122a30(pfVar14, iVar6);
                        uVar31 = 1;
                        pppppppiVar29 = (int64_t *******)0x0;
                        if (1 < iVar6) {
                            do {
                                uVar40 = (uint32_t)uVar31;
                                fVar56 = pfVar14[uVar31 * 5];
                                fVar47 = pfVar14[uVar31 * 5 + 1];
                                uVar1 = *(undefined8 *)(pfVar14 + uVar31 * 5 + 2);
                                fVar64 = pfVar14[uVar31 * 5 + 4];
                                if (uVar40 < 4) goto code_r0x00018012d37c;
                                do {
                                    uVar10 = (uint32_t)uVar31;
                                    if (pfVar14[uVar31 * 5 + -4] <= fVar47) goto code_r0x00018012d3b6;
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    fVar57 = pfVar45[1];
                                    fVar59 = pfVar45[2];
                                    fVar53 = pfVar45[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -1];
                                    pfVar30 = pfVar14 + uVar31 * 5;
                                    *pfVar30 = *pfVar45;
                                    pfVar30[1] = fVar57;
                                    pfVar30[2] = fVar59;
                                    pfVar30[3] = fVar53;
                                    pfVar14[uVar31 * 5 + 4] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -9] <= fVar47) {
                                        uVar10 = uVar10 - 1;
                                        goto code_r0x00018012d3b6;
                                    }
                                    pfVar30 = pfVar14 + uVar31 * 5 + -10;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -6];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -1] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -0xe] <= fVar47) {
                                        uVar10 = uVar10 - 2;
                                        goto code_r0x00018012d3b6;
                                    }
                                    pfVar30 = pfVar14 + uVar31 * 5 + -0xf;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -0xb];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -10;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -6] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -0x13] <= fVar47) {
                                        uVar10 = uVar10 - 3;
                                        goto code_r0x00018012d3b6;
                                    }
                                    fVar51 = pfVar14[uVar31 * 5 + -0x10];
                                    uVar10 = uVar10 - 4;
                                    pfVar30 = pfVar14 + uVar31 * 5 + -0x14;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -0xf;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -0xb] = fVar51;
                                    uVar31 = (uint64_t)uVar10;
                                } while (3 < (int32_t)uVar10);
                                while (0 < (int32_t)uVar10) {
code_r0x00018012d37c:
                                    uVar10 = (uint32_t)uVar31;
                                    if (pfVar14[uVar31 * 5 + -4] <= fVar47) break;
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    fVar57 = pfVar45[1];
                                    fVar59 = pfVar45[2];
                                    fVar53 = pfVar45[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -1];
                                    uVar10 = uVar10 - 1;
                                    pfVar30 = pfVar14 + uVar31 * 5;
                                    *pfVar30 = *pfVar45;
                                    pfVar30[1] = fVar57;
                                    pfVar30[2] = fVar59;
                                    pfVar30[3] = fVar53;
                                    pfVar14[uVar31 * 5 + 4] = fVar51;
                                    uVar31 = (uint64_t)uVar10;
                                }
code_r0x00018012d3b6:
                                if (uVar40 != uVar10) {
                                    iVar12 = (int64_t)(int32_t)uVar10;
                                    *(undefined8 *)(pfVar14 + iVar12 * 5 + 2) = uVar1;
                                    pfVar14[iVar12 * 5 + 4] = fVar64;
                                    pfVar14[iVar12 * 5 + 1] = fVar47;
                                    pfVar14[iVar12 * 5] = fVar56;
                                }
                                uVar31 = (uint64_t)(uVar40 + 1);
                            } while ((int32_t)(uVar40 + 1) < iVar6);
                        }
                        puStack_360 = (undefined8 *)0x0;
                        uVar40 = 0;
                        pppppppiStack_3b0 = (int64_t *******)0x0;
                        var_408h = 0;
                        iVar37 = iVar43 + 1;
                        pfStack_338 = pfVar14;
                        if (iVar37 < 0x41) {
                            puVar16 = auStack_2f8;
                        } else {
                            puVar16 = (undefined *)func_0x00018046d050((int64_t)(iVar37 * 2 + 1) << 2);
                        }
                        iStack_310 = (int64_t)iVar37 * 4;
                        puVar42 = puVar16 + iStack_310;
                        pfVar14[(int64_t)iVar6 * 5 + 1] = (float)(iStack_3e0 + (int32_t)uStack_e8) + 1.0;
                        puVar26 = puStack_360;
                        puStack_340 = puVar16;
                        puStack_318 = puVar42;
                        pfVar30 = pfVar14;
                        if (0 < (int32_t)uStack_e8) {
                            iStack_320 = (int64_t)(iVar43 + 2) << 2;
                            iVar37 = 0;
                            pppppppiVar44 = pppppppiVar29;
                            pppppppiVar21 = pppppppiVar29;
                            auVar60 = *(undefined (*) [16])0x180646c10;
                            iVar6 = iStack_3e0;
                            do {
                                fVar47 = (float)iVar6 + 1.0;
                                fVar56 = (float)iVar6 + 0.0;
                                func_0x0001804986e0(puVar16, 0, iStack_310);
                                func_0x0001804986e0(puVar42, 0, iStack_320);
                                pppppppiVar20 = pppppppiVar21;
                                if (pppppppiVar21 != (int64_t *******)0x0) {
                                    pppppppiVar18 = (int64_t *******)&pppppppiStack_3b0;
                                    do {
                                        pppppppiVar20 = pppppppiVar21;
                                        if (*(float *)((int64_t)pppppppiVar21 + 0x1c) <= fVar56) {
                                            *pppppppiVar18 = *pppppppiVar21;
                                            *pppppppiVar21 = (int64_t ******)pppppppiVar44;
                                            *(undefined4 *)((int64_t)pppppppiVar21 + 0x14) = 0;
                                            pppppppiVar20 = pppppppiVar18;
                                            pppppppiVar44 = pppppppiVar21;
                                        }
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar20;
                                        pppppppiVar18 = pppppppiVar20;
                                        pppppppiVar20 = pppppppiStack_3b0;
                                    } while (pppppppiVar21 != (int64_t *******)0x0);
                                }
                                puVar26 = puStack_360;
                                if (pfVar14[1] <= fVar47) {
                                    do {
                                        iVar39 = (int32_t)pppppppiVar29;
                                        if (pfVar14[1] != pfVar14[3]) {
                                            puVar17 = puVar26;
                                            if (pppppppiVar44 == (int64_t *******)0x0) {
                                                if (iVar39 == 0) {
                                                    puVar17 = (undefined8 *)func_0x00018046d050(0x6408);
                                                    if (puVar17 == (undefined8 *)0x0) goto code_r0x00018012d652;
                                                    *puVar17 = puVar26;
                                                    iVar39 = 800;
                                                }
                                                pppppppiVar29 = (int64_t *******)(uint64_t)(iVar39 - 1U);
                                                pppppppiVar21 =
                                                     (int64_t *******)
                                                     (puVar17 + (int64_t)(int32_t)(iVar39 - 1U) * 4 + 1);
                                                puVar26 = puVar17;
                                                if (pppppppiVar21 == (int64_t *******)0x0) goto code_r0x00018012d652;
                                            } else {
                                                pppppppiVar21 = pppppppiVar44;
                                                pppppppiVar44 = (int64_t *******)*pppppppiVar44;
                                            }
                                            fVar64 = (pfVar14[2] - *pfVar14) / (pfVar14[3] - pfVar14[1]);
                                            *(float *)((int64_t)pppppppiVar21 + 0xc) = fVar64;
                                            if (fVar64 == 0.0) {
                                                fVar51 = 0.0;
                                            } else {
                                                fVar51 = 1.0 / fVar64;
                                            }
                                            *(float *)(pppppppiVar21 + 2) = fVar51;
                                            *(float *)(pppppppiVar21 + 1) =
                                                 ((fVar56 - pfVar14[1]) * fVar64 + *pfVar14) - (float)iStack_3c0;
                                            uVar48 = 0xbf800000;
                                            if (pfVar14[4] != 0.0) {
                                                uVar48 = 0x3f800000;
                                            }
                                            *(undefined4 *)((int64_t)pppppppiVar21 + 0x14) = uVar48;
                                            *(float *)(pppppppiVar21 + 3) = pfVar14[1];
                                            fVar64 = pfVar14[3];
                                            *(float *)((int64_t)pppppppiVar21 + 0x1c) = fVar64;
                                            if (((var_408h == 0) && (iStack_3e0 != 0)) && (fVar64 < fVar56)) {
                                                *(float *)((int64_t)pppppppiVar21 + 0x1c) = fVar56;
                                            }
                                            *pppppppiVar21 = (int64_t ******)pppppppiVar20;
                                            pppppppiStack_3b0 = pppppppiVar21;
                                            puVar26 = puVar17;
                                            pppppppiVar20 = pppppppiVar21;
                                        }
code_r0x00018012d652:
                                        pfVar45 = pfVar14 + 5;
                                        pfVar30 = pfVar14 + 6;
                                        pfVar14 = pfVar45;
                                    } while (*pfVar30 <= fVar47);
                                    puStack_360 = puVar26;
                                    uVar40 = (uint32_t)pppppppiVar29;
                                    pfStack_338 = pfVar45;
                                    puVar16 = puStack_340;
                                    puVar42 = puStack_318;
                                }
                                iVar39 = iVar43 + 1;
                                if (pppppppiVar20 != (int64_t *******)0x0) {
                                    fVar47 = fVar56 + 1.0;
                                    pppppppiVar21 = pppppppiVar20;
                                    do {
                                        fVar64 = *(float *)((int64_t)pppppppiVar21 + 0xc);
                                        fVar51 = *(float *)(pppppppiVar21 + 1);
                                        if (fVar64 == 0.0) {
                                            if (fVar51 < (float)iVar39) {
                                                var_450h._0_4_ = fVar51;
                                                if (fVar51 < 0.0) {
                                                    var_458h._0_4_ = fVar56;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar42);
                                                } else {
                                                    var_458h._0_4_ = fVar56;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar16);
                                                    var_458h._0_4_ = fVar56;
                                                    var_450h._0_4_ = fVar51;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar42);
                                                }
                                            }
                                        } else {
                                            fVar57 = *(float *)(pppppppiVar21 + 3);
                                            fVar65 = fVar64 + fVar51;
                                            fVar59 = fVar56;
                                            fVar53 = fVar51;
                                            if (fVar56 < fVar57) {
                                                fVar59 = fVar57;
                                                fVar53 = (fVar57 - fVar56) * fVar64 + fVar51;
                                            }
                                            fVar57 = *(float *)((int64_t)pppppppiVar21 + 0x1c);
                                            fVar49 = fVar47;
                                            fVar63 = fVar65;
                                            if (fVar57 < fVar47) {
                                                fVar49 = fVar57;
                                                fVar63 = (fVar57 - fVar56) * fVar64 + fVar51;
                                            }
                                            if (((fVar53 < 0.0) || (fVar63 < 0.0)) ||
                                               (((float)iVar39 <= fVar53 || ((float)iVar39 <= fVar63)))) {
                                                uVar31 = 0;
                                                if (0 < iVar39) {
                                                    do {
                                                        uVar10 = (int32_t)uVar31 + 1;
                                                        uVar36 = (uint64_t)uVar10;
                                                        fVar53 = (float)(int32_t)uVar31;
                                                        fVar57 = (float)uVar10;
                                                        fVar49 = (fVar53 - fVar51) / fVar64 + fVar56;
                                                        fVar59 = (fVar57 - fVar51) / fVar64 + fVar56;
                                                        var_450h._0_4_ = fVar53;
                                                        var_448h._0_4_ = fVar49;
                                                        if ((fVar53 <= fVar51) || (fVar65 <= fVar57)) {
                                                            if ((fVar53 <= fVar65) || (fVar51 <= fVar57)) {
                                                                if (((fVar51 < fVar53) && (fVar53 < fVar65)) ||
                                                                   ((fVar65 < fVar53 && (fVar53 < fVar51)))) {
                                                                    var_458h._0_4_ = fVar56;
                                                                    func_0x0001801228f0(puVar16);
                                                                    var_458h._0_4_ = fVar49;
                                                                } else if (((fVar51 < fVar57) && (fVar57 < fVar65)) ||
                                                                          ((var_458h._0_4_ = fVar56, fVar65 < fVar57 &&
                                                                           (fVar57 < fVar51)))) {
                                                                    var_458h._0_4_ = fVar56;
                                                                    var_450h._0_4_ = fVar57;
                                                                    var_448h._0_4_ = fVar59;
                                                                    func_0x0001801228f0(puVar16);
                                                                    var_458h._0_4_ = fVar59;
                                                                }
                                                            } else {
                                                                var_458h._0_4_ = fVar56;
                                                                var_450h._0_4_ = fVar57;
                                                                var_448h._0_4_ = fVar59;
                                                                func_0x0001801228f0(puVar16);
                                                                var_458h._0_4_ = fVar59;
                                                                var_450h._0_4_ = fVar53;
                                                                var_448h._0_4_ = fVar49;
                                                                func_0x0001801228f0();
                                                                var_458h._0_4_ = fVar49;
                                                            }
                                                        } else {
                                                            var_458h._0_4_ = fVar56;
                                                            func_0x0001801228f0(puVar16);
                                                            var_458h._0_4_ = fVar49;
                                                            var_450h._0_4_ = fVar57;
                                                            var_448h._0_4_ = fVar59;
                                                            func_0x0001801228f0();
                                                            var_458h._0_4_ = fVar59;
                                                        }
                                                        var_450h._0_4_ = fVar65;
                                                        var_448h._0_4_ = fVar47;
                                                        func_0x0001801228f0(puVar16);
                                                        uVar31 = uVar36 & 0xffffffff;
                                                    } while ((int32_t)uVar36 < iVar39);
                                                }
                                            } else {
                                                iVar8 = (int32_t)fVar53;
                                                if (iVar8 == (int32_t)fVar63) {
                                                    iVar12 = (int64_t)iVar8;
                                                    fVar64 = (fVar49 - fVar59) *
                                                             *(float *)((int64_t)pppppppiVar21 + 0x14);
                                                    *(float *)(puVar16 + iVar12 * 4) =
                                                         ((((float)iVar8 + 1.0) - fVar63) +
                                                         (((float)iVar8 + 1.0) - fVar53)) * 0.5 * fVar64 +
                                                         *(float *)(puVar16 + iVar12 * 4);
                                                    *(float *)(puVar42 + iVar12 * 4 + 4) =
                                                         fVar64 + *(float *)(puVar42 + iVar12 * 4 + 4);
                                                } else {
                                                    fVar64 = *(float *)(pppppppiVar21 + 2);
                                                    fVar57 = fVar63;
                                                    if (fVar63 < fVar53) {
                                                        fVar51 = fVar49 - fVar56;
                                                        fVar64 = (float)((uint32_t)fVar64 ^ 0x80000000);
                                                        fVar49 = fVar47 - (fVar59 - fVar56);
                                                        fVar59 = fVar47 - fVar51;
                                                        fVar51 = fVar65;
                                                        fVar57 = fVar53;
                                                        fVar53 = fVar63;
                                                    }
                                                    fVar65 = *(float *)((int64_t)pppppppiVar21 + 0x14);
                                                    iVar35 = (int32_t)fVar53;
                                                    iVar41 = (int32_t)fVar57;
                                                    iVar8 = iVar35 + 1;
                                                    fVar66 = (float)iVar41;
                                                    fVar50 = ((float)iVar8 - fVar51) * fVar64 + fVar56;
                                                    fVar63 = (fVar66 - fVar51) * fVar64 + fVar56;
                                                    fVar51 = fVar47;
                                                    if (fVar50 <= fVar47) {
                                                        fVar51 = fVar50;
                                                    }
                                                    fVar50 = (fVar51 - fVar59) * fVar65;
                                                    *(float *)(puVar16 + (int64_t)iVar35 * 4) =
                                                         ((float)iVar8 - fVar53) * fVar50 * 0.5 +
                                                         *(float *)(puVar16 + (int64_t)iVar35 * 4);
                                                    if ((fVar47 < fVar63) &&
                                                       (iVar35 = (iVar41 - iVar35) + -1, fVar63 = fVar47, iVar35 != 0))
                                                    {
                                                        fVar64 = (fVar47 - fVar51) / (float)iVar35;
                                                    }
                                                    if (iVar8 < iVar41) {
                                                        fVar64 = fVar64 * fVar65;
                                                        fVar51 = fVar64 * 0.5;
                                                        if (3 < iVar41 - iVar8) {
                                                            do {
                                                                iVar12 = (int64_t)iVar8;
                                                                iVar8 = iVar8 + 4;
                                                                *(float *)(puVar16 + iVar12 * 4) =
                                                                     fVar50 + fVar51 + *(float *)(puVar16 + iVar12 * 4);
                                                                fVar53 = fVar50 + fVar64 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 4) =
                                                                     fVar51 + fVar50 + fVar64 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 4);
                                                                fVar54 = fVar53 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 8) =
                                                                     fVar51 + fVar53 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 8);
                                                                fVar50 = fVar54 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 0xc) =
                                                                     fVar51 + fVar54 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 0xc);
                                                            } while (iVar8 < iVar41 + -3);
                                                        }
                                                        for (; iVar8 < iVar41; iVar8 = iVar8 + 1) {
                                                            fVar53 = fVar50 + fVar51;
                                                            fVar50 = fVar50 + fVar64;
                                                            *(float *)(puVar16 + (int64_t)iVar8 * 4) =
                                                                 fVar53 + *(float *)(puVar16 + (int64_t)iVar8 * 4);
                                                        }
                                                    }
                                                    iVar12 = (int64_t)iVar41;
                                                    *(float *)(puVar16 + iVar12 * 4) =
                                                         (((fVar66 + 1.0) - fVar57) + ((fVar66 + 1.0) - fVar66)) * 0.5 *
                                                         (fVar49 - fVar63) * fVar65 + fVar50 +
                                                         *(float *)(puVar16 + iVar12 * 4);
                                                    *(float *)(puVar42 + iVar12 * 4 + 4) =
                                                         (fVar49 - fVar59) * fVar65 +
                                                         *(float *)(puVar42 + iVar12 * 4 + 4);
                                                }
                                            }
                                        }
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar21;
                                        auVar60 = *(undefined (*) [16])0x180646c10;
                                    } while (pppppppiVar21 != (int64_t *******)0x0);
                                }
                                iVar8 = 0;
                                auVar52._0_12_ = ZEXT812(0);
                                auVar52._12_4_ = 0;
                                uVar10 = auVar60._0_4_;
                                if (iVar39 < 4) {
                                    if (0 < iVar39) goto code_r0x00018012dce2;
                                } else {
                                    do {
                                        iVar34 = (int64_t)iVar8;
                                        iVar12 = (int64_t)(iVar8 + iVar37);
                                        fVar47 = auVar52._0_4_ + *(float *)(puVar42 + iVar34 * 4);
                                        iVar39 = (int32_t)((float)((uint32_t)(fVar47 + *(float *)(puVar16 + iVar34 * 4))
                                                                  & uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12] = uVar19;
                                        fVar47 = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 4);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (fVar47 + *(float *)(puVar16 + iVar34 * 4 + 4)) &
                                                                  uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12 + 1] = uVar19;
                                        fVar47 = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 8);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (fVar47 + *(float *)(puVar16 + iVar34 * 4 + 8)) &
                                                                  uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12 + 2] = uVar19;
                                        auVar52._0_4_ = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 0xc);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (auVar52._0_4_ +
                                                                   *(float *)(puVar16 + iVar34 * 4 + 0xc)) & uVar10) *
                                                           255.0 + 0.5);
                                        if (0xff < iVar39) {
                                            iVar39 = 0xff;
                                        }
                                        iVar8 = iVar8 + 4;
                                        puVar27[iVar12 + 3] = (uint8_t)iVar39;
                                    } while (iVar8 < iVar43 + -2);
                                    pppppppiVar29 = (int64_t *******)(uint64_t)uVar40;
                                    if (iVar8 < iVar43 + 1) {
code_r0x00018012dce2:
                                        do {
                                            auVar52._0_4_ = auVar52._0_4_ + *(float *)(puVar42 + (int64_t)iVar8 * 4);
                                            iVar39 = iVar37 + iVar8;
                                            iVar41 = (int32_t)((float)((uint32_t)
                                                                       (auVar52._0_4_ +
                                                                       *(float *)(puVar16 + (int64_t)iVar8 * 4)) &
                                                                      uVar10) * 255.0 + 0.5);
                                            if (0xff < iVar41) {
                                                iVar41 = 0xff;
                                            }
                                            iVar8 = iVar8 + 1;
                                            puVar27[iVar39] = (uint8_t)iVar41;
                                        } while (iVar8 < iVar43 + 1);
                                        pppppppiVar29 = (int64_t *******)(uint64_t)uVar40;
                                        pfVar14 = pfStack_338;
                                    }
                                }
                                if (pppppppiVar20 != (int64_t *******)0x0) {
                                    pppppppiVar21 = (int64_t *******)&pppppppiStack_3b0;
                                    pppppppiVar18 = pppppppiVar20;
                                    do {
                                        *(float *)(pppppppiVar18 + 1) =
                                             *(float *)((int64_t)pppppppiVar18 + 0xc) + *(float *)(pppppppiVar18 + 1);
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar21;
                                        pppppppiVar18 = (int64_t *******)*pppppppiVar21;
                                    } while (pppppppiVar18 != (int64_t *******)0x0);
                                }
                                iVar6 = iVar6 + 1;
                                iVar37 = iVar37 + uVar46;
                                var_408h = var_408h + 1;
                                pppppppiVar21 = pppppppiVar20;
                                puVar26 = puStack_360;
                                pfVar30 = pfStack_308;
                            } while (var_408h < (int32_t)uStack_e8);
                        }
                        while (puVar26 != (undefined8 *)0x0) {
                            puVar17 = (undefined8 *)*puVar26;
                            fcn.180460d90(puVar26);
                            puVar26 = puVar17;
                        }
                        if (puVar16 != auStack_2f8) {
                            fcn.180460d90(puVar16);
                        }
                        fcn.180460d90(pfVar30);
                        iVar12 = iStack_358;
                    }
                    fcn.180460d90(iVar12);
                    iVar12 = iStack_3e8;
code_r0x00018012cf0c:
                    fcn.180460d90(iVar12);
                }
            }
        }
    }
    fcn.180460d90(stack0xfffffffffffffc08);
    uVar40 = uVar11;
    puVar28 = puVar27;
    if (1 < (int32_t)(uint32_t)var_410h) {
        iVar6 = 0;
        uStack_e8 = 0;
        if (0 < (int32_t)uVar11) {
            do {
                func_0x0001804986e0(&uStack_e8, 0, (uint32_t)var_410h);
                uVar36 = 0;
                uVar31 = 0;
                if ((uint32_t)var_410h == 2) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 + 2;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 >> 1);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else if ((uint32_t)var_410h == 3) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 + 3;
                            uVar36 = (uint64_t)
                                     ((int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7))));
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar36 / 3);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else if ((uint32_t)var_410h == 4) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 - 4;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 >> 2);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else {
                    uVar10 = 0;
                    uVar31 = uVar36;
                    if ((uint32_t)var_410h == 5) {
                        if (-1 < iVar43) {
                            do {
                                iVar12 = (int64_t)(int32_t)uVar10;
                                iVar34 = (int64_t)(int32_t)uVar10;
                                uVar22 = uVar10 - 3;
                                uVar36 = (uint64_t)
                                         ((int32_t)uVar36 +
                                         ((uint32_t)puVar27[iVar12] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)) = puVar27[iVar12];
                                puVar27[iVar34] = (uint8_t)(uVar36 / 5);
                                uVar31 = uVar36;
                            } while ((int32_t)uVar10 <= iVar43);
                        }
                    } else if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar10;
                            iVar12 = (int64_t)(int32_t)uVar10;
                            uVar22 = uVar10 + (uint32_t)var_410h;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 / (uint32_t)var_410h);
                            uVar31 = uVar36;
                        } while ((int32_t)uVar10 <= iVar43);
                    }
                }
                for (; (int32_t)uVar10 < (int32_t)uVar46; uVar10 = uVar10 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar22 = (int32_t)uVar31 - (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7));
                    puVar27[(int32_t)uVar10] = (uint8_t)(uVar22 / (uint32_t)var_410h);
                    uVar31 = (uint64_t)uVar22;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                puVar27 = puVar27 + (int32_t)uVar46;
                iVar6 = iVar6 + 1;
            } while (iVar6 < (int32_t)uVar11);
        }
    }
    puVar27 = puVar28;
    if (1 < (int32_t)uVar7) {
        iVar6 = 0;
        uStack_e8 = 0;
        if (0 < (int32_t)uVar46) {
            do {
                func_0x0001804986e0(&uStack_e8, 0, uVar7);
                uVar36 = 0;
                uVar31 = 0;
                if (uVar7 == 2) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar22 = (int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar22;
                            uVar11 = uVar10 + 2;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar22 >> 1);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else if (uVar7 == 3) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar36 = (uint64_t)
                                     ((int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                            uVar11 = uVar10 + 3;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar36 / 3);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else if (uVar7 == 4) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar22 = (int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar22;
                            uVar11 = uVar10 - 4;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar22 >> 2);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else {
                    uVar10 = 0;
                    uVar31 = uVar36;
                    if (uVar7 == 5) {
                        uVar11 = 0;
                        if (-1 < iVar9) {
                            do {
                                iVar43 = uVar10 * uVar46;
                                uVar36 = (uint64_t)
                                         ((int32_t)uVar36 +
                                         ((uint32_t)puVar28[iVar43] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                                uVar11 = uVar10 - 3;
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                                puVar28[iVar43] = (uint8_t)(uVar36 / 5);
                                uVar31 = uVar36;
                                uVar11 = uVar10;
                            } while ((int32_t)uVar10 <= iVar9);
                        }
                    } else {
                        uVar11 = uVar10;
                        if (-1 < iVar9) {
                            do {
                                iVar43 = uVar10 * uVar46;
                                uVar22 = (int32_t)uVar36 +
                                         ((uint32_t)puVar28[iVar43] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                                uVar36 = (uint64_t)uVar22;
                                uVar11 = uVar10 + uVar7;
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                                puVar28[iVar43] = (uint8_t)(uVar22 / uVar7);
                                uVar31 = uVar36;
                                uVar11 = uVar10;
                            } while ((int32_t)uVar10 <= iVar9);
                        }
                    }
                }
                for (; (int32_t)uVar11 < (int32_t)uVar40; uVar11 = uVar11 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar10 = (int32_t)uVar31 - (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7));
                    puVar28[(int32_t)(uVar11 * uVar46)] = (uint8_t)(uVar10 / uVar7);
                    uVar31 = (uint64_t)uVar10;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                puVar28 = puVar28 + 1;
                iVar6 = iVar6 + 1;
            } while (iVar6 < (int32_t)uVar46);
        }
    }
    if ((uint32_t)var_410h == 0) {
        fVar47 = 0.0;
    } else {
        fVar47 = (float)(1 - (uint32_t)var_410h) / (fVar62 + fVar62);
    }
    if (uVar7 == 0) {
        fVar56 = 0.0;
    } else {
        fVar56 = (float)(1 - uVar7) / (fVar61 + fVar61);
    }
    fVar64 = *(float *)(**(int64_t **)(*(int64_t *)(iStack_300 + 0x58) + 0x28) + 0x3c);
    if (fVar64 == 0.0) {
        auVar55 = ZEXT812(0x3f800000);
    } else {
        auVar55._4_8_ = 0;
        auVar55._0_4_ = *(float *)(iStack_300 + 0x14) / fVar64;
    }
    auVar5._4_8_ = auVar55._4_8_;
    auVar5._0_4_ = auVar55._0_4_ * *(float *)(iStack_328 + 0x50) + 0.5;
    iVar12 = iStack_300;
    fVar64 = (float)func_0x0001800f4120(auVar5._0_8_);
    fVar64 = fVar64 + fVar47;
    fVar47 = (float)func_0x0001800f4120();
    iVar34 = iStack_348;
    fVar62 = 1.0 / (fVar62 * fVar58);
    fVar47 = fVar47 + (float)(int32_t)(*(float *)(iVar12 + 0x44) + 0.5) + fVar56;
    fVar56 = 1.0 / (fVar61 * fVar58);
    puStack_330[2] = (uint32_t)((float)iStack_3b8 * fVar62 + fVar64);
    puStack_330[3] = (uint32_t)((float)iStack_3b4 * fVar56 + fVar47);
    puStack_330[4] =
         (uint32_t)((float)((uint32_t)*(uint16_t *)(pfStack_3a8 + iStack_348 * 2 + 1) + iStack_3b8) * fVar62 + fVar64);
    uVar3 = *(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 6);
    *puStack_330 = *puStack_330 | 2;
    puStack_330[10] = uStack_368;
    puStack_330[5] = (uint32_t)((float)((uint32_t)uVar3 + iStack_3b4) * fVar56 + fVar47);
    iVar12 = *(int64_t *)(iStack_350 + 0x38);
    uVar3 = *(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 6);
    uVar7 = (uint32_t)uVar3;
    iVar6 = *(int32_t *)(iVar12 + 0x24) * *(int32_t *)(iVar12 + 0x1c);
    uVar4 = *(uint16_t *)(pfStack_3a8 + iStack_348 * 2 + 1);
    puVar32 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 2) *
                                   *(int32_t *)(iVar12 + 0x1c) + (uint32_t)*(uint16_t *)(pfStack_3a8 + iStack_348 * 2))
                                 * *(int32_t *)(iVar12 + 0x24)) + *(int64_t *)(iVar12 + 0x28));
    iStack_348 = iVar12;
    if (*(int32_t *)(iVar12 + 0x18) == 1) {
        if (uVar3 != 0) {
            do {
                func_0x000180498030(puVar32, puVar27, (uint32_t)uVar4);
                uVar7 = uVar7 - 1;
                puVar27 = puVar27 + (int32_t)uVar46;
                puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
            } while (0 < (int32_t)uVar7);
        }
    } else if ((*(int32_t *)(iVar12 + 0x18) == 0) && (uVar7 != 0)) {
        do {
            puVar28 = puVar27;
            puVar24 = puVar32;
            uVar11 = (uint32_t)uVar4;
            if (uVar4 != 0) {
                do {
                    uVar19 = *puVar28;
                    puVar28 = puVar28 + 1;
                    uVar11 = uVar11 - 1;
                    *puVar24 = (uint32_t)uVar19 << 0x18 | 0xffffff;
                    puVar24 = puVar24 + 1;
                } while (0 < (int32_t)uVar11);
            }
            uVar7 = uVar7 - 1;
            puVar27 = puVar27 + (int32_t)uVar46;
            puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
        } while (0 < (int32_t)uVar7);
    }
    uVar3 = *(uint16_t *)(pfStack_3a8 + iVar34 * 2 + 1);
    fVar47 = *(float *)(iStack_328 + 0x6c);
    if (fVar47 != 1.0) {
        uVar4 = *(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 6);
        uVar7 = (uint32_t)uVar4;
        iVar6 = *(int32_t *)(iStack_348 + 0x1c) * *(int32_t *)(iStack_348 + 0x24);
        puVar32 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 2) *
                                       *(int32_t *)(iStack_348 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(pfStack_3a8 + iVar34 * 2)) *
                                     *(int32_t *)(iStack_348 + 0x24)) + *(int64_t *)(iStack_348 + 0x28));
        if (*(int32_t *)(iStack_348 + 0x18) == 1) {
            if (uVar4 != 0) {
                do {
                    uVar46 = (uint32_t)uVar3;
                    puVar24 = puVar32;
                    if (3 < uVar46) {
                        do {
                            uVar19 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47) < 0xff) {
                                uVar19 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47);
                            }
                            *(uint8_t *)puVar24 = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 1) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            *(uint8_t *)((int64_t)puVar24 + 1) = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 2) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            *(uint8_t *)((int64_t)puVar24 + 2) = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            uVar46 = uVar46 - 4;
                            *(uint8_t *)((int64_t)puVar24 + 3) = uVar19;
                            puVar24 = puVar24 + 1;
                        } while (3 < (int32_t)uVar46);
                    }
                    for (; 0 < (int32_t)uVar46; uVar46 = uVar46 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                        uVar19 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47) < 0xff) {
                            uVar19 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47);
                        }
                        *(uint8_t *)puVar24 = uVar19;
                        puVar24 = (uint32_t *)((int64_t)puVar24 + 1);
                    }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar7 = uVar7 - 1;
                    puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
                } while (0 < (int32_t)uVar7);
            }
        } else if ((*(int32_t *)(iStack_348 + 0x18) == 0) && (uVar7 != 0)) {
            do {
                uVar46 = (uint32_t)uVar3;
                puVar24 = puVar32;
                if (3 < uVar46) {
                    do {
                        uVar11 = *puVar24;
                        uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                        uVar40 = 0xff;
                        if (uVar10 < 0xff) {
                            uVar40 = uVar10;
                        }
                        uVar10 = puVar24[1];
                        *puVar24 = ((uVar40 << 8 | uVar11 >> 0x10 & 0xff) << 8 | uVar11 >> 8 & 0xff) << 8 |
                                   uVar11 & 0xff;
                        uVar40 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 7) * fVar47);
                        uVar11 = 0xff;
                        if (uVar40 < 0xff) {
                            uVar11 = uVar40;
                        }
                        uVar40 = puVar24[2];
                        puVar24[1] = ((uVar11 << 8 | uVar10 >> 0x10 & 0xff) << 8 | uVar10 >> 8 & 0xff) << 8 |
                                     uVar10 & 0xff;
                        uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 0xb) * fVar47);
                        uVar11 = 0xff;
                        if (uVar10 < 0xff) {
                            uVar11 = uVar10;
                        }
                        uVar10 = puVar24[3];
                        puVar24[2] = ((uVar11 << 8 | uVar40 >> 0x10 & 0xff) << 8 | uVar40 >> 8 & 0xff) << 8 |
                                     uVar40 & 0xff;
                        uVar40 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 0xf) * fVar47);
                        uVar11 = 0xff;
                        if (uVar40 < 0xff) {
                            uVar11 = uVar40;
                        }
                        uVar46 = uVar46 - 4;
                        puVar24[3] = ((uVar11 << 8 | uVar10 >> 0x10 & 0xff) << 8 | uVar10 >> 8 & 0xff) << 8 |
                                     uVar10 & 0xff;
                        puVar24 = puVar24 + 4;
                    } while (3 < (int32_t)uVar46);
                }
                for (; 0 < (int32_t)uVar46; uVar46 = uVar46 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar11 = *puVar24;
                    uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                    uVar40 = 0xff;
                    if (uVar10 < 0xff) {
                        uVar40 = uVar10;
                    }
                    *puVar24 = ((uVar40 << 8 | uVar11 >> 0x10 & 0xff) << 8 | uVar11 >> 8 & 0xff) << 8 | uVar11 & 0xff;
                    puVar24 = puVar24 + 1;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                uVar7 = uVar7 - 1;
                puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
            } while (0 < (int32_t)uVar7);
        }
    }
    var_450h._0_4_ = (float)(uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 6);
    var_458h._0_4_ = (float)(uint32_t)*(uint16_t *)(pfStack_3a8 + iVar34 * 2 + 1);
    func_0x000180127510(iStack_350, iStack_348, *(undefined2 *)(pfStack_3a8 + iVar34 * 2), 
                        *(undefined2 *)((int64_t)pfStack_3a8 + iVar34 * 8 + 2));
code_r0x00018012e7ec:
    func_0x000180459870(uStack_e0 ^ (uint64_t)auStackY_478);
    return;
}

// ============================================================
// Function: FUN_18012cbcb
// Address: 0x18012cbcb
// Size: 910 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_40ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_400h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_414h
// WARNING: [rz-ghidra] Detected overlap for variable var_408h
// WARNING: [rz-ghidra] Detected overlap for variable var_418h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_ach
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18012c510(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined auVar5 [12];
    int32_t iVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    float *pfVar14;
    int64_t iVar15;
    undefined *puVar16;
    undefined8 *puVar17;
    int64_t *******pppppppiVar18;
    uint8_t uVar19;
    int64_t *******pppppppiVar20;
    int64_t *******pppppppiVar21;
    uint32_t uVar22;
    int64_t iVar23;
    uint32_t *puVar24;
    int64_t iVar25;
    undefined8 *puVar26;
    uint8_t *puVar27;
    uint8_t *puVar28;
    int64_t *******pppppppiVar29;
    float *pfVar30;
    uint64_t uVar31;
    uint32_t *puVar32;
    int16_t iVar33;
    int64_t iVar34;
    int32_t iVar35;
    uint64_t uVar36;
    int32_t iVar37;
    uint32_t uVar38;
    int32_t iVar39;
    uint32_t uVar40;
    int32_t iVar41;
    undefined *puVar42;
    int32_t iVar43;
    int64_t *******pppppppiVar44;
    float *pfVar45;
    uint32_t uVar46;
    float fVar47;
    undefined4 uVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    float fVar53;
    float fVar54;
    undefined auVar55 [12];
    float fVar56;
    float fVar57;
    float fVar58;
    float fVar59;
    undefined auVar60 [16];
    float fVar61;
    float fVar62;
    float fVar63;
    float fVar64;
    float fVar65;
    float fVar66;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_478 [32];
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_440h;
    int64_t var_438h;
    int64_t var_430h;
    int64_t var_428h;
    int64_t var_420h;
    undefined4 in_stack_fffffffffffffbe8;
    undefined4 in_stack_fffffffffffffbec;
    int64_t var_410h;
    int32_t var_408h;
    int64_t var_404h;
    int64_t var_3fch;
    int64_t iStack_3e8;
    int32_t iStack_3e0;
    undefined4 in_stack_fffffffffffffc34;
    int64_t in_stack_fffffffffffffc38;
    int32_t iStack_3c0;
    int32_t iStack_3b8;
    int32_t iStack_3b4;
    int64_t *******pppppppiStack_3b0;
    float *pfStack_3a8;
    undefined8 uStack_3a0;
    undefined auStack_398 [16];
    undefined auStack_388 [8];
    int32_t iStack_380;
    int32_t iStack_37c;
    undefined8 uStack_378;
    undefined4 uStack_370;
    uint32_t uStack_368;
    undefined8 *puStack_360;
    int64_t iStack_358;
    int64_t iStack_350;
    int64_t iStack_348;
    undefined *puStack_340;
    float *pfStack_338;
    uint32_t *puStack_330;
    int64_t iStack_328;
    int64_t iStack_320;
    undefined *puStack_318;
    int64_t iStack_310;
    float *pfStack_308;
    int64_t iStack_300;
    undefined auStack_2f8 [528];
    undefined8 uStack_e8;
    uint64_t uStack_e0;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_ch;
    
    uStack_e0 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_478;
    iVar12 = *(int64_t *)(arg2 + 0x90);
    puStack_330 = (uint32_t *)arg_30h;
    pfStack_3a8 = (float *)arg_38h;
    iStack_350 = arg1;
    iStack_328 = arg2;
    iStack_300 = arg3;
    iVar6 = fcn.180120380(iVar12, arg_28h & 0xffff);
    if (iVar6 == 0) goto code_r0x00018012e7ec;
    var_410h._0_4_ = (uint32_t)*(char *)(arg2 + 0x37);
    if (*(char *)(arg2 + 0x37) == '\0') {
        if ((36.0 < *(float *)(arg3 + 0x18) * *(float *)(arg3 + 0x14) * *(float *)(arg2 + 0x70)) ||
           (*(char *)(arg2 + 0x36) != '\0')) {
            var_410h._0_4_ = 1;
        } else {
            var_410h._0_4_ = 2;
        }
    }
    uVar7 = (uint32_t)*(char *)(arg2 + 0x38);
    if (*(char *)(arg2 + 0x38) == '\0') {
        uVar7 = 1;
    }
    fVar56 = *(float *)(arg3 + 0x14) * *(float *)(iVar12 + 0xa0);
    fVar58 = *(float *)(arg3 + 0x18) * *(float *)(arg2 + 0x70);
    fVar62 = (float)(uint32_t)var_410h;
    fVar47 = fVar56 * fVar58;
    fVar61 = (float)uVar7;
    fVar64 = fVar62 * fVar47;
    fVar47 = fVar61 * fVar47;
    iVar9 = 0;
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        uVar46 = (uint32_t)var_410h;
        iVar43 = func_0x000180120730(iVar12, iVar6);
        if (-1 < iVar43) {
            iVar34 = *(int64_t *)(iVar12 + 8);
            iVar15 = (int64_t)iVar43;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 3 + iVar15) +
                                      (uint16_t)*(uint8_t *)(iVar34 + 2 + iVar15) * 0x100);
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 4 + iVar15) * 0x100 +
                                       (uint16_t)*(uint8_t *)(iVar34 + 5 + iVar15));
            iVar37 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 7 + iVar15) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 6 + iVar15) * 0x100);
            iVar39 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 9 + iVar15) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 8 + iVar15) * 0x100);
            goto code_r0x00018012c74a;
        }
        iVar39 = 0;
        iVar37 = 0;
        iVar43 = iVar9;
    } else {
        uStack_3a0 = 1;
        auStack_398._0_12_ = ZEXT812(0);
        auStack_398._12_4_ = 0;
        uStack_378 = 0;
        _auStack_388 = ZEXT816(0);
        uStack_370 = 0;
        iVar8 = func_0x000180121980(iVar12, iVar6, &uStack_3a0);
        iVar37 = 0;
        iVar43 = 0;
        if (iVar8 != 0) {
            iVar37 = auStack_388._4_4_;
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_380;
        }
        iVar39 = 0;
        if (iVar8 != 0) {
            iVar39 = iStack_37c;
        }
code_r0x00018012c74a:
        fVar51 = (float)iVar9 * fVar64 + 0.0;
        iVar8 = (int32_t)fVar51;
        if ((fVar51 < 0.0) && ((float)iVar8 != fVar51)) {
            iVar8 = iVar8 + -1;
        }
        fVar51 = 0.0 - (float)iVar39 * fVar47;
        iVar9 = (int32_t)fVar51;
        if ((fVar51 < 0.0) && ((float)iVar9 != fVar51)) {
            iVar9 = iVar9 + -1;
        }
        iVar39 = (int32_t)(float)iVar9;
        fVar51 = (float)func_0x000180471c90((float)iVar37 * fVar64 + 0.0);
        iVar9 = (int32_t)fVar51;
        fVar51 = (float)func_0x000180471c90(0.0 - (float)iVar43 * fVar47);
        iVar37 = (int32_t)fVar51;
        arg_38h = (int64_t)pfStack_3a8;
        iVar43 = (int32_t)(float)iVar8;
        uVar46 = (uint32_t)var_410h;
    }
    iVar15 = iStack_350;
    iVar34 = *(int64_t *)(iVar12 + 8);
    iVar8 = (uint32_t)*(uint8_t *)((int64_t)*(int32_t *)(iVar12 + 0x24) + 0x22 + iVar34) * 0x100 +
            (uint32_t)*(uint8_t *)((int64_t)*(int32_t *)(iVar12 + 0x24) + 0x23 + iVar34);
    if (iVar6 < iVar8) {
        iVar23 = (int64_t)(iVar6 * 4) + (int64_t)*(int32_t *)(iVar12 + 0x28);
        iVar33 = (uint16_t)*(uint8_t *)(iVar23 + iVar34) * 0x100 + (uint16_t)*(uint8_t *)(iVar23 + 1 + iVar34);
    } else {
        iVar23 = (uint64_t)(uint32_t)(iVar8 * 4) + (int64_t)*(int32_t *)(iVar12 + 0x28);
        iVar33 = (uint16_t)*(uint8_t *)(iVar23 + -3 + iVar34) + (uint16_t)*(uint8_t *)(iVar23 + -4 + iVar34) * 0x100;
    }
    fVar56 = (float)(int32_t)iVar33 * fVar56;
    if ((float *)arg_38h != (float *)0x0) {
        *(float *)arg_38h = fVar56;
        goto code_r0x00018012e7ec;
    }
    *puStack_330 = *puStack_330 & 0x3f;
    *puStack_330 = *puStack_330 | (uint32_t)(uint16_t)arg_28h << 6;
    puStack_330[1] = (uint32_t)fVar56;
    if ((iVar43 == iVar9) || (iVar39 == iVar37)) goto code_r0x00018012e7ec;
    uVar40 = (uVar7 - 1) + (iVar37 - iVar39);
    uVar46 = (iVar9 - iVar43) + -1 + uVar46;
    uVar11 = uVar40;
    uStack_368 = fcn.18012ae60(iStack_350, (uint64_t)uVar46, (uint64_t)uVar40, 0, 
                               CONCAT44(in_stack_fffffffffffffbec, in_stack_fffffffffffffbe8), 
                               CONCAT44(in_stack_fffffffffffffc34, uVar40), in_stack_fffffffffffffc38);
    if (uStack_368 == 0xffffffff) goto code_r0x00018012e7ec;
    iVar34 = *(int64_t *)(iVar15 + 0x2b0);
    pfStack_3a8 = *(float **)(iVar34 + 0x68);
    iStack_348 = (int64_t)(*(int32_t *)(*(int64_t *)(iVar34 + 0x78) + (uint64_t)(uStack_368 & 0x7ffff) * 4) << 0xc) >>
                 0xc;
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        iVar9 = func_0x000180120730(iVar12, iVar6);
        if (-1 < iVar9) {
            iVar34 = *(int64_t *)(iVar12 + 8);
            iVar23 = (int64_t)iVar9;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar23 + 2 + iVar34) * 0x100 +
                                      (uint16_t)*(uint8_t *)(iVar23 + 3 + iVar34));
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar23 + 9 + iVar34) +
                                       (uint16_t)*(uint8_t *)(iVar23 + 8 + iVar34) * 0x100);
            goto code_r0x00018012c9d5;
        }
        iStack_3b8 = 0;
        iStack_3b4 = 0;
    } else {
        uStack_3a0 = 1;
        auStack_398 = ZEXT816(0);
        uStack_378 = 0;
        _auStack_388 = ZEXT816(0);
        uStack_370 = 0;
        iVar37 = func_0x000180121980(iVar12, iVar6, &uStack_3a0);
        iVar9 = 0;
        iVar43 = 0;
        if (iVar37 != 0) {
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_37c;
        }
code_r0x00018012c9d5:
        fVar56 = (float)iVar9 * fVar64 + 0.0;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3b8 = (int32_t)(float)iVar9;
        fVar56 = 0.0 - (float)iVar43 * fVar47;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3b4 = (int32_t)(float)iVar9;
    }
    iVar34 = *(int64_t *)(iVar15 + 0x2b0);
    func_0x00018011f640(iVar34 + 0x80, uVar40 * uVar46);
    puVar27 = *(uint8_t **)(iVar34 + 0x88);
    func_0x0001804986e0(puVar27, 0, (int64_t)(int32_t)(uVar40 * uVar46));
    iVar6 = func_0x000180122810(iVar12, iVar6);
    if (*(int32_t *)(iVar12 + 0x4c) == 0) {
        iVar9 = func_0x000180120730(iVar12);
        if (-1 < iVar9) {
            iVar12 = *(int64_t *)(iVar12 + 8);
            iVar34 = (int64_t)iVar9;
            iVar9 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 3 + iVar12) +
                                      (uint16_t)*(uint8_t *)(iVar34 + 2 + iVar12) * 0x100);
            iVar43 = (int32_t)(int16_t)((uint16_t)*(uint8_t *)(iVar34 + 9 + iVar12) +
                                       (uint16_t)*(uint8_t *)(iVar34 + 8 + iVar12) * 0x100);
            goto code_r0x00018012cb2f;
        }
        iStack_3c0 = 0;
        iStack_3e0 = 0;
    } else {
        auStack_398 = ZEXT816(0);
        uStack_3a0 = 1;
        _auStack_388 = ZEXT816(0);
        uStack_378 = 0;
        uStack_370 = 0;
        iVar37 = func_0x000180121980();
        iVar9 = 0;
        iVar43 = 0;
        if (iVar37 != 0) {
            iVar9 = auStack_388._0_4_;
            iVar43 = iStack_37c;
        }
code_r0x00018012cb2f:
        fVar56 = (float)iVar9 * fVar64 + 0.0;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3c0 = (int32_t)(float)iVar9;
        fVar56 = 0.0 - (float)iVar43 * fVar47;
        iVar9 = (int32_t)fVar56;
        if ((fVar56 < 0.0) && ((float)iVar9 != fVar56)) {
            iVar9 = iVar9 + -1;
        }
        iStack_3e0 = (int32_t)(float)iVar9;
    }
    iVar9 = uVar40 - uVar7;
    iVar43 = uVar46 - (uint32_t)var_410h;
    if (iVar43 != -1) {
        uStack_e8 = CONCAT44(uStack_e8._4_4_, iVar9 + 1);
        if (iVar9 + 1 != 0) {
            uVar10 = 0;
            iVar37 = 0;
            uVar31 = 0;
            uVar40 = 0;
            fVar56 = fVar47;
            if (fVar64 <= fVar47) {
                fVar56 = fVar64;
            }
            if (0 < iVar6) {
                do {
                    uVar40 = uVar10 + 1;
                    if (*(char *)(uVar31 * 0xe + 0xc + stack0xfffffffffffffc08) != '\x01') {
                        uVar40 = uVar10;
                    }
                    uVar22 = (int32_t)uVar31 + 1;
                    uVar31 = (uint64_t)uVar22;
                    uVar10 = uVar40;
                } while ((int32_t)uVar22 < iVar6);
            }
            if ((uVar40 != 0) && (iVar12 = func_0x00018046d050((int64_t)(int32_t)uVar40 * 4), iVar12 != 0)) {
                iVar34 = 0;
                iStack_3e8 = 0;
                var_408h = 0;
                fVar56 = (0.35 / fVar56) * (0.35 / fVar56);
                do {
                    if ((var_408h == 1) && (iStack_3e8 = func_0x00018046d050((int64_t)iVar37 << 3), iStack_3e8 == 0)) {
                        fcn.180460d90(0);
                        goto code_r0x00018012cf0c;
                    }
                    iVar37 = 0;
                    iVar41 = 0;
                    iVar39 = 0;
                    iVar8 = -1;
                    if (0 < iVar6) {
                        iVar23 = 0;
                        iVar15 = stack0xfffffffffffffc08;
                        do {
                            iVar25 = iVar23 * 0xe;
                            cVar2 = *(char *)(iVar25 + 0xc + iVar15);
                            if (cVar2 == '\x01') {
                                if (-1 < iVar8) {
                                    *(int32_t *)(iVar12 + (int64_t)iVar8 * 4) = iVar37 - (int32_t)iVar34;
                                }
                                iVar8 = iVar8 + 1;
                                iVar34 = (int64_t)iVar37;
                                iVar33 = *(int16_t *)(iVar25 + 2 + iVar15);
                                iVar37 = iVar37 + 1;
                                iVar39 = iVar37;
                                if (iStack_3e8 != 0) {
                                    *(float *)(iStack_3e8 + iVar34 * 8) = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                    *(float *)(iStack_3e8 + 4 + iVar34 * 8) = (float)(int32_t)iVar33;
                                }
                            } else if (cVar2 == '\x02') {
                                iVar33 = *(int16_t *)(iVar25 + 2 + iVar15);
                                iVar13 = (int64_t)iVar37;
                                iVar37 = iVar37 + 1;
                                iVar39 = iVar37;
                                if (iStack_3e8 != 0) {
                                    *(float *)(iStack_3e8 + iVar13 * 8) = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                    *(float *)(iStack_3e8 + 4 + iVar13 * 8) = (float)(int32_t)iVar33;
                                }
                            } else if (cVar2 == '\x03') {
                                var_430h._0_4_ = 0.0;
                                var_440h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 2 + iVar15);
                                var_448h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                var_450h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 6 + iVar15);
                                var_458h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 4 + iVar15);
                                var_438h._0_4_ = fVar56;
                                iVar37 = iVar39;
                                func_0x000180122bd0(iStack_3e8);
                                iVar39 = iVar37;
                            } else if (cVar2 == '\x04') {
                                var_420h._0_4_ = 0;
                                var_430h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 2 + iVar15);
                                var_438h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + iVar15);
                                var_440h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 10 + iVar15);
                                var_448h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 8 + iVar15);
                                var_450h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 6 + iVar15);
                                var_458h._0_4_ = (float)(int32_t)*(int16_t *)(iVar25 + 4 + iVar15);
                                var_428h._0_4_ = fVar56;
                                iVar37 = iVar39;
                                func_0x000180122dd0(iStack_3e8);
                                iVar15 = stack0xfffffffffffffc08;
                                iVar39 = iVar37;
                            }
                            iVar41 = iVar41 + 1;
                            iVar23 = iVar23 + 1;
                        } while (iVar41 < iVar6);
                    }
                    *(int32_t *)(iVar12 + (int64_t)iVar8 * 4) = iVar37 - (int32_t)iVar34;
                    var_408h = var_408h + 1;
                } while (var_408h < 2);
                if (iStack_3e8 != 0) {
                    if (0 < (int32_t)uVar40) {
                        iVar37 = 0;
                        iVar6 = 0;
                        if (7 < uVar40) {
                            uVar10 = uVar40 & 0x80000007;
                            if ((int32_t)uVar10 < 0) {
                                uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                            }
                            do {
                                iVar37 = iVar37 + 8;
                            } while (iVar37 < (int32_t)(uVar40 - uVar10));
                            iVar6 = iVar37;
                            if ((int32_t)uVar40 <= iVar37) goto code_r0x00018012d11d;
                        }
                        if (1 < (int32_t)(uVar40 - iVar6)) {
                            do {
                                iVar6 = iVar6 + 2;
                            } while (iVar6 < (int32_t)(uVar40 - 1));
                        }
                    }
code_r0x00018012d11d:
                    uVar10 = uVar40;
                    iStack_358 = iVar12;
                    pfVar14 = (float *)func_0x00018046d050();
                    pfStack_308 = pfVar14;
                    if (pfVar14 != (float *)0x0) {
                        iVar6 = 0;
                        iVar39 = 0;
                        iVar37 = 0;
                        if (0 < (int32_t)uVar40) {
                            do {
                                iVar34 = iStack_3e8 + (int64_t)iVar39 * 8;
                                iVar8 = *(int32_t *)(iVar12 + (int64_t)iVar37 * 4);
                                iVar39 = iVar39 + iVar8;
                                iVar41 = iVar8 + -1;
                                iVar35 = 0;
                                if (0 < iVar8) {
                                    do {
                                        if (*(float *)(iVar34 + 4 + (int64_t)iVar41 * 8) !=
                                            *(float *)(iVar34 + 4 + (int64_t)iVar35 * 8)) {
                                            iVar15 = (int64_t)iVar6;
                                            pfVar14[iVar15 * 5 + 4] = 0.0;
                                            fVar56 = *(float *)(iVar34 + 4 + (int64_t)iVar41 * 8);
                                            pfVar30 = (float *)(iVar34 + 4 + (int64_t)iVar35 * 8);
                                            iVar8 = iVar35;
                                            if (*pfVar30 <= fVar56 && fVar56 != *pfVar30) {
                                                pfVar14[iVar15 * 5 + 4] = 1.401298e-45;
                                                iVar8 = iVar41;
                                                iVar41 = iVar35;
                                            }
                                            iVar6 = iVar6 + 1;
                                            pfVar14[iVar15 * 5] = fVar64 * *(float *)(iVar34 + (int64_t)iVar8 * 8) + 0.0
                                            ;
                                            pfVar14[iVar15 * 5 + 1] =
                                                 (float)((uint32_t)fVar47 ^ 0x80000000) *
                                                 *(float *)(iVar34 + 4 + (int64_t)iVar8 * 8) + 0.0;
                                            pfVar14[iVar15 * 5 + 2] =
                                                 fVar64 * *(float *)(iVar34 + (int64_t)iVar41 * 8) + 0.0;
                                            pfVar14[iVar15 * 5 + 3] =
                                                 (float)((uint32_t)fVar47 ^ 0x80000000) *
                                                 *(float *)(iVar34 + 4 + (int64_t)iVar41 * 8) + 0.0;
                                        }
                                        iVar8 = iVar35 + 1;
                                        uVar40 = uVar10;
                                        iVar41 = iVar35;
                                        iVar35 = iVar8;
                                    } while (iVar8 < *(int32_t *)(iVar12 + (int64_t)iVar37 * 4));
                                }
                                iVar37 = iVar37 + 1;
                            } while (iVar37 < (int32_t)uVar40);
                        }
                        func_0x000180122a30(pfVar14, iVar6);
                        uVar31 = 1;
                        pppppppiVar29 = (int64_t *******)0x0;
                        if (1 < iVar6) {
                            do {
                                uVar40 = (uint32_t)uVar31;
                                fVar56 = pfVar14[uVar31 * 5];
                                fVar47 = pfVar14[uVar31 * 5 + 1];
                                uVar1 = *(undefined8 *)(pfVar14 + uVar31 * 5 + 2);
                                fVar64 = pfVar14[uVar31 * 5 + 4];
                                if (uVar40 < 4) goto code_r0x00018012d37c;
                                do {
                                    uVar10 = (uint32_t)uVar31;
                                    if (pfVar14[uVar31 * 5 + -4] <= fVar47) goto code_r0x00018012d3b6;
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    fVar57 = pfVar45[1];
                                    fVar59 = pfVar45[2];
                                    fVar53 = pfVar45[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -1];
                                    pfVar30 = pfVar14 + uVar31 * 5;
                                    *pfVar30 = *pfVar45;
                                    pfVar30[1] = fVar57;
                                    pfVar30[2] = fVar59;
                                    pfVar30[3] = fVar53;
                                    pfVar14[uVar31 * 5 + 4] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -9] <= fVar47) {
                                        uVar10 = uVar10 - 1;
                                        goto code_r0x00018012d3b6;
                                    }
                                    pfVar30 = pfVar14 + uVar31 * 5 + -10;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -6];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -1] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -0xe] <= fVar47) {
                                        uVar10 = uVar10 - 2;
                                        goto code_r0x00018012d3b6;
                                    }
                                    pfVar30 = pfVar14 + uVar31 * 5 + -0xf;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -0xb];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -10;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -6] = fVar51;
                                    if (pfVar14[uVar31 * 5 + -0x13] <= fVar47) {
                                        uVar10 = uVar10 - 3;
                                        goto code_r0x00018012d3b6;
                                    }
                                    fVar51 = pfVar14[uVar31 * 5 + -0x10];
                                    uVar10 = uVar10 - 4;
                                    pfVar30 = pfVar14 + uVar31 * 5 + -0x14;
                                    fVar57 = pfVar30[1];
                                    fVar59 = pfVar30[2];
                                    fVar53 = pfVar30[3];
                                    pfVar45 = pfVar14 + uVar31 * 5 + -0xf;
                                    *pfVar45 = *pfVar30;
                                    pfVar45[1] = fVar57;
                                    pfVar45[2] = fVar59;
                                    pfVar45[3] = fVar53;
                                    pfVar14[uVar31 * 5 + -0xb] = fVar51;
                                    uVar31 = (uint64_t)uVar10;
                                } while (3 < (int32_t)uVar10);
                                while (0 < (int32_t)uVar10) {
code_r0x00018012d37c:
                                    uVar10 = (uint32_t)uVar31;
                                    if (pfVar14[uVar31 * 5 + -4] <= fVar47) break;
                                    pfVar45 = pfVar14 + uVar31 * 5 + -5;
                                    fVar57 = pfVar45[1];
                                    fVar59 = pfVar45[2];
                                    fVar53 = pfVar45[3];
                                    fVar51 = pfVar14[uVar31 * 5 + -1];
                                    uVar10 = uVar10 - 1;
                                    pfVar30 = pfVar14 + uVar31 * 5;
                                    *pfVar30 = *pfVar45;
                                    pfVar30[1] = fVar57;
                                    pfVar30[2] = fVar59;
                                    pfVar30[3] = fVar53;
                                    pfVar14[uVar31 * 5 + 4] = fVar51;
                                    uVar31 = (uint64_t)uVar10;
                                }
code_r0x00018012d3b6:
                                if (uVar40 != uVar10) {
                                    iVar12 = (int64_t)(int32_t)uVar10;
                                    *(undefined8 *)(pfVar14 + iVar12 * 5 + 2) = uVar1;
                                    pfVar14[iVar12 * 5 + 4] = fVar64;
                                    pfVar14[iVar12 * 5 + 1] = fVar47;
                                    pfVar14[iVar12 * 5] = fVar56;
                                }
                                uVar31 = (uint64_t)(uVar40 + 1);
                            } while ((int32_t)(uVar40 + 1) < iVar6);
                        }
                        puStack_360 = (undefined8 *)0x0;
                        uVar40 = 0;
                        pppppppiStack_3b0 = (int64_t *******)0x0;
                        var_408h = 0;
                        iVar37 = iVar43 + 1;
                        pfStack_338 = pfVar14;
                        if (iVar37 < 0x41) {
                            puVar16 = auStack_2f8;
                        } else {
                            puVar16 = (undefined *)func_0x00018046d050((int64_t)(iVar37 * 2 + 1) << 2);
                        }
                        iStack_310 = (int64_t)iVar37 * 4;
                        puVar42 = puVar16 + iStack_310;
                        pfVar14[(int64_t)iVar6 * 5 + 1] = (float)(iStack_3e0 + (int32_t)uStack_e8) + 1.0;
                        puVar26 = puStack_360;
                        puStack_340 = puVar16;
                        puStack_318 = puVar42;
                        pfVar30 = pfVar14;
                        if (0 < (int32_t)uStack_e8) {
                            iStack_320 = (int64_t)(iVar43 + 2) << 2;
                            iVar37 = 0;
                            pppppppiVar44 = pppppppiVar29;
                            pppppppiVar21 = pppppppiVar29;
                            auVar60 = *(undefined (*) [16])0x180646c10;
                            iVar6 = iStack_3e0;
                            do {
                                fVar47 = (float)iVar6 + 1.0;
                                fVar56 = (float)iVar6 + 0.0;
                                func_0x0001804986e0(puVar16, 0, iStack_310);
                                func_0x0001804986e0(puVar42, 0, iStack_320);
                                pppppppiVar20 = pppppppiVar21;
                                if (pppppppiVar21 != (int64_t *******)0x0) {
                                    pppppppiVar18 = (int64_t *******)&pppppppiStack_3b0;
                                    do {
                                        pppppppiVar20 = pppppppiVar21;
                                        if (*(float *)((int64_t)pppppppiVar21 + 0x1c) <= fVar56) {
                                            *pppppppiVar18 = *pppppppiVar21;
                                            *pppppppiVar21 = (int64_t ******)pppppppiVar44;
                                            *(undefined4 *)((int64_t)pppppppiVar21 + 0x14) = 0;
                                            pppppppiVar20 = pppppppiVar18;
                                            pppppppiVar44 = pppppppiVar21;
                                        }
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar20;
                                        pppppppiVar18 = pppppppiVar20;
                                        pppppppiVar20 = pppppppiStack_3b0;
                                    } while (pppppppiVar21 != (int64_t *******)0x0);
                                }
                                puVar26 = puStack_360;
                                if (pfVar14[1] <= fVar47) {
                                    do {
                                        iVar39 = (int32_t)pppppppiVar29;
                                        if (pfVar14[1] != pfVar14[3]) {
                                            puVar17 = puVar26;
                                            if (pppppppiVar44 == (int64_t *******)0x0) {
                                                if (iVar39 == 0) {
                                                    puVar17 = (undefined8 *)func_0x00018046d050(0x6408);
                                                    if (puVar17 == (undefined8 *)0x0) goto code_r0x00018012d652;
                                                    *puVar17 = puVar26;
                                                    iVar39 = 800;
                                                }
                                                pppppppiVar29 = (int64_t *******)(uint64_t)(iVar39 - 1U);
                                                pppppppiVar21 =
                                                     (int64_t *******)
                                                     (puVar17 + (int64_t)(int32_t)(iVar39 - 1U) * 4 + 1);
                                                puVar26 = puVar17;
                                                if (pppppppiVar21 == (int64_t *******)0x0) goto code_r0x00018012d652;
                                            } else {
                                                pppppppiVar21 = pppppppiVar44;
                                                pppppppiVar44 = (int64_t *******)*pppppppiVar44;
                                            }
                                            fVar64 = (pfVar14[2] - *pfVar14) / (pfVar14[3] - pfVar14[1]);
                                            *(float *)((int64_t)pppppppiVar21 + 0xc) = fVar64;
                                            if (fVar64 == 0.0) {
                                                fVar51 = 0.0;
                                            } else {
                                                fVar51 = 1.0 / fVar64;
                                            }
                                            *(float *)(pppppppiVar21 + 2) = fVar51;
                                            *(float *)(pppppppiVar21 + 1) =
                                                 ((fVar56 - pfVar14[1]) * fVar64 + *pfVar14) - (float)iStack_3c0;
                                            uVar48 = 0xbf800000;
                                            if (pfVar14[4] != 0.0) {
                                                uVar48 = 0x3f800000;
                                            }
                                            *(undefined4 *)((int64_t)pppppppiVar21 + 0x14) = uVar48;
                                            *(float *)(pppppppiVar21 + 3) = pfVar14[1];
                                            fVar64 = pfVar14[3];
                                            *(float *)((int64_t)pppppppiVar21 + 0x1c) = fVar64;
                                            if (((var_408h == 0) && (iStack_3e0 != 0)) && (fVar64 < fVar56)) {
                                                *(float *)((int64_t)pppppppiVar21 + 0x1c) = fVar56;
                                            }
                                            *pppppppiVar21 = (int64_t ******)pppppppiVar20;
                                            pppppppiStack_3b0 = pppppppiVar21;
                                            puVar26 = puVar17;
                                            pppppppiVar20 = pppppppiVar21;
                                        }
code_r0x00018012d652:
                                        pfVar45 = pfVar14 + 5;
                                        pfVar30 = pfVar14 + 6;
                                        pfVar14 = pfVar45;
                                    } while (*pfVar30 <= fVar47);
                                    puStack_360 = puVar26;
                                    uVar40 = (uint32_t)pppppppiVar29;
                                    pfStack_338 = pfVar45;
                                    puVar16 = puStack_340;
                                    puVar42 = puStack_318;
                                }
                                iVar39 = iVar43 + 1;
                                if (pppppppiVar20 != (int64_t *******)0x0) {
                                    fVar47 = fVar56 + 1.0;
                                    pppppppiVar21 = pppppppiVar20;
                                    do {
                                        fVar64 = *(float *)((int64_t)pppppppiVar21 + 0xc);
                                        fVar51 = *(float *)(pppppppiVar21 + 1);
                                        if (fVar64 == 0.0) {
                                            if (fVar51 < (float)iVar39) {
                                                var_450h._0_4_ = fVar51;
                                                if (fVar51 < 0.0) {
                                                    var_458h._0_4_ = fVar56;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar42);
                                                } else {
                                                    var_458h._0_4_ = fVar56;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar16);
                                                    var_458h._0_4_ = fVar56;
                                                    var_450h._0_4_ = fVar51;
                                                    var_448h._0_4_ = fVar47;
                                                    func_0x0001801228f0(puVar42);
                                                }
                                            }
                                        } else {
                                            fVar57 = *(float *)(pppppppiVar21 + 3);
                                            fVar65 = fVar64 + fVar51;
                                            fVar59 = fVar56;
                                            fVar53 = fVar51;
                                            if (fVar56 < fVar57) {
                                                fVar59 = fVar57;
                                                fVar53 = (fVar57 - fVar56) * fVar64 + fVar51;
                                            }
                                            fVar57 = *(float *)((int64_t)pppppppiVar21 + 0x1c);
                                            fVar49 = fVar47;
                                            fVar63 = fVar65;
                                            if (fVar57 < fVar47) {
                                                fVar49 = fVar57;
                                                fVar63 = (fVar57 - fVar56) * fVar64 + fVar51;
                                            }
                                            if (((fVar53 < 0.0) || (fVar63 < 0.0)) ||
                                               (((float)iVar39 <= fVar53 || ((float)iVar39 <= fVar63)))) {
                                                uVar31 = 0;
                                                if (0 < iVar39) {
                                                    do {
                                                        uVar10 = (int32_t)uVar31 + 1;
                                                        uVar36 = (uint64_t)uVar10;
                                                        fVar53 = (float)(int32_t)uVar31;
                                                        fVar57 = (float)uVar10;
                                                        fVar49 = (fVar53 - fVar51) / fVar64 + fVar56;
                                                        fVar59 = (fVar57 - fVar51) / fVar64 + fVar56;
                                                        var_450h._0_4_ = fVar53;
                                                        var_448h._0_4_ = fVar49;
                                                        if ((fVar53 <= fVar51) || (fVar65 <= fVar57)) {
                                                            if ((fVar53 <= fVar65) || (fVar51 <= fVar57)) {
                                                                if (((fVar51 < fVar53) && (fVar53 < fVar65)) ||
                                                                   ((fVar65 < fVar53 && (fVar53 < fVar51)))) {
                                                                    var_458h._0_4_ = fVar56;
                                                                    func_0x0001801228f0(puVar16);
                                                                    var_458h._0_4_ = fVar49;
                                                                } else if (((fVar51 < fVar57) && (fVar57 < fVar65)) ||
                                                                          ((var_458h._0_4_ = fVar56, fVar65 < fVar57 &&
                                                                           (fVar57 < fVar51)))) {
                                                                    var_458h._0_4_ = fVar56;
                                                                    var_450h._0_4_ = fVar57;
                                                                    var_448h._0_4_ = fVar59;
                                                                    func_0x0001801228f0(puVar16);
                                                                    var_458h._0_4_ = fVar59;
                                                                }
                                                            } else {
                                                                var_458h._0_4_ = fVar56;
                                                                var_450h._0_4_ = fVar57;
                                                                var_448h._0_4_ = fVar59;
                                                                func_0x0001801228f0(puVar16);
                                                                var_458h._0_4_ = fVar59;
                                                                var_450h._0_4_ = fVar53;
                                                                var_448h._0_4_ = fVar49;
                                                                func_0x0001801228f0();
                                                                var_458h._0_4_ = fVar49;
                                                            }
                                                        } else {
                                                            var_458h._0_4_ = fVar56;
                                                            func_0x0001801228f0(puVar16);
                                                            var_458h._0_4_ = fVar49;
                                                            var_450h._0_4_ = fVar57;
                                                            var_448h._0_4_ = fVar59;
                                                            func_0x0001801228f0();
                                                            var_458h._0_4_ = fVar59;
                                                        }
                                                        var_450h._0_4_ = fVar65;
                                                        var_448h._0_4_ = fVar47;
                                                        func_0x0001801228f0(puVar16);
                                                        uVar31 = uVar36 & 0xffffffff;
                                                    } while ((int32_t)uVar36 < iVar39);
                                                }
                                            } else {
                                                iVar8 = (int32_t)fVar53;
                                                if (iVar8 == (int32_t)fVar63) {
                                                    iVar12 = (int64_t)iVar8;
                                                    fVar64 = (fVar49 - fVar59) *
                                                             *(float *)((int64_t)pppppppiVar21 + 0x14);
                                                    *(float *)(puVar16 + iVar12 * 4) =
                                                         ((((float)iVar8 + 1.0) - fVar63) +
                                                         (((float)iVar8 + 1.0) - fVar53)) * 0.5 * fVar64 +
                                                         *(float *)(puVar16 + iVar12 * 4);
                                                    *(float *)(puVar42 + iVar12 * 4 + 4) =
                                                         fVar64 + *(float *)(puVar42 + iVar12 * 4 + 4);
                                                } else {
                                                    fVar64 = *(float *)(pppppppiVar21 + 2);
                                                    fVar57 = fVar63;
                                                    if (fVar63 < fVar53) {
                                                        fVar51 = fVar49 - fVar56;
                                                        fVar64 = (float)((uint32_t)fVar64 ^ 0x80000000);
                                                        fVar49 = fVar47 - (fVar59 - fVar56);
                                                        fVar59 = fVar47 - fVar51;
                                                        fVar51 = fVar65;
                                                        fVar57 = fVar53;
                                                        fVar53 = fVar63;
                                                    }
                                                    fVar65 = *(float *)((int64_t)pppppppiVar21 + 0x14);
                                                    iVar35 = (int32_t)fVar53;
                                                    iVar41 = (int32_t)fVar57;
                                                    iVar8 = iVar35 + 1;
                                                    fVar66 = (float)iVar41;
                                                    fVar50 = ((float)iVar8 - fVar51) * fVar64 + fVar56;
                                                    fVar63 = (fVar66 - fVar51) * fVar64 + fVar56;
                                                    fVar51 = fVar47;
                                                    if (fVar50 <= fVar47) {
                                                        fVar51 = fVar50;
                                                    }
                                                    fVar50 = (fVar51 - fVar59) * fVar65;
                                                    *(float *)(puVar16 + (int64_t)iVar35 * 4) =
                                                         ((float)iVar8 - fVar53) * fVar50 * 0.5 +
                                                         *(float *)(puVar16 + (int64_t)iVar35 * 4);
                                                    if ((fVar47 < fVar63) &&
                                                       (iVar35 = (iVar41 - iVar35) + -1, fVar63 = fVar47, iVar35 != 0))
                                                    {
                                                        fVar64 = (fVar47 - fVar51) / (float)iVar35;
                                                    }
                                                    if (iVar8 < iVar41) {
                                                        fVar64 = fVar64 * fVar65;
                                                        fVar51 = fVar64 * 0.5;
                                                        if (3 < iVar41 - iVar8) {
                                                            do {
                                                                iVar12 = (int64_t)iVar8;
                                                                iVar8 = iVar8 + 4;
                                                                *(float *)(puVar16 + iVar12 * 4) =
                                                                     fVar50 + fVar51 + *(float *)(puVar16 + iVar12 * 4);
                                                                fVar53 = fVar50 + fVar64 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 4) =
                                                                     fVar51 + fVar50 + fVar64 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 4);
                                                                fVar54 = fVar53 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 8) =
                                                                     fVar51 + fVar53 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 8);
                                                                fVar50 = fVar54 + fVar64;
                                                                *(float *)(puVar16 + iVar12 * 4 + 0xc) =
                                                                     fVar51 + fVar54 +
                                                                     *(float *)(puVar16 + iVar12 * 4 + 0xc);
                                                            } while (iVar8 < iVar41 + -3);
                                                        }
                                                        for (; iVar8 < iVar41; iVar8 = iVar8 + 1) {
                                                            fVar53 = fVar50 + fVar51;
                                                            fVar50 = fVar50 + fVar64;
                                                            *(float *)(puVar16 + (int64_t)iVar8 * 4) =
                                                                 fVar53 + *(float *)(puVar16 + (int64_t)iVar8 * 4);
                                                        }
                                                    }
                                                    iVar12 = (int64_t)iVar41;
                                                    *(float *)(puVar16 + iVar12 * 4) =
                                                         (((fVar66 + 1.0) - fVar57) + ((fVar66 + 1.0) - fVar66)) * 0.5 *
                                                         (fVar49 - fVar63) * fVar65 + fVar50 +
                                                         *(float *)(puVar16 + iVar12 * 4);
                                                    *(float *)(puVar42 + iVar12 * 4 + 4) =
                                                         (fVar49 - fVar59) * fVar65 +
                                                         *(float *)(puVar42 + iVar12 * 4 + 4);
                                                }
                                            }
                                        }
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar21;
                                        auVar60 = *(undefined (*) [16])0x180646c10;
                                    } while (pppppppiVar21 != (int64_t *******)0x0);
                                }
                                iVar8 = 0;
                                auVar52._0_12_ = ZEXT812(0);
                                auVar52._12_4_ = 0;
                                uVar10 = auVar60._0_4_;
                                if (iVar39 < 4) {
                                    if (0 < iVar39) goto code_r0x00018012dce2;
                                } else {
                                    do {
                                        iVar34 = (int64_t)iVar8;
                                        iVar12 = (int64_t)(iVar8 + iVar37);
                                        fVar47 = auVar52._0_4_ + *(float *)(puVar42 + iVar34 * 4);
                                        iVar39 = (int32_t)((float)((uint32_t)(fVar47 + *(float *)(puVar16 + iVar34 * 4))
                                                                  & uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12] = uVar19;
                                        fVar47 = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 4);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (fVar47 + *(float *)(puVar16 + iVar34 * 4 + 4)) &
                                                                  uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12 + 1] = uVar19;
                                        fVar47 = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 8);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (fVar47 + *(float *)(puVar16 + iVar34 * 4 + 8)) &
                                                                  uVar10) * 255.0 + 0.5);
                                        uVar19 = (uint8_t)iVar39;
                                        if (0xff < iVar39) {
                                            uVar19 = 0xff;
                                        }
                                        puVar27[iVar12 + 2] = uVar19;
                                        auVar52._0_4_ = fVar47 + *(float *)(puVar42 + iVar34 * 4 + 0xc);
                                        iVar39 = (int32_t)((float)((uint32_t)
                                                                   (auVar52._0_4_ +
                                                                   *(float *)(puVar16 + iVar34 * 4 + 0xc)) & uVar10) *
                                                           255.0 + 0.5);
                                        if (0xff < iVar39) {
                                            iVar39 = 0xff;
                                        }
                                        iVar8 = iVar8 + 4;
                                        puVar27[iVar12 + 3] = (uint8_t)iVar39;
                                    } while (iVar8 < iVar43 + -2);
                                    pppppppiVar29 = (int64_t *******)(uint64_t)uVar40;
                                    if (iVar8 < iVar43 + 1) {
code_r0x00018012dce2:
                                        do {
                                            auVar52._0_4_ = auVar52._0_4_ + *(float *)(puVar42 + (int64_t)iVar8 * 4);
                                            iVar39 = iVar37 + iVar8;
                                            iVar41 = (int32_t)((float)((uint32_t)
                                                                       (auVar52._0_4_ +
                                                                       *(float *)(puVar16 + (int64_t)iVar8 * 4)) &
                                                                      uVar10) * 255.0 + 0.5);
                                            if (0xff < iVar41) {
                                                iVar41 = 0xff;
                                            }
                                            iVar8 = iVar8 + 1;
                                            puVar27[iVar39] = (uint8_t)iVar41;
                                        } while (iVar8 < iVar43 + 1);
                                        pppppppiVar29 = (int64_t *******)(uint64_t)uVar40;
                                        pfVar14 = pfStack_338;
                                    }
                                }
                                if (pppppppiVar20 != (int64_t *******)0x0) {
                                    pppppppiVar21 = (int64_t *******)&pppppppiStack_3b0;
                                    pppppppiVar18 = pppppppiVar20;
                                    do {
                                        *(float *)(pppppppiVar18 + 1) =
                                             *(float *)((int64_t)pppppppiVar18 + 0xc) + *(float *)(pppppppiVar18 + 1);
                                        pppppppiVar21 = (int64_t *******)*pppppppiVar21;
                                        pppppppiVar18 = (int64_t *******)*pppppppiVar21;
                                    } while (pppppppiVar18 != (int64_t *******)0x0);
                                }
                                iVar6 = iVar6 + 1;
                                iVar37 = iVar37 + uVar46;
                                var_408h = var_408h + 1;
                                pppppppiVar21 = pppppppiVar20;
                                puVar26 = puStack_360;
                                pfVar30 = pfStack_308;
                            } while (var_408h < (int32_t)uStack_e8);
                        }
                        while (puVar26 != (undefined8 *)0x0) {
                            puVar17 = (undefined8 *)*puVar26;
                            fcn.180460d90(puVar26);
                            puVar26 = puVar17;
                        }
                        if (puVar16 != auStack_2f8) {
                            fcn.180460d90(puVar16);
                        }
                        fcn.180460d90(pfVar30);
                        iVar12 = iStack_358;
                    }
                    fcn.180460d90(iVar12);
                    iVar12 = iStack_3e8;
code_r0x00018012cf0c:
                    fcn.180460d90(iVar12);
                }
            }
        }
    }
    fcn.180460d90(stack0xfffffffffffffc08);
    uVar40 = uVar11;
    puVar28 = puVar27;
    if (1 < (int32_t)(uint32_t)var_410h) {
        iVar6 = 0;
        uStack_e8 = 0;
        if (0 < (int32_t)uVar11) {
            do {
                func_0x0001804986e0(&uStack_e8, 0, (uint32_t)var_410h);
                uVar36 = 0;
                uVar31 = 0;
                if ((uint32_t)var_410h == 2) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 + 2;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 >> 1);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else if ((uint32_t)var_410h == 3) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 + 3;
                            uVar36 = (uint64_t)
                                     ((int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7))));
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar36 / 3);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else if ((uint32_t)var_410h == 4) {
                    uVar22 = 0;
                    uVar10 = 0;
                    if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar22;
                            iVar12 = (int64_t)(int32_t)uVar22;
                            uVar10 = uVar22 - 4;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar22 = uVar22 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 >> 2);
                            uVar31 = uVar36;
                            uVar10 = uVar22;
                        } while ((int32_t)uVar22 <= iVar43);
                    }
                } else {
                    uVar10 = 0;
                    uVar31 = uVar36;
                    if ((uint32_t)var_410h == 5) {
                        if (-1 < iVar43) {
                            do {
                                iVar12 = (int64_t)(int32_t)uVar10;
                                iVar34 = (int64_t)(int32_t)uVar10;
                                uVar22 = uVar10 - 3;
                                uVar36 = (uint64_t)
                                         ((int32_t)uVar36 +
                                         ((uint32_t)puVar27[iVar12] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)) = puVar27[iVar12];
                                puVar27[iVar34] = (uint8_t)(uVar36 / 5);
                                uVar31 = uVar36;
                            } while ((int32_t)uVar10 <= iVar43);
                        }
                    } else if (-1 < iVar43) {
                        do {
                            iVar34 = (int64_t)(int32_t)uVar10;
                            iVar12 = (int64_t)(int32_t)uVar10;
                            uVar22 = uVar10 + (uint32_t)var_410h;
                            uVar38 = (int32_t)uVar36 +
                                     ((uint32_t)puVar27[iVar34] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar38;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar22 & 7)) = puVar27[iVar34];
                            puVar27[iVar12] = (uint8_t)(uVar38 / (uint32_t)var_410h);
                            uVar31 = uVar36;
                        } while ((int32_t)uVar10 <= iVar43);
                    }
                }
                for (; (int32_t)uVar10 < (int32_t)uVar46; uVar10 = uVar10 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar22 = (int32_t)uVar31 - (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7));
                    puVar27[(int32_t)uVar10] = (uint8_t)(uVar22 / (uint32_t)var_410h);
                    uVar31 = (uint64_t)uVar22;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                puVar27 = puVar27 + (int32_t)uVar46;
                iVar6 = iVar6 + 1;
            } while (iVar6 < (int32_t)uVar11);
        }
    }
    puVar27 = puVar28;
    if (1 < (int32_t)uVar7) {
        iVar6 = 0;
        uStack_e8 = 0;
        if (0 < (int32_t)uVar46) {
            do {
                func_0x0001804986e0(&uStack_e8, 0, uVar7);
                uVar36 = 0;
                uVar31 = 0;
                if (uVar7 == 2) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar22 = (int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar22;
                            uVar11 = uVar10 + 2;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar22 >> 1);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else if (uVar7 == 3) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar36 = (uint64_t)
                                     ((int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                            uVar11 = uVar10 + 3;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar36 / 3);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else if (uVar7 == 4) {
                    uVar10 = 0;
                    uVar11 = 0;
                    if (-1 < iVar9) {
                        do {
                            iVar43 = uVar10 * uVar46;
                            uVar22 = (int32_t)uVar36 +
                                     ((uint32_t)puVar28[iVar43] -
                                     (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                            uVar36 = (uint64_t)uVar22;
                            uVar11 = uVar10 - 4;
                            uVar10 = uVar10 + 1;
                            *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                            puVar28[iVar43] = (uint8_t)(uVar22 >> 2);
                            uVar31 = uVar36;
                            uVar11 = uVar10;
                        } while ((int32_t)uVar10 <= iVar9);
                    }
                } else {
                    uVar10 = 0;
                    uVar31 = uVar36;
                    if (uVar7 == 5) {
                        uVar11 = 0;
                        if (-1 < iVar9) {
                            do {
                                iVar43 = uVar10 * uVar46;
                                uVar36 = (uint64_t)
                                         ((int32_t)uVar36 +
                                         ((uint32_t)puVar28[iVar43] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7))));
                                uVar11 = uVar10 - 3;
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                                puVar28[iVar43] = (uint8_t)(uVar36 / 5);
                                uVar31 = uVar36;
                                uVar11 = uVar10;
                            } while ((int32_t)uVar10 <= iVar9);
                        }
                    } else {
                        uVar11 = uVar10;
                        if (-1 < iVar9) {
                            do {
                                iVar43 = uVar10 * uVar46;
                                uVar22 = (int32_t)uVar36 +
                                         ((uint32_t)puVar28[iVar43] -
                                         (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar10 & 7)));
                                uVar36 = (uint64_t)uVar22;
                                uVar11 = uVar10 + uVar7;
                                uVar10 = uVar10 + 1;
                                *(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7)) = puVar28[iVar43];
                                puVar28[iVar43] = (uint8_t)(uVar22 / uVar7);
                                uVar31 = uVar36;
                                uVar11 = uVar10;
                            } while ((int32_t)uVar10 <= iVar9);
                        }
                    }
                }
                for (; (int32_t)uVar11 < (int32_t)uVar40; uVar11 = uVar11 + 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar10 = (int32_t)uVar31 - (uint32_t)*(uint8_t *)((int64_t)&uStack_e8 + (uint64_t)(uVar11 & 7));
                    puVar28[(int32_t)(uVar11 * uVar46)] = (uint8_t)(uVar10 / uVar7);
                    uVar31 = (uint64_t)uVar10;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                puVar28 = puVar28 + 1;
                iVar6 = iVar6 + 1;
            } while (iVar6 < (int32_t)uVar46);
        }
    }
    if ((uint32_t)var_410h == 0) {
        fVar47 = 0.0;
    } else {
        fVar47 = (float)(1 - (uint32_t)var_410h) / (fVar62 + fVar62);
    }
    if (uVar7 == 0) {
        fVar56 = 0.0;
    } else {
        fVar56 = (float)(1 - uVar7) / (fVar61 + fVar61);
    }
    fVar64 = *(float *)(**(int64_t **)(*(int64_t *)(iStack_300 + 0x58) + 0x28) + 0x3c);
    if (fVar64 == 0.0) {
        auVar55 = ZEXT812(0x3f800000);
    } else {
        auVar55._4_8_ = 0;
        auVar55._0_4_ = *(float *)(iStack_300 + 0x14) / fVar64;
    }
    auVar5._4_8_ = auVar55._4_8_;
    auVar5._0_4_ = auVar55._0_4_ * *(float *)(iStack_328 + 0x50) + 0.5;
    iVar12 = iStack_300;
    fVar64 = (float)func_0x0001800f4120(auVar5._0_8_);
    fVar64 = fVar64 + fVar47;
    fVar47 = (float)func_0x0001800f4120();
    iVar34 = iStack_348;
    fVar62 = 1.0 / (fVar62 * fVar58);
    fVar47 = fVar47 + (float)(int32_t)(*(float *)(iVar12 + 0x44) + 0.5) + fVar56;
    fVar56 = 1.0 / (fVar61 * fVar58);
    puStack_330[2] = (uint32_t)((float)iStack_3b8 * fVar62 + fVar64);
    puStack_330[3] = (uint32_t)((float)iStack_3b4 * fVar56 + fVar47);
    puStack_330[4] =
         (uint32_t)((float)((uint32_t)*(uint16_t *)(pfStack_3a8 + iStack_348 * 2 + 1) + iStack_3b8) * fVar62 + fVar64);
    uVar3 = *(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 6);
    *puStack_330 = *puStack_330 | 2;
    puStack_330[10] = uStack_368;
    puStack_330[5] = (uint32_t)((float)((uint32_t)uVar3 + iStack_3b4) * fVar56 + fVar47);
    iVar12 = *(int64_t *)(iStack_350 + 0x38);
    uVar3 = *(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 6);
    uVar7 = (uint32_t)uVar3;
    iVar6 = *(int32_t *)(iVar12 + 0x24) * *(int32_t *)(iVar12 + 0x1c);
    uVar4 = *(uint16_t *)(pfStack_3a8 + iStack_348 * 2 + 1);
    puVar32 = (uint32_t *)
              ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iStack_348 * 8 + 2) *
                                   *(int32_t *)(iVar12 + 0x1c) + (uint32_t)*(uint16_t *)(pfStack_3a8 + iStack_348 * 2))
                                 * *(int32_t *)(iVar12 + 0x24)) + *(int64_t *)(iVar12 + 0x28));
    iStack_348 = iVar12;
    if (*(int32_t *)(iVar12 + 0x18) == 1) {
        if (uVar3 != 0) {
            do {
                func_0x000180498030(puVar32, puVar27, (uint32_t)uVar4);
                uVar7 = uVar7 - 1;
                puVar27 = puVar27 + (int32_t)uVar46;
                puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
            } while (0 < (int32_t)uVar7);
        }
    } else if ((*(int32_t *)(iVar12 + 0x18) == 0) && (uVar7 != 0)) {
        do {
            puVar28 = puVar27;
            puVar24 = puVar32;
            uVar11 = (uint32_t)uVar4;
            if (uVar4 != 0) {
                do {
                    uVar19 = *puVar28;
                    puVar28 = puVar28 + 1;
                    uVar11 = uVar11 - 1;
                    *puVar24 = (uint32_t)uVar19 << 0x18 | 0xffffff;
                    puVar24 = puVar24 + 1;
                } while (0 < (int32_t)uVar11);
            }
            uVar7 = uVar7 - 1;
            puVar27 = puVar27 + (int32_t)uVar46;
            puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
        } while (0 < (int32_t)uVar7);
    }
    uVar3 = *(uint16_t *)(pfStack_3a8 + iVar34 * 2 + 1);
    fVar47 = *(float *)(iStack_328 + 0x6c);
    if (fVar47 != 1.0) {
        uVar4 = *(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 6);
        uVar7 = (uint32_t)uVar4;
        iVar6 = *(int32_t *)(iStack_348 + 0x1c) * *(int32_t *)(iStack_348 + 0x24);
        puVar32 = (uint32_t *)
                  ((int64_t)(int32_t)(((uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 2) *
                                       *(int32_t *)(iStack_348 + 0x1c) +
                                      (uint32_t)*(uint16_t *)(pfStack_3a8 + iVar34 * 2)) *
                                     *(int32_t *)(iStack_348 + 0x24)) + *(int64_t *)(iStack_348 + 0x28));
        if (*(int32_t *)(iStack_348 + 0x18) == 1) {
            if (uVar4 != 0) {
                do {
                    uVar46 = (uint32_t)uVar3;
                    puVar24 = puVar32;
                    if (3 < uVar46) {
                        do {
                            uVar19 = 0xff;
                            if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47) < 0xff) {
                                uVar19 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47);
                            }
                            *(uint8_t *)puVar24 = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 1) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            *(uint8_t *)((int64_t)puVar24 + 1) = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 2) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            *(uint8_t *)((int64_t)puVar24 + 2) = uVar19;
                            iVar12 = (int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                            uVar19 = 0xff;
                            if ((uint32_t)iVar12 < 0xff) {
                                uVar19 = (uint8_t)iVar12;
                            }
                            uVar46 = uVar46 - 4;
                            *(uint8_t *)((int64_t)puVar24 + 3) = uVar19;
                            puVar24 = puVar24 + 1;
                        } while (3 < (int32_t)uVar46);
                    }
                    for (; 0 < (int32_t)uVar46; uVar46 = uVar46 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                        uVar19 = 0xff;
                        if ((uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47) < 0xff) {
                            uVar19 = (uint8_t)(int64_t)((float)(uint32_t)*(uint8_t *)puVar24 * fVar47);
                        }
                        *(uint8_t *)puVar24 = uVar19;
                        puVar24 = (uint32_t *)((int64_t)puVar24 + 1);
                    }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar7 = uVar7 - 1;
                    puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
                } while (0 < (int32_t)uVar7);
            }
        } else if ((*(int32_t *)(iStack_348 + 0x18) == 0) && (uVar7 != 0)) {
            do {
                uVar46 = (uint32_t)uVar3;
                puVar24 = puVar32;
                if (3 < uVar46) {
                    do {
                        uVar11 = *puVar24;
                        uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                        uVar40 = 0xff;
                        if (uVar10 < 0xff) {
                            uVar40 = uVar10;
                        }
                        uVar10 = puVar24[1];
                        *puVar24 = ((uVar40 << 8 | uVar11 >> 0x10 & 0xff) << 8 | uVar11 >> 8 & 0xff) << 8 |
                                   uVar11 & 0xff;
                        uVar40 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 7) * fVar47);
                        uVar11 = 0xff;
                        if (uVar40 < 0xff) {
                            uVar11 = uVar40;
                        }
                        uVar40 = puVar24[2];
                        puVar24[1] = ((uVar11 << 8 | uVar10 >> 0x10 & 0xff) << 8 | uVar10 >> 8 & 0xff) << 8 |
                                     uVar10 & 0xff;
                        uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 0xb) * fVar47);
                        uVar11 = 0xff;
                        if (uVar10 < 0xff) {
                            uVar11 = uVar10;
                        }
                        uVar10 = puVar24[3];
                        puVar24[2] = ((uVar11 << 8 | uVar40 >> 0x10 & 0xff) << 8 | uVar40 >> 8 & 0xff) << 8 |
                                     uVar40 & 0xff;
                        uVar40 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 0xf) * fVar47);
                        uVar11 = 0xff;
                        if (uVar40 < 0xff) {
                            uVar11 = uVar40;
                        }
                        uVar46 = uVar46 - 4;
                        puVar24[3] = ((uVar11 << 8 | uVar10 >> 0x10 & 0xff) << 8 | uVar10 >> 8 & 0xff) << 8 |
                                     uVar10 & 0xff;
                        puVar24 = puVar24 + 4;
                    } while (3 < (int32_t)uVar46);
                }
                for (; 0 < (int32_t)uVar46; uVar46 = uVar46 - 1) {
    // WARNING: Read-only address (ram,0x000180646c10) is written
                    uVar11 = *puVar24;
                    uVar10 = (uint32_t)(int64_t)((float)(uint32_t)*(uint8_t *)((int64_t)puVar24 + 3) * fVar47);
                    uVar40 = 0xff;
                    if (uVar10 < 0xff) {
                        uVar40 = uVar10;
                    }
                    *puVar24 = ((uVar40 << 8 | uVar11 >> 0x10 & 0xff) << 8 | uVar11 >> 8 & 0xff) << 8 | uVar11 & 0xff;
                    puVar24 = puVar24 + 1;
                }
    // WARNING: Read-only address (ram,0x000180646c10) is written
                uVar7 = uVar7 - 1;
                puVar32 = (uint32_t *)((int64_t)puVar32 + (int64_t)iVar6);
            } while (0 < (int32_t)uVar7);
        }
    }
    var_450h._0_4_ = (float)(uint32_t)*(uint16_t *)((int64_t)pfStack_3a8 + iVar34 * 8 + 6);
    var_458h._0_4_ = (float)(uint32_t)*(uint16_t *)(pfStack_3a8 + iVar34 * 2 + 1);
    func_0x000180127510(iStack_350, iStack_348, *(undefined2 *)(pfStack_3a8 + iVar34 * 2), 
                        *(undefined2 *)((int64_t)pfStack_3a8 + iVar34 * 8 + 2));
code_r0x00018012e7ec:
    func_0x000180459870(uStack_e0 ^ (uint64_t)auStackY_478);
    return;
}

