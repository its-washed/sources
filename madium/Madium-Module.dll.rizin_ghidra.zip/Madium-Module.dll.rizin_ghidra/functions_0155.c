// Chunk 155 - 50 functions

// ============================================================
// Function: FUN_18020a6e0
// Address: 0x18020a6e0
// Size: 35 bytes
// ============================================================
void fcn.18020a6e0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18020a710
// Address: 0x18020a710
// Size: 99 bytes
// ============================================================
undefined8 fcn.18020a710(int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020a71c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020a734;
    iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020a746;
        iVar1 = fcn.18022a5d0(*(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                              *(int64_t *)(&stack0x00000098 + iVar2), *(int64_t *)(&stack0x000000a0 + iVar2));
        if ((iVar1 == 0) || (*(uint64_t *)(&stack0x00000028 + iVar2) < 0x4b0)) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020a760;
        fcn.18020ae60(in_RCX);
    }
    return 1;
}

// ============================================================
// Function: FUN_18020a780
// Address: 0x18020a780
// Size: 381 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18020a780(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18020a7a4;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x18020a7bc;
    iVar2 = fcn.18022ae60(*(int64_t *)((int64_t)&var_8h + iVar1));
    iVar7 = 0;
    iVar8 = iVar7;
    if (iVar2 == 0) {
code_r0x00018020a7df:
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x18020a7ee;
        iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)&var_8h + iVar1));
        iVar2 = iVar7;
        if (iVar3 != 0) {
            if ((*(int32_t *)(iVar3 + 8) != 2) || (*(int64_t *)(iVar3 + 0x18) != 8)) goto code_r0x00018020a8f9;
            iVar2 = *(int64_t *)(iVar3 + 0x10);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x18020a81e;
        iVar4 = fcn.18022ae60(*(int64_t *)((int64_t)&var_8h + iVar1));
        iVar3 = iVar7;
        if (iVar4 != 0) {
            if ((*(int32_t *)(iVar4 + 8) != 2) || (*(int64_t *)(iVar4 + 0x18) != 8)) goto code_r0x00018020a8f9;
            iVar3 = *(int64_t *)(iVar4 + 0x10);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x18020a84e;
        iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_8h + iVar1));
        iVar4 = iVar7;
        if (iVar5 != 0) {
            if ((*(int32_t *)(iVar5 + 8) != 2) || (*(int64_t *)(iVar5 + 0x18) != 8)) goto code_r0x00018020a8f9;
            iVar4 = *(int64_t *)(iVar5 + 0x10);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x18020a87e;
        iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_8h + iVar1));
        if (iVar5 != 0) {
            if ((*(int32_t *)(iVar5 + 8) != 2) || (*(int64_t *)(iVar5 + 0x18) != 4)) goto code_r0x00018020a8f9;
            iVar7 = *(int64_t *)(iVar5 + 0x10);
        }
        if (iVar8 != 0) {
            *(int64_t *)(in_RCX + 0x78) = iVar8;
        }
        if (iVar2 != 0) {
            *(int64_t *)(in_RCX + 0x80) = iVar2;
        }
        if (iVar3 != 0) {
            *(int64_t *)(in_RCX + 0x88) = iVar3;
        }
        if (iVar4 != 0) {
            *(int64_t *)(in_RCX + 0x90) = iVar4;
        }
        if (iVar7 != 0) {
            *(int64_t *)(in_RCX + 0x98) = iVar7;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x18020a8d5;
        func_0x00018020aec0(in_RCX);
        uVar6 = 1;
    } else {
        if ((*(int32_t *)(iVar2 + 8) == 2) && (*(int64_t *)(iVar2 + 0x18) == 8)) {
            iVar8 = *(int64_t *)(iVar2 + 0x10);
            goto code_r0x00018020a7df;
        }
code_r0x00018020a8f9:
        uVar6 = 0;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18020a900
// Address: 0x18020a900
// Size: 185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18020a900(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020a915;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020a92d;
    iVar2 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)(in_RCX + 0x78) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020a947;
    iVar2 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)(in_RCX + 0x80) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020a962;
    iVar2 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)(in_RCX + 0x88) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020a97d;
    iVar2 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)(in_RCX + 0x90) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020a998;
    iVar1 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar1 != 0) {
        *(undefined8 *)(in_RCX + 0x98) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18020aa10
// Address: 0x18020aa10
// Size: 32 bytes
// ============================================================
undefined8 fcn.18020aa10(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020aa1a;
    iVar1 = fcn.18045a350();
    *(int64_t *)(param_1 + 0x38) = *(int64_t *)(param_1 + 0x38) + param_2;
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020aa26;
    fcn.18020aec0();
    return 1;
}

// ============================================================
// Function: FUN_18020ab40
// Address: 0x18020ab40
// Size: 108 bytes
// ============================================================
undefined8 fcn.18020ab40(int64_t param_1, uint64_t *param_2)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020ab4a;
    iVar1 = fcn.18045a350();
    if (*(uint64_t *)(param_1 + 0x38) < param_2[1]) {
        return 0;
    }
    *(uint64_t *)(param_1 + 0x38) = *(uint64_t *)(param_1 + 0x38) - param_2[1];
    if (*(int32_t *)(param_1 + 0x60) == 0) {
        if (*param_2 <= *(uint64_t *)(param_1 + 0x68)) goto code_r0x00018020ab9a;
        *(undefined4 *)(param_1 + 0x60) = 1;
        *(undefined8 *)(param_1 + 0x50) = 0;
    }
    uVar2 = *(uint64_t *)(param_1 + 0x68);
    if (uVar2 <= *param_2) {
        uVar2 = *param_2;
    }
    *(uint64_t *)(param_1 + 0x68) = uVar2;
code_r0x00018020ab9a:
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020aba2;
    fcn.18020aec0(param_1);
    return 1;
}

// ============================================================
// Function: FUN_18020abb0
// Address: 0x18020abb0
// Size: 28 bytes
// ============================================================
undefined8 fcn.18020abb0(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020abba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020abc2;
    fcn.18020ac30(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1));
    return 1;
}

// ============================================================
// Function: FUN_18020abd0
// Address: 0x18020abd0
// Size: 32 bytes
// ============================================================
undefined8 fcn.18020abd0(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020abda;
    iVar1 = fcn.18045a350();
    *(int64_t *)(param_1 + 0x38) = *(int64_t *)(param_1 + 0x38) - param_2;
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020abe6;
    fcn.18020aec0();
    return 1;
}

// ============================================================
// Function: FUN_18020abf0
// Address: 0x18020abf0
// Size: 52 bytes
// ============================================================
undefined8 fcn.18020abf0(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020abfa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)(param_1 + 0x60) = 1;
    *(undefined8 *)(param_1 + 0x50) = 0;
    *(undefined8 *)(param_1 + 0x68) = *param_2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020ac1a;
    fcn.18020ac30(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1));
    return 1;
}

// ============================================================
// Function: FUN_18020ac30
// Address: 0x18020ac30
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18020ac30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    code *pcVar8;
    code *pcVar9;
    uint64_t uVar10;
    undefined4 uVar11;
    code **in_RCX;
    code *pcVar12;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ac40;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 0xc) != 0) {
        pcVar9 = in_RCX[0xb];
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
        bVar5 = false;
        if (pcVar9 < in_RCX[0xd]) {
            pcVar9 = *in_RCX;
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
            *(undefined4 *)(in_RCX + 0xe) = 1;
            pcVar8 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ac7f;
            pcVar8 = (code *)(*pcVar9)(pcVar8);
            uVar10 = (uint64_t)*(uint32_t *)((int64_t)in_RCX + 0x24);
            pcVar12 = (code *)CONCAT44(0, *(uint32_t *)(in_RCX + 4));
            pcVar9 = in_RCX[8];
            in_RCX[0xb] = pcVar8;
            if (uVar10 == 0) {
                if ((pcVar9 == (code *)0x0) || (pcVar12 == (code *)0x0)) {
                    in_RCX[9] = (code *)0x0;
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                } else {
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                }
            } else if ((pcVar12 == (code *)0x0) ||
                      (auVar2._8_8_ = 0, auVar2._0_8_ = pcVar12,
                      pcVar9 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0))) {
                pcVar9 = (code *)((uint64_t)((int64_t)pcVar9 * (int64_t)pcVar12) / uVar10);
                in_RCX[9] = pcVar9;
            } else {
                pcVar8 = pcVar12;
                if (pcVar9 < pcVar12) {
                    pcVar8 = pcVar9;
                    pcVar9 = pcVar12;
                }
                if ((((pcVar8 != (code *)0x0) &&
                     (auVar3._8_8_ = 0, auVar3._0_8_ = pcVar8, bVar6 = true,
                     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3, 0) < (uint64_t)pcVar9 % uVar10)
                     ) || (bVar6 = bVar5, pcVar8 != (code *)0x0)) &&
                   (bVar5 = bVar6, auVar4._8_8_ = 0, auVar4._0_8_ = pcVar8,
                   SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar4, 0) < (uint64_t)pcVar9 / uVar10))
                {
                    bVar5 = true;
                }
                uVar13 = ((uint64_t)pcVar9 / uVar10) * (int64_t)pcVar8;
                uVar10 = (((uint64_t)pcVar9 % uVar10) * (int64_t)pcVar8) / uVar10;
                if (~uVar13 < uVar10) {
                    bVar5 = true;
                }
                pcVar9 = (code *)(uVar10 + uVar13);
                in_RCX[9] = pcVar9;
                if (bVar5) {
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    pcVar9 = (code *)0xffffffffffffffff;
                }
            }
            in_RCX[8] = pcVar9;
            if (pcVar9 < in_RCX[3]) {
                in_RCX[8] = in_RCX[3];
            }
        }
        if ((in_RDX & 1) != 0) {
            in_RCX[8] = in_RCX[3];
            in_RCX[0xb] = (code *)0x0;
        }
        *(undefined4 *)(in_RCX + 0xc) = 0;
        if ((code **)in_RCX[0xf] != (code **)0x0) {
            *(code **)in_RCX[0xf] = in_RCX[6];
        }
        if ((code **)in_RCX[0x10] != (code **)0x0) {
            *(code **)in_RCX[0x10] = in_RCX[8];
        }
        if ((code **)in_RCX[0x11] != (code **)0x0) {
            *(code **)in_RCX[0x11] = in_RCX[3];
        }
        if ((code **)in_RCX[0x12] != (code **)0x0) {
            *(code **)in_RCX[0x12] = in_RCX[7];
        }
        puVar1 = (undefined4 *)in_RCX[0x13];
        if (puVar1 != (undefined4 *)0x0) {
            if (*(int32_t *)(in_RCX + 0xe) != 0) {
                *puVar1 = 0x52;
                return;
            }
            uVar11 = 0x41;
            if (in_RCX[8] < in_RCX[9]) {
                uVar11 = 0x53;
            }
            *puVar1 = uVar11;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020ac56
// Address: 0x18020ac56
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18020ac30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    code *pcVar8;
    code *pcVar9;
    uint64_t uVar10;
    undefined4 uVar11;
    code **in_RCX;
    code *pcVar12;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ac40;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 0xc) != 0) {
        pcVar9 = in_RCX[0xb];
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
        bVar5 = false;
        if (pcVar9 < in_RCX[0xd]) {
            pcVar9 = *in_RCX;
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
            *(undefined4 *)(in_RCX + 0xe) = 1;
            pcVar8 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ac7f;
            pcVar8 = (code *)(*pcVar9)(pcVar8);
            uVar10 = (uint64_t)*(uint32_t *)((int64_t)in_RCX + 0x24);
            pcVar12 = (code *)CONCAT44(0, *(uint32_t *)(in_RCX + 4));
            pcVar9 = in_RCX[8];
            in_RCX[0xb] = pcVar8;
            if (uVar10 == 0) {
                if ((pcVar9 == (code *)0x0) || (pcVar12 == (code *)0x0)) {
                    in_RCX[9] = (code *)0x0;
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                } else {
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                }
            } else if ((pcVar12 == (code *)0x0) ||
                      (auVar2._8_8_ = 0, auVar2._0_8_ = pcVar12,
                      pcVar9 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0))) {
                pcVar9 = (code *)((uint64_t)((int64_t)pcVar9 * (int64_t)pcVar12) / uVar10);
                in_RCX[9] = pcVar9;
            } else {
                pcVar8 = pcVar12;
                if (pcVar9 < pcVar12) {
                    pcVar8 = pcVar9;
                    pcVar9 = pcVar12;
                }
                if ((((pcVar8 != (code *)0x0) &&
                     (auVar3._8_8_ = 0, auVar3._0_8_ = pcVar8, bVar6 = true,
                     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3, 0) < (uint64_t)pcVar9 % uVar10)
                     ) || (bVar6 = bVar5, pcVar8 != (code *)0x0)) &&
                   (bVar5 = bVar6, auVar4._8_8_ = 0, auVar4._0_8_ = pcVar8,
                   SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar4, 0) < (uint64_t)pcVar9 / uVar10))
                {
                    bVar5 = true;
                }
                uVar13 = ((uint64_t)pcVar9 / uVar10) * (int64_t)pcVar8;
                uVar10 = (((uint64_t)pcVar9 % uVar10) * (int64_t)pcVar8) / uVar10;
                if (~uVar13 < uVar10) {
                    bVar5 = true;
                }
                pcVar9 = (code *)(uVar10 + uVar13);
                in_RCX[9] = pcVar9;
                if (bVar5) {
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    pcVar9 = (code *)0xffffffffffffffff;
                }
            }
            in_RCX[8] = pcVar9;
            if (pcVar9 < in_RCX[3]) {
                in_RCX[8] = in_RCX[3];
            }
        }
        if ((in_RDX & 1) != 0) {
            in_RCX[8] = in_RCX[3];
            in_RCX[0xb] = (code *)0x0;
        }
        *(undefined4 *)(in_RCX + 0xc) = 0;
        if ((code **)in_RCX[0xf] != (code **)0x0) {
            *(code **)in_RCX[0xf] = in_RCX[6];
        }
        if ((code **)in_RCX[0x10] != (code **)0x0) {
            *(code **)in_RCX[0x10] = in_RCX[8];
        }
        if ((code **)in_RCX[0x11] != (code **)0x0) {
            *(code **)in_RCX[0x11] = in_RCX[3];
        }
        if ((code **)in_RCX[0x12] != (code **)0x0) {
            *(code **)in_RCX[0x12] = in_RCX[7];
        }
        puVar1 = (undefined4 *)in_RCX[0x13];
        if (puVar1 != (undefined4 *)0x0) {
            if (*(int32_t *)(in_RCX + 0xe) != 0) {
                *puVar1 = 0x52;
                return;
            }
            uVar11 = 0x41;
            if (in_RCX[8] < in_RCX[9]) {
                uVar11 = 0x53;
            }
            *puVar1 = uVar11;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020ac6a
// Address: 0x18020ac6a
// Size: 316 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18020ac30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    code *pcVar8;
    code *pcVar9;
    uint64_t uVar10;
    undefined4 uVar11;
    code **in_RCX;
    code *pcVar12;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ac40;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 0xc) != 0) {
        pcVar9 = in_RCX[0xb];
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
        bVar5 = false;
        if (pcVar9 < in_RCX[0xd]) {
            pcVar9 = *in_RCX;
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
            *(undefined4 *)(in_RCX + 0xe) = 1;
            pcVar8 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ac7f;
            pcVar8 = (code *)(*pcVar9)(pcVar8);
            uVar10 = (uint64_t)*(uint32_t *)((int64_t)in_RCX + 0x24);
            pcVar12 = (code *)CONCAT44(0, *(uint32_t *)(in_RCX + 4));
            pcVar9 = in_RCX[8];
            in_RCX[0xb] = pcVar8;
            if (uVar10 == 0) {
                if ((pcVar9 == (code *)0x0) || (pcVar12 == (code *)0x0)) {
                    in_RCX[9] = (code *)0x0;
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                } else {
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                }
            } else if ((pcVar12 == (code *)0x0) ||
                      (auVar2._8_8_ = 0, auVar2._0_8_ = pcVar12,
                      pcVar9 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0))) {
                pcVar9 = (code *)((uint64_t)((int64_t)pcVar9 * (int64_t)pcVar12) / uVar10);
                in_RCX[9] = pcVar9;
            } else {
                pcVar8 = pcVar12;
                if (pcVar9 < pcVar12) {
                    pcVar8 = pcVar9;
                    pcVar9 = pcVar12;
                }
                if ((((pcVar8 != (code *)0x0) &&
                     (auVar3._8_8_ = 0, auVar3._0_8_ = pcVar8, bVar6 = true,
                     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3, 0) < (uint64_t)pcVar9 % uVar10)
                     ) || (bVar6 = bVar5, pcVar8 != (code *)0x0)) &&
                   (bVar5 = bVar6, auVar4._8_8_ = 0, auVar4._0_8_ = pcVar8,
                   SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar4, 0) < (uint64_t)pcVar9 / uVar10))
                {
                    bVar5 = true;
                }
                uVar13 = ((uint64_t)pcVar9 / uVar10) * (int64_t)pcVar8;
                uVar10 = (((uint64_t)pcVar9 % uVar10) * (int64_t)pcVar8) / uVar10;
                if (~uVar13 < uVar10) {
                    bVar5 = true;
                }
                pcVar9 = (code *)(uVar10 + uVar13);
                in_RCX[9] = pcVar9;
                if (bVar5) {
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    pcVar9 = (code *)0xffffffffffffffff;
                }
            }
            in_RCX[8] = pcVar9;
            if (pcVar9 < in_RCX[3]) {
                in_RCX[8] = in_RCX[3];
            }
        }
        if ((in_RDX & 1) != 0) {
            in_RCX[8] = in_RCX[3];
            in_RCX[0xb] = (code *)0x0;
        }
        *(undefined4 *)(in_RCX + 0xc) = 0;
        if ((code **)in_RCX[0xf] != (code **)0x0) {
            *(code **)in_RCX[0xf] = in_RCX[6];
        }
        if ((code **)in_RCX[0x10] != (code **)0x0) {
            *(code **)in_RCX[0x10] = in_RCX[8];
        }
        if ((code **)in_RCX[0x11] != (code **)0x0) {
            *(code **)in_RCX[0x11] = in_RCX[3];
        }
        if ((code **)in_RCX[0x12] != (code **)0x0) {
            *(code **)in_RCX[0x12] = in_RCX[7];
        }
        puVar1 = (undefined4 *)in_RCX[0x13];
        if (puVar1 != (undefined4 *)0x0) {
            if (*(int32_t *)(in_RCX + 0xe) != 0) {
                *puVar1 = 0x52;
                return;
            }
            uVar11 = 0x41;
            if (in_RCX[8] < in_RCX[9]) {
                uVar11 = 0x53;
            }
            *puVar1 = uVar11;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020ada6
// Address: 0x18020ada6
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18020ac30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    code *pcVar8;
    code *pcVar9;
    uint64_t uVar10;
    undefined4 uVar11;
    code **in_RCX;
    code *pcVar12;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ac40;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 0xc) != 0) {
        pcVar9 = in_RCX[0xb];
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
        bVar5 = false;
        if (pcVar9 < in_RCX[0xd]) {
            pcVar9 = *in_RCX;
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
            *(undefined4 *)(in_RCX + 0xe) = 1;
            pcVar8 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ac7f;
            pcVar8 = (code *)(*pcVar9)(pcVar8);
            uVar10 = (uint64_t)*(uint32_t *)((int64_t)in_RCX + 0x24);
            pcVar12 = (code *)CONCAT44(0, *(uint32_t *)(in_RCX + 4));
            pcVar9 = in_RCX[8];
            in_RCX[0xb] = pcVar8;
            if (uVar10 == 0) {
                if ((pcVar9 == (code *)0x0) || (pcVar12 == (code *)0x0)) {
                    in_RCX[9] = (code *)0x0;
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                } else {
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                }
            } else if ((pcVar12 == (code *)0x0) ||
                      (auVar2._8_8_ = 0, auVar2._0_8_ = pcVar12,
                      pcVar9 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0))) {
                pcVar9 = (code *)((uint64_t)((int64_t)pcVar9 * (int64_t)pcVar12) / uVar10);
                in_RCX[9] = pcVar9;
            } else {
                pcVar8 = pcVar12;
                if (pcVar9 < pcVar12) {
                    pcVar8 = pcVar9;
                    pcVar9 = pcVar12;
                }
                if ((((pcVar8 != (code *)0x0) &&
                     (auVar3._8_8_ = 0, auVar3._0_8_ = pcVar8, bVar6 = true,
                     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3, 0) < (uint64_t)pcVar9 % uVar10)
                     ) || (bVar6 = bVar5, pcVar8 != (code *)0x0)) &&
                   (bVar5 = bVar6, auVar4._8_8_ = 0, auVar4._0_8_ = pcVar8,
                   SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar4, 0) < (uint64_t)pcVar9 / uVar10))
                {
                    bVar5 = true;
                }
                uVar13 = ((uint64_t)pcVar9 / uVar10) * (int64_t)pcVar8;
                uVar10 = (((uint64_t)pcVar9 % uVar10) * (int64_t)pcVar8) / uVar10;
                if (~uVar13 < uVar10) {
                    bVar5 = true;
                }
                pcVar9 = (code *)(uVar10 + uVar13);
                in_RCX[9] = pcVar9;
                if (bVar5) {
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    pcVar9 = (code *)0xffffffffffffffff;
                }
            }
            in_RCX[8] = pcVar9;
            if (pcVar9 < in_RCX[3]) {
                in_RCX[8] = in_RCX[3];
            }
        }
        if ((in_RDX & 1) != 0) {
            in_RCX[8] = in_RCX[3];
            in_RCX[0xb] = (code *)0x0;
        }
        *(undefined4 *)(in_RCX + 0xc) = 0;
        if ((code **)in_RCX[0xf] != (code **)0x0) {
            *(code **)in_RCX[0xf] = in_RCX[6];
        }
        if ((code **)in_RCX[0x10] != (code **)0x0) {
            *(code **)in_RCX[0x10] = in_RCX[8];
        }
        if ((code **)in_RCX[0x11] != (code **)0x0) {
            *(code **)in_RCX[0x11] = in_RCX[3];
        }
        if ((code **)in_RCX[0x12] != (code **)0x0) {
            *(code **)in_RCX[0x12] = in_RCX[7];
        }
        puVar1 = (undefined4 *)in_RCX[0x13];
        if (puVar1 != (undefined4 *)0x0) {
            if (*(int32_t *)(in_RCX + 0xe) != 0) {
                *puVar1 = 0x52;
                return;
            }
            uVar11 = 0x41;
            if (in_RCX[8] < in_RCX[9]) {
                uVar11 = 0x53;
            }
            *puVar1 = uVar11;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020adb5
// Address: 0x18020adb5
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18020ac30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    code *pcVar8;
    code *pcVar9;
    uint64_t uVar10;
    undefined4 uVar11;
    code **in_RCX;
    code *pcVar12;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ac40;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 0xc) != 0) {
        pcVar9 = in_RCX[0xb];
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
        bVar5 = false;
        if (pcVar9 < in_RCX[0xd]) {
            pcVar9 = *in_RCX;
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
            *(undefined4 *)(in_RCX + 0xe) = 1;
            pcVar8 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ac7f;
            pcVar8 = (code *)(*pcVar9)(pcVar8);
            uVar10 = (uint64_t)*(uint32_t *)((int64_t)in_RCX + 0x24);
            pcVar12 = (code *)CONCAT44(0, *(uint32_t *)(in_RCX + 4));
            pcVar9 = in_RCX[8];
            in_RCX[0xb] = pcVar8;
            if (uVar10 == 0) {
                if ((pcVar9 == (code *)0x0) || (pcVar12 == (code *)0x0)) {
                    in_RCX[9] = (code *)0x0;
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                } else {
                    pcVar9 = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    in_RCX[9] = (code *)0xffffffffffffffff;
                }
            } else if ((pcVar12 == (code *)0x0) ||
                      (auVar2._8_8_ = 0, auVar2._0_8_ = pcVar12,
                      pcVar9 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0))) {
                pcVar9 = (code *)((uint64_t)((int64_t)pcVar9 * (int64_t)pcVar12) / uVar10);
                in_RCX[9] = pcVar9;
            } else {
                pcVar8 = pcVar12;
                if (pcVar9 < pcVar12) {
                    pcVar8 = pcVar9;
                    pcVar9 = pcVar12;
                }
                if ((((pcVar8 != (code *)0x0) &&
                     (auVar3._8_8_ = 0, auVar3._0_8_ = pcVar8, bVar6 = true,
                     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3, 0) < (uint64_t)pcVar9 % uVar10)
                     ) || (bVar6 = bVar5, pcVar8 != (code *)0x0)) &&
                   (bVar5 = bVar6, auVar4._8_8_ = 0, auVar4._0_8_ = pcVar8,
                   SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar4, 0) < (uint64_t)pcVar9 / uVar10))
                {
                    bVar5 = true;
                }
                uVar13 = ((uint64_t)pcVar9 / uVar10) * (int64_t)pcVar8;
                uVar10 = (((uint64_t)pcVar9 % uVar10) * (int64_t)pcVar8) / uVar10;
                if (~uVar13 < uVar10) {
                    bVar5 = true;
                }
                pcVar9 = (code *)(uVar10 + uVar13);
                in_RCX[9] = pcVar9;
                if (bVar5) {
                    in_RCX[9] = (code *)0xffffffffffffffff;
                    pcVar9 = (code *)0xffffffffffffffff;
                }
            }
            in_RCX[8] = pcVar9;
            if (pcVar9 < in_RCX[3]) {
                in_RCX[8] = in_RCX[3];
            }
        }
        if ((in_RDX & 1) != 0) {
            in_RCX[8] = in_RCX[3];
            in_RCX[0xb] = (code *)0x0;
        }
        *(undefined4 *)(in_RCX + 0xc) = 0;
        if ((code **)in_RCX[0xf] != (code **)0x0) {
            *(code **)in_RCX[0xf] = in_RCX[6];
        }
        if ((code **)in_RCX[0x10] != (code **)0x0) {
            *(code **)in_RCX[0x10] = in_RCX[8];
        }
        if ((code **)in_RCX[0x11] != (code **)0x0) {
            *(code **)in_RCX[0x11] = in_RCX[3];
        }
        if ((code **)in_RCX[0x12] != (code **)0x0) {
            *(code **)in_RCX[0x12] = in_RCX[7];
        }
        puVar1 = (undefined4 *)in_RCX[0x13];
        if (puVar1 != (undefined4 *)0x0) {
            if (*(int32_t *)(in_RCX + 0xe) != 0) {
                *puVar1 = 0x52;
                return;
            }
            uVar11 = 0x41;
            if (in_RCX[8] < in_RCX[9]) {
                uVar11 = 0x53;
            }
            *puVar1 = uVar11;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020ae60
// Address: 0x18020ae60
// Size: 85 bytes
// ============================================================
void fcn.18020ae60(int64_t param_1, uint64_t param_2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    
    fcn.18045a350();
    uVar1 = *(uint64_t *)(param_1 + 0x30);
    uVar3 = param_2 * 2;
    *(uint64_t *)(param_1 + 0x30) = param_2;
    uVar6 = uVar3;
    if (uVar3 < 0x3980) {
        uVar6 = 0x3980;
    }
    uVar4 = param_2 * 10;
    *(uint64_t *)(param_1 + 0x10) = uVar4;
    if (uVar6 < uVar4) {
        *(uint64_t *)(param_1 + 0x10) = uVar6;
        uVar4 = uVar6;
    }
    *(uint64_t *)(param_1 + 0x18) = uVar3;
    if (param_2 < uVar1) {
        *(uint64_t *)(param_1 + 0x40) = uVar4;
    }
    if (*(undefined8 **)(param_1 + 0x78) != (undefined8 *)0x0) {
        **(undefined8 **)(param_1 + 0x78) = *(undefined8 *)(param_1 + 0x30);
    }
    if (*(undefined8 **)(param_1 + 0x80) != (undefined8 *)0x0) {
        **(undefined8 **)(param_1 + 0x80) = *(undefined8 *)(param_1 + 0x40);
    }
    if (*(undefined8 **)(param_1 + 0x88) != (undefined8 *)0x0) {
        **(undefined8 **)(param_1 + 0x88) = *(undefined8 *)(param_1 + 0x18);
    }
    if (*(undefined8 **)(param_1 + 0x90) != (undefined8 *)0x0) {
        **(undefined8 **)(param_1 + 0x90) = *(undefined8 *)(param_1 + 0x38);
    }
    puVar2 = *(undefined4 **)(param_1 + 0x98);
    if (puVar2 != (undefined4 *)0x0) {
        if (*(int32_t *)(param_1 + 0x70) != 0) {
            *puVar2 = 0x52;
            return;
        }
        uVar5 = 0x41;
        if (*(uint64_t *)(param_1 + 0x40) < *(uint64_t *)(param_1 + 0x48)) {
            uVar5 = 0x53;
        }
        *puVar2 = uVar5;
    }
    return;
}

// ============================================================
// Function: FUN_18020af50
// Address: 0x18020af50
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18020af50(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined (*pauVar2) [16];
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020af60;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020af7d;
    pauVar2 = (undefined (*) [16])
              fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (pauVar2 == (undefined (*) [16])0x0) {
        return;
    }
    *pauVar2 = ZEXT816(0);
    *(undefined8 *)(pauVar2[1] + 8) = in_RDX;
    *(undefined8 *)pauVar2[1] = in_RCX;
    return;
}

// ============================================================
// Function: FUN_18020afb0
// Address: 0x18020afb0
// Size: 21 bytes
// ============================================================
void fcn.18020afb0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **in_RCX;
    int64_t *piVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020afba;
    iVar2 = fcn.18045a350();
    piVar3 = *in_RCX;
    if (piVar3 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&var_20h + -iVar2) = unaff_RBX;
        do {
            piVar1 = (int64_t *)*piVar3;
            *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x18020afe5;
            fcn.180224990(piVar3, 0x1804ba210, 0x47);
            piVar3 = piVar1;
        } while (piVar1 != (int64_t *)0x0);
    }
    return;
}

// ============================================================
// Function: FUN_18020afc5
// Address: 0x18020afc5
// Size: 45 bytes
// ============================================================
void fcn.18020afb0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **in_RCX;
    int64_t *piVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020afba;
    iVar2 = fcn.18045a350();
    piVar3 = *in_RCX;
    if (piVar3 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&var_20h + -iVar2) = unaff_RBX;
        do {
            piVar1 = (int64_t *)*piVar3;
            *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x18020afe5;
            fcn.180224990(piVar3, 0x1804ba210, 0x47);
            piVar3 = piVar1;
        } while (piVar1 != (int64_t *)0x0);
    }
    return;
}

// ============================================================
// Function: FUN_18020aff2
// Address: 0x18020aff2
// Size: 5 bytes
// ============================================================
void fcn.18020afb0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **in_RCX;
    int64_t *piVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020afba;
    iVar2 = fcn.18045a350();
    piVar3 = *in_RCX;
    if (piVar3 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&var_20h + -iVar2) = unaff_RBX;
        do {
            piVar1 = (int64_t *)*piVar3;
            *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x18020afe5;
            fcn.180224990(piVar3, 0x1804ba210, 0x47);
            piVar3 = piVar1;
        } while (piVar1 != (int64_t *)0x0);
    }
    return;
}

// ============================================================
// Function: FUN_18020b010
// Address: 0x18020b010
// Size: 624 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18020b010(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint64_t uVar1;
    undefined *puVar2;
    int64_t iVar3;
    undefined (*pauVar4) [16];
    undefined (**ppauVar5) [16];
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined (**in_RCX) [16];
    uint64_t uVar9;
    uint64_t *in_RDX;
    undefined (*pauVar10) [16];
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined (*pauVar12) [16];
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b02b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *in_RDX;
    uVar8 = in_RDX[1];
    if (uVar1 <= uVar8) {
        if (in_RCX[2] == (undefined (*) [16])0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b053;
            pauVar4 = (undefined (*) [16])
                      fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (pauVar4 != (undefined (*) [16])0x0) {
                if (*in_RCX != (undefined (*) [16])0x0) {
                    *(undefined (**) [16])(**in_RCX + 8) = pauVar4;
                }
                *(undefined (**) [16])*pauVar4 = *in_RCX;
                *(undefined8 *)(*pauVar4 + 8) = 0;
                *in_RCX = pauVar4;
                if (in_RCX[1] == (undefined (*) [16])0x0) {
                    in_RCX[1] = pauVar4;
                }
                in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                return 1;
            }
        } else {
            pauVar4 = in_RCX[1];
            uVar7 = *(uint64_t *)(pauVar4[1] + 8);
            if (uVar1 <= uVar7) {
                pauVar12 = *in_RCX;
                if ((*(uint64_t *)pauVar12[1] < uVar1) || (uVar8 < uVar7)) {
                    if (uVar8 < *(uint64_t *)pauVar12[1]) {
                        pauVar4 = pauVar12;
                    }
                    if (pauVar4 != (undefined (*) [16])0x0) {
                        while( true ) {
                            pauVar12 = pauVar4;
                            uVar7 = *(uint64_t *)pauVar12[1];
                            pauVar4 = *(undefined (**) [16])(*pauVar12 + 8);
                            if ((uVar7 <= uVar1) && (uVar8 <= *(uint64_t *)(pauVar12[1] + 8))) {
                                return 1;
                            }
                            uVar11 = *(uint64_t *)(pauVar12[1] + 8);
                            uVar9 = uVar1;
                            if (uVar1 < uVar7) {
                                uVar9 = uVar7;
                            }
                            uVar6 = uVar8;
                            if (uVar11 < uVar8) {
                                uVar6 = uVar11;
                            }
                            if (uVar9 <= uVar6) break;
                            if (uVar8 < uVar7) {
                                if ((pauVar4 == (undefined (*) [16])0x0) || (*(uint64_t *)(pauVar4[1] + 8) < uVar1)) {
                                    if (uVar7 == uVar8 + 1) {
                                        *(uint64_t *)pauVar12[1] = uVar1;
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b207;
                                        func_0x00018020b500(in_RCX, pauVar12);
                                        return 1;
                                    }
                                    if ((pauVar4 != (undefined (*) [16])0x0) &&
                                       (*(int64_t *)(pauVar4[1] + 8) + 1U == uVar1)) {
                                        *(uint64_t *)(pauVar4[1] + 8) = uVar8;
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b231;
                                        func_0x00018020b500(in_RCX, pauVar12);
                                        return 1;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b243;
                                    pauVar4 = (undefined (*) [16])
                                              fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                                            *(int64_t *)(&stack0x00000048 + iVar3));
                                    if (pauVar4 == (undefined (*) [16])0x0) {
                                        return 0;
                                    }
                                    *(undefined (**) [16])*pauVar4 = pauVar12;
                                    *(undefined8 *)(*pauVar4 + 8) = *(undefined8 *)(*pauVar12 + 8);
                                    if (*(undefined (***) [16])(*pauVar12 + 8) != (undefined (**) [16])0x0) {
                                        **(undefined (***) [16])(*pauVar12 + 8) = pauVar4;
                                    }
                                    *(undefined (**) [16])(*pauVar12 + 8) = pauVar4;
                                    if (*in_RCX == pauVar12) {
                                        *in_RCX = pauVar4;
                                    }
                                    in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                                    return 1;
                                }
                            } else if (pauVar4 == (undefined (*) [16])0x0) {
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
                        if (uVar11 < uVar8) {
                            uVar11 = uVar8;
                        }
                        *(uint64_t *)(pauVar12[1] + 8) = uVar11;
                        pauVar10 = pauVar12;
                        if (pauVar4 != (undefined (*) [16])0x0) {
                            do {
                                uVar8 = in_RDX[1];
                                if (*(uint64_t *)(pauVar4[1] + 8) < in_RDX[1]) {
                                    uVar8 = *(uint64_t *)(pauVar4[1] + 8);
                                }
                                uVar7 = *in_RDX;
                                if (*in_RDX < *(uint64_t *)pauVar4[1]) {
                                    uVar7 = *(uint64_t *)pauVar4[1];
                                }
                            } while ((uVar7 <= uVar8) &&
                                    (puVar2 = *pauVar4, pauVar10 = pauVar4, pauVar4 = *(undefined (**) [16])(puVar2 + 8)
                                    , *(undefined (**) [16])(puVar2 + 8) != (undefined (*) [16])0x0));
                        }
                        uVar8 = *(uint64_t *)pauVar10[1];
                        if (uVar1 < *(uint64_t *)pauVar10[1]) {
                            uVar8 = uVar1;
                        }
                        *(uint64_t *)pauVar12[1] = uVar8;
                        while (pauVar10 != pauVar12) {
                            pauVar4 = *(undefined (**) [16])*pauVar10;
                            if (*in_RCX == pauVar10) {
                                *in_RCX = pauVar4;
                            }
                            if (in_RCX[1] == pauVar10) {
                                in_RCX[1] = *(undefined (**) [16])(*pauVar10 + 8);
                            }
                            if (*(undefined8 **)(*pauVar10 + 8) != (undefined8 *)0x0) {
                                **(undefined8 **)(*pauVar10 + 8) = *(undefined8 *)*pauVar10;
                            }
                            if (*(int64_t *)*pauVar10 != 0) {
                                *(undefined8 *)(*(int64_t *)*pauVar10 + 8) = *(undefined8 *)(*pauVar10 + 8);
                            }
                            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                            *pauVar10 = ZEXT816(0);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b33a;
                            fcn.180224990(pauVar10, 0x1804ba210, 0xda);
                            pauVar10 = pauVar4;
                        }
                        return 1;
                    }
                } else {
                    *(uint64_t *)pauVar12[1] = uVar1;
                    pauVar4 = *(undefined (**) [16])*pauVar12;
                    *(uint64_t *)(pauVar12[1] + 8) = uVar8;
                    if (pauVar4 != (undefined (*) [16])0x0) {
                        do {
                            pauVar12 = *(undefined (**) [16])*pauVar4;
                            pauVar10 = pauVar12;
                            if (*in_RCX == pauVar4) {
                                *in_RCX = pauVar12;
                                pauVar10 = *(undefined (**) [16])*pauVar4;
                            }
                            if (in_RCX[1] == pauVar4) {
                                in_RCX[1] = *(undefined (**) [16])(*pauVar4 + 8);
                                pauVar10 = *(undefined (**) [16])*pauVar4;
                            }
                            ppauVar5 = *(undefined (***) [16])(*pauVar4 + 8);
                            if (ppauVar5 != (undefined (**) [16])0x0) {
                                *ppauVar5 = pauVar10;
                                ppauVar5 = *(undefined (***) [16])(*pauVar4 + 8);
                            }
                            if (*(int64_t *)*pauVar4 != 0) {
                                *(undefined (***) [16])(*(int64_t *)*pauVar4 + 8) = ppauVar5;
                            }
                            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                            *pauVar4 = ZEXT816(0);
                            pauVar4 = pauVar12;
                        } while (pauVar12 != (undefined (*) [16])0x0);
                        return 1;
                    }
                }
                return 1;
            }
            if (uVar7 + 1 == uVar1) {
                *(uint64_t *)(pauVar4[1] + 8) = uVar8;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b0be;
            pauVar4 = (undefined (*) [16])
                      fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (pauVar4 != (undefined (*) [16])0x0) {
                if (in_RCX[1] != (undefined (*) [16])0x0) {
                    *(undefined (**) [16])*in_RCX[1] = pauVar4;
                }
                *(undefined (**) [16])(*pauVar4 + 8) = in_RCX[1];
                *(undefined8 *)*pauVar4 = 0;
                in_RCX[1] = pauVar4;
                if (*in_RCX == (undefined (*) [16])0x0) {
                    *in_RCX = pauVar4;
                }
                in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b280
// Address: 0x18020b280
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18020b010(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint64_t uVar1;
    undefined *puVar2;
    int64_t iVar3;
    undefined (*pauVar4) [16];
    undefined (**ppauVar5) [16];
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined (**in_RCX) [16];
    uint64_t uVar9;
    uint64_t *in_RDX;
    undefined (*pauVar10) [16];
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined (*pauVar12) [16];
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b02b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *in_RDX;
    uVar8 = in_RDX[1];
    if (uVar1 <= uVar8) {
        if (in_RCX[2] == (undefined (*) [16])0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b053;
            pauVar4 = (undefined (*) [16])
                      fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (pauVar4 != (undefined (*) [16])0x0) {
                if (*in_RCX != (undefined (*) [16])0x0) {
                    *(undefined (**) [16])(**in_RCX + 8) = pauVar4;
                }
                *(undefined (**) [16])*pauVar4 = *in_RCX;
                *(undefined8 *)(*pauVar4 + 8) = 0;
                *in_RCX = pauVar4;
                if (in_RCX[1] == (undefined (*) [16])0x0) {
                    in_RCX[1] = pauVar4;
                }
                in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                return 1;
            }
        } else {
            pauVar4 = in_RCX[1];
            uVar7 = *(uint64_t *)(pauVar4[1] + 8);
            if (uVar1 <= uVar7) {
                pauVar12 = *in_RCX;
                if ((*(uint64_t *)pauVar12[1] < uVar1) || (uVar8 < uVar7)) {
                    if (uVar8 < *(uint64_t *)pauVar12[1]) {
                        pauVar4 = pauVar12;
                    }
                    if (pauVar4 != (undefined (*) [16])0x0) {
                        while( true ) {
                            pauVar12 = pauVar4;
                            uVar7 = *(uint64_t *)pauVar12[1];
                            pauVar4 = *(undefined (**) [16])(*pauVar12 + 8);
                            if ((uVar7 <= uVar1) && (uVar8 <= *(uint64_t *)(pauVar12[1] + 8))) {
                                return 1;
                            }
                            uVar11 = *(uint64_t *)(pauVar12[1] + 8);
                            uVar9 = uVar1;
                            if (uVar1 < uVar7) {
                                uVar9 = uVar7;
                            }
                            uVar6 = uVar8;
                            if (uVar11 < uVar8) {
                                uVar6 = uVar11;
                            }
                            if (uVar9 <= uVar6) break;
                            if (uVar8 < uVar7) {
                                if ((pauVar4 == (undefined (*) [16])0x0) || (*(uint64_t *)(pauVar4[1] + 8) < uVar1)) {
                                    if (uVar7 == uVar8 + 1) {
                                        *(uint64_t *)pauVar12[1] = uVar1;
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b207;
                                        func_0x00018020b500(in_RCX, pauVar12);
                                        return 1;
                                    }
                                    if ((pauVar4 != (undefined (*) [16])0x0) &&
                                       (*(int64_t *)(pauVar4[1] + 8) + 1U == uVar1)) {
                                        *(uint64_t *)(pauVar4[1] + 8) = uVar8;
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b231;
                                        func_0x00018020b500(in_RCX, pauVar12);
                                        return 1;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b243;
                                    pauVar4 = (undefined (*) [16])
                                              fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                                            *(int64_t *)(&stack0x00000048 + iVar3));
                                    if (pauVar4 == (undefined (*) [16])0x0) {
                                        return 0;
                                    }
                                    *(undefined (**) [16])*pauVar4 = pauVar12;
                                    *(undefined8 *)(*pauVar4 + 8) = *(undefined8 *)(*pauVar12 + 8);
                                    if (*(undefined (***) [16])(*pauVar12 + 8) != (undefined (**) [16])0x0) {
                                        **(undefined (***) [16])(*pauVar12 + 8) = pauVar4;
                                    }
                                    *(undefined (**) [16])(*pauVar12 + 8) = pauVar4;
                                    if (*in_RCX == pauVar12) {
                                        *in_RCX = pauVar4;
                                    }
                                    in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                                    return 1;
                                }
                            } else if (pauVar4 == (undefined (*) [16])0x0) {
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
                        if (uVar11 < uVar8) {
                            uVar11 = uVar8;
                        }
                        *(uint64_t *)(pauVar12[1] + 8) = uVar11;
                        pauVar10 = pauVar12;
                        if (pauVar4 != (undefined (*) [16])0x0) {
                            do {
                                uVar8 = in_RDX[1];
                                if (*(uint64_t *)(pauVar4[1] + 8) < in_RDX[1]) {
                                    uVar8 = *(uint64_t *)(pauVar4[1] + 8);
                                }
                                uVar7 = *in_RDX;
                                if (*in_RDX < *(uint64_t *)pauVar4[1]) {
                                    uVar7 = *(uint64_t *)pauVar4[1];
                                }
                            } while ((uVar7 <= uVar8) &&
                                    (puVar2 = *pauVar4, pauVar10 = pauVar4, pauVar4 = *(undefined (**) [16])(puVar2 + 8)
                                    , *(undefined (**) [16])(puVar2 + 8) != (undefined (*) [16])0x0));
                        }
                        uVar8 = *(uint64_t *)pauVar10[1];
                        if (uVar1 < *(uint64_t *)pauVar10[1]) {
                            uVar8 = uVar1;
                        }
                        *(uint64_t *)pauVar12[1] = uVar8;
                        while (pauVar10 != pauVar12) {
                            pauVar4 = *(undefined (**) [16])*pauVar10;
                            if (*in_RCX == pauVar10) {
                                *in_RCX = pauVar4;
                            }
                            if (in_RCX[1] == pauVar10) {
                                in_RCX[1] = *(undefined (**) [16])(*pauVar10 + 8);
                            }
                            if (*(undefined8 **)(*pauVar10 + 8) != (undefined8 *)0x0) {
                                **(undefined8 **)(*pauVar10 + 8) = *(undefined8 *)*pauVar10;
                            }
                            if (*(int64_t *)*pauVar10 != 0) {
                                *(undefined8 *)(*(int64_t *)*pauVar10 + 8) = *(undefined8 *)(*pauVar10 + 8);
                            }
                            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                            *pauVar10 = ZEXT816(0);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b33a;
                            fcn.180224990(pauVar10, 0x1804ba210, 0xda);
                            pauVar10 = pauVar4;
                        }
                        return 1;
                    }
                } else {
                    *(uint64_t *)pauVar12[1] = uVar1;
                    pauVar4 = *(undefined (**) [16])*pauVar12;
                    *(uint64_t *)(pauVar12[1] + 8) = uVar8;
                    if (pauVar4 != (undefined (*) [16])0x0) {
                        do {
                            pauVar12 = *(undefined (**) [16])*pauVar4;
                            pauVar10 = pauVar12;
                            if (*in_RCX == pauVar4) {
                                *in_RCX = pauVar12;
                                pauVar10 = *(undefined (**) [16])*pauVar4;
                            }
                            if (in_RCX[1] == pauVar4) {
                                in_RCX[1] = *(undefined (**) [16])(*pauVar4 + 8);
                                pauVar10 = *(undefined (**) [16])*pauVar4;
                            }
                            ppauVar5 = *(undefined (***) [16])(*pauVar4 + 8);
                            if (ppauVar5 != (undefined (**) [16])0x0) {
                                *ppauVar5 = pauVar10;
                                ppauVar5 = *(undefined (***) [16])(*pauVar4 + 8);
                            }
                            if (*(int64_t *)*pauVar4 != 0) {
                                *(undefined (***) [16])(*(int64_t *)*pauVar4 + 8) = ppauVar5;
                            }
                            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                            *pauVar4 = ZEXT816(0);
                            pauVar4 = pauVar12;
                        } while (pauVar12 != (undefined (*) [16])0x0);
                        return 1;
                    }
                }
                return 1;
            }
            if (uVar7 + 1 == uVar1) {
                *(uint64_t *)(pauVar4[1] + 8) = uVar8;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b0be;
            pauVar4 = (undefined (*) [16])
                      fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (pauVar4 != (undefined (*) [16])0x0) {
                if (in_RCX[1] != (undefined (*) [16])0x0) {
                    *(undefined (**) [16])*in_RCX[1] = pauVar4;
                }
                *(undefined (**) [16])(*pauVar4 + 8) = in_RCX[1];
                *(undefined8 *)*pauVar4 = 0;
                in_RCX[1] = pauVar4;
                if (*in_RCX == (undefined (*) [16])0x0) {
                    *in_RCX = pauVar4;
                }
                in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b344
// Address: 0x18020b344
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18020b010(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint64_t uVar1;
    undefined *puVar2;
    int64_t iVar3;
    undefined (*pauVar4) [16];
    undefined (**ppauVar5) [16];
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined (**in_RCX) [16];
    uint64_t uVar9;
    uint64_t *in_RDX;
    undefined (*pauVar10) [16];
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined (*pauVar12) [16];
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b02b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *in_RDX;
    uVar8 = in_RDX[1];
    if (uVar1 <= uVar8) {
        if (in_RCX[2] == (undefined (*) [16])0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b053;
            pauVar4 = (undefined (*) [16])
                      fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (pauVar4 != (undefined (*) [16])0x0) {
                if (*in_RCX != (undefined (*) [16])0x0) {
                    *(undefined (**) [16])(**in_RCX + 8) = pauVar4;
                }
                *(undefined (**) [16])*pauVar4 = *in_RCX;
                *(undefined8 *)(*pauVar4 + 8) = 0;
                *in_RCX = pauVar4;
                if (in_RCX[1] == (undefined (*) [16])0x0) {
                    in_RCX[1] = pauVar4;
                }
                in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                return 1;
            }
        } else {
            pauVar4 = in_RCX[1];
            uVar7 = *(uint64_t *)(pauVar4[1] + 8);
            if (uVar1 <= uVar7) {
                pauVar12 = *in_RCX;
                if ((*(uint64_t *)pauVar12[1] < uVar1) || (uVar8 < uVar7)) {
                    if (uVar8 < *(uint64_t *)pauVar12[1]) {
                        pauVar4 = pauVar12;
                    }
                    if (pauVar4 != (undefined (*) [16])0x0) {
                        while( true ) {
                            pauVar12 = pauVar4;
                            uVar7 = *(uint64_t *)pauVar12[1];
                            pauVar4 = *(undefined (**) [16])(*pauVar12 + 8);
                            if ((uVar7 <= uVar1) && (uVar8 <= *(uint64_t *)(pauVar12[1] + 8))) {
                                return 1;
                            }
                            uVar11 = *(uint64_t *)(pauVar12[1] + 8);
                            uVar9 = uVar1;
                            if (uVar1 < uVar7) {
                                uVar9 = uVar7;
                            }
                            uVar6 = uVar8;
                            if (uVar11 < uVar8) {
                                uVar6 = uVar11;
                            }
                            if (uVar9 <= uVar6) break;
                            if (uVar8 < uVar7) {
                                if ((pauVar4 == (undefined (*) [16])0x0) || (*(uint64_t *)(pauVar4[1] + 8) < uVar1)) {
                                    if (uVar7 == uVar8 + 1) {
                                        *(uint64_t *)pauVar12[1] = uVar1;
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b207;
                                        func_0x00018020b500(in_RCX, pauVar12);
                                        return 1;
                                    }
                                    if ((pauVar4 != (undefined (*) [16])0x0) &&
                                       (*(int64_t *)(pauVar4[1] + 8) + 1U == uVar1)) {
                                        *(uint64_t *)(pauVar4[1] + 8) = uVar8;
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b231;
                                        func_0x00018020b500(in_RCX, pauVar12);
                                        return 1;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b243;
                                    pauVar4 = (undefined (*) [16])
                                              fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                                            *(int64_t *)(&stack0x00000048 + iVar3));
                                    if (pauVar4 == (undefined (*) [16])0x0) {
                                        return 0;
                                    }
                                    *(undefined (**) [16])*pauVar4 = pauVar12;
                                    *(undefined8 *)(*pauVar4 + 8) = *(undefined8 *)(*pauVar12 + 8);
                                    if (*(undefined (***) [16])(*pauVar12 + 8) != (undefined (**) [16])0x0) {
                                        **(undefined (***) [16])(*pauVar12 + 8) = pauVar4;
                                    }
                                    *(undefined (**) [16])(*pauVar12 + 8) = pauVar4;
                                    if (*in_RCX == pauVar12) {
                                        *in_RCX = pauVar4;
                                    }
                                    in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                                    return 1;
                                }
                            } else if (pauVar4 == (undefined (*) [16])0x0) {
                                return 1;
                            }
                        }
                        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
                        if (uVar11 < uVar8) {
                            uVar11 = uVar8;
                        }
                        *(uint64_t *)(pauVar12[1] + 8) = uVar11;
                        pauVar10 = pauVar12;
                        if (pauVar4 != (undefined (*) [16])0x0) {
                            do {
                                uVar8 = in_RDX[1];
                                if (*(uint64_t *)(pauVar4[1] + 8) < in_RDX[1]) {
                                    uVar8 = *(uint64_t *)(pauVar4[1] + 8);
                                }
                                uVar7 = *in_RDX;
                                if (*in_RDX < *(uint64_t *)pauVar4[1]) {
                                    uVar7 = *(uint64_t *)pauVar4[1];
                                }
                            } while ((uVar7 <= uVar8) &&
                                    (puVar2 = *pauVar4, pauVar10 = pauVar4, pauVar4 = *(undefined (**) [16])(puVar2 + 8)
                                    , *(undefined (**) [16])(puVar2 + 8) != (undefined (*) [16])0x0));
                        }
                        uVar8 = *(uint64_t *)pauVar10[1];
                        if (uVar1 < *(uint64_t *)pauVar10[1]) {
                            uVar8 = uVar1;
                        }
                        *(uint64_t *)pauVar12[1] = uVar8;
                        while (pauVar10 != pauVar12) {
                            pauVar4 = *(undefined (**) [16])*pauVar10;
                            if (*in_RCX == pauVar10) {
                                *in_RCX = pauVar4;
                            }
                            if (in_RCX[1] == pauVar10) {
                                in_RCX[1] = *(undefined (**) [16])(*pauVar10 + 8);
                            }
                            if (*(undefined8 **)(*pauVar10 + 8) != (undefined8 *)0x0) {
                                **(undefined8 **)(*pauVar10 + 8) = *(undefined8 *)*pauVar10;
                            }
                            if (*(int64_t *)*pauVar10 != 0) {
                                *(undefined8 *)(*(int64_t *)*pauVar10 + 8) = *(undefined8 *)(*pauVar10 + 8);
                            }
                            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                            *pauVar10 = ZEXT816(0);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b33a;
                            fcn.180224990(pauVar10, 0x1804ba210, 0xda);
                            pauVar10 = pauVar4;
                        }
                        return 1;
                    }
                } else {
                    *(uint64_t *)pauVar12[1] = uVar1;
                    pauVar4 = *(undefined (**) [16])*pauVar12;
                    *(uint64_t *)(pauVar12[1] + 8) = uVar8;
                    if (pauVar4 != (undefined (*) [16])0x0) {
                        do {
                            pauVar12 = *(undefined (**) [16])*pauVar4;
                            pauVar10 = pauVar12;
                            if (*in_RCX == pauVar4) {
                                *in_RCX = pauVar12;
                                pauVar10 = *(undefined (**) [16])*pauVar4;
                            }
                            if (in_RCX[1] == pauVar4) {
                                in_RCX[1] = *(undefined (**) [16])(*pauVar4 + 8);
                                pauVar10 = *(undefined (**) [16])*pauVar4;
                            }
                            ppauVar5 = *(undefined (***) [16])(*pauVar4 + 8);
                            if (ppauVar5 != (undefined (**) [16])0x0) {
                                *ppauVar5 = pauVar10;
                                ppauVar5 = *(undefined (***) [16])(*pauVar4 + 8);
                            }
                            if (*(int64_t *)*pauVar4 != 0) {
                                *(undefined (***) [16])(*(int64_t *)*pauVar4 + 8) = ppauVar5;
                            }
                            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                            *pauVar4 = ZEXT816(0);
                            pauVar4 = pauVar12;
                        } while (pauVar12 != (undefined (*) [16])0x0);
                        return 1;
                    }
                }
                return 1;
            }
            if (uVar7 + 1 == uVar1) {
                *(uint64_t *)(pauVar4[1] + 8) = uVar8;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020b0be;
            pauVar4 = (undefined (*) [16])
                      fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (pauVar4 != (undefined (*) [16])0x0) {
                if (in_RCX[1] != (undefined (*) [16])0x0) {
                    *(undefined (**) [16])*in_RCX[1] = pauVar4;
                }
                *(undefined (**) [16])(*pauVar4 + 8) = in_RCX[1];
                *(undefined8 *)*pauVar4 = 0;
                in_RCX[1] = pauVar4;
                if (*in_RCX == (undefined (*) [16])0x0) {
                    *in_RCX = pauVar4;
                }
                in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b3b0
// Address: 0x18020b3b0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18020b3b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined (**in_RCX) [16];
    uint64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined (*pauVar7) [16];
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b3c6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *in_RDX;
    uVar2 = in_RDX[1];
    if (uVar2 < uVar1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    pauVar7 = in_RCX[1];
    if (pauVar7 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        do {
            uVar3 = *(uint64_t *)(pauVar7[1] + 8);
            pauVar6 = *(undefined (**) [16])(*pauVar7 + 8);
            if (uVar3 < uVar1) {
                return 1;
            }
            if (*(uint64_t *)pauVar7[1] < uVar1) {
                if (uVar2 < uVar3) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020b4a6;
                    pauVar6 = (undefined (*) [16])
                              fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                            *(int64_t *)(&stack0x00000048 + iVar4));
                    *(undefined (**) [16])(*pauVar6 + 8) = pauVar7;
                    *(undefined8 *)*pauVar6 = *(undefined8 *)*pauVar7;
                    if (*(int64_t *)*pauVar7 != 0) {
                        *(undefined (**) [16])(*(int64_t *)*pauVar7 + 8) = pauVar6;
                    }
                    *(undefined (**) [16])*pauVar7 = pauVar6;
                    if (in_RCX[1] == pauVar7) {
                        in_RCX[1] = pauVar6;
                    }
                    in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                }
                *(uint64_t *)(pauVar7[1] + 8) = uVar1 - 1;
                return 1;
            }
            if (uVar2 < uVar3) {
                if (*(uint64_t *)pauVar7[1] <= uVar2) {
                    *(uint64_t *)pauVar7[1] = uVar2 + 1;
                }
            } else {
                pauVar5 = pauVar6;
                if (*in_RCX == pauVar7) {
                    *in_RCX = *(undefined (**) [16])*pauVar7;
                    pauVar5 = *(undefined (**) [16])(*pauVar7 + 8);
                }
                if (in_RCX[1] == pauVar7) {
                    in_RCX[1] = pauVar5;
                }
                if (*(undefined8 **)(*pauVar7 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(*pauVar7 + 8) = *(undefined8 *)*pauVar7;
                }
                if (*(int64_t *)*pauVar7 != 0) {
                    *(undefined8 *)(*(int64_t *)*pauVar7 + 8) = *(undefined8 *)(*pauVar7 + 8);
                }
                in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                *pauVar7 = ZEXT816(0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020b47b;
                fcn.180224990(pauVar7, 0x1804ba210, 0x118);
            }
            pauVar7 = pauVar6;
        } while (pauVar6 != (undefined (*) [16])0x0);
    }
    return 1;
}

// ============================================================
// Function: FUN_18020b3fd
// Address: 0x18020b3fd
// Size: 221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18020b3b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined (**in_RCX) [16];
    uint64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined (*pauVar7) [16];
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b3c6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *in_RDX;
    uVar2 = in_RDX[1];
    if (uVar2 < uVar1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    pauVar7 = in_RCX[1];
    if (pauVar7 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        do {
            uVar3 = *(uint64_t *)(pauVar7[1] + 8);
            pauVar6 = *(undefined (**) [16])(*pauVar7 + 8);
            if (uVar3 < uVar1) {
                return 1;
            }
            if (*(uint64_t *)pauVar7[1] < uVar1) {
                if (uVar2 < uVar3) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020b4a6;
                    pauVar6 = (undefined (*) [16])
                              fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                            *(int64_t *)(&stack0x00000048 + iVar4));
                    *(undefined (**) [16])(*pauVar6 + 8) = pauVar7;
                    *(undefined8 *)*pauVar6 = *(undefined8 *)*pauVar7;
                    if (*(int64_t *)*pauVar7 != 0) {
                        *(undefined (**) [16])(*(int64_t *)*pauVar7 + 8) = pauVar6;
                    }
                    *(undefined (**) [16])*pauVar7 = pauVar6;
                    if (in_RCX[1] == pauVar7) {
                        in_RCX[1] = pauVar6;
                    }
                    in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                }
                *(uint64_t *)(pauVar7[1] + 8) = uVar1 - 1;
                return 1;
            }
            if (uVar2 < uVar3) {
                if (*(uint64_t *)pauVar7[1] <= uVar2) {
                    *(uint64_t *)pauVar7[1] = uVar2 + 1;
                }
            } else {
                pauVar5 = pauVar6;
                if (*in_RCX == pauVar7) {
                    *in_RCX = *(undefined (**) [16])*pauVar7;
                    pauVar5 = *(undefined (**) [16])(*pauVar7 + 8);
                }
                if (in_RCX[1] == pauVar7) {
                    in_RCX[1] = pauVar5;
                }
                if (*(undefined8 **)(*pauVar7 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(*pauVar7 + 8) = *(undefined8 *)*pauVar7;
                }
                if (*(int64_t *)*pauVar7 != 0) {
                    *(undefined8 *)(*(int64_t *)*pauVar7 + 8) = *(undefined8 *)(*pauVar7 + 8);
                }
                in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                *pauVar7 = ZEXT816(0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020b47b;
                fcn.180224990(pauVar7, 0x1804ba210, 0x118);
            }
            pauVar7 = pauVar6;
        } while (pauVar6 != (undefined (*) [16])0x0);
    }
    return 1;
}

// ============================================================
// Function: FUN_18020b4da
// Address: 0x18020b4da
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18020b3b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined (**in_RCX) [16];
    uint64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined (*pauVar7) [16];
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b3c6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *in_RDX;
    uVar2 = in_RDX[1];
    if (uVar2 < uVar1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    pauVar7 = in_RCX[1];
    if (pauVar7 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        do {
            uVar3 = *(uint64_t *)(pauVar7[1] + 8);
            pauVar6 = *(undefined (**) [16])(*pauVar7 + 8);
            if (uVar3 < uVar1) {
                return 1;
            }
            if (*(uint64_t *)pauVar7[1] < uVar1) {
                if (uVar2 < uVar3) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020b4a6;
                    pauVar6 = (undefined (*) [16])
                              fcn.18020af50(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                            *(int64_t *)(&stack0x00000048 + iVar4));
                    *(undefined (**) [16])(*pauVar6 + 8) = pauVar7;
                    *(undefined8 *)*pauVar6 = *(undefined8 *)*pauVar7;
                    if (*(int64_t *)*pauVar7 != 0) {
                        *(undefined (**) [16])(*(int64_t *)*pauVar7 + 8) = pauVar6;
                    }
                    *(undefined (**) [16])*pauVar7 = pauVar6;
                    if (in_RCX[1] == pauVar7) {
                        in_RCX[1] = pauVar6;
                    }
                    in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
                }
                *(uint64_t *)(pauVar7[1] + 8) = uVar1 - 1;
                return 1;
            }
            if (uVar2 < uVar3) {
                if (*(uint64_t *)pauVar7[1] <= uVar2) {
                    *(uint64_t *)pauVar7[1] = uVar2 + 1;
                }
            } else {
                pauVar5 = pauVar6;
                if (*in_RCX == pauVar7) {
                    *in_RCX = *(undefined (**) [16])*pauVar7;
                    pauVar5 = *(undefined (**) [16])(*pauVar7 + 8);
                }
                if (in_RCX[1] == pauVar7) {
                    in_RCX[1] = pauVar5;
                }
                if (*(undefined8 **)(*pauVar7 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(*pauVar7 + 8) = *(undefined8 *)*pauVar7;
                }
                if (*(int64_t *)*pauVar7 != 0) {
                    *(undefined8 *)(*(int64_t *)*pauVar7 + 8) = *(undefined8 *)(*pauVar7 + 8);
                }
                in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
                *pauVar7 = ZEXT816(0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020b47b;
                fcn.180224990(pauVar7, 0x1804ba210, 0x118);
            }
            pauVar7 = pauVar6;
        } while (pauVar6 != (undefined (*) [16])0x0);
    }
    return 1;
}

// ============================================================
// Function: FUN_18020b500
// Address: 0x18020b500
// Size: 139 bytes
// ============================================================
void fcn.18020b500(undefined (**param_1) [16], int64_t param_2)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined (*pauVar6) [16];
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pauVar6 = *(undefined (**) [16])(param_2 + 8);
    if ((pauVar6 == (undefined (*) [16])0x0) || (*(int64_t *)(param_2 + 0x10) + -1 != *(int64_t *)(pauVar6[1] + 8))) {
        return;
    }
    *(undefined8 *)(param_2 + 0x10) = *(undefined8 *)pauVar6[1];
    if (*param_1 == pauVar6) {
        *param_1 = *(undefined (**) [16])*pauVar6;
    }
    if (param_1[1] == pauVar6) {
        param_1[1] = *(undefined (**) [16])(*pauVar6 + 8);
    }
    if (*(undefined8 **)(*pauVar6 + 8) != (undefined8 *)0x0) {
        **(undefined8 **)(*pauVar6 + 8) = *(undefined8 *)*pauVar6;
    }
    if (*(int64_t *)*pauVar6 != 0) {
        *(undefined8 *)(*(int64_t *)*pauVar6 + 8) = *(undefined8 *)(*pauVar6 + 8);
    }
    param_1[2] = (undefined (*) [16])(param_1[2][-1] + 0xf);
    *pauVar6 = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350(pauVar6, 0x1804ba210, 0x58);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (pauVar6 != (undefined (*) [16])0x0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, pauVar6);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18020b590
// Address: 0x18020b590
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020b590(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t iVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b5a0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *in_RCX;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RDI;
        do {
            iVar1 = *(int64_t *)(iVar7 + 8);
            if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar2 = *(int64_t *)(iVar7 + 0x28), iVar2 != 0)) {
                iVar3 = *(int64_t *)(iVar7 + 0x18);
                iVar4 = *(int64_t *)(iVar7 + 0x10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5d3;
                func_0x000180244fc0(iVar2, iVar3 - iVar4);
            }
            uVar5 = *(undefined8 *)(iVar7 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5dc;
            func_0x0001802054c0(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5f1;
            fcn.180224990(iVar7, 0x1804ba228, 0x1b);
            iVar7 = iVar1;
        } while (iVar1 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_18020b5ae
// Address: 0x18020b5ae
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020b590(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t iVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b5a0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *in_RCX;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RDI;
        do {
            iVar1 = *(int64_t *)(iVar7 + 8);
            if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar2 = *(int64_t *)(iVar7 + 0x28), iVar2 != 0)) {
                iVar3 = *(int64_t *)(iVar7 + 0x18);
                iVar4 = *(int64_t *)(iVar7 + 0x10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5d3;
                func_0x000180244fc0(iVar2, iVar3 - iVar4);
            }
            uVar5 = *(undefined8 *)(iVar7 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5dc;
            func_0x0001802054c0(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5f1;
            fcn.180224990(iVar7, 0x1804ba228, 0x1b);
            iVar7 = iVar1;
        } while (iVar1 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_18020b5fe
// Address: 0x18020b5fe
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020b590(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t iVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020b5a0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *in_RCX;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RDI;
        do {
            iVar1 = *(int64_t *)(iVar7 + 8);
            if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar2 = *(int64_t *)(iVar7 + 0x28), iVar2 != 0)) {
                iVar3 = *(int64_t *)(iVar7 + 0x18);
                iVar4 = *(int64_t *)(iVar7 + 0x10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5d3;
                func_0x000180244fc0(iVar2, iVar3 - iVar4);
            }
            uVar5 = *(undefined8 *)(iVar7 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5dc;
            func_0x0001802054c0(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020b5f1;
            fcn.180224990(iVar7, 0x1804ba228, 0x1b);
            iVar7 = iVar1;
        } while (iVar1 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_18020b610
// Address: 0x18020b610
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18020b610(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar6;
    undefined8 *puVar7;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18020b620;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((uint64_t)in_RCX[4] <= in_RDX) {
        if (in_RCX[1] == 0) {
            if (in_RDX == in_RCX[4]) goto code_r0x00018020b653;
        } else if (in_RDX <= *(uint64_t *)(in_RCX[1] + 0x18)) {
code_r0x00018020b653:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            puVar7 = (undefined8 *)*in_RCX;
            in_RCX[4] = in_RDX;
            if (puVar7 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                puVar6 = puVar7;
                do {
                    puVar7 = puVar6;
                    if (in_RDX < (uint64_t)puVar6[3]) break;
                    puVar7 = (undefined8 *)puVar6[1];
                    in_RCX[3] = in_RCX[3] + -1;
                    if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar1 = puVar6[5], iVar1 != 0)) {
                        iVar2 = puVar6[3];
                        iVar3 = puVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a0;
                        func_0x000180244fc0(iVar1, iVar2 - iVar3);
                    }
                    uVar4 = puVar6[4];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a9;
                    func_0x0001802054c0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6be;
                    fcn.180224990(puVar6, 0x1804ba228, 0x1b);
                    puVar6 = puVar7;
                } while (puVar7 != (undefined8 *)0x0);
            }
            *in_RCX = puVar7;
            if (puVar7 == (undefined8 *)0x0) {
                in_RCX[1] = 0;
                *(undefined4 *)(in_RCX + 5) = 0;
                return 1;
            }
            *puVar7 = 0;
            *(undefined4 *)(in_RCX + 5) = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b653
// Address: 0x18020b653
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18020b610(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar6;
    undefined8 *puVar7;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18020b620;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((uint64_t)in_RCX[4] <= in_RDX) {
        if (in_RCX[1] == 0) {
            if (in_RDX == in_RCX[4]) goto code_r0x00018020b653;
        } else if (in_RDX <= *(uint64_t *)(in_RCX[1] + 0x18)) {
code_r0x00018020b653:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            puVar7 = (undefined8 *)*in_RCX;
            in_RCX[4] = in_RDX;
            if (puVar7 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                puVar6 = puVar7;
                do {
                    puVar7 = puVar6;
                    if (in_RDX < (uint64_t)puVar6[3]) break;
                    puVar7 = (undefined8 *)puVar6[1];
                    in_RCX[3] = in_RCX[3] + -1;
                    if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar1 = puVar6[5], iVar1 != 0)) {
                        iVar2 = puVar6[3];
                        iVar3 = puVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a0;
                        func_0x000180244fc0(iVar1, iVar2 - iVar3);
                    }
                    uVar4 = puVar6[4];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a9;
                    func_0x0001802054c0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6be;
                    fcn.180224990(puVar6, 0x1804ba228, 0x1b);
                    puVar6 = puVar7;
                } while (puVar7 != (undefined8 *)0x0);
            }
            *in_RCX = puVar7;
            if (puVar7 == (undefined8 *)0x0) {
                in_RCX[1] = 0;
                *(undefined4 *)(in_RCX + 5) = 0;
                return 1;
            }
            *puVar7 = 0;
            *(undefined4 *)(in_RCX + 5) = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b664
// Address: 0x18020b664
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18020b610(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar6;
    undefined8 *puVar7;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18020b620;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((uint64_t)in_RCX[4] <= in_RDX) {
        if (in_RCX[1] == 0) {
            if (in_RDX == in_RCX[4]) goto code_r0x00018020b653;
        } else if (in_RDX <= *(uint64_t *)(in_RCX[1] + 0x18)) {
code_r0x00018020b653:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            puVar7 = (undefined8 *)*in_RCX;
            in_RCX[4] = in_RDX;
            if (puVar7 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                puVar6 = puVar7;
                do {
                    puVar7 = puVar6;
                    if (in_RDX < (uint64_t)puVar6[3]) break;
                    puVar7 = (undefined8 *)puVar6[1];
                    in_RCX[3] = in_RCX[3] + -1;
                    if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar1 = puVar6[5], iVar1 != 0)) {
                        iVar2 = puVar6[3];
                        iVar3 = puVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a0;
                        func_0x000180244fc0(iVar1, iVar2 - iVar3);
                    }
                    uVar4 = puVar6[4];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a9;
                    func_0x0001802054c0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6be;
                    fcn.180224990(puVar6, 0x1804ba228, 0x1b);
                    puVar6 = puVar7;
                } while (puVar7 != (undefined8 *)0x0);
            }
            *in_RCX = puVar7;
            if (puVar7 == (undefined8 *)0x0) {
                in_RCX[1] = 0;
                *(undefined4 *)(in_RCX + 5) = 0;
                return 1;
            }
            *puVar7 = 0;
            *(undefined4 *)(in_RCX + 5) = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b6c8
// Address: 0x18020b6c8
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18020b610(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar6;
    undefined8 *puVar7;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18020b620;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((uint64_t)in_RCX[4] <= in_RDX) {
        if (in_RCX[1] == 0) {
            if (in_RDX == in_RCX[4]) goto code_r0x00018020b653;
        } else if (in_RDX <= *(uint64_t *)(in_RCX[1] + 0x18)) {
code_r0x00018020b653:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            puVar7 = (undefined8 *)*in_RCX;
            in_RCX[4] = in_RDX;
            if (puVar7 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                puVar6 = puVar7;
                do {
                    puVar7 = puVar6;
                    if (in_RDX < (uint64_t)puVar6[3]) break;
                    puVar7 = (undefined8 *)puVar6[1];
                    in_RCX[3] = in_RCX[3] + -1;
                    if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar1 = puVar6[5], iVar1 != 0)) {
                        iVar2 = puVar6[3];
                        iVar3 = puVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a0;
                        func_0x000180244fc0(iVar1, iVar2 - iVar3);
                    }
                    uVar4 = puVar6[4];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a9;
                    func_0x0001802054c0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6be;
                    fcn.180224990(puVar6, 0x1804ba228, 0x1b);
                    puVar6 = puVar7;
                } while (puVar7 != (undefined8 *)0x0);
            }
            *in_RCX = puVar7;
            if (puVar7 == (undefined8 *)0x0) {
                in_RCX[1] = 0;
                *(undefined4 *)(in_RCX + 5) = 0;
                return 1;
            }
            *puVar7 = 0;
            *(undefined4 *)(in_RCX + 5) = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b6ed
// Address: 0x18020b6ed
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18020b610(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar6;
    undefined8 *puVar7;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18020b620;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((uint64_t)in_RCX[4] <= in_RDX) {
        if (in_RCX[1] == 0) {
            if (in_RDX == in_RCX[4]) goto code_r0x00018020b653;
        } else if (in_RDX <= *(uint64_t *)(in_RCX[1] + 0x18)) {
code_r0x00018020b653:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            puVar7 = (undefined8 *)*in_RCX;
            in_RCX[4] = in_RDX;
            if (puVar7 != (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                puVar6 = puVar7;
                do {
                    puVar7 = puVar6;
                    if (in_RDX < (uint64_t)puVar6[3]) break;
                    puVar7 = (undefined8 *)puVar6[1];
                    in_RCX[3] = in_RCX[3] + -1;
                    if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar1 = puVar6[5], iVar1 != 0)) {
                        iVar2 = puVar6[3];
                        iVar3 = puVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a0;
                        func_0x000180244fc0(iVar1, iVar2 - iVar3);
                    }
                    uVar4 = puVar6[4];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6a9;
                    func_0x0001802054c0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020b6be;
                    fcn.180224990(puVar6, 0x1804ba228, 0x1b);
                    puVar6 = puVar7;
                } while (puVar7 != (undefined8 *)0x0);
            }
            *in_RCX = puVar7;
            if (puVar7 == (undefined8 *)0x0) {
                in_RCX[1] = 0;
                *(undefined4 *)(in_RCX + 5) = 0;
                return 1;
            }
            *puVar7 = 0;
            *(undefined4 *)(in_RCX + 5) = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020b720
// Address: 0x18020b720
// Size: 655 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.18020b720(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **in_RCX;
    uint64_t *in_RDX;
    int64_t *piVar11;
    int64_t *piVar12;
    int64_t *in_R8;
    int64_t *in_R9;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x18020b742;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    piVar1 = (int64_t *)in_RDX[1];
    uVar13 = 0;
    if (piVar1 <= in_RCX[4]) goto code_r0x00018020b7be;
    piVar11 = in_RCX[1];
    if (piVar11 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b782;
        ppiVar10 = (int64_t **)func_0x000180224d60(0x30, 0x1804ba228, 0x21);
        if (ppiVar10 == (int64_t **)0x0) {
            *in_RCX = (int64_t *)0x0;
            in_RCX[1] = (int64_t *)0x0;
            return 0;
        }
        if (in_R8 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b7a2;
            func_0x000180205510(in_R8);
        }
        uVar5 = *(undefined4 *)in_RDX;
        uVar6 = *(undefined4 *)((int64_t)in_RDX + 4);
        uVar7 = *(undefined4 *)(in_RDX + 1);
        uVar8 = *(undefined4 *)((int64_t)in_RDX + 0xc);
        ppiVar10[4] = in_R8;
        ppiVar10[5] = in_R9;
        *(undefined4 *)(ppiVar10 + 2) = uVar5;
        *(undefined4 *)((int64_t)ppiVar10 + 0x14) = uVar6;
        *(undefined4 *)(ppiVar10 + 3) = uVar7;
        *(undefined4 *)((int64_t)ppiVar10 + 0x1c) = uVar8;
        *in_RCX = (int64_t *)ppiVar10;
code_r0x00018020b7b6:
        in_RCX[1] = (int64_t *)ppiVar10;
    } else {
        if ((uint64_t)piVar11[2] < *in_RDX) {
            if (piVar1 <= (int64_t *)piVar11[3]) goto code_r0x00018020b7be;
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b81f;
            ppiVar10 = (int64_t **)func_0x000180224d60(0x30, 0x1804ba228, 0x21);
            if (ppiVar10 == (int64_t **)0x0) {
                return 0;
            }
            if (in_R8 != (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b838;
                func_0x000180205510(in_R8);
            }
            uVar5 = *(undefined4 *)in_RDX;
            uVar6 = *(undefined4 *)((int64_t)in_RDX + 4);
            uVar7 = *(undefined4 *)(in_RDX + 1);
            uVar8 = *(undefined4 *)((int64_t)in_RDX + 0xc);
            ppiVar10[4] = in_R8;
            ppiVar10[5] = in_R9;
            *(undefined4 *)(ppiVar10 + 2) = uVar5;
            *(undefined4 *)((int64_t)ppiVar10 + 0x14) = uVar6;
            *(undefined4 *)(ppiVar10 + 3) = uVar7;
            *(undefined4 *)((int64_t)ppiVar10 + 0x1c) = uVar8;
            *ppiVar10 = in_RCX[1];
            if (in_RCX[1] != (int64_t *)0x0) {
                in_RCX[1][1] = (int64_t)ppiVar10;
            }
            goto code_r0x00018020b7b6;
        }
        piVar11 = (int64_t *)0x0;
        piVar12 = *in_RCX;
        if (*in_RCX == (int64_t *)0x0) {
            return 0;
        }
        while ((uint64_t)piVar12[2] < *in_RDX) {
            ppiVar10 = (int64_t **)(piVar12 + 1);
            piVar11 = piVar12;
            piVar12 = *ppiVar10;
            if (*ppiVar10 == (int64_t *)0x0) {
                return 0;
            }
        }
        if ((piVar11 != (int64_t *)0x0) && (piVar1 <= (int64_t *)piVar11[3])) goto code_r0x00018020b7be;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b8b4;
        ppiVar10 = (int64_t **)func_0x000180224d60(0x30, 0x1804ba228, 0x21);
        if (ppiVar10 == (int64_t **)0x0) {
            return 0;
        }
        if (in_R8 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b8cd;
            func_0x000180205510(in_R8);
        }
        uVar5 = *(undefined4 *)in_RDX;
        uVar6 = *(undefined4 *)((int64_t)in_RDX + 4);
        uVar7 = *(undefined4 *)(in_RDX + 1);
        uVar8 = *(undefined4 *)((int64_t)in_RDX + 0xc);
        ppiVar10[4] = in_R8;
        ppiVar10[5] = in_R9;
        *(undefined4 *)(ppiVar10 + 2) = uVar5;
        *(undefined4 *)((int64_t)ppiVar10 + 0x14) = uVar6;
        *(undefined4 *)(ppiVar10 + 3) = uVar7;
        *(undefined4 *)((int64_t)ppiVar10 + 0x1c) = uVar8;
        do {
            if (in_RDX[1] < (uint64_t)piVar12[3]) {
                if ((piVar11 != (int64_t *)0x0) && ((uint64_t)piVar12[2] <= (uint64_t)piVar11[3])) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b98a;
                    func_0x00018020bae0(in_RCX, ppiVar10);
                    goto code_r0x00018020b7be;
                }
                *piVar12 = (int64_t)ppiVar10;
                goto code_r0x00018020b992;
            }
            piVar1 = (int64_t *)piVar12[1];
            if (piVar1 != (int64_t *)0x0) {
                *piVar1 = *piVar12;
            }
            if (piVar11 != (int64_t *)0x0) {
                piVar11[1] = (int64_t)piVar12[1];
            }
            if (*in_RCX == piVar12) {
                *in_RCX = piVar1;
            }
            if (in_RCX[1] == piVar12) {
                in_RCX[1] = piVar11;
            }
            in_RCX[3] = (int64_t *)((int64_t)in_RCX[3] + -1);
            if ((*(int32_t *)((int64_t)in_RCX + 0x2c) != 0) && (iVar2 = piVar12[5], iVar2 != 0)) {
                uVar3 = piVar12[3];
                iVar4 = piVar12[2];
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b943;
                func_0x000180244fc0(iVar2, uVar3 - iVar4);
            }
            iVar2 = piVar12[4];
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b94c;
            func_0x0001802054c0(iVar2);
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x18020b961;
            fcn.180224990(piVar12, 0x1804ba228, 0x1b);
            piVar12 = piVar1;
        } while (piVar1 != (int64_t *)0x0);
        in_RCX[1] = (int64_t *)ppiVar10;
code_r0x00018020b992:
        ppiVar10[1] = piVar12;
        *ppiVar10 = piVar11;
        if (piVar11 == (int64_t *)0x0) {
            *in_RCX = (int64_t *)ppiVar10;
        } else {
            piVar11[1] = (int64_t)ppiVar10;
        }
    }
    in_RCX[3] = (int64_t *)((int64_t)in_RCX[3] + 1);
code_r0x00018020b7be:
    if ((*(int32_t *)((int64_t)&arg_48h + iVar9) != 0) || (*(int32_t *)(in_RCX + 2) != 0)) {
        uVar13 = 1;
    }
    *(undefined4 *)(in_RCX + 2) = uVar13;
    return 1;
}

// ============================================================
// Function: FUN_18020bae0
// Address: 0x18020bae0
// Size: 81 bytes
// ============================================================
void fcn.18020bae0(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020baec;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*(int32_t *)(param_1 + 0x2c) != 0) && (iVar6 = *(int64_t *)(param_2 + 0x28), iVar6 != 0)) {
        iVar1 = *(int64_t *)(param_2 + 0x18);
        iVar2 = *(int64_t *)(param_2 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020bb0e;
        func_0x000180244fc0(iVar6, iVar1 - iVar2);
    }
    uVar8 = *(undefined8 *)(param_2 + 0x20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020bb17;
    func_0x0001802054c0(uVar8);
    uVar8 = *(undefined8 *)((int64_t)auStackX_18 + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x18022499a;
    iVar6 = fcn.18045a350(param_2, 0x1804ba228, 0x1b);
    iVar6 = -iVar6;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_2 != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar5) = uVar8;
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18047ca3c;
            iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_2);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18047ca46;
                uVar4 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18047ca4d;
                uVar4 = fcn.18046b63c(uVar4);
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18047ca54;
                puVar7 = (undefined4 *)fcn.18046b77c();
                *puVar7 = uVar4;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18020bb80
// Address: 0x18020bb80
// Size: 22 bytes
// ============================================================
uint64_t fcn.18020bb80(int64_t arg_40h, int64_t arg_60h, int64_t arg_80h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t in_R8;
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBX;
    *(undefined8 *)(&stack0x00000030 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000028 + iVar6) = 0x1801d6070;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int64_t *)(in_RCX + 0x1140) != 0) && (*(int64_t *)(in_RCX + 0x1020) != 0)) {
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x1801d6094;
        uVar4 = func_0x00018020e940();
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x1801d609c;
        uVar2 = func_0x00018020ef80(uVar4);
        if ((((uVar2 >> 0x17 & 1) != 0) &&
            ((((iVar1 = *(int32_t *)(in_RCX + 0x14), iVar1 == 0x302 || (iVar1 == 0x303)) || (iVar1 == 0x100)) ||
             ((iVar1 == 0xfeff || (iVar1 == 0xfefd)))))) && (in_R8 != 0)) {
            uVar5 = (in_R8 - 1U) / **(uint64_t **)((int64_t)&arg_80h + iVar3 + iVar6) + 1;
            if (*(uint64_t *)(in_RCX + 0x1140) <= uVar5) {
                uVar5 = *(uint64_t *)(in_RCX + 0x1140);
            }
            return uVar5;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020bba0
// Address: 0x18020bba0
// Size: 32 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1110h because it doesn't fit into ProtoModel

bool fcn.18020bba0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020bbaa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18020bbb2;
    iVar1 = fcn.1801d7bb0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_18020bbc0
// Address: 0x18020bbc0
// Size: 256 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18020bbc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t iVar6;
    uint64_t uVar7;
    uint32_t in_EDX;
    uint8_t *puVar8;
    uint64_t uVar9;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020bbda;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bbeb;
    iVar3 = func_0x00018020bfa0();
    if ((iVar3 == 0) || (1 < in_EDX)) {
code_r0x00018020bc97:
        *(undefined *)(in_RCX + 4) = 1;
        goto code_r0x00018020bc9b;
    }
    uVar1 = *(uint64_t *)(in_RCX + 0x50);
    uVar7 = *(uint64_t *)(in_RCX + 0x48);
    if (uVar1 <= uVar7) {
        if (uVar1 == 0) {
            uVar9 = 0x10;
            iVar5 = in_RCX + 0x11;
code_r0x00018020bc55:
            uVar7 = *(uint64_t *)(in_RCX + 0x48);
            *(int64_t *)(in_RCX + 8) = iVar5;
        } else {
            uVar9 = uVar1 * 2;
            if (uVar1 < uVar9) {
                iVar5 = in_RCX + 0x11;
                if (0x10 < uVar9) {
                    iVar6 = *(int64_t *)(in_RCX + 8);
                    if (iVar6 == iVar5) {
                        iVar6 = 0;
                        *(undefined8 *)(in_RCX + 8) = 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bc50;
                    iVar5 = func_0x0001802249c0(iVar6, uVar9, 0x1804ba480, 0x82);
                    if (iVar5 == 0) goto code_r0x00018020bc97;
                }
                goto code_r0x00018020bc55;
            }
        }
        *(uint64_t *)(in_RCX + 0x50) = uVar9;
    }
    puVar8 = (uint8_t *)(*(int64_t *)(in_RCX + 8) + uVar7);
    if (in_EDX == 0) {
        *puVar8 = *puVar8 & ~(uint8_t)(1 << (*(uint8_t *)(in_RCX + 5) & 0x1f));
    } else {
        *puVar8 = *puVar8 | (char)in_EDX << (*(uint8_t *)(in_RCX + 5) & 0x1f);
    }
    uVar2 = *(char *)(in_RCX + 5) + 1U & 7;
    *(uint8_t *)(in_RCX + 5) = uVar2;
    if (uVar2 == 0) {
        *(int64_t *)(in_RCX + 0x48) = *(int64_t *)(in_RCX + 0x48) + 1;
    }
code_r0x00018020bc9b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bca7;
    func_0x00018020c1a0(in_RCX, in_R8 & 0xff);
    *(undefined *)(in_RCX + 0x10) = 1;
    return;
}

// ============================================================
// Function: FUN_18020bcc0
// Address: 0x18020bcc0
// Size: 331 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18020bcc0(int64_t arg_28h)
{
    uint8_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t uVar6;
    uint8_t *in_RCX;
    uint32_t in_EDX;
    int64_t iVar7;
    uint8_t uVar8;
    uint64_t in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020bcd0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = in_RCX[0x10];
    if (in_RCX[4] != 0) {
        return;
    }
    uVar8 = in_RCX[5];
    iVar2 = *(int64_t *)(in_RCX + 0x48);
    in_RCX[0x10] = 0;
    if (uVar8 == 0) {
        if (iVar2 != 0) {
            uVar6 = 7;
            iVar7 = iVar2 + -1;
            goto code_r0x00018020bd1e;
        }
        uVar3 = 0xffffffff;
    } else {
        uVar6 = uVar8 - 1;
        iVar7 = iVar2;
code_r0x00018020bd1e:
        uVar3 = (uint32_t)(((uint8_t)(1 << (uVar6 & 0x1f)) & *(uint8_t *)(iVar7 + *(int64_t *)(in_RCX + 8))) != 0);
    }
    if (((uVar3 == in_EDX) && ((in_EDX != 0 || (in_RCX[6] != 1)))) && ((iVar2 != 0 || (uVar8 != 0)))) {
        if (uVar8 == 0) {
            uVar8 = 7;
            *(int64_t *)(in_RCX + 0x48) = iVar2 + -1;
        } else {
            uVar8 = uVar8 - 1;
        }
        in_RCX[5] = uVar8;
        if (uVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020bd83;
            func_0x00018020be10(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020bd8f;
        func_0x00018020c1a0(in_RCX, in_R8 & 0xff);
        if ((in_RCX[5] != 0) || (*(int64_t *)(in_RCX + 0x48) != 0)) {
            in_RCX[6] = 2;
            return;
        }
        in_RCX[6] = 2;
        if ((*in_RCX & 1) == 0) {
            return;
        }
        if (in_RCX[4] != 0) {
            return;
        }
        if (in_RCX[0x10] != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020bdb9;
            func_0x00018020be10(in_RCX);
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020bdce;
            iVar4 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar4 == 0) goto code_r0x00018020bdfc;
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = 10;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
        return;
    }
code_r0x00018020bdfc:
    in_RCX[4] = 1;
    return;
}

// ============================================================
// Function: FUN_18020be10
// Address: 0x18020be10
// Size: 33 bytes
// ============================================================
void fcn.18020be10(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint8_t *in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    char *pcVar8;
    undefined8 unaff_R15;
    int64_t iVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020be1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX[0x10] = 0;
    if ((*in_RCX & 2) != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be3b;
        func_0x00018020c1a0();
        iVar9 = ((uint64_t)in_RCX[5] + *(int64_t *)(in_RCX + 0x48) * 8) * 4;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
            do {
                if (in_RCX[4] == 0) {
                    if (in_RCX[0x10] != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be88;
                        fcn.18020be10(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000090 + iVar4));
                    }
                    pcVar8 = "    ";
                    cVar6 = ' ';
                    do {
                        uVar7 = *(uint64_t *)(in_RCX + 0x40);
                        pcVar8 = pcVar8 + 1;
                        if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            uVar5 = 0;
                            if (uVar7 != 0) {
                                do {
                                    iVar1 = *(int64_t *)(in_RCX + 0x30);
                                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bed7;
                                    iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, 
                                                                (int64_t)&arg_48h + iVar4);
                                    uVar7 = *(uint64_t *)(in_RCX + 0x40);
                                    if (iVar3 == 0) {
                                        iVar1 = *(int64_t *)(in_RCX + 0x30);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bf1a;
                                        func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                        *(undefined8 *)(in_RCX + 0x40) = 0;
                                        in_RCX[4] = 1;
                                        goto code_r0x00018020bf22;
                                    }
                                    uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_48h + iVar4);
                                } while (uVar5 < uVar7);
                            }
                            *(undefined8 *)(in_RCX + 0x40) = 0;
                            uVar7 = 0;
                        }
                        *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                        cVar6 = *pcVar8;
                    } while (cVar6 != '\0');
                }
code_r0x00018020bf22:
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020be31
// Address: 0x18020be31
// Size: 35 bytes
// ============================================================
void fcn.18020be10(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint8_t *in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    char *pcVar8;
    undefined8 unaff_R15;
    int64_t iVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020be1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX[0x10] = 0;
    if ((*in_RCX & 2) != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be3b;
        func_0x00018020c1a0();
        iVar9 = ((uint64_t)in_RCX[5] + *(int64_t *)(in_RCX + 0x48) * 8) * 4;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
            do {
                if (in_RCX[4] == 0) {
                    if (in_RCX[0x10] != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be88;
                        fcn.18020be10(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000090 + iVar4));
                    }
                    pcVar8 = "    ";
                    cVar6 = ' ';
                    do {
                        uVar7 = *(uint64_t *)(in_RCX + 0x40);
                        pcVar8 = pcVar8 + 1;
                        if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            uVar5 = 0;
                            if (uVar7 != 0) {
                                do {
                                    iVar1 = *(int64_t *)(in_RCX + 0x30);
                                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bed7;
                                    iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, 
                                                                (int64_t)&arg_48h + iVar4);
                                    uVar7 = *(uint64_t *)(in_RCX + 0x40);
                                    if (iVar3 == 0) {
                                        iVar1 = *(int64_t *)(in_RCX + 0x30);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bf1a;
                                        func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                        *(undefined8 *)(in_RCX + 0x40) = 0;
                                        in_RCX[4] = 1;
                                        goto code_r0x00018020bf22;
                                    }
                                    uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_48h + iVar4);
                                } while (uVar5 < uVar7);
                            }
                            *(undefined8 *)(in_RCX + 0x40) = 0;
                            uVar7 = 0;
                        }
                        *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                        cVar6 = *pcVar8;
                    } while (cVar6 != '\0');
                }
code_r0x00018020bf22:
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020be54
// Address: 0x18020be54
// Size: 241 bytes
// ============================================================
void fcn.18020be10(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint8_t *in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    char *pcVar8;
    undefined8 unaff_R15;
    int64_t iVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020be1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX[0x10] = 0;
    if ((*in_RCX & 2) != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be3b;
        func_0x00018020c1a0();
        iVar9 = ((uint64_t)in_RCX[5] + *(int64_t *)(in_RCX + 0x48) * 8) * 4;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
            do {
                if (in_RCX[4] == 0) {
                    if (in_RCX[0x10] != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be88;
                        fcn.18020be10(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000090 + iVar4));
                    }
                    pcVar8 = "    ";
                    cVar6 = ' ';
                    do {
                        uVar7 = *(uint64_t *)(in_RCX + 0x40);
                        pcVar8 = pcVar8 + 1;
                        if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            uVar5 = 0;
                            if (uVar7 != 0) {
                                do {
                                    iVar1 = *(int64_t *)(in_RCX + 0x30);
                                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bed7;
                                    iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, 
                                                                (int64_t)&arg_48h + iVar4);
                                    uVar7 = *(uint64_t *)(in_RCX + 0x40);
                                    if (iVar3 == 0) {
                                        iVar1 = *(int64_t *)(in_RCX + 0x30);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bf1a;
                                        func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                        *(undefined8 *)(in_RCX + 0x40) = 0;
                                        in_RCX[4] = 1;
                                        goto code_r0x00018020bf22;
                                    }
                                    uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_48h + iVar4);
                                } while (uVar5 < uVar7);
                            }
                            *(undefined8 *)(in_RCX + 0x40) = 0;
                            uVar7 = 0;
                        }
                        *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                        cVar6 = *pcVar8;
                    } while (cVar6 != '\0');
                }
code_r0x00018020bf22:
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020bf45
// Address: 0x18020bf45
// Size: 5 bytes
// ============================================================
void fcn.18020be10(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint8_t *in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    char *pcVar8;
    undefined8 unaff_R15;
    int64_t iVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020be1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX[0x10] = 0;
    if ((*in_RCX & 2) != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be3b;
        func_0x00018020c1a0();
        iVar9 = ((uint64_t)in_RCX[5] + *(int64_t *)(in_RCX + 0x48) * 8) * 4;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
            do {
                if (in_RCX[4] == 0) {
                    if (in_RCX[0x10] != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be88;
                        fcn.18020be10(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000090 + iVar4));
                    }
                    pcVar8 = "    ";
                    cVar6 = ' ';
                    do {
                        uVar7 = *(uint64_t *)(in_RCX + 0x40);
                        pcVar8 = pcVar8 + 1;
                        if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            uVar5 = 0;
                            if (uVar7 != 0) {
                                do {
                                    iVar1 = *(int64_t *)(in_RCX + 0x30);
                                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bed7;
                                    iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, 
                                                                (int64_t)&arg_48h + iVar4);
                                    uVar7 = *(uint64_t *)(in_RCX + 0x40);
                                    if (iVar3 == 0) {
                                        iVar1 = *(int64_t *)(in_RCX + 0x30);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bf1a;
                                        func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                        *(undefined8 *)(in_RCX + 0x40) = 0;
                                        in_RCX[4] = 1;
                                        goto code_r0x00018020bf22;
                                    }
                                    uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_48h + iVar4);
                                } while (uVar5 < uVar7);
                            }
                            *(undefined8 *)(in_RCX + 0x40) = 0;
                            uVar7 = 0;
                        }
                        *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                        cVar6 = *pcVar8;
                    } while (cVar6 != '\0');
                }
code_r0x00018020bf22:
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020bf4a
// Address: 0x18020bf4a
// Size: 6 bytes
// ============================================================
void fcn.18020be10(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint8_t *in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    char cVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    char *pcVar8;
    undefined8 unaff_R15;
    int64_t iVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020be1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX[0x10] = 0;
    if ((*in_RCX & 2) != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be3b;
        func_0x00018020c1a0();
        iVar9 = ((uint64_t)in_RCX[5] + *(int64_t *)(in_RCX + 0x48) * 8) * 4;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
            do {
                if (in_RCX[4] == 0) {
                    if (in_RCX[0x10] != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020be88;
                        fcn.18020be10(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000090 + iVar4));
                    }
                    pcVar8 = "    ";
                    cVar6 = ' ';
                    do {
                        uVar7 = *(uint64_t *)(in_RCX + 0x40);
                        pcVar8 = pcVar8 + 1;
                        if (*(uint64_t *)(in_RCX + 0x38) == uVar7) {
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            uVar5 = 0;
                            if (uVar7 != 0) {
                                do {
                                    iVar1 = *(int64_t *)(in_RCX + 0x30);
                                    uVar2 = *(undefined8 *)(in_RCX + 0x28);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bed7;
                                    iVar3 = func_0x00018021b300(uVar2, iVar1 + uVar5, uVar7 - uVar5, 
                                                                (int64_t)&arg_48h + iVar4);
                                    uVar7 = *(uint64_t *)(in_RCX + 0x40);
                                    if (iVar3 == 0) {
                                        iVar1 = *(int64_t *)(in_RCX + 0x30);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020bf1a;
                                        func_0x000180498030(iVar1, iVar1 + uVar5, uVar7 - uVar5);
                                        *(undefined8 *)(in_RCX + 0x40) = 0;
                                        in_RCX[4] = 1;
                                        goto code_r0x00018020bf22;
                                    }
                                    uVar5 = uVar5 + *(int64_t *)((int64_t)&arg_48h + iVar4);
                                } while (uVar5 < uVar7);
                            }
                            *(undefined8 *)(in_RCX + 0x40) = 0;
                            uVar7 = 0;
                        }
                        *(char *)(uVar7 + *(int64_t *)(in_RCX + 0x30)) = cVar6;
                        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                        cVar6 = *pcVar8;
                    } while (cVar6 != '\0');
                }
code_r0x00018020bf22:
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020bfa0
// Address: 0x18020bfa0
// Size: 144 bytes
// ============================================================
undefined8 fcn.18020bfa0(uint8_t *param_1)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020bfac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1[4] == 0) {
        uVar1 = param_1[6];
        if (uVar1 != 0) {
            if (uVar1 == 1) {
                return 1;
            }
            if (uVar1 == 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020bfd2;
                iVar2 = fcn.18020bf50(param_1);
                if (iVar2 != 0) {
                    if (iVar2 != 1) {
                        if ((iVar2 < 0) && ((*param_1 & 1) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020c015;
                            fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                        }
                        param_1[6] = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020bfe5;
                    fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (param_1[4] != 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020bff3;
                    fcn.18020be10(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000038 + iVar3)
                                  , *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                                  *(int64_t *)(&stack0x00000090 + iVar3));
                    param_1[6] = 1;
                    return 1;
                }
            }
        }
        param_1[4] = 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18020c030
// Address: 0x18020c030
// Size: 193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh

void fcn.18020c030(int64_t arg_50h, int64_t arg_58h)
{
    uint8_t uVar1;
    char cVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBP;
    char *pcVar7;
    int32_t in_R8D;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18020c043;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&var_20h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    pcVar7 = (char *)((int64_t)&var_18h + iVar5 + 5);
    if (((in_R8D == 0) && ((*in_RCX & 4) != 0)) && (0x1fffffffffffff < in_RDX)) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c089;
    iVar4 = fcn.18020bfa0();
    if (iVar4 != 0) {
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c0a0;
            fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        }
        if (in_RDX == 0) {
            pcVar7 = "0";
        } else {
            *(undefined *)((int64_t)&var_18h + iVar5 + 5) = 0;
            do {
                pcVar7 = pcVar7 + -1;
                uVar6 = in_RDX / 10;
                *pcVar7 = (char)in_RDX + (char)uVar6 * -10 + '0';
                in_RDX = uVar6;
            } while (uVar6 != 0);
        }
        if (in_RCX[4] == 0) {
            uVar1 = in_RCX[0x10];
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
            if (uVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c100;
                fcn.18020be10(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                              *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5));
            }
            cVar2 = *pcVar7;
            while (cVar2 != '\0') {
                pcVar7 = pcVar7 + 1;
                if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c129;
                    iVar4 = func_0x00018020cd80(in_RCX + 0x28, 0);
                    if (iVar4 == 0) {
                        in_RCX[4] = 1;
                        break;
                    }
                }
                *(char *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = cVar2;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar2 = *pcVar7;
            }
        }
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c15f;
            fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        }
        if ((in_RCX[5] == 0) && (*(int64_t *)(in_RCX + 0x48) == 0)) {
            in_RCX[6] = 2;
            if ((*in_RCX & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c17f;
                fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            }
        } else {
            in_RCX[6] = 2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c192;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18020c0f1
// Address: 0x18020c0f1
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh

void fcn.18020c030(int64_t arg_50h, int64_t arg_58h)
{
    uint8_t uVar1;
    char cVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBP;
    char *pcVar7;
    int32_t in_R8D;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18020c043;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&var_20h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    pcVar7 = (char *)((int64_t)&var_18h + iVar5 + 5);
    if (((in_R8D == 0) && ((*in_RCX & 4) != 0)) && (0x1fffffffffffff < in_RDX)) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c089;
    iVar4 = fcn.18020bfa0();
    if (iVar4 != 0) {
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c0a0;
            fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        }
        if (in_RDX == 0) {
            pcVar7 = "0";
        } else {
            *(undefined *)((int64_t)&var_18h + iVar5 + 5) = 0;
            do {
                pcVar7 = pcVar7 + -1;
                uVar6 = in_RDX / 10;
                *pcVar7 = (char)in_RDX + (char)uVar6 * -10 + '0';
                in_RDX = uVar6;
            } while (uVar6 != 0);
        }
        if (in_RCX[4] == 0) {
            uVar1 = in_RCX[0x10];
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
            if (uVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c100;
                fcn.18020be10(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                              *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5));
            }
            cVar2 = *pcVar7;
            while (cVar2 != '\0') {
                pcVar7 = pcVar7 + 1;
                if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c129;
                    iVar4 = func_0x00018020cd80(in_RCX + 0x28, 0);
                    if (iVar4 == 0) {
                        in_RCX[4] = 1;
                        break;
                    }
                }
                *(char *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = cVar2;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar2 = *pcVar7;
            }
        }
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c15f;
            fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        }
        if ((in_RCX[5] == 0) && (*(int64_t *)(in_RCX + 0x48) == 0)) {
            in_RCX[6] = 2;
            if ((*in_RCX & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c17f;
                fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            }
        } else {
            in_RCX[6] = 2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c192;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18020c150
// Address: 0x18020c150
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh

void fcn.18020c030(int64_t arg_50h, int64_t arg_58h)
{
    uint8_t uVar1;
    char cVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint8_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBP;
    char *pcVar7;
    int32_t in_R8D;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18020c043;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&var_20h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    pcVar7 = (char *)((int64_t)&var_18h + iVar5 + 5);
    if (((in_R8D == 0) && ((*in_RCX & 4) != 0)) && (0x1fffffffffffff < in_RDX)) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c089;
    iVar4 = fcn.18020bfa0();
    if (iVar4 != 0) {
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c0a0;
            fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        }
        if (in_RDX == 0) {
            pcVar7 = "0";
        } else {
            *(undefined *)((int64_t)&var_18h + iVar5 + 5) = 0;
            do {
                pcVar7 = pcVar7 + -1;
                uVar6 = in_RDX / 10;
                *pcVar7 = (char)in_RDX + (char)uVar6 * -10 + '0';
                in_RDX = uVar6;
            } while (uVar6 != 0);
        }
        if (in_RCX[4] == 0) {
            uVar1 = in_RCX[0x10];
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
            if (uVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c100;
                fcn.18020be10(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                              *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5));
            }
            cVar2 = *pcVar7;
            while (cVar2 != '\0') {
                pcVar7 = pcVar7 + 1;
                if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c129;
                    iVar4 = func_0x00018020cd80(in_RCX + 0x28, 0);
                    if (iVar4 == 0) {
                        in_RCX[4] = 1;
                        break;
                    }
                }
                *(char *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = cVar2;
                *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
                cVar2 = *pcVar7;
            }
        }
        if (bVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c15f;
            fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        }
        if ((in_RCX[5] == 0) && (*(int64_t *)(in_RCX + 0x48) == 0)) {
            in_RCX[6] = 2;
            if ((*in_RCX & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c17f;
                fcn.18020c1a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            }
        } else {
            in_RCX[6] = 2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020c192;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18020c1a0
// Address: 0x18020c1a0
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020c1a0(int64_t arg_28h, int64_t arg_30h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined in_DL;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020c1b0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(in_RCX + 4) == '\0') {
        cVar1 = *(char *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        if (cVar1 != '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020c1cf;
            fcn.18020be10(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000090 + iVar3));
        }
        if (*(int64_t *)(in_RCX + 0x38) == *(int64_t *)(in_RCX + 0x40)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020c1e4;
            iVar2 = func_0x00018020cd80(in_RCX + 0x28, 0);
            if (iVar2 == 0) {
                *(undefined *)(in_RCX + 4) = 1;
                return;
            }
        }
        *(undefined *)(*(int64_t *)(in_RCX + 0x30) + *(int64_t *)(in_RCX + 0x40)) = in_DL;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    }
    return;
}

