// Chunk 128 - 50 functions

// ============================================================
// Function: FUN_1801ba9d0
// Address: 0x1801ba9d0
// Size: 256 bytes
// ============================================================
void fcn.1801ba9d0(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ba9de;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00000218 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    puVar6 = (undefined *)*param_2;
    uVar11 = param_2[1];
    uVar10 = param_2[1];
    *(undefined **)((int64_t)&var_8h + iVar8) = puVar6;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar11;
    if (1 < uVar10) {
        uVar10 = uVar10 - 2;
        uVar12 = (uint64_t)CONCAT11(*puVar6, puVar6[1]);
        if (uVar12 <= uVar10) {
            *(undefined **)((int64_t)&var_8h + iVar8) = puVar6 + 2 + uVar12;
            *(uint64_t *)((int64_t)&var_10h + iVar8) = uVar10 - uVar12;
            uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar8 + 4);
            uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar8);
            uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar8 + 4);
            *(undefined4 *)param_2 = *(undefined4 *)((int64_t)&var_8h + iVar8);
            *(undefined4 *)((int64_t)param_2 + 4) = uVar3;
            *(undefined4 *)(param_2 + 1) = uVar4;
            *(undefined4 *)((int64_t)param_2 + 0xc) = uVar5;
            if (0x100 < uVar12) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa57;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa6f;
                func_0x0001802295a0(0x1804afc90, 0xb77, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa85;
                func_0x00018019b5e0(param_1, 0x32, 0x92, 0);
                goto code_r0x0001801bab59;
            }
            if (*(int64_t *)(param_1 + 0x970) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa9b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baab3;
                func_0x0001802295a0(0x1804afc90, 0xb7b, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baac9;
                func_0x00018019b5e0(param_1, 0x50, 0xe1, 0);
                goto code_r0x0001801bab59;
            }
            *(undefined8 *)(&stack0x00000258 + iVar8) = unaff_RBX;
            iVar1 = *(int64_t *)(param_1 + 0x8f8);
            uVar11 = *(undefined8 *)(iVar1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baaf8;
            func_0x000180224990(uVar11, 0x1804a9450, 0x1f6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab10;
            iVar9 = func_0x000180223270(puVar6 + 2, uVar12, 0x1804a9450, 0x1f9);
            *(int64_t *)(iVar1 + 0x2a8) = iVar9;
            if (iVar9 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab21;
                func_0x000180229480();
                uVar11 = 0xb80;
code_r0x0001801bab2d:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab39;
                func_0x0001802295a0(0x1804afc90, uVar11, 0x1804afee8);
                uVar13 = 0xc0103;
code_r0x0001801bab3f:
                uVar11 = 0x50;
            } else {
                pcVar2 = *(code **)(param_1 + 0x970);
                uVar11 = *(undefined8 *)(param_1 + 0x40);
                uVar13 = *(undefined8 *)(*(int64_t *)(param_1 + 0x8f8) + 0x2a8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab9a;
                uVar7 = (*pcVar2)(uVar11, uVar13, (int64_t)&var_18h + iVar8, 0x200);
                uVar10 = (uint64_t)uVar7;
                if (0x200 < uVar10) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babaa;
                    func_0x000180229480();
                    uVar11 = 0xb89;
                    goto code_r0x0001801bab2d;
                }
                if (uVar7 != 0) {
                    uVar11 = *(undefined8 *)(param_1 + 0x3c0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac05;
                    func_0x000180224990(uVar11, 0x1804afc90, 0xb93);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac1f;
                    uVar11 = func_0x000180223170((int64_t)&var_18h + iVar8, uVar10, 0x1804afc90, 0xb94);
                    *(undefined8 *)(param_1 + 0x3c0) = uVar11;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac33;
                    func_0x000180244fc0((int64_t)&var_18h + iVar8, uVar10);
                    if (*(int64_t *)(param_1 + 0x3c0) != 0) {
                        *(uint64_t *)(param_1 + 0x3c8) = uVar10;
                        goto code_r0x0001801bab59;
                    }
                    *(undefined8 *)(param_1 + 0x3c8) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac4d;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac65;
                    func_0x0001802295a0(0x1804afc90, 0xb99, 0x1804afee8);
                    uVar13 = 0x8000f;
                    goto code_r0x0001801bab3f;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babc4;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babdc;
                func_0x0001802295a0(0x1804afc90, 0xb8f, 0x1804afee8);
                uVar11 = 0x73;
                uVar13 = 0xdf;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab4f;
            func_0x00018019b5e0(param_1, uVar11, uVar13, 0);
            goto code_r0x0001801bab59;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac86;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac9e;
    func_0x0001802295a0(0x1804afc90, 0xb73, 0x1804afee8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bacb4;
    func_0x00018019b5e0(param_1, 0x32, 0x9f, 0);
code_r0x0001801bab59:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab69;
    func_0x000180459870(*(uint64_t *)(&stack0x00000218 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801baad0
// Address: 0x1801baad0
// Size: 137 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

void fcn.1801ba9d0(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ba9de;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00000218 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    puVar6 = (undefined *)*param_2;
    uVar11 = param_2[1];
    uVar10 = param_2[1];
    *(undefined **)((int64_t)&var_8h + iVar8) = puVar6;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar11;
    if (1 < uVar10) {
        uVar10 = uVar10 - 2;
        uVar12 = (uint64_t)CONCAT11(*puVar6, puVar6[1]);
        if (uVar12 <= uVar10) {
            *(undefined **)((int64_t)&var_8h + iVar8) = puVar6 + 2 + uVar12;
            *(uint64_t *)((int64_t)&var_10h + iVar8) = uVar10 - uVar12;
            uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar8 + 4);
            uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar8);
            uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar8 + 4);
            *(undefined4 *)param_2 = *(undefined4 *)((int64_t)&var_8h + iVar8);
            *(undefined4 *)((int64_t)param_2 + 4) = uVar3;
            *(undefined4 *)(param_2 + 1) = uVar4;
            *(undefined4 *)((int64_t)param_2 + 0xc) = uVar5;
            if (0x100 < uVar12) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa57;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa6f;
                func_0x0001802295a0(0x1804afc90, 0xb77, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa85;
                func_0x00018019b5e0(param_1, 0x32, 0x92, 0);
                goto code_r0x0001801bab59;
            }
            if (*(int64_t *)(param_1 + 0x970) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa9b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baab3;
                func_0x0001802295a0(0x1804afc90, 0xb7b, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baac9;
                func_0x00018019b5e0(param_1, 0x50, 0xe1, 0);
                goto code_r0x0001801bab59;
            }
            *(undefined8 *)(&stack0x00000258 + iVar8) = unaff_RBX;
            iVar1 = *(int64_t *)(param_1 + 0x8f8);
            uVar11 = *(undefined8 *)(iVar1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baaf8;
            func_0x000180224990(uVar11, 0x1804a9450, 0x1f6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab10;
            iVar9 = func_0x000180223270(puVar6 + 2, uVar12, 0x1804a9450, 0x1f9);
            *(int64_t *)(iVar1 + 0x2a8) = iVar9;
            if (iVar9 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab21;
                func_0x000180229480();
                uVar11 = 0xb80;
code_r0x0001801bab2d:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab39;
                func_0x0001802295a0(0x1804afc90, uVar11, 0x1804afee8);
                uVar13 = 0xc0103;
code_r0x0001801bab3f:
                uVar11 = 0x50;
            } else {
                pcVar2 = *(code **)(param_1 + 0x970);
                uVar11 = *(undefined8 *)(param_1 + 0x40);
                uVar13 = *(undefined8 *)(*(int64_t *)(param_1 + 0x8f8) + 0x2a8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab9a;
                uVar7 = (*pcVar2)(uVar11, uVar13, (int64_t)&var_18h + iVar8, 0x200);
                uVar10 = (uint64_t)uVar7;
                if (0x200 < uVar10) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babaa;
                    func_0x000180229480();
                    uVar11 = 0xb89;
                    goto code_r0x0001801bab2d;
                }
                if (uVar7 != 0) {
                    uVar11 = *(undefined8 *)(param_1 + 0x3c0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac05;
                    func_0x000180224990(uVar11, 0x1804afc90, 0xb93);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac1f;
                    uVar11 = func_0x000180223170((int64_t)&var_18h + iVar8, uVar10, 0x1804afc90, 0xb94);
                    *(undefined8 *)(param_1 + 0x3c0) = uVar11;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac33;
                    func_0x000180244fc0((int64_t)&var_18h + iVar8, uVar10);
                    if (*(int64_t *)(param_1 + 0x3c0) != 0) {
                        *(uint64_t *)(param_1 + 0x3c8) = uVar10;
                        goto code_r0x0001801bab59;
                    }
                    *(undefined8 *)(param_1 + 0x3c8) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac4d;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac65;
                    func_0x0001802295a0(0x1804afc90, 0xb99, 0x1804afee8);
                    uVar13 = 0x8000f;
                    goto code_r0x0001801bab3f;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babc4;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babdc;
                func_0x0001802295a0(0x1804afc90, 0xb8f, 0x1804afee8);
                uVar11 = 0x73;
                uVar13 = 0xdf;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab4f;
            func_0x00018019b5e0(param_1, uVar11, uVar13, 0);
            goto code_r0x0001801bab59;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac86;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac9e;
    func_0x0001802295a0(0x1804afc90, 0xb73, 0x1804afee8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bacb4;
    func_0x00018019b5e0(param_1, 0x32, 0x9f, 0);
code_r0x0001801bab59:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab69;
    func_0x000180459870(*(uint64_t *)(&stack0x00000218 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801bab59
// Address: 0x1801bab59
// Size: 27 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

void fcn.1801ba9d0(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ba9de;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00000218 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    puVar6 = (undefined *)*param_2;
    uVar11 = param_2[1];
    uVar10 = param_2[1];
    *(undefined **)((int64_t)&var_8h + iVar8) = puVar6;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar11;
    if (1 < uVar10) {
        uVar10 = uVar10 - 2;
        uVar12 = (uint64_t)CONCAT11(*puVar6, puVar6[1]);
        if (uVar12 <= uVar10) {
            *(undefined **)((int64_t)&var_8h + iVar8) = puVar6 + 2 + uVar12;
            *(uint64_t *)((int64_t)&var_10h + iVar8) = uVar10 - uVar12;
            uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar8 + 4);
            uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar8);
            uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar8 + 4);
            *(undefined4 *)param_2 = *(undefined4 *)((int64_t)&var_8h + iVar8);
            *(undefined4 *)((int64_t)param_2 + 4) = uVar3;
            *(undefined4 *)(param_2 + 1) = uVar4;
            *(undefined4 *)((int64_t)param_2 + 0xc) = uVar5;
            if (0x100 < uVar12) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa57;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa6f;
                func_0x0001802295a0(0x1804afc90, 0xb77, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa85;
                func_0x00018019b5e0(param_1, 0x32, 0x92, 0);
                goto code_r0x0001801bab59;
            }
            if (*(int64_t *)(param_1 + 0x970) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa9b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baab3;
                func_0x0001802295a0(0x1804afc90, 0xb7b, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baac9;
                func_0x00018019b5e0(param_1, 0x50, 0xe1, 0);
                goto code_r0x0001801bab59;
            }
            *(undefined8 *)(&stack0x00000258 + iVar8) = unaff_RBX;
            iVar1 = *(int64_t *)(param_1 + 0x8f8);
            uVar11 = *(undefined8 *)(iVar1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baaf8;
            func_0x000180224990(uVar11, 0x1804a9450, 0x1f6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab10;
            iVar9 = func_0x000180223270(puVar6 + 2, uVar12, 0x1804a9450, 0x1f9);
            *(int64_t *)(iVar1 + 0x2a8) = iVar9;
            if (iVar9 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab21;
                func_0x000180229480();
                uVar11 = 0xb80;
code_r0x0001801bab2d:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab39;
                func_0x0001802295a0(0x1804afc90, uVar11, 0x1804afee8);
                uVar13 = 0xc0103;
code_r0x0001801bab3f:
                uVar11 = 0x50;
            } else {
                pcVar2 = *(code **)(param_1 + 0x970);
                uVar11 = *(undefined8 *)(param_1 + 0x40);
                uVar13 = *(undefined8 *)(*(int64_t *)(param_1 + 0x8f8) + 0x2a8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab9a;
                uVar7 = (*pcVar2)(uVar11, uVar13, (int64_t)&var_18h + iVar8, 0x200);
                uVar10 = (uint64_t)uVar7;
                if (0x200 < uVar10) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babaa;
                    func_0x000180229480();
                    uVar11 = 0xb89;
                    goto code_r0x0001801bab2d;
                }
                if (uVar7 != 0) {
                    uVar11 = *(undefined8 *)(param_1 + 0x3c0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac05;
                    func_0x000180224990(uVar11, 0x1804afc90, 0xb93);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac1f;
                    uVar11 = func_0x000180223170((int64_t)&var_18h + iVar8, uVar10, 0x1804afc90, 0xb94);
                    *(undefined8 *)(param_1 + 0x3c0) = uVar11;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac33;
                    func_0x000180244fc0((int64_t)&var_18h + iVar8, uVar10);
                    if (*(int64_t *)(param_1 + 0x3c0) != 0) {
                        *(uint64_t *)(param_1 + 0x3c8) = uVar10;
                        goto code_r0x0001801bab59;
                    }
                    *(undefined8 *)(param_1 + 0x3c8) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac4d;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac65;
                    func_0x0001802295a0(0x1804afc90, 0xb99, 0x1804afee8);
                    uVar13 = 0x8000f;
                    goto code_r0x0001801bab3f;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babc4;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babdc;
                func_0x0001802295a0(0x1804afc90, 0xb8f, 0x1804afee8);
                uVar11 = 0x73;
                uVar13 = 0xdf;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab4f;
            func_0x00018019b5e0(param_1, uVar11, uVar13, 0);
            goto code_r0x0001801bab59;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac86;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac9e;
    func_0x0001802295a0(0x1804afc90, 0xb73, 0x1804afee8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bacb4;
    func_0x00018019b5e0(param_1, 0x32, 0x9f, 0);
code_r0x0001801bab59:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab69;
    func_0x000180459870(*(uint64_t *)(&stack0x00000218 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801bab74
// Address: 0x1801bab74
// Size: 269 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

void fcn.1801ba9d0(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ba9de;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00000218 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    puVar6 = (undefined *)*param_2;
    uVar11 = param_2[1];
    uVar10 = param_2[1];
    *(undefined **)((int64_t)&var_8h + iVar8) = puVar6;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar11;
    if (1 < uVar10) {
        uVar10 = uVar10 - 2;
        uVar12 = (uint64_t)CONCAT11(*puVar6, puVar6[1]);
        if (uVar12 <= uVar10) {
            *(undefined **)((int64_t)&var_8h + iVar8) = puVar6 + 2 + uVar12;
            *(uint64_t *)((int64_t)&var_10h + iVar8) = uVar10 - uVar12;
            uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar8 + 4);
            uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar8);
            uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar8 + 4);
            *(undefined4 *)param_2 = *(undefined4 *)((int64_t)&var_8h + iVar8);
            *(undefined4 *)((int64_t)param_2 + 4) = uVar3;
            *(undefined4 *)(param_2 + 1) = uVar4;
            *(undefined4 *)((int64_t)param_2 + 0xc) = uVar5;
            if (0x100 < uVar12) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa57;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa6f;
                func_0x0001802295a0(0x1804afc90, 0xb77, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa85;
                func_0x00018019b5e0(param_1, 0x32, 0x92, 0);
                goto code_r0x0001801bab59;
            }
            if (*(int64_t *)(param_1 + 0x970) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa9b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baab3;
                func_0x0001802295a0(0x1804afc90, 0xb7b, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baac9;
                func_0x00018019b5e0(param_1, 0x50, 0xe1, 0);
                goto code_r0x0001801bab59;
            }
            *(undefined8 *)(&stack0x00000258 + iVar8) = unaff_RBX;
            iVar1 = *(int64_t *)(param_1 + 0x8f8);
            uVar11 = *(undefined8 *)(iVar1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baaf8;
            func_0x000180224990(uVar11, 0x1804a9450, 0x1f6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab10;
            iVar9 = func_0x000180223270(puVar6 + 2, uVar12, 0x1804a9450, 0x1f9);
            *(int64_t *)(iVar1 + 0x2a8) = iVar9;
            if (iVar9 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab21;
                func_0x000180229480();
                uVar11 = 0xb80;
code_r0x0001801bab2d:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab39;
                func_0x0001802295a0(0x1804afc90, uVar11, 0x1804afee8);
                uVar13 = 0xc0103;
code_r0x0001801bab3f:
                uVar11 = 0x50;
            } else {
                pcVar2 = *(code **)(param_1 + 0x970);
                uVar11 = *(undefined8 *)(param_1 + 0x40);
                uVar13 = *(undefined8 *)(*(int64_t *)(param_1 + 0x8f8) + 0x2a8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab9a;
                uVar7 = (*pcVar2)(uVar11, uVar13, (int64_t)&var_18h + iVar8, 0x200);
                uVar10 = (uint64_t)uVar7;
                if (0x200 < uVar10) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babaa;
                    func_0x000180229480();
                    uVar11 = 0xb89;
                    goto code_r0x0001801bab2d;
                }
                if (uVar7 != 0) {
                    uVar11 = *(undefined8 *)(param_1 + 0x3c0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac05;
                    func_0x000180224990(uVar11, 0x1804afc90, 0xb93);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac1f;
                    uVar11 = func_0x000180223170((int64_t)&var_18h + iVar8, uVar10, 0x1804afc90, 0xb94);
                    *(undefined8 *)(param_1 + 0x3c0) = uVar11;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac33;
                    func_0x000180244fc0((int64_t)&var_18h + iVar8, uVar10);
                    if (*(int64_t *)(param_1 + 0x3c0) != 0) {
                        *(uint64_t *)(param_1 + 0x3c8) = uVar10;
                        goto code_r0x0001801bab59;
                    }
                    *(undefined8 *)(param_1 + 0x3c8) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac4d;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac65;
                    func_0x0001802295a0(0x1804afc90, 0xb99, 0x1804afee8);
                    uVar13 = 0x8000f;
                    goto code_r0x0001801bab3f;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babc4;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babdc;
                func_0x0001802295a0(0x1804afc90, 0xb8f, 0x1804afee8);
                uVar11 = 0x73;
                uVar13 = 0xdf;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab4f;
            func_0x00018019b5e0(param_1, uVar11, uVar13, 0);
            goto code_r0x0001801bab59;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac86;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac9e;
    func_0x0001802295a0(0x1804afc90, 0xb73, 0x1804afee8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bacb4;
    func_0x00018019b5e0(param_1, 0x32, 0x9f, 0);
code_r0x0001801bab59:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab69;
    func_0x000180459870(*(uint64_t *)(&stack0x00000218 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801bac81
// Address: 0x1801bac81
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

void fcn.1801ba9d0(int64_t param_1, undefined8 *param_2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ba9de;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00000218 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8);
    puVar6 = (undefined *)*param_2;
    uVar11 = param_2[1];
    uVar10 = param_2[1];
    *(undefined **)((int64_t)&var_8h + iVar8) = puVar6;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar11;
    if (1 < uVar10) {
        uVar10 = uVar10 - 2;
        uVar12 = (uint64_t)CONCAT11(*puVar6, puVar6[1]);
        if (uVar12 <= uVar10) {
            *(undefined **)((int64_t)&var_8h + iVar8) = puVar6 + 2 + uVar12;
            *(uint64_t *)((int64_t)&var_10h + iVar8) = uVar10 - uVar12;
            uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar8 + 4);
            uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar8);
            uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar8 + 4);
            *(undefined4 *)param_2 = *(undefined4 *)((int64_t)&var_8h + iVar8);
            *(undefined4 *)((int64_t)param_2 + 4) = uVar3;
            *(undefined4 *)(param_2 + 1) = uVar4;
            *(undefined4 *)((int64_t)param_2 + 0xc) = uVar5;
            if (0x100 < uVar12) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa57;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa6f;
                func_0x0001802295a0(0x1804afc90, 0xb77, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa85;
                func_0x00018019b5e0(param_1, 0x32, 0x92, 0);
                goto code_r0x0001801bab59;
            }
            if (*(int64_t *)(param_1 + 0x970) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baa9b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baab3;
                func_0x0001802295a0(0x1804afc90, 0xb7b, 0x1804afee8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baac9;
                func_0x00018019b5e0(param_1, 0x50, 0xe1, 0);
                goto code_r0x0001801bab59;
            }
            *(undefined8 *)(&stack0x00000258 + iVar8) = unaff_RBX;
            iVar1 = *(int64_t *)(param_1 + 0x8f8);
            uVar11 = *(undefined8 *)(iVar1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801baaf8;
            func_0x000180224990(uVar11, 0x1804a9450, 0x1f6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab10;
            iVar9 = func_0x000180223270(puVar6 + 2, uVar12, 0x1804a9450, 0x1f9);
            *(int64_t *)(iVar1 + 0x2a8) = iVar9;
            if (iVar9 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab21;
                func_0x000180229480();
                uVar11 = 0xb80;
code_r0x0001801bab2d:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab39;
                func_0x0001802295a0(0x1804afc90, uVar11, 0x1804afee8);
                uVar13 = 0xc0103;
code_r0x0001801bab3f:
                uVar11 = 0x50;
            } else {
                pcVar2 = *(code **)(param_1 + 0x970);
                uVar11 = *(undefined8 *)(param_1 + 0x40);
                uVar13 = *(undefined8 *)(*(int64_t *)(param_1 + 0x8f8) + 0x2a8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab9a;
                uVar7 = (*pcVar2)(uVar11, uVar13, (int64_t)&var_18h + iVar8, 0x200);
                uVar10 = (uint64_t)uVar7;
                if (0x200 < uVar10) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babaa;
                    func_0x000180229480();
                    uVar11 = 0xb89;
                    goto code_r0x0001801bab2d;
                }
                if (uVar7 != 0) {
                    uVar11 = *(undefined8 *)(param_1 + 0x3c0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac05;
                    func_0x000180224990(uVar11, 0x1804afc90, 0xb93);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac1f;
                    uVar11 = func_0x000180223170((int64_t)&var_18h + iVar8, uVar10, 0x1804afc90, 0xb94);
                    *(undefined8 *)(param_1 + 0x3c0) = uVar11;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac33;
                    func_0x000180244fc0((int64_t)&var_18h + iVar8, uVar10);
                    if (*(int64_t *)(param_1 + 0x3c0) != 0) {
                        *(uint64_t *)(param_1 + 0x3c8) = uVar10;
                        goto code_r0x0001801bab59;
                    }
                    *(undefined8 *)(param_1 + 0x3c8) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac4d;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac65;
                    func_0x0001802295a0(0x1804afc90, 0xb99, 0x1804afee8);
                    uVar13 = 0x8000f;
                    goto code_r0x0001801bab3f;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babc4;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801babdc;
                func_0x0001802295a0(0x1804afc90, 0xb8f, 0x1804afee8);
                uVar11 = 0x73;
                uVar13 = 0xdf;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab4f;
            func_0x00018019b5e0(param_1, uVar11, uVar13, 0);
            goto code_r0x0001801bab59;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac86;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bac9e;
    func_0x0001802295a0(0x1804afc90, 0xb73, 0x1804afee8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bacb4;
    func_0x00018019b5e0(param_1, 0x32, 0x9f, 0);
code_r0x0001801bab59:
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bab69;
    func_0x000180459870(*(uint64_t *)(&stack0x00000218 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801bacc0
// Address: 0x1801bacc0
// Size: 129 bytes
// ============================================================
void fcn.1801bacc0(int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_98h,
                  int64_t arg_a0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_130h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t in_RCX;
    uint64_t uVar13;
    int64_t *in_RDX;
    undefined8 uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 unaff_R12;
    undefined4 *puVar17;
    undefined8 unaff_R15;
    undefined *puVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bacd1;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_d0h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar11 = *(int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + 8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad09;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad21;
        func_0x0001802295a0(0x1804afc90, 0xbb4, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad37;
        func_0x00018019b5e0(in_RCX, 0x50, 0xa8, 0);
        goto code_r0x0001801bb07a;
    }
    iVar8 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar9) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_e0h + iVar9) = unaff_R15;
    if ((iVar8 != 0x300) && (iVar8 != 0x100)) {
        puVar7 = (undefined *)*in_RDX;
        iVar10 = in_RDX[1];
        uVar13 = in_RDX[1];
        *(undefined **)((int64_t)&var_10h + iVar9) = puVar7;
        *(int64_t *)((int64_t)&var_18h + iVar9) = iVar10;
        if (1 < uVar13) {
            uVar13 = uVar13 - 2;
            puVar18 = puVar7 + 2;
            uVar15 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
            if (uVar15 <= uVar13) {
                *(undefined **)((int64_t)&var_10h + iVar9) = puVar18 + uVar15;
                *(uint64_t *)((int64_t)&var_18h + iVar9) = uVar13 - uVar15;
                uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_10h + iVar9);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if (in_RDX[1] == 0) goto code_r0x0001801bae01;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badc5;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baddd;
        func_0x0001802295a0(0x1804afc90, 0xbbe, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badf3;
        func_0x00018019b5e0(in_RCX, 0x32, 0x9f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar15 = in_RDX[1];
    puVar18 = (undefined *)*in_RDX;
code_r0x0001801bae01:
    *(undefined8 *)((int64_t)&arg_130h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0x30;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae29;
    iVar10 = func_0x0001802248d0(0x30, 0x1804afc90, 0xbc4);
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae36;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae4e;
        func_0x0001802295a0(0x1804afc90, 0xbc6, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae64;
        func_0x00018019b5e0(in_RCX, 0x50, 0x8000f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar14 = puVar2[0x8c];
    uVar16 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae7d;
    iVar11 = func_0x000180259210(uVar16, iVar11, uVar14);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae8a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baea2;
        func_0x0001802295a0(0x1804afc90, 0xbcc, 0x1804aff08);
        uVar14 = 0x50;
        uVar16 = 0x80006;
code_r0x0001801bb02f:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb03a;
        func_0x00018019b5e0(in_RCX, uVar14, uVar16, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeba;
        iVar8 = func_0x000180265050(iVar11);
        if (iVar8 < 1) {
code_r0x0001801bb007:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb00c;
            func_0x000180229480();
            uVar14 = 0xbdd;
code_r0x0001801bb011:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb024;
            func_0x0001802295a0(0x1804afc90, uVar14, 0x1804aff08);
            uVar14 = 0x33;
            uVar16 = 0x93;
            goto code_r0x0001801bb02f;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baecf;
        iVar8 = func_0x00018025dd20(iVar11, 7);
        if (iVar8 < 1) goto code_r0x0001801bb007;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeef;
        puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff20, in_RCX + 0x9cc);
        piVar3 = &arg_78h;
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = *puVar12;
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000058 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000005c + iVar9) = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_60h + iVar9) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_60h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000068 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000006c + iVar9) = uVar6;
        uVar1 = *(uint32_t *)(in_RCX + 0x9a8);
        *(undefined8 *)((int64_t)&arg_70h + iVar9) = *(undefined8 *)(puVar12 + 8);
        if ((uVar1 >> 0x17 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf3b;
            puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff38, in_RCX + 0x48);
            piVar3 = &arg_a0h;
            uVar4 = puVar12[1];
            uVar5 = puVar12[2];
            uVar6 = puVar12[3];
            *(undefined4 *)((int64_t)&arg_78h + iVar9) = *puVar12;
            *(undefined4 *)((int64_t)&arg_78h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000080 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000084 + iVar9) = uVar6;
            uVar4 = puVar12[5];
            uVar5 = puVar12[6];
            uVar6 = puVar12[7];
            *(undefined4 *)((int64_t)&arg_88h + iVar9) = puVar12[4];
            *(undefined4 *)((int64_t)&arg_88h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000090 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000094 + iVar9) = uVar6;
            *(undefined8 *)((int64_t)&arg_98h + iVar9) = *(undefined8 *)(puVar12 + 8);
        }
        puVar17 = (undefined4 *)((int64_t)piVar3 + iVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf72;
        puVar12 = (undefined4 *)func_0x000180229ba0((int64_t)&var_20h + iVar9);
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *puVar17 = *puVar12;
        puVar17[1] = uVar4;
        puVar17[2] = uVar5;
        puVar17[3] = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        puVar17[4] = puVar12[4];
        puVar17[5] = uVar4;
        puVar17[6] = uVar5;
        puVar17[7] = uVar6;
        *(undefined8 *)(puVar17 + 8) = *(undefined8 *)(puVar12 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf9a;
        iVar8 = func_0x0001802592f0(iVar11, (int64_t)&arg_50h + iVar9);
        if (iVar8 == 0) {
code_r0x0001801baffb:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb000;
            func_0x000180229480();
            uVar14 = 0xbed;
            goto code_r0x0001801bb011;
        }
        *(uint64_t *)(&stack0x00000000 + iVar9) = uVar15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafb6;
        iVar8 = func_0x000180264d90(iVar11, iVar10, (int64_t)&var_10h + iVar9, puVar18);
        if (iVar8 < 1) goto code_r0x0001801baffb;
        if (*(int64_t *)((int64_t)&var_10h + iVar9) != 0x30) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafcf;
            func_0x000180244fc0(iVar10, 0x30);
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafd4;
            func_0x000180229480();
            uVar14 = 0xbf7;
            goto code_r0x0001801bb011;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafef;
        func_0x0001801c6380(in_RCX, iVar10, 0x30, 0);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb04f;
    func_0x000180224990(iVar10, 0x1804afc90, 0xc03);
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb057;
    func_0x000180258be0(iVar11);
code_r0x0001801bb07a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb08a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_d0h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801bad41
// Address: 0x1801bad41
// Size: 198 bytes
// ============================================================
void fcn.1801bacc0(int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_98h,
                  int64_t arg_a0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_130h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t in_RCX;
    uint64_t uVar13;
    int64_t *in_RDX;
    undefined8 uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 unaff_R12;
    undefined4 *puVar17;
    undefined8 unaff_R15;
    undefined *puVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bacd1;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_d0h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar11 = *(int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + 8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad09;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad21;
        func_0x0001802295a0(0x1804afc90, 0xbb4, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad37;
        func_0x00018019b5e0(in_RCX, 0x50, 0xa8, 0);
        goto code_r0x0001801bb07a;
    }
    iVar8 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar9) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_e0h + iVar9) = unaff_R15;
    if ((iVar8 != 0x300) && (iVar8 != 0x100)) {
        puVar7 = (undefined *)*in_RDX;
        iVar10 = in_RDX[1];
        uVar13 = in_RDX[1];
        *(undefined **)((int64_t)&var_10h + iVar9) = puVar7;
        *(int64_t *)((int64_t)&var_18h + iVar9) = iVar10;
        if (1 < uVar13) {
            uVar13 = uVar13 - 2;
            puVar18 = puVar7 + 2;
            uVar15 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
            if (uVar15 <= uVar13) {
                *(undefined **)((int64_t)&var_10h + iVar9) = puVar18 + uVar15;
                *(uint64_t *)((int64_t)&var_18h + iVar9) = uVar13 - uVar15;
                uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_10h + iVar9);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if (in_RDX[1] == 0) goto code_r0x0001801bae01;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badc5;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baddd;
        func_0x0001802295a0(0x1804afc90, 0xbbe, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badf3;
        func_0x00018019b5e0(in_RCX, 0x32, 0x9f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar15 = in_RDX[1];
    puVar18 = (undefined *)*in_RDX;
code_r0x0001801bae01:
    *(undefined8 *)((int64_t)&arg_130h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0x30;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae29;
    iVar10 = func_0x0001802248d0(0x30, 0x1804afc90, 0xbc4);
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae36;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae4e;
        func_0x0001802295a0(0x1804afc90, 0xbc6, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae64;
        func_0x00018019b5e0(in_RCX, 0x50, 0x8000f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar14 = puVar2[0x8c];
    uVar16 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae7d;
    iVar11 = func_0x000180259210(uVar16, iVar11, uVar14);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae8a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baea2;
        func_0x0001802295a0(0x1804afc90, 0xbcc, 0x1804aff08);
        uVar14 = 0x50;
        uVar16 = 0x80006;
code_r0x0001801bb02f:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb03a;
        func_0x00018019b5e0(in_RCX, uVar14, uVar16, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeba;
        iVar8 = func_0x000180265050(iVar11);
        if (iVar8 < 1) {
code_r0x0001801bb007:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb00c;
            func_0x000180229480();
            uVar14 = 0xbdd;
code_r0x0001801bb011:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb024;
            func_0x0001802295a0(0x1804afc90, uVar14, 0x1804aff08);
            uVar14 = 0x33;
            uVar16 = 0x93;
            goto code_r0x0001801bb02f;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baecf;
        iVar8 = func_0x00018025dd20(iVar11, 7);
        if (iVar8 < 1) goto code_r0x0001801bb007;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeef;
        puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff20, in_RCX + 0x9cc);
        piVar3 = &arg_78h;
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = *puVar12;
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000058 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000005c + iVar9) = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_60h + iVar9) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_60h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000068 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000006c + iVar9) = uVar6;
        uVar1 = *(uint32_t *)(in_RCX + 0x9a8);
        *(undefined8 *)((int64_t)&arg_70h + iVar9) = *(undefined8 *)(puVar12 + 8);
        if ((uVar1 >> 0x17 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf3b;
            puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff38, in_RCX + 0x48);
            piVar3 = &arg_a0h;
            uVar4 = puVar12[1];
            uVar5 = puVar12[2];
            uVar6 = puVar12[3];
            *(undefined4 *)((int64_t)&arg_78h + iVar9) = *puVar12;
            *(undefined4 *)((int64_t)&arg_78h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000080 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000084 + iVar9) = uVar6;
            uVar4 = puVar12[5];
            uVar5 = puVar12[6];
            uVar6 = puVar12[7];
            *(undefined4 *)((int64_t)&arg_88h + iVar9) = puVar12[4];
            *(undefined4 *)((int64_t)&arg_88h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000090 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000094 + iVar9) = uVar6;
            *(undefined8 *)((int64_t)&arg_98h + iVar9) = *(undefined8 *)(puVar12 + 8);
        }
        puVar17 = (undefined4 *)((int64_t)piVar3 + iVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf72;
        puVar12 = (undefined4 *)func_0x000180229ba0((int64_t)&var_20h + iVar9);
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *puVar17 = *puVar12;
        puVar17[1] = uVar4;
        puVar17[2] = uVar5;
        puVar17[3] = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        puVar17[4] = puVar12[4];
        puVar17[5] = uVar4;
        puVar17[6] = uVar5;
        puVar17[7] = uVar6;
        *(undefined8 *)(puVar17 + 8) = *(undefined8 *)(puVar12 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf9a;
        iVar8 = func_0x0001802592f0(iVar11, (int64_t)&arg_50h + iVar9);
        if (iVar8 == 0) {
code_r0x0001801baffb:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb000;
            func_0x000180229480();
            uVar14 = 0xbed;
            goto code_r0x0001801bb011;
        }
        *(uint64_t *)(&stack0x00000000 + iVar9) = uVar15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafb6;
        iVar8 = func_0x000180264d90(iVar11, iVar10, (int64_t)&var_10h + iVar9, puVar18);
        if (iVar8 < 1) goto code_r0x0001801baffb;
        if (*(int64_t *)((int64_t)&var_10h + iVar9) != 0x30) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafcf;
            func_0x000180244fc0(iVar10, 0x30);
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafd4;
            func_0x000180229480();
            uVar14 = 0xbf7;
            goto code_r0x0001801bb011;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafef;
        func_0x0001801c6380(in_RCX, iVar10, 0x30, 0);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb04f;
    func_0x000180224990(iVar10, 0x1804afc90, 0xc03);
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb057;
    func_0x000180258be0(iVar11);
code_r0x0001801bb07a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb08a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_d0h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801bae07
// Address: 0x1801bae07
// Size: 603 bytes
// ============================================================
void fcn.1801bacc0(int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_98h,
                  int64_t arg_a0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_130h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t in_RCX;
    uint64_t uVar13;
    int64_t *in_RDX;
    undefined8 uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 unaff_R12;
    undefined4 *puVar17;
    undefined8 unaff_R15;
    undefined *puVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bacd1;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_d0h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar11 = *(int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + 8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad09;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad21;
        func_0x0001802295a0(0x1804afc90, 0xbb4, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad37;
        func_0x00018019b5e0(in_RCX, 0x50, 0xa8, 0);
        goto code_r0x0001801bb07a;
    }
    iVar8 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar9) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_e0h + iVar9) = unaff_R15;
    if ((iVar8 != 0x300) && (iVar8 != 0x100)) {
        puVar7 = (undefined *)*in_RDX;
        iVar10 = in_RDX[1];
        uVar13 = in_RDX[1];
        *(undefined **)((int64_t)&var_10h + iVar9) = puVar7;
        *(int64_t *)((int64_t)&var_18h + iVar9) = iVar10;
        if (1 < uVar13) {
            uVar13 = uVar13 - 2;
            puVar18 = puVar7 + 2;
            uVar15 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
            if (uVar15 <= uVar13) {
                *(undefined **)((int64_t)&var_10h + iVar9) = puVar18 + uVar15;
                *(uint64_t *)((int64_t)&var_18h + iVar9) = uVar13 - uVar15;
                uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_10h + iVar9);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if (in_RDX[1] == 0) goto code_r0x0001801bae01;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badc5;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baddd;
        func_0x0001802295a0(0x1804afc90, 0xbbe, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badf3;
        func_0x00018019b5e0(in_RCX, 0x32, 0x9f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar15 = in_RDX[1];
    puVar18 = (undefined *)*in_RDX;
code_r0x0001801bae01:
    *(undefined8 *)((int64_t)&arg_130h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0x30;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae29;
    iVar10 = func_0x0001802248d0(0x30, 0x1804afc90, 0xbc4);
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae36;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae4e;
        func_0x0001802295a0(0x1804afc90, 0xbc6, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae64;
        func_0x00018019b5e0(in_RCX, 0x50, 0x8000f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar14 = puVar2[0x8c];
    uVar16 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae7d;
    iVar11 = func_0x000180259210(uVar16, iVar11, uVar14);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae8a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baea2;
        func_0x0001802295a0(0x1804afc90, 0xbcc, 0x1804aff08);
        uVar14 = 0x50;
        uVar16 = 0x80006;
code_r0x0001801bb02f:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb03a;
        func_0x00018019b5e0(in_RCX, uVar14, uVar16, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeba;
        iVar8 = func_0x000180265050(iVar11);
        if (iVar8 < 1) {
code_r0x0001801bb007:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb00c;
            func_0x000180229480();
            uVar14 = 0xbdd;
code_r0x0001801bb011:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb024;
            func_0x0001802295a0(0x1804afc90, uVar14, 0x1804aff08);
            uVar14 = 0x33;
            uVar16 = 0x93;
            goto code_r0x0001801bb02f;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baecf;
        iVar8 = func_0x00018025dd20(iVar11, 7);
        if (iVar8 < 1) goto code_r0x0001801bb007;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeef;
        puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff20, in_RCX + 0x9cc);
        piVar3 = &arg_78h;
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = *puVar12;
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000058 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000005c + iVar9) = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_60h + iVar9) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_60h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000068 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000006c + iVar9) = uVar6;
        uVar1 = *(uint32_t *)(in_RCX + 0x9a8);
        *(undefined8 *)((int64_t)&arg_70h + iVar9) = *(undefined8 *)(puVar12 + 8);
        if ((uVar1 >> 0x17 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf3b;
            puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff38, in_RCX + 0x48);
            piVar3 = &arg_a0h;
            uVar4 = puVar12[1];
            uVar5 = puVar12[2];
            uVar6 = puVar12[3];
            *(undefined4 *)((int64_t)&arg_78h + iVar9) = *puVar12;
            *(undefined4 *)((int64_t)&arg_78h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000080 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000084 + iVar9) = uVar6;
            uVar4 = puVar12[5];
            uVar5 = puVar12[6];
            uVar6 = puVar12[7];
            *(undefined4 *)((int64_t)&arg_88h + iVar9) = puVar12[4];
            *(undefined4 *)((int64_t)&arg_88h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000090 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000094 + iVar9) = uVar6;
            *(undefined8 *)((int64_t)&arg_98h + iVar9) = *(undefined8 *)(puVar12 + 8);
        }
        puVar17 = (undefined4 *)((int64_t)piVar3 + iVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf72;
        puVar12 = (undefined4 *)func_0x000180229ba0((int64_t)&var_20h + iVar9);
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *puVar17 = *puVar12;
        puVar17[1] = uVar4;
        puVar17[2] = uVar5;
        puVar17[3] = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        puVar17[4] = puVar12[4];
        puVar17[5] = uVar4;
        puVar17[6] = uVar5;
        puVar17[7] = uVar6;
        *(undefined8 *)(puVar17 + 8) = *(undefined8 *)(puVar12 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf9a;
        iVar8 = func_0x0001802592f0(iVar11, (int64_t)&arg_50h + iVar9);
        if (iVar8 == 0) {
code_r0x0001801baffb:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb000;
            func_0x000180229480();
            uVar14 = 0xbed;
            goto code_r0x0001801bb011;
        }
        *(uint64_t *)(&stack0x00000000 + iVar9) = uVar15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafb6;
        iVar8 = func_0x000180264d90(iVar11, iVar10, (int64_t)&var_10h + iVar9, puVar18);
        if (iVar8 < 1) goto code_r0x0001801baffb;
        if (*(int64_t *)((int64_t)&var_10h + iVar9) != 0x30) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafcf;
            func_0x000180244fc0(iVar10, 0x30);
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafd4;
            func_0x000180229480();
            uVar14 = 0xbf7;
            goto code_r0x0001801bb011;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafef;
        func_0x0001801c6380(in_RCX, iVar10, 0x30, 0);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb04f;
    func_0x000180224990(iVar10, 0x1804afc90, 0xc03);
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb057;
    func_0x000180258be0(iVar11);
code_r0x0001801bb07a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb08a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_d0h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801bb062
// Address: 0x1801bb062
// Size: 24 bytes
// ============================================================
void fcn.1801bacc0(int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_98h,
                  int64_t arg_a0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_130h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t in_RCX;
    uint64_t uVar13;
    int64_t *in_RDX;
    undefined8 uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 unaff_R12;
    undefined4 *puVar17;
    undefined8 unaff_R15;
    undefined *puVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bacd1;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_d0h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar11 = *(int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + 8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad09;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad21;
        func_0x0001802295a0(0x1804afc90, 0xbb4, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad37;
        func_0x00018019b5e0(in_RCX, 0x50, 0xa8, 0);
        goto code_r0x0001801bb07a;
    }
    iVar8 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar9) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_e0h + iVar9) = unaff_R15;
    if ((iVar8 != 0x300) && (iVar8 != 0x100)) {
        puVar7 = (undefined *)*in_RDX;
        iVar10 = in_RDX[1];
        uVar13 = in_RDX[1];
        *(undefined **)((int64_t)&var_10h + iVar9) = puVar7;
        *(int64_t *)((int64_t)&var_18h + iVar9) = iVar10;
        if (1 < uVar13) {
            uVar13 = uVar13 - 2;
            puVar18 = puVar7 + 2;
            uVar15 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
            if (uVar15 <= uVar13) {
                *(undefined **)((int64_t)&var_10h + iVar9) = puVar18 + uVar15;
                *(uint64_t *)((int64_t)&var_18h + iVar9) = uVar13 - uVar15;
                uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_10h + iVar9);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if (in_RDX[1] == 0) goto code_r0x0001801bae01;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badc5;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baddd;
        func_0x0001802295a0(0x1804afc90, 0xbbe, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badf3;
        func_0x00018019b5e0(in_RCX, 0x32, 0x9f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar15 = in_RDX[1];
    puVar18 = (undefined *)*in_RDX;
code_r0x0001801bae01:
    *(undefined8 *)((int64_t)&arg_130h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0x30;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae29;
    iVar10 = func_0x0001802248d0(0x30, 0x1804afc90, 0xbc4);
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae36;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae4e;
        func_0x0001802295a0(0x1804afc90, 0xbc6, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae64;
        func_0x00018019b5e0(in_RCX, 0x50, 0x8000f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar14 = puVar2[0x8c];
    uVar16 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae7d;
    iVar11 = func_0x000180259210(uVar16, iVar11, uVar14);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae8a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baea2;
        func_0x0001802295a0(0x1804afc90, 0xbcc, 0x1804aff08);
        uVar14 = 0x50;
        uVar16 = 0x80006;
code_r0x0001801bb02f:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb03a;
        func_0x00018019b5e0(in_RCX, uVar14, uVar16, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeba;
        iVar8 = func_0x000180265050(iVar11);
        if (iVar8 < 1) {
code_r0x0001801bb007:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb00c;
            func_0x000180229480();
            uVar14 = 0xbdd;
code_r0x0001801bb011:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb024;
            func_0x0001802295a0(0x1804afc90, uVar14, 0x1804aff08);
            uVar14 = 0x33;
            uVar16 = 0x93;
            goto code_r0x0001801bb02f;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baecf;
        iVar8 = func_0x00018025dd20(iVar11, 7);
        if (iVar8 < 1) goto code_r0x0001801bb007;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeef;
        puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff20, in_RCX + 0x9cc);
        piVar3 = &arg_78h;
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = *puVar12;
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000058 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000005c + iVar9) = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_60h + iVar9) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_60h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000068 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000006c + iVar9) = uVar6;
        uVar1 = *(uint32_t *)(in_RCX + 0x9a8);
        *(undefined8 *)((int64_t)&arg_70h + iVar9) = *(undefined8 *)(puVar12 + 8);
        if ((uVar1 >> 0x17 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf3b;
            puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff38, in_RCX + 0x48);
            piVar3 = &arg_a0h;
            uVar4 = puVar12[1];
            uVar5 = puVar12[2];
            uVar6 = puVar12[3];
            *(undefined4 *)((int64_t)&arg_78h + iVar9) = *puVar12;
            *(undefined4 *)((int64_t)&arg_78h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000080 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000084 + iVar9) = uVar6;
            uVar4 = puVar12[5];
            uVar5 = puVar12[6];
            uVar6 = puVar12[7];
            *(undefined4 *)((int64_t)&arg_88h + iVar9) = puVar12[4];
            *(undefined4 *)((int64_t)&arg_88h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000090 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000094 + iVar9) = uVar6;
            *(undefined8 *)((int64_t)&arg_98h + iVar9) = *(undefined8 *)(puVar12 + 8);
        }
        puVar17 = (undefined4 *)((int64_t)piVar3 + iVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf72;
        puVar12 = (undefined4 *)func_0x000180229ba0((int64_t)&var_20h + iVar9);
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *puVar17 = *puVar12;
        puVar17[1] = uVar4;
        puVar17[2] = uVar5;
        puVar17[3] = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        puVar17[4] = puVar12[4];
        puVar17[5] = uVar4;
        puVar17[6] = uVar5;
        puVar17[7] = uVar6;
        *(undefined8 *)(puVar17 + 8) = *(undefined8 *)(puVar12 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf9a;
        iVar8 = func_0x0001802592f0(iVar11, (int64_t)&arg_50h + iVar9);
        if (iVar8 == 0) {
code_r0x0001801baffb:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb000;
            func_0x000180229480();
            uVar14 = 0xbed;
            goto code_r0x0001801bb011;
        }
        *(uint64_t *)(&stack0x00000000 + iVar9) = uVar15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafb6;
        iVar8 = func_0x000180264d90(iVar11, iVar10, (int64_t)&var_10h + iVar9, puVar18);
        if (iVar8 < 1) goto code_r0x0001801baffb;
        if (*(int64_t *)((int64_t)&var_10h + iVar9) != 0x30) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafcf;
            func_0x000180244fc0(iVar10, 0x30);
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafd4;
            func_0x000180229480();
            uVar14 = 0xbf7;
            goto code_r0x0001801bb011;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafef;
        func_0x0001801c6380(in_RCX, iVar10, 0x30, 0);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb04f;
    func_0x000180224990(iVar10, 0x1804afc90, 0xc03);
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb057;
    func_0x000180258be0(iVar11);
code_r0x0001801bb07a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb08a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_d0h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801bb07a
// Address: 0x1801bb07a
// Size: 30 bytes
// ============================================================
void fcn.1801bacc0(int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_98h,
                  int64_t arg_a0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_130h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t in_RCX;
    uint64_t uVar13;
    int64_t *in_RDX;
    undefined8 uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 unaff_R12;
    undefined4 *puVar17;
    undefined8 unaff_R15;
    undefined *puVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bacd1;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_d0h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar11 = *(int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + 8);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad09;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad21;
        func_0x0001802295a0(0x1804afc90, 0xbb4, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bad37;
        func_0x00018019b5e0(in_RCX, 0x50, 0xa8, 0);
        goto code_r0x0001801bb07a;
    }
    iVar8 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&arg_f0h + iVar9) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar9) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_e0h + iVar9) = unaff_R15;
    if ((iVar8 != 0x300) && (iVar8 != 0x100)) {
        puVar7 = (undefined *)*in_RDX;
        iVar10 = in_RDX[1];
        uVar13 = in_RDX[1];
        *(undefined **)((int64_t)&var_10h + iVar9) = puVar7;
        *(int64_t *)((int64_t)&var_18h + iVar9) = iVar10;
        if (1 < uVar13) {
            uVar13 = uVar13 - 2;
            puVar18 = puVar7 + 2;
            uVar15 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
            if (uVar15 <= uVar13) {
                *(undefined **)((int64_t)&var_10h + iVar9) = puVar18 + uVar15;
                *(uint64_t *)((int64_t)&var_18h + iVar9) = uVar13 - uVar15;
                uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_10h + iVar9);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                if (in_RDX[1] == 0) goto code_r0x0001801bae01;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badc5;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baddd;
        func_0x0001802295a0(0x1804afc90, 0xbbe, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801badf3;
        func_0x00018019b5e0(in_RCX, 0x32, 0x9f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar15 = in_RDX[1];
    puVar18 = (undefined *)*in_RDX;
code_r0x0001801bae01:
    *(undefined8 *)((int64_t)&arg_130h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0x30;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae29;
    iVar10 = func_0x0001802248d0(0x30, 0x1804afc90, 0xbc4);
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae36;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae4e;
        func_0x0001802295a0(0x1804afc90, 0xbc6, 0x1804aff08);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae64;
        func_0x00018019b5e0(in_RCX, 0x50, 0x8000f, 0);
        goto code_r0x0001801bb07a;
    }
    uVar14 = puVar2[0x8c];
    uVar16 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae7d;
    iVar11 = func_0x000180259210(uVar16, iVar11, uVar14);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bae8a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baea2;
        func_0x0001802295a0(0x1804afc90, 0xbcc, 0x1804aff08);
        uVar14 = 0x50;
        uVar16 = 0x80006;
code_r0x0001801bb02f:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb03a;
        func_0x00018019b5e0(in_RCX, uVar14, uVar16, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeba;
        iVar8 = func_0x000180265050(iVar11);
        if (iVar8 < 1) {
code_r0x0001801bb007:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb00c;
            func_0x000180229480();
            uVar14 = 0xbdd;
code_r0x0001801bb011:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb024;
            func_0x0001802295a0(0x1804afc90, uVar14, 0x1804aff08);
            uVar14 = 0x33;
            uVar16 = 0x93;
            goto code_r0x0001801bb02f;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baecf;
        iVar8 = func_0x00018025dd20(iVar11, 7);
        if (iVar8 < 1) goto code_r0x0001801bb007;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baeef;
        puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff20, in_RCX + 0x9cc);
        piVar3 = &arg_78h;
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = *puVar12;
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000058 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000005c + iVar9) = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_60h + iVar9) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_60h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000068 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000006c + iVar9) = uVar6;
        uVar1 = *(uint32_t *)(in_RCX + 0x9a8);
        *(undefined8 *)((int64_t)&arg_70h + iVar9) = *(undefined8 *)(puVar12 + 8);
        if ((uVar1 >> 0x17 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf3b;
            puVar12 = (undefined4 *)func_0x000180229d80((int64_t)&var_20h + iVar9, 0x1804aff38, in_RCX + 0x48);
            piVar3 = &arg_a0h;
            uVar4 = puVar12[1];
            uVar5 = puVar12[2];
            uVar6 = puVar12[3];
            *(undefined4 *)((int64_t)&arg_78h + iVar9) = *puVar12;
            *(undefined4 *)((int64_t)&arg_78h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000080 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000084 + iVar9) = uVar6;
            uVar4 = puVar12[5];
            uVar5 = puVar12[6];
            uVar6 = puVar12[7];
            *(undefined4 *)((int64_t)&arg_88h + iVar9) = puVar12[4];
            *(undefined4 *)((int64_t)&arg_88h + iVar9 + 4) = uVar4;
            *(undefined4 *)(&stack0x00000090 + iVar9) = uVar5;
            *(undefined4 *)(&stack0x00000094 + iVar9) = uVar6;
            *(undefined8 *)((int64_t)&arg_98h + iVar9) = *(undefined8 *)(puVar12 + 8);
        }
        puVar17 = (undefined4 *)((int64_t)piVar3 + iVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf72;
        puVar12 = (undefined4 *)func_0x000180229ba0((int64_t)&var_20h + iVar9);
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        *puVar17 = *puVar12;
        puVar17[1] = uVar4;
        puVar17[2] = uVar5;
        puVar17[3] = uVar6;
        uVar4 = puVar12[5];
        uVar5 = puVar12[6];
        uVar6 = puVar12[7];
        puVar17[4] = puVar12[4];
        puVar17[5] = uVar4;
        puVar17[6] = uVar5;
        puVar17[7] = uVar6;
        *(undefined8 *)(puVar17 + 8) = *(undefined8 *)(puVar12 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801baf9a;
        iVar8 = func_0x0001802592f0(iVar11, (int64_t)&arg_50h + iVar9);
        if (iVar8 == 0) {
code_r0x0001801baffb:
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb000;
            func_0x000180229480();
            uVar14 = 0xbed;
            goto code_r0x0001801bb011;
        }
        *(uint64_t *)(&stack0x00000000 + iVar9) = uVar15;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafb6;
        iVar8 = func_0x000180264d90(iVar11, iVar10, (int64_t)&var_10h + iVar9, puVar18);
        if (iVar8 < 1) goto code_r0x0001801baffb;
        if (*(int64_t *)((int64_t)&var_10h + iVar9) != 0x30) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafcf;
            func_0x000180244fc0(iVar10, 0x30);
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafd4;
            func_0x000180229480();
            uVar14 = 0xbf7;
            goto code_r0x0001801bb011;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bafef;
        func_0x0001801c6380(in_RCX, iVar10, 0x30, 0);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb04f;
    func_0x000180224990(iVar10, 0x1804afc90, 0xc03);
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb057;
    func_0x000180258be0(iVar11);
code_r0x0001801bb07a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1801bb08a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_d0h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801bb0a0
// Address: 0x1801bb0a0
// Size: 236 bytes
// ============================================================
bool fcn.1801bb0a0(int64_t arg_28h)
{
    undefined *puVar1;
    uint64_t uVar2;
    undefined *puVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bb0ac;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (1 < (uint64_t)in_RDX[1]) {
        puVar3 = (undefined *)*in_RDX;
        puVar1 = puVar3 + 2;
        uVar2 = in_RDX[1] - 2;
        uVar8 = (uint32_t)CONCAT11(*puVar3, puVar3[1]);
        *in_RDX = (int64_t)puVar1;
        in_RDX[1] = uVar2;
        if (uVar8 <= uVar2) {
            in_RDX[1] = uVar2 - uVar8;
            *in_RDX = (int64_t)(puVar1 + uVar8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb106;
            iVar6 = fcn.180254c30(puVar1, uVar8, 0);
            *(int64_t *)(in_RCX + 0xc18) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb117;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb12f;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb145;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
                return false;
            }
            uVar7 = *(undefined8 *)(in_RCX + 0xbf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb15c;
            iVar4 = fcn.180255960(iVar6, uVar7);
            if (iVar4 < 0) {
                uVar7 = *(undefined8 *)(in_RCX + 0xc18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb170;
                iVar4 = fcn.1802553f0(uVar7);
                if (iVar4 == 0) {
                    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                    uVar7 = *(undefined8 *)(iVar6 + 0x358);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb19d;
                    fcn.180224990(uVar7, 0x1804afc90, 0xc89);
                    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1bd;
                    uVar7 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar5));
                    *(undefined8 *)(iVar6 + 0x358) = uVar7;
                    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x358) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1df;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1f7;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                      *(int64_t *)(&stack0x00000048 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb20d;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
                        return false;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb21d;
                    iVar4 = fcn.1801bce90(*(int64_t *)((int64_t)&arg_28h + iVar5), 
                                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5)
                                         );
                    return iVar4 != 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb231;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb249;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb25f;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb26c;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb284;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb29a;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
    return false;
}

// ============================================================
// Function: FUN_1801bb18c
// Address: 0x1801bb18c
// Size: 78 bytes
// ============================================================
bool fcn.1801bb0a0(int64_t arg_28h)
{
    undefined *puVar1;
    uint64_t uVar2;
    undefined *puVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bb0ac;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (1 < (uint64_t)in_RDX[1]) {
        puVar3 = (undefined *)*in_RDX;
        puVar1 = puVar3 + 2;
        uVar2 = in_RDX[1] - 2;
        uVar8 = (uint32_t)CONCAT11(*puVar3, puVar3[1]);
        *in_RDX = (int64_t)puVar1;
        in_RDX[1] = uVar2;
        if (uVar8 <= uVar2) {
            in_RDX[1] = uVar2 - uVar8;
            *in_RDX = (int64_t)(puVar1 + uVar8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb106;
            iVar6 = fcn.180254c30(puVar1, uVar8, 0);
            *(int64_t *)(in_RCX + 0xc18) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb117;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb12f;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb145;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
                return false;
            }
            uVar7 = *(undefined8 *)(in_RCX + 0xbf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb15c;
            iVar4 = fcn.180255960(iVar6, uVar7);
            if (iVar4 < 0) {
                uVar7 = *(undefined8 *)(in_RCX + 0xc18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb170;
                iVar4 = fcn.1802553f0(uVar7);
                if (iVar4 == 0) {
                    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                    uVar7 = *(undefined8 *)(iVar6 + 0x358);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb19d;
                    fcn.180224990(uVar7, 0x1804afc90, 0xc89);
                    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1bd;
                    uVar7 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar5));
                    *(undefined8 *)(iVar6 + 0x358) = uVar7;
                    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x358) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1df;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1f7;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                      *(int64_t *)(&stack0x00000048 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb20d;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
                        return false;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb21d;
                    iVar4 = fcn.1801bce90(*(int64_t *)((int64_t)&arg_28h + iVar5), 
                                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5)
                                         );
                    return iVar4 != 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb231;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb249;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb25f;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb26c;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb284;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb29a;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
    return false;
}

// ============================================================
// Function: FUN_1801bb1da
// Address: 0x1801bb1da
// Size: 200 bytes
// ============================================================
bool fcn.1801bb0a0(int64_t arg_28h)
{
    undefined *puVar1;
    uint64_t uVar2;
    undefined *puVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bb0ac;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (1 < (uint64_t)in_RDX[1]) {
        puVar3 = (undefined *)*in_RDX;
        puVar1 = puVar3 + 2;
        uVar2 = in_RDX[1] - 2;
        uVar8 = (uint32_t)CONCAT11(*puVar3, puVar3[1]);
        *in_RDX = (int64_t)puVar1;
        in_RDX[1] = uVar2;
        if (uVar8 <= uVar2) {
            in_RDX[1] = uVar2 - uVar8;
            *in_RDX = (int64_t)(puVar1 + uVar8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb106;
            iVar6 = fcn.180254c30(puVar1, uVar8, 0);
            *(int64_t *)(in_RCX + 0xc18) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb117;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb12f;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb145;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
                return false;
            }
            uVar7 = *(undefined8 *)(in_RCX + 0xbf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb15c;
            iVar4 = fcn.180255960(iVar6, uVar7);
            if (iVar4 < 0) {
                uVar7 = *(undefined8 *)(in_RCX + 0xc18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb170;
                iVar4 = fcn.1802553f0(uVar7);
                if (iVar4 == 0) {
                    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                    uVar7 = *(undefined8 *)(iVar6 + 0x358);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb19d;
                    fcn.180224990(uVar7, 0x1804afc90, 0xc89);
                    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1bd;
                    uVar7 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar5));
                    *(undefined8 *)(iVar6 + 0x358) = uVar7;
                    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x358) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1df;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb1f7;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                      *(int64_t *)(&stack0x00000048 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb20d;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
                        return false;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb21d;
                    iVar4 = fcn.1801bce90(*(int64_t *)((int64_t)&arg_28h + iVar5), 
                                          *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5)
                                         );
                    return iVar4 != 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb231;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb249;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb25f;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb26c;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb284;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bb29a;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
    return false;
}

// ============================================================
// Function: FUN_1801bb2b0
// Address: 0x1801bb2b0
// Size: 383 bytes
// ============================================================
int64_t fcn.1801bb2b0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    char cVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t in_RCX;
    uint8_t *puVar11;
    uint8_t **in_RDX;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint8_t *puVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bb2c4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar15 = 0;
    var_50h = *(int64_t *)(in_RCX + 8);
    var_8h = 0;
    var_18h = 0;
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x68);
    if (pcVar3 != (code *)0x0) {
        uVar10 = *(undefined8 *)(in_RCX + 0xc78);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb2fc;
        (*pcVar3)(uVar10, 0);
    }
    cVar1 = *(char *)(in_RCX + 0xb50);
    if (cVar1 == '\x02') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb312;
        iVar7 = func_0x0001801bc2d0(in_RCX, in_RDX);
        return iVar7;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R13;
    if (cVar1 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb330;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb348;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb35e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb368;
    var_18h = func_0x000180221f20();
    if (var_18h == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb376;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb38e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb3a4;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar6 = **(int32_t **)(in_RCX + 0x18), iVar6 < 0x304)) || (iVar6 == 0x10000)) goto code_r0x0001801bb427;
    var_48h = (int64_t)*in_RDX;
    var_40h = (int64_t)in_RDX[1];
    if (in_RDX[1] != (uint8_t *)0x0) {
        puVar12 = in_RDX[1] + -1;
        puVar14 = (uint8_t *)(uint64_t)*(uint8_t *)var_48h;
        puVar13 = (uint8_t *)(var_48h + 1);
        if (puVar14 <= puVar12) {
            var_40h = (int64_t)(puVar12 + -(int64_t)puVar14);
            var_48h = (int64_t)(puVar13 + (int64_t)puVar14);
            *in_RDX = puVar13 + (int64_t)puVar14;
            in_RDX[1] = puVar12 + -(int64_t)puVar14;
            if (*(int64_t *)(in_RCX + 0xbb0) == 0) {
                if (puVar14 == (uint8_t *)0x0) {
code_r0x0001801bb427:
                    var_48h = (int64_t)*in_RDX;
                    var_40h = (int64_t)in_RDX[1];
                    puVar13 = in_RDX[1];
                    *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RBX;
                    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
                    if (puVar13 < (uint8_t *)0x3) {
code_r0x0001801bba1b:
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba20;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba38;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7));
                    } else {
                        puVar13 = puVar13 + -3;
                        puVar14 = (uint8_t *)(var_48h + 3);
                        puVar12 = (uint8_t *)
                                  (uint64_t)
                                  CONCAT21(CONCAT11(*(uint8_t *)var_48h, *(uint8_t *)(var_48h + 1)), 
                                           *(uint8_t *)(var_48h + 2));
                        if (puVar13 < puVar12) goto code_r0x0001801bba1b;
                        var_48h = (int64_t)(puVar12 + (int64_t)puVar14);
                        var_40h = (int64_t)(puVar13 + -(int64_t)puVar12);
                        *in_RDX = puVar12 + (int64_t)puVar14;
                        in_RDX[1] = puVar13 + -(int64_t)puVar12;
                        iVar9 = iVar15;
                        iVar8 = var_18h;
                        if (in_RDX[1] != (uint8_t *)0x0) goto code_r0x0001801bba1b;
                        while (var_18h = iVar8, puVar12 != (uint8_t *)0x0) {
                            if (puVar12 < (uint8_t *)0x3) {
code_r0x0001801bb7bf:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7c4;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
code_r0x0001801bb751:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb764;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            puVar13 = puVar14 + 3;
                            puVar11 = (uint8_t *)(uint64_t)CONCAT21(CONCAT11(*puVar14, puVar14[1]), puVar14[2]);
                            if (puVar12 + -3 < puVar11) goto code_r0x0001801bb7bf;
                            puVar12 = puVar12 + -3 + -(int64_t)puVar11;
                            puVar14 = puVar13 + (int64_t)puVar11;
                            uVar10 = *(undefined8 *)(var_50h + 0x460);
                            uVar4 = *(undefined8 *)var_50h;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb4fe;
                            var_58h = (int64_t)puVar13;
                            var_8h = func_0x00018021ff10(uVar4, uVar10);
                            if (var_8h == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb79c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7b4;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb51b;
                            iVar8 = func_0x00018021fff0(&var_8h, &var_58h, puVar11);
                            if (iVar8 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb774;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb78c;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            if ((uint8_t *)var_58h != puVar11 + (int64_t)puVar13) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb74c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                goto code_r0x0001801bb751;
                            }
                            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                                (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) {
                                var_20h = 0;
                                if ((uint8_t *)0x1 < puVar12) {
                                    puVar13 = puVar14 + 2;
                                    puVar11 = (uint8_t *)(uint64_t)CONCAT11(*puVar14, puVar14[1]);
                                    if (puVar11 <= puVar12 + -2) {
                                        puVar12 = puVar12 + -2 + -(int64_t)puVar11;
                                        puVar14 = puVar11 + (int64_t)puVar13;
                                        *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) = (uint32_t)(iVar9 == 0);
                                        var_48h = (int64_t)puVar13;
                                        var_40h = (int64_t)puVar11;
                                        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5c3;
                                        iVar6 = func_0x0001801c9450(in_RCX, &var_48h, 0x1000, &var_20h);
                                        iVar5 = var_20h;
                                        iVar8 = var_8h;
                                        if (iVar6 != 0) {
                                            *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) =
                                                 (uint32_t)(puVar12 == (uint8_t *)0x0);
                                            *(int64_t *)(&stack0x00000000 + iVar7) = iVar9;
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5f2;
                                            iVar6 = func_0x0001801c9b70(in_RCX, 0x1000, iVar5, iVar8);
                                            if (iVar6 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb610;
                                                fcn.180224990(var_20h, 0x1804afc90, 0xe87);
                                                goto code_r0x0001801bb610;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6ed;
                                        fcn.180224990(var_20h, 0x1804afc90, 0xe84);
                                        iVar15 = 0;
                                        goto code_r0x0001801bba5b;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6f7;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb70f;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
code_r0x0001801bb610:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb61d;
                            iVar6 = func_0x000180222110(var_18h, var_8h);
                            if (iVar6 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb71f;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb737;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            var_8h = 0;
                            iVar9 = iVar9 + 1;
                            iVar8 = var_18h;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb641;
                        iVar6 = func_0x000180222010(iVar8);
                        if (iVar6 < 1) {
                            if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb65b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb673;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            } else {
                                if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) != 3) {
                                    if (*(int64_t *)(in_RCX + 0x1a8) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb818;
                                        iVar6 = func_0x0001801da790(in_RCX, 0);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
code_r0x0001801bb820:
                                    if (*(int32_t *)(in_RCX + 0xba8) == 4) {
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb83b;
                                        iVar9 = func_0x00018019dc20(uVar10, 0);
                                        if (iVar9 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb84c;
                                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb864;
                                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7));
                                            goto code_r0x0001801bba43;
                                        }
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb90c;
                                        func_0x00018019c980(uVar10);
                                        *(int64_t *)(in_RCX + 0x8f8) = iVar9;
                                    }
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb926;
                                    func_0x00018021fe80(uVar10);
                                    iVar9 = *(int64_t *)(in_RCX + 0x8f8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb935;
                                    uVar10 = func_0x0001802222a0(iVar8);
                                    *(undefined8 *)(iVar9 + 0x2c0) = uVar10;
                                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) =
                                         *(undefined4 *)(in_RCX + 0x990);
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb962;
                                    func_0x000180238640(uVar10);
                                    var_18h = 0;
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = iVar8;
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb987;
                                    func_0x00018022ecc0(uVar10);
                                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb9c3;
                                        iVar6 = func_0x0001801da790(in_RCX, 1);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba08;
                                        iVar6 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
                                        iVar15 = 0;
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                        *(undefined8 *)(in_RCX + 0x1550) = 0;
                                    }
                                    iVar15 = 3;
                                    goto code_r0x0001801bba5b;
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7dd;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7f5;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb87f;
                            iVar6 = func_0x0001801a2880(in_RCX, iVar8);
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb888;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8a0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                uVar2 = *(undefined4 *)(in_RCX + 0x990);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ab;
                                func_0x0001801affa0(uVar2);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8c2;
                                uVar10 = func_0x000180222340(iVar8, 0);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ca;
                                iVar9 = func_0x000180238400(uVar10);
                                if (iVar9 != 0) goto code_r0x0001801bb820;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8d8;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8f0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        }
                    }
code_r0x0001801bba43:
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba4e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    goto code_r0x0001801bba5b;
                }
            } else if (puVar14 == *(uint8_t **)(in_RCX + 3000)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb697;
                iVar6 = func_0x0001802262e0(puVar13);
                if (iVar6 == 0) goto code_r0x0001801bb427;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6a4;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6bc;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6d2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
code_r0x0001801bba5b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba64;
    func_0x00018021fe80(var_8h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba6d;
    func_0x000180238640(var_18h);
    return iVar15;
}

// ============================================================
// Function: FUN_1801bb42f
// Address: 0x1801bb42f
// Size: 596 bytes
// ============================================================
int64_t fcn.1801bb2b0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    char cVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t in_RCX;
    uint8_t *puVar11;
    uint8_t **in_RDX;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint8_t *puVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bb2c4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar15 = 0;
    var_50h = *(int64_t *)(in_RCX + 8);
    var_8h = 0;
    var_18h = 0;
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x68);
    if (pcVar3 != (code *)0x0) {
        uVar10 = *(undefined8 *)(in_RCX + 0xc78);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb2fc;
        (*pcVar3)(uVar10, 0);
    }
    cVar1 = *(char *)(in_RCX + 0xb50);
    if (cVar1 == '\x02') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb312;
        iVar7 = func_0x0001801bc2d0(in_RCX, in_RDX);
        return iVar7;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R13;
    if (cVar1 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb330;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb348;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb35e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb368;
    var_18h = func_0x000180221f20();
    if (var_18h == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb376;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb38e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb3a4;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar6 = **(int32_t **)(in_RCX + 0x18), iVar6 < 0x304)) || (iVar6 == 0x10000)) goto code_r0x0001801bb427;
    var_48h = (int64_t)*in_RDX;
    var_40h = (int64_t)in_RDX[1];
    if (in_RDX[1] != (uint8_t *)0x0) {
        puVar12 = in_RDX[1] + -1;
        puVar14 = (uint8_t *)(uint64_t)*(uint8_t *)var_48h;
        puVar13 = (uint8_t *)(var_48h + 1);
        if (puVar14 <= puVar12) {
            var_40h = (int64_t)(puVar12 + -(int64_t)puVar14);
            var_48h = (int64_t)(puVar13 + (int64_t)puVar14);
            *in_RDX = puVar13 + (int64_t)puVar14;
            in_RDX[1] = puVar12 + -(int64_t)puVar14;
            if (*(int64_t *)(in_RCX + 0xbb0) == 0) {
                if (puVar14 == (uint8_t *)0x0) {
code_r0x0001801bb427:
                    var_48h = (int64_t)*in_RDX;
                    var_40h = (int64_t)in_RDX[1];
                    puVar13 = in_RDX[1];
                    *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RBX;
                    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
                    if (puVar13 < (uint8_t *)0x3) {
code_r0x0001801bba1b:
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba20;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba38;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7));
                    } else {
                        puVar13 = puVar13 + -3;
                        puVar14 = (uint8_t *)(var_48h + 3);
                        puVar12 = (uint8_t *)
                                  (uint64_t)
                                  CONCAT21(CONCAT11(*(uint8_t *)var_48h, *(uint8_t *)(var_48h + 1)), 
                                           *(uint8_t *)(var_48h + 2));
                        if (puVar13 < puVar12) goto code_r0x0001801bba1b;
                        var_48h = (int64_t)(puVar12 + (int64_t)puVar14);
                        var_40h = (int64_t)(puVar13 + -(int64_t)puVar12);
                        *in_RDX = puVar12 + (int64_t)puVar14;
                        in_RDX[1] = puVar13 + -(int64_t)puVar12;
                        iVar9 = iVar15;
                        iVar8 = var_18h;
                        if (in_RDX[1] != (uint8_t *)0x0) goto code_r0x0001801bba1b;
                        while (var_18h = iVar8, puVar12 != (uint8_t *)0x0) {
                            if (puVar12 < (uint8_t *)0x3) {
code_r0x0001801bb7bf:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7c4;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
code_r0x0001801bb751:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb764;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            puVar13 = puVar14 + 3;
                            puVar11 = (uint8_t *)(uint64_t)CONCAT21(CONCAT11(*puVar14, puVar14[1]), puVar14[2]);
                            if (puVar12 + -3 < puVar11) goto code_r0x0001801bb7bf;
                            puVar12 = puVar12 + -3 + -(int64_t)puVar11;
                            puVar14 = puVar13 + (int64_t)puVar11;
                            uVar10 = *(undefined8 *)(var_50h + 0x460);
                            uVar4 = *(undefined8 *)var_50h;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb4fe;
                            var_58h = (int64_t)puVar13;
                            var_8h = func_0x00018021ff10(uVar4, uVar10);
                            if (var_8h == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb79c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7b4;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb51b;
                            iVar8 = func_0x00018021fff0(&var_8h, &var_58h, puVar11);
                            if (iVar8 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb774;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb78c;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            if ((uint8_t *)var_58h != puVar11 + (int64_t)puVar13) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb74c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                goto code_r0x0001801bb751;
                            }
                            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                                (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) {
                                var_20h = 0;
                                if ((uint8_t *)0x1 < puVar12) {
                                    puVar13 = puVar14 + 2;
                                    puVar11 = (uint8_t *)(uint64_t)CONCAT11(*puVar14, puVar14[1]);
                                    if (puVar11 <= puVar12 + -2) {
                                        puVar12 = puVar12 + -2 + -(int64_t)puVar11;
                                        puVar14 = puVar11 + (int64_t)puVar13;
                                        *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) = (uint32_t)(iVar9 == 0);
                                        var_48h = (int64_t)puVar13;
                                        var_40h = (int64_t)puVar11;
                                        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5c3;
                                        iVar6 = func_0x0001801c9450(in_RCX, &var_48h, 0x1000, &var_20h);
                                        iVar5 = var_20h;
                                        iVar8 = var_8h;
                                        if (iVar6 != 0) {
                                            *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) =
                                                 (uint32_t)(puVar12 == (uint8_t *)0x0);
                                            *(int64_t *)(&stack0x00000000 + iVar7) = iVar9;
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5f2;
                                            iVar6 = func_0x0001801c9b70(in_RCX, 0x1000, iVar5, iVar8);
                                            if (iVar6 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb610;
                                                fcn.180224990(var_20h, 0x1804afc90, 0xe87);
                                                goto code_r0x0001801bb610;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6ed;
                                        fcn.180224990(var_20h, 0x1804afc90, 0xe84);
                                        iVar15 = 0;
                                        goto code_r0x0001801bba5b;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6f7;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb70f;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
code_r0x0001801bb610:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb61d;
                            iVar6 = func_0x000180222110(var_18h, var_8h);
                            if (iVar6 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb71f;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb737;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            var_8h = 0;
                            iVar9 = iVar9 + 1;
                            iVar8 = var_18h;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb641;
                        iVar6 = func_0x000180222010(iVar8);
                        if (iVar6 < 1) {
                            if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb65b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb673;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            } else {
                                if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) != 3) {
                                    if (*(int64_t *)(in_RCX + 0x1a8) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb818;
                                        iVar6 = func_0x0001801da790(in_RCX, 0);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
code_r0x0001801bb820:
                                    if (*(int32_t *)(in_RCX + 0xba8) == 4) {
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb83b;
                                        iVar9 = func_0x00018019dc20(uVar10, 0);
                                        if (iVar9 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb84c;
                                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb864;
                                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7));
                                            goto code_r0x0001801bba43;
                                        }
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb90c;
                                        func_0x00018019c980(uVar10);
                                        *(int64_t *)(in_RCX + 0x8f8) = iVar9;
                                    }
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb926;
                                    func_0x00018021fe80(uVar10);
                                    iVar9 = *(int64_t *)(in_RCX + 0x8f8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb935;
                                    uVar10 = func_0x0001802222a0(iVar8);
                                    *(undefined8 *)(iVar9 + 0x2c0) = uVar10;
                                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) =
                                         *(undefined4 *)(in_RCX + 0x990);
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb962;
                                    func_0x000180238640(uVar10);
                                    var_18h = 0;
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = iVar8;
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb987;
                                    func_0x00018022ecc0(uVar10);
                                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb9c3;
                                        iVar6 = func_0x0001801da790(in_RCX, 1);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba08;
                                        iVar6 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
                                        iVar15 = 0;
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                        *(undefined8 *)(in_RCX + 0x1550) = 0;
                                    }
                                    iVar15 = 3;
                                    goto code_r0x0001801bba5b;
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7dd;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7f5;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb87f;
                            iVar6 = func_0x0001801a2880(in_RCX, iVar8);
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb888;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8a0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                uVar2 = *(undefined4 *)(in_RCX + 0x990);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ab;
                                func_0x0001801affa0(uVar2);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8c2;
                                uVar10 = func_0x000180222340(iVar8, 0);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ca;
                                iVar9 = func_0x000180238400(uVar10);
                                if (iVar9 != 0) goto code_r0x0001801bb820;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8d8;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8f0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        }
                    }
code_r0x0001801bba43:
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba4e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    goto code_r0x0001801bba5b;
                }
            } else if (puVar14 == *(uint8_t **)(in_RCX + 3000)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb697;
                iVar6 = func_0x0001802262e0(puVar13);
                if (iVar6 == 0) goto code_r0x0001801bb427;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6a4;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6bc;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6d2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
code_r0x0001801bba5b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba64;
    func_0x00018021fe80(var_8h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba6d;
    func_0x000180238640(var_18h);
    return iVar15;
}

// ============================================================
// Function: FUN_1801bb683
// Address: 0x1801bb683
// Size: 84 bytes
// ============================================================
int64_t fcn.1801bb2b0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    char cVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t in_RCX;
    uint8_t *puVar11;
    uint8_t **in_RDX;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint8_t *puVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bb2c4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar15 = 0;
    var_50h = *(int64_t *)(in_RCX + 8);
    var_8h = 0;
    var_18h = 0;
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x68);
    if (pcVar3 != (code *)0x0) {
        uVar10 = *(undefined8 *)(in_RCX + 0xc78);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb2fc;
        (*pcVar3)(uVar10, 0);
    }
    cVar1 = *(char *)(in_RCX + 0xb50);
    if (cVar1 == '\x02') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb312;
        iVar7 = func_0x0001801bc2d0(in_RCX, in_RDX);
        return iVar7;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R13;
    if (cVar1 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb330;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb348;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb35e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb368;
    var_18h = func_0x000180221f20();
    if (var_18h == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb376;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb38e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb3a4;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar6 = **(int32_t **)(in_RCX + 0x18), iVar6 < 0x304)) || (iVar6 == 0x10000)) goto code_r0x0001801bb427;
    var_48h = (int64_t)*in_RDX;
    var_40h = (int64_t)in_RDX[1];
    if (in_RDX[1] != (uint8_t *)0x0) {
        puVar12 = in_RDX[1] + -1;
        puVar14 = (uint8_t *)(uint64_t)*(uint8_t *)var_48h;
        puVar13 = (uint8_t *)(var_48h + 1);
        if (puVar14 <= puVar12) {
            var_40h = (int64_t)(puVar12 + -(int64_t)puVar14);
            var_48h = (int64_t)(puVar13 + (int64_t)puVar14);
            *in_RDX = puVar13 + (int64_t)puVar14;
            in_RDX[1] = puVar12 + -(int64_t)puVar14;
            if (*(int64_t *)(in_RCX + 0xbb0) == 0) {
                if (puVar14 == (uint8_t *)0x0) {
code_r0x0001801bb427:
                    var_48h = (int64_t)*in_RDX;
                    var_40h = (int64_t)in_RDX[1];
                    puVar13 = in_RDX[1];
                    *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RBX;
                    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
                    if (puVar13 < (uint8_t *)0x3) {
code_r0x0001801bba1b:
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba20;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba38;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7));
                    } else {
                        puVar13 = puVar13 + -3;
                        puVar14 = (uint8_t *)(var_48h + 3);
                        puVar12 = (uint8_t *)
                                  (uint64_t)
                                  CONCAT21(CONCAT11(*(uint8_t *)var_48h, *(uint8_t *)(var_48h + 1)), 
                                           *(uint8_t *)(var_48h + 2));
                        if (puVar13 < puVar12) goto code_r0x0001801bba1b;
                        var_48h = (int64_t)(puVar12 + (int64_t)puVar14);
                        var_40h = (int64_t)(puVar13 + -(int64_t)puVar12);
                        *in_RDX = puVar12 + (int64_t)puVar14;
                        in_RDX[1] = puVar13 + -(int64_t)puVar12;
                        iVar9 = iVar15;
                        iVar8 = var_18h;
                        if (in_RDX[1] != (uint8_t *)0x0) goto code_r0x0001801bba1b;
                        while (var_18h = iVar8, puVar12 != (uint8_t *)0x0) {
                            if (puVar12 < (uint8_t *)0x3) {
code_r0x0001801bb7bf:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7c4;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
code_r0x0001801bb751:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb764;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            puVar13 = puVar14 + 3;
                            puVar11 = (uint8_t *)(uint64_t)CONCAT21(CONCAT11(*puVar14, puVar14[1]), puVar14[2]);
                            if (puVar12 + -3 < puVar11) goto code_r0x0001801bb7bf;
                            puVar12 = puVar12 + -3 + -(int64_t)puVar11;
                            puVar14 = puVar13 + (int64_t)puVar11;
                            uVar10 = *(undefined8 *)(var_50h + 0x460);
                            uVar4 = *(undefined8 *)var_50h;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb4fe;
                            var_58h = (int64_t)puVar13;
                            var_8h = func_0x00018021ff10(uVar4, uVar10);
                            if (var_8h == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb79c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7b4;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb51b;
                            iVar8 = func_0x00018021fff0(&var_8h, &var_58h, puVar11);
                            if (iVar8 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb774;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb78c;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            if ((uint8_t *)var_58h != puVar11 + (int64_t)puVar13) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb74c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                goto code_r0x0001801bb751;
                            }
                            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                                (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) {
                                var_20h = 0;
                                if ((uint8_t *)0x1 < puVar12) {
                                    puVar13 = puVar14 + 2;
                                    puVar11 = (uint8_t *)(uint64_t)CONCAT11(*puVar14, puVar14[1]);
                                    if (puVar11 <= puVar12 + -2) {
                                        puVar12 = puVar12 + -2 + -(int64_t)puVar11;
                                        puVar14 = puVar11 + (int64_t)puVar13;
                                        *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) = (uint32_t)(iVar9 == 0);
                                        var_48h = (int64_t)puVar13;
                                        var_40h = (int64_t)puVar11;
                                        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5c3;
                                        iVar6 = func_0x0001801c9450(in_RCX, &var_48h, 0x1000, &var_20h);
                                        iVar5 = var_20h;
                                        iVar8 = var_8h;
                                        if (iVar6 != 0) {
                                            *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) =
                                                 (uint32_t)(puVar12 == (uint8_t *)0x0);
                                            *(int64_t *)(&stack0x00000000 + iVar7) = iVar9;
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5f2;
                                            iVar6 = func_0x0001801c9b70(in_RCX, 0x1000, iVar5, iVar8);
                                            if (iVar6 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb610;
                                                fcn.180224990(var_20h, 0x1804afc90, 0xe87);
                                                goto code_r0x0001801bb610;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6ed;
                                        fcn.180224990(var_20h, 0x1804afc90, 0xe84);
                                        iVar15 = 0;
                                        goto code_r0x0001801bba5b;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6f7;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb70f;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
code_r0x0001801bb610:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb61d;
                            iVar6 = func_0x000180222110(var_18h, var_8h);
                            if (iVar6 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb71f;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb737;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            var_8h = 0;
                            iVar9 = iVar9 + 1;
                            iVar8 = var_18h;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb641;
                        iVar6 = func_0x000180222010(iVar8);
                        if (iVar6 < 1) {
                            if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb65b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb673;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            } else {
                                if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) != 3) {
                                    if (*(int64_t *)(in_RCX + 0x1a8) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb818;
                                        iVar6 = func_0x0001801da790(in_RCX, 0);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
code_r0x0001801bb820:
                                    if (*(int32_t *)(in_RCX + 0xba8) == 4) {
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb83b;
                                        iVar9 = func_0x00018019dc20(uVar10, 0);
                                        if (iVar9 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb84c;
                                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb864;
                                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7));
                                            goto code_r0x0001801bba43;
                                        }
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb90c;
                                        func_0x00018019c980(uVar10);
                                        *(int64_t *)(in_RCX + 0x8f8) = iVar9;
                                    }
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb926;
                                    func_0x00018021fe80(uVar10);
                                    iVar9 = *(int64_t *)(in_RCX + 0x8f8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb935;
                                    uVar10 = func_0x0001802222a0(iVar8);
                                    *(undefined8 *)(iVar9 + 0x2c0) = uVar10;
                                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) =
                                         *(undefined4 *)(in_RCX + 0x990);
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb962;
                                    func_0x000180238640(uVar10);
                                    var_18h = 0;
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = iVar8;
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb987;
                                    func_0x00018022ecc0(uVar10);
                                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb9c3;
                                        iVar6 = func_0x0001801da790(in_RCX, 1);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba08;
                                        iVar6 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
                                        iVar15 = 0;
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                        *(undefined8 *)(in_RCX + 0x1550) = 0;
                                    }
                                    iVar15 = 3;
                                    goto code_r0x0001801bba5b;
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7dd;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7f5;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb87f;
                            iVar6 = func_0x0001801a2880(in_RCX, iVar8);
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb888;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8a0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                uVar2 = *(undefined4 *)(in_RCX + 0x990);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ab;
                                func_0x0001801affa0(uVar2);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8c2;
                                uVar10 = func_0x000180222340(iVar8, 0);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ca;
                                iVar9 = func_0x000180238400(uVar10);
                                if (iVar9 != 0) goto code_r0x0001801bb820;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8d8;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8f0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        }
                    }
code_r0x0001801bba43:
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba4e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    goto code_r0x0001801bba5b;
                }
            } else if (puVar14 == *(uint8_t **)(in_RCX + 3000)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb697;
                iVar6 = func_0x0001802262e0(puVar13);
                if (iVar6 == 0) goto code_r0x0001801bb427;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6a4;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6bc;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6d2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
code_r0x0001801bba5b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba64;
    func_0x00018021fe80(var_8h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba6d;
    func_0x000180238640(var_18h);
    return iVar15;
}

// ============================================================
// Function: FUN_1801bb6d7
// Address: 0x1801bb6d7
// Size: 900 bytes
// ============================================================
int64_t fcn.1801bb2b0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    char cVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t in_RCX;
    uint8_t *puVar11;
    uint8_t **in_RDX;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint8_t *puVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bb2c4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar15 = 0;
    var_50h = *(int64_t *)(in_RCX + 8);
    var_8h = 0;
    var_18h = 0;
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x68);
    if (pcVar3 != (code *)0x0) {
        uVar10 = *(undefined8 *)(in_RCX + 0xc78);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb2fc;
        (*pcVar3)(uVar10, 0);
    }
    cVar1 = *(char *)(in_RCX + 0xb50);
    if (cVar1 == '\x02') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb312;
        iVar7 = func_0x0001801bc2d0(in_RCX, in_RDX);
        return iVar7;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R13;
    if (cVar1 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb330;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb348;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb35e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb368;
    var_18h = func_0x000180221f20();
    if (var_18h == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb376;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb38e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb3a4;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar6 = **(int32_t **)(in_RCX + 0x18), iVar6 < 0x304)) || (iVar6 == 0x10000)) goto code_r0x0001801bb427;
    var_48h = (int64_t)*in_RDX;
    var_40h = (int64_t)in_RDX[1];
    if (in_RDX[1] != (uint8_t *)0x0) {
        puVar12 = in_RDX[1] + -1;
        puVar14 = (uint8_t *)(uint64_t)*(uint8_t *)var_48h;
        puVar13 = (uint8_t *)(var_48h + 1);
        if (puVar14 <= puVar12) {
            var_40h = (int64_t)(puVar12 + -(int64_t)puVar14);
            var_48h = (int64_t)(puVar13 + (int64_t)puVar14);
            *in_RDX = puVar13 + (int64_t)puVar14;
            in_RDX[1] = puVar12 + -(int64_t)puVar14;
            if (*(int64_t *)(in_RCX + 0xbb0) == 0) {
                if (puVar14 == (uint8_t *)0x0) {
code_r0x0001801bb427:
                    var_48h = (int64_t)*in_RDX;
                    var_40h = (int64_t)in_RDX[1];
                    puVar13 = in_RDX[1];
                    *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RBX;
                    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
                    if (puVar13 < (uint8_t *)0x3) {
code_r0x0001801bba1b:
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba20;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba38;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7));
                    } else {
                        puVar13 = puVar13 + -3;
                        puVar14 = (uint8_t *)(var_48h + 3);
                        puVar12 = (uint8_t *)
                                  (uint64_t)
                                  CONCAT21(CONCAT11(*(uint8_t *)var_48h, *(uint8_t *)(var_48h + 1)), 
                                           *(uint8_t *)(var_48h + 2));
                        if (puVar13 < puVar12) goto code_r0x0001801bba1b;
                        var_48h = (int64_t)(puVar12 + (int64_t)puVar14);
                        var_40h = (int64_t)(puVar13 + -(int64_t)puVar12);
                        *in_RDX = puVar12 + (int64_t)puVar14;
                        in_RDX[1] = puVar13 + -(int64_t)puVar12;
                        iVar9 = iVar15;
                        iVar8 = var_18h;
                        if (in_RDX[1] != (uint8_t *)0x0) goto code_r0x0001801bba1b;
                        while (var_18h = iVar8, puVar12 != (uint8_t *)0x0) {
                            if (puVar12 < (uint8_t *)0x3) {
code_r0x0001801bb7bf:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7c4;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
code_r0x0001801bb751:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb764;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            puVar13 = puVar14 + 3;
                            puVar11 = (uint8_t *)(uint64_t)CONCAT21(CONCAT11(*puVar14, puVar14[1]), puVar14[2]);
                            if (puVar12 + -3 < puVar11) goto code_r0x0001801bb7bf;
                            puVar12 = puVar12 + -3 + -(int64_t)puVar11;
                            puVar14 = puVar13 + (int64_t)puVar11;
                            uVar10 = *(undefined8 *)(var_50h + 0x460);
                            uVar4 = *(undefined8 *)var_50h;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb4fe;
                            var_58h = (int64_t)puVar13;
                            var_8h = func_0x00018021ff10(uVar4, uVar10);
                            if (var_8h == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb79c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7b4;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb51b;
                            iVar8 = func_0x00018021fff0(&var_8h, &var_58h, puVar11);
                            if (iVar8 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb774;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb78c;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            if ((uint8_t *)var_58h != puVar11 + (int64_t)puVar13) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb74c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                goto code_r0x0001801bb751;
                            }
                            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                                (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) {
                                var_20h = 0;
                                if ((uint8_t *)0x1 < puVar12) {
                                    puVar13 = puVar14 + 2;
                                    puVar11 = (uint8_t *)(uint64_t)CONCAT11(*puVar14, puVar14[1]);
                                    if (puVar11 <= puVar12 + -2) {
                                        puVar12 = puVar12 + -2 + -(int64_t)puVar11;
                                        puVar14 = puVar11 + (int64_t)puVar13;
                                        *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) = (uint32_t)(iVar9 == 0);
                                        var_48h = (int64_t)puVar13;
                                        var_40h = (int64_t)puVar11;
                                        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5c3;
                                        iVar6 = func_0x0001801c9450(in_RCX, &var_48h, 0x1000, &var_20h);
                                        iVar5 = var_20h;
                                        iVar8 = var_8h;
                                        if (iVar6 != 0) {
                                            *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) =
                                                 (uint32_t)(puVar12 == (uint8_t *)0x0);
                                            *(int64_t *)(&stack0x00000000 + iVar7) = iVar9;
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5f2;
                                            iVar6 = func_0x0001801c9b70(in_RCX, 0x1000, iVar5, iVar8);
                                            if (iVar6 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb610;
                                                fcn.180224990(var_20h, 0x1804afc90, 0xe87);
                                                goto code_r0x0001801bb610;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6ed;
                                        fcn.180224990(var_20h, 0x1804afc90, 0xe84);
                                        iVar15 = 0;
                                        goto code_r0x0001801bba5b;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6f7;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb70f;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
code_r0x0001801bb610:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb61d;
                            iVar6 = func_0x000180222110(var_18h, var_8h);
                            if (iVar6 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb71f;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb737;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            var_8h = 0;
                            iVar9 = iVar9 + 1;
                            iVar8 = var_18h;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb641;
                        iVar6 = func_0x000180222010(iVar8);
                        if (iVar6 < 1) {
                            if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb65b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb673;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            } else {
                                if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) != 3) {
                                    if (*(int64_t *)(in_RCX + 0x1a8) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb818;
                                        iVar6 = func_0x0001801da790(in_RCX, 0);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
code_r0x0001801bb820:
                                    if (*(int32_t *)(in_RCX + 0xba8) == 4) {
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb83b;
                                        iVar9 = func_0x00018019dc20(uVar10, 0);
                                        if (iVar9 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb84c;
                                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb864;
                                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7));
                                            goto code_r0x0001801bba43;
                                        }
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb90c;
                                        func_0x00018019c980(uVar10);
                                        *(int64_t *)(in_RCX + 0x8f8) = iVar9;
                                    }
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb926;
                                    func_0x00018021fe80(uVar10);
                                    iVar9 = *(int64_t *)(in_RCX + 0x8f8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb935;
                                    uVar10 = func_0x0001802222a0(iVar8);
                                    *(undefined8 *)(iVar9 + 0x2c0) = uVar10;
                                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) =
                                         *(undefined4 *)(in_RCX + 0x990);
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb962;
                                    func_0x000180238640(uVar10);
                                    var_18h = 0;
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = iVar8;
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb987;
                                    func_0x00018022ecc0(uVar10);
                                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb9c3;
                                        iVar6 = func_0x0001801da790(in_RCX, 1);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba08;
                                        iVar6 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
                                        iVar15 = 0;
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                        *(undefined8 *)(in_RCX + 0x1550) = 0;
                                    }
                                    iVar15 = 3;
                                    goto code_r0x0001801bba5b;
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7dd;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7f5;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb87f;
                            iVar6 = func_0x0001801a2880(in_RCX, iVar8);
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb888;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8a0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                uVar2 = *(undefined4 *)(in_RCX + 0x990);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ab;
                                func_0x0001801affa0(uVar2);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8c2;
                                uVar10 = func_0x000180222340(iVar8, 0);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ca;
                                iVar9 = func_0x000180238400(uVar10);
                                if (iVar9 != 0) goto code_r0x0001801bb820;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8d8;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8f0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        }
                    }
code_r0x0001801bba43:
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba4e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    goto code_r0x0001801bba5b;
                }
            } else if (puVar14 == *(uint8_t **)(in_RCX + 3000)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb697;
                iVar6 = func_0x0001802262e0(puVar13);
                if (iVar6 == 0) goto code_r0x0001801bb427;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6a4;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6bc;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6d2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
code_r0x0001801bba5b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba64;
    func_0x00018021fe80(var_8h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba6d;
    func_0x000180238640(var_18h);
    return iVar15;
}

// ============================================================
// Function: FUN_1801bba5b
// Address: 0x1801bba5b
// Size: 42 bytes
// ============================================================
int64_t fcn.1801bb2b0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    char cVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t in_RCX;
    uint8_t *puVar11;
    uint8_t **in_RDX;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint8_t *puVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801bb2c4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar15 = 0;
    var_50h = *(int64_t *)(in_RCX + 8);
    var_8h = 0;
    var_18h = 0;
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x68);
    if (pcVar3 != (code *)0x0) {
        uVar10 = *(undefined8 *)(in_RCX + 0xc78);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb2fc;
        (*pcVar3)(uVar10, 0);
    }
    cVar1 = *(char *)(in_RCX + 0xb50);
    if (cVar1 == '\x02') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb312;
        iVar7 = func_0x0001801bc2d0(in_RCX, in_RDX);
        return iVar7;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R13;
    if (cVar1 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb330;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb348;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb35e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb368;
    var_18h = func_0x000180221f20();
    if (var_18h == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb376;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb38e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb3a4;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
        goto code_r0x0001801bba5b;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar6 = **(int32_t **)(in_RCX + 0x18), iVar6 < 0x304)) || (iVar6 == 0x10000)) goto code_r0x0001801bb427;
    var_48h = (int64_t)*in_RDX;
    var_40h = (int64_t)in_RDX[1];
    if (in_RDX[1] != (uint8_t *)0x0) {
        puVar12 = in_RDX[1] + -1;
        puVar14 = (uint8_t *)(uint64_t)*(uint8_t *)var_48h;
        puVar13 = (uint8_t *)(var_48h + 1);
        if (puVar14 <= puVar12) {
            var_40h = (int64_t)(puVar12 + -(int64_t)puVar14);
            var_48h = (int64_t)(puVar13 + (int64_t)puVar14);
            *in_RDX = puVar13 + (int64_t)puVar14;
            in_RDX[1] = puVar12 + -(int64_t)puVar14;
            if (*(int64_t *)(in_RCX + 0xbb0) == 0) {
                if (puVar14 == (uint8_t *)0x0) {
code_r0x0001801bb427:
                    var_48h = (int64_t)*in_RDX;
                    var_40h = (int64_t)in_RDX[1];
                    puVar13 = in_RDX[1];
                    *(undefined8 *)((int64_t)&arg_78h + iVar7) = unaff_RBX;
                    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
                    if (puVar13 < (uint8_t *)0x3) {
code_r0x0001801bba1b:
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba20;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba38;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7));
                    } else {
                        puVar13 = puVar13 + -3;
                        puVar14 = (uint8_t *)(var_48h + 3);
                        puVar12 = (uint8_t *)
                                  (uint64_t)
                                  CONCAT21(CONCAT11(*(uint8_t *)var_48h, *(uint8_t *)(var_48h + 1)), 
                                           *(uint8_t *)(var_48h + 2));
                        if (puVar13 < puVar12) goto code_r0x0001801bba1b;
                        var_48h = (int64_t)(puVar12 + (int64_t)puVar14);
                        var_40h = (int64_t)(puVar13 + -(int64_t)puVar12);
                        *in_RDX = puVar12 + (int64_t)puVar14;
                        in_RDX[1] = puVar13 + -(int64_t)puVar12;
                        iVar9 = iVar15;
                        iVar8 = var_18h;
                        if (in_RDX[1] != (uint8_t *)0x0) goto code_r0x0001801bba1b;
                        while (var_18h = iVar8, puVar12 != (uint8_t *)0x0) {
                            if (puVar12 < (uint8_t *)0x3) {
code_r0x0001801bb7bf:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7c4;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
code_r0x0001801bb751:
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb764;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            puVar13 = puVar14 + 3;
                            puVar11 = (uint8_t *)(uint64_t)CONCAT21(CONCAT11(*puVar14, puVar14[1]), puVar14[2]);
                            if (puVar12 + -3 < puVar11) goto code_r0x0001801bb7bf;
                            puVar12 = puVar12 + -3 + -(int64_t)puVar11;
                            puVar14 = puVar13 + (int64_t)puVar11;
                            uVar10 = *(undefined8 *)(var_50h + 0x460);
                            uVar4 = *(undefined8 *)var_50h;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb4fe;
                            var_58h = (int64_t)puVar13;
                            var_8h = func_0x00018021ff10(uVar4, uVar10);
                            if (var_8h == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb79c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7b4;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb51b;
                            iVar8 = func_0x00018021fff0(&var_8h, &var_58h, puVar11);
                            if (iVar8 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb774;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb78c;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            if ((uint8_t *)var_58h != puVar11 + (int64_t)puVar13) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb74c;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                goto code_r0x0001801bb751;
                            }
                            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                                (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) {
                                var_20h = 0;
                                if ((uint8_t *)0x1 < puVar12) {
                                    puVar13 = puVar14 + 2;
                                    puVar11 = (uint8_t *)(uint64_t)CONCAT11(*puVar14, puVar14[1]);
                                    if (puVar11 <= puVar12 + -2) {
                                        puVar12 = puVar12 + -2 + -(int64_t)puVar11;
                                        puVar14 = puVar11 + (int64_t)puVar13;
                                        *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) = (uint32_t)(iVar9 == 0);
                                        var_48h = (int64_t)puVar13;
                                        var_40h = (int64_t)puVar11;
                                        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5c3;
                                        iVar6 = func_0x0001801c9450(in_RCX, &var_48h, 0x1000, &var_20h);
                                        iVar5 = var_20h;
                                        iVar8 = var_8h;
                                        if (iVar6 != 0) {
                                            *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) =
                                                 (uint32_t)(puVar12 == (uint8_t *)0x0);
                                            *(int64_t *)(&stack0x00000000 + iVar7) = iVar9;
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb5f2;
                                            iVar6 = func_0x0001801c9b70(in_RCX, 0x1000, iVar5, iVar8);
                                            if (iVar6 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb610;
                                                fcn.180224990(var_20h, 0x1804afc90, 0xe87);
                                                goto code_r0x0001801bb610;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6ed;
                                        fcn.180224990(var_20h, 0x1804afc90, 0xe84);
                                        iVar15 = 0;
                                        goto code_r0x0001801bba5b;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6f7;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb70f;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
code_r0x0001801bb610:
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb61d;
                            iVar6 = func_0x000180222110(var_18h, var_8h);
                            if (iVar6 == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb71f;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb737;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                goto code_r0x0001801bba43;
                            }
                            var_8h = 0;
                            iVar9 = iVar9 + 1;
                            iVar8 = var_18h;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb641;
                        iVar6 = func_0x000180222010(iVar8);
                        if (iVar6 < 1) {
                            if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb65b;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb673;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            } else {
                                if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) != 3) {
                                    if (*(int64_t *)(in_RCX + 0x1a8) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb818;
                                        iVar6 = func_0x0001801da790(in_RCX, 0);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
code_r0x0001801bb820:
                                    if (*(int32_t *)(in_RCX + 0xba8) == 4) {
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb83b;
                                        iVar9 = func_0x00018019dc20(uVar10, 0);
                                        if (iVar9 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb84c;
                                            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb864;
                                            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7));
                                            goto code_r0x0001801bba43;
                                        }
                                        uVar10 = *(undefined8 *)(in_RCX + 0x8f8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb90c;
                                        func_0x00018019c980(uVar10);
                                        *(int64_t *)(in_RCX + 0x8f8) = iVar9;
                                    }
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb926;
                                    func_0x00018021fe80(uVar10);
                                    iVar9 = *(int64_t *)(in_RCX + 0x8f8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb935;
                                    uVar10 = func_0x0001802222a0(iVar8);
                                    *(undefined8 *)(iVar9 + 0x2c0) = uVar10;
                                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) =
                                         *(undefined4 *)(in_RCX + 0x990);
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb962;
                                    func_0x000180238640(uVar10);
                                    var_18h = 0;
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = iVar8;
                                    uVar10 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb987;
                                    func_0x00018022ecc0(uVar10);
                                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb9c3;
                                        iVar6 = func_0x0001801da790(in_RCX, 1);
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                    }
                                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                          == 0) && (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) &&
                                       (iVar6 != 0x10000)) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba08;
                                        iVar6 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
                                        iVar15 = 0;
                                        if (iVar6 == 0) goto code_r0x0001801bba5b;
                                        *(undefined8 *)(in_RCX + 0x1550) = 0;
                                    }
                                    iVar15 = 3;
                                    goto code_r0x0001801bba5b;
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7dd;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb7f5;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb87f;
                            iVar6 = func_0x0001801a2880(in_RCX, iVar8);
                            if (iVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb888;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8a0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                                uVar2 = *(undefined4 *)(in_RCX + 0x990);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ab;
                                func_0x0001801affa0(uVar2);
                            } else {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8c2;
                                uVar10 = func_0x000180222340(iVar8, 0);
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8ca;
                                iVar9 = func_0x000180238400(uVar10);
                                if (iVar9 != 0) goto code_r0x0001801bb820;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8d8;
                                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb8f0;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7));
                            }
                        }
                    }
code_r0x0001801bba43:
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba4e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    goto code_r0x0001801bba5b;
                }
            } else if (puVar14 == *(uint8_t **)(in_RCX + 3000)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb697;
                iVar6 = func_0x0001802262e0(puVar13);
                if (iVar6 == 0) goto code_r0x0001801bb427;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6a4;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6bc;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bb6d2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
code_r0x0001801bba5b:
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba64;
    func_0x00018021fe80(var_8h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801bba6d;
    func_0x000180238640(var_18h);
    return iVar15;
}

// ============================================================
// Function: FUN_1801bba90
// Address: 0x1801bba90
// Size: 1708 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801bba90(int64_t arg_28h, int64_t arg_38h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    int64_t in_RCX;
    uint8_t *puVar14;
    uint8_t *puVar15;
    uint32_t uVar16;
    uint8_t **in_RDX;
    uint8_t *puVar17;
    uint32_t uVar18;
    uint8_t *puVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801bbab4;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    piVar12 = (int32_t *)0x0;
    if (((*(int32_t *)(in_RCX + 0xba0) == 0) && (*(int64_t *)(in_RCX + 0x260) != 0)) &&
       (*(int64_t *)(in_RCX + 0x2e8) != 0)) {
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar10 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar10)) && (iVar10 != 0x10000)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbb0f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbb27;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                          *(int64_t *)((int64_t)&arg_38h + iVar11));
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbb3d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar11));
            goto code_r0x0001801bc106;
        }
        if ((((uint32_t)*(uint64_t *)(in_RCX + 0x9a8) & 0x40000100) != 0x100) ||
           ((*(int32_t *)(in_RCX + 0x4b0) == 0 && ((*(uint64_t *)(in_RCX + 0x9a8) >> 0x12 & 1) == 0)))) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbbe3;
            func_0x0001801c6e50(in_RCX, 1, 100);
            return 1;
        }
        *(undefined4 *)(in_RCX + 0xba0) = 1;
        *(undefined4 *)(in_RCX + 0x7c) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbb90;
    piVar12 = (int32_t *)func_0x000180224d60(0x290, 0x1804afc90, 0x5eb);
    if (piVar12 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbb9d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbbb5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                      *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                      *(int64_t *)((int64_t)&arg_38h + iVar11));
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbbcb;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar11));
        goto code_r0x0001801bc106;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbbf9;
    iVar10 = func_0x0001801a2f40(in_RCX + 0xc50);
    *piVar12 = iVar10;
    if (iVar10 == 0) {
code_r0x0001801bbc9a:
        if (in_RDX[1] < (uint8_t *)0x2) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc0bf;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc0d7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                          *(int64_t *)((int64_t)&arg_38h + iVar11));
            goto code_r0x0001801bc0e2;
        }
        uVar1 = **in_RDX;
        piVar12[1] = (uint32_t)uVar1 << 8;
        piVar12[1] = (uint32_t)CONCAT11(uVar1, (*in_RDX)[1]);
        *in_RDX = *in_RDX + 2;
        in_RDX[1] = in_RDX[1] + -2;
        puVar19 = *in_RDX;
        puVar17 = in_RDX[1];
        if (*piVar12 != 0) {
            if (puVar17 < (uint8_t *)0x2) {
code_r0x0001801bbe60:
                *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbe65;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            } else {
                uVar1 = puVar19[1];
                uVar2 = *puVar19;
                *in_RDX = puVar19 + 2;
                in_RDX[1] = puVar17 + -2;
                if (puVar17 + -2 < (uint8_t *)0x2) goto code_r0x0001801bbe60;
                uVar16 = (uint32_t)CONCAT11(puVar19[2], puVar19[3]);
                *in_RDX = puVar19 + 4;
                in_RDX[1] = puVar17 + -4;
                if (puVar17 + -4 < (uint8_t *)0x2) goto code_r0x0001801bbe60;
                uVar18 = (uint32_t)CONCAT11(puVar19[4], puVar19[5]);
                puVar15 = (uint8_t *)(uint64_t)uVar18;
                *in_RDX = puVar19 + 6;
                in_RDX[1] = puVar17 + -6;
                if (0x20 < uVar16) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbd4c;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbd64;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                                  *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar11));
                    goto code_r0x0001801bc0e2;
                }
                puVar14 = (uint8_t *)(uint64_t)CONCAT11(uVar2, uVar1);
                if (puVar14 <= puVar17 + -6) {
                    *(uint8_t **)(piVar12 + 0x58) = puVar14;
                    *(uint8_t **)(piVar12 + 0x56) = puVar19 + 6;
                    *in_RDX = *in_RDX + (int64_t)puVar14;
                    in_RDX[1] = in_RDX[1] + -(int64_t)puVar14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbdae;
                    iVar10 = func_0x0001801b4900(in_RDX, piVar12 + 0xc, (uint64_t)uVar16);
                    if ((iVar10 != 0) && (puVar15 <= in_RDX[1])) {
                        puVar19 = *in_RDX;
                        puVar17 = in_RDX[1] + -(int64_t)puVar15;
                        in_RDX[1] = puVar17;
                        *in_RDX = puVar19 + (int64_t)puVar15;
                        if (puVar17 == (uint8_t *)0x0) {
                            *(uint64_t *)(piVar12 + 10) = (uint64_t)uVar16;
                            *(undefined (*) [16])(piVar12 + 2) = ZEXT816(0);
                            if (0x20 < uVar18) {
                                uVar18 = 0x20;
                            }
                            *(undefined (*) [16])(piVar12 + 6) = ZEXT816(0);
                            if (puVar15 < (uint8_t *)(uint64_t)uVar18) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbe2e;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), 
                                              *(int64_t *)((int64_t)&var_10h + iVar11));
                                goto code_r0x0001801bbc77;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbe0a;
                            fcn.180498030((int64_t)piVar12 + (0x28 - (int64_t)(uint8_t *)(uint64_t)uVar18), puVar19);
                            puVar17 = (uint8_t *)0x1;
                            *(undefined8 *)(piVar12 + 0x9c) = 0;
                            puVar19 = (uint8_t *)0x1804afb9b;
                            *(undefined8 *)(piVar12 + 0x9e) = 0;
                            goto code_r0x0001801bc037;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbe3d;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbe55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                          *(int64_t *)((int64_t)&arg_38h + iVar11));
            goto code_r0x0001801bc0e2;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbe7e;
        iVar10 = func_0x0001801b4900(in_RDX, piVar12 + 2, 0x20);
        if (iVar10 == 0) {
code_r0x0001801bbecb:
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbed0;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
code_r0x0001801bbf86:
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbf99;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                          *(int64_t *)((int64_t)&arg_38h + iVar11));
            goto code_r0x0001801bc0e2;
        }
        puVar17 = *in_RDX;
        puVar15 = in_RDX[1];
        puVar19 = in_RDX[1];
        *(uint8_t **)((int64_t)&var_18h + iVar11) = puVar17;
        *(uint8_t **)((int64_t)&var_20h + iVar11) = puVar15;
        if (puVar19 == (uint8_t *)0x0) goto code_r0x0001801bbecb;
        puVar19 = puVar19 + -1;
        puVar15 = (uint8_t *)(uint64_t)*puVar17;
        if (puVar19 < puVar15) goto code_r0x0001801bbecb;
        *(uint8_t **)((int64_t)&var_18h + iVar11) = puVar15 + (int64_t)(puVar17 + 1);
        *(int64_t *)((int64_t)&var_20h + iVar11) = (int64_t)puVar19 - (int64_t)puVar15;
        uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar11 + 4);
        uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar11);
        uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar11 + 4);
        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar11);
        *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
        *(undefined4 *)(in_RDX + 1) = uVar5;
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
        if ((uint8_t *)0x20 < puVar15) {
            *(undefined8 *)(piVar12 + 10) = 0;
            goto code_r0x0001801bbecb;
        }
        *(uint8_t **)(piVar12 + 10) = puVar15;
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbee7;
        fcn.180498030(piVar12 + 0xc);
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            puVar17 = *in_RDX;
            puVar15 = in_RDX[1];
            puVar19 = in_RDX[1];
            *(uint8_t **)((int64_t)&var_18h + iVar11) = puVar17;
            *(uint8_t **)((int64_t)&var_20h + iVar11) = puVar15;
            if (puVar19 != (uint8_t *)0x0) {
                puVar19 = puVar19 + -1;
                puVar15 = (uint8_t *)(uint64_t)*puVar17;
                if (puVar15 <= puVar19) {
                    *(int64_t *)((int64_t)&var_20h + iVar11) = (int64_t)puVar19 - (int64_t)puVar15;
                    *(uint8_t **)((int64_t)&var_18h + iVar11) = puVar15 + (int64_t)(puVar17 + 1);
                    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar11 + 4);
                    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar11);
                    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar11 + 4);
                    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar11);
                    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                    *(undefined4 *)(in_RDX + 1) = uVar5;
                    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                    *(uint8_t **)(piVar12 + 0x14) = puVar15;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbf48;
                    fcn.180498030(piVar12 + 0x16);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbf50;
                    uVar13 = func_0x000180193b40(in_RCX);
                    if (((uVar13 >> 0xd & 1) != 0) && (*(int64_t *)(piVar12 + 0x14) == 0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbf72;
                        fcn.180224990(piVar12, 0x1804afc90, 0x670);
                        return 1;
                    }
                    goto code_r0x0001801bbfa4;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbf81;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            goto code_r0x0001801bbf86;
        }
code_r0x0001801bbfa4:
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbfb3;
        iVar10 = func_0x0001801b4960(in_RDX, piVar12 + 0x56);
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbfbc;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            goto code_r0x0001801bbf86;
        }
        puVar19 = *in_RDX;
        puVar17 = in_RDX[1];
        puVar15 = in_RDX[1];
        *(uint8_t **)((int64_t)&var_18h + iVar11) = puVar19;
        *(uint8_t **)((int64_t)&var_20h + iVar11) = puVar17;
        if (puVar15 == (uint8_t *)0x0) {
code_r0x0001801bc0ab:
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc0b0;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            goto code_r0x0001801bbf86;
        }
        puVar15 = puVar15 + -1;
        puVar17 = (uint8_t *)(uint64_t)*puVar19;
        puVar19 = puVar19 + 1;
        if (puVar15 < puVar17) goto code_r0x0001801bc0ab;
        *(uint8_t **)((int64_t)&var_18h + iVar11) = puVar19 + (int64_t)puVar17;
        *(int64_t *)((int64_t)&var_20h + iVar11) = (int64_t)puVar15 - (int64_t)puVar17;
        uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar11 + 4);
        uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar11);
        uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar11 + 4);
        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar11);
        *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
        *(undefined4 *)(in_RDX + 1) = uVar5;
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
        if (in_RDX[1] == (uint8_t *)0x0) {
            *(undefined8 *)(piVar12 + 0x9c) = 0;
            *(undefined8 *)(piVar12 + 0x9e) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc02d;
            iVar10 = func_0x0001801b4960(in_RDX, piVar12 + 0x9c);
            if ((iVar10 == 0) || (in_RDX[1] != (uint8_t *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc0a1;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
                goto code_r0x0001801bbf86;
            }
        }
code_r0x0001801bc037:
        *(uint8_t **)(piVar12 + 0x5a) = puVar17;
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc050;
        fcn.180498030(piVar12 + 0x5c, puVar19, puVar17);
        iVar10 = piVar12[0x9c];
        iVar7 = piVar12[0x9d];
        iVar8 = piVar12[0x9e];
        iVar9 = piVar12[0x9f];
        *(undefined4 *)((int64_t)&var_10h + iVar11) = 1;
        *(int32_t **)((int64_t)&var_8h + iVar11) = piVar12 + 0xa0;
        *(int32_t *)((int64_t)&arg_28h + iVar11) = iVar10;
        *(int32_t *)((int64_t)&arg_28h + iVar11 + 4) = iVar7;
        *(int32_t *)(&stack0x00000030 + iVar11) = iVar8;
        *(int32_t *)(&stack0x00000034 + iVar11) = iVar9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc087;
        iVar10 = func_0x0001801c9450(in_RCX, (int64_t)&arg_28h + iVar11, 0x80, piVar12 + 0xa2);
        if (iVar10 != 0) {
            *(int32_t **)(in_RCX + 0xb58) = piVar12;
            return 2;
        }
    } else {
        if (((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) &&
           (*(int32_t *)(in_RCX + 0x8c8) == 0)) {
            if (in_RDX[1] != (uint8_t *)0x0) {
                uVar1 = **in_RDX;
                *in_RDX = *in_RDX + 1;
                in_RDX[1] = in_RDX[1] + -1;
                if (uVar1 == 1) goto code_r0x0001801bbc9a;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbc72;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
code_r0x0001801bbc77:
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbc8a;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                          *(int64_t *)((int64_t)&arg_38h + iVar11));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbc23;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bbc3b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11), 
                          *(int64_t *)((int64_t)&arg_38h + iVar11));
        }
code_r0x0001801bc0e2:
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc0ed;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar11));
    }
    uVar3 = *(undefined8 *)(piVar12 + 0xa2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc106;
    fcn.180224990(uVar3, 0x1804afc90, 0x6a1);
code_r0x0001801bc106:
    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801bc11b;
    fcn.180224990(piVar12, 0x1804afc90, 0x6a2);
    return 0;
}

// ============================================================
// Function: FUN_1801bc140
// Address: 0x1801bc140
// Size: 391 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

undefined8 fcn.1801bc140(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc155;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c);
    if ((uVar1 & 0x1c8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc175;
        iVar4 = fcn.1801ba9d0();
        if (iVar4 == 0) goto code_r0x0001801bc287;
    }
    if ((uVar1 & 8) == 0) {
        if ((uVar1 & 0x41) == 0) {
            if ((uVar1 & 0x102) == 0) {
                if ((uVar1 & 0x84) == 0) {
                    if ((uVar1 & 0x20) == 0) {
                        if ((uVar1 & 0x10) == 0) {
                            if ((uVar1 >> 9 & 1) == 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc259;
                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc271;
                                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar5));
                                goto code_r0x0001801bc27c;
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc23b;
                            iVar4 = func_0x0001801ba6a0(in_RCX, in_RDX);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc228;
                            iVar4 = func_0x0001801ba3d0(in_RCX, in_RDX);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc215;
                        iVar4 = fcn.1801bb0a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc202;
                    iVar4 = func_0x0001801ba1d0(in_RCX, in_RDX);
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc1ef;
                iVar4 = func_0x0001801b9fe0(in_RCX, in_RDX);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc1da;
            iVar4 = fcn.1801bacc0(*(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                                  *(int64_t *)(&stack0x00000090 + iVar5), *(int64_t *)(&stack0x000000c0 + iVar5), 
                                  *(int64_t *)(&stack0x000000d0 + iVar5), *(int64_t *)(&stack0x000000d8 + iVar5), 
                                  *(int64_t *)(&stack0x000000e0 + iVar5), *(int64_t *)(&stack0x00000120 + iVar5));
        }
    } else {
        if (*(int64_t *)(in_RDX + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc18f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc1a7;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801bc27c:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc287;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
            goto code_r0x0001801bc287;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc1c7;
        iVar4 = func_0x0001801c6380(in_RCX, 0, 0, 0);
    }
    if (iVar4 != 0) {
        return 2;
    }
code_r0x0001801bc287:
    uVar2 = *(undefined8 *)(in_RCX + 0x3c8);
    uVar3 = *(undefined8 *)(in_RCX + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bc2a7;
    func_0x000180224b90(uVar3, uVar2, 0x1804afc90, 0xd90);
    *(undefined8 *)(in_RCX + 0x3c0) = 0;
    *(undefined8 *)(in_RCX + 0x3c8) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801bc2d0
// Address: 0x1801bc2d0
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801bc2d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 uVar6;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc2e0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc2f7;
    iVar3 = func_0x0001801b2020();
    if (iVar3 == 0) goto code_r0x0001801bc4f7;
    if (*(int64_t *)((int64_t)&arg_38h + iVar4) == 0) {
        if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) == 3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc31f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc337;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc34d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc35a;
        iVar3 = func_0x0001801a2c20(in_RCX);
        if (iVar3 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc363;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc37b;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            uVar1 = *(undefined4 *)(in_RCX + 0x990);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc386;
            func_0x0001801affa0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc399;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
    }
    iVar3 = *(int32_t *)(in_RCX + 0xba8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
    if (iVar3 == 4) {
        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3ba;
        iVar5 = func_0x00018019dc20(uVar2, 0);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3c7;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3df;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3f5;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc406;
        func_0x00018019c980(uVar2);
        *(int64_t *)(in_RCX + 0x8f8) = iVar5;
    }
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc420;
    func_0x00018021fe80(uVar2);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc448;
    func_0x000180222050(uVar2, 0x18021fe80);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc469;
    func_0x00018022ecc0(uVar2);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = *(undefined8 *)((int64_t)&arg_38h + iVar4);
    iVar5 = *(int64_t *)(in_RCX + 0x8f8);
    uVar1 = *(undefined4 *)(in_RCX + 0x990);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined4 *)(iVar5 + 0x2d0) = uVar1;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc4c2;
        iVar3 = func_0x0001801da790(in_RCX, 1);
        if (iVar3 == 0) goto code_r0x0001801bc4f7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc4e2;
        iVar3 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
        if (iVar3 == 0) goto code_r0x0001801bc4f7;
        *(undefined8 *)(in_RCX + 0x1550) = 0;
    }
    uVar6 = 3;
code_r0x0001801bc4f7:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc501;
    func_0x00018022ecc0(*(undefined8 *)((int64_t)&arg_38h + iVar4));
    return uVar6;
}

// ============================================================
// Function: FUN_1801bc3a5
// Address: 0x1801bc3a5
// Size: 338 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801bc2d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 uVar6;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc2e0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc2f7;
    iVar3 = func_0x0001801b2020();
    if (iVar3 == 0) goto code_r0x0001801bc4f7;
    if (*(int64_t *)((int64_t)&arg_38h + iVar4) == 0) {
        if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) == 3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc31f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc337;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc34d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc35a;
        iVar3 = func_0x0001801a2c20(in_RCX);
        if (iVar3 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc363;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc37b;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            uVar1 = *(undefined4 *)(in_RCX + 0x990);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc386;
            func_0x0001801affa0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc399;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
    }
    iVar3 = *(int32_t *)(in_RCX + 0xba8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
    if (iVar3 == 4) {
        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3ba;
        iVar5 = func_0x00018019dc20(uVar2, 0);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3c7;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3df;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3f5;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc406;
        func_0x00018019c980(uVar2);
        *(int64_t *)(in_RCX + 0x8f8) = iVar5;
    }
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc420;
    func_0x00018021fe80(uVar2);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc448;
    func_0x000180222050(uVar2, 0x18021fe80);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc469;
    func_0x00018022ecc0(uVar2);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = *(undefined8 *)((int64_t)&arg_38h + iVar4);
    iVar5 = *(int64_t *)(in_RCX + 0x8f8);
    uVar1 = *(undefined4 *)(in_RCX + 0x990);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined4 *)(iVar5 + 0x2d0) = uVar1;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc4c2;
        iVar3 = func_0x0001801da790(in_RCX, 1);
        if (iVar3 == 0) goto code_r0x0001801bc4f7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc4e2;
        iVar3 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
        if (iVar3 == 0) goto code_r0x0001801bc4f7;
        *(undefined8 *)(in_RCX + 0x1550) = 0;
    }
    uVar6 = 3;
code_r0x0001801bc4f7:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc501;
    func_0x00018022ecc0(*(undefined8 *)((int64_t)&arg_38h + iVar4));
    return uVar6;
}

// ============================================================
// Function: FUN_1801bc4f7
// Address: 0x1801bc4f7
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801bc2d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 uVar6;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc2e0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc2f7;
    iVar3 = func_0x0001801b2020();
    if (iVar3 == 0) goto code_r0x0001801bc4f7;
    if (*(int64_t *)((int64_t)&arg_38h + iVar4) == 0) {
        if (((uint8_t)*(undefined4 *)(in_RCX + 0x948) & 3) == 3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc31f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc337;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc34d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc35a;
        iVar3 = func_0x0001801a2c20(in_RCX);
        if (iVar3 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc363;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc37b;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            uVar1 = *(undefined4 *)(in_RCX + 0x990);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc386;
            func_0x0001801affa0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc399;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
    }
    iVar3 = *(int32_t *)(in_RCX + 0xba8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
    if (iVar3 == 4) {
        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3ba;
        iVar5 = func_0x00018019dc20(uVar2, 0);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3c7;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3df;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc3f5;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            goto code_r0x0001801bc4f7;
        }
        uVar2 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc406;
        func_0x00018019c980(uVar2);
        *(int64_t *)(in_RCX + 0x8f8) = iVar5;
    }
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc420;
    func_0x00018021fe80(uVar2);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc448;
    func_0x000180222050(uVar2, 0x18021fe80);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc469;
    func_0x00018022ecc0(uVar2);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = *(undefined8 *)((int64_t)&arg_38h + iVar4);
    iVar5 = *(int64_t *)(in_RCX + 0x8f8);
    uVar1 = *(undefined4 *)(in_RCX + 0x990);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined4 *)(iVar5 + 0x2d0) = uVar1;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc4c2;
        iVar3 = func_0x0001801da790(in_RCX, 1);
        if (iVar3 == 0) goto code_r0x0001801bc4f7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc4e2;
        iVar3 = func_0x000180197770(in_RCX, in_RCX + 0x880, 0x40, in_RCX + 0x8c0);
        if (iVar3 == 0) goto code_r0x0001801bc4f7;
        *(undefined8 *)(in_RCX + 0x1550) = 0;
    }
    uVar6 = 3;
code_r0x0001801bc4f7:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bc501;
    func_0x00018022ecc0(*(undefined8 *)((int64_t)&arg_38h + iVar4));
    return uVar6;
}

// ============================================================
// Function: FUN_1801bc510
// Address: 0x1801bc510
// Size: 36 bytes
// ============================================================
undefined8
fcn.1801bc510(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 *in_RCX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int32_t iVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1801bc51a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar14 = 1;
    iVar10 = 0;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar6) = 0x1801bc557;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar3 = 0;
    if ((iVar10 == 0) && (in_RCX == (undefined8 *)0x0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc575;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc58d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc59f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
    } else {
        if ((iVar13 == 0) && (iVar14 != 0)) {
            iVar13 = 0x1804b0168;
            *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar6) = 0x1804b0168;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5d7;
        iVar1 = func_0x000180265d70(iVar13, (int64_t)&var_18h + iVar7 + iVar6);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc636;
            uVar8 = func_0x000180265d20(*(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6), 
                                        (int64_t)&arg_88h + iVar7 + iVar6, (int64_t)&arg_78h + iVar7 + iVar6);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc63e;
            iVar13 = func_0x0001801dc640();
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc64d;
                func_0x0001802454c0(0);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc655;
                func_0x0001801dc5e0(0);
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_80h + iVar7 + iVar6) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = unaff_R14;
            uVar2 = 0x62;
            if (iVar14 != 0) {
                uVar2 = 2;
            }
            if (iVar10 == 0) {
                iVar15 = in_RCX[1];
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6a8;
                func_0x0001801dc780(iVar13, in_RCX);
            } else {
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc696;
                func_0x0001801dc680(iVar13, iVar10);
                in_RCX = *(undefined8 **)(iVar10 + 8);
            }
            uVar9 = *in_RCX;
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6b3;
            iVar3 = func_0x0001802451e0(uVar9);
            uVar4 = uVar2 | 0x10;
            if (iVar3 == 0) {
                uVar4 = uVar2;
            }
            uVar2 = uVar4 | 8;
            if (*(int64_t *)(iVar15 + 0x40) == 0x1801982f0) {
                uVar2 = uVar4;
            }
            uVar4 = uVar2 | 4;
            if (*(int64_t *)(iVar15 + 0x48) == 0x1801982f0) {
                uVar4 = uVar2;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6f1;
            func_0x0001801dc670(iVar13, uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6f9;
            uVar9 = func_0x0001802454c0(uVar9);
            iVar1 = 0;
            uVar12 = 0;
            if (*(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6) != 0) {
                do {
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc735;
                    func_0x000180265d50(uVar8, uVar12, (int64_t)&arg_28h + iVar7 + iVar6, 
                                        (int64_t)&var_20h + iVar7 + iVar6);
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc747;
                    iVar5 = func_0x0001801dc860(iVar13, *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6));
                    iVar11 = iVar1 + 1;
                    if (0 < iVar5) {
                        iVar11 = iVar1;
                    }
                    iVar1 = iVar11;
                    uVar12 = uVar12 + 1;
                } while (uVar12 < *(uint64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc766;
            iVar5 = func_0x0001801dc490(iVar13);
            iVar11 = iVar1 + 1;
            if (iVar5 != 0) {
                iVar11 = iVar1;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc776;
            func_0x0001802454c0(uVar9);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc77e;
            func_0x0001801dc5e0(iVar13);
            if (iVar11 == 0) {
                return 1;
            }
            goto code_r0x0001801bc787;
        }
        if (iVar14 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5e4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5fc;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc61a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5a6;
    func_0x0001802454c0(0);
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5ad;
    func_0x0001801dc5e0(0);
code_r0x0001801bc787:
    if ((iVar14 != 0) && (iVar3 == 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bc540
// Address: 0x1801bc540
// Size: 294 bytes
// ============================================================
undefined8
fcn.1801bc510(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 *in_RCX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int32_t iVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1801bc51a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar14 = 1;
    iVar10 = 0;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar6) = 0x1801bc557;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar3 = 0;
    if ((iVar10 == 0) && (in_RCX == (undefined8 *)0x0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc575;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc58d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc59f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
    } else {
        if ((iVar13 == 0) && (iVar14 != 0)) {
            iVar13 = 0x1804b0168;
            *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar6) = 0x1804b0168;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5d7;
        iVar1 = func_0x000180265d70(iVar13, (int64_t)&var_18h + iVar7 + iVar6);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc636;
            uVar8 = func_0x000180265d20(*(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6), 
                                        (int64_t)&arg_88h + iVar7 + iVar6, (int64_t)&arg_78h + iVar7 + iVar6);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc63e;
            iVar13 = func_0x0001801dc640();
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc64d;
                func_0x0001802454c0(0);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc655;
                func_0x0001801dc5e0(0);
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_80h + iVar7 + iVar6) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = unaff_R14;
            uVar2 = 0x62;
            if (iVar14 != 0) {
                uVar2 = 2;
            }
            if (iVar10 == 0) {
                iVar15 = in_RCX[1];
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6a8;
                func_0x0001801dc780(iVar13, in_RCX);
            } else {
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc696;
                func_0x0001801dc680(iVar13, iVar10);
                in_RCX = *(undefined8 **)(iVar10 + 8);
            }
            uVar9 = *in_RCX;
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6b3;
            iVar3 = func_0x0001802451e0(uVar9);
            uVar4 = uVar2 | 0x10;
            if (iVar3 == 0) {
                uVar4 = uVar2;
            }
            uVar2 = uVar4 | 8;
            if (*(int64_t *)(iVar15 + 0x40) == 0x1801982f0) {
                uVar2 = uVar4;
            }
            uVar4 = uVar2 | 4;
            if (*(int64_t *)(iVar15 + 0x48) == 0x1801982f0) {
                uVar4 = uVar2;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6f1;
            func_0x0001801dc670(iVar13, uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6f9;
            uVar9 = func_0x0001802454c0(uVar9);
            iVar1 = 0;
            uVar12 = 0;
            if (*(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6) != 0) {
                do {
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc735;
                    func_0x000180265d50(uVar8, uVar12, (int64_t)&arg_28h + iVar7 + iVar6, 
                                        (int64_t)&var_20h + iVar7 + iVar6);
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc747;
                    iVar5 = func_0x0001801dc860(iVar13, *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6));
                    iVar11 = iVar1 + 1;
                    if (0 < iVar5) {
                        iVar11 = iVar1;
                    }
                    iVar1 = iVar11;
                    uVar12 = uVar12 + 1;
                } while (uVar12 < *(uint64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc766;
            iVar5 = func_0x0001801dc490(iVar13);
            iVar11 = iVar1 + 1;
            if (iVar5 != 0) {
                iVar11 = iVar1;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc776;
            func_0x0001802454c0(uVar9);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc77e;
            func_0x0001801dc5e0(iVar13);
            if (iVar11 == 0) {
                return 1;
            }
            goto code_r0x0001801bc787;
        }
        if (iVar14 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5e4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5fc;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc61a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5a6;
    func_0x0001802454c0(0);
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5ad;
    func_0x0001801dc5e0(0);
code_r0x0001801bc787:
    if ((iVar14 != 0) && (iVar3 == 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bc666
// Address: 0x1801bc666
// Size: 186 bytes
// ============================================================
undefined8
fcn.1801bc510(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 *in_RCX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int32_t iVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1801bc51a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar14 = 1;
    iVar10 = 0;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar6) = 0x1801bc557;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar3 = 0;
    if ((iVar10 == 0) && (in_RCX == (undefined8 *)0x0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc575;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc58d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc59f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
    } else {
        if ((iVar13 == 0) && (iVar14 != 0)) {
            iVar13 = 0x1804b0168;
            *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar6) = 0x1804b0168;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5d7;
        iVar1 = func_0x000180265d70(iVar13, (int64_t)&var_18h + iVar7 + iVar6);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc636;
            uVar8 = func_0x000180265d20(*(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6), 
                                        (int64_t)&arg_88h + iVar7 + iVar6, (int64_t)&arg_78h + iVar7 + iVar6);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc63e;
            iVar13 = func_0x0001801dc640();
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc64d;
                func_0x0001802454c0(0);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc655;
                func_0x0001801dc5e0(0);
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_80h + iVar7 + iVar6) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = unaff_R14;
            uVar2 = 0x62;
            if (iVar14 != 0) {
                uVar2 = 2;
            }
            if (iVar10 == 0) {
                iVar15 = in_RCX[1];
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6a8;
                func_0x0001801dc780(iVar13, in_RCX);
            } else {
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc696;
                func_0x0001801dc680(iVar13, iVar10);
                in_RCX = *(undefined8 **)(iVar10 + 8);
            }
            uVar9 = *in_RCX;
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6b3;
            iVar3 = func_0x0001802451e0(uVar9);
            uVar4 = uVar2 | 0x10;
            if (iVar3 == 0) {
                uVar4 = uVar2;
            }
            uVar2 = uVar4 | 8;
            if (*(int64_t *)(iVar15 + 0x40) == 0x1801982f0) {
                uVar2 = uVar4;
            }
            uVar4 = uVar2 | 4;
            if (*(int64_t *)(iVar15 + 0x48) == 0x1801982f0) {
                uVar4 = uVar2;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6f1;
            func_0x0001801dc670(iVar13, uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6f9;
            uVar9 = func_0x0001802454c0(uVar9);
            iVar1 = 0;
            uVar12 = 0;
            if (*(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6) != 0) {
                do {
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc735;
                    func_0x000180265d50(uVar8, uVar12, (int64_t)&arg_28h + iVar7 + iVar6, 
                                        (int64_t)&var_20h + iVar7 + iVar6);
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc747;
                    iVar5 = func_0x0001801dc860(iVar13, *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6));
                    iVar11 = iVar1 + 1;
                    if (0 < iVar5) {
                        iVar11 = iVar1;
                    }
                    iVar1 = iVar11;
                    uVar12 = uVar12 + 1;
                } while (uVar12 < *(uint64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc766;
            iVar5 = func_0x0001801dc490(iVar13);
            iVar11 = iVar1 + 1;
            if (iVar5 != 0) {
                iVar11 = iVar1;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc776;
            func_0x0001802454c0(uVar9);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc77e;
            func_0x0001801dc5e0(iVar13);
            if (iVar11 == 0) {
                return 1;
            }
            goto code_r0x0001801bc787;
        }
        if (iVar14 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5e4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5fc;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc61a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5a6;
    func_0x0001802454c0(0);
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5ad;
    func_0x0001801dc5e0(0);
code_r0x0001801bc787:
    if ((iVar14 != 0) && (iVar3 == 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bc720
// Address: 0x1801bc720
// Size: 103 bytes
// ============================================================
undefined8
fcn.1801bc510(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 *in_RCX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int32_t iVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1801bc51a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar14 = 1;
    iVar10 = 0;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar6) = 0x1801bc557;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar3 = 0;
    if ((iVar10 == 0) && (in_RCX == (undefined8 *)0x0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc575;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc58d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc59f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
    } else {
        if ((iVar13 == 0) && (iVar14 != 0)) {
            iVar13 = 0x1804b0168;
            *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar6) = 0x1804b0168;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5d7;
        iVar1 = func_0x000180265d70(iVar13, (int64_t)&var_18h + iVar7 + iVar6);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc636;
            uVar8 = func_0x000180265d20(*(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6), 
                                        (int64_t)&arg_88h + iVar7 + iVar6, (int64_t)&arg_78h + iVar7 + iVar6);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc63e;
            iVar13 = func_0x0001801dc640();
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc64d;
                func_0x0001802454c0(0);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc655;
                func_0x0001801dc5e0(0);
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_80h + iVar7 + iVar6) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = unaff_R14;
            uVar2 = 0x62;
            if (iVar14 != 0) {
                uVar2 = 2;
            }
            if (iVar10 == 0) {
                iVar15 = in_RCX[1];
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6a8;
                func_0x0001801dc780(iVar13, in_RCX);
            } else {
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc696;
                func_0x0001801dc680(iVar13, iVar10);
                in_RCX = *(undefined8 **)(iVar10 + 8);
            }
            uVar9 = *in_RCX;
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6b3;
            iVar3 = func_0x0001802451e0(uVar9);
            uVar4 = uVar2 | 0x10;
            if (iVar3 == 0) {
                uVar4 = uVar2;
            }
            uVar2 = uVar4 | 8;
            if (*(int64_t *)(iVar15 + 0x40) == 0x1801982f0) {
                uVar2 = uVar4;
            }
            uVar4 = uVar2 | 4;
            if (*(int64_t *)(iVar15 + 0x48) == 0x1801982f0) {
                uVar4 = uVar2;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6f1;
            func_0x0001801dc670(iVar13, uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6f9;
            uVar9 = func_0x0001802454c0(uVar9);
            iVar1 = 0;
            uVar12 = 0;
            if (*(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6) != 0) {
                do {
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc735;
                    func_0x000180265d50(uVar8, uVar12, (int64_t)&arg_28h + iVar7 + iVar6, 
                                        (int64_t)&var_20h + iVar7 + iVar6);
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc747;
                    iVar5 = func_0x0001801dc860(iVar13, *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6));
                    iVar11 = iVar1 + 1;
                    if (0 < iVar5) {
                        iVar11 = iVar1;
                    }
                    iVar1 = iVar11;
                    uVar12 = uVar12 + 1;
                } while (uVar12 < *(uint64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc766;
            iVar5 = func_0x0001801dc490(iVar13);
            iVar11 = iVar1 + 1;
            if (iVar5 != 0) {
                iVar11 = iVar1;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc776;
            func_0x0001802454c0(uVar9);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc77e;
            func_0x0001801dc5e0(iVar13);
            if (iVar11 == 0) {
                return 1;
            }
            goto code_r0x0001801bc787;
        }
        if (iVar14 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5e4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5fc;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc61a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5a6;
    func_0x0001802454c0(0);
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5ad;
    func_0x0001801dc5e0(0);
code_r0x0001801bc787:
    if ((iVar14 != 0) && (iVar3 == 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bc787
// Address: 0x1801bc787
// Size: 42 bytes
// ============================================================
undefined8
fcn.1801bc510(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 *in_RCX;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int32_t iVar14;
    undefined8 unaff_R12;
    int64_t iVar15;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1801bc51a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar14 = 1;
    iVar10 = 0;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar6 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar6) = 0x1801bc557;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar3 = 0;
    if ((iVar10 == 0) && (in_RCX == (undefined8 *)0x0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc575;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc58d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc59f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
    } else {
        if ((iVar13 == 0) && (iVar14 != 0)) {
            iVar13 = 0x1804b0168;
            *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar6) = 0x1804b0168;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5d7;
        iVar1 = func_0x000180265d70(iVar13, (int64_t)&var_18h + iVar7 + iVar6);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc636;
            uVar8 = func_0x000180265d20(*(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6), 
                                        (int64_t)&arg_88h + iVar7 + iVar6, (int64_t)&arg_78h + iVar7 + iVar6);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc63e;
            iVar13 = func_0x0001801dc640();
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc64d;
                func_0x0001802454c0(0);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc655;
                func_0x0001801dc5e0(0);
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_80h + iVar7 + iVar6) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = unaff_R14;
            uVar2 = 0x62;
            if (iVar14 != 0) {
                uVar2 = 2;
            }
            if (iVar10 == 0) {
                iVar15 = in_RCX[1];
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6a8;
                func_0x0001801dc780(iVar13, in_RCX);
            } else {
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc696;
                func_0x0001801dc680(iVar13, iVar10);
                in_RCX = *(undefined8 **)(iVar10 + 8);
            }
            uVar9 = *in_RCX;
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6b3;
            iVar3 = func_0x0001802451e0(uVar9);
            uVar4 = uVar2 | 0x10;
            if (iVar3 == 0) {
                uVar4 = uVar2;
            }
            uVar2 = uVar4 | 8;
            if (*(int64_t *)(iVar15 + 0x40) == 0x1801982f0) {
                uVar2 = uVar4;
            }
            uVar4 = uVar2 | 4;
            if (*(int64_t *)(iVar15 + 0x48) == 0x1801982f0) {
                uVar4 = uVar2;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6 + -8 + 8) = 0x1801bc6f1;
            func_0x0001801dc670(iVar13, uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc6f9;
            uVar9 = func_0x0001802454c0(uVar9);
            iVar1 = 0;
            uVar12 = 0;
            if (*(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6) != 0) {
                do {
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc735;
                    func_0x000180265d50(uVar8, uVar12, (int64_t)&arg_28h + iVar7 + iVar6, 
                                        (int64_t)&var_20h + iVar7 + iVar6);
                    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc747;
                    iVar5 = func_0x0001801dc860(iVar13, *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6));
                    iVar11 = iVar1 + 1;
                    if (0 < iVar5) {
                        iVar11 = iVar1;
                    }
                    iVar1 = iVar11;
                    uVar12 = uVar12 + 1;
                } while (uVar12 < *(uint64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc766;
            iVar5 = func_0x0001801dc490(iVar13);
            iVar11 = iVar1 + 1;
            if (iVar5 != 0) {
                iVar11 = iVar1;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc776;
            func_0x0001802454c0(uVar9);
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc77e;
            func_0x0001801dc5e0(iVar13);
            if (iVar11 == 0) {
                return 1;
            }
            goto code_r0x0001801bc787;
        }
        if (iVar14 == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5e4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5fc;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc61a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5a6;
    func_0x0001802454c0(0);
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + iVar6) = 0x1801bc5ad;
    func_0x0001801dc5e0(0);
code_r0x0001801bc787:
    if ((iVar14 != 0) && (iVar3 == 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bc7c0
// Address: 0x1801bc7c0
// Size: 31 bytes
// ============================================================
undefined8 fcn.1801bc7c0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc7cc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc7e9;
    uVar3 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc7f7;
    iVar1 = fcn.18022ff90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc803;
        fcn.18022ecc0(uVar3);
        return 0;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801bc7df
// Address: 0x1801bc7df
// Size: 49 bytes
// ============================================================
undefined8 fcn.1801bc7c0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc7cc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc7e9;
    uVar3 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc7f7;
    iVar1 = fcn.18022ff90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc803;
        fcn.18022ecc0(uVar3);
        return 0;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801bc810
// Address: 0x1801bc810
// Size: 14 bytes
// ============================================================
undefined8 fcn.1801bc7c0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc7cc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc7e9;
    uVar3 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc7f7;
    iVar1 = fcn.18022ff90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc803;
        fcn.18022ecc0(uVar3);
        return 0;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801bc830
// Address: 0x1801bc830
// Size: 67 bytes
// ============================================================
undefined8 fcn.1801bc830(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t *in_R8;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc83c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc850;
    iVar1 = fcn.18021d590(*(int64_t *)(&stack0x00000048 + iVar2));
    if (0 < iVar1) {
        if (in_R8 != (uint64_t *)0x0) {
            *in_R8 = (uint64_t)*(uint32_t *)((int64_t)&arg_28h + iVar2);
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bc880
// Address: 0x1801bc880
// Size: 26 bytes
// ============================================================
void fcn.1801bc880(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = *(undefined8 **)(param_1 + 8);
    if (puVar4 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x18021d410;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        uVar1 = puVar4[2];
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18021d41f;
        fcn.1802154a0(uVar1);
        uVar1 = puVar4[3];
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18021d428;
        fcn.1802154a0(uVar1);
        uVar1 = puVar4[1];
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18021d431;
        fcn.1802154a0(uVar1);
        uVar1 = puVar4[2];
        *puVar4 = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18021d441;
        fcn.180215310(uVar1);
        uVar1 = puVar4[3];
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18021d44a;
        fcn.180215310(uVar1);
        uVar1 = puVar4[1];
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18021d453;
        fcn.180215310(uVar1);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18021d468;
        fcn.180224990(puVar4, 0x1804be838, 0xc2);
    }
    return;
}

// ============================================================
// Function: FUN_1801bc8a0
// Address: 0x1801bc8a0
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801bc8a0(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc8b5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bc8ca;
    fcn.18022e160(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1));
    *(undefined8 *)((int64_t)&iStackX_20 + iVar1 + -8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bc8e4;
    fcn.18021d640(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8));
    return;
}

// ============================================================
// Function: FUN_1801bc900
// Address: 0x1801bc900
// Size: 43 bytes
// ============================================================
bool fcn.1801bc900(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc90c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1801bc917;
    iVar1 = fcn.18021d470();
    *(int64_t *)(param_1 + 8) = iVar1;
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1801bc930
// Address: 0x1801bc930
// Size: 26 bytes
// ============================================================
int64_t fcn.1801bc930(int64_t param_1)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    puVar5 = *(undefined8 **)(param_1 + 8);
    *(undefined8 *)((int64_t)&uStackX_20 + -iVar3) = 0x18021d97a;
    iVar4 = fcn.18045a350();
    uVar1 = *puVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + (-iVar3 - iVar4)) = 0x18021d985;
    iVar2 = fcn.18020f800(uVar1);
    if (iVar2 < 0) {
        iVar2 = 0;
    }
    return (int64_t)iVar2;
}

// ============================================================
// Function: FUN_1801bc950
// Address: 0x1801bc950
// Size: 26 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018025c50f: Changing call to branch
// WARNING: Possible PIC construction at 0x00018025cdcc: Changing call to branch

uint64_t fcn.1801bc950(int64_t arg_70h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_b0h,
                      int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h)
{
    uint32_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int64_t iVar9;
    int64_t *piVar10;
    undefined8 in_RDX;
    int32_t *unaff_RBX;
    undefined *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar6 = fcn.18045a350();
    piVar10 = *(int64_t **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStackX_20 + -iVar6) = 0x18021d94a;
    iVar8 = fcn.18045a350();
    if (*piVar10 == 0) {
        return 0;
    }
    iVar9 = piVar10[1];
    puVar11 = &stack0x00000050 + (-iVar6 - iVar8);
    while( true ) {
        *(undefined8 *)(puVar11 + -8) = 0x1802149ba;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        if (in_R8 == 0) {
            return 1;
        }
        if ((*(uint32_t *)(iVar9 + 0x18) >> 0xb & 1) != 0) break;
        puVar1 = *(uint32_t **)(iVar9 + 0x28);
        if (((puVar1 == (uint32_t *)0x0) || (uVar4 = *puVar1, (uVar4 & 0xc1f0) == 0)) ||
           (*(int64_t *)(puVar1 + 0xc) == 0)) {
            iVar8 = *(int64_t *)(iVar9 + 8);
            if (((iVar8 == 0) || (*(int64_t *)(iVar8 + 0x68) == 0)) || ((*(uint32_t *)(iVar9 + 0x18) >> 8 & 1) != 0)) {
                if (*(code **)(iVar9 + 0x30) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214abd. Too many branches
    // WARNING: Treating indirect jump as call
                    uVar7 = (**(code **)(iVar9 + 0x30))();
                    return uVar7;
                }
                return 0;
            }
            if (*(code **)(iVar8 + 0x88) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214aa6. Too many branches
    // WARNING: Treating indirect jump as call
                uVar7 = (**(code **)(iVar8 + 0x88))(*(undefined8 *)(iVar9 + 0x38), in_RDX);
                return uVar7;
            }
            *(undefined8 *)(puVar11 + iVar6 + -8) = 0x180214a8a;
            fcn.180229480(*(int64_t *)(puVar11 + iVar6 + 0x20), *(int64_t *)(puVar11 + iVar6 + 0x28));
            goto code_r0x0001802149eb;
        }
        if (uVar4 == 0x80) {
            *(int32_t **)(puVar11 + iVar6 + 0x38) = unaff_RBX;
            *(int64_t *)(puVar11 + iVar6 + 0x40) = unaff_RBP;
            *(int64_t *)(puVar11 + iVar6 + 0x48) = unaff_RSI;
            *(undefined8 *)(puVar11 + iVar6 + 0x20) = unaff_R14;
            *(undefined8 *)(puVar11 + iVar6 + 0x18) = 0x18025c35b;
            unaff_RBP = in_R8;
            iVar8 = fcn.18045a350();
            iVar8 = -iVar8;
            unaff_RBX = *(int32_t **)(iVar9 + 0x28);
            if ((*(uint32_t *)(iVar9 + 0x18) & 0x800) != 0) {
                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c379;
                fcn.180229480(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48)
                             );
                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c391;
                fcn.1802295a0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48)
                              , *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x50), 
                              *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x58), *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x70)
                             );
                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c3a3;
                fcn.1802296d0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60));
                return 0;
            }
            *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60) = unaff_RDI;
            if (unaff_RBX != (int32_t *)0x0) {
                if (((*unaff_RBX == 0x80) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
                   (unaff_RDI = *(int64_t *)(unaff_RBX + 10), unaff_RDI != 0)) {
                    iVar9 = 0x1805aadb1;
                    if (*(int64_t *)(unaff_RDI + 0x10) != 0) {
                        iVar9 = *(int64_t *)(unaff_RDI + 0x10);
                    }
                    if (*(int64_t *)(unaff_RDI + 0x98) != 0) {
                        *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c440;
                        fcn.180229b10();
                        pcVar2 = *(code **)(unaff_RDI + 0x98);
                        uVar3 = *(undefined8 *)(unaff_RBX + 0xc);
                        *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c453;
                        uVar4 = (*pcVar2)(uVar3, in_RDX, unaff_RBP);
                        if ((int32_t)uVar4 < 1) {
                            *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c45e;
                            iVar5 = fcn.180229970();
                            if (iVar5 == 0) {
                                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c467;
                                fcn.180229480(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                              *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48));
                                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c47f;
                                fcn.1802295a0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                              *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48), 
                                              *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x50), 
                                              *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x58), 
                                              *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x70));
                                *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40) = iVar9;
                                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c49e;
                                fcn.1802296d0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60));
                            }
                        }
                        *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c4a3;
                        fcn.180229900();
                        return (uint64_t)uVar4;
                    }
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c3fd;
                    fcn.180229480(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48));
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c415;
                    fcn.1802295a0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x50), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x58), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x70));
                    *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40) = iVar9;
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c434;
                    fcn.1802296d0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60));
                    return 0;
                }
                if (*(int64_t *)(unaff_RBX + 0x1e) == 0) {
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c4b5;
                    fcn.180229480(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48));
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c4cd;
                    fcn.1802295a0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x50), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x58), 
                                  *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x70));
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c4df;
                    fcn.1802296d0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60));
                    return 0;
                }
                if ((*(uint8_t *)(unaff_RBX + 0x28) & 1) != 0) {
                    pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8);
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025c4fb;
                    iVar5 = (*pcVar2)(unaff_RBX, iVar9);
                    if (iVar5 == 0) {
                        return 0;
                    }
                }
                unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
            }
            puVar12 = (undefined8 *)(puVar11 + iVar8 + iVar6 + 0x20 + -8);
            puVar11 = puVar11 + iVar8 + iVar6 + 0x20 + -8;
            *puVar12 = 0x18025c514;
            unaff_RSI = iVar9;
            in_R8 = unaff_RBP;
            unaff_R14 = in_RDX;
        } else {
            if (uVar4 != 0x100) {
                *(undefined8 *)(puVar11 + iVar6 + -8) = 0x180214a54;
                fcn.180229480(*(int64_t *)(puVar11 + iVar6 + 0x20), *(int64_t *)(puVar11 + iVar6 + 0x28));
                goto code_r0x0001802149eb;
            }
            *(int32_t **)(puVar11 + iVar6 + 0x38) = unaff_RBX;
            *(int64_t *)(puVar11 + iVar6 + 0x40) = unaff_RBP;
            *(int64_t *)(puVar11 + iVar6 + 0x48) = unaff_RSI;
            *(undefined8 *)(puVar11 + iVar6 + 0x20) = unaff_R14;
            *(undefined8 *)(puVar11 + iVar6 + 0x18) = 0x18025cc4b;
            unaff_RBP = in_R8;
            iVar8 = fcn.18045a350();
            iVar8 = -iVar8;
            unaff_RBX = *(int32_t **)(iVar9 + 0x28);
            if ((*(uint32_t *)(iVar9 + 0x18) & 0x800) != 0) {
                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cc69;
                fcn.180229480(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48)
                             );
                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cc81;
                fcn.1802295a0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48)
                              , *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x50), 
                              *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x58), *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x70)
                             );
                *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cc93;
                fcn.1802296d0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60));
                return 0;
            }
            *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60) = unaff_RDI;
            if (unaff_RBX != (int32_t *)0x0) {
                if (((*unaff_RBX == 0x100) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
                   (unaff_RDI = *(int64_t *)(unaff_RBX + 10), unaff_RDI != 0)) {
                    iVar9 = 0x1805aadb1;
                    if (*(int64_t *)(unaff_RDI + 0x10) != 0) {
                        iVar9 = *(int64_t *)(unaff_RDI + 0x10);
                    }
                    if (*(int64_t *)(unaff_RDI + 0xb8) == 0) {
                        *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cced;
                        fcn.180229480(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                      *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48));
                        *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd05;
                        fcn.1802295a0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                      *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48), 
                                      *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x50), 
                                      *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x58), 
                                      *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x70));
                        *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40) = iVar9;
                        *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd24;
                        fcn.1802296d0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60));
                        return 0;
                    }
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd30;
                    fcn.180229b10();
                    pcVar2 = *(code **)(unaff_RDI + 0xb8);
                    uVar3 = *(undefined8 *)(unaff_RBX + 0xc);
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd43;
                    uVar4 = (*pcVar2)(uVar3, in_RDX, unaff_RBP);
                    if ((int32_t)uVar4 < 1) {
                        *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd4e;
                        iVar5 = fcn.180229970();
                        if (iVar5 == 0) {
                            *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd57;
                            fcn.180229480(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                          *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48));
                            *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd6f;
                            fcn.1802295a0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40), 
                                          *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x48), 
                                          *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x50), 
                                          *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x58), 
                                          *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x70));
                            *(int64_t *)(puVar11 + iVar8 + iVar6 + 0x40) = iVar9;
                            *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd8e;
                            fcn.1802296d0(*(int64_t *)(puVar11 + iVar8 + iVar6 + 0x60));
                        }
                    }
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cd93;
                    fcn.180229900();
                    return (uint64_t)uVar4;
                }
                if ((*(uint8_t *)(unaff_RBX + 0x28) & 1) != 0) {
                    pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8);
                    *(undefined8 *)(puVar11 + iVar8 + iVar6 + 0x18) = 0x18025cdb4;
                    iVar5 = (*pcVar2)(unaff_RBX, iVar9);
                    if (iVar5 == 0) {
                        return 0;
                    }
                }
                unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
            }
            puVar13 = (undefined8 *)(puVar11 + iVar8 + iVar6 + 0x20 + -8);
            puVar11 = puVar11 + iVar8 + iVar6 + 0x20 + -8;
            *puVar13 = 0x18025cdd1;
            unaff_RSI = iVar9;
            in_R8 = unaff_RBP;
            unaff_R14 = in_RDX;
        }
    }
    *(undefined8 *)(puVar11 + iVar6 + -8) = 0x1802149df;
    fcn.180229480(*(int64_t *)(puVar11 + iVar6 + 0x20), *(int64_t *)(puVar11 + iVar6 + 0x28));
code_r0x0001802149eb:
    *(undefined8 *)(puVar11 + iVar6 + -8) = 0x1802149f7;
    fcn.1802295a0(*(int64_t *)(puVar11 + iVar6 + 0x20), *(int64_t *)(puVar11 + iVar6 + 0x28), 
                  *(int64_t *)(puVar11 + iVar6 + 0x30), *(int64_t *)(puVar11 + iVar6 + 0x38), 
                  *(int64_t *)(puVar11 + iVar6 + 0x50));
    *(undefined8 *)(puVar11 + iVar6 + -8) = 0x180214a09;
    fcn.1802296d0(*(int64_t *)(puVar11 + iVar6 + 0x40));
    return 0;
}

// ============================================================
// Function: FUN_1801bc970
// Address: 0x1801bc970
// Size: 209 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801bc970(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
             int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bc98a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc9a6;
    iVar3 = func_0x00018021eaf0(*(undefined8 *)((int64_t)&arg_88h + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc9b0;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc9c8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc9da;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bc9e6;
        iVar1 = func_0x000180266ad0(iVar3);
        *(int32_t *)((int64_t)&arg_38h + iVar2) = iVar1;
        if (iVar1 != 0) {
            *(undefined8 *)(&stack0x00000030 + iVar2) = 1;
            *(int64_t *)((int64_t)&arg_28h + iVar2) = (int64_t)&arg_38h + iVar2;
            *(undefined8 *)((int64_t)&var_20h + iVar2) = *(undefined8 *)((int64_t)&arg_80h + iVar2);
            *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)((int64_t)&arg_78h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bca2c;
            uVar4 = func_0x0001801abb30(in_RCX, in_RDX, in_R8, in_R9);
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bca50
// Address: 0x1801bca50
// Size: 22 bytes
// ============================================================
int32_t fcn.1801bca50(int64_t arg_38h, int64_t arg_58h)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x18026aef0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af17;
    iVar3 = fcn.180222950(*(undefined8 *)0x180782b60);
    if (iVar3 == 0) {
        return 0;
    }
    iVar3 = 1;
    piVar1 = (int32_t *)(in_RCX + 0xa0);
    *piVar1 = *piVar1 + -1;
    if ((*piVar1 == 0) && (*(int64_t *)(in_RCX + 0x68) != 0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af3f;
        fcn.180222910(*(undefined8 *)0x180782b60);
        pcVar2 = *(code **)(in_RCX + 0x68);
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af48;
        iVar3 = (*pcVar2)(in_RCX);
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af56;
        iVar4 = fcn.180222950(*(undefined8 *)0x180782b60);
        if ((iVar4 != 0) && (iVar3 != 0)) goto code_r0x00018026af5e;
    } else {
code_r0x00018026af5e:
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af68;
        iVar4 = fcn.18029b560(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026afb5;
            fcn.180222910(*(undefined8 *)0x180782b60);
            if (iVar3 != 0) {
                return iVar3;
            }
            goto code_r0x00018026afb9;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af71;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5), *(int64_t *)(&stack0x00000048 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af89;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5), *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000070 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026af9b;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026afa7;
    fcn.180222910(*(undefined8 *)0x180782b60);
code_r0x00018026afb9:
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026afbe;
    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5), *(int64_t *)(&stack0x00000048 + iVar6 + iVar5));
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026afd6;
    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5), *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)(&stack0x00000070 + iVar6 + iVar5));
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar5) = 0x18026afe8;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801bca70
// Address: 0x1801bca70
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801bca70(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bca8a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcaa6;
    fcn.1801a1020();
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcacd;
    fcn.18026aa00(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)((int64_t)&arg_48h + iVar1), *(int64_t *)((int64_t)&arg_58h + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1), 
                  *(int64_t *)(&stack0x00000070 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801bcaf0
// Address: 0x1801bcaf0
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801bcaf0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bcb00;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcb0a;
    iVar2 = fcn.18026abf0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1), 
                          *(int64_t *)(&stack0x00000068 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcb1c;
        uVar3 = fcn.18026ab80(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcb27;
        fcn.18026aee0(*(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bcb40
// Address: 0x1801bcb40
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801bcb40(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bcb50;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcb5a;
    iVar2 = fcn.18026ada0();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcb6c;
        uVar3 = fcn.18026ad30(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801bcb77;
        fcn.18026aee0(*(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bcb90
// Address: 0x1801bcb90
// Size: 33 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801a247b: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801a2480)
// WARNING: Removing unreachable block (ram,0x0001801a249e)
// WARNING: Removing unreachable block (ram,0x0001801a2484)
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.1801bcb90(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
                      int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h,
                      int64_t arg_100h, int64_t arg_108h, int64_t arg_118h, int64_t arg_150h, int64_t arg_1b8h)
{
    int32_t *piVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    bool bVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t **ppiVar16;
    int64_t *piVar17;
    undefined2 *puVar18;
    int64_t iVar19;
    int64_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    int64_t **ppiVar23;
    int64_t *piVar24;
    int64_t in_RCX;
    int64_t *piVar25;
    uint64_t uVar26;
    int64_t *in_RDX;
    int32_t iVar27;
    int64_t iVar28;
    undefined8 unaff_RBX;
    undefined *puVar29;
    undefined8 unaff_RBP;
    uint32_t uVar30;
    int64_t unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar31;
    uint64_t uVar32;
    undefined2 *puVar33;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    code *apcStackX_18 [2];
    
    iVar19 = fcn.18045a350();
    iVar19 = -iVar19;
    uVar11 = 0;
    iVar13 = 0x51;
    *(undefined8 *)((int64_t)&arg_30h + iVar19) = unaff_RBX;
    iVar21 = iVar19 + 0x20;
    iVar28 = iVar19 + 0x20;
    iVar14 = iVar19 + 0x20;
    iVar3 = iVar19 + 0x20;
    iVar6 = iVar19 + 0x20;
    iVar7 = iVar19 + 0x20;
    iVar8 = iVar19 + 0x20;
    iVar9 = iVar19 + 0x20;
    *(undefined8 *)((int64_t)apcStackX_18 + iVar19 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)apcStackX_18 + iVar19) = 0x1801c4680;
    iVar20 = fcn.18045a350();
    iVar20 = -iVar20;
    iVar10 = iVar20 + iVar19 + 0x20;
    // switch table (137 cases) at 0x1801c4de4
    switch(iVar13) {
    case 3:
        if (in_RDX == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46bc;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                          *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
            goto code_r0x0001801c46c8;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46fb;
        iVar21 = fcn.1801bc7c0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19));
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4732;
            iVar13 = fcn.180192b80(*(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19));
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4742;
                fcn.18022ecc0(iVar21);
                return 0;
            }
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4708;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4720;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 4:
        if (in_RDX != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_50h + iVar20 + iVar19) = in_RDX;
            *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19) = in_RCX + 0x2b0;
            *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19) = in_RCX + 0x2b8;
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c47ea;
            uVar22 = fcn.1801bc970(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_90h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_98h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_a0h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_a8h + iVar20 + iVar19));
            return uVar22;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c479b;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
code_r0x0001801c46c8:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46d4;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    default:
        goto code_r0x0001801c46e6;
    case 6:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4754;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c476c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0xe:
        iVar21 = *(int64_t *)(in_RCX + 0x110);
        if (iVar21 == 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cb3;
            iVar21 = fcn.180221f20();
            *(int64_t *)(in_RCX + 0x110) = iVar21;
            if (iVar21 != 0) goto code_r0x0001801c4ce6;
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cc4;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                          *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        } else {
code_r0x0001801c4ce6:
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cf1;
            iVar13 = fcn.180222110(iVar21, in_RDX);
            if (iVar13 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cfa;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                          *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cdc;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x36:
        *(int64_t **)(in_RCX + 0x238) = in_RDX;
        return 1;
    case 0x3a:
    case 0x3b:
        if (in_RDX == (int64_t *)0x0) {
            return 0x50;
        }
        if (uVar11 == 0x50) {
            if (iVar13 == 0x3b) {
                iVar13 = *(int32_t *)((int64_t)in_RDX + 4);
                iVar27 = *(int32_t *)(in_RDX + 1);
                iVar4 = *(int32_t *)((int64_t)in_RDX + 0xc);
                piVar1 = *(int32_t **)(in_RCX + 0x250);
                *(int32_t *)(in_RCX + 0x240) = *(int32_t *)in_RDX;
                *(int32_t *)(in_RCX + 0x244) = iVar13;
                *(int32_t *)(in_RCX + 0x248) = iVar27;
                *(int32_t *)(in_RCX + 0x24c) = iVar4;
                iVar13 = *(int32_t *)((int64_t)in_RDX + 0x14);
                iVar27 = *(int32_t *)(in_RDX + 3);
                iVar4 = *(int32_t *)((int64_t)in_RDX + 0x1c);
                *piVar1 = *(int32_t *)(in_RDX + 2);
                piVar1[1] = iVar13;
                piVar1[2] = iVar27;
                piVar1[3] = iVar4;
                iVar13 = *(int32_t *)((int64_t)in_RDX + 0x24);
                iVar27 = *(int32_t *)(in_RDX + 5);
                iVar4 = *(int32_t *)((int64_t)in_RDX + 0x2c);
                piVar1[4] = *(int32_t *)(in_RDX + 4);
                piVar1[5] = iVar13;
                piVar1[6] = iVar27;
                piVar1[7] = iVar4;
                iVar19 = *(int64_t *)(in_RCX + 0x250);
                iVar13 = *(int32_t *)((int64_t)in_RDX + 0x34);
                iVar27 = *(int32_t *)(in_RDX + 7);
                iVar4 = *(int32_t *)((int64_t)in_RDX + 0x3c);
                *(int32_t *)(iVar19 + 0x20) = *(int32_t *)(in_RDX + 6);
                *(int32_t *)(iVar19 + 0x24) = iVar13;
                *(int32_t *)(iVar19 + 0x28) = iVar27;
                *(int32_t *)(iVar19 + 0x2c) = iVar4;
                iVar13 = *(int32_t *)((int64_t)in_RDX + 0x44);
                iVar27 = *(int32_t *)(in_RDX + 9);
                iVar4 = *(int32_t *)((int64_t)in_RDX + 0x4c);
                *(int32_t *)(iVar19 + 0x30) = *(int32_t *)(in_RDX + 8);
                *(int32_t *)(iVar19 + 0x34) = iVar13;
                *(int32_t *)(iVar19 + 0x38) = iVar27;
                *(int32_t *)(iVar19 + 0x3c) = iVar4;
                return 1;
            }
            iVar13 = *(int32_t *)(in_RCX + 0x244);
            iVar27 = *(int32_t *)(in_RCX + 0x248);
            iVar4 = *(int32_t *)(in_RCX + 0x24c);
            *(int32_t *)in_RDX = *(int32_t *)(in_RCX + 0x240);
            *(int32_t *)((int64_t)in_RDX + 4) = iVar13;
            *(int32_t *)(in_RDX + 1) = iVar27;
            *(int32_t *)((int64_t)in_RDX + 0xc) = iVar4;
            piVar1 = *(int32_t **)(in_RCX + 0x250);
            iVar13 = piVar1[1];
            iVar27 = piVar1[2];
            iVar4 = piVar1[3];
            *(int32_t *)(in_RDX + 2) = *piVar1;
            *(int32_t *)((int64_t)in_RDX + 0x14) = iVar13;
            *(int32_t *)(in_RDX + 3) = iVar27;
            *(int32_t *)((int64_t)in_RDX + 0x1c) = iVar4;
            iVar13 = piVar1[5];
            iVar27 = piVar1[6];
            iVar4 = piVar1[7];
            *(int32_t *)(in_RDX + 4) = piVar1[4];
            *(int32_t *)((int64_t)in_RDX + 0x24) = iVar13;
            *(int32_t *)(in_RDX + 5) = iVar27;
            *(int32_t *)((int64_t)in_RDX + 0x2c) = iVar4;
            iVar19 = *(int64_t *)(in_RCX + 0x250);
            iVar13 = *(int32_t *)(iVar19 + 0x24);
            iVar27 = *(int32_t *)(iVar19 + 0x28);
            iVar4 = *(int32_t *)(iVar19 + 0x2c);
            *(int32_t *)(in_RDX + 6) = *(int32_t *)(iVar19 + 0x20);
            *(int32_t *)((int64_t)in_RDX + 0x34) = iVar13;
            *(int32_t *)(in_RDX + 7) = iVar27;
            *(int32_t *)((int64_t)in_RDX + 0x3c) = iVar4;
            iVar13 = *(int32_t *)(iVar19 + 0x34);
            iVar27 = *(int32_t *)(iVar19 + 0x38);
            iVar4 = *(int32_t *)(iVar19 + 0x3c);
            *(int32_t *)(in_RDX + 8) = *(int32_t *)(iVar19 + 0x30);
            *(int32_t *)((int64_t)in_RDX + 0x44) = iVar13;
            *(int32_t *)(in_RDX + 9) = iVar27;
            *(int32_t *)((int64_t)in_RDX + 0x4c) = iVar4;
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c482c;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4844;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x40:
        *(int64_t **)(in_RCX + 0x270) = in_RDX;
        return 1;
    case 0x41:
        *(uint32_t *)(in_RCX + 0x278) = uVar11;
        return 1;
    case 0x4e:
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(int64_t **)(in_RCX + 0x340) = in_RDX;
        return 1;
    case 0x4f:
        uVar15 = *(undefined8 *)(in_RCX + 0x360);
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c497e;
        fcn.180224990(uVar15, 0x1804b3080, 0x1013);
        *(undefined8 *)(in_RCX + 0x360) = 0;
        if (in_RDX == (int64_t *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c499a;
        uVar22 = fcn.180498cd0(in_RDX);
        if (uVar22 < 0x100) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49aa;
            iVar21 = fcn.180498cd0(in_RDX);
            if (iVar21 != 0) {
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49c5;
                iVar21 = fcn.1802231e0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                                       *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                                       *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19));
                *(int64_t *)(in_RCX + 0x360) = iVar21;
                if (iVar21 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49da;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                              *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
                goto code_r0x0001801c49df;
            }
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a01;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a19;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x50:
        *(uint32_t *)(in_RCX + 0x3b0) = uVar11;
        return 1;
    case 0x51:
        iVar21 = *(int64_t *)(in_RCX + 0x3a8);
        *(undefined8 *)(in_RCX + 0x358) = 0x1801c31f0;
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a4f;
            fcn.180224990(iVar21, 0x1804b3080, 0x1024);
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a64;
        iVar21 = fcn.1802231e0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19));
        *(int64_t *)(in_RCX + 0x3a8) = iVar21;
        if (iVar21 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a79;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
code_r0x0001801c49df:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x52:
        iVar19 = *(int64_t *)(in_RCX + 0x110);
        if ((iVar19 != 0) || (uVar11 != 0)) goto code_r0x0001801c4d20;
    case 0x73:
        iVar19 = *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x10);
code_r0x0001801c4d20:
        *in_RDX = iVar19;
        return 1;
    case 0x53:
        uVar15 = *(undefined8 *)(in_RCX + 0x110);
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4d3f;
        fcn.180238640(uVar15);
        *(undefined8 *)(in_RCX + 0x110) = 0;
        return 1;
    case 0x58:
        iVar21 = 0;
        if (uVar11 == 0) {
            piVar25 = *(int64_t **)((int64_t)&arg_70h + iVar20 + iVar19);
            iVar28 = *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19);
            puVar29 = (undefined *)((int64_t)&arg_68h + iVar20 + iVar19);
        } else {
            piVar25 = *(int64_t **)((int64_t)&arg_70h + iVar20 + iVar19);
            *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RSI;
            iVar28 = iVar20 + iVar6 + 0x40;
            *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
            *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a2440;
            iVar19 = fcn.18045a350();
            iVar19 = -iVar19;
            if (in_RDX == (int64_t *)0x0) {
                puVar29 = (undefined *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar6 + -0x20);
                unaff_RSI = *(int64_t *)((int64_t)&arg_98h + iVar19 + iVar20 + iVar6 + -0x20);
                iVar28 = *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar6 + -0x20);
                in_RDX = (int64_t *)0x0;
            } else {
                *(int64_t **)((int64_t)&arg_90h + iVar19 + iVar20 + iVar6 + -0x20) = piVar25;
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar6 + -0x20) = 0x1801a246a;
                piVar25 = (int64_t *)fcn.180238060(*(int64_t *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar6 + -0x20));
                if (piVar25 == (int64_t *)0x0) {
                    return 0;
                }
                puVar29 = (undefined *)((int64_t)&arg_58h + iVar19 + iVar28 + -0x60);
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar28 + -0x60) = 0x1801a2480;
                unaff_RSI = iVar21;
                iVar28 = in_RCX;
                in_RDX = piVar25;
            }
        }
        *(undefined8 *)(puVar29 + 0x20) = unaff_RBP;
        *(int64_t *)(puVar29 + -8) = unaff_RSI;
        *(int64_t *)(puVar29 + -0x10) = iVar28;
        *(undefined8 *)(puVar29 + -0x18) = unaff_R15;
        *(undefined8 *)(puVar29 + -0x20) = 0x1801a2333;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if (iVar21 == 0) {
            piVar24 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar24 = *(int64_t **)(iVar21 + 0x878);
        }
        iVar20 = *piVar24;
        if (iVar20 == 0) {
            return 0;
        }
        *(int64_t **)(puVar29 + iVar19 + 0x38) = piVar25;
        *(undefined8 *)(puVar29 + iVar19 + 0x40) = unaff_R12;
        iVar27 = 0;
        *(undefined8 *)(puVar29 + iVar19 + 0x48) = unaff_R14;
        *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2389;
        iVar13 = fcn.180222010(in_RDX);
        if (0 < iVar13) {
            do {
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a239a;
                fcn.180222340(in_RDX, iVar27);
                *(undefined4 *)(puVar29 + iVar19 + 8) = 0;
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23b0;
                iVar13 = fcn.1801a8d20(*(int64_t *)(puVar29 + iVar19 + 0x28), *(int64_t *)(puVar29 + iVar19 + 0x30), 
                                       *(int64_t *)(puVar29 + iVar19 + 0x40), *(int64_t *)(puVar29 + iVar19 + 0x48), 
                                       *(int64_t *)(puVar29 + iVar19 + 0xb8));
                if (iVar13 != 1) {
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)(puVar29 + iVar19 + 8), *(int64_t *)(puVar29 + iVar19 + 0x10));
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)(puVar29 + iVar19 + 8), *(int64_t *)(puVar29 + iVar19 + 0x10), 
                                  *(int64_t *)(puVar29 + iVar19 + 0x18), *(int64_t *)(puVar29 + iVar19 + 0x20), 
                                  *(int64_t *)(puVar29 + iVar19 + 0x38));
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(puVar29 + iVar19 + 0x28));
                    return 0;
                }
                iVar27 = iVar27 + 1;
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23c2;
                iVar13 = fcn.180222010(in_RDX);
            } while (iVar27 < iVar13);
        }
        uVar15 = *(undefined8 *)(iVar20 + 0x10);
        *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23cf;
        fcn.180238640(uVar15);
        *(int64_t **)(iVar20 + 0x10) = in_RDX;
        return 1;
    case 0x59:
        iVar21 = 0;
        if (uVar11 == 0) {
            uVar15 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
            *(undefined8 *)((int64_t)&arg_80h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
            *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a17c0;
            iVar19 = fcn.18045a350(0, in_RCX, in_RDX);
            iVar19 = -iVar19;
            if (iVar21 == 0) {
                piVar25 = *(int64_t **)(in_RCX + 0x158);
            } else {
                piVar25 = *(int64_t **)(iVar21 + 0x878);
            }
            *(undefined8 *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar28 + -0x20) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar28 + -0x20) = uVar15;
            iVar21 = *piVar25;
            if (iVar21 != 0) {
                *(undefined4 *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar28 + -0x20) = 0;
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a17fb;
                iVar13 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)((int64_t)&arg_b8h + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar28 + -0x20));
                if (iVar13 == 1) {
                    iVar14 = *(int64_t *)(iVar21 + 0x10);
                    if (iVar14 == 0) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1853;
                        iVar14 = fcn.180221f20();
                        *(int64_t *)(iVar21 + 0x10) = iVar14;
                        if (iVar14 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1867;
                    iVar13 = fcn.180222110(iVar14, in_RDX);
                    return (uint64_t)(iVar13 != 0);
                }
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1807;
                fcn.180229480(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar28 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a181f;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_98h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_b0h + iVar19 + iVar20 + iVar28 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a182e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar28 + -0x20));
            }
            return 0;
        }
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a1895;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a18a9;
        uVar22 = fcn.1802375f0(in_RDX);
        if ((int32_t)uVar22 == 0) {
            return uVar22;
        }
        *(undefined8 *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar14 + -0x20) = uVar15;
        if (iVar21 == 0) {
            piVar25 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar25 = *(int64_t **)(iVar21 + 0x878);
        }
        iVar21 = *piVar25;
        if (iVar21 != 0) {
            *(undefined4 *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar14 + -0x20) = 0;
            *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a18f8;
            iVar13 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_b8h + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar14 + -0x20));
            if (iVar13 == 1) {
                iVar28 = *(int64_t *)(iVar21 + 0x10);
                if (iVar28 == 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1958;
                    iVar28 = fcn.180221f20();
                    *(int64_t *)(iVar21 + 0x10) = iVar28;
                    if (iVar28 == 0) goto code_r0x0001801a192b;
                }
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a196c;
                iVar13 = fcn.180222110(iVar28, in_RDX);
                if (iVar13 != 0) {
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1904;
                fcn.180229480(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar14 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a191c;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_98h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_b0h + iVar19 + iVar20 + iVar14 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a192b;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar14 + -0x20));
            }
        }
code_r0x0001801a192b:
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1933;
        fcn.18021fe80(in_RDX);
        return 0;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19) = (int64_t)(int32_t)uVar11;
        *(int64_t **)((int64_t)&arg_50h + iVar20 + iVar19) = in_RDX;
        *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19) = in_RCX + 0x2b8;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4afe;
        uVar22 = fcn.1801abb30(*(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_68h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_88h + iVar20 + iVar19));
        return uVar22;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_58h + iVar20 + iVar19) = in_RDX;
        *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19) = in_RCX + 0x2b8;
        *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19) = in_RCX + 0x2a0;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4b4f;
        uVar22 = fcn.1801abdc0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_90h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b0h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b8h + iVar20 + iVar19));
        return uVar22;
    case 0x61:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 0;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar31 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        goto code_r0x0001801ac640;
    case 0x62:
        iVar13 = 0;
        goto code_r0x0001801c4bb0;
    case 0x65:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 1;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar31 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
code_r0x0001801ac640:
        uVar22 = (uint64_t)(int32_t)uVar11;
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = uVar15;
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = uVar31;
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_50h + iVar20 + iVar19) = unaff_R15;
        *(undefined8 *)((int64_t)&arg_48h + iVar20 + iVar19) = 0x1801ac65e;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if ((uVar22 & 1) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac697;
            puVar18 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar8 + -0x20));
            if (puVar18 != (undefined2 *)0x0) {
                uVar32 = 0;
                puVar33 = puVar18;
                if (uVar22 != 0) {
                    do {
                        iVar27 = *(int32_t *)in_RDX;
                        uVar26 = 0;
                        piVar1 = (int32_t *)((int64_t)in_RDX + 4);
                        in_RDX = in_RDX + 1;
                        iVar28 = 0x1804ae0e0;
                        do {
                            if ((*(int32_t *)(iVar28 + 0x14) == iVar27) && (*(int32_t *)(iVar28 + 0x1c) == *piVar1)) {
                                *puVar33 = *(undefined2 *)(iVar28 + 0x10);
                                puVar33 = puVar33 + 1;
                                break;
                            }
                            uVar26 = uVar26 + 1;
                            iVar28 = iVar28 + 0x48;
                        } while (uVar26 < 0x1f);
                        if (uVar26 == 0x1f) {
                            *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac744;
                            fcn.180224990(puVar18, 0x1804aeee0, 0xf47);
                            return 0;
                        }
                        uVar32 = uVar32 + 2;
                    } while (uVar32 < uVar22);
                }
                if (iVar13 == 0) {
                    uVar15 = *(undefined8 *)(iVar21 + 0x40);
                    *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac76e;
                    fcn.180224990(uVar15, 0x1804aeee0, 0xf3f);
                    *(undefined2 **)(iVar21 + 0x40) = puVar18;
                    *(uint64_t *)(iVar21 + 0x48) = uVar22 >> 1;
                    return 1;
                }
                uVar15 = *(undefined8 *)(iVar21 + 0x50);
                *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac720;
                fcn.180224990(uVar15, 0x1804aeee0, 0xf3b);
                *(undefined2 **)(iVar21 + 0x50) = puVar18;
                *(uint64_t *)(iVar21 + 0x58) = uVar22 >> 1;
                return 1;
            }
        }
        return 0;
    case 0x66:
        iVar13 = 1;
code_r0x0001801c4bb0:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        uVar15 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_48h + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_40h + iVar20 + iVar19) = 0x1801ac790;
        iVar28 = fcn.18045a350(in_RCX, iVar21, in_RDX);
        iVar28 = -iVar28;
        *(uint64_t *)((int64_t)&arg_108h + iVar28 + iVar20 + iVar9 + -0x20) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&arg_48h + iVar28 + iVar20 + iVar9 + -0x20;
        iVar19 = *(int64_t *)((int64_t)&arg_100h + iVar28 + iVar20 + iVar9 + -0x20);
        *(undefined8 *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar9 + -0x20) = 0;
        if (in_RCX != 0) {
            iVar19 = in_RCX;
        }
        *(int64_t *)((int64_t)&arg_100h + iVar28 + iVar20 + iVar9 + -0x20) = iVar19;
        *(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar9 + -0x20) =
             (int64_t)&arg_78h + iVar28 + iVar20 + iVar9 + -0x20;
        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac7f0;
        iVar27 = fcn.18024a850(*(int64_t *)((int64_t)&arg_70h + iVar28 + iVar20 + iVar9 + -0x20), 
                               *(int64_t *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar9 + -0x20), 
                               *(int64_t *)((int64_t)&arg_80h + iVar28 + iVar20 + iVar9 + -0x20), 
                               *(int64_t *)((int64_t)&arg_90h + iVar28 + iVar20 + iVar9 + -0x20));
        if (iVar27 != 0) {
            *(undefined8 *)((int64_t)&arg_118h + iVar28 + iVar20 + iVar9 + -0x20) = uVar15;
            iVar19 = *(int64_t *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar9 + -0x20);
            if (iVar19 == 0) {
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac80f;
                fcn.180229480(*(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)((int64_t)&arg_70h + iVar28 + iVar20 + iVar9 + -0x20));
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac827;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)((int64_t)&arg_70h + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)((int64_t)&arg_80h + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)((int64_t)&arg_98h + iVar28 + iVar20 + iVar9 + -0x20));
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac840;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_88h + iVar28 + iVar20 + iVar9 + -0x20));
            } else if (iVar21 != 0) {
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac86d;
                iVar14 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar9 + -0x20));
                if (iVar14 != 0) {
                    *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac886;
                    fcn.180498030(iVar14, (int64_t)&arg_80h + iVar28 + iVar20 + iVar9 + -0x20, iVar19 * 2);
                    if (iVar13 == 0) {
                        uVar15 = *(undefined8 *)(iVar21 + 0x40);
                        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac8ba;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf17);
                        *(int64_t *)(iVar21 + 0x40) = iVar14;
                        *(int64_t *)(iVar21 + 0x48) = iVar19;
                    } else {
                        uVar15 = *(undefined8 *)(iVar21 + 0x50);
                        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac8a1;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf13);
                        *(int64_t *)(iVar21 + 0x50) = iVar14;
                        *(int64_t *)(iVar21 + 0x58) = iVar19;
                    }
                }
            }
        }
        uVar22 = *(uint64_t *)((int64_t)&arg_108h + iVar28 + iVar20 + iVar9 + -0x20);
        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac8e1;
        uVar22 = fcn.180459870(uVar22 ^ (int64_t)&arg_48h + iVar28 + iVar20 + iVar9 + -0x20);
        return uVar22;
    case 0x68:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        uVar22 = (uint64_t)(int32_t)uVar11;
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19 + 0x20 + -0x20) =
             *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801c5915;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        uVar15 = *(undefined8 *)(iVar21 + 0x30);
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar10 + -0x20) = 0x1801c5937;
        fcn.180224990(uVar15, 0x1804b3080, 0x121c);
        *(undefined8 *)(iVar21 + 0x30) = 0;
        *(undefined8 *)(iVar21 + 0x38) = 0;
        if ((in_RDX != (int64_t *)0x0) && (uVar22 != 0)) {
            if (uVar22 < 0x100) {
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar10 + -0x20) = 0x1801c596c;
                iVar19 = fcn.180223170(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar10 + -0x20));
                *(int64_t *)(iVar21 + 0x30) = iVar19;
                if (iVar19 != 0) {
                    *(uint64_t *)(iVar21 + 0x38) = uVar22;
                    return 1;
                }
            }
            return 0;
        }
        return 1;
    case 0x69:
        iVar14 = 0;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar31 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19) = in_RCX;
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = uVar15;
        *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar20 + iVar19) = uVar31;
        *(undefined8 *)((int64_t)&arg_48h + iVar20 + iVar19) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_40h + iVar20 + iVar19) = unaff_R13;
        *(undefined8 *)(&stack0x00000038 + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_30h + iVar20 + iVar19) = unaff_R15;
        *(undefined8 *)(&stack0x00000028 + iVar20 + iVar19) = 0x1801a141f;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        iVar28 = 0;
        *(undefined8 *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20) = 0;
        if (iVar14 == 0) {
            ppiVar23 = *(int64_t ***)(in_RCX + 0x158);
        } else {
            ppiVar23 = *(int64_t ***)(iVar14 + 0x878);
            in_RCX = *(int64_t *)(iVar14 + 8);
        }
        piVar25 = *ppiVar23;
        *(int64_t **)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20) = piVar25;
        uVar32 = 0;
        uVar30 = 0;
        uVar22 = 0;
        *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20) = in_RCX;
        *(int64_t ***)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20) = ppiVar23;
        *(uint32_t *)((int64_t)&arg_d0h + iVar19 + iVar20 + iVar21 + -0x20) = uVar11 & 4;
        if (*piVar25 == 0) {
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a147d;
            fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1495;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14a7;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
            uVar22 = uVar32;
code_r0x0001801a1782:
            uVar32 = uVar22;
            if (*(int32_t *)((int64_t)&arg_d0h + iVar19 + iVar20 + iVar21 + -0x20) == 0) goto code_r0x0001801a1794;
        } else {
            if ((uVar11 & 4) == 0) {
                if ((uVar11 & 1) != 0) {
                    *(int64_t *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20) = piVar25[2];
                }
code_r0x0001801a1536:
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a154a;
                iVar28 = fcn.18024c080(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                if (iVar28 == 0) {
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1557;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a156f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1581;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                    uVar22 = uVar32;
                } else {
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a159c;
                    iVar13 = fcn.18024bbe0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                           *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                           *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20));
                    if (iVar13 == 0) {
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15a5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                        uVar22 = uVar32;
                    } else {
                        uVar2 = *(uint32_t *)((int64_t)ppiVar23 + 0x1c);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15e5;
                        fcn.18024c330(iVar28, uVar2 & 0x30000);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15ed;
                        iVar13 = fcn.18024c740(*(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar21 + -0x20));
                        if (iVar13 < 1) {
                            if ((uVar11 & 8) == 0) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16f2;
                                uVar12 = fcn.18024bbd0(iVar28);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16f9;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1711;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1718;
                                fcn.180250ec0(uVar12);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1731;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                                goto code_r0x0001801a1782;
                            }
                            if ((uVar11 & 0x10) != 0) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1606;
                                fcn.1802203d0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                            }
                            uVar30 = 2;
                        }
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1613;
                        iVar14 = fcn.18024b970(iVar28);
                        *(int64_t *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20) = iVar14;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1626;
                        uVar15 = fcn.1802222a0(*(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a162e;
                        fcn.18021fe80(uVar15);
                        if ((uVar11 & 2) != 0) {
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a163c;
                            iVar13 = fcn.180222010(iVar14);
                            if (0 < iVar13) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1648;
                                iVar13 = fcn.180222010(iVar14);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1653;
                                uVar15 = fcn.180222340(iVar14, iVar13 + -1);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a165b;
                                uVar11 = fcn.18023bbb0(uVar15);
                                if ((uVar11 >> 0xd & 1) != 0) {
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1669;
                                    uVar15 = fcn.180222020(iVar14);
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1671;
                                    fcn.18021fe80(uVar15);
                                }
                            }
                        }
                        iVar27 = 0;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a167b;
                        iVar13 = fcn.180222010(iVar14);
                        if (iVar13 < 1) {
                            iVar3 = piVar25[2];
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1774;
                            fcn.180238640(iVar3);
                            piVar25[2] = iVar14;
                            uVar22 = (uint64_t)uVar30;
                            if (uVar30 == 0) {
                                uVar22 = 1;
                            }
                        } else {
                            do {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a169d;
                                fcn.180222340(iVar14, iVar27);
                                *(undefined4 *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20) = 0;
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16b6;
                                uVar11 = fcn.1801a8d20(*(int64_t *)
                                                        ((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_88h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_90h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_100h + iVar19 + iVar20 + iVar21 + -0x20));
                                uVar22 = (uint64_t)uVar11;
                                if (uVar11 != 1) {
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1738;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1750;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a175f;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1767;
                                    fcn.180238640(iVar14);
                                    uVar22 = 0;
                                    goto code_r0x0001801a1782;
                                }
                                iVar27 = iVar27 + 1;
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16c7;
                                iVar13 = fcn.180222010(iVar14);
                            } while (iVar27 < iVar13);
                            iVar14 = *(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20);
                            uVar15 = *(undefined8 *)(iVar14 + 0x10);
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16d9;
                            fcn.180238640(uVar15);
                            *(undefined8 *)(iVar14 + 0x10) =
                                 *(undefined8 *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20);
                        }
                    }
                }
                goto code_r0x0001801a1782;
            }
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14b5;
            iVar14 = fcn.18021f3d0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
            if (iVar14 != 0) {
                iVar3 = piVar25[2];
                iVar27 = 0;
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14cc;
                iVar13 = fcn.180222010(iVar3);
                if (0 < iVar13) {
                    do {
                        iVar3 = piVar25[2];
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14db;
                        uVar15 = fcn.180222340(iVar3, iVar27);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14e6;
                        iVar13 = fcn.18021f070(iVar14, uVar15);
                        if (iVar13 == 0) goto code_r0x0001801a178c;
                        iVar3 = piVar25[2];
                        iVar27 = iVar27 + 1;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14f9;
                        iVar13 = fcn.180222010(iVar3);
                    } while (iVar27 < iVar13);
                }
                iVar3 = *piVar25;
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1508;
                iVar13 = fcn.18021f070(iVar14, iVar3);
                if (iVar13 != 0) {
                    ppiVar23 = *(int64_t ***)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20);
                    goto code_r0x0001801a1536;
                }
            }
        }
code_r0x0001801a178c:
        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1794;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar21 + -0x20));
code_r0x0001801a1794:
        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a179c;
        fcn.18024b910(iVar28);
        return uVar32;
    case 0x6a:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 0;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar31 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        goto code_r0x0001801a24c0;
    case 0x6b:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 1;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar31 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
code_r0x0001801a24c0:
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = uVar31;
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a24d5;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if ((uVar11 != 0) && (in_RDX != (int64_t *)0x0)) {
            *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801a24f3;
            uVar22 = fcn.18021f5b0(in_RDX);
            if ((int32_t)uVar22 == 0) {
                return uVar22;
            }
        }
        *(undefined8 *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar7 + -0x20) = uVar15;
        iVar28 = 0x70;
        if (iVar13 == 0) {
            iVar28 = 0x78;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801a2524;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)((int64_t)&arg_b0h + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)((int64_t)&arg_b8h + iVar19 + iVar20 + iVar7 + -0x20));
        *(int64_t **)(iVar28 + iVar21) = in_RDX;
        return 1;
    case 0x74:
        ppiVar23 = *(int64_t ***)(in_RCX + 0x158);
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_88h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a2280;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if (in_RDX != (int64_t *)0x0) {
            piVar25 = (int64_t *)0x0;
            if (ppiVar23[5] != (int64_t *)0x0) {
                ppiVar16 = (int64_t **)ppiVar23[4];
                piVar24 = piVar25;
                do {
                    if ((*ppiVar16 == in_RDX) && (ppiVar16[1] != (int64_t *)0x0)) {
                        *ppiVar23 = (int64_t *)ppiVar16;
                        return 1;
                    }
                    piVar24 = (int64_t *)((int64_t)piVar24 + 1);
                    ppiVar16 = ppiVar16 + 5;
                    piVar17 = piVar25;
                } while (piVar24 < ppiVar23[5]);
                do {
                    piVar24 = (int64_t *)((int64_t)ppiVar23[4] + (int64_t)piVar17);
                    if ((piVar24[1] != 0) && (*piVar24 != 0)) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar3 + -0x20) = 0x1801a22de;
                        iVar13 = fcn.180238200(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_c8h + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x00000178 + iVar19 + iVar20 + iVar3 + -0x20));
                        if (iVar13 == 0) {
                            *ppiVar23 = piVar24;
                            return 1;
                        }
                    }
                    piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                    piVar17 = piVar17 + 5;
                } while (piVar25 < ppiVar23[5]);
            }
        }
        return 0;
    case 0x75:
        ppiVar23 = *(int64_t ***)(in_RCX + 0x158);
        if (ppiVar23 != (int64_t **)0x0) {
            if (uVar11 == 1) {
                piVar24 = ppiVar23[5];
                piVar25 = (int64_t *)0x0;
                if (piVar24 != (int64_t *)0x0) {
code_r0x0001801a25ab:
                    piVar17 = ppiVar23[4] + (int64_t)piVar25 * 5;
                    while ((*piVar17 == 0 || (piVar17[1] == 0))) {
                        piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                        piVar17 = piVar17 + 5;
                        if (piVar24 <= piVar25) {
                            return 0;
                        }
                    }
                    *ppiVar23 = piVar17;
                    return 1;
                }
            } else if ((uVar11 == 2) &&
                      (piVar25 = (int64_t *)(((int64_t)*ppiVar23 - (int64_t)ppiVar23[4]) / 0x28 + 1),
                      piVar25 < ppiVar23[5])) {
                piVar24 = ppiVar23[5];
                goto code_r0x0001801a25ab;
            }
        }
        return 0;
    case 0x76:
        *(uint32_t *)(*(int64_t *)(in_RCX + 0x158) + 0x18) = uVar11;
        return 1;
    case 0x7f:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x278);
    case 0x80:
        *in_RDX = *(int64_t *)(in_RCX + 0x268);
        return 1;
    case 0x81:
        *in_RDX = *(int64_t *)(in_RCX + 0x270);
        return 1;
    case 0x89:
        iVar19 = *(int64_t *)(in_RCX + 0x158);
        bVar5 = false;
        goto code_r0x0001801a1fc0;
    case 0x8a:
        iVar19 = *(int64_t *)(in_RCX + 0x158);
        bVar5 = true;
code_r0x0001801a1fc0:
        iVar20 = 0x70;
        if (!bVar5) {
            iVar20 = 0x78;
        }
        *in_RDX = *(int64_t *)(iVar20 + iVar19);
        return 1;
    case 0x8b:
        *(int64_t **)((int64_t)&arg_48h + iVar20 + iVar19) = in_RDX;
        *(uint32_t *)((int64_t)&arg_40h + iVar20 + iVar19) = uVar11;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4b83;
        uVar22 = fcn.1801ab100(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_68h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b0h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b8h + iVar20 + iVar19));
        return uVar22;
    }
    *(code **)((int64_t)apcStackX_18 + iVar20 + iVar19) = case.0x1801c46af.5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19));
code_r0x0001801c46e6:
    return 0;
}

// ============================================================
// Function: FUN_1801bcbc0
// Address: 0x1801bcbc0
// Size: 33 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801a247b: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801a2480)
// WARNING: Removing unreachable block (ram,0x0001801a249e)
// WARNING: Removing unreachable block (ram,0x0001801a2484)
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.1801bcbc0(int64_t param_1, int64_t *param_2)
{
    int32_t *piVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    bool bVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t **ppiVar16;
    int64_t *piVar17;
    undefined2 *puVar18;
    int64_t iVar19;
    int64_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    int64_t **ppiVar23;
    int64_t *piVar24;
    int64_t *piVar25;
    uint64_t uVar26;
    int32_t iVar27;
    int64_t iVar28;
    undefined8 unaff_RBX;
    undefined *puVar29;
    undefined8 unaff_RBP;
    uint32_t uVar30;
    int64_t unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar31;
    uint64_t uVar32;
    undefined2 *puVar33;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    code *apcStackX_18 [2];
    
    iVar19 = fcn.18045a350();
    iVar19 = -iVar19;
    uVar11 = 0;
    iVar13 = 0x4f;
    *(undefined8 *)(&stack0x00000030 + iVar19) = unaff_RBX;
    iVar21 = iVar19 + 0x20;
    iVar28 = iVar19 + 0x20;
    iVar14 = iVar19 + 0x20;
    iVar3 = iVar19 + 0x20;
    iVar6 = iVar19 + 0x20;
    iVar7 = iVar19 + 0x20;
    iVar8 = iVar19 + 0x20;
    iVar9 = iVar19 + 0x20;
    *(undefined8 *)((int64_t)apcStackX_18 + iVar19 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)apcStackX_18 + iVar19) = 0x1801c4680;
    iVar20 = fcn.18045a350();
    iVar20 = -iVar20;
    iVar10 = iVar20 + iVar19 + 0x20;
    switch(iVar13) {
    case 3:
        if (param_2 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46bc;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                          *(int64_t *)(&stack0x00000048 + iVar20 + iVar19));
            goto code_r0x0001801c46c8;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46fb;
        iVar21 = fcn.1801bc7c0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19));
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4732;
            iVar13 = fcn.180192b80(*(int64_t *)(&stack0x00000050 + iVar20 + iVar19));
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4742;
                fcn.18022ecc0(iVar21);
                return 0;
            }
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4708;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                     );
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4720;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                      , *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                      *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), *(int64_t *)(&stack0x00000070 + iVar20 + iVar19)
                     );
        break;
    case 4:
        if (param_2 != (int64_t *)0x0) {
            *(int64_t **)(&stack0x00000050 + iVar20 + iVar19) = param_2;
            *(int64_t *)(&stack0x00000048 + iVar20 + iVar19) = param_1 + 0x2b0;
            *(int64_t *)(&stack0x00000040 + iVar20 + iVar19) = param_1 + 0x2b8;
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c47ea;
            uVar22 = fcn.1801bc970(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x00000070 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x00000078 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x00000080 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x00000090 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x00000098 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x000000a0 + iVar20 + iVar19), 
                                   *(int64_t *)(&stack0x000000a8 + iVar20 + iVar19));
            return uVar22;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c479b;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                     );
code_r0x0001801c46c8:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46d4;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                      , *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                      *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), *(int64_t *)(&stack0x00000070 + iVar20 + iVar19)
                     );
        break;
    default:
        goto code_r0x0001801c46e6;
    case 6:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4754;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                     );
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c476c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                      , *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                      *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), *(int64_t *)(&stack0x00000070 + iVar20 + iVar19)
                     );
        break;
    case 0xe:
        iVar21 = *(int64_t *)(param_1 + 0x110);
        if (iVar21 == 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cb3;
            iVar21 = fcn.180221f20();
            *(int64_t *)(param_1 + 0x110) = iVar21;
            if (iVar21 != 0) goto code_r0x0001801c4ce6;
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cc4;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                          *(int64_t *)(&stack0x00000048 + iVar20 + iVar19));
        } else {
code_r0x0001801c4ce6:
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cf1;
            iVar13 = fcn.180222110(iVar21, param_2);
            if (iVar13 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cfa;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                          *(int64_t *)(&stack0x00000048 + iVar20 + iVar19));
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cdc;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                      , *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                      *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), *(int64_t *)(&stack0x00000070 + iVar20 + iVar19)
                     );
        break;
    case 0x36:
        *(int64_t **)(param_1 + 0x238) = param_2;
        return 1;
    case 0x3a:
    case 0x3b:
        if (param_2 == (int64_t *)0x0) {
            return 0x50;
        }
        if (uVar11 == 0x50) {
            if (iVar13 == 0x3b) {
                iVar13 = *(int32_t *)((int64_t)param_2 + 4);
                iVar27 = *(int32_t *)(param_2 + 1);
                iVar4 = *(int32_t *)((int64_t)param_2 + 0xc);
                piVar1 = *(int32_t **)(param_1 + 0x250);
                *(int32_t *)(param_1 + 0x240) = *(int32_t *)param_2;
                *(int32_t *)(param_1 + 0x244) = iVar13;
                *(int32_t *)(param_1 + 0x248) = iVar27;
                *(int32_t *)(param_1 + 0x24c) = iVar4;
                iVar13 = *(int32_t *)((int64_t)param_2 + 0x14);
                iVar27 = *(int32_t *)(param_2 + 3);
                iVar4 = *(int32_t *)((int64_t)param_2 + 0x1c);
                *piVar1 = *(int32_t *)(param_2 + 2);
                piVar1[1] = iVar13;
                piVar1[2] = iVar27;
                piVar1[3] = iVar4;
                iVar13 = *(int32_t *)((int64_t)param_2 + 0x24);
                iVar27 = *(int32_t *)(param_2 + 5);
                iVar4 = *(int32_t *)((int64_t)param_2 + 0x2c);
                piVar1[4] = *(int32_t *)(param_2 + 4);
                piVar1[5] = iVar13;
                piVar1[6] = iVar27;
                piVar1[7] = iVar4;
                iVar19 = *(int64_t *)(param_1 + 0x250);
                iVar13 = *(int32_t *)((int64_t)param_2 + 0x34);
                iVar27 = *(int32_t *)(param_2 + 7);
                iVar4 = *(int32_t *)((int64_t)param_2 + 0x3c);
                *(int32_t *)(iVar19 + 0x20) = *(int32_t *)(param_2 + 6);
                *(int32_t *)(iVar19 + 0x24) = iVar13;
                *(int32_t *)(iVar19 + 0x28) = iVar27;
                *(int32_t *)(iVar19 + 0x2c) = iVar4;
                iVar13 = *(int32_t *)((int64_t)param_2 + 0x44);
                iVar27 = *(int32_t *)(param_2 + 9);
                iVar4 = *(int32_t *)((int64_t)param_2 + 0x4c);
                *(int32_t *)(iVar19 + 0x30) = *(int32_t *)(param_2 + 8);
                *(int32_t *)(iVar19 + 0x34) = iVar13;
                *(int32_t *)(iVar19 + 0x38) = iVar27;
                *(int32_t *)(iVar19 + 0x3c) = iVar4;
                return 1;
            }
            iVar13 = *(int32_t *)(param_1 + 0x244);
            iVar27 = *(int32_t *)(param_1 + 0x248);
            iVar4 = *(int32_t *)(param_1 + 0x24c);
            *(int32_t *)param_2 = *(int32_t *)(param_1 + 0x240);
            *(int32_t *)((int64_t)param_2 + 4) = iVar13;
            *(int32_t *)(param_2 + 1) = iVar27;
            *(int32_t *)((int64_t)param_2 + 0xc) = iVar4;
            piVar1 = *(int32_t **)(param_1 + 0x250);
            iVar13 = piVar1[1];
            iVar27 = piVar1[2];
            iVar4 = piVar1[3];
            *(int32_t *)(param_2 + 2) = *piVar1;
            *(int32_t *)((int64_t)param_2 + 0x14) = iVar13;
            *(int32_t *)(param_2 + 3) = iVar27;
            *(int32_t *)((int64_t)param_2 + 0x1c) = iVar4;
            iVar13 = piVar1[5];
            iVar27 = piVar1[6];
            iVar4 = piVar1[7];
            *(int32_t *)(param_2 + 4) = piVar1[4];
            *(int32_t *)((int64_t)param_2 + 0x24) = iVar13;
            *(int32_t *)(param_2 + 5) = iVar27;
            *(int32_t *)((int64_t)param_2 + 0x2c) = iVar4;
            iVar19 = *(int64_t *)(param_1 + 0x250);
            iVar13 = *(int32_t *)(iVar19 + 0x24);
            iVar27 = *(int32_t *)(iVar19 + 0x28);
            iVar4 = *(int32_t *)(iVar19 + 0x2c);
            *(int32_t *)(param_2 + 6) = *(int32_t *)(iVar19 + 0x20);
            *(int32_t *)((int64_t)param_2 + 0x34) = iVar13;
            *(int32_t *)(param_2 + 7) = iVar27;
            *(int32_t *)((int64_t)param_2 + 0x3c) = iVar4;
            iVar13 = *(int32_t *)(iVar19 + 0x34);
            iVar27 = *(int32_t *)(iVar19 + 0x38);
            iVar4 = *(int32_t *)(iVar19 + 0x3c);
            *(int32_t *)(param_2 + 8) = *(int32_t *)(iVar19 + 0x30);
            *(int32_t *)((int64_t)param_2 + 0x44) = iVar13;
            *(int32_t *)(param_2 + 9) = iVar27;
            *(int32_t *)((int64_t)param_2 + 0x4c) = iVar4;
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c482c;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                     );
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4844;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                      , *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                      *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), *(int64_t *)(&stack0x00000070 + iVar20 + iVar19)
                     );
        break;
    case 0x40:
        *(int64_t **)(param_1 + 0x270) = param_2;
        return 1;
    case 0x41:
        *(uint32_t *)(param_1 + 0x278) = uVar11;
        return 1;
    case 0x4e:
        *(uint32_t *)(param_1 + 0x3b4) = *(uint32_t *)(param_1 + 0x3b4) | 0x20;
        *(int64_t **)(param_1 + 0x340) = param_2;
        return 1;
    case 0x4f:
        uVar15 = *(undefined8 *)(param_1 + 0x360);
        *(uint32_t *)(param_1 + 0x3b4) = *(uint32_t *)(param_1 + 0x3b4) | 0x20;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c497e;
        fcn.180224990(uVar15, 0x1804b3080, 0x1013);
        *(undefined8 *)(param_1 + 0x360) = 0;
        if (param_2 == (int64_t *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c499a;
        uVar22 = fcn.180498cd0(param_2);
        if (uVar22 < 0x100) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49aa;
            iVar21 = fcn.180498cd0(param_2);
            if (iVar21 != 0) {
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49c5;
                iVar21 = fcn.1802231e0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                                       *(int64_t *)(&stack0x00000048 + iVar20 + iVar19), 
                                       *(int64_t *)(&stack0x00000050 + iVar20 + iVar19));
                *(int64_t *)(param_1 + 0x360) = iVar21;
                if (iVar21 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49da;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                              *(int64_t *)(&stack0x00000048 + iVar20 + iVar19));
                goto code_r0x0001801c49df;
            }
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a01;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                     );
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a19;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                      , *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                      *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), *(int64_t *)(&stack0x00000070 + iVar20 + iVar19)
                     );
        break;
    case 0x50:
        *(uint32_t *)(param_1 + 0x3b0) = uVar11;
        return 1;
    case 0x51:
        iVar21 = *(int64_t *)(param_1 + 0x3a8);
        *(undefined8 *)(param_1 + 0x358) = 0x1801c31f0;
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a4f;
            fcn.180224990(iVar21, 0x1804b3080, 0x1024);
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a64;
        iVar21 = fcn.1802231e0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000048 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000050 + iVar20 + iVar19));
        *(int64_t *)(param_1 + 0x3a8) = iVar21;
        if (iVar21 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a79;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                     );
code_r0x0001801c49df:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49f2;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), *(int64_t *)(&stack0x00000048 + iVar20 + iVar19)
                      , *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                      *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), *(int64_t *)(&stack0x00000070 + iVar20 + iVar19)
                     );
        break;
    case 0x52:
        iVar19 = *(int64_t *)(param_1 + 0x110);
        if ((iVar19 != 0) || (uVar11 != 0)) goto code_r0x0001801c4d20;
    case 0x73:
        iVar19 = *(int64_t *)(**(int64_t **)(param_1 + 0x158) + 0x10);
code_r0x0001801c4d20:
        *param_2 = iVar19;
        return 1;
    case 0x53:
        uVar15 = *(undefined8 *)(param_1 + 0x110);
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4d3f;
        fcn.180238640(uVar15);
        *(undefined8 *)(param_1 + 0x110) = 0;
        return 1;
    case 0x58:
        iVar21 = 0;
        if (uVar11 == 0) {
            piVar25 = *(int64_t **)(&stack0x00000070 + iVar20 + iVar19);
            iVar28 = *(int64_t *)(&stack0x00000060 + iVar20 + iVar19);
            puVar29 = &stack0x00000068 + iVar20 + iVar19;
        } else {
            piVar25 = *(int64_t **)(&stack0x00000070 + iVar20 + iVar19);
            *(int64_t *)(&stack0x00000078 + iVar20 + iVar19) = unaff_RSI;
            iVar28 = iVar20 + iVar6 + 0x40;
            *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19) = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
            *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = 0x1801a2440;
            iVar19 = fcn.18045a350();
            iVar19 = -iVar19;
            if (param_2 == (int64_t *)0x0) {
                puVar29 = &stack0x00000088 + iVar19 + iVar20 + iVar6 + -0x20;
                unaff_RSI = *(int64_t *)(&stack0x00000098 + iVar19 + iVar20 + iVar6 + -0x20);
                iVar28 = *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar6 + -0x20);
                param_2 = (int64_t *)0x0;
            } else {
                *(int64_t **)(&stack0x00000090 + iVar19 + iVar20 + iVar6 + -0x20) = piVar25;
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar6 + -0x20) = 0x1801a246a;
                piVar25 = (int64_t *)fcn.180238060(*(int64_t *)(&stack0x000000a8 + iVar19 + iVar20 + iVar6 + -0x20));
                if (piVar25 == (int64_t *)0x0) {
                    return 0;
                }
                puVar29 = &stack0x00000058 + iVar19 + iVar28 + -0x60;
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar28 + -0x60) = 0x1801a2480;
                unaff_RSI = iVar21;
                iVar28 = param_1;
                param_2 = piVar25;
            }
        }
        *(undefined8 *)(puVar29 + 0x20) = unaff_RBP;
        *(int64_t *)(puVar29 + -8) = unaff_RSI;
        *(int64_t *)(puVar29 + -0x10) = iVar28;
        *(undefined8 *)(puVar29 + -0x18) = unaff_R15;
        *(undefined8 *)(puVar29 + -0x20) = 0x1801a2333;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if (iVar21 == 0) {
            piVar24 = *(int64_t **)(param_1 + 0x158);
        } else {
            piVar24 = *(int64_t **)(iVar21 + 0x878);
        }
        iVar20 = *piVar24;
        if (iVar20 == 0) {
            return 0;
        }
        *(int64_t **)(puVar29 + iVar19 + 0x38) = piVar25;
        *(undefined8 *)(puVar29 + iVar19 + 0x40) = unaff_R12;
        iVar27 = 0;
        *(undefined8 *)(puVar29 + iVar19 + 0x48) = unaff_R14;
        *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2389;
        iVar13 = fcn.180222010(param_2);
        if (0 < iVar13) {
            do {
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a239a;
                fcn.180222340(param_2, iVar27);
                *(undefined4 *)(puVar29 + iVar19 + 8) = 0;
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23b0;
                iVar13 = fcn.1801a8d20(*(int64_t *)(puVar29 + iVar19 + 0x28), *(int64_t *)(puVar29 + iVar19 + 0x30), 
                                       *(int64_t *)(puVar29 + iVar19 + 0x40), *(int64_t *)(puVar29 + iVar19 + 0x48), 
                                       *(int64_t *)(puVar29 + iVar19 + 0xb8));
                if (iVar13 != 1) {
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)(puVar29 + iVar19 + 8), *(int64_t *)(puVar29 + iVar19 + 0x10));
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)(puVar29 + iVar19 + 8), *(int64_t *)(puVar29 + iVar19 + 0x10), 
                                  *(int64_t *)(puVar29 + iVar19 + 0x18), *(int64_t *)(puVar29 + iVar19 + 0x20), 
                                  *(int64_t *)(puVar29 + iVar19 + 0x38));
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(puVar29 + iVar19 + 0x28));
                    return 0;
                }
                iVar27 = iVar27 + 1;
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23c2;
                iVar13 = fcn.180222010(param_2);
            } while (iVar27 < iVar13);
        }
        uVar15 = *(undefined8 *)(iVar20 + 0x10);
        *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23cf;
        fcn.180238640(uVar15);
        *(int64_t **)(iVar20 + 0x10) = param_2;
        return 1;
    case 0x59:
        iVar21 = 0;
        if (uVar11 == 0) {
            uVar15 = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
            *(undefined8 *)(&stack0x00000080 + iVar20 + iVar19) = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
            *(int64_t *)(&stack0x00000060 + iVar20 + iVar19) = unaff_RSI;
            *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = 0x1801a17c0;
            iVar19 = fcn.18045a350(0, param_1, param_2);
            iVar19 = -iVar19;
            if (iVar21 == 0) {
                piVar25 = *(int64_t **)(param_1 + 0x158);
            } else {
                piVar25 = *(int64_t **)(iVar21 + 0x878);
            }
            *(undefined8 *)(&stack0x000000a0 + iVar19 + iVar20 + iVar28 + -0x20) = unaff_RBP;
            *(undefined8 *)(&stack0x000000a8 + iVar19 + iVar20 + iVar28 + -0x20) = uVar15;
            iVar21 = *piVar25;
            if (iVar21 != 0) {
                *(undefined4 *)(&stack0x00000080 + iVar19 + iVar20 + iVar28 + -0x20) = 0;
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a17fb;
                iVar13 = fcn.1801a8d20(*(int64_t *)(&stack0x000000a0 + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x000000a8 + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x000000b8 + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar28 + -0x20));
                if (iVar13 == 1) {
                    iVar14 = *(int64_t *)(iVar21 + 0x10);
                    if (iVar14 == 0) {
                        *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1853;
                        iVar14 = fcn.180221f20();
                        *(int64_t *)(iVar21 + 0x10) = iVar14;
                        if (iVar14 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1867;
                    iVar13 = fcn.180222110(iVar14, param_2);
                    return (uint64_t)(iVar13 != 0);
                }
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1807;
                fcn.180229480(*(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar28 + -0x20));
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a181f;
                fcn.1802295a0(*(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)(&stack0x00000098 + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)(&stack0x000000b0 + iVar19 + iVar20 + iVar28 + -0x20));
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a182e;
                fcn.1802296d0(*(int64_t *)(&stack0x000000a0 + iVar19 + iVar20 + iVar28 + -0x20));
            }
            return 0;
        }
        uVar15 = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        *(undefined8 *)(&stack0x00000078 + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)(&stack0x00000080 + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19) = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
        *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = 0x1801a1895;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a18a9;
        uVar22 = fcn.1802375f0(param_2);
        if ((int32_t)uVar22 == 0) {
            return uVar22;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar19 + iVar20 + iVar14 + -0x20) = uVar15;
        if (iVar21 == 0) {
            piVar25 = *(int64_t **)(param_1 + 0x158);
        } else {
            piVar25 = *(int64_t **)(iVar21 + 0x878);
        }
        iVar21 = *piVar25;
        if (iVar21 != 0) {
            *(undefined4 *)(&stack0x00000080 + iVar19 + iVar20 + iVar14 + -0x20) = 0;
            *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a18f8;
            iVar13 = fcn.1801a8d20(*(int64_t *)(&stack0x000000a0 + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x000000a8 + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x000000b8 + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar14 + -0x20));
            if (iVar13 == 1) {
                iVar28 = *(int64_t *)(iVar21 + 0x10);
                if (iVar28 == 0) {
                    *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1958;
                    iVar28 = fcn.180221f20();
                    *(int64_t *)(iVar21 + 0x10) = iVar28;
                    if (iVar28 == 0) goto code_r0x0001801a192b;
                }
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a196c;
                iVar13 = fcn.180222110(iVar28, param_2);
                if (iVar13 != 0) {
                    return 1;
                }
            } else {
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1904;
                fcn.180229480(*(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar14 + -0x20));
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a191c;
                fcn.1802295a0(*(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)(&stack0x00000098 + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)(&stack0x000000b0 + iVar19 + iVar20 + iVar14 + -0x20));
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a192b;
                fcn.1802296d0(*(int64_t *)(&stack0x000000a0 + iVar19 + iVar20 + iVar14 + -0x20));
            }
        }
code_r0x0001801a192b:
        *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1933;
        fcn.18021fe80(param_2);
        return 0;
    case 0x5b:
        *(int64_t *)(&stack0x00000058 + iVar20 + iVar19) = (int64_t)(int32_t)uVar11;
        *(int64_t **)(&stack0x00000050 + iVar20 + iVar19) = param_2;
        *(int64_t *)(&stack0x00000048 + iVar20 + iVar19) = param_1 + 0x2b0;
        *(int64_t *)(&stack0x00000040 + iVar20 + iVar19) = param_1 + 0x2b8;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4afe;
        uVar22 = fcn.1801abb30(*(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000060 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000068 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000070 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000078 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000080 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000088 + iVar20 + iVar19));
        return uVar22;
    case 0x5c:
        *(int64_t **)(&stack0x00000058 + iVar20 + iVar19) = param_2;
        *(int64_t *)(&stack0x00000050 + iVar20 + iVar19) = param_1 + 0x2b0;
        *(int64_t *)(&stack0x00000048 + iVar20 + iVar19) = param_1 + 0x2b8;
        *(int64_t *)(&stack0x00000040 + iVar20 + iVar19) = param_1 + 0x2a0;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4b4f;
        uVar22 = fcn.1801abdc0(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000048 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000090 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x000000b0 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x000000b8 + iVar20 + iVar19));
        return uVar22;
    case 0x61:
        iVar21 = *(int64_t *)(param_1 + 0x158);
        iVar13 = 0;
        uVar15 = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        uVar31 = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
        goto code_r0x0001801ac640;
    case 0x62:
        iVar13 = 0;
        goto code_r0x0001801c4bb0;
    case 0x65:
        iVar21 = *(int64_t *)(param_1 + 0x158);
        iVar13 = 1;
        uVar15 = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        uVar31 = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
code_r0x0001801ac640:
        uVar22 = (uint64_t)(int32_t)uVar11;
        *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19) = uVar15;
        *(undefined8 *)(&stack0x00000078 + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)(&stack0x00000080 + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19) = uVar31;
        *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)(&stack0x00000050 + iVar20 + iVar19) = unaff_R15;
        *(undefined8 *)(&stack0x00000048 + iVar20 + iVar19) = 0x1801ac65e;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if ((uVar22 & 1) == 0) {
            *(undefined8 *)(&stack0x00000048 + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac697;
            puVar18 = (undefined2 *)fcn.180224ed0(*(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar8 + -0x20));
            if (puVar18 != (undefined2 *)0x0) {
                uVar32 = 0;
                puVar33 = puVar18;
                if (uVar22 != 0) {
                    do {
                        iVar27 = *(int32_t *)param_2;
                        uVar26 = 0;
                        piVar1 = (int32_t *)((int64_t)param_2 + 4);
                        param_2 = param_2 + 1;
                        iVar28 = 0x1804ae0e0;
                        do {
                            if ((*(int32_t *)(iVar28 + 0x14) == iVar27) && (*(int32_t *)(iVar28 + 0x1c) == *piVar1)) {
                                *puVar33 = *(undefined2 *)(iVar28 + 0x10);
                                puVar33 = puVar33 + 1;
                                break;
                            }
                            uVar26 = uVar26 + 1;
                            iVar28 = iVar28 + 0x48;
                        } while (uVar26 < 0x1f);
                        if (uVar26 == 0x1f) {
                            *(undefined8 *)(&stack0x00000048 + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac744;
                            fcn.180224990(puVar18, 0x1804aeee0, 0xf47);
                            return 0;
                        }
                        uVar32 = uVar32 + 2;
                    } while (uVar32 < uVar22);
                }
                if (iVar13 == 0) {
                    uVar15 = *(undefined8 *)(iVar21 + 0x40);
                    *(undefined8 *)(&stack0x00000048 + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac76e;
                    fcn.180224990(uVar15, 0x1804aeee0, 0xf3f);
                    *(undefined2 **)(iVar21 + 0x40) = puVar18;
                    *(uint64_t *)(iVar21 + 0x48) = uVar22 >> 1;
                    return 1;
                }
                uVar15 = *(undefined8 *)(iVar21 + 0x50);
                *(undefined8 *)(&stack0x00000048 + iVar19 + iVar20 + iVar8 + -0x20) = 0x1801ac720;
                fcn.180224990(uVar15, 0x1804aeee0, 0xf3b);
                *(undefined2 **)(iVar21 + 0x50) = puVar18;
                *(uint64_t *)(iVar21 + 0x58) = uVar22 >> 1;
                return 1;
            }
        }
        return 0;
    case 0x66:
        iVar13 = 1;
code_r0x0001801c4bb0:
        iVar21 = *(int64_t *)(param_1 + 0x158);
        uVar15 = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
        *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19) = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)(&stack0x00000050 + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)(&stack0x00000048 + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)(&stack0x00000040 + iVar20 + iVar19) = 0x1801ac790;
        iVar28 = fcn.18045a350(param_1, iVar21, param_2);
        iVar28 = -iVar28;
        *(uint64_t *)(&stack0x00000108 + iVar28 + iVar20 + iVar9 + -0x20) =
             *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000048 + iVar28 + iVar20 + iVar9 + -0x20);
        iVar19 = *(int64_t *)(&stack0x00000100 + iVar28 + iVar20 + iVar9 + -0x20);
        *(undefined8 *)(&stack0x00000078 + iVar28 + iVar20 + iVar9 + -0x20) = 0;
        if (param_1 != 0) {
            iVar19 = param_1;
        }
        *(int64_t *)(&stack0x00000100 + iVar28 + iVar20 + iVar9 + -0x20) = iVar19;
        *(undefined **)(&stack0x00000068 + iVar28 + iVar20 + iVar9 + -0x20) =
             &stack0x00000078 + iVar28 + iVar20 + iVar9 + -0x20;
        *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac7f0;
        iVar27 = fcn.18024a850(*(int64_t *)(&stack0x00000070 + iVar28 + iVar20 + iVar9 + -0x20), 
                               *(int64_t *)(&stack0x00000078 + iVar28 + iVar20 + iVar9 + -0x20), 
                               *(int64_t *)(&stack0x00000080 + iVar28 + iVar20 + iVar9 + -0x20), 
                               *(int64_t *)(&stack0x00000090 + iVar28 + iVar20 + iVar9 + -0x20));
        if (iVar27 != 0) {
            *(undefined8 *)(&stack0x00000118 + iVar28 + iVar20 + iVar9 + -0x20) = uVar15;
            iVar19 = *(int64_t *)(&stack0x00000078 + iVar28 + iVar20 + iVar9 + -0x20);
            if (iVar19 == 0) {
                *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac80f;
                fcn.180229480(*(int64_t *)(&stack0x00000068 + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)(&stack0x00000070 + iVar28 + iVar20 + iVar9 + -0x20));
                *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac827;
                fcn.1802295a0(*(int64_t *)(&stack0x00000068 + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)(&stack0x00000070 + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)(&stack0x00000078 + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar28 + iVar20 + iVar9 + -0x20), 
                              *(int64_t *)(&stack0x00000098 + iVar28 + iVar20 + iVar9 + -0x20));
                *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac840;
                fcn.1802296d0(*(int64_t *)(&stack0x00000088 + iVar28 + iVar20 + iVar9 + -0x20));
            } else if (iVar21 != 0) {
                *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac86d;
                iVar14 = fcn.180224ed0(*(int64_t *)(&stack0x00000068 + iVar28 + iVar20 + iVar9 + -0x20));
                if (iVar14 != 0) {
                    *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac886;
                    fcn.180498030(iVar14, &stack0x00000080 + iVar28 + iVar20 + iVar9 + -0x20, iVar19 * 2);
                    if (iVar13 == 0) {
                        uVar15 = *(undefined8 *)(iVar21 + 0x40);
                        *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac8ba;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf17);
                        *(int64_t *)(iVar21 + 0x40) = iVar14;
                        *(int64_t *)(iVar21 + 0x48) = iVar19;
                    } else {
                        uVar15 = *(undefined8 *)(iVar21 + 0x50);
                        *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac8a1;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf13);
                        *(int64_t *)(iVar21 + 0x50) = iVar14;
                        *(int64_t *)(iVar21 + 0x58) = iVar19;
                    }
                }
            }
        }
        uVar22 = *(uint64_t *)(&stack0x00000108 + iVar28 + iVar20 + iVar9 + -0x20);
        *(undefined8 *)(&stack0x00000040 + iVar28 + iVar20 + iVar9 + -0x20) = 0x1801ac8e1;
        uVar22 = fcn.180459870(uVar22 ^ (uint64_t)(&stack0x00000048 + iVar28 + iVar20 + iVar9 + -0x20));
        return uVar22;
    case 0x68:
        iVar21 = *(int64_t *)(param_1 + 0x158);
        uVar22 = (uint64_t)(int32_t)uVar11;
        *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19) = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        *(int64_t *)(&stack0x00000078 + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19 + 0x20 + -0x20) =
             *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
        *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = 0x1801c5915;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        uVar15 = *(undefined8 *)(iVar21 + 0x30);
        *(undefined8 *)(&stack0x00000058 + iVar19 + iVar10 + -0x20) = 0x1801c5937;
        fcn.180224990(uVar15, 0x1804b3080, 0x121c);
        *(undefined8 *)(iVar21 + 0x30) = 0;
        *(undefined8 *)(iVar21 + 0x38) = 0;
        if ((param_2 != (int64_t *)0x0) && (uVar22 != 0)) {
            if (uVar22 < 0x100) {
                *(undefined8 *)(&stack0x00000058 + iVar19 + iVar10 + -0x20) = 0x1801c596c;
                iVar19 = fcn.180223170(*(int64_t *)(&stack0x00000080 + iVar19 + iVar10 + -0x20));
                *(int64_t *)(iVar21 + 0x30) = iVar19;
                if (iVar19 != 0) {
                    *(uint64_t *)(iVar21 + 0x38) = uVar22;
                    return 1;
                }
            }
            return 0;
        }
        return 1;
    case 0x69:
        iVar14 = 0;
        uVar15 = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        uVar31 = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
        *(int64_t *)(&stack0x00000078 + iVar20 + iVar19) = param_1;
        *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19) = 0;
        *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19) = uVar15;
        *(int64_t *)(&stack0x00000058 + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)(&stack0x00000050 + iVar20 + iVar19) = uVar31;
        *(undefined8 *)(&stack0x00000048 + iVar20 + iVar19) = unaff_R12;
        *(undefined8 *)(&stack0x00000040 + iVar20 + iVar19) = unaff_R13;
        *(undefined8 *)(&stack0x00000038 + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar20 + iVar19) = unaff_R15;
        *(undefined8 *)(&stack0x00000028 + iVar20 + iVar19) = 0x1801a141f;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        iVar28 = 0;
        *(undefined8 *)(&stack0x000000d8 + iVar19 + iVar20 + iVar21 + -0x20) = 0;
        if (iVar14 == 0) {
            ppiVar23 = *(int64_t ***)(param_1 + 0x158);
        } else {
            ppiVar23 = *(int64_t ***)(iVar14 + 0x878);
            param_1 = *(int64_t *)(iVar14 + 8);
        }
        piVar25 = *ppiVar23;
        *(int64_t **)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20) = piVar25;
        uVar32 = 0;
        uVar30 = 0;
        uVar22 = 0;
        *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20) = param_1;
        *(int64_t ***)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20) = ppiVar23;
        *(uint32_t *)(&stack0x000000d0 + iVar19 + iVar20 + iVar21 + -0x20) = uVar11 & 4;
        if (*piVar25 == 0) {
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a147d;
            fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20));
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1495;
            fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20));
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14a7;
            fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20));
            uVar22 = uVar32;
code_r0x0001801a1782:
            uVar32 = uVar22;
            if (*(int32_t *)(&stack0x000000d0 + iVar19 + iVar20 + iVar21 + -0x20) == 0) goto code_r0x0001801a1794;
        } else {
            if ((uVar11 & 4) == 0) {
                if ((uVar11 & 1) != 0) {
                    *(int64_t *)(&stack0x000000d8 + iVar19 + iVar20 + iVar21 + -0x20) = piVar25[2];
                }
code_r0x0001801a1536:
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a154a;
                iVar28 = fcn.18024c080(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                       *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20));
                if (iVar28 == 0) {
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1557;
                    fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20));
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a156f;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20));
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1581;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20));
                    uVar22 = uVar32;
                } else {
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a159c;
                    iVar13 = fcn.18024bbe0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                           *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                           *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20));
                    if (iVar13 == 0) {
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15a5;
                        fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15bd;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15cf;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20));
                        uVar22 = uVar32;
                    } else {
                        uVar2 = *(uint32_t *)((int64_t)ppiVar23 + 0x1c);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15e5;
                        fcn.18024c330(iVar28, uVar2 & 0x30000);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15ed;
                        iVar13 = fcn.18024c740(*(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)(&stack0x00000078 + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar21 + -0x20));
                        if (iVar13 < 1) {
                            if ((uVar11 & 8) == 0) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16f2;
                                uVar12 = fcn.18024bbd0(iVar28);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16f9;
                                fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20));
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1711;
                                fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20));
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1718;
                                fcn.180250ec0(uVar12);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1731;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20));
                                goto code_r0x0001801a1782;
                            }
                            if ((uVar11 & 0x10) != 0) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1606;
                                fcn.1802203d0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20));
                            }
                            uVar30 = 2;
                        }
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1613;
                        iVar14 = fcn.18024b970(iVar28);
                        *(int64_t *)(&stack0x000000d8 + iVar19 + iVar20 + iVar21 + -0x20) = iVar14;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1626;
                        uVar15 = fcn.1802222a0(*(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)(&stack0x00000078 + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a162e;
                        fcn.18021fe80(uVar15);
                        if ((uVar11 & 2) != 0) {
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a163c;
                            iVar13 = fcn.180222010(iVar14);
                            if (0 < iVar13) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1648;
                                iVar13 = fcn.180222010(iVar14);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1653;
                                uVar15 = fcn.180222340(iVar14, iVar13 + -1);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a165b;
                                uVar11 = fcn.18023bbb0(uVar15);
                                if ((uVar11 >> 0xd & 1) != 0) {
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1669;
                                    uVar15 = fcn.180222020(iVar14);
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1671;
                                    fcn.18021fe80(uVar15);
                                }
                            }
                        }
                        iVar27 = 0;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a167b;
                        iVar13 = fcn.180222010(iVar14);
                        if (iVar13 < 1) {
                            iVar3 = piVar25[2];
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1774;
                            fcn.180238640(iVar3);
                            piVar25[2] = iVar14;
                            uVar22 = (uint64_t)uVar30;
                            if (uVar30 == 0) {
                                uVar22 = 1;
                            }
                        } else {
                            do {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a169d;
                                fcn.180222340(iVar14, iVar27);
                                *(undefined4 *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20) = 0;
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16b6;
                                uVar11 = fcn.1801a8d20(*(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20)
                                                       , *(int64_t *)
                                                          (&stack0x00000078 + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar21 + -0x20)
                                                       , *(int64_t *)
                                                          (&stack0x00000090 + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)(&stack0x00000100 + iVar19 + iVar20 + iVar21 + -0x20)
                                                      );
                                uVar22 = (uint64_t)uVar11;
                                if (uVar11 != 1) {
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1738;
                                    fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1750;
                                    fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)(&stack0x00000068 + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a175f;
                                    fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1767;
                                    fcn.180238640(iVar14);
                                    uVar22 = 0;
                                    goto code_r0x0001801a1782;
                                }
                                iVar27 = iVar27 + 1;
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16c7;
                                iVar13 = fcn.180222010(iVar14);
                            } while (iVar27 < iVar13);
                            iVar14 = *(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20);
                            uVar15 = *(undefined8 *)(iVar14 + 0x10);
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16d9;
                            fcn.180238640(uVar15);
                            *(undefined8 *)(iVar14 + 0x10) =
                                 *(undefined8 *)(&stack0x000000d8 + iVar19 + iVar20 + iVar21 + -0x20);
                        }
                    }
                }
                goto code_r0x0001801a1782;
            }
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14b5;
            iVar14 = fcn.18021f3d0(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)(&stack0x00000070 + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)(&stack0x00000078 + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20));
            if (iVar14 != 0) {
                iVar3 = piVar25[2];
                iVar27 = 0;
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14cc;
                iVar13 = fcn.180222010(iVar3);
                if (0 < iVar13) {
                    do {
                        iVar3 = piVar25[2];
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14db;
                        uVar15 = fcn.180222340(iVar3, iVar27);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14e6;
                        iVar13 = fcn.18021f070(iVar14, uVar15);
                        if (iVar13 == 0) goto code_r0x0001801a178c;
                        iVar3 = piVar25[2];
                        iVar27 = iVar27 + 1;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14f9;
                        iVar13 = fcn.180222010(iVar3);
                    } while (iVar27 < iVar13);
                }
                iVar3 = *piVar25;
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1508;
                iVar13 = fcn.18021f070(iVar14, iVar3);
                if (iVar13 != 0) {
                    ppiVar23 = *(int64_t ***)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20);
                    goto code_r0x0001801a1536;
                }
            }
        }
code_r0x0001801a178c:
        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1794;
        fcn.18021f290(*(int64_t *)(&stack0x00000050 + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)(&stack0x00000058 + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)(&stack0x00000060 + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar21 + -0x20));
code_r0x0001801a1794:
        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a179c;
        fcn.18024b910(iVar28);
        return uVar32;
    case 0x6a:
        iVar21 = *(int64_t *)(param_1 + 0x158);
        iVar13 = 0;
        uVar15 = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        uVar31 = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
        goto code_r0x0001801a24c0;
    case 0x6b:
        iVar21 = *(int64_t *)(param_1 + 0x158);
        iVar13 = 1;
        uVar15 = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        uVar31 = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
code_r0x0001801a24c0:
        *(undefined8 *)(&stack0x00000078 + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)(&stack0x00000080 + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19) = uVar31;
        *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = 0x1801a24d5;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if ((uVar11 != 0) && (param_2 != (int64_t *)0x0)) {
            *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801a24f3;
            uVar22 = fcn.18021f5b0(param_2);
            if ((int32_t)uVar22 == 0) {
                return uVar22;
            }
        }
        *(undefined8 *)(&stack0x00000090 + iVar19 + iVar20 + iVar7 + -0x20) = uVar15;
        iVar28 = 0x70;
        if (iVar13 == 0) {
            iVar28 = 0x78;
        }
        *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801a2524;
        fcn.18021f290(*(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)(&stack0x00000090 + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)(&stack0x000000b0 + iVar19 + iVar20 + iVar7 + -0x20), 
                      *(int64_t *)(&stack0x000000b8 + iVar19 + iVar20 + iVar7 + -0x20));
        *(int64_t **)(iVar28 + iVar21) = param_2;
        return 1;
    case 0x74:
        ppiVar23 = *(int64_t ***)(param_1 + 0x158);
        *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19) = *(undefined8 *)(&stack0x00000070 + iVar20 + iVar19);
        *(undefined8 *)(&stack0x00000078 + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)(&stack0x00000080 + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)(&stack0x00000088 + iVar20 + iVar19) = *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19);
        *(undefined8 *)(&stack0x00000060 + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)(&stack0x00000058 + iVar20 + iVar19) = 0x1801a2280;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if (param_2 != (int64_t *)0x0) {
            piVar25 = (int64_t *)0x0;
            if (ppiVar23[5] != (int64_t *)0x0) {
                ppiVar16 = (int64_t **)ppiVar23[4];
                piVar24 = piVar25;
                do {
                    if ((*ppiVar16 == param_2) && (ppiVar16[1] != (int64_t *)0x0)) {
                        *ppiVar23 = (int64_t *)ppiVar16;
                        return 1;
                    }
                    piVar24 = (int64_t *)((int64_t)piVar24 + 1);
                    ppiVar16 = ppiVar16 + 5;
                    piVar17 = piVar25;
                } while (piVar24 < ppiVar23[5]);
                do {
                    piVar24 = (int64_t *)((int64_t)ppiVar23[4] + (int64_t)piVar17);
                    if ((piVar24[1] != 0) && (*piVar24 != 0)) {
                        *(undefined8 *)(&stack0x00000058 + iVar19 + iVar20 + iVar3 + -0x20) = 0x1801a22de;
                        iVar13 = fcn.180238200(*(int64_t *)(&stack0x00000080 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x00000088 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x00000090 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x000000c8 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar3 + -0x20), 
                                               *(int64_t *)(&stack0x00000178 + iVar19 + iVar20 + iVar3 + -0x20));
                        if (iVar13 == 0) {
                            *ppiVar23 = piVar24;
                            return 1;
                        }
                    }
                    piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                    piVar17 = piVar17 + 5;
                } while (piVar25 < ppiVar23[5]);
            }
        }
        return 0;
    case 0x75:
        ppiVar23 = *(int64_t ***)(param_1 + 0x158);
        if (ppiVar23 != (int64_t **)0x0) {
            if (uVar11 == 1) {
                piVar24 = ppiVar23[5];
                piVar25 = (int64_t *)0x0;
                if (piVar24 != (int64_t *)0x0) {
code_r0x0001801a25ab:
                    piVar17 = ppiVar23[4] + (int64_t)piVar25 * 5;
                    while ((*piVar17 == 0 || (piVar17[1] == 0))) {
                        piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                        piVar17 = piVar17 + 5;
                        if (piVar24 <= piVar25) {
                            return 0;
                        }
                    }
                    *ppiVar23 = piVar17;
                    return 1;
                }
            } else if ((uVar11 == 2) &&
                      (piVar25 = (int64_t *)(((int64_t)*ppiVar23 - (int64_t)ppiVar23[4]) / 0x28 + 1),
                      piVar25 < ppiVar23[5])) {
                piVar24 = ppiVar23[5];
                goto code_r0x0001801a25ab;
            }
        }
        return 0;
    case 0x76:
        *(uint32_t *)(*(int64_t *)(param_1 + 0x158) + 0x18) = uVar11;
        return 1;
    case 0x7f:
        return (uint64_t)*(uint32_t *)(param_1 + 0x278);
    case 0x80:
        *param_2 = *(int64_t *)(param_1 + 0x268);
        return 1;
    case 0x81:
        *param_2 = *(int64_t *)(param_1 + 0x270);
        return 1;
    case 0x89:
        iVar19 = *(int64_t *)(param_1 + 0x158);
        bVar5 = false;
        goto code_r0x0001801a1fc0;
    case 0x8a:
        iVar19 = *(int64_t *)(param_1 + 0x158);
        bVar5 = true;
code_r0x0001801a1fc0:
        iVar20 = 0x70;
        if (!bVar5) {
            iVar20 = 0x78;
        }
        *param_2 = *(int64_t *)(iVar20 + iVar19);
        return 1;
    case 0x8b:
        *(int64_t **)(&stack0x00000048 + iVar20 + iVar19) = param_2;
        *(uint32_t *)(&stack0x00000040 + iVar20 + iVar19) = uVar11;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4b83;
        uVar22 = fcn.1801ab100(*(int64_t *)(&stack0x00000040 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000048 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000050 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000058 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x00000068 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x000000b0 + iVar20 + iVar19), 
                               *(int64_t *)(&stack0x000000b8 + iVar20 + iVar19));
        return uVar22;
    }
    *(code **)((int64_t)apcStackX_18 + iVar20 + iVar19) = case.0x1801c46af.5;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar20 + iVar19));
code_r0x0001801c46e6:
    return 0;
}

// ============================================================
// Function: FUN_1801bcbf0
// Address: 0x1801bcbf0
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801bcbf0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    uint64_t uVar15;
    undefined8 unaff_R13;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bcc07;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar14 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar15 = 0;
    uVar2 = *(undefined8 *)(in_RCX + 0xc10);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc2b;
    iVar6 = func_0x00018026bac0(uVar2, uVar14);
    uVar9 = uVar15;
    if (iVar6 == 0) {
code_r0x0001801bce26:
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce2b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce43;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    } else {
        uVar14 = *puVar1;
        uVar2 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar3 = *(undefined8 *)(in_RCX + 0xc10);
        uVar4 = *(undefined8 *)(in_RCX + 0xc18);
        *(undefined8 *)((int64_t)&var_8h + iVar8) = puVar1[0x8c];
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc5c;
        uVar9 = func_0x00018026b7d0(uVar4, uVar3, uVar2, uVar14);
        if ((uVar9 == 0) || (pcVar5 = *(code **)(in_RCX + 0xbe8), pcVar5 == (code *)0x0)) goto code_r0x0001801bce26;
        uVar14 = *(undefined8 *)(in_RCX + 0xbd0);
        uVar2 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc85;
        iVar10 = (*pcVar5)(uVar2, uVar14);
        if (iVar10 != 0) {
            uVar14 = puVar1[0x8c];
            uVar2 = *puVar1;
            uVar3 = *(undefined8 *)(in_RCX + 0xbf0);
            uVar4 = *(undefined8 *)(in_RCX + 0xc08);
            *(undefined8 *)((int64_t)&arg_48h + iVar8) = unaff_RBP;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar14;
            *(undefined8 *)((int64_t)&arg_50h + iVar8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcce4;
            iVar11 = func_0x00018026b7f0(uVar4, uVar3, iVar10, uVar2);
            uVar12 = uVar15;
            if (iVar11 == 0) {
code_r0x0001801bcdb7:
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdbc;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdd4;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)(&stack0x00000028 + iVar8));
code_r0x0001801bcdda:
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdea;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar8));
            } else {
                uVar14 = *(undefined8 *)(in_RCX + 0xc00);
                uVar2 = *(undefined8 *)(in_RCX + 0xc10);
                uVar3 = *(undefined8 *)(in_RCX + 0xbf8);
                *(undefined8 *)((int64_t)&var_10h + iVar8) = puVar1[0x8c];
                *(undefined8 *)((int64_t)&iStackX_8 + iVar8) = *puVar1;
                uVar4 = *(undefined8 *)(in_RCX + 0xc20);
                *(uint64_t *)(&stack0x00000000 + iVar8) = uVar9;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd32;
                uVar12 = func_0x00018026b460(uVar3, uVar2, uVar14, iVar11);
                if (uVar12 == 0) goto code_r0x0001801bcdb7;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd42;
                iVar6 = func_0x000180255500(uVar12);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd66;
                iVar13 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                if (iVar13 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd73;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd8b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)(&stack0x00000028 + iVar8));
                    goto code_r0x0001801bcdda;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd9e;
                func_0x000180254c60(uVar12, iVar13);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdb2;
                uVar7 = func_0x0001801c6380(in_RCX, iVar13, 
                                            (int64_t)((int32_t)(iVar6 + 7 + (iVar6 + 7 >> 0x1f & 7U)) >> 3), 1);
                uVar15 = (uint64_t)uVar7;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdf2;
            func_0x000180254e90(uVar12);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdfa;
            func_0x000180254e90(iVar11);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce02;
            uVar14 = fcn.180498cd0(iVar10);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce1a;
            func_0x000180224b90(iVar10, uVar14, 0x1804b01a8, 0x196);
            goto code_r0x0001801bce67;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc92;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bccaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce59;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce60;
    func_0x000180254e90(0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce67;
    func_0x000180254e90(0);
code_r0x0001801bce67:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce6f;
    func_0x000180254e90(uVar9);
    return uVar15;
}

// ============================================================
// Function: FUN_1801bccd0
// Address: 0x1801bccd0
// Size: 342 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801bcbf0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    uint64_t uVar15;
    undefined8 unaff_R13;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bcc07;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar14 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar15 = 0;
    uVar2 = *(undefined8 *)(in_RCX + 0xc10);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc2b;
    iVar6 = func_0x00018026bac0(uVar2, uVar14);
    uVar9 = uVar15;
    if (iVar6 == 0) {
code_r0x0001801bce26:
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce2b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce43;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    } else {
        uVar14 = *puVar1;
        uVar2 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar3 = *(undefined8 *)(in_RCX + 0xc10);
        uVar4 = *(undefined8 *)(in_RCX + 0xc18);
        *(undefined8 *)((int64_t)&var_8h + iVar8) = puVar1[0x8c];
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc5c;
        uVar9 = func_0x00018026b7d0(uVar4, uVar3, uVar2, uVar14);
        if ((uVar9 == 0) || (pcVar5 = *(code **)(in_RCX + 0xbe8), pcVar5 == (code *)0x0)) goto code_r0x0001801bce26;
        uVar14 = *(undefined8 *)(in_RCX + 0xbd0);
        uVar2 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc85;
        iVar10 = (*pcVar5)(uVar2, uVar14);
        if (iVar10 != 0) {
            uVar14 = puVar1[0x8c];
            uVar2 = *puVar1;
            uVar3 = *(undefined8 *)(in_RCX + 0xbf0);
            uVar4 = *(undefined8 *)(in_RCX + 0xc08);
            *(undefined8 *)((int64_t)&arg_48h + iVar8) = unaff_RBP;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar14;
            *(undefined8 *)((int64_t)&arg_50h + iVar8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcce4;
            iVar11 = func_0x00018026b7f0(uVar4, uVar3, iVar10, uVar2);
            uVar12 = uVar15;
            if (iVar11 == 0) {
code_r0x0001801bcdb7:
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdbc;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdd4;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)(&stack0x00000028 + iVar8));
code_r0x0001801bcdda:
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdea;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar8));
            } else {
                uVar14 = *(undefined8 *)(in_RCX + 0xc00);
                uVar2 = *(undefined8 *)(in_RCX + 0xc10);
                uVar3 = *(undefined8 *)(in_RCX + 0xbf8);
                *(undefined8 *)((int64_t)&var_10h + iVar8) = puVar1[0x8c];
                *(undefined8 *)((int64_t)&iStackX_8 + iVar8) = *puVar1;
                uVar4 = *(undefined8 *)(in_RCX + 0xc20);
                *(uint64_t *)(&stack0x00000000 + iVar8) = uVar9;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd32;
                uVar12 = func_0x00018026b460(uVar3, uVar2, uVar14, iVar11);
                if (uVar12 == 0) goto code_r0x0001801bcdb7;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd42;
                iVar6 = func_0x000180255500(uVar12);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd66;
                iVar13 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                if (iVar13 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd73;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd8b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)(&stack0x00000028 + iVar8));
                    goto code_r0x0001801bcdda;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd9e;
                func_0x000180254c60(uVar12, iVar13);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdb2;
                uVar7 = func_0x0001801c6380(in_RCX, iVar13, 
                                            (int64_t)((int32_t)(iVar6 + 7 + (iVar6 + 7 >> 0x1f & 7U)) >> 3), 1);
                uVar15 = (uint64_t)uVar7;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdf2;
            func_0x000180254e90(uVar12);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdfa;
            func_0x000180254e90(iVar11);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce02;
            uVar14 = fcn.180498cd0(iVar10);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce1a;
            func_0x000180224b90(iVar10, uVar14, 0x1804b01a8, 0x196);
            goto code_r0x0001801bce67;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc92;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bccaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce59;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce60;
    func_0x000180254e90(0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce67;
    func_0x000180254e90(0);
code_r0x0001801bce67:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce6f;
    func_0x000180254e90(uVar9);
    return uVar15;
}

// ============================================================
// Function: FUN_1801bce26
// Address: 0x1801bce26
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801bcbf0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    uint64_t uVar15;
    undefined8 unaff_R13;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bcc07;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar14 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar15 = 0;
    uVar2 = *(undefined8 *)(in_RCX + 0xc10);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc2b;
    iVar6 = func_0x00018026bac0(uVar2, uVar14);
    uVar9 = uVar15;
    if (iVar6 == 0) {
code_r0x0001801bce26:
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce2b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce43;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    } else {
        uVar14 = *puVar1;
        uVar2 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar3 = *(undefined8 *)(in_RCX + 0xc10);
        uVar4 = *(undefined8 *)(in_RCX + 0xc18);
        *(undefined8 *)((int64_t)&var_8h + iVar8) = puVar1[0x8c];
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc5c;
        uVar9 = func_0x00018026b7d0(uVar4, uVar3, uVar2, uVar14);
        if ((uVar9 == 0) || (pcVar5 = *(code **)(in_RCX + 0xbe8), pcVar5 == (code *)0x0)) goto code_r0x0001801bce26;
        uVar14 = *(undefined8 *)(in_RCX + 0xbd0);
        uVar2 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc85;
        iVar10 = (*pcVar5)(uVar2, uVar14);
        if (iVar10 != 0) {
            uVar14 = puVar1[0x8c];
            uVar2 = *puVar1;
            uVar3 = *(undefined8 *)(in_RCX + 0xbf0);
            uVar4 = *(undefined8 *)(in_RCX + 0xc08);
            *(undefined8 *)((int64_t)&arg_48h + iVar8) = unaff_RBP;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar14;
            *(undefined8 *)((int64_t)&arg_50h + iVar8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcce4;
            iVar11 = func_0x00018026b7f0(uVar4, uVar3, iVar10, uVar2);
            uVar12 = uVar15;
            if (iVar11 == 0) {
code_r0x0001801bcdb7:
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdbc;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdd4;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)(&stack0x00000028 + iVar8));
code_r0x0001801bcdda:
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdea;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar8));
            } else {
                uVar14 = *(undefined8 *)(in_RCX + 0xc00);
                uVar2 = *(undefined8 *)(in_RCX + 0xc10);
                uVar3 = *(undefined8 *)(in_RCX + 0xbf8);
                *(undefined8 *)((int64_t)&var_10h + iVar8) = puVar1[0x8c];
                *(undefined8 *)((int64_t)&iStackX_8 + iVar8) = *puVar1;
                uVar4 = *(undefined8 *)(in_RCX + 0xc20);
                *(uint64_t *)(&stack0x00000000 + iVar8) = uVar9;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd32;
                uVar12 = func_0x00018026b460(uVar3, uVar2, uVar14, iVar11);
                if (uVar12 == 0) goto code_r0x0001801bcdb7;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd42;
                iVar6 = func_0x000180255500(uVar12);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd66;
                iVar13 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                if (iVar13 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd73;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd8b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)(&stack0x00000028 + iVar8));
                    goto code_r0x0001801bcdda;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcd9e;
                func_0x000180254c60(uVar12, iVar13);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdb2;
                uVar7 = func_0x0001801c6380(in_RCX, iVar13, 
                                            (int64_t)((int32_t)(iVar6 + 7 + (iVar6 + 7 >> 0x1f & 7U)) >> 3), 1);
                uVar15 = (uint64_t)uVar7;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdf2;
            func_0x000180254e90(uVar12);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcdfa;
            func_0x000180254e90(iVar11);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce02;
            uVar14 = fcn.180498cd0(iVar10);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce1a;
            func_0x000180224b90(iVar10, uVar14, 0x1804b01a8, 0x196);
            goto code_r0x0001801bce67;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bcc92;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bccaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce59;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce60;
    func_0x000180254e90(0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce67;
    func_0x000180254e90(0);
code_r0x0001801bce67:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801bce6f;
    func_0x000180254e90(uVar9);
    return uVar15;
}

// ============================================================
// Function: FUN_1801bce90
// Address: 0x1801bce90
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801bce90(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801bcea8;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar2 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar13 = 0;
    uVar3 = *(undefined8 *)(in_RCX + 0xc18);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcecb;
    iVar6 = func_0x00018026ba20(uVar3, uVar2);
    uVar12 = uVar13;
    uVar9 = uVar13;
    uVar10 = uVar13;
    if (iVar6 != 0) {
        uVar2 = *puVar1;
        uVar3 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar4 = *(undefined8 *)(in_RCX + 0xc10);
        uVar5 = *(undefined8 *)(in_RCX + 0xc18);
        *(undefined8 *)((int64_t)&var_8h + iVar8) = puVar1[0x8c];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcefc;
        uVar9 = func_0x00018026b7d0(uVar5, uVar4, uVar3, uVar2);
        uVar12 = 0;
        if (uVar9 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0xc28);
            uVar3 = *(undefined8 *)(in_RCX + 0xc30);
            uVar4 = *(undefined8 *)(in_RCX + 0xc18);
            *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)(in_RCX + 0xbf8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf31;
            uVar10 = func_0x00018026b6b0(uVar4, uVar3, uVar9, uVar2);
            if (uVar10 != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_R15;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf4a;
                iVar6 = func_0x000180255500(uVar10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf6e;
                iVar11 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                if (iVar11 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf7b;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf93;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfa9;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar8));
                    uVar12 = uVar13;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfb6;
                    func_0x000180254c60(uVar10, iVar11);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfca;
                    uVar7 = func_0x0001801c6380(in_RCX, iVar11, 
                                                (int64_t)((int32_t)(iVar6 + 7 + (iVar6 + 7 >> 0x1f & 7U)) >> 3), 1);
                    uVar12 = (uint64_t)uVar7;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfd9;
    func_0x000180254e90(uVar10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfe1;
    func_0x000180254e90(uVar9);
    return uVar12;
}

// ============================================================
// Function: FUN_1801bcf40
// Address: 0x1801bcf40
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801bce90(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801bcea8;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar2 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar13 = 0;
    uVar3 = *(undefined8 *)(in_RCX + 0xc18);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcecb;
    iVar6 = func_0x00018026ba20(uVar3, uVar2);
    uVar12 = uVar13;
    uVar9 = uVar13;
    uVar10 = uVar13;
    if (iVar6 != 0) {
        uVar2 = *puVar1;
        uVar3 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar4 = *(undefined8 *)(in_RCX + 0xc10);
        uVar5 = *(undefined8 *)(in_RCX + 0xc18);
        *(undefined8 *)((int64_t)&var_8h + iVar8) = puVar1[0x8c];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcefc;
        uVar9 = func_0x00018026b7d0(uVar5, uVar4, uVar3, uVar2);
        uVar12 = 0;
        if (uVar9 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0xc28);
            uVar3 = *(undefined8 *)(in_RCX + 0xc30);
            uVar4 = *(undefined8 *)(in_RCX + 0xc18);
            *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)(in_RCX + 0xbf8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf31;
            uVar10 = func_0x00018026b6b0(uVar4, uVar3, uVar9, uVar2);
            if (uVar10 != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_R15;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf4a;
                iVar6 = func_0x000180255500(uVar10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf6e;
                iVar11 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                if (iVar11 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf7b;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf93;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfa9;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar8));
                    uVar12 = uVar13;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfb6;
                    func_0x000180254c60(uVar10, iVar11);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfca;
                    uVar7 = func_0x0001801c6380(in_RCX, iVar11, 
                                                (int64_t)((int32_t)(iVar6 + 7 + (iVar6 + 7 >> 0x1f & 7U)) >> 3), 1);
                    uVar12 = (uint64_t)uVar7;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfd9;
    func_0x000180254e90(uVar10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfe1;
    func_0x000180254e90(uVar9);
    return uVar12;
}

// ============================================================
// Function: FUN_1801bcfd1
// Address: 0x1801bcfd1
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801bce90(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801bcea8;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar2 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar13 = 0;
    uVar3 = *(undefined8 *)(in_RCX + 0xc18);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcecb;
    iVar6 = func_0x00018026ba20(uVar3, uVar2);
    uVar12 = uVar13;
    uVar9 = uVar13;
    uVar10 = uVar13;
    if (iVar6 != 0) {
        uVar2 = *puVar1;
        uVar3 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar4 = *(undefined8 *)(in_RCX + 0xc10);
        uVar5 = *(undefined8 *)(in_RCX + 0xc18);
        *(undefined8 *)((int64_t)&var_8h + iVar8) = puVar1[0x8c];
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcefc;
        uVar9 = func_0x00018026b7d0(uVar5, uVar4, uVar3, uVar2);
        uVar12 = 0;
        if (uVar9 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0xc28);
            uVar3 = *(undefined8 *)(in_RCX + 0xc30);
            uVar4 = *(undefined8 *)(in_RCX + 0xc18);
            *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)(in_RCX + 0xbf8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf31;
            uVar10 = func_0x00018026b6b0(uVar4, uVar3, uVar9, uVar2);
            if (uVar10 != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_R15;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf4a;
                iVar6 = func_0x000180255500(uVar10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf6e;
                iVar11 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                if (iVar11 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf7b;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcf93;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfa9;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar8));
                    uVar12 = uVar13;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfb6;
                    func_0x000180254c60(uVar10, iVar11);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfca;
                    uVar7 = func_0x0001801c6380(in_RCX, iVar11, 
                                                (int64_t)((int32_t)(iVar6 + 7 + (iVar6 + 7 >> 0x1f & 7U)) >> 3), 1);
                    uVar12 = (uint64_t)uVar7;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfd9;
    func_0x000180254e90(uVar10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801bcfe1;
    func_0x000180254e90(uVar9);
    return uVar12;
}

