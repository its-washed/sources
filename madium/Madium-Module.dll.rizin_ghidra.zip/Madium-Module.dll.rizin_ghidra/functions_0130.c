// Chunk 130 - 50 functions

// ============================================================
// Function: FUN_1801bf220
// Address: 0x1801bf220
// Size: 174 bytes
// ============================================================
undefined4 fcn.1801bf220(int64_t arg_38h, int64_t arg_48h, int64_t arg_60h, int64_t arg_70h, int64_t arg_b0h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bf22a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801bf23d;
    iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
    if (iVar1 == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RDI;
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&var_20h + iVar3) + 0x58);
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801bf263;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801bf26b;
    fcn.18026d890(uVar4);
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar3) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801bf27c;
    iVar1 = fcn.1801e3c10(uVar4);
    if (*(int32_t *)((int64_t)&arg_48h + iVar3) == 0) {
        uVar2 = *(undefined4 *)(*(int64_t *)((int64_t)&arg_38h + iVar3) + 0x128);
    } else {
        uVar2 = *(undefined4 *)(*(int64_t *)(&stack0x00000040 + iVar3) + 0xb8);
    }
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&var_20h + iVar3) + 0x58);
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801bf2ab;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801bf2b3;
    fcn.18026d900(uVar4);
    if (iVar1 != 0) {
        uVar2 = 5;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801bf2d0
// Address: 0x1801bf2d0
// Size: 27 bytes
// ============================================================
undefined8
fcn.1801bf2d0(int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h, int64_t arg_98h,
             int64_t arg_a0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = 0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801c1130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1149;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = unaff_RBX;
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1170;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1178;
    fcn.18026d890(uVar5);
    if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11a8;
        fcn.180193130(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11bc;
        fcn.180194b20(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
        iVar1 = *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3);
        *(uint64_t *)(iVar1 + 0x110) = (*(uint64_t *)(iVar1 + 0x110) & ~uVar7 | uVar8) & 0x3df6ffb87;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) + 0x110);
    iVar1 = *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3);
    if (iVar1 != 0) {
        *(uint64_t *)(iVar1 + 0xb0) = ((uint32_t)~uVar7 & *(uint32_t *)(iVar1 + 0xb0) | uVar8) & 0xde0fa987;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c121f;
        fcn.1801c22c0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) != 0) {
            uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) + 0xb0);
        }
    }
    uVar6 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1240;
    uVar6 = fcn.1801dd6c0(uVar6);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1248;
    fcn.18026d900(uVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1801bf2f0
// Address: 0x1801bf2f0
// Size: 334 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801bf2f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined2 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t **in_R8;
    bool bVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801bf312;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar1 = *(int64_t *)(in_RCX + 0x6c8);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf341;
        iVar5 = fcn.18026bf70(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf351;
            iVar5 = fcn.18026bea0(in_RDX);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf35c;
            uVar4 = fcn.18026bff0(in_RDX);
            iVar2 = *(int64_t *)((int64_t)&arg_28h + iVar6);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf37f;
            piVar7 = (int32_t *)fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
            if (piVar7 != (int32_t *)0x0) {
                *piVar7 = 1;
                *(int32_t **)(piVar7 + 2) = piVar7 + 10;
                *(int64_t *)(piVar7 + 4) = iVar2 + 6;
                *(undefined8 *)(piVar7 + 8) = 0;
                *(int64_t *)(piVar7 + 6) = iVar2 + 0x2e + (int64_t)piVar7;
                piVar7[10] = iVar5;
                *(undefined2 *)(piVar7 + 0xb) = uVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf3bf;
                iVar5 = fcn.18026bf70(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
                if (iVar5 != 0) {
                    uVar3 = *(undefined8 *)(iVar1 + 0x10);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf3f3;
                    fcn.18026d890(uVar3);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf3fe;
                    piVar8 = (int32_t *)fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar6));
                    bVar9 = piVar8 != (int32_t *)0x0;
                    if (bVar9) {
                        *in_R8 = piVar8;
                        LOCK();
                        *piVar8 = *piVar8 + 1;
                        UNLOCK();
                    }
                    uVar3 = *(undefined8 *)(iVar1 + 0x10);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf417;
                    fcn.18026d900(uVar3);
                    LOCK();
                    iVar5 = *piVar7;
                    *piVar7 = *piVar7 + -1;
                    UNLOCK();
                    if (1 < iVar5) {
                        return bVar9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf43a;
                    fcn.180224990(piVar7, 0x1804b0248, 0x1373);
                    return bVar9;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bf3cb;
                fcn.1801bf150(piVar7);
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801bf440
// Address: 0x1801bf440
// Size: 104 bytes
// ============================================================
uint64_t fcn.1801bf440(int64_t arg_30h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bf44c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf461;
    uVar4 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if ((int32_t)uVar4 == 0) {
        return uVar4;
    }
    uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_30h + iVar3) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf47c;
    iVar2 = fcn.1801e3b50(uVar1);
    if (iVar2 != 0) {
        uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_30h + iVar3) + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf496;
        iVar2 = fcn.1801e3ad0(uVar1);
        uVar5 = 1;
        if (iVar2 == 0) {
            uVar5 = 3;
        }
    }
    return (uint64_t)uVar5;
}

// ============================================================
// Function: FUN_1801bf4b0
// Address: 0x1801bf4b0
// Size: 87 bytes
// ============================================================
undefined8 fcn.1801bf4b0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bf4ba;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bf4cd;
    iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bf4d6;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bf4ee;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bf500;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bf510
// Address: 0x1801bf510
// Size: 967 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1801bf510(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    undefined8 *in_RCX;
    undefined8 uVar9;
    undefined8 uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bf525;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = in_RCX[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf534;
    iVar6 = func_0x00018019b200();
    if (iVar7 == iVar6) {
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0xc0101;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf563;
        func_0x0001801c1390(0, 0x1804b0248, 0x254, 0x1804b0270);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf578;
    iVar7 = fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar5));
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x8000f;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf5aa;
        func_0x0001801c1390(0, 0x1804b0248, 0x25a, 0x1804b0270);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf5b4;
    iVar6 = func_0x00018026d8b0();
    *(int64_t *)(iVar7 + 0xa8) = iVar6;
    if (iVar6 == 0) {
        uVar9 = 0x261;
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x8000f;
code_r0x0001801bf88c:
        uVar10 = 0x1804b0270;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf5df;
        uVar9 = func_0x00018019a2d0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf5ed;
        piVar8 = (int32_t *)func_0x000180196080(in_RCX, iVar7, uVar9);
        *(int32_t **)(iVar7 + 0x78) = piVar8;
        if (piVar8 == (int32_t *)0x0) {
code_r0x0001801bf877:
            uVar9 = 0x269;
code_r0x0001801bf87f:
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0xc0103;
            goto code_r0x0001801bf88c;
        }
        if (*piVar8 != 0) {
            if ((char)*piVar8 < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf610;
                piVar8 = (int32_t *)func_0x0001801bda50(piVar8);
                if (piVar8 != (int32_t *)0x0) goto code_r0x0001801bf619;
            }
            goto code_r0x0001801bf877;
        }
code_r0x0001801bf619:
        piVar8[0x58] = piVar8[0x58] | 0x6000;
        piVar8[0x2eb] = 0;
        *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
        uVar1 = *(uint32_t *)(iVar7 + 0x100);
        uVar2 = *(uint32_t *)(in_RCX + 0xd8);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = 0;
        *(uint32_t *)(iVar7 + 0x100) = ((uVar2 >> 2 & 1) << 3 ^ uVar1 & 0xfffffff7) & 0xfffffff9;
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = *in_RCX;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = in_RCX[0x8c];
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(iVar7 + 0xa8);
        uVar3 = in_RCX[0xd8];
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
        *(undefined (*) [16])((int64_t)&arg_50h + iVar5) = ZEXT816(0);
        if (((uVar3 & 4) != 0) || (((uint8_t)uVar3 & 10) == 10)) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf6be;
        iVar6 = func_0x0001801dd790((int64_t)&arg_28h + iVar5);
        *(int64_t *)(iVar7 + 0x90) = iVar6;
        if (iVar6 != 0) {
            *(undefined8 **)((int64_t)&arg_60h + iVar5) = in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf6fb;
            iVar6 = func_0x0001801dd620(iVar6, (int64_t)&arg_48h + iVar5);
            *(int64_t *)(iVar7 + 0x98) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0xc0103;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf72f;
                func_0x0001801c1390(0, 0x1804b0248, 0x746, 0x1804b0308);
                uVar9 = *(undefined8 *)(iVar7 + 0x90);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf73b;
                func_0x0001801dd680(uVar9);
                goto code_r0x0001801bf8a1;
            }
            uVar9 = *(undefined8 *)(iVar7 + 0x78);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf74c;
            iVar6 = func_0x0001801e8ca0(iVar6, uVar9);
            *(int64_t *)(iVar7 + 0xa0) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0xc0103;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf780;
                func_0x0001801c1390(0, 0x1804b0248, 0x74d, 0x1804b0308);
                uVar9 = *(undefined8 *)(iVar7 + 0x98);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf78c;
                func_0x0001801e8db0(uVar9);
                uVar9 = *(undefined8 *)(iVar7 + 0x90);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf798;
                func_0x0001801dd680(uVar9);
                goto code_r0x0001801bf8a1;
            }
            uVar9 = in_RCX[0x2e];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf7af;
            func_0x0001801e4c80(iVar6, uVar9, iVar7);
            uVar9 = in_RCX[0x2f];
            uVar10 = *(undefined8 *)(iVar7 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf7c2;
            func_0x0001801e4d00(uVar10, uVar9);
            *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)(iVar7 + 0x98);
            *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)(iVar7 + 0x90);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf7ee;
            iVar4 = func_0x0001801bda70(iVar7, in_RCX, 0x80, 0);
            if (iVar4 != 0) {
                iVar4 = 1;
                *(undefined4 *)(iVar7 + 0x104) = 1;
                *(undefined4 *)(iVar7 + 0x108) = *(undefined4 *)(*(int64_t *)(iVar7 + 8) + 0x140);
                uVar3 = *(uint64_t *)(*(int64_t *)(iVar7 + 8) + 0x138);
                *(undefined4 *)(iVar7 + 0x118) = 0;
                *(uint64_t *)(iVar7 + 0x110) = uVar3 & 0x3df6ffb87;
                *(undefined4 *)(iVar7 + 0x128) = 0;
                if ((*(int64_t *)(iVar7 + 0xb0) != 0) || ((*(uint8_t *)(iVar7 + 0x100) & 0x10) != 0)) {
                    iVar4 = 2;
                }
                uVar9 = *(undefined8 *)(iVar7 + 0x120);
                uVar10 = *(undefined8 *)(iVar7 + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf872;
                func_0x0001801e4c50(uVar10, iVar4 == 2, uVar9);
                return iVar7;
            }
            uVar9 = 0x286;
            goto code_r0x0001801bf87f;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
        uVar10 = 0x1804b0308;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0xc0103;
        uVar9 = 0x73f;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf8a1;
    func_0x0001801c1390(0, 0x1804b0248, uVar9, uVar10);
code_r0x0001801bf8a1:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf8ab;
    func_0x0001801c0480(iVar7, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf8c0;
    fcn.180224990(iVar7, 0x1804b0248, 0x2a2);
    return 0;
}

// ============================================================
// Function: FUN_1801bf8e0
// Address: 0x1801bf8e0
// Size: 238 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.1801bf8e0(int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bf8f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf90a;
    piVar4 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
    if (piVar4 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf929;
        fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x180195290;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf952;
        iVar5 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        *piVar4 = iVar5;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf95f;
            iVar5 = fcn.18026d8b0();
            piVar4[2] = iVar5;
            if (iVar5 != 0) {
                *(undefined4 *)(piVar4 + 1) = 1;
                return piVar4;
            }
        }
        LOCK();
        piVar1 = piVar4 + 1;
        iVar2 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf995;
            fcn.18026d840(piVar4 + 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf9a4;
            fcn.180228c50(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf9ac;
            fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf9c1;
            fcn.180224990(piVar4, 0x1804b0248, 0x12dc);
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1801bf9d0
// Address: 0x1801bf9d0
// Size: 31 bytes
// ============================================================
void fcn.1801bf9d0(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bf9da;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801bf9ea;
    fcn.1801c1470(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                  *(int64_t *)(&stack0x000000a0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801bf9f0
// Address: 0x1801bf9f0
// Size: 24 bytes
// ============================================================
undefined8
fcn.1801bf9f0(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_a0h, int64_t arg_f0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 uVar7;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1801bfa20;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa37;
    iVar1 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa59;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa61;
    fcn.18026d890(uVar4);
    if ((*(uint8_t *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0x100) & 1) == 0) goto code_r0x0001801bfb3d;
    iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa8c;
        iVar1 = fcn.1801c0620(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000a8 + iVar3 + iVar2));
        if (iVar1 != 0) {
            iVar5 = *(int64_t *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0xb0);
            *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2) = iVar5;
            goto code_r0x0001801bfaa1;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0x163;
    } else {
code_r0x0001801bfaa1:
        if (*(int64_t *)(iVar5 + 0x80) != 0) {
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb3a;
                uVar7 = fcn.1801bfe40(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2), 
                                      *(int64_t *)(&stack0x00000080 + iVar3 + iVar2));
            } else {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfafd;
                iVar5 = fcn.1801bfe40(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2), 
                                      *(int64_t *)(&stack0x00000080 + iVar3 + iVar2));
                if (iVar5 == 0) {
                    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0xa0);
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb13;
                    iVar1 = fcn.1801e3a00(uVar4);
                    if (iVar1 == 0) {
                        uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0xa0);
                        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb28;
                        iVar1 = fcn.1801e3b50(uVar4);
                        if (iVar1 == 0) goto code_r0x0001801bfb3d;
                    }
                }
                uVar7 = 1;
            }
            goto code_r0x0001801bfb3d;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0xc0103;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfaed;
    fcn.1801c1390(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                  *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2));
code_r0x0001801bfb3d:
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb4b;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb53;
    fcn.18026d900(uVar4);
    return uVar7;
}

// ============================================================
// Function: FUN_1801bfa10
// Address: 0x1801bfa10
// Size: 340 bytes
// ============================================================
undefined8
fcn.1801bf9f0(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_a0h, int64_t arg_f0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 uVar7;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1801bfa20;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa37;
    iVar1 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa59;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa61;
    fcn.18026d890(uVar4);
    if ((*(uint8_t *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0x100) & 1) == 0) goto code_r0x0001801bfb3d;
    iVar5 = *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfa8c;
        iVar1 = fcn.1801c0620(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x000000a8 + iVar3 + iVar2));
        if (iVar1 != 0) {
            iVar5 = *(int64_t *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0xb0);
            *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2) = iVar5;
            goto code_r0x0001801bfaa1;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0x163;
    } else {
code_r0x0001801bfaa1:
        if (*(int64_t *)(iVar5 + 0x80) != 0) {
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb3a;
                uVar7 = fcn.1801bfe40(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2), 
                                      *(int64_t *)(&stack0x00000080 + iVar3 + iVar2));
            } else {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfafd;
                iVar5 = fcn.1801bfe40(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2), 
                                      *(int64_t *)(&stack0x00000080 + iVar3 + iVar2));
                if (iVar5 == 0) {
                    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0xa0);
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb13;
                    iVar1 = fcn.1801e3a00(uVar4);
                    if (iVar1 == 0) {
                        uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2) + 0xa0);
                        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb28;
                        iVar1 = fcn.1801e3b50(uVar4);
                        if (iVar1 == 0) goto code_r0x0001801bfb3d;
                    }
                }
                uVar7 = 1;
            }
            goto code_r0x0001801bfb3d;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0xc0103;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfaed;
    fcn.1801c1390(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar2), 
                  *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2));
code_r0x0001801bfb3d:
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb4b;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1801bfb53;
    fcn.18026d900(uVar4);
    return uVar7;
}

// ============================================================
// Function: FUN_1801bfb70
// Address: 0x1801bfb70
// Size: 31 bytes
// ============================================================
void fcn.1801bfb70(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bfb7a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801bfb8a;
    fcn.1801c1470(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                  *(int64_t *)(&stack0x000000a0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801bfb90
// Address: 0x1801bfb90
// Size: 87 bytes
// ============================================================
undefined8 fcn.1801bfb90(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bfb9a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bfbad;
    iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bfbb6;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bfbce;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bfbe0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bfbf0
// Address: 0x1801bfbf0
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801bfbf0(int64_t arg_28h, int64_t arg_78h, int64_t arg_c0h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bfc00;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bfc20;
    iVar2 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    uVar1 = *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar3) + 0x100);
    if ((uVar1 & 4) == 0) {
        if ((uVar1 & 1) != 0) {
            if (in_EDX == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0x118;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bfc69;
            fcn.1801c1390(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            return 0;
        }
        *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar3) + 0x100) = uVar1 | 4;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801bfca0
// Address: 0x1801bfca0
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801bfca0(int64_t arg_28h, int64_t arg_78h, int64_t arg_c0h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bfcb0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bfcd0;
    iVar2 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    uVar1 = *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar3) + 0x100);
    if ((uVar1 & 4) != 0) {
        if ((uVar1 & 1) != 0) {
            if (in_EDX == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 0x118;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bfd19;
            fcn.1801c1390(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            return 0;
        }
        *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar3) + 0x100) = uVar1 & 0xfffffffb;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801bfd50
// Address: 0x1801bfd50
// Size: 27 bytes
// ============================================================
undefined8 fcn.1801bfd50(undefined8 param_1, uint64_t param_2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801c1130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1149;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)(&stack0x00000090 + iVar4 + iVar3) = unaff_RBX;
    uVar5 = *(undefined8 *)(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1170;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1178;
    fcn.18026d890(uVar5);
    if (*(int32_t *)(&stack0x00000068 + iVar4 + iVar3) == 0) {
        *(undefined8 *)(&stack0x00000098 + iVar4 + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11a8;
        fcn.180193130(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000098 + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11bc;
        fcn.180194b20(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000098 + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
        *(uint64_t *)(*(int64_t *)(&stack0x00000058 + iVar4 + iVar3) + 0x110) =
             (*(uint64_t *)(*(int64_t *)(&stack0x00000058 + iVar4 + iVar3) + 0x110) & ~uVar7 | param_2) & 0x3df6ffb87;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(&stack0x00000058 + iVar4 + iVar3) + 0x110);
    iVar1 = *(int64_t *)(&stack0x00000060 + iVar4 + iVar3);
    if (iVar1 != 0) {
        *(uint64_t *)(iVar1 + 0xb0) = ((uint32_t)~uVar7 & *(uint32_t *)(iVar1 + 0xb0) | param_2) & 0xde0fa987;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c121f;
        fcn.1801c22c0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
        if (*(int32_t *)(&stack0x00000068 + iVar4 + iVar3) != 0) {
            uVar5 = *(undefined8 *)(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3) + 0xb0);
        }
    }
    uVar6 = *(undefined8 *)(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1240;
    uVar6 = fcn.1801dd6c0(uVar6);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1248;
    fcn.18026d900(uVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1801bfd70
// Address: 0x1801bfd70
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801bfd70(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bfd80;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar2 = *(int64_t *)(in_RCX + 0x6c8);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfda7;
        iVar5 = fcn.1801be1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
        if (iVar5 != 0) {
            uVar3 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdbd;
            fcn.18026d890(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdc8;
            piVar6 = (int32_t *)fcn.180229240(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            if (piVar6 != (int32_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfddb;
                fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)(&stack0x00000038 + iVar4));
                LOCK();
                iVar1 = *piVar6;
                *piVar6 = *piVar6 + -1;
                UNLOCK();
                if (iVar1 < 2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdfe;
                    fcn.180224990(piVar6, 0x1804b0248, 0x1373);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfe09;
            fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000038 + iVar4));
            uVar3 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfe12;
            fcn.18026d900(uVar3);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bfdb3
// Address: 0x1801bfdb3
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801bfd70(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bfd80;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar2 = *(int64_t *)(in_RCX + 0x6c8);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfda7;
        iVar5 = fcn.1801be1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
        if (iVar5 != 0) {
            uVar3 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdbd;
            fcn.18026d890(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdc8;
            piVar6 = (int32_t *)fcn.180229240(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            if (piVar6 != (int32_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfddb;
                fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)(&stack0x00000038 + iVar4));
                LOCK();
                iVar1 = *piVar6;
                *piVar6 = *piVar6 + -1;
                UNLOCK();
                if (iVar1 < 2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdfe;
                    fcn.180224990(piVar6, 0x1804b0248, 0x1373);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfe09;
            fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000038 + iVar4));
            uVar3 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfe12;
            fcn.18026d900(uVar3);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bfe27
// Address: 0x1801bfe27
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801bfd70(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bfd80;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar2 = *(int64_t *)(in_RCX + 0x6c8);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfda7;
        iVar5 = fcn.1801be1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
        if (iVar5 != 0) {
            uVar3 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdbd;
            fcn.18026d890(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdc8;
            piVar6 = (int32_t *)fcn.180229240(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            if (piVar6 != (int32_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfddb;
                fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)(&stack0x00000038 + iVar4));
                LOCK();
                iVar1 = *piVar6;
                *piVar6 = *piVar6 + -1;
                UNLOCK();
                if (iVar1 < 2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfdfe;
                    fcn.180224990(piVar6, 0x1804b0248, 0x1373);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfe09;
            fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000038 + iVar4));
            uVar3 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfe12;
            fcn.18026d900(uVar3);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801bfe40
// Address: 0x1801bfe40
// Size: 180 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1801bfe40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_68h)
{
    undefined uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar5;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bfe50;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined *)(in_RCX + 0x102);
    iVar5 = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = 0;
    // switch table (7 cases) at 0x1801bfed8
    switch(uVar1) {
    default:
        return 0;
    case 1:
    case 2:
    case 3:
        break;
    case 5:
        return (int64_t)in_EDX;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bfe90;
    iVar3 = func_0x0001801e6a70(uVar2, (int64_t)&arg_38h + iVar4, (int64_t)&arg_28h + iVar4);
    if ((((iVar3 == 0) || (iVar5 = *(int64_t *)((int64_t)&arg_38h + iVar4), iVar5 == 0)) && (in_EDX != 0)) &&
       (*(int32_t *)((int64_t)&arg_28h + iVar4) != 0)) {
        iVar5 = 1;
    }
    return iVar5;
}

// ============================================================
// Function: FUN_1801bff00
// Address: 0x1801bff00
// Size: 240 bytes
// ============================================================
undefined8 fcn.1801bff00(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined8 uVar5;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bff0c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = 3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bff21;
    iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)((int64_t)&arg_40h + iVar2));
    if (iVar1 != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)((int64_t)&var_18h + iVar2) + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bff3e;
        uVar3 = fcn.1801dd6c0(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bff46;
        fcn.18026d890(uVar3);
        if (*(int32_t *)((int64_t)&arg_40h + iVar2) == 0) {
            uVar4 = *(undefined4 *)(*(int64_t *)((int64_t)&arg_30h + iVar2) + 0x128);
        } else {
            uVar4 = *(undefined4 *)(*(int64_t *)((int64_t)&arg_38h + iVar2) + 0xb8);
        }
    // switch table (11 cases) at 0x1801bffc4
        switch(uVar4) {
        case 2:
            break;
        case 3:
            uVar5 = 2;
            break;
        case 4:
            uVar5 = 4;
            break;
        default:
            uVar5 = 1;
            break;
        case 0xb:
            uVar5 = 7;
            break;
        case 0xc:
            uVar5 = 8;
        }
        uVar3 = *(undefined8 *)(*(int64_t *)((int64_t)&var_18h + iVar2) + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bffb2;
        uVar3 = fcn.1801dd6c0(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bffba;
        fcn.18026d900(uVar3);
        return uVar5;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801bfff0
// Address: 0x1801bfff0
// Size: 31 bytes
// ============================================================
void fcn.1801bfff0(void)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bfffa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c000a;
    fcn.1801c0010(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000070 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801c0010
// Address: 0x1801c0010
// Size: 1125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

undefined4 fcn.1801c0010(int64_t arg_28h, int64_t arg_78h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 in_RDX;
    undefined4 uVar8;
    int64_t in_R8;
    uint64_t in_R9;
    uint32_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_34h;
    
    stack0xffffffffffffffd0 = 0x1801c0037;
    iVar6 = fcn.18045a350();
    iVar1 = arg_28h;
    iVar6 = -iVar6;
    uVar8 = 0;
    *(undefined8 *)arg_28h = 0;
    uVar9 = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0065;
        iVar4 = fcn.1801bdce0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        if (iVar4 == 0) {
            return 0;
        }
        uVar7 = *(undefined8 *)(var_68h + 0x58);
        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0076;
        uVar7 = fcn.1801dd6c0(uVar7);
        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c007e;
        fcn.18026d890(uVar7);
        var_34h._0_4_ = 1;
        if ((int32_t)var_40h == 0) {
            if (var_50h != 0) {
                *(undefined4 *)(var_50h + 0x128) = 0;
            }
            goto code_r0x0001801c0095;
        }
        if (var_48h != 0) {
            *(undefined4 *)(var_48h + 0xb8) = 0;
            goto code_r0x0001801c0095;
        }
    } else {
        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c00c6;
        iVar4 = fcn.1801bdce0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        if (iVar4 == 0) {
            return 0;
        }
code_r0x0001801c0095:
        if (var_48h != 0) {
            uVar9 = *(uint32_t *)(var_48h + 0xa8) & 1;
        }
    }
    if ((in_R9 & 0xfffffffe) != 0) {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0x19c;
        goto code_r0x0001801c042b;
    }
    if ((*(uint8_t *)(var_50h + 0x100) & 0x20) == 0) {
        uVar7 = *(undefined8 *)(var_50h + 0xa0);
        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0113;
        iVar4 = fcn.1801e3b50(uVar7);
        if (iVar4 != 0) goto code_r0x0001801c0411;
        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0124;
        iVar4 = func_0x0001801c0be0(&var_68h);
        uVar5 = 0;
        if (iVar4 < 1) goto code_r0x0001801c043d;
        if (in_R8 == 0) {
            if ((in_R9 & 1) != 0) {
                uVar9 = *(uint32_t *)(var_68h + 0x70);
                iVar1 = var_68h;
                while ((uVar9 = uVar9 >> 5 & 3, uVar9 == 0 && (iVar1 = *(int64_t *)(iVar1 + 0x40), iVar1 != 0))) {
                    uVar9 = *(uint32_t *)(iVar1 + 0x70);
                }
                uVar7 = *(undefined8 *)(*(int64_t *)(var_48h + 0x80) + 0x70);
                *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c03ee;
                func_0x0001801e6170(uVar7);
                if (uVar9 != 2) {
                    uVar7 = *(undefined8 *)(*(int64_t *)(var_48h + 0x78) + 0xa0);
                    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0403;
                    uVar7 = func_0x0001801e39d0(uVar7);
                    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c040d;
                    func_0x0001801dd2b0(uVar7, 0);
                }
            }
code_r0x0001801c040d:
            uVar5 = 1;
            goto code_r0x0001801c043d;
        }
        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0142;
        iVar4 = func_0x0001801c1be0(var_48h, &arg_28h);
        if (iVar4 == 0) {
            uVar8 = (undefined4)arg_28h;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = uVar8;
        } else {
            *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0166;
            iVar4 = fcn.1801bd970(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
            iVar3 = var_48h;
            if (iVar4 != 0) {
                arg_28h = 0;
                *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0188;
                iVar4 = func_0x0001801c21f0(var_48h, in_RDX, in_R8, &arg_28h);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0xc0103;
                    *(undefined8 *)iVar1 = 0;
code_r0x0001801c01a2:
                    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c01b9;
                    uVar5 = fcn.1801c1390(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6));
                } else {
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 1;
                    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c01e7;
                    func_0x0001801c12e0(var_48h, arg_28h != 0, arg_28h == in_R8, in_R9);
                    *(int64_t *)iVar1 = arg_28h;
                    if (arg_28h != in_R8) {
                        uVar7 = *(undefined8 *)(var_68h + 0x58);
                        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c022b;
                        fcn.1801dd840(uVar7, 0);
                        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0233;
                        fcn.1801dd6d0(uVar7);
                        *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0249;
                        iVar4 = fcn.1801dcf10(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)(&stack0x00000050 + iVar6));
                        if (iVar4 < 1) {
                            iVar1 = *(int64_t *)(var_48h + 0x78);
                            if ((*(uint8_t *)(iVar1 + 0x100) & 0x20) == 0) {
                                uVar7 = *(undefined8 *)(iVar1 + 0xa0);
                                *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0266;
                                iVar4 = fcn.1801e3b50(uVar7);
                                if (iVar4 == 0) {
                                    uVar7 = *(undefined8 *)(iVar1 + 0xa0);
                                    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0276;
                                    iVar4 = func_0x0001801e3ab0(uVar7);
                                    if (iVar4 != 0) {
                                        *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
                                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0xc0103;
                                        goto code_r0x0001801c01a2;
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0xcf;
                            goto code_r0x0001801c01a2;
                        }
                        *(undefined8 *)iVar1 = *(undefined8 *)iVar1;
                    }
                    uVar5 = 1;
                }
                goto code_r0x0001801c043d;
            }
            if (uVar9 == 0) {
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar1;
                *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c03aa;
                uVar5 = func_0x0001801c1ef0(&var_68h, in_RDX, in_R8, in_R9);
                goto code_r0x0001801c043d;
            }
            *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c02cf;
            iVar4 = func_0x0001801c21f0(var_48h, in_RDX, in_R8, iVar1);
            if (iVar4 != 0) {
                uVar9 = *(uint32_t *)(var_68h + 0x70);
                iVar2 = var_68h;
                while ((uVar9 = uVar9 >> 5 & 3, uVar9 == 0 && (iVar2 = *(int64_t *)(iVar2 + 0x40), iVar2 != 0))) {
                    uVar9 = *(uint32_t *)(iVar2 + 0x70);
                }
                iVar2 = *(int64_t *)iVar1;
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar6) = (uint32_t)(uVar9 != 2);
                *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c034a;
                func_0x0001801c12e0(iVar3, iVar2 != 0, iVar2 == in_R8, in_R9);
                if (*(int64_t *)iVar1 == 0) {
                    uVar5 = uVar8;
                    if ((int32_t)var_34h != 0) {
                        if ((int32_t)var_40h == 0) {
                            if (var_50h != 0) {
                                *(undefined4 *)(var_50h + 0x128) = 3;
                            }
                        } else if (var_48h != 0) {
                            *(undefined4 *)(var_48h + 0xb8) = 3;
                        }
                    }
                    goto code_r0x0001801c043d;
                }
                goto code_r0x0001801c040d;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0xc0103;
            *(undefined8 *)iVar1 = 0;
        }
    } else {
code_r0x0001801c0411:
        *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0xcf;
    }
code_r0x0001801c042b:
    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c043b;
    uVar5 = fcn.1801c1390(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6));
code_r0x0001801c043d:
    uVar7 = *(undefined8 *)(var_68h + 0x58);
    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c044a;
    uVar7 = fcn.1801dd6c0(uVar7);
    *(undefined8 *)((int64_t)&var_34h + iVar6 + 4) = 0x1801c0452;
    fcn.18026d900(uVar7);
    return uVar5;
}

// ============================================================
// Function: FUN_1801c0480
// Address: 0x1801c0480
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c0480(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c049a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = *(undefined8 *)(in_RCX + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c04ab;
    fcn.180193500(uVar3);
    uVar3 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)(in_RCX + 0x78) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c04bd;
    func_0x0001801e3930(uVar3);
    iVar1 = *(int64_t *)(in_RCX + 0x98);
    *(undefined8 *)(in_RCX + 0xa0) = 0;
    if (((iVar1 != 0) && (*(int64_t *)(in_RCX + 0x80) == 0)) && ((*(uint32_t *)(in_RCX + 0x100) & 0x200) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c04ed;
        uVar3 = func_0x0001801e3990(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c04f5;
        func_0x00018021a070(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c04fd;
        uVar3 = func_0x0001801e8e30(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c0505;
        func_0x00018021a070(uVar3);
        uVar3 = *(undefined8 *)(in_RCX + 0x98);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c0511;
        func_0x0001801e8db0(uVar3);
        uVar3 = *(undefined8 *)(in_RCX + 0x90);
        *(undefined8 *)(in_RCX + 0x98) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c0524;
        func_0x0001801dd680(uVar3);
        *(undefined8 *)(in_RCX + 0x90) = 0;
    }
    if (in_EDX != 0) {
        uVar3 = *(undefined8 *)(in_RCX + 0xa8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c053b;
        fcn.18026d900(uVar3);
    }
    if ((*(int64_t *)(in_RCX + 0x80) == 0) && ((*(uint32_t *)(in_RCX + 0x100) & 0x200) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c055c;
        fcn.18026d840(in_RCX + 0xa8);
    }
    return;
}

// ============================================================
// Function: FUN_1801c0580
// Address: 0x1801c0580
// Size: 70 bytes
// ============================================================
undefined8 fcn.1801c0580(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c058c;
    iVar2 = fcn.18045a350();
    uVar3 = *(undefined8 *)(param_1 + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801c059e;
    uVar3 = fcn.1801e39c0(uVar3);
    if ((*(uint8_t *)(param_1 + 0x100) & 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801c05af;
        iVar1 = fcn.1801e79d0(uVar3);
        if (iVar1 != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c05d0
// Address: 0x1801c05d0
// Size: 74 bytes
// ============================================================
void fcn.1801c05d0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    
    fcn.18045a350();
    *(uint32_t *)(param_1 + 0x100) = *(uint32_t *)(param_1 + 0x100) | 0x10;
    iVar3 = *(int32_t *)(param_1 + 0x118);
    if (iVar3 == 0) {
        iVar3 = (*(int32_t *)(param_1 + 0x104) != 0) + 1;
    }
    uVar1 = *(undefined8 *)(param_1 + 0x120);
    iVar2 = *(int64_t *)(param_1 + 0xa0);
    *(uint32_t *)(iVar2 + 0x5d0) = *(uint32_t *)(iVar2 + 0x5d0) & 0xbfffffff;
    *(undefined8 *)(iVar2 + 0x560) = uVar1;
    *(uint32_t *)(iVar2 + 0x5d0) = *(uint32_t *)(iVar2 + 0x5d0) | -(uint32_t)(iVar3 == 2) & 0x40000000;
    return;
}

// ============================================================
// Function: FUN_1801c0620
// Address: 0x1801c0620
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.1801c0620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_90h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c0639;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_60h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    iVar2 = in_RCX[3];
    uVar1 = *(uint32_t *)(iVar2 + 0x100);
    if (((uVar1 & 0x10) != 0) || (*(int32_t *)(iVar2 + 0x104) == 0)) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x163;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c090e;
        fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        goto code_r0x0001801c0749;
    }
    uVar6 = *(undefined8 *)(iVar2 + 0xa0);
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0691;
    fcn.1801e39c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c069c;
    iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
    if (iVar5 == 0) {
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06bd;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06c8;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06dc;
        fcn.1801c0920(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06e8;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06f3;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        if (in_EDX != 0) goto code_r0x0001801c0749;
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0714;
        iVar3 = fcn.1801e3b50(uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0777;
            iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar3 == 0) {
                if (*(int32_t *)((int64_t)in_RCX + 0x34) != 0) {
                    if (*(int32_t *)(in_RCX + 5) == 0) {
                        if (in_RCX[3] != 0) {
                            *(undefined4 *)(in_RCX[3] + 0x128) = 2;
                        }
                    } else if (in_RCX[4] != 0) {
                        *(undefined4 *)(in_RCX[4] + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c0749;
            }
            iVar5 = *in_RCX;
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar2;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
            *(int64_t **)((int64_t)&arg_30h + iVar4) = in_RCX;
            *(uint64_t *)((int64_t)&arg_38h + iVar4) = (uint64_t)(~uVar1 >> 1 & 1);
            uVar6 = *(undefined8 *)(iVar5 + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07e4;
            fcn.1801dd840(uVar6, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07ec;
            fcn.1801dd6d0(uVar6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0803;
            iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&arg_60h + iVar4));
            if (iVar3 != 0) {
                if ((iVar3 < 0) || (*(int64_t *)((int64_t)&arg_28h + iVar4) == 0)) goto code_r0x0001801c0749;
                goto code_r0x0001801c0839;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xcf;
        }
    } else {
code_r0x0001801c0839:
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0845;
        uVar6 = fcn.1801e39f0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0852;
        fcn.1801de220(uVar6, (int64_t)&arg_40h + iVar4);
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c085e;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c086e;
        fcn.1801e7d30(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0879;
        iVar7 = fcn.1801bdbb0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar5 = *(int64_t *)(iVar2 + 0xb0);
        if (iVar5 != iVar7) {
            *(int64_t *)(iVar2 + 0xb0) = iVar7;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0899;
                fcn.180194eb0(iVar2);
            } else {
                LOCK();
                *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + -1;
                UNLOCK();
            }
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08ac;
                fcn.180193500(iVar5);
            }
        }
        if (*(int64_t *)(iVar2 + 0xb0) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08dc;
            fcn.1801c05d0(iVar2);
            goto code_r0x0001801c0749;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0741;
    fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801c0749:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0756;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801c0684
// Address: 0x1801c0684
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.1801c0620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_90h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c0639;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_60h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    iVar2 = in_RCX[3];
    uVar1 = *(uint32_t *)(iVar2 + 0x100);
    if (((uVar1 & 0x10) != 0) || (*(int32_t *)(iVar2 + 0x104) == 0)) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x163;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c090e;
        fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        goto code_r0x0001801c0749;
    }
    uVar6 = *(undefined8 *)(iVar2 + 0xa0);
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0691;
    fcn.1801e39c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c069c;
    iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
    if (iVar5 == 0) {
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06bd;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06c8;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06dc;
        fcn.1801c0920(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06e8;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06f3;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        if (in_EDX != 0) goto code_r0x0001801c0749;
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0714;
        iVar3 = fcn.1801e3b50(uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0777;
            iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar3 == 0) {
                if (*(int32_t *)((int64_t)in_RCX + 0x34) != 0) {
                    if (*(int32_t *)(in_RCX + 5) == 0) {
                        if (in_RCX[3] != 0) {
                            *(undefined4 *)(in_RCX[3] + 0x128) = 2;
                        }
                    } else if (in_RCX[4] != 0) {
                        *(undefined4 *)(in_RCX[4] + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c0749;
            }
            iVar5 = *in_RCX;
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar2;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
            *(int64_t **)((int64_t)&arg_30h + iVar4) = in_RCX;
            *(uint64_t *)((int64_t)&arg_38h + iVar4) = (uint64_t)(~uVar1 >> 1 & 1);
            uVar6 = *(undefined8 *)(iVar5 + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07e4;
            fcn.1801dd840(uVar6, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07ec;
            fcn.1801dd6d0(uVar6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0803;
            iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&arg_60h + iVar4));
            if (iVar3 != 0) {
                if ((iVar3 < 0) || (*(int64_t *)((int64_t)&arg_28h + iVar4) == 0)) goto code_r0x0001801c0749;
                goto code_r0x0001801c0839;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xcf;
        }
    } else {
code_r0x0001801c0839:
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0845;
        uVar6 = fcn.1801e39f0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0852;
        fcn.1801de220(uVar6, (int64_t)&arg_40h + iVar4);
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c085e;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c086e;
        fcn.1801e7d30(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0879;
        iVar7 = fcn.1801bdbb0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar5 = *(int64_t *)(iVar2 + 0xb0);
        if (iVar5 != iVar7) {
            *(int64_t *)(iVar2 + 0xb0) = iVar7;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0899;
                fcn.180194eb0(iVar2);
            } else {
                LOCK();
                *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + -1;
                UNLOCK();
            }
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08ac;
                fcn.180193500(iVar5);
            }
        }
        if (*(int64_t *)(iVar2 + 0xb0) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08dc;
            fcn.1801c05d0(iVar2);
            goto code_r0x0001801c0749;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0741;
    fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801c0749:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0756;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801c0749
// Address: 0x1801c0749
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.1801c0620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_90h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c0639;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_60h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    iVar2 = in_RCX[3];
    uVar1 = *(uint32_t *)(iVar2 + 0x100);
    if (((uVar1 & 0x10) != 0) || (*(int32_t *)(iVar2 + 0x104) == 0)) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x163;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c090e;
        fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        goto code_r0x0001801c0749;
    }
    uVar6 = *(undefined8 *)(iVar2 + 0xa0);
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0691;
    fcn.1801e39c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c069c;
    iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
    if (iVar5 == 0) {
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06bd;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06c8;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06dc;
        fcn.1801c0920(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06e8;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06f3;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        if (in_EDX != 0) goto code_r0x0001801c0749;
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0714;
        iVar3 = fcn.1801e3b50(uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0777;
            iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar3 == 0) {
                if (*(int32_t *)((int64_t)in_RCX + 0x34) != 0) {
                    if (*(int32_t *)(in_RCX + 5) == 0) {
                        if (in_RCX[3] != 0) {
                            *(undefined4 *)(in_RCX[3] + 0x128) = 2;
                        }
                    } else if (in_RCX[4] != 0) {
                        *(undefined4 *)(in_RCX[4] + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c0749;
            }
            iVar5 = *in_RCX;
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar2;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
            *(int64_t **)((int64_t)&arg_30h + iVar4) = in_RCX;
            *(uint64_t *)((int64_t)&arg_38h + iVar4) = (uint64_t)(~uVar1 >> 1 & 1);
            uVar6 = *(undefined8 *)(iVar5 + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07e4;
            fcn.1801dd840(uVar6, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07ec;
            fcn.1801dd6d0(uVar6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0803;
            iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&arg_60h + iVar4));
            if (iVar3 != 0) {
                if ((iVar3 < 0) || (*(int64_t *)((int64_t)&arg_28h + iVar4) == 0)) goto code_r0x0001801c0749;
                goto code_r0x0001801c0839;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xcf;
        }
    } else {
code_r0x0001801c0839:
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0845;
        uVar6 = fcn.1801e39f0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0852;
        fcn.1801de220(uVar6, (int64_t)&arg_40h + iVar4);
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c085e;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c086e;
        fcn.1801e7d30(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0879;
        iVar7 = fcn.1801bdbb0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar5 = *(int64_t *)(iVar2 + 0xb0);
        if (iVar5 != iVar7) {
            *(int64_t *)(iVar2 + 0xb0) = iVar7;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0899;
                fcn.180194eb0(iVar2);
            } else {
                LOCK();
                *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + -1;
                UNLOCK();
            }
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08ac;
                fcn.180193500(iVar5);
            }
        }
        if (*(int64_t *)(iVar2 + 0xb0) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08dc;
            fcn.1801c05d0(iVar2);
            goto code_r0x0001801c0749;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0741;
    fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801c0749:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0756;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801c076f
// Address: 0x1801c076f
// Size: 375 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.1801c0620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_90h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c0639;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_60h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    iVar2 = in_RCX[3];
    uVar1 = *(uint32_t *)(iVar2 + 0x100);
    if (((uVar1 & 0x10) != 0) || (*(int32_t *)(iVar2 + 0x104) == 0)) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x163;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c090e;
        fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        goto code_r0x0001801c0749;
    }
    uVar6 = *(undefined8 *)(iVar2 + 0xa0);
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0691;
    fcn.1801e39c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c069c;
    iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
    if (iVar5 == 0) {
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06bd;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06c8;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06dc;
        fcn.1801c0920(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06e8;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06f3;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        if (in_EDX != 0) goto code_r0x0001801c0749;
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0714;
        iVar3 = fcn.1801e3b50(uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0777;
            iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar3 == 0) {
                if (*(int32_t *)((int64_t)in_RCX + 0x34) != 0) {
                    if (*(int32_t *)(in_RCX + 5) == 0) {
                        if (in_RCX[3] != 0) {
                            *(undefined4 *)(in_RCX[3] + 0x128) = 2;
                        }
                    } else if (in_RCX[4] != 0) {
                        *(undefined4 *)(in_RCX[4] + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c0749;
            }
            iVar5 = *in_RCX;
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar2;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
            *(int64_t **)((int64_t)&arg_30h + iVar4) = in_RCX;
            *(uint64_t *)((int64_t)&arg_38h + iVar4) = (uint64_t)(~uVar1 >> 1 & 1);
            uVar6 = *(undefined8 *)(iVar5 + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07e4;
            fcn.1801dd840(uVar6, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07ec;
            fcn.1801dd6d0(uVar6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0803;
            iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&arg_60h + iVar4));
            if (iVar3 != 0) {
                if ((iVar3 < 0) || (*(int64_t *)((int64_t)&arg_28h + iVar4) == 0)) goto code_r0x0001801c0749;
                goto code_r0x0001801c0839;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xcf;
        }
    } else {
code_r0x0001801c0839:
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0845;
        uVar6 = fcn.1801e39f0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0852;
        fcn.1801de220(uVar6, (int64_t)&arg_40h + iVar4);
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c085e;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c086e;
        fcn.1801e7d30(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0879;
        iVar7 = fcn.1801bdbb0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar5 = *(int64_t *)(iVar2 + 0xb0);
        if (iVar5 != iVar7) {
            *(int64_t *)(iVar2 + 0xb0) = iVar7;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0899;
                fcn.180194eb0(iVar2);
            } else {
                LOCK();
                *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + -1;
                UNLOCK();
            }
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08ac;
                fcn.180193500(iVar5);
            }
        }
        if (*(int64_t *)(iVar2 + 0xb0) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08dc;
            fcn.1801c05d0(iVar2);
            goto code_r0x0001801c0749;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0741;
    fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801c0749:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0756;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801c08e6
// Address: 0x1801c08e6
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.1801c0620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_90h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c0639;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_60h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    iVar2 = in_RCX[3];
    uVar1 = *(uint32_t *)(iVar2 + 0x100);
    if (((uVar1 & 0x10) != 0) || (*(int32_t *)(iVar2 + 0x104) == 0)) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x163;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c090e;
        fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        goto code_r0x0001801c0749;
    }
    uVar6 = *(undefined8 *)(iVar2 + 0xa0);
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0691;
    fcn.1801e39c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c069c;
    iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
    if (iVar5 == 0) {
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06bd;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06c8;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06dc;
        fcn.1801c0920(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06e8;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c06f3;
        iVar5 = fcn.1801e7870(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (iVar5 != 0) goto code_r0x0001801c0839;
        if (in_EDX != 0) goto code_r0x0001801c0749;
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0714;
        iVar3 = fcn.1801e3b50(uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0777;
            iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar3 == 0) {
                if (*(int32_t *)((int64_t)in_RCX + 0x34) != 0) {
                    if (*(int32_t *)(in_RCX + 5) == 0) {
                        if (in_RCX[3] != 0) {
                            *(undefined4 *)(in_RCX[3] + 0x128) = 2;
                        }
                    } else if (in_RCX[4] != 0) {
                        *(undefined4 *)(in_RCX[4] + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c0749;
            }
            iVar5 = *in_RCX;
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar2;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
            *(int64_t **)((int64_t)&arg_30h + iVar4) = in_RCX;
            *(uint64_t *)((int64_t)&arg_38h + iVar4) = (uint64_t)(~uVar1 >> 1 & 1);
            uVar6 = *(undefined8 *)(iVar5 + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07e4;
            fcn.1801dd840(uVar6, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c07ec;
            fcn.1801dd6d0(uVar6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0803;
            iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&arg_60h + iVar4));
            if (iVar3 != 0) {
                if ((iVar3 < 0) || (*(int64_t *)((int64_t)&arg_28h + iVar4) == 0)) goto code_r0x0001801c0749;
                goto code_r0x0001801c0839;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xcf;
        }
    } else {
code_r0x0001801c0839:
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0845;
        uVar6 = fcn.1801e39f0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0852;
        fcn.1801de220(uVar6, (int64_t)&arg_40h + iVar4);
        uVar6 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c085e;
        fcn.1801e39c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c086e;
        fcn.1801e7d30(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0879;
        iVar7 = fcn.1801bdbb0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar5 = *(int64_t *)(iVar2 + 0xb0);
        if (iVar5 != iVar7) {
            *(int64_t *)(iVar2 + 0xb0) = iVar7;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0899;
                fcn.180194eb0(iVar2);
            } else {
                LOCK();
                *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + -1;
                UNLOCK();
            }
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08ac;
                fcn.180193500(iVar5);
            }
        }
        if (*(int64_t *)(iVar2 + 0xb0) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c08dc;
            fcn.1801c05d0(iVar2);
            goto code_r0x0001801c0749;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xc0103;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0741;
    fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x0001801c0749:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c0756;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801c0920
// Address: 0x1801c0920
// Size: 88 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah

void fcn.1801c0920(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    char cVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t *in_RCX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 uStackX_18;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c092a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *in_RCX;
    uVar8 = *(uint32_t *)(iVar7 + 0x70);
    iVar6 = iVar7;
    while (uVar8 = uVar8 >> 5 & 3, uVar8 == 0) {
        iVar6 = *(int64_t *)(iVar6 + 0x40);
        if (iVar6 == 0) goto code_r0x0001801c095c;
        uVar8 = *(uint32_t *)(iVar6 + 0x70);
    }
    if (uVar8 == 2) {
        return;
    }
code_r0x0001801c095c:
    uVar2 = *(undefined8 *)(iVar7 + 0x58);
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x1801c0965;
    iVar6 = fcn.1801dd6d0(uVar2);
    uVar9 = 0;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7 + iVar5) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_20 + iVar7 + iVar5;
    pcVar3 = *(code **)(iVar6 + 0x28);
    uVar2 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_40h + iVar7 + iVar5) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_18 + iVar7 + iVar5) = 0x1801dd2eb;
    (*pcVar3)((int64_t)&arg_40h + iVar7 + iVar5, uVar2, uVar9);
    cVar1 = *(char *)((int64_t)&arg_48h + iVar7 + iVar5 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_48h + iVar7 + iVar5) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_40h + iVar7 + iVar5);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_48h + iVar7 + iVar5 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar7 + iVar5) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar2 = *(undefined8 *)(iVar6 + 0x38);
            uVar4 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_18 + iVar7 + iVar5) = 0x1801dd34d;
            func_0x00018026d610(uVar4, uVar2);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar7 + iVar5) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7 + iVar5) ^ (int64_t)&uStackX_20 + iVar7 + iVar5);
    return;
}

// ============================================================
// Function: FUN_1801c0980
// Address: 0x1801c0980
// Size: 593 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

int64_t fcn.1801c0980(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_a0h,
                     int64_t arg_d8h, int64_t arg_100h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    uint64_t in_RDX;
    int32_t in_R8D;
    uint32_t uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801c09a2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = in_RCX[3];
    iVar7 = 0;
    uVar8 = (uint32_t)in_RDX & 1;
    iVar9 = 0;
    if (in_R8D != 0) {
        uVar6 = *(undefined8 *)(*in_RCX + 0x58);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c09d9;
        uVar6 = fcn.1801dd6c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c09e1;
        fcn.18026d890(uVar6);
    }
    if ((*(uint8_t *)(iVar1 + 0x100) & 0x20) == 0) {
        uVar6 = *(undefined8 *)(iVar1 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c09fa;
        iVar3 = fcn.1801e3b50(uVar6);
        if (iVar3 != 0) goto code_r0x0001801c0b47;
        if ((in_RDX & 4) == 0) {
            uVar6 = *(undefined8 *)(iVar1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0a1a;
            iVar3 = func_0x0001801e3b00(uVar6, uVar8);
            if (iVar3 != 0) goto code_r0x0001801c0adc;
            if ((in_RDX & 2) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0a33;
                iVar3 = fcn.1801bd970(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
                if (iVar3 == 0) goto code_r0x0001801c0ac7;
                iVar2 = *in_RCX;
                *(int64_t *)((int64_t)&var_8h + iVar5) = iVar1;
                *(uint32_t *)((int64_t)&var_10h + iVar5) = uVar8;
                uVar6 = *(undefined8 *)(iVar2 + 0x58);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0a56;
                fcn.1801dd840(uVar6, 0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0a5e;
                fcn.1801dd6d0(uVar6);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0a75;
                iVar3 = fcn.1801dcf10(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar5));
                if ((*(uint8_t *)(iVar1 + 0x100) & 0x20) != 0) goto code_r0x0001801c0b47;
                uVar6 = *(undefined8 *)(iVar1 + 0xa0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0a8c;
                iVar4 = fcn.1801e3b50(uVar6);
                if (iVar4 != 0) goto code_r0x0001801c0b47;
                uVar6 = *(undefined8 *)(iVar1 + 0xa0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0a9c;
                iVar4 = func_0x0001801e3ab0(uVar6);
                if (iVar4 == 0) goto code_r0x0001801c0b47;
                if (0 < iVar3) goto code_r0x0001801c0adc;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -0x20) = 0;
                *(undefined4 *)(&stack0xfffffffffffffff8 + iVar5) = 0xc0103;
                iVar9 = iVar7;
            } else {
code_r0x0001801c0ac7:
                *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -0x20) = 0;
                *(undefined4 *)(&stack0xfffffffffffffff8 + iVar5) = 0x19b;
            }
        } else {
code_r0x0001801c0adc:
            uVar6 = *(undefined8 *)(iVar1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0aeb;
            iVar9 = func_0x0001801e3c20(uVar6, uVar8);
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b13;
                iVar7 = fcn.1801bdbb0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
                if (iVar7 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b23;
                    fcn.1801c05d0(iVar1);
                    if (in_R8D == 0) {
                        return iVar7;
                    }
                    uVar6 = *(undefined8 *)(*in_RCX + 0x58);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b34;
                    uVar6 = fcn.1801dd6c0(uVar6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b3c;
                    fcn.18026d900(uVar6);
                    return iVar7;
                }
                goto code_r0x0001801c0b6a;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -0x20) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar5) = 0xc0103;
        }
    } else {
code_r0x0001801c0b47:
        *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -0x20) = 0;
        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar5) = 0xcf;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b6a;
    fcn.1801c1390(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
code_r0x0001801c0b6a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b7f;
    fcn.180224990(iVar7, 0x1804b0248, 0x940);
    uVar6 = *(undefined8 *)(iVar1 + 0xa0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b8b;
    uVar6 = fcn.1801e39c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0b96;
    func_0x0001801e7c50(uVar6, iVar9);
    if (in_R8D != 0) {
        uVar6 = *(undefined8 *)(*in_RCX + 0x58);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0ba7;
        uVar6 = fcn.1801dd6c0(uVar6);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c0baf;
        fcn.18026d900(uVar6);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c0be0
// Address: 0x1801c0be0
// Size: 1182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

undefined8 fcn.1801c0be0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c0bf8;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar1 = in_RCX[3];
    uVar9 = *(undefined8 *)(iVar1 + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0c0e;
    iVar3 = func_0x0001801e3af0(uVar9);
    if (iVar3 != 0) {
        return 1;
    }
    if ((*(uint8_t *)(iVar1 + 0x100) & 0x20) != 0) {
code_r0x0001801c1037:
        *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xcf;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c1064;
        uVar9 = fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
        return uVar9;
    }
    uVar9 = *(undefined8 *)(iVar1 + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0c2f;
    iVar3 = fcn.1801e3b50(uVar9);
    if (iVar3 != 0) goto code_r0x0001801c1037;
    if (((*(uint32_t *)(iVar1 + 0x100) >> 1 ^ *(uint32_t *)(iVar1 + 0x100)) & 2) != 0) {
        *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x80106;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0c75;
        fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0xffffffff;
    }
    uVar9 = *(undefined8 *)(*in_RCX + 0x60);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0c8e;
    iVar7 = func_0x0001801e3990(uVar9);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0c99;
    iVar8 = func_0x0001801e8e30(uVar9);
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x80;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c1030;
        fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0xffffffff;
    }
    if ((*(uint8_t *)(iVar1 + 0x100) & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0cc3;
        iVar3 = func_0x0001801e8e80(uVar9);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0cd3;
            iVar3 = fcn.18026bea0(iVar1 + 0xb8);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0cee;
                iVar3 = func_0x000180219d10(iVar8, 0x5d, 0, iVar1 + 0xb8);
                if (iVar3 < 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0cfe;
                    func_0x00018026be30(iVar1 + 0xb8);
                } else {
                    uVar2 = *(undefined8 *)(iVar1 + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0d13;
                    func_0x0001801e4d70(uVar2, iVar1 + 0xb8);
                }
            }
        }
        if ((*(uint8_t *)(iVar1 + 0x100) & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0d24;
            iVar3 = func_0x0001801e8e80(uVar9);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0d34;
                iVar3 = fcn.18026bea0(iVar1 + 0xb8);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x15a;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0d65;
                    fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0xffffffff;
                }
            }
        }
    }
    iVar7 = in_RCX[3];
    if ((*(uint8_t *)(iVar7 + 0x100) & 1) == 0) {
        uVar9 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0d93;
        iVar3 = func_0x0001801e4d70(uVar9, iVar7 + 0xb8);
        if (iVar3 == 0) {
            uVar9 = 0x1804b0318;
code_r0x0001801c0dfe:
            *(undefined8 *)((int64_t)&var_10h + iVar6) = uVar9;
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0103;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0e22;
            fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            return 0xffffffff;
        }
        uVar9 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0db2;
        iVar3 = func_0x0001801e4ee0(uVar9);
        if (iVar3 == 0) {
            uVar9 = *(undefined8 *)(iVar7 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0dc2;
            func_0x0001801e4c00(uVar9);
            uVar9 = 0x1804b0350;
            goto code_r0x0001801c0dfe;
        }
        if ((*(uint8_t *)(iVar7 + 0x100) & 8) != 0) {
            uVar9 = *(undefined8 *)(iVar7 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0ded;
            iVar3 = func_0x0001801e8450(iVar7 + 0xd8, uVar9);
            if (iVar3 == 0) {
                uVar9 = 0x1804b0368;
                goto code_r0x0001801c0dfe;
            }
        }
    }
    *(uint32_t *)(iVar7 + 0x100) = *(uint32_t *)(iVar7 + 0x100) | 1;
    uVar9 = *(undefined8 *)(iVar1 + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0e3f;
    iVar3 = func_0x0001801e3af0(uVar9);
    if (iVar3 != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0e4f;
    iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar6));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0e5b;
        fcn.1801c0920(*(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)(&stack0x00000030 + iVar6));
        uVar9 = *(undefined8 *)(iVar1 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0e67;
        iVar3 = func_0x0001801e3af0(uVar9);
        if (iVar3 != 0) {
            return 1;
        }
        uVar9 = *(undefined8 *)(iVar1 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0e7b;
        iVar3 = fcn.1801e3b50(uVar9);
        if (iVar3 != 0) goto code_r0x0001801c0e85;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0ebb;
        iVar3 = func_0x0001801bda10(iVar1);
        if (iVar3 != 0) {
            uVar9 = *(undefined8 *)(iVar1 + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0ecd;
            func_0x0001801dd860(uVar9, 1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0ed5;
    iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar6));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0fbe;
        iVar3 = func_0x0001801c2120(iVar1);
        if (iVar3 == 0) {
            if (*(int32_t *)((int64_t)in_RCX + 0x34) != 0) {
                if (*(int32_t *)(in_RCX + 5) == 0) {
                    if (in_RCX[3] != 0) {
                        *(undefined4 *)(in_RCX[3] + 0x128) = 2;
                    }
                } else if (in_RCX[4] != 0) {
                    *(undefined4 *)(in_RCX[4] + 0xb8) = 2;
                    return 0xffffffff;
                }
            }
            return 0xffffffff;
        }
code_r0x0001801c0f8c:
        uVar9 = *(undefined8 *)(iVar1 + 0x78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0f97;
        uVar5 = func_0x000180193b00(uVar9, 0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0fa1;
        func_0x0001801c1440(in_RCX, uVar5);
        return 0xffffffff;
    }
    iVar7 = *in_RCX;
    *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar1;
    uVar9 = *(undefined8 *)(iVar7 + 0x58);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0ef3;
    fcn.1801dd840(uVar9, 0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0efb;
    fcn.1801dd6d0(uVar9);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0f12;
    iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000060 + iVar6));
    if ((*(uint8_t *)(iVar1 + 0x100) & 0x20) == 0) {
        uVar9 = *(undefined8 *)(iVar1 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0f2d;
        iVar4 = fcn.1801e3b50(uVar9);
        if (iVar4 == 0) {
            uVar9 = *(undefined8 *)(iVar1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0f3d;
            iVar4 = func_0x0001801e3ab0(uVar9);
            if (iVar4 != 0) {
                if (iVar3 < 1) {
                    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0103;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0f72;
                    fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    return 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0f84;
                iVar3 = func_0x0001801c2120(iVar1);
                if (iVar3 == 0) {
                    return 1;
                }
                goto code_r0x0001801c0f8c;
            }
        }
    }
code_r0x0001801c0e85:
    *(undefined8 *)((int64_t)&var_10h + iVar6) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xcf;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801c0eac;
    fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801c1080
// Address: 0x1801c1080
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801c1080(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c1090;
    iVar5 = fcn.18045a350();
    iVar3 = -iVar5;
    iVar1 = *in_RCX;
    if ((*(uint8_t *)(iVar1 + 0x100) & (uint8_t)iVar5) == 0) {
        uVar2 = *(undefined8 *)(iVar1 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c10ad;
        iVar4 = fcn.1801e3b50(uVar2);
        if (iVar4 == 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c10bd;
            iVar4 = fcn.1801e3ab0(uVar2);
            if (iVar4 != 0) {
                uVar2 = *(undefined8 *)(*in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c10d0;
                iVar4 = fcn.1801e3af0(uVar2);
                if (iVar4 == 0) {
                    uVar2 = *(undefined8 *)(*in_RCX + 0x78);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c10e0;
                    iVar4 = fcn.180194f30(uVar2);
                    if ((iVar4 != 4) && (iVar4 != 7)) {
                        return (uint64_t)(iVar4 == 8);
                    }
                }
                return 1;
            }
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801c1120
// Address: 0x1801c1120
// Size: 106 bytes
// ============================================================
undefined8
fcn.1801bf2d0(int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h, int64_t arg_98h,
             int64_t arg_a0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = 0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801c1130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1149;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = unaff_RBX;
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1170;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1178;
    fcn.18026d890(uVar5);
    if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11a8;
        fcn.180193130(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11bc;
        fcn.180194b20(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
        iVar1 = *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3);
        *(uint64_t *)(iVar1 + 0x110) = (*(uint64_t *)(iVar1 + 0x110) & ~uVar7 | uVar8) & 0x3df6ffb87;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) + 0x110);
    iVar1 = *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3);
    if (iVar1 != 0) {
        *(uint64_t *)(iVar1 + 0xb0) = ((uint32_t)~uVar7 & *(uint32_t *)(iVar1 + 0xb0) | uVar8) & 0xde0fa987;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c121f;
        fcn.1801c22c0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) != 0) {
            uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) + 0xb0);
        }
    }
    uVar6 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1240;
    uVar6 = fcn.1801dd6c0(uVar6);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1248;
    fcn.18026d900(uVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1801c118a
// Address: 0x1801c118a
// Size: 93 bytes
// ============================================================
undefined8
fcn.1801bf2d0(int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h, int64_t arg_98h,
             int64_t arg_a0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = 0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801c1130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1149;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = unaff_RBX;
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1170;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1178;
    fcn.18026d890(uVar5);
    if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11a8;
        fcn.180193130(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11bc;
        fcn.180194b20(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
        iVar1 = *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3);
        *(uint64_t *)(iVar1 + 0x110) = (*(uint64_t *)(iVar1 + 0x110) & ~uVar7 | uVar8) & 0x3df6ffb87;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) + 0x110);
    iVar1 = *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3);
    if (iVar1 != 0) {
        *(uint64_t *)(iVar1 + 0xb0) = ((uint32_t)~uVar7 & *(uint32_t *)(iVar1 + 0xb0) | uVar8) & 0xde0fa987;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c121f;
        fcn.1801c22c0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) != 0) {
            uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) + 0xb0);
        }
    }
    uVar6 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1240;
    uVar6 = fcn.1801dd6c0(uVar6);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1248;
    fcn.18026d900(uVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1801c11e7
// Address: 0x1801c11e7
// Size: 119 bytes
// ============================================================
undefined8
fcn.1801bf2d0(int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h, int64_t arg_98h,
             int64_t arg_a0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = 0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801c1130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1149;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = unaff_RBX;
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1170;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1178;
    fcn.18026d890(uVar5);
    if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11a8;
        fcn.180193130(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11bc;
        fcn.180194b20(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
        iVar1 = *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3);
        *(uint64_t *)(iVar1 + 0x110) = (*(uint64_t *)(iVar1 + 0x110) & ~uVar7 | uVar8) & 0x3df6ffb87;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) + 0x110);
    iVar1 = *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3);
    if (iVar1 != 0) {
        *(uint64_t *)(iVar1 + 0xb0) = ((uint32_t)~uVar7 & *(uint32_t *)(iVar1 + 0xb0) | uVar8) & 0xde0fa987;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c121f;
        fcn.1801c22c0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) != 0) {
            uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) + 0xb0);
        }
    }
    uVar6 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1240;
    uVar6 = fcn.1801dd6c0(uVar6);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1248;
    fcn.18026d900(uVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1801c1260
// Address: 0x1801c1260
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801c1260(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c1270;
    iVar6 = fcn.18045a350();
    iVar4 = -iVar6;
    iVar2 = *in_RCX;
    if ((*(uint8_t *)(iVar2 + 0x100) & (uint8_t)iVar6) == 0) {
        uVar3 = *(undefined8 *)(iVar2 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c128d;
        iVar5 = fcn.1801e3b50(uVar3);
        if (iVar5 == 0) {
            uVar3 = *(undefined8 *)(iVar2 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c129d;
            iVar5 = fcn.1801e3ab0(uVar3);
            if (iVar5 != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 1);
                uVar3 = *(undefined8 *)(iVar2 + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c12b0;
                iVar5 = fcn.1801e3b00(uVar3, uVar1);
                return (uint64_t)(iVar5 != 0);
            }
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801c12e0
// Address: 0x1801c12e0
// Size: 15 bytes
// ============================================================
void fcn.1801c12e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c12ec;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
    if (in_EDX != 0) {
        iVar7 = *(int64_t *)(in_RCX + 0x78);
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar6 = *(int64_t *)(in_RCX + 0x80);
        uVar5 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c132a;
        uVar5 = fcn.1801e39c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1335;
        func_0x0001801e7fb0(uVar5, iVar6);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    if ((in_R8D != 0) && ((in_R9 & 1) != 0)) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1356;
        func_0x0001801e6170(uVar5);
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1376;
    iVar6 = func_0x0001801e39d0(uVar5);
    uVar9 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar7 + iVar4;
    pcVar2 = *(code **)(iVar6 + 0x28);
    uVar5 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar7 + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&arg_38h + iVar7 + iVar4, uVar5, uVar9);
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_40h + iVar7 + iVar4) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar5 = *(undefined8 *)(iVar6 + 0x38);
            uVar3 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd34d;
            func_0x00018026d610(uVar3, uVar5);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) ^ (int64_t)auStackX_18 + iVar7 + iVar4);
    return;
}

// ============================================================
// Function: FUN_1801c12ef
// Address: 0x1801c12ef
// Size: 20 bytes
// ============================================================
void fcn.1801c12e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c12ec;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
    if (in_EDX != 0) {
        iVar7 = *(int64_t *)(in_RCX + 0x78);
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar6 = *(int64_t *)(in_RCX + 0x80);
        uVar5 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c132a;
        uVar5 = fcn.1801e39c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1335;
        func_0x0001801e7fb0(uVar5, iVar6);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    if ((in_R8D != 0) && ((in_R9 & 1) != 0)) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1356;
        func_0x0001801e6170(uVar5);
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1376;
    iVar6 = func_0x0001801e39d0(uVar5);
    uVar9 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar7 + iVar4;
    pcVar2 = *(code **)(iVar6 + 0x28);
    uVar5 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar7 + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&arg_38h + iVar7 + iVar4, uVar5, uVar9);
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_40h + iVar7 + iVar4) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar5 = *(undefined8 *)(iVar6 + 0x38);
            uVar3 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd34d;
            func_0x00018026d610(uVar3, uVar5);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) ^ (int64_t)auStackX_18 + iVar7 + iVar4);
    return;
}

// ============================================================
// Function: FUN_1801c1303
// Address: 0x1801c1303
// Size: 19 bytes
// ============================================================
void fcn.1801c12e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c12ec;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
    if (in_EDX != 0) {
        iVar7 = *(int64_t *)(in_RCX + 0x78);
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar6 = *(int64_t *)(in_RCX + 0x80);
        uVar5 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c132a;
        uVar5 = fcn.1801e39c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1335;
        func_0x0001801e7fb0(uVar5, iVar6);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    if ((in_R8D != 0) && ((in_R9 & 1) != 0)) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1356;
        func_0x0001801e6170(uVar5);
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1376;
    iVar6 = func_0x0001801e39d0(uVar5);
    uVar9 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar7 + iVar4;
    pcVar2 = *(code **)(iVar6 + 0x28);
    uVar5 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar7 + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&arg_38h + iVar7 + iVar4, uVar5, uVar9);
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_40h + iVar7 + iVar4) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar5 = *(undefined8 *)(iVar6 + 0x38);
            uVar3 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd34d;
            func_0x00018026d610(uVar3, uVar5);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) ^ (int64_t)auStackX_18 + iVar7 + iVar4);
    return;
}

// ============================================================
// Function: FUN_1801c1316
// Address: 0x1801c1316
// Size: 36 bytes
// ============================================================
void fcn.1801c12e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c12ec;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
    if (in_EDX != 0) {
        iVar7 = *(int64_t *)(in_RCX + 0x78);
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar6 = *(int64_t *)(in_RCX + 0x80);
        uVar5 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c132a;
        uVar5 = fcn.1801e39c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1335;
        func_0x0001801e7fb0(uVar5, iVar6);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    if ((in_R8D != 0) && ((in_R9 & 1) != 0)) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1356;
        func_0x0001801e6170(uVar5);
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1376;
    iVar6 = func_0x0001801e39d0(uVar5);
    uVar9 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar7 + iVar4;
    pcVar2 = *(code **)(iVar6 + 0x28);
    uVar5 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar7 + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&arg_38h + iVar7 + iVar4, uVar5, uVar9);
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_40h + iVar7 + iVar4) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar5 = *(undefined8 *)(iVar6 + 0x38);
            uVar3 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd34d;
            func_0x00018026d610(uVar3, uVar5);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) ^ (int64_t)auStackX_18 + iVar7 + iVar4);
    return;
}

// ============================================================
// Function: FUN_1801c133a
// Address: 0x1801c133a
// Size: 10 bytes
// ============================================================
void fcn.1801c12e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c12ec;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
    if (in_EDX != 0) {
        iVar7 = *(int64_t *)(in_RCX + 0x78);
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar6 = *(int64_t *)(in_RCX + 0x80);
        uVar5 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c132a;
        uVar5 = fcn.1801e39c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1335;
        func_0x0001801e7fb0(uVar5, iVar6);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    if ((in_R8D != 0) && ((in_R9 & 1) != 0)) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1356;
        func_0x0001801e6170(uVar5);
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1376;
    iVar6 = func_0x0001801e39d0(uVar5);
    uVar9 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar7 + iVar4;
    pcVar2 = *(code **)(iVar6 + 0x28);
    uVar5 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar7 + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&arg_38h + iVar7 + iVar4, uVar5, uVar9);
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_40h + iVar7 + iVar4) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar5 = *(undefined8 *)(iVar6 + 0x38);
            uVar3 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd34d;
            func_0x00018026d610(uVar3, uVar5);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) ^ (int64_t)auStackX_18 + iVar7 + iVar4);
    return;
}

// ============================================================
// Function: FUN_1801c1344
// Address: 0x1801c1344
// Size: 35 bytes
// ============================================================
void fcn.1801c12e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c12ec;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
    if (in_EDX != 0) {
        iVar7 = *(int64_t *)(in_RCX + 0x78);
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar6 = *(int64_t *)(in_RCX + 0x80);
        uVar5 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c132a;
        uVar5 = fcn.1801e39c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1335;
        func_0x0001801e7fb0(uVar5, iVar6);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    if ((in_R8D != 0) && ((in_R9 & 1) != 0)) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1356;
        func_0x0001801e6170(uVar5);
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1376;
    iVar6 = func_0x0001801e39d0(uVar5);
    uVar9 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar7 + iVar4;
    pcVar2 = *(code **)(iVar6 + 0x28);
    uVar5 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar7 + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&arg_38h + iVar7 + iVar4, uVar5, uVar9);
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_40h + iVar7 + iVar4) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar5 = *(undefined8 *)(iVar6 + 0x38);
            uVar3 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd34d;
            func_0x00018026d610(uVar3, uVar5);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) ^ (int64_t)auStackX_18 + iVar7 + iVar4);
    return;
}

// ============================================================
// Function: FUN_1801c1367
// Address: 0x1801c1367
// Size: 36 bytes
// ============================================================
void fcn.1801c12e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t in_R9;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c12ec;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
    if (in_EDX != 0) {
        iVar7 = *(int64_t *)(in_RCX + 0x78);
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar6 = *(int64_t *)(in_RCX + 0x80);
        uVar5 = *(undefined8 *)(iVar7 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c132a;
        uVar5 = fcn.1801e39c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1335;
        func_0x0001801e7fb0(uVar5, iVar6);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    }
    if ((in_R8D != 0) && ((in_R9 & 1) != 0)) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1356;
        func_0x0001801e6170(uVar5);
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1376;
    iVar6 = func_0x0001801e39d0(uVar5);
    uVar9 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1801dd2bc;
    iVar7 = fcn.18045a350(iVar6, 0);
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar7 + iVar4;
    pcVar2 = *(code **)(iVar6 + 0x28);
    uVar5 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar7 + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&arg_38h + iVar7 + iVar4, uVar5, uVar9);
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 1);
    uVar8 = ((int32_t)*(char *)((int64_t)&arg_40h + iVar7 + iVar4) ^ *(uint32_t *)(iVar6 + 0x58)) & 1 ^
            *(uint32_t *)(iVar6 + 0x58);
    *(undefined8 *)(iVar6 + 0x20) = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4);
    uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
    cVar1 = *(char *)((int64_t)&arg_40h + iVar7 + iVar4 + 2);
    *(uint32_t *)(iVar6 + 0x58) = uVar8;
    if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(iVar6 + 0x50) != 0)) {
        if ((uVar8 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd334;
            func_0x0001801f81d0(iVar6 + 0x40);
            *(uint32_t *)(iVar6 + 0x58) = *(uint32_t *)(iVar6 + 0x58) | 0x20;
            if ((*(uint32_t *)(iVar6 + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar5 = *(undefined8 *)(iVar6 + 0x38);
            uVar3 = *(undefined8 *)(iVar6 + 0x48);
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd34d;
            func_0x00018026d610(uVar3, uVar5);
        } while ((*(uint8_t *)(iVar6 + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar4) = 0x1801dd365;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7 + iVar4) ^ (int64_t)auStackX_18 + iVar7 + iVar4);
    return;
}

// ============================================================
// Function: FUN_1801c1390
// Address: 0x1801c1390
// Size: 166 bytes
// ============================================================
undefined8 fcn.1801c1390(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c139e;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != 0) {
        if (*(int32_t *)(in_RCX + 0x34) != 0) {
            if (*(int32_t *)(in_RCX + 0x28) == 0) {
                if (*(int64_t *)(in_RCX + 0x18) != 0) {
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x18) + 0x128) = 1;
                }
            } else if (*(int64_t *)(in_RCX + 0x20) != 0) {
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x20) + 0xb8) = 1;
            }
        }
        if ((*(int32_t *)((int64_t)&arg_48h + iVar2) == 0xcf) && (*(int64_t *)(in_RCX + 0x18) != 0)) {
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801c1402;
            func_0x0001801e4c00(uVar1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801c1407;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801c1414;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 0x18), 
                  *(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801c142c;
    fcn.180229700(*(int64_t *)((int64_t)aiStackX_8 + iVar2 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 0x18), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801c1470
// Address: 0x1801c1470
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

uint64_t fcn.1801c1470(int64_t arg_28h, int64_t arg_88h, int64_t arg_a8h)
{
    int64_t iVar1;
    undefined4 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_24h;
    uint64_t uVar9;
    
    stack0xffffffffffffffe0 = 0x1801c148e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar9 = 0;
    uVar8 = 0;
    *in_R9 = 0;
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14ae;
    uVar6 = fcn.1801bdce0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5));
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    uVar7 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14c3;
    uVar7 = fcn.1801dd6c0(uVar7);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14cb;
    fcn.18026d890(uVar7);
    var_24h._0_4_ = 1;
    if ((int32_t)var_30h == 0) {
        if (var_40h != 0) {
            *(undefined4 *)(var_40h + 0x128) = 0;
        }
    } else if (var_38h != 0) {
        *(undefined4 *)(var_38h + 0xb8) = 0;
    }
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1500;
    iVar3 = fcn.1801c0be0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5));
    if (iVar3 < 1) goto code_r0x0001801c1767;
    if (var_38h == 0) {
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c151b;
        iVar3 = fcn.1801c0620(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000070 + iVar5));
        if (iVar3 == 0) goto code_r0x0001801c1767;
        var_38h = *(int64_t *)(var_40h + 0xb0);
    }
    uVar2 = (undefined4)arg_28h;
    uVar7 = *(undefined8 *)(var_38h + 0x80);
    *(undefined8 *)((int64_t)&arg_a8h + iVar5) = unaff_RSI;
    *(undefined4 *)((int64_t)&var_10h + iVar5) = (undefined4)arg_28h;
    *(int64_t **)((int64_t)&var_8h + iVar5) = in_R9;
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c155c;
    iVar3 = func_0x0001801c17a0(&var_58h, uVar7, in_RDX, in_R8);
    if (iVar3 == 0) goto code_r0x0001801c1767;
    if (*in_R9 != 0) {
        if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
            uVar7 = *(undefined8 *)(var_40h + 0xa0);
            *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1582;
            iVar3 = fcn.1801e3b50(uVar7);
            if (iVar3 == 0) {
                uVar4 = *(uint32_t *)(var_58h + 0x70);
                iVar1 = var_58h;
                while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                    iVar1 = *(int64_t *)(iVar1 + 0x40);
                    if (iVar1 == 0) goto code_r0x0001801c15bc;
                    uVar4 = *(uint32_t *)(iVar1 + 0x70);
                }
                if (uVar4 != 2) {
code_r0x0001801c15bc:
                    uVar7 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15c9;
                    uVar7 = fcn.1801dd6d0(uVar7);
                    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15d3;
                    func_0x0001801dd2b0(uVar7, 0);
                }
            }
        }
code_r0x0001801c15d3:
        uVar9 = 1;
        goto code_r0x0001801c1767;
    }
    if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
        uVar7 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15f6;
        iVar3 = fcn.1801e3b50(uVar7);
        if (iVar3 != 0) goto code_r0x0001801c1733;
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1607;
        iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar5));
        if (iVar3 == 0) {
            uVar4 = *(uint32_t *)(var_58h + 0x70);
            iVar1 = var_58h;
            while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                iVar1 = *(int64_t *)(iVar1 + 0x40);
                if (iVar1 == 0) goto code_r0x0001801c16bc;
                uVar4 = *(uint32_t *)(iVar1 + 0x70);
            }
            if (uVar4 != 2) {
code_r0x0001801c16bc:
                uVar7 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16c5;
                uVar7 = fcn.1801dd6d0(uVar7);
                *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16cf;
                func_0x0001801dd2b0(uVar7, 0);
            }
            *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar2;
            *(int64_t **)((int64_t)&var_8h + iVar5) = in_R9;
            uVar7 = *(undefined8 *)(var_38h + 0x80);
            *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16f2;
            iVar3 = func_0x0001801c17a0(&var_58h, uVar7, in_RDX, in_R8);
            if (iVar3 == 0) goto code_r0x0001801c1767;
            if (*in_R9 == 0) {
                uVar9 = uVar8;
                if ((int32_t)var_24h != 0) {
                    if ((int32_t)var_30h == 0) {
                        if (var_40h != 0) {
                            *(undefined4 *)(var_40h + 0x128) = 2;
                        }
                    } else if (var_38h != 0) {
                        *(undefined4 *)(var_38h + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c1767;
            }
            goto code_r0x0001801c15d3;
        }
        uVar7 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1643;
        fcn.1801dd840(uVar7, 0);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c164b;
        fcn.1801dd6d0(uVar7);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1661;
        iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
        if (iVar3 != 0) {
            uVar9 = (uint64_t)(-1 < iVar3);
            goto code_r0x0001801c1767;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0xc0103;
    } else {
code_r0x0001801c1733:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0xcf;
    }
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c175d;
    uVar4 = fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
    uVar9 = (uint64_t)uVar4;
code_r0x0001801c1767:
    uVar7 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1774;
    uVar7 = fcn.1801dd6c0(uVar7);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c177c;
    fcn.18026d900(uVar7);
    return uVar9;
}

// ============================================================
// Function: FUN_1801c153d
// Address: 0x1801c153d
// Size: 554 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

uint64_t fcn.1801c1470(int64_t arg_28h, int64_t arg_88h, int64_t arg_a8h)
{
    int64_t iVar1;
    undefined4 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_24h;
    uint64_t uVar9;
    
    stack0xffffffffffffffe0 = 0x1801c148e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar9 = 0;
    uVar8 = 0;
    *in_R9 = 0;
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14ae;
    uVar6 = fcn.1801bdce0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5));
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    uVar7 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14c3;
    uVar7 = fcn.1801dd6c0(uVar7);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14cb;
    fcn.18026d890(uVar7);
    var_24h._0_4_ = 1;
    if ((int32_t)var_30h == 0) {
        if (var_40h != 0) {
            *(undefined4 *)(var_40h + 0x128) = 0;
        }
    } else if (var_38h != 0) {
        *(undefined4 *)(var_38h + 0xb8) = 0;
    }
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1500;
    iVar3 = fcn.1801c0be0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5));
    if (iVar3 < 1) goto code_r0x0001801c1767;
    if (var_38h == 0) {
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c151b;
        iVar3 = fcn.1801c0620(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000070 + iVar5));
        if (iVar3 == 0) goto code_r0x0001801c1767;
        var_38h = *(int64_t *)(var_40h + 0xb0);
    }
    uVar2 = (undefined4)arg_28h;
    uVar7 = *(undefined8 *)(var_38h + 0x80);
    *(undefined8 *)((int64_t)&arg_a8h + iVar5) = unaff_RSI;
    *(undefined4 *)((int64_t)&var_10h + iVar5) = (undefined4)arg_28h;
    *(int64_t **)((int64_t)&var_8h + iVar5) = in_R9;
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c155c;
    iVar3 = func_0x0001801c17a0(&var_58h, uVar7, in_RDX, in_R8);
    if (iVar3 == 0) goto code_r0x0001801c1767;
    if (*in_R9 != 0) {
        if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
            uVar7 = *(undefined8 *)(var_40h + 0xa0);
            *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1582;
            iVar3 = fcn.1801e3b50(uVar7);
            if (iVar3 == 0) {
                uVar4 = *(uint32_t *)(var_58h + 0x70);
                iVar1 = var_58h;
                while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                    iVar1 = *(int64_t *)(iVar1 + 0x40);
                    if (iVar1 == 0) goto code_r0x0001801c15bc;
                    uVar4 = *(uint32_t *)(iVar1 + 0x70);
                }
                if (uVar4 != 2) {
code_r0x0001801c15bc:
                    uVar7 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15c9;
                    uVar7 = fcn.1801dd6d0(uVar7);
                    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15d3;
                    func_0x0001801dd2b0(uVar7, 0);
                }
            }
        }
code_r0x0001801c15d3:
        uVar9 = 1;
        goto code_r0x0001801c1767;
    }
    if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
        uVar7 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15f6;
        iVar3 = fcn.1801e3b50(uVar7);
        if (iVar3 != 0) goto code_r0x0001801c1733;
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1607;
        iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar5));
        if (iVar3 == 0) {
            uVar4 = *(uint32_t *)(var_58h + 0x70);
            iVar1 = var_58h;
            while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                iVar1 = *(int64_t *)(iVar1 + 0x40);
                if (iVar1 == 0) goto code_r0x0001801c16bc;
                uVar4 = *(uint32_t *)(iVar1 + 0x70);
            }
            if (uVar4 != 2) {
code_r0x0001801c16bc:
                uVar7 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16c5;
                uVar7 = fcn.1801dd6d0(uVar7);
                *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16cf;
                func_0x0001801dd2b0(uVar7, 0);
            }
            *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar2;
            *(int64_t **)((int64_t)&var_8h + iVar5) = in_R9;
            uVar7 = *(undefined8 *)(var_38h + 0x80);
            *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16f2;
            iVar3 = func_0x0001801c17a0(&var_58h, uVar7, in_RDX, in_R8);
            if (iVar3 == 0) goto code_r0x0001801c1767;
            if (*in_R9 == 0) {
                uVar9 = uVar8;
                if ((int32_t)var_24h != 0) {
                    if ((int32_t)var_30h == 0) {
                        if (var_40h != 0) {
                            *(undefined4 *)(var_40h + 0x128) = 2;
                        }
                    } else if (var_38h != 0) {
                        *(undefined4 *)(var_38h + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c1767;
            }
            goto code_r0x0001801c15d3;
        }
        uVar7 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1643;
        fcn.1801dd840(uVar7, 0);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c164b;
        fcn.1801dd6d0(uVar7);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1661;
        iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
        if (iVar3 != 0) {
            uVar9 = (uint64_t)(-1 < iVar3);
            goto code_r0x0001801c1767;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0xc0103;
    } else {
code_r0x0001801c1733:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0xcf;
    }
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c175d;
    uVar4 = fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
    uVar9 = (uint64_t)uVar4;
code_r0x0001801c1767:
    uVar7 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1774;
    uVar7 = fcn.1801dd6c0(uVar7);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c177c;
    fcn.18026d900(uVar7);
    return uVar9;
}

// ============================================================
// Function: FUN_1801c1767
// Address: 0x1801c1767
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

uint64_t fcn.1801c1470(int64_t arg_28h, int64_t arg_88h, int64_t arg_a8h)
{
    int64_t iVar1;
    undefined4 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_24h;
    uint64_t uVar9;
    
    stack0xffffffffffffffe0 = 0x1801c148e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar9 = 0;
    uVar8 = 0;
    *in_R9 = 0;
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14ae;
    uVar6 = fcn.1801bdce0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000030 + iVar5));
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    uVar7 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14c3;
    uVar7 = fcn.1801dd6c0(uVar7);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c14cb;
    fcn.18026d890(uVar7);
    var_24h._0_4_ = 1;
    if ((int32_t)var_30h == 0) {
        if (var_40h != 0) {
            *(undefined4 *)(var_40h + 0x128) = 0;
        }
    } else if (var_38h != 0) {
        *(undefined4 *)(var_38h + 0xb8) = 0;
    }
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1500;
    iVar3 = fcn.1801c0be0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5));
    if (iVar3 < 1) goto code_r0x0001801c1767;
    if (var_38h == 0) {
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c151b;
        iVar3 = fcn.1801c0620(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000070 + iVar5));
        if (iVar3 == 0) goto code_r0x0001801c1767;
        var_38h = *(int64_t *)(var_40h + 0xb0);
    }
    uVar2 = (undefined4)arg_28h;
    uVar7 = *(undefined8 *)(var_38h + 0x80);
    *(undefined8 *)((int64_t)&arg_a8h + iVar5) = unaff_RSI;
    *(undefined4 *)((int64_t)&var_10h + iVar5) = (undefined4)arg_28h;
    *(int64_t **)((int64_t)&var_8h + iVar5) = in_R9;
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c155c;
    iVar3 = func_0x0001801c17a0(&var_58h, uVar7, in_RDX, in_R8);
    if (iVar3 == 0) goto code_r0x0001801c1767;
    if (*in_R9 != 0) {
        if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
            uVar7 = *(undefined8 *)(var_40h + 0xa0);
            *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1582;
            iVar3 = fcn.1801e3b50(uVar7);
            if (iVar3 == 0) {
                uVar4 = *(uint32_t *)(var_58h + 0x70);
                iVar1 = var_58h;
                while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                    iVar1 = *(int64_t *)(iVar1 + 0x40);
                    if (iVar1 == 0) goto code_r0x0001801c15bc;
                    uVar4 = *(uint32_t *)(iVar1 + 0x70);
                }
                if (uVar4 != 2) {
code_r0x0001801c15bc:
                    uVar7 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15c9;
                    uVar7 = fcn.1801dd6d0(uVar7);
                    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15d3;
                    func_0x0001801dd2b0(uVar7, 0);
                }
            }
        }
code_r0x0001801c15d3:
        uVar9 = 1;
        goto code_r0x0001801c1767;
    }
    if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
        uVar7 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c15f6;
        iVar3 = fcn.1801e3b50(uVar7);
        if (iVar3 != 0) goto code_r0x0001801c1733;
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1607;
        iVar3 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar5));
        if (iVar3 == 0) {
            uVar4 = *(uint32_t *)(var_58h + 0x70);
            iVar1 = var_58h;
            while (uVar4 = uVar4 >> 5 & 3, uVar4 == 0) {
                iVar1 = *(int64_t *)(iVar1 + 0x40);
                if (iVar1 == 0) goto code_r0x0001801c16bc;
                uVar4 = *(uint32_t *)(iVar1 + 0x70);
            }
            if (uVar4 != 2) {
code_r0x0001801c16bc:
                uVar7 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16c5;
                uVar7 = fcn.1801dd6d0(uVar7);
                *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16cf;
                func_0x0001801dd2b0(uVar7, 0);
            }
            *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar2;
            *(int64_t **)((int64_t)&var_8h + iVar5) = in_R9;
            uVar7 = *(undefined8 *)(var_38h + 0x80);
            *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c16f2;
            iVar3 = func_0x0001801c17a0(&var_58h, uVar7, in_RDX, in_R8);
            if (iVar3 == 0) goto code_r0x0001801c1767;
            if (*in_R9 == 0) {
                uVar9 = uVar8;
                if ((int32_t)var_24h != 0) {
                    if ((int32_t)var_30h == 0) {
                        if (var_40h != 0) {
                            *(undefined4 *)(var_40h + 0x128) = 2;
                        }
                    } else if (var_38h != 0) {
                        *(undefined4 *)(var_38h + 0xb8) = 2;
                    }
                }
                goto code_r0x0001801c1767;
            }
            goto code_r0x0001801c15d3;
        }
        uVar7 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1643;
        fcn.1801dd840(uVar7, 0);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c164b;
        fcn.1801dd6d0(uVar7);
        *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1661;
        iVar3 = fcn.1801dcf10(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000060 + iVar5));
        if (iVar3 != 0) {
            uVar9 = (uint64_t)(-1 < iVar3);
            goto code_r0x0001801c1767;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0xc0103;
    } else {
code_r0x0001801c1733:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0xcf;
    }
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c175d;
    uVar4 = fcn.1801c1390(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
    uVar9 = (uint64_t)uVar4;
code_r0x0001801c1767:
    uVar7 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c1774;
    uVar7 = fcn.1801dd6c0(uVar7);
    *(undefined8 *)((int64_t)&var_24h + iVar5 + 4) = 0x1801c177c;
    fcn.18026d900(uVar7);
    return uVar9;
}

// ============================================================
// Function: FUN_1801c17a0
// Address: 0x1801c17a0
// Size: 628 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801c17a0(int64_t arg_28h, int64_t arg_78h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint32_t *puVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t aiStackX_8 [4];
    code *pcStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    pcStack_38 = (code *)0x1801c17b3;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_28h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    iVar2 = *(int64_t *)(in_RCX + 0x20);
    piVar3 = *(int64_t **)((int64_t)&arg_90h + iVar7);
    iVar4 = *(int64_t *)(in_RCX + 0x18);
    *(undefined4 *)((int64_t)aiStackX_8 + iVar7 + -8) = 0;
    if ((iVar2 == 0) || (*(int64_t *)(iVar2 + 0x80) == 0)) {
        uVar6 = 0xc0103;
        goto code_r0x0001801c19b9;
    }
    // switch table (7 cases) at 0x1801c19f8
    switch(*(undefined *)(*(int64_t *)(iVar2 + 0x80) + 0x102)) {
    default:
        uVar6 = 0x17b;
        break;
    case 1:
    case 2:
    case 3:
        uVar9 = *(undefined8 *)(in_RDX + 0x78);
        *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)aiStackX_8 + iVar7 + -8;
        if (*(int32_t *)((int64_t)&arg_98h + iVar7) == 0) {
            *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c18a5;
            iVar5 = func_0x0001801e6e30(uVar9, in_R8, in_R9, piVar3);
            if (iVar5 != 0) {
                if (*piVar3 != 0) {
                    uVar9 = *(undefined8 *)(iVar4 + 0xa0);
                    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c18d2;
                    uVar9 = fcn.1801e39f0(uVar9);
                    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c18df;
                    fcn.1801de220(uVar9, (int64_t)aiStackX_8 + iVar7);
                    iVar2 = *piVar3;
                    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c18f3;
                    iVar5 = func_0x0001801e5a40(in_RDX + 0xa0, iVar2, *(undefined8 *)((int64_t)aiStackX_8 + iVar7));
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xc0103;
                        goto code_r0x0001801c19c8;
                    }
                }
                if (*(int32_t *)((int64_t)aiStackX_8 + iVar7 + -8) != 0) {
                    uVar9 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0xa0);
                    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c1926;
                    uVar8 = fcn.1801e39c0(uVar9);
                    uVar9 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x20) + 0x80);
                    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c1939;
                    func_0x0001801e7ba0(uVar8, uVar9);
                }
                iVar2 = *piVar3;
                if (iVar2 != 0) {
                    uVar9 = *(undefined8 *)(iVar4 + 0xa0);
                    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c194a;
                    uVar9 = fcn.1801e39c0(uVar9);
                    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c1955;
                    func_0x0001801e7fb0(uVar9, in_RDX);
                    goto code_r0x0001801c1955;
                }
                goto code_r0x0001801c1958;
            }
            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xc0103;
        } else {
            *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c1880;
            iVar5 = func_0x0001801e6d40();
            if (iVar5 != 0) {
code_r0x0001801c1955:
                iVar2 = *piVar3;
code_r0x0001801c1958:
                if ((iVar2 != 0) || (*(int32_t *)((int64_t)aiStackX_8 + iVar7 + -8) == 0)) goto code_r0x0001801c19de;
                puVar1 = (uint32_t *)(*(int64_t *)(in_RCX + 0x20) + 0x88);
                *puVar1 = *puVar1 | 1;
                goto code_r0x0001801c196c;
            }
            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xc0103;
        }
        goto code_r0x0001801c19c8;
    case 4:
        *(uint32_t *)(iVar2 + 0x88) = *(uint32_t *)(iVar2 + 0x88) | 1;
code_r0x0001801c196c:
        if (*(int32_t *)(in_RCX + 0x34) != 0) {
            if (*(int32_t *)(in_RCX + 0x28) == 0) {
                if (*(int64_t *)(in_RCX + 0x18) != 0) {
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x18) + 0x128) = 6;
                }
            } else if (*(int64_t *)(in_RCX + 0x20) != 0) {
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x20) + 0xb8) = 6;
            }
        }
        goto code_r0x0001801c19de;
    case 5:
        uVar9 = *(undefined8 *)(*(int64_t *)(iVar2 + 0x78) + 0xa0);
        *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c1835;
        uVar8 = fcn.1801e39c0(uVar9);
        uVar9 = *(undefined8 *)(iVar2 + 0x80);
        *(code **)((int64_t)&pcStack_38 + iVar7) = case.0x1801c1823.6;
        func_0x0001801e7a30(uVar8, uVar9);
    case 6:
        uVar6 = 0x177;
    }
code_r0x0001801c19b9:
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar6;
code_r0x0001801c19c8:
    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c19de;
    fcn.1801c1390(*(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x10), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x18));
code_r0x0001801c19de:
    *(undefined8 *)((int64_t)&pcStack_38 + iVar7) = 0x1801c19eb;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

