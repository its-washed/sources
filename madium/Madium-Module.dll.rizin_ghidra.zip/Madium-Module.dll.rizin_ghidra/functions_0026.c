// Chunk 26 - 50 functions

// ============================================================
// Function: FUN_180050f90
// Address: 0x180050f90
// Size: 456 bytes
// ============================================================
void fcn.180050f90(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined8 *puVar10;
    undefined8 uVar11;
    int64_t var_10h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    uVar4 = *(undefined8 *)(arg1 + 0x30);
    uVar9 = (*(code *)0x69a3d8)(0, *(undefined8 *)(arg1 + 8), *(undefined8 *)(arg1 + 0x10), *(undefined4 *)(arg1 + 0x18)
                               );
    puVar10 = (undefined8 *)func_0x0001800137d0();
    uVar5 = *puVar10;
    puVar10 = (undefined8 *)func_0x000180459890(0x88);
    *(undefined4 *)(puVar10 + 1) = 1;
    *(undefined4 *)((int64_t)puVar10 + 0xc) = 1;
    *puVar10 = 0x180623990;
    uVar6 = *(undefined8 *)arg1;
    var_88h = 0x180623ee0;
    var_50h = (int64_t)&var_88h;
    *(undefined4 *)(puVar10 + 3) = 2;
    puVar10[2] = 0x180623918;
    puVar10[0xb] = 0;
    var_80h._0_4_ = uVar9;
    uVar11 = func_0x000180051270(&var_88h, puVar10 + 4);
    puVar10[0xb] = uVar11;
    puVar10[0xc] = uVar6;
    puVar10[0xd] = uVar4;
    puVar10[0xe] = 0;
    puVar10[0xf] = 0;
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x28) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    puVar10[0xe] = *(undefined8 *)(arg1 + 0x20);
    puVar10[0xf] = *(undefined8 *)(arg1 + 0x28);
    *(undefined *)(puVar10 + 0x10) = 0;
    *(undefined4 *)(puVar10 + 3) = 1;
    if (var_50h != 0) {
        (**(code **)(*(int64_t *)var_50h + 0x20))
                  (var_50h, CONCAT71((unkint7)((uint64_t)&var_88h >> 8), (int64_t *)var_50h != &var_88h));
    }
    var_98h = (int64_t)(puVar10 + 2);
    var_90h = (int64_t)puVar10;
    func_0x00018000a9d0(uVar5, &var_98h);
    iVar8 = var_90h;
    if (var_90h != 0) {
        LOCK();
        piVar1 = (int32_t *)(var_90h + 8);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (***(code ***)var_90h)(var_90h);
            LOCK();
            piVar1 = (int32_t *)(iVar8 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*(int64_t *)iVar8 + 8))(iVar8);
            }
        }
    }
    func_0x00018045476c();
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar7 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    func_0x000180459c3c(arg1, 0x38);
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_180051160
// Address: 0x180051160
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051160(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_18005116e
// Address: 0x18005116e
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051160(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_18005117c
// Address: 0x18005117c
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051160(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_1800511b2
// Address: 0x1800511b2
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051160(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_1800511c4
// Address: 0x1800511c4
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051160(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_1800511d0
// Address: 0x1800511d0
// Size: 108 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180051205: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018005120a)
// WARNING: Removing unreachable block (ram,0x000180051212)
// WARNING: Removing unreachable block (ram,0x000180051219)

int64_t fcn.1800511d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 unaff_RBX;
    undefined8 auStack_30 [6];
    
    if (0x7ffffffffffffff < (uint64_t)arg2) {
code_r0x000180051236:
        auStack_30[0] = 0x18005123b;
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        iVar3 = (*pcVar1)();
        return iVar3;
    }
    uVar4 = arg2 * 0x20;
    if (uVar4 == 0) {
        return 0;
    }
    if (0xfff < uVar4) {
        if (uVar4 + 0x27 <= uVar4) goto code_r0x000180051236;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18005120a;
        uVar4 = uVar4 + 0x27;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
    do {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598af;
        iVar3 = fcn.18046d050(uVar4);
        if (iVar3 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598a3;
        iVar2 = fcn.18047a460(uVar4);
    } while (iVar2 != 0);
    if (uVar4 == 0xffffffffffffffff) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598cb;
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        iVar3 = (*pcVar1)();
        return iVar3;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598c5;
    fcn.180454670();
    pcVar1 = (code *)swi(3);
    iVar3 = (*pcVar1)();
    return iVar3;
}

// ============================================================
// Function: FUN_180051250
// Address: 0x180051250
// Size: 28 bytes
// ============================================================
undefined8 fcn.180051250(int64_t arg1, int64_t arg2)
{
    fcn.1800865e0(*(undefined8 *)arg2, *(undefined4 *)(arg1 + 8));
    return 1;
}

// ============================================================
// Function: FUN_180051290
// Address: 0x180051290
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051290(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    piVar1 = (int32_t *)(arg1 + 0x60);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar5 = *piVar1 - (int32_t)piVar1;
        iVar3 = iVar5 * 2;
        if (iVar5 < 1) {
            iVar3 = iVar5 + 1;
        }
        func_0x000180093240(arg1, iVar3, 0);
    }
    uVar4 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar4) {
        **(uint64_t **)(arg1 + 0x18) = uVar4;
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar2 = *(int64_t **)(arg1 + 0x40);
    *piVar2 = arg2;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 10;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar5 = *piVar1 - (int32_t)piVar1;
        iVar3 = iVar5 * 2;
        if (iVar5 < 1) {
            iVar3 = iVar5 + 1;
        }
        func_0x000180093240(arg1, iVar3, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_1800512ac
// Address: 0x1800512ac
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051290(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    piVar1 = (int32_t *)(arg1 + 0x60);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar5 = *piVar1 - (int32_t)piVar1;
        iVar3 = iVar5 * 2;
        if (iVar5 < 1) {
            iVar3 = iVar5 + 1;
        }
        func_0x000180093240(arg1, iVar3, 0);
    }
    uVar4 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar4) {
        **(uint64_t **)(arg1 + 0x18) = uVar4;
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar2 = *(int64_t **)(arg1 + 0x40);
    *piVar2 = arg2;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 10;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar5 = *piVar1 - (int32_t)piVar1;
        iVar3 = iVar5 * 2;
        if (iVar5 < 1) {
            iVar3 = iVar5 + 1;
        }
        func_0x000180093240(arg1, iVar3, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180051339
// Address: 0x180051339
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180051290(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    piVar1 = (int32_t *)(arg1 + 0x60);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar5 = *piVar1 - (int32_t)piVar1;
        iVar3 = iVar5 * 2;
        if (iVar5 < 1) {
            iVar3 = iVar5 + 1;
        }
        func_0x000180093240(arg1, iVar3, 0);
    }
    uVar4 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar4) {
        **(uint64_t **)(arg1 + 0x18) = uVar4;
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar2 = *(int64_t **)(arg1 + 0x40);
    *piVar2 = arg2;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 10;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar5 = *piVar1 - (int32_t)piVar1;
        iVar3 = iVar5 * 2;
        if (iVar5 < 1) {
            iVar3 = iVar5 + 1;
        }
        func_0x000180093240(arg1, iVar3, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180051370
// Address: 0x180051370
// Size: 228 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180051370(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
        iVar6 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar3 = iVar6 * 2;
        if (iVar6 < 1) {
            iVar3 = iVar6 + 1;
        }
        func_0x000180093240(iVar1, iVar3, 0);
    }
    uVar4 = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar4) {
        **(uint64_t **)(iVar1 + 0x18) = uVar4;
    }
    func_0x000180086ba0(iVar1, arg1, 0);
    piVar5 = (int64_t *)func_0x000180024130(iVar1, 0x1807824b0, 2);
    if ((char)piVar5 != '\0') {
        piVar5 = (int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10);
        if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 10)) {
            *(int64_t **)(iVar1 + 0x40) = piVar5;
        } else {
            iVar2 = *piVar5;
            *(int64_t **)(iVar1 + 0x40) = piVar5;
            piVar5 = *(int64_t **)(iVar2 + 0x20);
            if (piVar5[0x3b] == iVar1) {
                *(int64_t *)arg2 = iVar2;
                return CONCAT71((unkint7)((uint64_t)piVar5 >> 8), 1);
            }
        }
    }
    return (uint64_t)piVar5 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_180051460
// Address: 0x180051460
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.180051460(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar1 = (int32_t *)(arg2 + 0x60);
    iVar13 = (int32_t)piVar1;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x21) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 2) {
            iVar10 = iVar14 + 2;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    uVar11 = *(int64_t *)(arg2 + 0x40) + 0x20;
    if (**(uint64_t **)(arg2 + 0x18) < uVar11) {
        **(uint64_t **)(arg2 + 0x18) = uVar11;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg1;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 7;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 1) {
            iVar10 = iVar14 + 1;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *(int64_t **)(arg2 + 0x40) = piVar2 + 2;
    iVar10 = *(int32_t *)((int64_t)piVar2 + 0xc);
    if (iVar10 == 6) {
        iVar10 = *(int32_t *)(*piVar2 + 0x14);
    } else if (iVar10 == 7) {
        iVar10 = func_0x0001800a1110(*piVar2);
    } else if ((iVar10 == 9) || (iVar10 == 0xb)) {
        iVar10 = *(int32_t *)(*piVar2 + 4);
    } else {
        iVar10 = 0;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg3;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 8;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar13 = *piVar1 - iVar13;
        iVar14 = iVar13 * 2;
        if (iVar13 < 1) {
            iVar14 = iVar13 + 1;
        }
        func_0x000180093240(arg2, iVar14, 0);
    }
    puVar3 = *(undefined4 **)(arg2 + 0x40);
    *(undefined4 **)(arg2 + 0x40) = puVar3 + 4;
    if (*(char *)(*(int64_t *)(puVar3 + -4) + 4) != '\0') {
        func_0x000180092f10(arg2);
        pcVar6 = (code *)swi(3);
        uVar11 = (*pcVar6)();
        return uVar11;
    }
    puVar12 = (undefined4 *)func_0x0001800a1010(arg2, *(int64_t *)(puVar3 + -4), iVar10 + 1);
    uVar7 = puVar3[1];
    uVar8 = puVar3[2];
    uVar9 = puVar3[3];
    *puVar12 = *puVar3;
    puVar12[1] = uVar7;
    puVar12[2] = uVar8;
    puVar12[3] = uVar9;
    if (5 < *(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4)) {
        iVar4 = *(int64_t *)(puVar3 + -4);
        if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar5 = *(int64_t *)(arg2 + 0x20);
            if (*(char *)(iVar5 + 0x59) == '\x02') {
                func_0x000180094420(iVar5);
            } else {
                *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                *(int64_t *)(iVar5 + 0x18) = iVar4;
            }
        }
    }
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x20;
    return (uint64_t)(iVar10 + 1);
}

// ============================================================
// Function: FUN_18005147e
// Address: 0x18005147e
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.180051460(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar1 = (int32_t *)(arg2 + 0x60);
    iVar13 = (int32_t)piVar1;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x21) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 2) {
            iVar10 = iVar14 + 2;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    uVar11 = *(int64_t *)(arg2 + 0x40) + 0x20;
    if (**(uint64_t **)(arg2 + 0x18) < uVar11) {
        **(uint64_t **)(arg2 + 0x18) = uVar11;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg1;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 7;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 1) {
            iVar10 = iVar14 + 1;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *(int64_t **)(arg2 + 0x40) = piVar2 + 2;
    iVar10 = *(int32_t *)((int64_t)piVar2 + 0xc);
    if (iVar10 == 6) {
        iVar10 = *(int32_t *)(*piVar2 + 0x14);
    } else if (iVar10 == 7) {
        iVar10 = func_0x0001800a1110(*piVar2);
    } else if ((iVar10 == 9) || (iVar10 == 0xb)) {
        iVar10 = *(int32_t *)(*piVar2 + 4);
    } else {
        iVar10 = 0;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg3;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 8;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar13 = *piVar1 - iVar13;
        iVar14 = iVar13 * 2;
        if (iVar13 < 1) {
            iVar14 = iVar13 + 1;
        }
        func_0x000180093240(arg2, iVar14, 0);
    }
    puVar3 = *(undefined4 **)(arg2 + 0x40);
    *(undefined4 **)(arg2 + 0x40) = puVar3 + 4;
    if (*(char *)(*(int64_t *)(puVar3 + -4) + 4) != '\0') {
        func_0x000180092f10(arg2);
        pcVar6 = (code *)swi(3);
        uVar11 = (*pcVar6)();
        return uVar11;
    }
    puVar12 = (undefined4 *)func_0x0001800a1010(arg2, *(int64_t *)(puVar3 + -4), iVar10 + 1);
    uVar7 = puVar3[1];
    uVar8 = puVar3[2];
    uVar9 = puVar3[3];
    *puVar12 = *puVar3;
    puVar12[1] = uVar7;
    puVar12[2] = uVar8;
    puVar12[3] = uVar9;
    if (5 < *(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4)) {
        iVar4 = *(int64_t *)(puVar3 + -4);
        if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar5 = *(int64_t *)(arg2 + 0x20);
            if (*(char *)(iVar5 + 0x59) == '\x02') {
                func_0x000180094420(iVar5);
            } else {
                *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                *(int64_t *)(iVar5 + 0x18) = iVar4;
            }
        }
    }
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x20;
    return (uint64_t)(iVar10 + 1);
}

// ============================================================
// Function: FUN_180051486
// Address: 0x180051486
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.180051460(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar1 = (int32_t *)(arg2 + 0x60);
    iVar13 = (int32_t)piVar1;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x21) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 2) {
            iVar10 = iVar14 + 2;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    uVar11 = *(int64_t *)(arg2 + 0x40) + 0x20;
    if (**(uint64_t **)(arg2 + 0x18) < uVar11) {
        **(uint64_t **)(arg2 + 0x18) = uVar11;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg1;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 7;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 1) {
            iVar10 = iVar14 + 1;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *(int64_t **)(arg2 + 0x40) = piVar2 + 2;
    iVar10 = *(int32_t *)((int64_t)piVar2 + 0xc);
    if (iVar10 == 6) {
        iVar10 = *(int32_t *)(*piVar2 + 0x14);
    } else if (iVar10 == 7) {
        iVar10 = func_0x0001800a1110(*piVar2);
    } else if ((iVar10 == 9) || (iVar10 == 0xb)) {
        iVar10 = *(int32_t *)(*piVar2 + 4);
    } else {
        iVar10 = 0;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg3;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 8;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar13 = *piVar1 - iVar13;
        iVar14 = iVar13 * 2;
        if (iVar13 < 1) {
            iVar14 = iVar13 + 1;
        }
        func_0x000180093240(arg2, iVar14, 0);
    }
    puVar3 = *(undefined4 **)(arg2 + 0x40);
    *(undefined4 **)(arg2 + 0x40) = puVar3 + 4;
    if (*(char *)(*(int64_t *)(puVar3 + -4) + 4) != '\0') {
        func_0x000180092f10(arg2);
        pcVar6 = (code *)swi(3);
        uVar11 = (*pcVar6)();
        return uVar11;
    }
    puVar12 = (undefined4 *)func_0x0001800a1010(arg2, *(int64_t *)(puVar3 + -4), iVar10 + 1);
    uVar7 = puVar3[1];
    uVar8 = puVar3[2];
    uVar9 = puVar3[3];
    *puVar12 = *puVar3;
    puVar12[1] = uVar7;
    puVar12[2] = uVar8;
    puVar12[3] = uVar9;
    if (5 < *(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4)) {
        iVar4 = *(int64_t *)(puVar3 + -4);
        if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar5 = *(int64_t *)(arg2 + 0x20);
            if (*(char *)(iVar5 + 0x59) == '\x02') {
                func_0x000180094420(iVar5);
            } else {
                *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                *(int64_t *)(iVar5 + 0x18) = iVar4;
            }
        }
    }
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x20;
    return (uint64_t)(iVar10 + 1);
}

// ============================================================
// Function: FUN_18005158a
// Address: 0x18005158a
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.180051460(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar1 = (int32_t *)(arg2 + 0x60);
    iVar13 = (int32_t)piVar1;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x21) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 2) {
            iVar10 = iVar14 + 2;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    uVar11 = *(int64_t *)(arg2 + 0x40) + 0x20;
    if (**(uint64_t **)(arg2 + 0x18) < uVar11) {
        **(uint64_t **)(arg2 + 0x18) = uVar11;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg1;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 7;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 1) {
            iVar10 = iVar14 + 1;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *(int64_t **)(arg2 + 0x40) = piVar2 + 2;
    iVar10 = *(int32_t *)((int64_t)piVar2 + 0xc);
    if (iVar10 == 6) {
        iVar10 = *(int32_t *)(*piVar2 + 0x14);
    } else if (iVar10 == 7) {
        iVar10 = func_0x0001800a1110(*piVar2);
    } else if ((iVar10 == 9) || (iVar10 == 0xb)) {
        iVar10 = *(int32_t *)(*piVar2 + 4);
    } else {
        iVar10 = 0;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg3;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 8;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar13 = *piVar1 - iVar13;
        iVar14 = iVar13 * 2;
        if (iVar13 < 1) {
            iVar14 = iVar13 + 1;
        }
        func_0x000180093240(arg2, iVar14, 0);
    }
    puVar3 = *(undefined4 **)(arg2 + 0x40);
    *(undefined4 **)(arg2 + 0x40) = puVar3 + 4;
    if (*(char *)(*(int64_t *)(puVar3 + -4) + 4) != '\0') {
        func_0x000180092f10(arg2);
        pcVar6 = (code *)swi(3);
        uVar11 = (*pcVar6)();
        return uVar11;
    }
    puVar12 = (undefined4 *)func_0x0001800a1010(arg2, *(int64_t *)(puVar3 + -4), iVar10 + 1);
    uVar7 = puVar3[1];
    uVar8 = puVar3[2];
    uVar9 = puVar3[3];
    *puVar12 = *puVar3;
    puVar12[1] = uVar7;
    puVar12[2] = uVar8;
    puVar12[3] = uVar9;
    if (5 < *(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4)) {
        iVar4 = *(int64_t *)(puVar3 + -4);
        if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar5 = *(int64_t *)(arg2 + 0x20);
            if (*(char *)(iVar5 + 0x59) == '\x02') {
                func_0x000180094420(iVar5);
            } else {
                *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                *(int64_t *)(iVar5 + 0x18) = iVar4;
            }
        }
    }
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x20;
    return (uint64_t)(iVar10 + 1);
}

// ============================================================
// Function: FUN_1800515cb
// Address: 0x1800515cb
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.180051460(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar1 = (int32_t *)(arg2 + 0x60);
    iVar13 = (int32_t)piVar1;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x21) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 2) {
            iVar10 = iVar14 + 2;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    uVar11 = *(int64_t *)(arg2 + 0x40) + 0x20;
    if (**(uint64_t **)(arg2 + 0x18) < uVar11) {
        **(uint64_t **)(arg2 + 0x18) = uVar11;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg1;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 7;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar14 = *piVar1 - iVar13;
        iVar10 = iVar14 * 2;
        if (iVar14 < 1) {
            iVar10 = iVar14 + 1;
        }
        func_0x000180093240(arg2, iVar10, 0);
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *(int64_t **)(arg2 + 0x40) = piVar2 + 2;
    iVar10 = *(int32_t *)((int64_t)piVar2 + 0xc);
    if (iVar10 == 6) {
        iVar10 = *(int32_t *)(*piVar2 + 0x14);
    } else if (iVar10 == 7) {
        iVar10 = func_0x0001800a1110(*piVar2);
    } else if ((iVar10 == 9) || (iVar10 == 0xb)) {
        iVar10 = *(int32_t *)(*piVar2 + 4);
    } else {
        iVar10 = 0;
    }
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    piVar2 = *(int64_t **)(arg2 + 0x40);
    *piVar2 = arg3;
    *(undefined4 *)((int64_t)piVar2 + 0xc) = 8;
    if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
        iVar13 = *piVar1 - iVar13;
        iVar14 = iVar13 * 2;
        if (iVar13 < 1) {
            iVar14 = iVar13 + 1;
        }
        func_0x000180093240(arg2, iVar14, 0);
    }
    puVar3 = *(undefined4 **)(arg2 + 0x40);
    *(undefined4 **)(arg2 + 0x40) = puVar3 + 4;
    if (*(char *)(*(int64_t *)(puVar3 + -4) + 4) != '\0') {
        func_0x000180092f10(arg2);
        pcVar6 = (code *)swi(3);
        uVar11 = (*pcVar6)();
        return uVar11;
    }
    puVar12 = (undefined4 *)func_0x0001800a1010(arg2, *(int64_t *)(puVar3 + -4), iVar10 + 1);
    uVar7 = puVar3[1];
    uVar8 = puVar3[2];
    uVar9 = puVar3[3];
    *puVar12 = *puVar3;
    puVar12[1] = uVar7;
    puVar12[2] = uVar8;
    puVar12[3] = uVar9;
    if (5 < *(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4)) {
        iVar4 = *(int64_t *)(puVar3 + -4);
        if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar5 = *(int64_t *)(arg2 + 0x20);
            if (*(char *)(iVar5 + 0x59) == '\x02') {
                func_0x000180094420(iVar5);
            } else {
                *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                *(int64_t *)(iVar5 + 0x18) = iVar4;
            }
        }
    }
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x20;
    return (uint64_t)(iVar10 + 1);
}

// ============================================================
// Function: FUN_180051680
// Address: 0x180051680
// Size: 313 bytes
// ============================================================
uint64_t fcn.180051680(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int32_t iVar15;
    int32_t iVar16;
    
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar13 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar13 = iVar16 + 2;
        }
        func_0x000180093240(arg1, iVar13, 0);
    }
    uVar11 = *(int64_t *)(arg1 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1 + 0x18) < uVar11) {
        **(uint64_t **)(arg1 + 0x18) = uVar11;
    }
    func_0x000180086ba0(arg1, arg3, 0);
    cVar9 = func_0x000180024130(arg1, arg2, 2);
    if (cVar9 == '\0') {
        func_0x000180086fd0(arg1, 0, 0);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar14 = (int64_t *)0x0;
        }
        fcn.180051460(*piVar14, arg1, arg4);
        func_0x000180086ba0(arg1, arg3, 0);
        uVar11 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        func_0x000180023f30(arg1, arg2, 2);
        func_0x000180085bf0(arg1, uVar11 & 0xffffffff);
        func_0x000180085bf0(arg1, (int32_t)uVar11 + -1);
        uVar11 = func_0x000180087440(arg1, 0xfffffffd);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
        return uVar11;
    }
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    piVar14 = piVar12;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar14 = (int64_t *)0x0;
    }
    iVar4 = *piVar14;
    *(int64_t **)(arg1 + 0x40) = piVar12;
    piVar1 = (int32_t *)(arg1 + 0x60);
    iVar13 = (int32_t)piVar1;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
        iVar15 = *piVar1 - iVar13;
        iVar16 = iVar15 * 2;
        if (iVar15 < 2) {
            iVar16 = iVar15 + 2;
        }
        func_0x000180093240(arg1, iVar16, 0);
    }
    uVar11 = *(int64_t *)(arg1 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1 + 0x18) < uVar11) {
        **(uint64_t **)(arg1 + 0x18) = uVar11;
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar14 = *(int64_t **)(arg1 + 0x40);
    *piVar14 = iVar4;
    *(undefined4 *)((int64_t)piVar14 + 0xc) = 7;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar15 = *piVar1 - iVar13;
        iVar16 = iVar15 * 2;
        if (iVar15 < 1) {
            iVar16 = iVar15 + 1;
        }
        func_0x000180093240(arg1, iVar16, 0);
    }
    piVar14 = *(int64_t **)(arg1 + 0x40);
    *(int64_t **)(arg1 + 0x40) = piVar14 + 2;
    iVar16 = *(int32_t *)((int64_t)piVar14 + 0xc);
    if (iVar16 == 6) {
        iVar16 = *(int32_t *)(*piVar14 + 0x14);
    } else if (iVar16 == 7) {
        iVar16 = func_0x0001800a1110(*piVar14);
    } else if ((iVar16 == 9) || (iVar16 == 0xb)) {
        iVar16 = *(int32_t *)(*piVar14 + 4);
    } else {
        iVar16 = 0;
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    piVar14 = *(int64_t **)(arg1 + 0x40);
    *piVar14 = arg4;
    *(undefined4 *)((int64_t)piVar14 + 0xc) = 8;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar13 = *piVar1 - iVar13;
        iVar15 = iVar13 * 2;
        if (iVar13 < 1) {
            iVar15 = iVar13 + 1;
        }
        func_0x000180093240(arg1, iVar15, 0);
    }
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    *(undefined4 **)(arg1 + 0x40) = puVar2 + 4;
    if (*(char *)(*(int64_t *)(puVar2 + -4) + 4) != '\0') {
        func_0x000180092f10(arg1);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(puVar2 + -4), iVar16 + 1);
    uVar6 = puVar2[1];
    uVar7 = puVar2[2];
    uVar8 = puVar2[3];
    *puVar10 = *puVar2;
    puVar10[1] = uVar6;
    puVar10[2] = uVar7;
    puVar10[3] = uVar8;
    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
        iVar4 = *(int64_t *)(puVar2 + -4);
        if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(arg1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420(iVar3);
            } else {
                *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar4;
            }
        }
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    return (uint64_t)(iVar16 + 1);
}

// ============================================================
// Function: FUN_1800517c0
// Address: 0x1800517c0
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_18005187c
// Address: 0x18005187c
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_18005188c
// Address: 0x18005188c
// Size: 802 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_180051bae
// Address: 0x180051bae
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_180051c3f
// Address: 0x180051c3f
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_180051c80
// Address: 0x180051c80
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_180051cb0
// Address: 0x180051cb0
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_180051cc4
// Address: 0x180051cc4
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800517c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined2 uVar2;
    undefined8 uVar3;
    int64_t arg1_00;
    undefined8 uVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    undefined4 uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_27h;
    
    if (19999 < *(int32_t *)(arg1 + 100)) {
        func_0x0001800933e0(arg1, 0x4f1a);
    }
    uVar3 = **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(arg1, iVar7, 0);
    }
    uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
    if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
        **(uint64_t **)(arg1 + 0x18) = uVar9;
    }
    func_0x000180086ba0(arg1, uVar3, 0);
    cVar6 = func_0x000180024130(arg1, 0x180782470, 2);
    if (cVar6 == '\0') {
code_r0x000180051cb4:
        func_0x000180088560(arg1, 0x180623f10);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    puVar15 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        *(undefined8 **)(arg1 + 0x40) = puVar15;
        goto code_r0x000180051cb4;
    }
    puVar13 = puVar15;
    if (puVar15 == *(undefined8 **)0x180782430) {
        puVar13 = (undefined8 *)0x0;
    }
    uVar3 = *puVar13;
    *(undefined8 **)(arg1 + 0x40) = puVar15;
    iVar10 = func_0x000180085760(arg1);
    arg1_00 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar7 = (int32_t)arg1_00;
    if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
        iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
        iVar12 = iVar16 * 2;
        if (iVar16 < 2) {
            iVar12 = iVar16 + 2;
        }
        func_0x000180093240(arg1_00, iVar12, 0);
    }
    uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
    if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
        **(uint64_t **)(arg1_00 + 0x18) = uVar9;
    }
    fcn.180051290(arg1_00, arg1);
    func_0x000180086ba0(arg1_00, iVar10, 0);
    uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
    func_0x000180023f30(arg1_00, 0x1807824b0, 2);
    func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
    func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
    func_0x000180087440(arg1_00, 0xfffffffd);
    *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    func_0x000180013530();
    uVar1 = *(uint8_t *)(arg1 + 1);
    *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xbf;
    uVar11 = *(uint8_t *)(iVar10 + 1);
    if ((uVar1 & 0x40) != 0) {
        uVar11 = uVar11 | 0x40;
        *(uint8_t *)(iVar10 + 1) = uVar11;
    }
    if (((*(int64_t *)(arg1 + 8) != 0) && (*(int64_t *)(iVar10 + 8) = *(int64_t *)(arg1 + 8), (uVar11 & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg1 + 8) + 1) & 3) != 0)) {
        iVar14 = *(int64_t *)(iVar10 + 0x20);
        if ((uint8_t)(*(char *)(iVar14 + 0x59) - 1U) < 3) {
            func_0x000180094420(iVar14);
        } else {
            *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar14 + 0x58) & 3 | uVar11 & 0xf8;
        }
    }
    fcn.180085610(arg1, 1);
    func_0x000180086ba0(arg1, **(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8), 0);
    cVar6 = func_0x000180024130(arg1, 0x180782488, 2);
    if (cVar6 == '\0') goto code_r0x000180051b76;
    iVar14 = *(int64_t *)(arg1 + 0x40);
    iVar12 = *(int32_t *)(iVar14 + -4);
    if (iVar12 == 6) {
        iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 0x14);
code_r0x000180051a3c:
        if (0 < iVar12) {
            func_0x000180086ed0(arg1, 0xffffffff, 1);
            iVar14 = *(int64_t *)(arg1 + 0x40);
            puVar15 = (undefined8 *)(iVar14 + -0x10);
            if ((puVar15 == *(undefined8 **)0x180782430) || (*(int32_t *)(iVar14 + -4) != 8)) {
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
            } else {
                if (puVar15 == *(undefined8 **)0x180782430) {
                    puVar15 = (undefined8 *)0x0;
                }
                uVar4 = *puVar15;
                *(int64_t *)(arg1 + 0x40) = iVar14 + -0x20;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x21) {
                    iVar16 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar12 = iVar16 * 2;
                    if (iVar16 < 2) {
                        iVar12 = iVar16 + 2;
                    }
                    func_0x000180093240(arg1_00, iVar12, 0);
                }
                uVar9 = *(int64_t *)(arg1_00 + 0x40) + 0x20;
                if (**(uint64_t **)(arg1_00 + 0x18) < uVar9) {
                    **(uint64_t **)(arg1_00 + 0x18) = uVar9;
                }
                puVar15 = *(undefined8 **)(arg1_00 + 0x40);
                *puVar15 = uVar4;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
                if (*(int64_t *)(arg1_00 + 0x30) - *(int64_t *)(arg1_00 + 0x40) < 0x11) {
                    iVar12 = *(int32_t *)(arg1_00 + 0x60) - (iVar7 + 0x60);
                    iVar7 = iVar12 * 2;
                    if (iVar12 < 1) {
                        iVar7 = iVar12 + 1;
                    }
                    func_0x000180093240(arg1_00, iVar7, 0);
                }
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + 0x10;
                func_0x000180086ba0(arg1_00, iVar10, 0);
                uVar9 = *(int64_t *)(arg1_00 + 0x40) - *(int64_t *)(arg1_00 + 0x28) >> 4;
                func_0x000180023f30(arg1_00, 0x1807824a8, 2);
                func_0x000180085bf0(arg1_00, uVar9 & 0xffffffff);
                func_0x000180085bf0(arg1_00, (int32_t)uVar9 + -1);
                func_0x000180087440(arg1_00, 0xfffffffd);
                *(int64_t *)(arg1_00 + 0x40) = *(int64_t *)(arg1_00 + 0x40) + -0x30;
            }
            goto code_r0x000180051b76;
        }
    } else {
        if (iVar12 == 7) {
            iVar12 = func_0x0001800a1110(*(undefined8 *)(iVar14 + -0x10));
            iVar14 = *(int64_t *)(arg1 + 0x40);
            goto code_r0x000180051a3c;
        }
        if ((iVar12 == 9) || (iVar12 == 0xb)) {
            iVar12 = *(int32_t *)(*(int64_t *)(iVar14 + -0x10) + 4);
            goto code_r0x000180051a3c;
        }
    }
    *(int64_t *)(arg1 + 0x40) = iVar14 + -0x10;
code_r0x000180051b76:
    uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180085610(iVar10, (int32_t)uVar9 + 1);
    puVar15 = *(undefined8 **)(iVar10 + 0x40);
    *puVar15 = uVar3;
    *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
    if (*(int64_t *)(iVar10 + 0x30) - *(int64_t *)(iVar10 + 0x40) < 0x11) {
        iVar12 = *(int32_t *)(iVar10 + 0x60) - ((int32_t)iVar10 + 0x60);
        iVar7 = iVar12 * 2;
        if (iVar12 < 1) {
            iVar7 = iVar12 + 1;
        }
        func_0x000180093240(iVar10, iVar7, 0);
    }
    *(int64_t *)(iVar10 + 0x40) = *(int64_t *)(iVar10 + 0x40) + 0x10;
    func_0x000180085680(arg1, iVar10, uVar9 & 0xffffffff);
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + 1;
    iVar7 = func_0x000180093d80(iVar10, 0, uVar9 & 0xffffffff);
    if (iVar7 == 0) {
        uVar2 = *(undefined2 *)(iVar10 + 0x68);
        uVar8 = fcn.180093190(iVar10, 0x180093a30, *(int64_t *)(iVar10 + 0x40) + (int64_t)(int32_t)uVar9 * -0x10);
        iVar7 = func_0x000180093ea0(iVar10, uVar8, uVar2);
    }
    *(int16_t *)(iVar10 + 0x6a) = *(int16_t *)(iVar10 + 0x6a) + -1;
    if (**(uint64_t **)(iVar10 + 0x18) < *(uint64_t *)(iVar10 + 0x40)) {
        **(uint64_t **)(iVar10 + 0x18) = *(uint64_t *)(iVar10 + 0x40);
    }
    if (iVar7 == 0) {
        uVar9 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
        if (0 < (int32_t)uVar9) {
            fcn.180085610(arg1, uVar9 & 0xffffffff);
            func_0x000180085680(iVar10, arg1, uVar9 & 0xffffffff);
        }
        return uVar9 & 0xffffffff;
    }
    if (iVar7 != 1) {
        iVar7 = func_0x0001800858b0(iVar10);
        if (0 < iVar7) {
            fcn.180085610(arg1, iVar7);
            func_0x000180085680(iVar10, arg1, iVar7);
        }
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar9 = (*pcVar5)();
        return uVar9;
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
        *(undefined *)(arg1 + 3) = 1;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_180051d10
// Address: 0x180051d10
// Size: 298 bytes
// ============================================================
void fcn.180051d10(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    char cVar4;
    int32_t iVar5;
    uint64_t uVar6;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    cVar4 = fcn.180051370(arg1, (int64_t)&var_68h);
    if (cVar4 != '\0') {
        cVar4 = *(char *)(var_68h + 3);
        iVar5 = (int32_t)arg2;
        if (((cVar4 == '\x01') || (cVar4 == '\x06')) || (cVar4 == '\x7f')) {
            uVar6 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            if (0 < (int32_t)uVar6) {
                fcn.180085610(var_68h, uVar6 & 0xffffffff);
                func_0x000180085680(arg1, var_68h, uVar6 & 0xffffffff);
            }
            iVar2 = *(int64_t *)(*(int64_t *)(var_68h + 0x50) + 0x98);
            func_0x0001800205e0(&var_60h, var_68h);
            var_70h = 0;
            if (iVar5 == 0) {
                uVar6 = uVar6 & 0xffffffff;
            } else {
                uVar6 = 0;
            }
            var_78h._0_1_ = iVar5 != 0;
            (**(code **)0x180782530)(iVar2 + 0x7f8, &var_50h, var_60h, uVar6);
            if (var_58h != 0) {
                LOCK();
                piVar1 = (int32_t *)(var_58h + 8);
                iVar5 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar5 == 1) {
                    (***(code ***)var_58h)(var_58h);
                    LOCK();
                    piVar1 = (int32_t *)(var_58h + 0xc);
                    iVar5 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar5 == 1) {
                        (**(code **)(*(int64_t *)var_58h + 8))(var_58h);
                    }
                }
            }
        } else if (iVar5 != 0) {
            fcn.180087960(var_68h);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    fcn.180459870(var_38h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_180051e40
// Address: 0x180051e40
// Size: 41 bytes
// ============================================================
undefined8 fcn.180051e40(int64_t arg1)
{
    undefined uVar1;
    int64_t var_10h;
    
    uVar1 = fcn.180051370(arg1, (int64_t)&var_10h);
    fcn.180086b20(arg1, uVar1);
    return 1;
}

// ============================================================
// Function: FUN_180051e70
// Address: 0x180051e70
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180051e70(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    char cVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    undefined8 *puVar7;
    int64_t unaff_RBX;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    func_0x000180086ba0(iVar1, arg1, 0);
    cVar3 = func_0x000180024130(iVar1, 0x1807824a8, 2);
    if (cVar3 != '\0') {
        puVar7 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) + -0x10);
        if ((puVar7 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) == 8)) {
            puVar5 = puVar7;
            if (puVar7 == *(undefined8 **)0x180782430) {
                puVar5 = (undefined8 *)0x0;
            }
            uVar6 = *puVar5;
            *(undefined8 **)(iVar1 + 0x40) = puVar7;
            fcn.180085610(arg1, 1);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar7 = *(undefined8 **)(arg1 + 0x40);
            *puVar7 = uVar6;
            *(undefined4 *)((int64_t)puVar7 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar8 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                iVar4 = iVar8 * 2;
                if (iVar8 < 1) {
                    iVar4 = iVar8 + 1;
                }
                func_0x000180093240(arg1, iVar4, 0);
            }
            goto code_r0x000180051f97;
        }
        *(undefined8 **)(iVar1 + 0x40) = puVar7;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBX);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
    }
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
code_r0x000180051f97:
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180051ed7
// Address: 0x180051ed7
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180051e70(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    char cVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    undefined8 *puVar7;
    int64_t unaff_RBX;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    func_0x000180086ba0(iVar1, arg1, 0);
    cVar3 = func_0x000180024130(iVar1, 0x1807824a8, 2);
    if (cVar3 != '\0') {
        puVar7 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) + -0x10);
        if ((puVar7 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) == 8)) {
            puVar5 = puVar7;
            if (puVar7 == *(undefined8 **)0x180782430) {
                puVar5 = (undefined8 *)0x0;
            }
            uVar6 = *puVar5;
            *(undefined8 **)(iVar1 + 0x40) = puVar7;
            fcn.180085610(arg1, 1);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar7 = *(undefined8 **)(arg1 + 0x40);
            *puVar7 = uVar6;
            *(undefined4 *)((int64_t)puVar7 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar8 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                iVar4 = iVar8 * 2;
                if (iVar8 < 1) {
                    iVar4 = iVar8 + 1;
                }
                func_0x000180093240(arg1, iVar4, 0);
            }
            goto code_r0x000180051f97;
        }
        *(undefined8 **)(iVar1 + 0x40) = puVar7;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBX);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
    }
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
code_r0x000180051f97:
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180051f38
// Address: 0x180051f38
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180051e70(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    char cVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    undefined8 *puVar7;
    int64_t unaff_RBX;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    func_0x000180086ba0(iVar1, arg1, 0);
    cVar3 = func_0x000180024130(iVar1, 0x1807824a8, 2);
    if (cVar3 != '\0') {
        puVar7 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) + -0x10);
        if ((puVar7 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) == 8)) {
            puVar5 = puVar7;
            if (puVar7 == *(undefined8 **)0x180782430) {
                puVar5 = (undefined8 *)0x0;
            }
            uVar6 = *puVar5;
            *(undefined8 **)(iVar1 + 0x40) = puVar7;
            fcn.180085610(arg1, 1);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar7 = *(undefined8 **)(arg1 + 0x40);
            *puVar7 = uVar6;
            *(undefined4 *)((int64_t)puVar7 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar8 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                iVar4 = iVar8 * 2;
                if (iVar8 < 1) {
                    iVar4 = iVar8 + 1;
                }
                func_0x000180093240(arg1, iVar4, 0);
            }
            goto code_r0x000180051f97;
        }
        *(undefined8 **)(iVar1 + 0x40) = puVar7;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBX);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
    }
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
code_r0x000180051f97:
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180051fd0
// Address: 0x180051fd0
// Size: 72 bytes
// ============================================================
undefined8 fcn.180051fd0(int64_t arg1)
{
    char cVar1;
    int64_t var_10h;
    
    var_10h = 0;
    cVar1 = fcn.180051370(arg1, (int64_t)&var_10h);
    if (cVar1 == '\0') {
        fcn.180086510();
        return 1;
    }
    fcn.180051290(arg1, var_10h);
    return 1;
}

// ============================================================
// Function: FUN_180052020
// Address: 0x180052020
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005207b
// Address: 0x18005207b
// Size: 282 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_180052195
// Address: 0x180052195
// Size: 419 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_180052338
// Address: 0x180052338
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005241d
// Address: 0x18005241d
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_180052431
// Address: 0x180052431
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_180052455
// Address: 0x180052455
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005246d
// Address: 0x18005246d
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.180052020(int64_t arg1)
{
    int32_t *piVar1;
    int64_t arg3;
    int64_t arg4;
    int64_t arg4_00;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined4 uVar15;
    int64_t var_3h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_58h;
    int64_t var_48h;
    int64_t in_stack_ffffffffffffffc0;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar14 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar14 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    piVar7 = piVar12 + 2;
    piVar8 = piVar7;
    if (piVar14 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
        func_0x000180088470(arg1, 2, 8);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar12) {
        piVar12 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = piVar8;
    }
    arg3 = *piVar12;
    if (*(char *)(arg3 + 3) == '\0') {
        func_0x000180088380(arg1, 1, 0x180623f20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (piVar14 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        piVar7 = piVar8;
    }
    aiStackX_18[0] = *piVar7;
    if (*(char *)(aiStackX_18[0] + 3) == '\0') {
        func_0x0001800869f0(arg1, 0x180025870, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x000180087810(arg1, 1);
        piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        piVar12 = piVar14;
        if (piVar14 == *(int64_t **)0x180782430) {
            piVar12 = piVar8;
        }
        arg4 = *piVar12;
        *(int64_t **)(arg1 + 0x40) = piVar14;
        unique0x100004a3 = arg4;
        func_0x0001800869f0(arg1, 0x1800252a0, 0, 0, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar5 = fcn.180085510(in_stack_ffffffffffffffc0), iVar5 != 0)) {
            piVar12 = *(int64_t **)(arg1 + 0x40);
            piVar14 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (piVar12 <= piVar14) {
                piVar14 = *(int64_t **)0x180782430;
            }
            uVar15 = *(undefined4 *)((int64_t)piVar14 + 4);
            uVar3 = *(undefined4 *)(piVar14 + 1);
            uVar4 = *(undefined4 *)((int64_t)piVar14 + 0xc);
            *(undefined4 *)piVar12 = *(undefined4 *)piVar14;
            *(undefined4 *)((int64_t)piVar12 + 4) = uVar15;
            *(undefined4 *)(piVar12 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar4;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087810(arg1, 1);
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = piVar8;
            }
            arg4_00 = *piVar12;
            *(int64_t *)(arg4_00 + 0x28) = (int64_t)fcn.180051d10 - (int64_t)(int64_t *)(arg4_00 + 0x28);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_10h = arg4_00;
            fcn.180051680(arg1, 0x1807824a0, arg3, arg4_00);
            piVar1 = (int32_t *)(arg1 + 0x60);
            iVar5 = (int32_t)piVar1;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 2) {
                    iVar6 = iVar11 + 2;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            piVar12 = *(int64_t **)(arg1 + 0x40);
            *piVar12 = arg4_00;
            *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar11 = *piVar1 - iVar5;
                iVar6 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar6 = iVar11 + 1;
                }
                func_0x000180093240(arg1, iVar6, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180086ba0(arg1, arg3, 0);
            uVar9 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180023f30(arg1, 0x180782470, 2);
            func_0x000180085bf0(arg1, uVar9 & 0xffffffff);
            func_0x000180085bf0(arg1, (int32_t)uVar9 + -1);
            func_0x000180087440(arg1, 0xfffffffd);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
            uVar15 = fcn.180051680(arg1, 0x180782488, arg3, arg4);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, (int64_t)&var_3h + 5);
            uVar15 = func_0x000180052b00(uVar15, &var_48h, &var_10h);
            func_0x000180052b00(uVar15, &var_48h, aiStackX_18);
            *(code **)(arg3 + 0x20) = fcn.1800517c0;
            if (((*(char *)0x180777010 == '\0') ||
                ((uint64_t)
                 ((int64_t)-(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * 0x10 +
                 *(int64_t *)(arg1 + 0x40)) <= **(uint64_t **)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_ffffffffffffffc0), iVar6 != 0)) {
                uVar9 = *(uint64_t *)(arg1 + 0x40);
                uVar13 = *(uint64_t *)(arg1 + 0x28);
                if (uVar9 < uVar13) {
                    do {
                        *(undefined4 *)(uVar9 + 0xc) = 0;
                        uVar9 = *(int64_t *)(arg1 + 0x40) + 0x10;
                        *(uint64_t *)(arg1 + 0x40) = uVar9;
                        uVar13 = *(uint64_t *)(arg1 + 0x28);
                    } while (uVar9 < uVar13);
                }
                *(uint64_t *)(arg1 + 0x40) = uVar13;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar12 = *(int64_t **)(arg1 + 0x40);
                *piVar12 = stack0x00000008;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = 8;
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar5 = *piVar1 - iVar5;
                    iVar6 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar6 = iVar5 + 1;
                    }
                    func_0x000180093240(arg1, iVar6, 0);
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                return 1;
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    func_0x000180088380(arg1, 2, 0x180623f50);
    pcVar2 = (code *)swi(3);
    uVar10 = (*pcVar2)();
    return uVar10;
}

// ============================================================
// Function: FUN_180052490
// Address: 0x180052490
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180052490(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    char cVar10;
    int32_t iVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t unaff_RBP;
    undefined4 *puVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar12 = piVar15;
    if (piVar1 <= piVar15) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar12 + 0xc) == 8)) {
        if (piVar1 <= piVar15) {
            piVar15 = *(int64_t **)0x180782430;
        }
        if (piVar15 == *(int64_t **)0x180782430) {
            piVar15 = (int64_t *)0x0;
        }
        iVar2 = *piVar15;
        if (((*(char *)0x180777010 == '\0') || (piVar1 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
            puVar16 = *(undefined4 **)(arg1 + 0x40);
            *puVar16 = 0;
            puVar16[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (*(char *)(iVar2 + 3) == '\0') {
                return 1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                piVar15 = *(int64_t **)(arg1 + 0x40);
                *piVar15 = iVar2;
                *(undefined4 *)(piVar15 + 1) = 0;
                *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                cVar10 = func_0x000180024130(arg1, 0x1807824a0, 2);
                if (cVar10 == '\0') {
                    return 1;
                }
                iVar3 = *(int64_t *)(arg1 + 0x40);
                iVar11 = *(int32_t *)(iVar3 + -4);
                if (iVar11 == 6) {
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
                } else if (iVar11 == 7) {
                    iVar11 = func_0x0001800a1110(*(undefined8 *)(iVar3 + -0x10));
                } else {
                    if ((iVar11 != 9) && (iVar11 != 0xb)) {
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        return 1;
                    }
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 4);
                }
                uVar4 = *(uint64_t *)(arg1 + 0x40);
                *(uint64_t *)(arg1 + 0x40) = uVar4 - 0x10;
                if (iVar11 == 0) {
                    return 1;
                }
                if (((*(char *)0x180777010 == '\0') || (uVar4 <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                    piVar15 = *(int64_t **)(arg1 + 0x40);
                    *piVar15 = iVar2;
                    *(undefined4 *)(piVar15 + 1) = 0;
                    *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    cVar10 = func_0x000180024130(arg1, 0x180782488, 2);
                    if (cVar10 == '\0') {
                        return 1;
                    }
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    if (((*(char *)0x180777010 == '\0') ||
                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                        puVar16 = *(undefined4 **)(arg1 + 0x40);
                        puVar13 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar16 + -4), 1);
                        piVar1 = *(int64_t **)0x180782430;
                        uVar7 = puVar13[1];
                        uVar8 = puVar13[2];
                        uVar9 = puVar13[3];
                        *puVar16 = *puVar13;
                        puVar16[1] = uVar7;
                        puVar16[2] = uVar8;
                        puVar16[3] = uVar9;
                        piVar15 = *(int64_t **)(arg1 + 0x40);
                        *(int64_t **)(arg1 + 0x40) = piVar15 + 2;
                        if ((piVar15 == piVar1) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
                            *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                            return 1;
                        }
                        piVar12 = piVar15;
                        if (piVar15 == piVar1) {
                            piVar12 = (int64_t *)0x0;
                        }
                        iVar3 = *piVar12;
                        *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                        *(undefined8 *)(iVar2 + 0x20) = *(undefined8 *)(iVar3 + 0x20);
                        *(int64_t *)(iVar2 + 0x28) =
                             ((iVar3 + 0x28) - (int64_t)(int64_t *)(iVar2 + 0x28)) + *(int64_t *)(iVar3 + 0x28);
                        if (((*(char *)0x180777010 == '\0') ||
                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                            puVar5 = *(undefined8 **)(arg1 + 0x40);
                            *puVar5 = 0x180782488;
                            *(undefined4 *)(puVar5 + 1) = 0;
                            *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                            if (((*(char *)0x180777010 == '\0') ||
                                (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                               (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                func_0x000180087440(arg1, 0xffffd8f0);
                                if (((*(char *)0x180777010 == '\0') ||
                                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                    puVar5 = *(undefined8 **)(arg1 + 0x40);
                                    *puVar5 = 0x1807824a0;
                                    *(undefined4 *)(puVar5 + 1) = 0;
                                    *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                    if (((*(char *)0x180777010 == '\0') ||
                                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                        func_0x000180087440(arg1, 0xffffd8f0);
                                        func_0x000180086ba0(arg1, iVar2, 0);
                                        iVar2 = *(int64_t *)(arg1 + 0x40);
                                        iVar3 = *(int64_t *)(arg1 + 0x28);
                                        func_0x000180023f30(arg1, 0x180782470, 2);
                                        func_0x000180085bf0(arg1, iVar2 - iVar3 >> 4 & 0xffffffff);
                                        fcn.180086510(arg1);
                                        func_0x000180087440(arg1, 0xfffffffd);
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
                                        if (((*(char *)0x180777010 == '\0') ||
                                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                            puVar16 = *(undefined4 **)(arg1 + 0x40);
                                            *puVar16 = 1;
                                            puVar16[3] = 1;
                                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar6 = (code *)swi(3);
        uVar14 = (*pcVar6)();
        return uVar14;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_1800524c8
// Address: 0x1800524c8
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180052490(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    char cVar10;
    int32_t iVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t unaff_RBP;
    undefined4 *puVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar12 = piVar15;
    if (piVar1 <= piVar15) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar12 + 0xc) == 8)) {
        if (piVar1 <= piVar15) {
            piVar15 = *(int64_t **)0x180782430;
        }
        if (piVar15 == *(int64_t **)0x180782430) {
            piVar15 = (int64_t *)0x0;
        }
        iVar2 = *piVar15;
        if (((*(char *)0x180777010 == '\0') || (piVar1 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
            puVar16 = *(undefined4 **)(arg1 + 0x40);
            *puVar16 = 0;
            puVar16[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (*(char *)(iVar2 + 3) == '\0') {
                return 1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                piVar15 = *(int64_t **)(arg1 + 0x40);
                *piVar15 = iVar2;
                *(undefined4 *)(piVar15 + 1) = 0;
                *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                cVar10 = func_0x000180024130(arg1, 0x1807824a0, 2);
                if (cVar10 == '\0') {
                    return 1;
                }
                iVar3 = *(int64_t *)(arg1 + 0x40);
                iVar11 = *(int32_t *)(iVar3 + -4);
                if (iVar11 == 6) {
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
                } else if (iVar11 == 7) {
                    iVar11 = func_0x0001800a1110(*(undefined8 *)(iVar3 + -0x10));
                } else {
                    if ((iVar11 != 9) && (iVar11 != 0xb)) {
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        return 1;
                    }
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 4);
                }
                uVar4 = *(uint64_t *)(arg1 + 0x40);
                *(uint64_t *)(arg1 + 0x40) = uVar4 - 0x10;
                if (iVar11 == 0) {
                    return 1;
                }
                if (((*(char *)0x180777010 == '\0') || (uVar4 <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                    piVar15 = *(int64_t **)(arg1 + 0x40);
                    *piVar15 = iVar2;
                    *(undefined4 *)(piVar15 + 1) = 0;
                    *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    cVar10 = func_0x000180024130(arg1, 0x180782488, 2);
                    if (cVar10 == '\0') {
                        return 1;
                    }
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    if (((*(char *)0x180777010 == '\0') ||
                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                        puVar16 = *(undefined4 **)(arg1 + 0x40);
                        puVar13 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar16 + -4), 1);
                        piVar1 = *(int64_t **)0x180782430;
                        uVar7 = puVar13[1];
                        uVar8 = puVar13[2];
                        uVar9 = puVar13[3];
                        *puVar16 = *puVar13;
                        puVar16[1] = uVar7;
                        puVar16[2] = uVar8;
                        puVar16[3] = uVar9;
                        piVar15 = *(int64_t **)(arg1 + 0x40);
                        *(int64_t **)(arg1 + 0x40) = piVar15 + 2;
                        if ((piVar15 == piVar1) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
                            *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                            return 1;
                        }
                        piVar12 = piVar15;
                        if (piVar15 == piVar1) {
                            piVar12 = (int64_t *)0x0;
                        }
                        iVar3 = *piVar12;
                        *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                        *(undefined8 *)(iVar2 + 0x20) = *(undefined8 *)(iVar3 + 0x20);
                        *(int64_t *)(iVar2 + 0x28) =
                             ((iVar3 + 0x28) - (int64_t)(int64_t *)(iVar2 + 0x28)) + *(int64_t *)(iVar3 + 0x28);
                        if (((*(char *)0x180777010 == '\0') ||
                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                            puVar5 = *(undefined8 **)(arg1 + 0x40);
                            *puVar5 = 0x180782488;
                            *(undefined4 *)(puVar5 + 1) = 0;
                            *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                            if (((*(char *)0x180777010 == '\0') ||
                                (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                               (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                func_0x000180087440(arg1, 0xffffd8f0);
                                if (((*(char *)0x180777010 == '\0') ||
                                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                    puVar5 = *(undefined8 **)(arg1 + 0x40);
                                    *puVar5 = 0x1807824a0;
                                    *(undefined4 *)(puVar5 + 1) = 0;
                                    *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                    if (((*(char *)0x180777010 == '\0') ||
                                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                        func_0x000180087440(arg1, 0xffffd8f0);
                                        func_0x000180086ba0(arg1, iVar2, 0);
                                        iVar2 = *(int64_t *)(arg1 + 0x40);
                                        iVar3 = *(int64_t *)(arg1 + 0x28);
                                        func_0x000180023f30(arg1, 0x180782470, 2);
                                        func_0x000180085bf0(arg1, iVar2 - iVar3 >> 4 & 0xffffffff);
                                        fcn.180086510(arg1);
                                        func_0x000180087440(arg1, 0xfffffffd);
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
                                        if (((*(char *)0x180777010 == '\0') ||
                                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                            puVar16 = *(undefined4 **)(arg1 + 0x40);
                                            *puVar16 = 1;
                                            puVar16[3] = 1;
                                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar6 = (code *)swi(3);
        uVar14 = (*pcVar6)();
        return uVar14;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_1800525cf
// Address: 0x1800525cf
// Size: 765 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180052490(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    char cVar10;
    int32_t iVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t unaff_RBP;
    undefined4 *puVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar12 = piVar15;
    if (piVar1 <= piVar15) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar12 + 0xc) == 8)) {
        if (piVar1 <= piVar15) {
            piVar15 = *(int64_t **)0x180782430;
        }
        if (piVar15 == *(int64_t **)0x180782430) {
            piVar15 = (int64_t *)0x0;
        }
        iVar2 = *piVar15;
        if (((*(char *)0x180777010 == '\0') || (piVar1 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
            puVar16 = *(undefined4 **)(arg1 + 0x40);
            *puVar16 = 0;
            puVar16[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (*(char *)(iVar2 + 3) == '\0') {
                return 1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                piVar15 = *(int64_t **)(arg1 + 0x40);
                *piVar15 = iVar2;
                *(undefined4 *)(piVar15 + 1) = 0;
                *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                cVar10 = func_0x000180024130(arg1, 0x1807824a0, 2);
                if (cVar10 == '\0') {
                    return 1;
                }
                iVar3 = *(int64_t *)(arg1 + 0x40);
                iVar11 = *(int32_t *)(iVar3 + -4);
                if (iVar11 == 6) {
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
                } else if (iVar11 == 7) {
                    iVar11 = func_0x0001800a1110(*(undefined8 *)(iVar3 + -0x10));
                } else {
                    if ((iVar11 != 9) && (iVar11 != 0xb)) {
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        return 1;
                    }
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 4);
                }
                uVar4 = *(uint64_t *)(arg1 + 0x40);
                *(uint64_t *)(arg1 + 0x40) = uVar4 - 0x10;
                if (iVar11 == 0) {
                    return 1;
                }
                if (((*(char *)0x180777010 == '\0') || (uVar4 <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                    piVar15 = *(int64_t **)(arg1 + 0x40);
                    *piVar15 = iVar2;
                    *(undefined4 *)(piVar15 + 1) = 0;
                    *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    cVar10 = func_0x000180024130(arg1, 0x180782488, 2);
                    if (cVar10 == '\0') {
                        return 1;
                    }
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    if (((*(char *)0x180777010 == '\0') ||
                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                        puVar16 = *(undefined4 **)(arg1 + 0x40);
                        puVar13 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar16 + -4), 1);
                        piVar1 = *(int64_t **)0x180782430;
                        uVar7 = puVar13[1];
                        uVar8 = puVar13[2];
                        uVar9 = puVar13[3];
                        *puVar16 = *puVar13;
                        puVar16[1] = uVar7;
                        puVar16[2] = uVar8;
                        puVar16[3] = uVar9;
                        piVar15 = *(int64_t **)(arg1 + 0x40);
                        *(int64_t **)(arg1 + 0x40) = piVar15 + 2;
                        if ((piVar15 == piVar1) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
                            *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                            return 1;
                        }
                        piVar12 = piVar15;
                        if (piVar15 == piVar1) {
                            piVar12 = (int64_t *)0x0;
                        }
                        iVar3 = *piVar12;
                        *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                        *(undefined8 *)(iVar2 + 0x20) = *(undefined8 *)(iVar3 + 0x20);
                        *(int64_t *)(iVar2 + 0x28) =
                             ((iVar3 + 0x28) - (int64_t)(int64_t *)(iVar2 + 0x28)) + *(int64_t *)(iVar3 + 0x28);
                        if (((*(char *)0x180777010 == '\0') ||
                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                            puVar5 = *(undefined8 **)(arg1 + 0x40);
                            *puVar5 = 0x180782488;
                            *(undefined4 *)(puVar5 + 1) = 0;
                            *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                            if (((*(char *)0x180777010 == '\0') ||
                                (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                               (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                func_0x000180087440(arg1, 0xffffd8f0);
                                if (((*(char *)0x180777010 == '\0') ||
                                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                    puVar5 = *(undefined8 **)(arg1 + 0x40);
                                    *puVar5 = 0x1807824a0;
                                    *(undefined4 *)(puVar5 + 1) = 0;
                                    *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                    if (((*(char *)0x180777010 == '\0') ||
                                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                        func_0x000180087440(arg1, 0xffffd8f0);
                                        func_0x000180086ba0(arg1, iVar2, 0);
                                        iVar2 = *(int64_t *)(arg1 + 0x40);
                                        iVar3 = *(int64_t *)(arg1 + 0x28);
                                        func_0x000180023f30(arg1, 0x180782470, 2);
                                        func_0x000180085bf0(arg1, iVar2 - iVar3 >> 4 & 0xffffffff);
                                        fcn.180086510(arg1);
                                        func_0x000180087440(arg1, 0xfffffffd);
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
                                        if (((*(char *)0x180777010 == '\0') ||
                                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                            puVar16 = *(undefined4 **)(arg1 + 0x40);
                                            *puVar16 = 1;
                                            puVar16[3] = 1;
                                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar6 = (code *)swi(3);
        uVar14 = (*pcVar6)();
        return uVar14;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_1800528cc
// Address: 0x1800528cc
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180052490(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    char cVar10;
    int32_t iVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t unaff_RBP;
    undefined4 *puVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar12 = piVar15;
    if (piVar1 <= piVar15) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar12 + 0xc) == 8)) {
        if (piVar1 <= piVar15) {
            piVar15 = *(int64_t **)0x180782430;
        }
        if (piVar15 == *(int64_t **)0x180782430) {
            piVar15 = (int64_t *)0x0;
        }
        iVar2 = *piVar15;
        if (((*(char *)0x180777010 == '\0') || (piVar1 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
            puVar16 = *(undefined4 **)(arg1 + 0x40);
            *puVar16 = 0;
            puVar16[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (*(char *)(iVar2 + 3) == '\0') {
                return 1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                piVar15 = *(int64_t **)(arg1 + 0x40);
                *piVar15 = iVar2;
                *(undefined4 *)(piVar15 + 1) = 0;
                *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                cVar10 = func_0x000180024130(arg1, 0x1807824a0, 2);
                if (cVar10 == '\0') {
                    return 1;
                }
                iVar3 = *(int64_t *)(arg1 + 0x40);
                iVar11 = *(int32_t *)(iVar3 + -4);
                if (iVar11 == 6) {
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
                } else if (iVar11 == 7) {
                    iVar11 = func_0x0001800a1110(*(undefined8 *)(iVar3 + -0x10));
                } else {
                    if ((iVar11 != 9) && (iVar11 != 0xb)) {
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        return 1;
                    }
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 4);
                }
                uVar4 = *(uint64_t *)(arg1 + 0x40);
                *(uint64_t *)(arg1 + 0x40) = uVar4 - 0x10;
                if (iVar11 == 0) {
                    return 1;
                }
                if (((*(char *)0x180777010 == '\0') || (uVar4 <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                    piVar15 = *(int64_t **)(arg1 + 0x40);
                    *piVar15 = iVar2;
                    *(undefined4 *)(piVar15 + 1) = 0;
                    *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    cVar10 = func_0x000180024130(arg1, 0x180782488, 2);
                    if (cVar10 == '\0') {
                        return 1;
                    }
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    if (((*(char *)0x180777010 == '\0') ||
                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                        puVar16 = *(undefined4 **)(arg1 + 0x40);
                        puVar13 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar16 + -4), 1);
                        piVar1 = *(int64_t **)0x180782430;
                        uVar7 = puVar13[1];
                        uVar8 = puVar13[2];
                        uVar9 = puVar13[3];
                        *puVar16 = *puVar13;
                        puVar16[1] = uVar7;
                        puVar16[2] = uVar8;
                        puVar16[3] = uVar9;
                        piVar15 = *(int64_t **)(arg1 + 0x40);
                        *(int64_t **)(arg1 + 0x40) = piVar15 + 2;
                        if ((piVar15 == piVar1) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
                            *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                            return 1;
                        }
                        piVar12 = piVar15;
                        if (piVar15 == piVar1) {
                            piVar12 = (int64_t *)0x0;
                        }
                        iVar3 = *piVar12;
                        *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                        *(undefined8 *)(iVar2 + 0x20) = *(undefined8 *)(iVar3 + 0x20);
                        *(int64_t *)(iVar2 + 0x28) =
                             ((iVar3 + 0x28) - (int64_t)(int64_t *)(iVar2 + 0x28)) + *(int64_t *)(iVar3 + 0x28);
                        if (((*(char *)0x180777010 == '\0') ||
                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                            puVar5 = *(undefined8 **)(arg1 + 0x40);
                            *puVar5 = 0x180782488;
                            *(undefined4 *)(puVar5 + 1) = 0;
                            *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                            if (((*(char *)0x180777010 == '\0') ||
                                (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                               (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                func_0x000180087440(arg1, 0xffffd8f0);
                                if (((*(char *)0x180777010 == '\0') ||
                                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                    puVar5 = *(undefined8 **)(arg1 + 0x40);
                                    *puVar5 = 0x1807824a0;
                                    *(undefined4 *)(puVar5 + 1) = 0;
                                    *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                    if (((*(char *)0x180777010 == '\0') ||
                                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                        func_0x000180087440(arg1, 0xffffd8f0);
                                        func_0x000180086ba0(arg1, iVar2, 0);
                                        iVar2 = *(int64_t *)(arg1 + 0x40);
                                        iVar3 = *(int64_t *)(arg1 + 0x28);
                                        func_0x000180023f30(arg1, 0x180782470, 2);
                                        func_0x000180085bf0(arg1, iVar2 - iVar3 >> 4 & 0xffffffff);
                                        fcn.180086510(arg1);
                                        func_0x000180087440(arg1, 0xfffffffd);
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
                                        if (((*(char *)0x180777010 == '\0') ||
                                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                            puVar16 = *(undefined4 **)(arg1 + 0x40);
                                            *puVar16 = 1;
                                            puVar16[3] = 1;
                                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar6 = (code *)swi(3);
        uVar14 = (*pcVar6)();
        return uVar14;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_1800528e0
// Address: 0x1800528e0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180052490(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    char cVar10;
    int32_t iVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t unaff_RBP;
    undefined4 *puVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar15 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar12 = piVar15;
    if (piVar1 <= piVar15) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar12 + 0xc) == 8)) {
        if (piVar1 <= piVar15) {
            piVar15 = *(int64_t **)0x180782430;
        }
        if (piVar15 == *(int64_t **)0x180782430) {
            piVar15 = (int64_t *)0x0;
        }
        iVar2 = *piVar15;
        if (((*(char *)0x180777010 == '\0') || (piVar1 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
            puVar16 = *(undefined4 **)(arg1 + 0x40);
            *puVar16 = 0;
            puVar16[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if (*(char *)(iVar2 + 3) == '\0') {
                return 1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                piVar15 = *(int64_t **)(arg1 + 0x40);
                *piVar15 = iVar2;
                *(undefined4 *)(piVar15 + 1) = 0;
                *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                cVar10 = func_0x000180024130(arg1, 0x1807824a0, 2);
                if (cVar10 == '\0') {
                    return 1;
                }
                iVar3 = *(int64_t *)(arg1 + 0x40);
                iVar11 = *(int32_t *)(iVar3 + -4);
                if (iVar11 == 6) {
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 0x14);
                } else if (iVar11 == 7) {
                    iVar11 = func_0x0001800a1110(*(undefined8 *)(iVar3 + -0x10));
                } else {
                    if ((iVar11 != 9) && (iVar11 != 0xb)) {
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        return 1;
                    }
                    iVar11 = *(int32_t *)(*(int64_t *)(iVar3 + -0x10) + 4);
                }
                uVar4 = *(uint64_t *)(arg1 + 0x40);
                *(uint64_t *)(arg1 + 0x40) = uVar4 - 0x10;
                if (iVar11 == 0) {
                    return 1;
                }
                if (((*(char *)0x180777010 == '\0') || (uVar4 <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                    piVar15 = *(int64_t **)(arg1 + 0x40);
                    *piVar15 = iVar2;
                    *(undefined4 *)(piVar15 + 1) = 0;
                    *(undefined4 *)((int64_t)piVar15 + 0xc) = 2;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    cVar10 = func_0x000180024130(arg1, 0x180782488, 2);
                    if (cVar10 == '\0') {
                        return 1;
                    }
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    if (((*(char *)0x180777010 == '\0') ||
                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                        puVar16 = *(undefined4 **)(arg1 + 0x40);
                        puVar13 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar16 + -4), 1);
                        piVar1 = *(int64_t **)0x180782430;
                        uVar7 = puVar13[1];
                        uVar8 = puVar13[2];
                        uVar9 = puVar13[3];
                        *puVar16 = *puVar13;
                        puVar16[1] = uVar7;
                        puVar16[2] = uVar8;
                        puVar16[3] = uVar9;
                        piVar15 = *(int64_t **)(arg1 + 0x40);
                        *(int64_t **)(arg1 + 0x40) = piVar15 + 2;
                        if ((piVar15 == piVar1) || (*(int32_t *)((int64_t)piVar15 + 0xc) != 8)) {
                            *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                            return 1;
                        }
                        piVar12 = piVar15;
                        if (piVar15 == piVar1) {
                            piVar12 = (int64_t *)0x0;
                        }
                        iVar3 = *piVar12;
                        *(int64_t **)(arg1 + 0x40) = piVar15 + -2;
                        *(undefined8 *)(iVar2 + 0x20) = *(undefined8 *)(iVar3 + 0x20);
                        *(int64_t *)(iVar2 + 0x28) =
                             ((iVar3 + 0x28) - (int64_t)(int64_t *)(iVar2 + 0x28)) + *(int64_t *)(iVar3 + 0x28);
                        if (((*(char *)0x180777010 == '\0') ||
                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                            puVar5 = *(undefined8 **)(arg1 + 0x40);
                            *puVar5 = 0x180782488;
                            *(undefined4 *)(puVar5 + 1) = 0;
                            *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                            if (((*(char *)0x180777010 == '\0') ||
                                (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                               (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                func_0x000180087440(arg1, 0xffffd8f0);
                                if (((*(char *)0x180777010 == '\0') ||
                                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                   (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                    puVar5 = *(undefined8 **)(arg1 + 0x40);
                                    *puVar5 = 0x1807824a0;
                                    *(undefined4 *)(puVar5 + 1) = 0;
                                    *(undefined4 *)((int64_t)puVar5 + 0xc) = 2;
                                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                    if (((*(char *)0x180777010 == '\0') ||
                                        (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                       (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                        func_0x000180087440(arg1, 0xffffd8f0);
                                        func_0x000180086ba0(arg1, iVar2, 0);
                                        iVar2 = *(int64_t *)(arg1 + 0x40);
                                        iVar3 = *(int64_t *)(arg1 + 0x28);
                                        func_0x000180023f30(arg1, 0x180782470, 2);
                                        func_0x000180085bf0(arg1, iVar2 - iVar3 >> 4 & 0xffffffff);
                                        fcn.180086510(arg1);
                                        func_0x000180087440(arg1, 0xfffffffd);
                                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
                                        if (((*(char *)0x180777010 == '\0') ||
                                            (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                                           (iVar11 = fcn.180085510(unaff_RBP), iVar11 != 0)) {
                                            puVar16 = *(undefined4 **)(arg1 + 0x40);
                                            *puVar16 = 1;
                                            puVar16[3] = 1;
                                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar6 = (code *)swi(3);
        uVar14 = (*pcVar6)();
        return uVar14;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_180052900
// Address: 0x180052900
// Size: 498 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800529de: Changing call to branch
// WARNING: Possible PIC construction at 0x000180052a19: Changing call to branch
// WARNING: Possible PIC construction at 0x000180052a54: Changing call to branch
// WARNING: Possible PIC construction at 0x000180052a8f: Changing call to branch
// WARNING: Possible PIC construction at 0x000180052aca: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180052a94)
// WARNING: Removing unreachable block (ram,0x000180052a59)
// WARNING: Removing unreachable block (ram,0x000180052a1e)
// WARNING: Removing unreachable block (ram,0x0001800529e3)
// WARNING: Removing unreachable block (ram,0x000180052acf)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.180052900(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_98 [32];
    undefined8 uStack_78;
    undefined4 uStack_6c;
    uint64_t uStack_68;
    int64_t iStack_58;
    undefined8 uStack_50;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    func_0x000180023f30(arg2, 0x180782470, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    func_0x000180023f30(arg2, 0x1807824b0, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    func_0x000180023f30(arg2, 0x1807824a0, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    func_0x000180023f30(arg2, 0x180782488, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    func_0x000180023f30(arg2, 0x1807824a8, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    func_0x000180018f70();
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180052020, 0x180623f68, 0);
    uStack_50 = 0;
    uStack_68 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    iVar4 = (int32_t)(iVar1 - iVar2 >> 4);
    iStack_58 = arg2;
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar5 = func_0x000180085370();
        } else {
            uVar5 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar5 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
    }
    piVar6 = (int64_t *)(arg2 + 0x40);
    uVar3 = fcn.180498cd0(0x180623f68);
    uStack_78 = fcn.18009a8e0(arg2, 0x180623f68, uVar3);
    uStack_6c = 6;
    func_0x0001800a8680(arg2, uVar5, &uStack_78, *piVar6 + -0x10);
    *piVar6 = *piVar6 + -0x10;
    fcn.180459870(uStack_68 ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_180052b00
// Address: 0x180052b00
// Size: 619 bytes
// ============================================================
int64_t fcn.180052b00(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    float fVar9;
    float fVar10;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar7 = (((((((((uint64_t)*(uint8_t *)arg3 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg3 + 1))
                  * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg3 + 2)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg3 + 3)
                ) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg3 + 4)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg3 + 5)
              ) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg3 + 6)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg3 + 7))
            * 0x100000001b3;
    puVar5 = *(undefined8 **)(*(int64_t *)0x18077af98 + 8 + (uVar7 & *(uint64_t *)0x18077afb0) * 0x10);
    puVar8 = *(undefined8 **)0x18077af88;
    if (puVar5 != *(undefined8 **)0x18077af88) {
        iVar6 = puVar5[2];
        puVar8 = puVar5;
        while( true ) {
            if (*(int64_t *)arg3 == iVar6) {
                *(undefined8 **)arg2 = puVar8;
                *(undefined *)(arg2 + 8) = 0;
                return arg2;
            }
            if (puVar8 == *(undefined8 **)(*(int64_t *)0x18077af98 + (uVar7 & *(uint64_t *)0x18077afb0) * 0x10)) break;
            puVar8 = (undefined8 *)puVar8[1];
            iVar6 = puVar8[2];
        }
    }
    if (*(int64_t *)0x18077af90 == 0xaaaaaaaaaaaaaaa) {
        func_0x0001804546d4(0x180620428);
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    puVar5 = (undefined8 *)func_0x000180459890(0x18);
    puVar5[2] = *(undefined8 *)arg3;
    uVar1 = *(int64_t *)0x18077af90 + 1;
    if ((int64_t)uVar1 < 0) {
        fVar9 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        fVar9 = fVar9 + fVar9;
    } else {
        fVar9 = (float)uVar1;
    }
    if ((int64_t)*(uint64_t *)0x18077afb8 < 0) {
        fVar10 = (float)(*(uint64_t *)0x18077afb8 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x18077afb8 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)*(uint64_t *)0x18077afb8;
    }
    if (*(float *)0x18077af80 < fVar9 / fVar10) {
        func_0x0001800296c0();
        puVar2 = *(undefined8 **)(*(int64_t *)0x18077af98 + 8 + (uVar7 & *(uint64_t *)0x18077afb0) * 0x10);
        puVar8 = *(undefined8 **)0x18077af88;
        if (puVar2 != *(undefined8 **)0x18077af88) {
            iVar6 = puVar2[2];
            puVar8 = puVar2;
            while (puVar5[2] != iVar6) {
                if (puVar8 == *(undefined8 **)(*(int64_t *)0x18077af98 + (uVar7 & *(uint64_t *)0x18077afb0) * 0x10))
                goto code_r0x000180052cea;
                puVar8 = (undefined8 *)puVar8[1];
                iVar6 = puVar8[2];
            }
            puVar8 = (undefined8 *)*puVar8;
        }
    }
code_r0x000180052cea:
    puVar2 = (undefined8 *)puVar8[1];
    *(int64_t *)0x18077af90 = *(int64_t *)0x18077af90 + 1;
    *puVar5 = puVar8;
    puVar5[1] = puVar2;
    *puVar2 = puVar5;
    puVar8[1] = puVar5;
    iVar6 = *(int64_t *)0x18077af98;
    uVar7 = *(uint64_t *)0x18077afb0 & uVar7;
    puVar3 = *(undefined8 **)(*(int64_t *)0x18077af98 + uVar7 * 0x10);
    if (puVar3 == *(undefined8 **)0x18077af88) {
        *(undefined8 **)(*(int64_t *)0x18077af98 + uVar7 * 0x10) = puVar5;
    } else {
        if (puVar3 == puVar8) {
            *(undefined8 **)(*(int64_t *)0x18077af98 + uVar7 * 0x10) = puVar5;
            goto code_r0x000180052d49;
        }
        if (*(undefined8 **)(*(int64_t *)0x18077af98 + 8 + uVar7 * 0x10) != puVar2) goto code_r0x000180052d49;
    }
    *(undefined8 **)(iVar6 + 8 + uVar7 * 0x10) = puVar5;
code_r0x000180052d49:
    *(undefined8 **)arg2 = puVar5;
    *(undefined *)(arg2 + 8) = 1;
    return arg2;
}

// ============================================================
// Function: FUN_180052d70
// Address: 0x180052d70
// Size: 495 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180052d70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = (int32_t)arg3;
    iVar5 = (int64_t)iVar3;
    iVar7 = 0;
    piVar6 = *(int64_t **)0x180782430;
    if (iVar3 < 1) {
        if (iVar3 < -9999) {
            piVar4 = (int64_t *)func_0x000180085370(arg2, arg3 & 0xffffffff);
        } else {
            piVar4 = (int64_t *)(iVar5 * 0x10 + *(int64_t *)(arg2 + 0x40));
        }
    } else {
        piVar4 = (int64_t *)(*(int64_t *)(arg2 + 0x28) + -0x10 + iVar5 * 0x10);
        if (*(int64_t **)(arg2 + 0x40) <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
    }
    if (piVar4 == piVar6) {
        iVar2 = -1;
    } else {
        iVar2 = *(int32_t *)((int64_t)piVar4 + 0xc);
        if (iVar2 == 0xb) {
            if (iVar3 < 1) {
                if (iVar3 < -9999) {
                    piVar4 = (int64_t *)func_0x000180085370(arg2, arg3 & 0xffffffff);
                } else {
                    piVar4 = (int64_t *)(iVar5 * 0x10 + *(int64_t *)(arg2 + 0x40));
                }
            } else {
                piVar4 = (int64_t *)(*(int64_t *)(arg2 + 0x28) + -0x10 + iVar5 * 0x10);
                if (*(int64_t **)(arg2 + 0x40) <= piVar4) {
                    piVar4 = piVar6;
                }
            }
            if (*(int32_t *)((int64_t)piVar4 + 0xc) == 0xb) {
                iVar5 = *piVar4 + 8;
                if (iVar5 != 0) {
                    func_0x000180054e70(arg1, iVar5, (uint64_t)*(uint32_t *)(*piVar4 + 4) + iVar5);
                    return arg1;
                }
            }
            func_0x000180088470(arg2, arg3 & 0xffffffff, 0xb);
            pcVar1 = (code *)swi(3);
            iVar5 = (*pcVar1)();
            return iVar5;
        }
        if (iVar2 == 6) {
            iStackX_20 = iVar7;
            iVar5 = func_0x0001800860c0(arg2, arg3 & 0xffffffff, &iStackX_20);
            func_0x000180054e70(arg1, iVar5, iStackX_20 + iVar5);
            return arg1;
        }
    }
    if (iVar2 == 7) {
        _var_30h = ZEXT816(0);
        var_20h = iVar7;
        func_0x000180086ed0(arg2, arg3 & 0xffffffff, 1);
        iVar3 = func_0x000180085d50(arg2, 0xffffffff);
        while (iVar3 != 0) {
            var_18h._0_1_ = func_0x000180085f50(arg2, 0xffffffff, 0);
            func_0x000180029270(&var_30h, &var_18h);
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
            func_0x000180086ed0(arg2, arg3 & 0xffffffff);
            iVar3 = func_0x000180085d50(arg2, 0xffffffff);
        }
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
        *(int64_t *)arg1 = var_30h;
        *(int64_t *)(arg1 + 8) = var_28h;
        *(int64_t *)(arg1 + 0x10) = var_20h;
        return arg1;
    }
    func_0x0001800883d0(arg2, arg3 & 0xffffffff, 0x180623fa8);
    pcVar1 = (code *)swi(3);
    iVar5 = (*pcVar1)();
    return iVar5;
}

// ============================================================
// Function: FUN_180052f60
// Address: 0x180052f60
// Size: 388 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_73h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180052f60(int64_t arg1)
{
    code *pcVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    piVar4 = (int64_t *)func_0x000180016e80();
    var_70h = 0xd;
    var_68h = 0xf;
    var_78h._0_4_ = 0x654e6b61;
    var_80h = 0x5220656c62616e45;
    var_78h._4_1_ = 0x74;
    var_78h._5_3_ = 0;
    var_50h = 0xc;
    var_48h = 0xf;
    var_58h._0_4_ = 0x73756f6e;
    var_60h = 0x616c6c656373694d;
    var_58h._4_4_ = 0;
    puVar6 = (undefined8 *)((undefined8 *)*piVar4)[1];
    for (puVar7 = *(undefined8 **)(undefined8 *)*piVar4; puVar7 != puVar6; puVar7 = puVar7 + 7) {
        puVar5 = puVar7;
        if (0xf < (uint64_t)puVar7[3]) {
            puVar5 = (undefined8 *)*puVar7;
        }
        if ((puVar7[2] == 0xc) && (iVar3 = fcn.180497f30(puVar5, &var_60h), iVar3 == 0)) {
            if (puVar7 != (undefined8 *)0x0) {
                puVar6 = (undefined8 *)puVar7[4];
                puVar7 = (undefined8 *)puVar7[5];
                goto joined_r0x000180053067;
            }
            break;
        }
    }
code_r0x000180053035:
    bVar2 = false;
code_r0x000180053037:
    if ((bVar2) && ((char)var_88h != '\0')) {
        return;
    }
    func_0x000180088560(arg1, 0x180623fd0);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
joined_r0x000180053067:
    if (puVar6 == puVar7) goto code_r0x000180053035;
    puVar5 = puVar6;
    if (0xf < (uint64_t)puVar6[3]) {
        puVar5 = (undefined8 *)*puVar6;
    }
    if ((puVar6[2] == 0xd) && (iVar3 = fcn.180497f30(puVar5, &var_80h), iVar3 == 0)) {
        if ((puVar6 != (undefined8 *)0x0) && ((puVar6 + 8 != (undefined8 *)0x0 && (*(char *)(puVar6 + 0xc) == '\0')))) {
            var_88h._0_1_ = *(char *)(puVar6 + 8);
            bVar2 = true;
            goto code_r0x000180053037;
        }
        goto code_r0x000180053035;
    }
    puVar6 = puVar6 + 0x13;
    goto joined_r0x000180053067;
}

// ============================================================
// Function: FUN_1800530f0
// Address: 0x1800530f0
// Size: 439 bytes
// ============================================================
undefined8 fcn.1800530f0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    undefined8 uStack_80;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    
    puVar8 = auStack_78;
    puVar9 = auStack_78;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar3 + 0xc) == 9) && (iVar1 = *piVar3, *(char *)(iVar1 + 3) == '|')) &&
       (puVar11 = (uint64_t *)(iVar1 + 0x10), puVar11 != (uint64_t *)0x0)) {
        fcn.180052d70((int64_t)&var_58h, arg1, 2);
        uVar12 = var_50h - var_58h;
        uVar7 = *puVar11;
        uVar6 = *(int64_t *)(iVar1 + 0x20) - uVar7;
        if (uVar6 < uVar12) {
            if (0x7fffffffffffffff < uVar12) {
                func_0x000180010010();
                goto code_r0x000180053295;
            }
            uVar10 = 0x7fffffffffffffff;
            if ((uVar6 <= 0x7fffffffffffffff - (uVar6 >> 1)) && (uVar10 = uVar6 + (uVar6 >> 1), uVar10 < uVar12)) {
                uVar10 = uVar12;
            }
            if (uVar7 != 0) {
                uVar6 = uVar7;
                puVar8 = auStack_78;
                if (0xfff < *(int64_t *)(iVar1 + 0x20) - uVar7) {
                    uVar6 = *(uint64_t *)(uVar7 - 8);
                    uVar7 = (uVar7 - uVar6) - 8;
                    puVar8 = auStack_78;
                    if (0x1f < uVar7) {
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        uVar6 = uVar7;
                        puVar8 = auStack_70;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x1800531d0;
                fcn.180459c3c(uVar6);
                *puVar11 = 0;
                *(undefined8 *)(iVar1 + 0x18) = 0;
                *(undefined8 *)(iVar1 + 0x20) = 0;
            }
            *(undefined8 *)(puVar8 + -8) = 0x1800531e8;
            func_0x000180054ef0(puVar11, uVar10);
            uVar7 = *puVar11;
            *(undefined8 *)(puVar8 + -8) = 0x1800531f9;
            fcn.180498030(uVar7, var_58h, uVar12);
            iVar4 = uVar7 + uVar12;
            puVar9 = puVar8;
        } else {
            uVar6 = *(int64_t *)(iVar1 + 0x18) - uVar7;
            iVar4 = var_58h;
            if (uVar6 < uVar12) {
                fcn.180498030(uVar7, var_58h, uVar6);
                uVar7 = *(uint64_t *)(iVar1 + 0x18);
                uVar12 = uVar12 - uVar6;
                iVar4 = uVar6 + var_58h;
            }
            fcn.180498030(uVar7, iVar4, uVar12);
            iVar4 = uVar12 + uVar7;
        }
        *(int64_t *)(iVar1 + 0x18) = iVar4;
        *(int64_t *)(iVar1 + 0x28) = var_50h - var_58h;
        *(undefined *)(iVar1 + 0x3c) = 1;
        if (var_58h != 0) {
            uVar7 = var_58h;
            if (0xfff < (uint64_t)(*(int64_t *)(puVar9 + 0x30) - var_58h)) {
                uVar7 = *(uint64_t *)(var_58h + -8);
                uVar6 = (var_58h - uVar7) - 8;
                if (0x1f < uVar6) {
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar9 = puVar9 + 8;
                    uVar7 = uVar6;
                }
            }
            *(undefined8 *)(puVar9 + -8) = 0x18005327e;
            fcn.180459c3c(uVar7);
        }
        return 0;
    }
code_r0x000180053295:
    func_0x0001800883d0();
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

